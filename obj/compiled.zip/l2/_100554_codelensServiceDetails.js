/// <mls shortName="codelensServiceDetails" project="100554" enhancement="_100554_enhancementLit" groupName="internal" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, unsafeHTML } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
export function initCodelensServiceDetails() {
    return true;
}
/// **collab_i18n_start**
const message_pt = {
    title: 'Detalhes do servi�o',
    p1: 'Para que seu service esteja disponivel para uso, � preciso configurar corretamente o service details, assim definindo o nome, icone, posi��es, level entre outras defini��es.',
    icon: 'Icone',
    p2: 'Para definir o icone, voc� precisa primeiro escolher um que mais representa ao seu service, no <a href="https://fontawesome.com/icons" target="_blank">FontAwesome </a>. Ap�s escolher, copie o seu unicode e preencha na propriedade icon.',
    example: 'Exemplo',
    state: 'Estado',
    p3: ' � possivel escolher entre o state <b>"foreground"</b> e <b>"background"</b>. No caso do foreground, o seu service ser� executado somente quando chamado em tela pelo usu�rio. No caso do background, seu service � instanciado, assim que inicia o level em que ele executa. ',
    exampleCustom: 'Exemplo Personalizado por posi��o:',
    p4: 'Tamb�m � possivel customizar, determinadas propriedades para cada level/position',
    exampleLevel: 'Exemplo Personalizado por n�vel:',
    p5: 'Tamb�m � possivel customizar, determinadas propriedades para cada level, nesse caso as configura��es ser�o aplicadas tanto para a posi��o left e right'
};
const message_en = {
    title: 'Service Details',
    p1: 'For your service to be available for use, it is necessary to properly configure the service details, thus defining the name, icon, positions, level, among other settings.',
    icon: 'Icon',
    p2: 'To set the icon, you first need to choose one that best represents your service, on <a href="https://fontawesome.com/icons" target="_blank">FontAwesome</a>. After choosing, copy its unicode and fill in the icon property.',
    example: 'Example',
    state: 'State',
    p3: 'You can choose between the states <b>"foreground"</b> and <b>"background"</b>. In the case of foreground, your service will only be executed when called on screen by the user. In the case of background, your service is instantiated as soon as the level it executes on starts.',
    exampleCustom: 'Custom Example by Position:',
    p4: 'It is also possible to customize certain properties for each level/position.',
    exampleLevel: 'Custom Example by Level:',
    p5: 'It is also possible to customize certain properties for each level; in this case, the settings will be applied to both the left and right positions.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CodeLensServiceDetails100554 = class CodeLensServiceDetails100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.textExampleIcon = `
    public details: IService = {
        <br>
        &nbsp;&nbsp;icon: '&#x[seu unicode]',
        <br>
        &nbsp;&nbsp;...
        <br>
    }
    `;
        this.textExampleNormal = `
    public details: IService = {
        <br>
        &nbsp;&nbsp;icon:'&#x[seu unicode]',
        <br>
        &nbsp;&nbsp;state: 'background',
        <br>
        &nbsp;&nbsp;tooltip: 'My service',
        <br>
        &nbsp;&nbsp;visible: true,
        <br>
        &nbsp;&nbsp;position: "right",
        <br>
        &nbsp;&nbsp;level: [3]
        <br>
    }
    `;
        this.textExampleCustom = `
    public details: IService = {
        <br>
        &nbsp;&nbsp;icon:'&#x[seu unicode]',
        <br>
        &nbsp;&nbsp;state: 'background',
        <br>
        &nbsp;&nbsp;tooltip: 'My service',
        <br>
        &nbsp;&nbsp;visible: true,
        <br>
        &nbsp;&nbsp;position: "all",
        <br>
        &nbsp;&nbsp;level: [4,5]
        <br>
        &nbsp;&nbsp;customConfiguration: {
            <br>
            &nbsp;&nbsp&nbsp;&nbsp4: {
                <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspleft: {
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsptooltip: 'My title 1'
                    <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp},
                <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspright: {
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspshow: false
                    <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp}
                <br>
            &nbsp;&nbsp&nbsp;&nbsp},
            <br>
            &nbsp;&nbsp&nbsp;&nbsp5: {
                <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspright: {
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsptooltip: 'My title 2',
                    <br>
                    &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbspclassname: 'separator-left'
                    <br>
                &nbsp;&nbsp&nbsp;&nbsp&nbsp;&nbsp}
                <br>
            &nbsp;&nbsp&nbsp;&nbsp}
            <br>
        &nbsp;&nbsp}
        <br>
    }
    `;
        this.textExampleCustomLevel = `
    public details: IService = {
        <br>
        &nbsp;&nbsp;icon:'&#x[seu unicode]',
        <br>
        &nbsp;&nbsp;state: 'background',
        <br>
        &nbsp;&nbsp;tooltip: 'My service',
        <br>
        &nbsp;&nbsp;visible: true,
        <br>
        &nbsp;&nbsp;position: "all",
        <br>
        &nbsp;&nbsp;level: [3,4,5]
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;customConfiguration: {
            <br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4: {
                <br>
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tooltip: 'My service title left and right'
                  <br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
            <br>
        &nbsp;&nbsp;&nbsp;&nbsp;}
        <br>
    }
    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <h1> ${this.msg.title} </h1>
        <p> ${this.msg.p1}
        </p>
        <h2>${this.msg.icon}</h2>
        <p> ${this.msg.p2} </p>
        <p>${this.msg.example}:</p>
        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">
            <code>${unsafeHTML(this.textExampleIcon)}</code>
        </div>
        <h2>${this.msg.state}</h2>
        <p>${this.msg.p3}</p>
        <h2>${this.msg.example}:</h2>
        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">
            <code>${unsafeHTML(this.textExampleNormal)}</code>
        </div>
        <h2>${this.msg.exampleCustom}</h2>
        <p>${this.msg.p4}</p>
        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">
            <code>${unsafeHTML(this.textExampleCustom)}</code>
        </div>
        <h2>${this.msg.exampleLevel}</h2>
        <p>${this.msg.p5}</p>
        <div style="    border: 1px solid #c3c3c3;padding: 1rem;">
            <code>${unsafeHTML(this.textExampleCustomLevel)}</code>
        </div>
    
        
        `;
    }
};
CodeLensServiceDetails100554.styles = css ``;
CodeLensServiceDetails100554 = __decorate([
    customElement('codelens-service-details-100554')
], CodeLensServiceDetails100554);
export { CodeLensServiceDetails100554 };
