/// <mls shortName="wcSection" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaLayoutFlowSectionBase } from './_100554_icaLayoutFlowSectionBase';
let WcSection100554 = class WcSection100554 extends IcaLayoutFlowSectionBase {
    render() {
        return html `
        <slot></slot>
       `;
    }
};
WcSection100554.styles = css `
        :host {
            height: 100%;
            width: 100%;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        :host(.full) {
            width: 100%;
        }
        :host(.outset) {
            max-width: 740px;
        }
        :host(.inset) {
            max-width: 680px;
        }
    `;
WcSection100554 = __decorate([
    customElement('wc-section-100554')
], WcSection100554);
export { WcSection100554 };
