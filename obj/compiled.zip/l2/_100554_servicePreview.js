/// <mls shortName="servicePreview" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// version = 1
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { convertTagToFileName } from './_100554_utilsLit';
import { initServicePreviewView } from './_100554_servicePreviewView';
import { initServicePreviewAddStyle } from './_100554_servicePreviewAddStyle';
/// **collab_i18n_start**
const message_pt = {
    theme: 'Tema',
    variations: 'Variação',
    editStyle: 'Editar estilo',
    pause: 'Parar preview',
    dark: ' escuro',
    light: 'Tema claro'
};
const message_en = {
    theme: 'Theme',
    variations: 'Variation',
    editStyle: 'Edit style',
    pause: 'Pause preview',
    dark: 'Theme dark',
    light: 'Theme light'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreview100554 = class ServicePreview100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.itens = undefined;
        this.error = '';
        this.watch = true;
        this.light = true;
        this.lastMode = 'icPreviewD';
        this.lastLevel = -1;
        this.elPreview = undefined;
        this.info = {};
        this.levels = [1, 2, 3, 4, 5, 6, 7];
        this.details = {
            icon: '&#xf06e',
            state: 'foreground',
            position: 'right',
            tooltip: 'Preview',
            visible: true,
            widget: '_100554_servicePreview',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.onClickLink = (op) => {
            if (op === 'opAboutTag')
                return this.opAboutTag();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            this.lastMode = op;
            if (op === 'icPreviewD')
                this.preview('desktop');
            if (op === 'icPreviewM')
                this.preview('mobile');
        };
        this.onClickButton = (op, opMenu) => {
            if (op === 'btWatch')
                return this.toogleWatch();
            if (op === 'btEditStyle')
                return this.editStyles();
            if (op === 'btVariations')
                return this.onBtVariationsClick(opMenu);
            if (op === 'btTheme')
                return this.onBtThemeClick();
            else
                throw new Error('Invalid option');
        };
        this.objVariations = {
            0: 'en',
            1: 'pt',
            2: 'es',
            3: 'ru'
        };
        this.menu = {
            title: 'Preview',
            actions: {},
            icons: {
                icPreviewD: 'Desktop;f390',
                icPreviewM: 'Mobile;f3cf'
            },
            buttons: {
                btTheme: `${this.msg.light};${this.msg.dark};f185;f186`,
                btVariations: this.msg.variations + ';f1ab:menu:0 - Default,1 - Portugues,2 - Espanhol,3 - Russo',
                btEditStyle: this.msg.editStyle + ';f0d0',
                btWatch: this.msg.pause + ';Update Preview;f04c;f04b',
            },
            actionDefault: '', // call after close icon clicked
            iconDefault: 'icPreviewD',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
            onClickButton: this.onClickButton
        };
        this.timeEvent = -1;
        this.htmlAbout = '';
        initServicePreviewView;
        initServicePreviewAddStyle;
        this.setEvents();
        // this.getTheme();
    }
    getIframePreviewHTML() {
        const htmlEl = this.previousElementSibling
            ?.querySelector('service-preview-view-100554')
            ?.shadowRoot
            ?.querySelector('iframe')
            ?.contentDocument
            ?.querySelector('html');
        return htmlEl;
    }
    onBtVariationsClick(opMenu) {
        if (!opMenu)
            return true;
        const htmlEl = this.getIframePreviewHTML();
        const variation = opMenu.substring(0, 1);
        if (htmlEl)
            htmlEl.lang = this.objVariations[variation];
        window.globalVariation = !isNaN(+variation) ? +variation : 0;
        if (window.top)
            window.top.window.globalVariation = !isNaN(+variation) ? +variation : 0;
        this.requestUpdateAllIcaComponentsInPage();
        return true;
    }
    onBtThemeClick() {
        this.light = !this.light;
        const htmlEl = this.getIframePreviewHTML();
        if (htmlEl) {
            if (this.light)
                htmlEl.removeAttribute('data-theme');
            else
                htmlEl.setAttribute('data-theme', 'dark');
        }
        this.onStyleChanged();
        return this.light;
    }
    toogleWatch() {
        this.watch = !this.watch;
        if (this.watch) {
            this.onReloader();
        }
        return this.watch;
    }
    editStyles() {
        this.openService('_100554_serviceDsStyles', 'left', 3);
        return true;
    }
    onServiceClick(visible, reinit) {
        if (visible && !reinit && this.menu.setIconActive) {
            this.menu.setIconActive(this.lastMode);
        }
        else if (visible && reinit && this.elPreview && this.menu.setIconActive && this.lastLevel == this.level) {
            this.menu.setIconActive(this.lastMode);
        }
        if (this.elPreview) {
            this.lastLevel = this.level;
            this.elPreview.setAttribute('level', this.level.toString());
        }
        else {
            this.preview(this.lastMode);
        }
    }
    // -------------- EVENTS -------------------
    setEvents() {
        mls.events.addListener(2, 'FileAction', this.onMLSFileAction.bind(this));
        mls.events.addEventListener([3], ['DSStyleChanged', 'DSColorChanged', 'DSCustomChanged', 'DSTYPOChanged'], async (ev) => {
            const rc = JSON.parse(ev.desc);
            if (rc.emitter === 'right' ||
                rc.emitter === 'right-get' ||
                (rc.emitter === 'left' && rc.helper))
                return;
            if (this.watch)
                this.onStyleChanged();
        });
    }
    onReloader() {
        clearTimeout(this.timeEvent);
        this.timeEvent = setTimeout(async () => {
            this.onServiceClick(true, false);
            mls.events.fire((+this.level), 'WCDEventChange', `{"op":"Navigation"}`);
        }, 500);
    }
    onStyleChanged() {
        if (this.elPreview) {
            this.lastLevel = this.level;
            this.elPreview.setAttribute('stylechanged', 'true');
        }
    }
    async onMLSFileAction(ev) {
        try {
            if (this.visible === 'false' || !this.visible)
                return;
            if (ev.level !== +this.level || (ev.type !== 'FileAction'))
                return;
            const fileAction = JSON.parse(ev.desc);
            const eventsValid = ['open', 'statusOrErrorChanged', 'changed', 'new'];
            if (fileAction.position === this.position ||
                !eventsValid.includes(fileAction.action))
                return;
            if (this.watch)
                this.onReloader();
        }
        catch (e) {
            console.info(e);
        }
    }
    activeMe(status, click) {
        if (!this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', status);
        if (click)
            this.serviceItemNav.click();
    }
    // -------------- COMPONENT ---------------
    async connectedCallback() {
        super.connectedCallback();
        const dsIndex = mls.actual[3].mode && +this.level !== 2 ? mls.actual[3].mode : 0;
        const ds = mls.l3.getDSInstance(mls.actual[5].project, dsIndex);
        await ds.init();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html ``;
    }
    firstUpdated() {
        const theme = this.getTheme();
        if (theme === 'dark' && this.menu.selectButton) {
            this.menu.selectButton('btTheme');
        }
    }
    // -------------- IMPLEMENTS-----------------
    getTheme() {
        const theme = localStorage.getItem('_100554_serviceUserSettings_theme') || 'light';
        return theme;
    }
    async setAboutTag(tag) {
        try {
            if (!tag)
                return false;
            const file = convertTagToFileName(tag.toLocaleLowerCase());
            this.htmlAbout = `  
                <h3>About this Component</h3>
                <ul>
                    <li>Reference: ${file}</li>
                    <li>Tag: ${tag} </li>
                    <li>Level: 2 </li>                    
                </ul>`;
            if (this.menu.setMenuActive && this.htmlAbout)
                this.menu.setMenuActive('opAboutTag');
        }
        catch (e) {
            console.info(e);
            return false;
        }
    }
    opAboutTag() {
        const doc = document.createElement('div');
        doc.innerHTML = this.htmlAbout;
        if (this.menu.setMode)
            this.menu.setMode('page', doc);
        return true;
    }
    async preview(mode) {
        if (!mls.actual[2].left)
            return true;
        const fullname = `_${mls.actual[2].left.project}_${mls.actual[2].left.shortName}`;
        this.menu.title = 'Preview: ' + fullname;
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        const doc = document.createElement('service-preview-view-100554');
        doc.setAttribute('page', fullname);
        doc.setAttribute('level', this.level);
        doc.setAttribute('mode', mode);
        doc.father = this;
        this.lastLevel = this.level;
        this.elPreview = doc;
        if (this.menu.setMode)
            this.menu.setMode('page', doc);
        return true;
    }
    requestUpdateAllIcaComponentsInPage() {
        const body = this.previousElementSibling
            ?.querySelector('service-preview-view-100554')
            ?.shadowRoot
            ?.querySelector('iframe')
            ?.contentDocument
            ?.querySelector('body');
        if (!body)
            return;
        const elements = this.findAllElementsIca(body);
        if (!elements)
            return;
        elements.forEach((el) => {
            if (el.tagName.split('-').length > 1 && el.globalVariation !== undefined) {
                el.globalVariation = window.globalVariation;
            }
        });
    }
    findAllElementsIca(el) {
        let elements = [];
        let elToSearch = el;
        function traverseShadowRoot(element) {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                elements.push(element);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child));
                }
            }
        }
        if (el.shadowRoot)
            elToSearch = el.shadowRoot;
        elToSearch.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item);
        });
        return elements;
    }
};
ServicePreview100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServicePreview100554.prototype, "itens", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "error", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "watch", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "light", void 0);
ServicePreview100554 = __decorate([
    customElement('service-preview-100554')
], ServicePreview100554);
export { ServicePreview100554 };
