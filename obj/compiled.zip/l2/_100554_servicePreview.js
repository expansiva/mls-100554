/// <mls shortName="servicePreview" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { getTokens } from './_100554_designSystemBase';
import { getConfigProject } from './_100554_libProjectConfig';
import { globalState, setState } from './_100554_collabState';
import { convertTagToFileName } from './_100554_utilsLit';
import { collab_record, collab_trash, collab_file_pen, collab_play, collab_test } from './_100554_collabIcons';
import { TsTestAst } from './_100554_tsTestAST';
import './_100554_collabConsole';
import './_100554_collabResultTest';
import './_100554_servicePreviewView';
/// **collab_i18n_start**
const message_pt = {
    theme: 'Tema',
    variations: 'Linguagem',
    editStyle: 'Editar estilo',
    pause: 'Preview pausado',
    run: 'Preview executando',
    dark: ' escuro',
    light: 'claro',
    help: 'Ajuda',
    consoleA: 'Console fechado',
    consoleD: 'Console aberto',
    testA: 'Teste não iniciado',
    testB: 'Teste gravando',
    testRun: 'Executar',
    testDelete: 'Excluir',
    testEdit: 'Editar',
    runAllTest: 'Todos os testes'
};
const message_en = {
    theme: 'Theme',
    variations: 'Language',
    editStyle: 'Edit style',
    pause: 'Preview paused',
    run: 'Preview running',
    dark: 'dark',
    light: 'light',
    help: 'Help',
    consoleA: 'Console closed',
    consoleD: 'Console open',
    testA: 'Test not started',
    testB: 'Test recording',
    testRun: 'Run',
    testDelete: 'Delete',
    testEdit: 'Edit',
    runAllTest: 'All testes'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreview100554 = class ServicePreview100554 extends ServiceBase {
    get confE() { return `l${this.level}_${this.position}`; }
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-nav-3-service[data-service="_100554_servicePreview"] collab-nav-3-menu-tools-cycle[key="test"][selected="0"] svg{color:var(--grey-color-darker);fill:var(--grey-color-darker)}collab-nav-3-service[data-service="_100554_servicePreview"] collab-nav-3-menu-tools-cycle[key="test"][selected="1"] svg{color:var(--error-color);fill:var(--error-color);animation:pulse 1s infinite}@keyframes pulse{0%{transform:scale(1);box-shadow:0 0 10px rgba(255,0,0,0.8)}50%{transform:scale(1.1);box-shadow:0 0 20px #f00}100%{transform:scale(1);box-shadow:0 0 10px rgba(255,0,0,0.8)}}service-preview-100554{display:block}service-preview-100554 collab-result-container-100554{display:flex;height:200px;overflow:auto;padding:1rem;background:#f4f4f4;flex-direction:column;gap:.6rem}service-preview-100554 collab-result-container-100554>div{display:flex;justify-content:end;padding:0 1rem}service-preview-100554 collab-result-container-100554>div i{cursor:pointer}`);
        this.itens = undefined;
        this.msize = '';
        this.error = '';
        this.watch = true;
        this.enabledConsole = false;
        this.enabledTest = false;
        this.light = true;
        this.lang = 'en';
        this.msg = messages['en'];
        this.lastMode = EPreview.icPreviewD;
        this.lastModePreview = 'desktop';
        this.lastLevel = -1;
        this.elPreview = undefined;
        this.themes = ['Default'];
        this.actualTheme = 'Default';
        this.languages = {};
        this.timeEvent = -1;
        this.details = {
            icon: '&#xf06e',
            state: 'foreground',
            position: 'right',
            tooltip: 'Preview',
            visible: true,
            widget: '_100554_servicePreview',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.menu = {
            title: 'Preview',
            main: {
                opAboutWCD: 'About this WCD',
                opResultHTML: 'Result HTML',
                opResultJS: 'Result Typescript',
                opResultTSTest: 'Result Typescript Test',
            },
            tabs: {
                group: 'Mode',
                type: 'full',
                selected: 0,
                options: [
                    { text: 'Desktop', icon: 'f390' },
                    { text: 'Mobile', icon: 'f3cf' },
                ]
            },
            tools: {
                test: {
                    type: 'cycle',
                    selected: 0,
                    onlyMenu: true,
                    options: [
                        { text: this.msg.testA, icon: collab_record.strings[0] },
                        { text: this.msg.testB, icon: collab_record.strings[0] },
                    ]
                },
                testList: {
                    type: 'tree-dropdown',
                    icon: collab_test.strings[0].trim(),
                    //onlyMenu: true,
                    selected: [],
                    options: []
                },
                darkLight: {
                    type: 'cycle',
                    selected: 0,
                    options: [
                        { text: this.msg.light, icon: 'f185' },
                        { text: this.msg.dark, icon: 'f186' },
                    ]
                },
                theme: {
                    type: 'dropdown',
                    icon: 'f53f',
                    onlyMenu: true,
                    selected: 0,
                    options: []
                },
                languages: {
                    type: 'dropdown',
                    selected: 0,
                    options: []
                },
                watchPreview: {
                    type: 'cycle',
                    selected: 0,
                    options: [
                        { text: this.msg.run, icon: 'f04c' },
                        { text: this.msg.pause, icon: 'f04b' },
                    ]
                },
                devConsole: {
                    type: 'cycle',
                    selected: 0,
                    onlyMenu: true,
                    options: [
                        { text: this.msg.consoleA, icon: 'f120' },
                        { text: this.msg.consoleD, icon: 'f410' },
                    ]
                },
                help: {
                    type: 'link',
                    onlyMenu: true,
                    options: [
                        { text: this.msg.help, icon: 'f059' },
                    ]
                },
            },
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
            onClickTools: this.onClickTools.bind(this),
        };
        this.lastStatusHasError = false;
        this.actualTestList = [];
        window.preview = {
            editor: undefined,
            iframe: undefined
        };
        this.setEvents();
    }
    onClickMain(op) {
        if (op === 'opAboutWCD')
            this.opAboutWCD();
        else if (op === 'opResultHTML')
            this.showEditorHTML();
        else if (op === 'opResultJS')
            this.showResultJS();
        else if (op === 'opResultTSTest')
            this.showResultTestJS();
    }
    onClickTabs(index) {
        this._ed1?.updateOptions({ readOnly: false });
        if (index === EPreview.icPreviewD) {
            this.preview('desktop');
        }
        if (index === EPreview.icPreviewM)
            this.preview('mobile');
        this.lastMode = index;
    }
    onClickTools(op) {
        if (op === 'watchPreview')
            this.toogleWatch();
        else if (op === 'devConsole')
            this.toogleConsole();
        else if (op === 'help')
            this.onHelpClick();
        else if (op === 'test')
            this.onBtTestClick();
        else if (op === 'testList')
            this.onBtTestListClick();
        else if (op === 'darkLight')
            this.onBtDarkLightClick();
        else if (['languages', 'theme'].includes(op)) {
            this.actButton(op);
        }
        else
            throw new Error('Invalid option');
    }
    async actButton(op) {
        await this.fireWcdChanges();
        if (op === 'languages')
            return this.onBtLanguageClick();
        if (op === 'theme')
            return this.onBtThemeClick();
    }
    onServiceClick(visible, reinit) {
        if (!visible)
            return;
        if (this.elPreview) {
            this.lastLevel = this.level;
            this.elPreview.setAttribute('level', this.level.toString());
        }
        else {
            this.onReloader();
        }
    }
    // -------------- EVENTS -------------------
    setEvents() {
        mls.events.addEventListener([2, 3, 4, 5, 6, 7], ['ModelHTMLCreated'], (ev) => { this.onModelHTMLCreated(ev); });
        mls.events.addEventListener([2, 5], ['FileAction'], this.onMLSFileAction.bind(this));
        mls.events.addListener(2, 'styleChanged', this.onStyleChanged.bind(this));
        mls.events.addListener(2, 'tsTestChanged', this.onTsTestChanged.bind(this));
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['LevelChanged'], this.onLevelChange.bind(this));
    }
    onReloader() {
        clearTimeout(this.timeEvent);
        this.timeEvent = setTimeout(async () => {
            this.preview(this.lastModePreview);
            mls.events.fire((+this.level), 'WCDEventChange', `{"op":"Navigation"}`);
        }, 500);
    }
    onModelHTMLCreated(ev) {
        try {
            if (!ev.desc)
                return;
            if (ev.level !== this.level)
                return;
            const iPath = JSON.parse(ev.desc);
            if (!iPath || !iPath.project || !iPath.shortName)
                return;
            const keyStorFile = mls.stor.getKeyToFiles(iPath.project, 2, iPath.shortName, '', '.html');
            const storFile = mls.stor.files[keyStorFile];
            if (!storFile)
                throw new Error('Invalid stor file for path:' + keyStorFile);
            this.setModel(storFile);
        }
        catch (err) {
            throw new Error(err);
        }
    }
    onStyleChanged() {
        if (this.elPreview) {
            this.lastLevel = this.level;
            if (this.actualFile) {
                const keyToFileInfo = mls.stor.getKeyToFiles(this.actualFile.project, 2, this.actualFile.shortName, this.actualFile.folder, '.less');
                const less = mls.stor.files[keyToFileInfo];
                if (less && !less.hasError && this.lastStatusHasError) {
                    if (this.watch) {
                        this.elPreview = undefined;
                        this.loading = false;
                        this.onReloader();
                        this.lastStatusHasError = false;
                        return;
                    }
                }
                else if (less && less.hasError) {
                    this.lastStatusHasError = true;
                }
            }
            this.elPreview.setAttribute('stylechanged', 'true');
            this.elPreview.setAttribute('actualtheme', this.actualTheme);
        }
    }
    onLevelChange(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (data.to === 7 || data.from === 7) {
            if (this.watch) {
                this.onReloader();
            }
        }
    }
    onTsTestChanged() {
        if (this.watch) {
            this.elPreview = undefined;
            this.loading = false;
            this.setTest();
            this.onReloader();
        }
    }
    async onMLSFileAction(ev) {
        try {
            if (![2, 5].includes(ev.level) || (ev.type !== 'FileAction') || !ev.desc)
                return;
            const fileAction = JSON.parse(ev.desc);
            // if ((this.visible === 'false') && !((fileAction.action as any) === 'openBackground')) return;
            const eventsValid = ['open', 'openBackground', 'statusOrErrorChanged', 'changed', 'new', 'modeCreated'];
            if (fileAction.position === this.position ||
                !eventsValid.includes(fileAction.action))
                return;
            const keyToFileInfo = mls.stor.getKeyToFiles(fileAction.project, 2, fileAction.shortName, fileAction.folder, '.html');
            const storFileHTML = mls.stor.files[keyToFileInfo];
            if (fileAction.action === 'open' || fileAction.action === 'openBackground') {
                this.setModel(storFileHTML);
                this.actualFile = storFileHTML;
                if (!this.watch && this.menu.selectTool) {
                    this.menu.selectTool('watchPreview');
                }
            }
            if (mls.istrace)
                console.info('is preview repaint:' + this.watch);
            if (fileAction.action === 'openBackground') {
                this.elPreview = undefined;
                this.preview('desktop');
                return;
            }
            if (fileAction.action === 'open') {
                this.loading = true;
                return;
            }
            if (this.menu && this.menu.closeMenu)
                this.menu.closeMenu();
            if (this.watch) {
                this.elPreview = undefined;
                this.loading = false;
                this.setTest();
                this.onReloader();
            }
        }
        catch (e) {
            console.info(e);
        }
    }
    // -------------- COMPONENT ---------------
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<div style="height:100%;" id="preview-container"></div>`;
    }
    async firstUpdated() {
        this.createEditor();
        const darkOrLight = this.getDarkLight();
        if (darkOrLight === 'dark' && this.menu.selectTool)
            this.menu.selectTool('darkLight');
        this.setLanguages();
        this.setTheme();
        this.setTest();
        this.configureButtonsRight(false);
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        const hasMsize = changedProperties.has('msize');
        if (hasMsize) {
            const msize = changedProperties.get('msize');
            if (!msize || typeof msize !== 'string' || !this.monacoeditor)
                return;
            this.monacoeditor.setAttribute('msize', msize);
            if (this.pluginResultJS)
                this.pluginResultJS.setAttribute('msize', msize);
            if (this.pluginResultTestJS)
                this.pluginResultTestJS.setAttribute('msize', msize);
            const pageOverlay = window.preview.iframe?.contentDocument?.body.querySelector('*[modeoverlay]');
            if (!pageOverlay)
                return;
            const pageOverlayName = pageOverlay.getAttribute('modeoverlay');
            if (!pageOverlayName)
                return;
            const wcdOverlay = pageOverlay.querySelector(pageOverlayName);
            if (wcdOverlay)
                wcdOverlay.setAttribute('msize', msize);
        }
    }
    // -------------- IMPLEMENTS-----------------
    configureButtonsRight(enabled) {
        const buttonsR = this.nav3Service?.querySelector('collab-nav-3-menu .tools');
        if (!buttonsR)
            return;
        buttonsR.style.opacity = enabled ? '1' : '.2';
        buttonsR.style.pointerEvents = enabled ? 'all' : 'none';
    }
    opAboutWCD() {
        if (!this.menu.setMode)
            return;
        const el = document.createElement("div");
        el.style.padding = '1rem';
        if (!window['preview'] || !window['preview'].iframe || !window['preview'].iframe.contentWindow || !window['preview'].iframe.contentWindow.wcdState) {
            el.innerHTML = `<h3>Not found any information about this page</h3>`;
            this.menu.setMode('page', el);
            return;
        }
        ;
        const info = window['preview'].iframe.contentWindow.wcdState;
        const elOverlay = window['preview'].iframe.contentDocument?.body.querySelector('*[modeoverlay]');
        let txt = '<h3>About this page</h3><ul>';
        if (elOverlay && elOverlay.getAttribute('modeoverlay')) {
            const n = elOverlay.getAttribute('modeoverlay');
            txt += `<li><b>Overlay:</b> ${convertTagToFileName(n)}</li>`;
        }
        if (info.elICA) {
            txt += `<li><b>Select:</b> ${convertTagToFileName(info.elICA.tagName.toLowerCase())}</li>`;
        }
        if (info.elMain) {
            txt += `<li><b>Element render:</b> ${convertTagToFileName(info.elMain.tagName.toLowerCase())}</li>`;
        }
        if (info.myParent) {
            txt += `<li><b>Main wcd:</b> ${convertTagToFileName(info.myParent.tagName.toLowerCase())}</li>`;
        }
        if (info.wcdItens && info.wcdItens.length > 0) {
            txt += `<li><b>Wcd itens:</b>`;
            info.wcdItens.forEach((it) => {
                txt += `<br/>${convertTagToFileName(it.tagName.toLowerCase())}`;
            });
            txt += `</li>`;
        }
        txt += `</ul>`;
        el.innerHTML = txt;
        this.menu.setMode('page', el);
        return;
    }
    showEditorHTML() {
        if (this.menu.setMode) {
            this.menu.setMode('page', this.monacoeditor);
            this._ed1?.updateOptions({ readOnly: true });
            this._ed1?.layout();
            this.monacoeditor?.setAttribute('msize', this.msize);
        }
        return true;
    }
    showResultJS() {
        import('./_100554_pluginPreviewResultJs');
        if (this.menu.setMode) {
            this.pluginResultJS = document.createElement('plugin-preview-result-js-100554');
            this.pluginResultJS.setAttribute('msize', this.msize);
            this.menu.setMode('page', this.pluginResultJS);
            this.menu.title = 'Result Typescript';
            if (this.menu.updateTitle)
                this.menu.updateTitle();
        }
        return true;
    }
    showResultTestJS() {
        import('./_100554_pluginPreviewResultTestJs');
        if (this.menu.setMode) {
            this.pluginResultTestJS = document.createElement('plugin-preview-result-test-js-100554');
            this.pluginResultTestJS.setAttribute('msize', this.msize);
            this.menu.setMode('page', this.pluginResultTestJS);
            this.menu.title = 'Result Test Typescript';
            if (this.menu.updateTitle)
                this.menu.updateTitle();
        }
        return true;
    }
    getIframePreviewHTML() {
        if (!window.preview.iframe)
            throw new Error('Preview no created yet');
        const htmlEl = window.preview.iframe
            ?.contentDocument
            ?.querySelector('html');
        return htmlEl;
    }
    async setTest() {
        this.refreshAST();
        if (!this.astTSTest)
            return;
        const fileTests = this.astTSTest.getTests();
        const opts = fileTests.flatMap(item => item.params.map((_, indexParam) => ({
            text: item.params.length > 1 ? `${item.functionName}(${indexParam})` : item.functionName,
            functionName: item.functionName,
            index: indexParam,
            options: [
                { text: this.msg.testRun, icon: collab_play.strings[0] },
                { text: this.msg.testDelete, icon: collab_trash.strings[0] },
                { text: this.msg.testEdit, icon: collab_file_pen.strings[0] },
            ]
        })));
        const optAllTests = [{
                text: this.msg.runAllTest,
                functionName: '',
                index: -1,
                options: [
                    { text: this.msg.testRun, icon: collab_play.strings[0] }
                ]
            }];
        const rcOpts = opts.length > 0 ? [...optAllTests, ...opts] : opts;
        this.actualTestList = rcOpts;
        if (opts.length >= 0 && this.menu.tools.testList) {
            this.menu.tools.testList.options = rcOpts;
        }
        this.menu.refresh?.('tools');
    }
    onBtTestClick() {
        if (!this.menu || !this.menu.tools || !this.menu.tools.test || this.menu.tools.test.selected === undefined)
            return;
        const selectedTest = this.menu.tools.test.selected;
        if (selectedTest === ERecord.Play) {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentWindow || !iframe.contentWindow.globalStateManagment)
                return;
            const ica = iframe.contentWindow.globalStateManagment;
            ica.clearHistory();
        }
        else if (selectedTest === ERecord.Stop) {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentWindow || !iframe.contentWindow.globalStateManagment)
                return;
            const ica = iframe.contentWindow.globalStateManagment;
            const script = this.getScriptTest(ica);
            this.fireEventsDetails(script);
        }
    }
    fireEventsDetails(script) {
        if (!script)
            return;
        const options = {
            shortName: undefined,
            project: undefined,
            htmlText: `<collab-process-test-100554 
                script=${btoa(script.func)}
            ></collab-process-test-100554>`,
            arguments: script
        };
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
    addTestResultItem(title, status, clear = true) {
        const item = document.createElement('collab-result-test-100554');
        item.setAttribute('testName', title);
        item.setAttribute('status', status);
        const collabResult = this.parentElement?.querySelector('collab-result-container-100554');
        if (clear)
            collabResult.querySelectorAll('collab-result-test-100554').forEach((item) => item.remove());
        collabResult.appendChild(item);
        this.openTestResults();
        return item;
    }
    async runTest(actualData, clear) {
        if (!this.astTSTest)
            throw new Error('Invalid AST');
        const testItem = this.addTestResultItem(actualData.functionName, 'running', clear);
        try {
            const result = await this.astTSTest.runTest(actualData.functionName, actualData.index);
            testItem.setAttribute('resultStatus', 'pass');
            testItem.setAttribute('result', result);
        }
        catch (err) {
            testItem.setAttribute('resultStatus', 'failed');
            testItem.setAttribute('result', err.message);
            throw new Error();
        }
        finally {
            testItem.setAttribute('status', 'finished');
        }
    }
    async runAllTests() {
        for (let i = 0; i < this.actualTestList.length; i++) {
            const data = this.actualTestList[i];
            if (data.index === -1)
                continue;
            if (!data.functionName)
                continue;
            try {
                await this.runTest(data, i === 1 ? true : false);
            }
            catch (error) {
                break;
            }
        }
    }
    async onBtTestListClick() {
        if (!mls.actual[2].left)
            return;
        if (!this.menu || !this.menu.tools || !this.menu.tools.testList)
            return;
        const selectedIndex = this.menu.tools.testList.selected;
        const [testIndex, actionIndex] = selectedIndex;
        const actualData = this.actualTestList[testIndex];
        if (actionIndex === ETestActions.Run) {
            this.refreshAST();
            if (!this.astTSTest)
                throw new Error('Invalid AST');
            if (actualData.index === -1) {
                this.runAllTests();
                return;
            }
            this.runTest(actualData, true);
        }
        else if (actionIndex === ETestActions.Delete) {
            await this.deleteTest(actualData.functionName, actualData.index);
            this.setTest();
        }
        else if (actionIndex === ETestActions.Edit) {
            if (!actualData) {
                this.error = 'Invalid test';
                return;
            }
            if (this.level !== 2)
                this.selectLevel(2);
            setTimeout(() => { setState('serviceSource.left.selectedMode', 'icTest'); }, 200);
            setTimeout(() => { this.astTSTest?.goToTest(actualData.functionName); }, 200);
        }
    }
    async deleteTest(testName, indexParams) {
        this.refreshAST();
        if (!this.astTSTest)
            throw new Error('Invalid AST');
        try {
            this.astTSTest.deleteTest(testName, indexParams);
        }
        catch (err) {
            this.error = err.message;
        }
    }
    refreshAST() {
        if (!this.actualFile)
            return false;
        const fileName = `_${this.actualFile.project}_${this.actualFile.shortName}`;
        const models = mls.editor.models[fileName];
        if (!models) {
            this.error = `No found models for file: ${fileName}`;
            return false;
        }
        if (!models.test) {
            this.error = `No found model test in file: ${fileName}`;
            return false;
        }
        const editor = mls.services['100554_serviceSource_left']._ed1;
        this.astTSTest = new TsTestAst(models.test, editor);
    }
    onBtLanguageClick() {
        if (this.menu.tools.languages.selected === undefined)
            return;
        const opMenu = this.menu.tools.languages.options[this.menu.tools.languages.selected].text;
        const htmlEl = this.getIframePreviewHTML();
        if (htmlEl)
            htmlEl.lang = this.languages[opMenu].acronym;
        this.lang = this.languages[opMenu].acronym;
        const variation = Object.keys(this.languages).indexOf(opMenu);
        globalState.globalVariation = !isNaN(variation) ? variation : 0;
        if (window.top)
            window.top.window.globalVariation = !isNaN(variation) ? variation : 0;
        if (this.level === 7)
            this.requestUpdateAllIcaComponentsInPage();
        else
            this.onReloader();
        return true;
    }
    onBtDarkLightClick() {
        this.light = !this.light;
        if (!mls.actual[2].left || !this.watch)
            return this.light;
        const htmlEl = this.getIframePreviewHTML();
        if (htmlEl) {
            if (this.light)
                htmlEl.removeAttribute('data-theme');
            else
                htmlEl.setAttribute('data-theme', 'dark');
        }
        this.onStyleChanged();
        return this.light;
    }
    onBtThemeClick() {
        if (this.menu.tools.theme.selected === undefined)
            return;
        const opMenu = this.menu.tools.theme.options[this.menu.tools.theme.selected].text;
        this.actualTheme = opMenu;
        this.onStyleChanged();
        return true;
    }
    toogleWatch() {
        this.elPreview = undefined;
        this.watch = this.menu.tools.watchPreview.selected === 0;
        if (this.watch)
            this.onReloader();
    }
    toogleConsole() {
        this.enabledConsole = this.menu.tools.devConsole.selected === 1;
        const collabConsole = this.parentElement?.querySelector('collab-console-100554');
        if (!collabConsole)
            return;
        collabConsole.style.display = this.enabledConsole ? 'block' : 'none';
        collabConsole.setAttribute('mode', this.enabledConsole ? 'enabled' : 'disabled');
    }
    openTestResults() {
        this.enabledTest = true;
        const collabResult = this.parentElement?.querySelector('collab-result-container-100554');
        if (!collabResult)
            return;
        collabResult.style.display = 'flex';
    }
    closeTestResults() {
        this.enabledTest = false;
        const collabResult = this.parentElement?.querySelector('collab-result-container-100554');
        if (!collabResult)
            return;
        collabResult.style.display = 'none';
    }
    onHelpClick() {
        this.openService('_100554_servicePage', 'left', 3);
    }
    createEditor() {
        if (!this.monacoeditor) {
            this.monacoeditor = document.createElement('mls-editor-100529');
            this.monacoeditor.setAttribute('ismls2', 'true');
            const [width, height] = this.msize.split(',');
            this.monacoeditor.style.width = width + 'px';
            this.monacoeditor.style.height = height + 'px';
        }
        if (this._ed1)
            return;
        this._ed1 = monaco.editor.create(this.monacoeditor, mls.editor.conf[this.confE]);
        monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
            noImplicitAny: true
        });
        this.monacoeditor['mlsEditor'] = this._ed1;
        window.preview.editor = this._ed1;
    }
    async createModelIfNeeded(storFile) {
        if (!storFile)
            throw new Error('Invalid storFile');
        const uri = this.getUri(`_${storFile.project}_${storFile.shortName}`, '.html');
        let model = monaco.editor.getModel(uri);
        if (model)
            return model;
        if (this.level !== 2)
            mls.events.fire(2, ['CreateModelHTML'], JSON.stringify(storFile));
        return model;
    }
    async setModel(storFile) {
        const model = await this.createModelIfNeeded(storFile);
        if (!this._ed1 || !model)
            return;
        this._ed1.setModel(model);
    }
    getUri(shortFN, ftype) {
        return monaco.Uri.parse(`file://server/${shortFN}${ftype}`);
    }
    getDarkLight() {
        const theme = localStorage.getItem('_100554_serviceUserSettings_theme') || 'light';
        return theme;
    }
    async setLanguages() {
        const { project } = mls.actual[5];
        if (!project) {
            this.languages = {
                'English': { acronym: 'en', name: 'English' }
            };
        }
        else {
            const config = await getConfigProject(project);
            if (!config || !config.languages || config.languages.length === 0) {
                this.languages = {
                    'English': { acronym: 'en', name: 'English' }
                };
            }
            else {
                config.languages.forEach((entry, index) => {
                    this.languages[`${entry.name}`] = {
                        acronym: entry.language,
                        name: entry.name,
                    };
                });
            }
        }
        const languagesOptions = Object.keys(this.languages).map((lg) => {
            const obj = this.languages[lg];
            const newOpt = {
                text: obj.name,
                class: `collab-flags ${obj.acronym}`
            };
            return newOpt;
        });
        if (this.menu.tools.languages)
            this.menu.tools.languages.options = languagesOptions;
        if (this.menu.refresh)
            this.menu.refresh();
    }
    async setTheme() {
        const project = mls.actual[5].project;
        if (!project)
            return;
        const tokens = await getTokens(project);
        this.themes = tokens.map((item) => item.themeName);
        const themesOptions = this.themes.map((th) => {
            const newOpt = {
                text: th,
            };
            return newOpt;
        });
        if (this.menu.tools.theme)
            this.menu.tools.theme.options = themesOptions;
        if (this.menu.refresh)
            this.menu.refresh();
    }
    async preview(mode) {
        if (!mls.actual[2].left || !this.watch)
            return true;
        const fullname = `_${mls.actual[2].left.project}_${mls.actual[2].left.shortName}`;
        this.menu.title = '';
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        await this.fireWcdChanges();
        this.lastModePreview = mode;
        this.lastLevel = this.level;
        const container = document.createElement('div');
        container.style.display = 'flex';
        container.style.flexDirection = 'column';
        container.style.height = '100%'; // this.style.height;
        const doc = document.createElement('service-preview-view-100554');
        doc.setAttribute('page', fullname);
        doc.setAttribute('level', this.level);
        doc.setAttribute('mode', mode);
        doc.setAttribute('actualtheme', this.actualTheme);
        doc.setAttribute('lang', this.lang);
        doc.style.flex = '1';
        doc.father = this;
        this.elPreview = doc;
        container.appendChild(doc);
        const consoleEl = document.createElement('collab-console-100554');
        consoleEl.setAttribute('mode', 'disabled');
        consoleEl.style.display = this.enabledConsole ? 'block' : 'none';
        container.appendChild(consoleEl);
        const testResultEl = this.createTestElement();
        container.appendChild(testResultEl);
        if (!this.previewContent)
            return;
        this.previewContent.innerHTML = '';
        this.previewContent.appendChild(container);
        // if (this.menu.setMode) this.menu.setMode('page', container);
        this.configureButtonsRight(true);
        mls.events.fire(3, 'WCDEventChange');
        return true;
    }
    createTestElement() {
        const testResultEl = document.createElement('collab-result-container-100554');
        const testResultElActions = document.createElement('div');
        const actionClose = document.createElement('i');
        actionClose.className = 'fa fa-times';
        actionClose.style.color = '#000000';
        actionClose.onclick = () => {
            this.closeTestResults();
        };
        testResultElActions.appendChild(actionClose);
        testResultEl.style.display = this.enabledTest ? 'block' : 'none';
        testResultEl.appendChild(testResultElActions);
        return testResultEl;
    }
    async fireWcdChanges() {
        const iframe = window.preview.iframe;
        if (!iframe)
            return;
        const wcd = iframe.contentDocument?.body.querySelector('wcd-toolbox-100554');
        if (!wcd)
            return;
        await wcd.beforeDelete();
        return;
    }
    requestUpdateAllIcaComponentsInPage() {
        if (!window.preview.iframe)
            throw new Error('Preview no created yet');
        const body = window.preview.iframe
            ?.contentDocument
            ?.querySelector('body');
        if (!body)
            return;
        const elements = this.findAllElementsIca(body);
        if (!elements)
            return;
        elements.forEach((el) => {
            if (el.tagName.split('-').length > 1 && el.globalVariation !== undefined) {
                el.globalVariation = globalState.globalVariation;
            }
        });
    }
    findAllElementsIca(el) {
        let elements = [];
        let elToSearch = el;
        function traverseShadowRoot(element) {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                elements.push(element);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child));
                }
            }
        }
        if (el.shadowRoot)
            elToSearch = el.shadowRoot;
        elToSearch.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item);
        });
        return elements;
    }
    getScriptTest(ica) {
        const stateHistories = ica.getHistory();
        if (stateHistories.length <= 0)
            return undefined;
        const params = {};
        const keysCont = {};
        let lastParam = '';
        stateHistories.forEach((stateHistory, index) => {
            const paramKey = stateHistory.key.split('.').pop();
            const paramType = typeof stateHistory.value;
            const paramValue = this.processValue(stateHistory.value);
            if (!paramKey)
                return;
            if (stateHistory.system) {
                lastParam = paramKey;
                return;
            }
            let resultKey = paramKey;
            if (!keysCont[paramKey])
                keysCont[paramKey] = 0;
            if (params[paramKey] && lastParam && lastParam !== resultKey) {
                keysCont[paramKey] += 1;
                resultKey = `${paramKey}_${keysCont[paramKey]}`;
            }
            params[resultKey] = {
                paramValue,
                paramType,
                paramOri: stateHistory.key,
                history: stateHistory
            };
            stateHistory.paramKey = resultKey;
            lastParam = resultKey;
        });
        const lines = [];
        let lastPath = '';
        let lastKey = '';
        let lastInteraction = '';
        let lastIndex = -1;
        stateHistories.forEach((history) => {
            const interationType = history.system ? "System" : "User";
            const vl = this.processValue(history.value);
            let row = '';
            if (!history.system) {
                const param = this.getParam(params, history.paramKey);
                if (!param)
                    return;
                row = `setState('${history.key}', args.${param})`;
            }
            else {
                row = `verifyState('${history.key}', ${vl})`;
                if (typeof vl === "string")
                    row = `verifyState('${history.key}', '${vl}')`;
            }
            if (lastInteraction === interationType && lastPath === history.key && lastKey === history.paramKey && lastIndex >= 0) {
                lines[lastIndex] = row;
            }
            else {
                lines.push(row);
                lastInteraction = interationType;
                lastPath = history.key;
                lastKey = history.paramKey;
                lastIndex = lines.length - 1;
            }
        });
        const exe = {
            functionName: '',
            description: '',
            page: '',
            enabled: true,
            schema: {}
        };
        Object.keys(params).forEach((k) => {
            const p = params[k];
            if (!p)
                return;
            exe.schema[k] = { type: p.paramType, value: p.paramValue };
        });
        let name = '';
        if (mls.actual[2])
            name = mls.actual[2].left.shortName;
        if (name !== '')
            name = `watchState('[pathTo].labelError', '[Expected Value]');`;
        const func = `export function @funcname(args: Record<string, any>): string {\n${name}\n${lines.join(';\n')}\nreturn 'ok';\n}`;
        return { func, exe };
    }
    getParam(params, key) {
        const keys = Object.keys(params);
        let ret = '';
        keys.forEach((i) => {
            if (i !== key)
                return;
            ret = i;
        });
        return ret;
    }
    processValue(vl) {
        if (typeof vl === "string" || typeof vl === "number") {
            return vl;
        }
        return JSON.stringify(vl);
    }
};
__decorate([
    property()
], ServicePreview100554.prototype, "itens", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "msize", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "error", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "watch", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "enabledConsole", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "enabledTest", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "light", void 0);
__decorate([
    property()
], ServicePreview100554.prototype, "lang", void 0);
__decorate([
    query('#preview-container')
], ServicePreview100554.prototype, "previewContent", void 0);
ServicePreview100554 = __decorate([
    customElement('service-preview-100554')
], ServicePreview100554);
export { ServicePreview100554 };
var ERecord;
(function (ERecord) {
    ERecord[ERecord["Stop"] = 0] = "Stop";
    ERecord[ERecord["Play"] = 1] = "Play";
})(ERecord || (ERecord = {}));
var ETestActions;
(function (ETestActions) {
    ETestActions[ETestActions["Run"] = 0] = "Run";
    ETestActions[ETestActions["Delete"] = 1] = "Delete";
    ETestActions[ETestActions["Edit"] = 2] = "Edit";
})(ETestActions || (ETestActions = {}));
var EPreview;
(function (EPreview) {
    EPreview[EPreview["icPreviewD"] = 0] = "icPreviewD";
    EPreview[EPreview["icPreviewM"] = 1] = "icPreviewM";
})(EPreview || (EPreview = {}));
