/// <mls shortName="pageTest2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState } from './_100554_icaState';
import { initTestState } from './_100554_testPagesState';
let PageTest2100554 = class PageTest2100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        initTestState();
        initState('projectTest.page2', {
            indexSel: -1,
            selecionado: {
                empresa: '',
                cnpj: '',
                endereco: '',
                contato: '',
                produtos: []
            }
        });
    }
    setEvents() {
        /*const eltableSelect = this.querySelector('#tableSelect');
        if (eltableSelect) {
            const evt = this.onSelectItemtableSelect.bind(this);
            eltableSelect.addEventListener('SelectItem', evt)
        }*/
        /*const novo = this.querySelector('#buttonNovo') as HTMLElement;
        if (novo) {
            novo.onclick = this.onNovo.bind(this);
        }*/
        const cancelar = this.querySelector('#buttonCancelar');
        if (cancelar) {
            cancelar.onclick = this.onCancelar.bind(this);
        }
        const salvar = this.querySelector('#buttonSalvar');
        if (salvar) {
            salvar.onclick = this.onSalvar.bind(this);
        }
        const excluir = this.querySelector('#buttonExcluir');
        if (excluir) {
            excluir.onclick = this.onExcluir.bind(this);
        }
    }
    onSelectItemtableSelect(e) {
        globalState.globalStateManagment.setState('projectTest.page2.indexSel', e.detail.index);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.empresa', globalState._ica.projectTest.tables.fornecedores[e.detail.index].empresa);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.cnpj', globalState._ica.projectTest.tables.fornecedores[e.detail.index].cnpj);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.endereco', globalState._ica.projectTest.tables.fornecedores[e.detail.index].endereco);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.contato', globalState._ica.projectTest.tables.fornecedores[e.detail.index].contato);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.produtos', globalState._ica.projectTest.tables.fornecedores[e.detail.index].produtos);
    }
    onCancelar() {
        const idx = globalState._ica.projectTest.page2.indexSel;
        const emp = idx < 0 ? '' : globalState._ica.projectTest.tables.fornecedores[idx].empresa;
        const cnpj = idx < 0 ? '' : globalState._ica.projectTest.tables.fornecedores[idx].cnpj;
        const end = idx < 0 ? '' : globalState._ica.projectTest.tables.fornecedores[idx].endereco;
        const ct = idx < 0 ? '' : globalState._ica.projectTest.tables.fornecedores[idx].contato;
        const prod = idx < 0 ? '' : globalState._ica.projectTest.tables.fornecedores[idx].produtos;
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.empresa', emp);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.cnpj', cnpj);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.endereco', end);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.contato', ct);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.produtos', prod);
    }
    onNovo() {
        globalState.globalStateManagment.setState('projectTest.page2.indexSel', -1);
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.empresa', '');
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.cnpj', '');
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.endereco', '');
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.contato', '');
        globalState.globalStateManagment.setState('projectTest.page2.selecionado.produtos', '');
    }
    onSalvar() {
        let idx = globalState._ica.projectTest.page2.indexSel;
        if (idx < 0) {
            globalState._ica.projectTest.tables.fornecedores.push(Object.assign({}, globalState._ica.projectTest.page2.selecionado));
            idx = globalState._ica.projectTest.tables.fornecedores.length;
        }
        else {
            const i = Object.assign({}, globalState._ica.projectTest.page2.selecionado);
            globalState.globalStateManagment.setState(`projectTest.tables.fornecedores[${idx}].empresa`, i.empresa);
            globalState.globalStateManagment.setState(`projectTest.tables.fornecedores[${idx}].cnpj`, i.cnpj);
            globalState.globalStateManagment.setState(`projectTest.tables.fornecedores[${idx}].endereco`, i.endereco);
            globalState.globalStateManagment.setState(`projectTest.tables.fornecedores[${idx}].contato`, ``);
            globalState.globalStateManagment.setState(`projectTest.tables.fornecedores[${idx}].produtos`, i.produtos);
        }
        globalState.globalStateManagment.setState('projectTest.page2.indexSel', idx);
        const eltableSelect = this.querySelector('#tableSelect');
        if (eltableSelect) {
            eltableSelect.data = globalState._ica.projectTest.tables.fornecedores;
            eltableSelect.requestUpdate();
        }
    }
    onExcluir() {
        let idx = globalState._ica.projectTest.page2.indexSel;
        if (idx < 0)
            return;
        globalState._ica.projectTest.tables.fornecedores.splice(idx, 1);
        globalState.globalStateManagment.setState(`projectTest.page2.indexSel`, -1);
        globalState.globalStateManagment.setState(`projectTest.page2.selecionado.empresa`, '');
        globalState.globalStateManagment.setState(`projectTest.page2.selecionado.cnpj`, '');
        globalState.globalStateManagment.setState(`projectTest.page2.selecionado.endereco`, '');
        globalState.globalStateManagment.setState(`projectTest.page2.selecionado.contato`, ``);
        globalState.globalStateManagment.setState(`projectTest.page2.selecionado.produtos`, '');
        const eltableSelect = this.querySelector('#tableSelect');
        if (eltableSelect) {
            eltableSelect.data = globalState._ica.projectTest.tables.fornecedores;
            eltableSelect.requestUpdate();
        }
    }
    /// **collab_events_start**
    handleClickButtonNovo() {
        this.onNovo();
    }
    handleItemSelectedTableSelect(ev) {
        this.onSelectItemtableSelect(ev);
    }
};
PageTest2100554 = __decorate([
    customElement('page-test2-100554')
], PageTest2100554);
export { PageTest2100554 };
