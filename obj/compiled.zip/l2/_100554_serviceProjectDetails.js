/// <mls shortName="serviceProjectDetails" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property, queryAll, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import * as icons from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    noProjectSelected: 'Nenhum projeto selecionado!',
    resume: 'Resumo',
    name: 'Nome',
    projectDriver: 'Driver do Projeto',
    projectURL: 'URL do Projeto',
    designSystems: 'Design systems',
    files: 'Arquivos',
    keyGithub: 'Chave do GitHub',
    project: 'Projeto',
    noProject: 'Nenhum projeto selecionado, por favor selecione.',
    selectProject: 'Selecione o projeto',
    btnChange: 'Alterar',
    btnAddNewProject: 'Adicionar novo projeto',
    btnCreateProject: 'Criar projeto',
    btnRefreshOrg: 'Atualizar',
    btnOpenProject: 'Abrir projeto',
    addProject: 'Novo projeto',
    placeholderFilter: 'Filtro',
    push: 'Permite que os desenvolvedores façam push diretamente para a branch principal.',
    pullRequest: 'Exige que todas as mudanças sejam feitas através de Pull Requests, permitindo revisões de código e aprovação antes da integração na branch principal.',
    projectNameLabel: 'Nome do projeto',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organização',
    visibilityLabel: 'Visibilidade do projeto',
    visibilityPublicOption: 'Público - Qualquer pessoa pode ver este repositório.',
    visibilityPrivateOption: 'Privado - Você escolhe quem pode ver.',
    teamLabel: 'Time',
    loadingAddText1: 'Buscando informações do usuário',
    loadingAddText2: 'Buscando organizações do usuário',
    step1Title: 'Passo 1',
    step2Title: 'Passo 2',
    step3Title: 'Passo 3',
    step1Msg: 'Escolha o driver para carregar suas organizações existentes.',
    step2Msg: 'Agora selecione a organização e o modo de atualização.',
    step3Msg: 'Finalmente, selecione a equipe e a visibilidade do projeto.'
};
const message_en = {
    noProjectSelected: 'No project selected!',
    resume: 'Resume',
    name: 'Name',
    projectDriver: 'ProjectDriver',
    projectURL: 'ProjectURL',
    designSystems: 'Design systems',
    files: 'Files',
    keyGithub: 'Key Github',
    project: 'Project',
    noProject: 'No project selected, please select',
    selectProject: 'Select project',
    btnChange: 'Change',
    btnAddNewProject: 'Add new Project',
    btnCreateProject: 'Create project',
    btnRefreshOrg: 'Refresh',
    btnOpenProject: 'Open project',
    addProject: 'New project',
    placeholderFilter: 'Filter',
    push: 'Allows developers to push directly to the main branch.',
    pullRequest: 'Requires all changes to be made through Pull Requests, allowing code reviews and approval before integration into the main branch.',
    projectNameLabel: 'Project name',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organization',
    visibilityLabel: 'Project visibility',
    visibilityPublicOption: 'Public - Anyone can see this repository.',
    visibilityPrivateOption: 'Private - You choose who can see.',
    teamLabel: 'Team',
    loadingAddText1: 'Loading user informations',
    loadingAddText2: 'Loading user organizations',
    step1Title: 'Step 1',
    step2Title: 'Step 2',
    step3Title: 'Step 3',
    step1Msg: 'Choose the driver to load your existing organizations.',
    step2Msg: 'Now select the organization and the update mode.',
    step3Msg: 'Finally select the team and the visibility of the project.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceProjectDetails100554 = class ServiceProjectDetails100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.showKey = false;
        this.projectCreated = false;
        this.state = { history: [], orgs: [], projectSelected: undefined };
        this.currentScenario = 'details';
        //------------ SERVICE -------------------
        this.details = {
            icon: '&#xf15b',
            state: 'foreground',
            position: 'left',
            tooltip: 'Project Details',
            visible: true,
            widget: '_100554_serviceProjectDetails',
            level: [5]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickTitle = () => {
            this.changeScenario('select');
        };
        this.menu = {
            title: {
                icon: '&#xf053',
                text: ''
            },
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined,
            onClickTitle: this.onClickTitle
        };
        //------------- IMPLEMENTATION-----------------------
        this.keyLocalHistory = {
            github: 'keyGitHub',
            gitlab: 'keyGitLab'
        };
        //-- braches
        this.listForks = [];
        this.branchMain = [];
        this.branch = '';
        this.owner = '';
        this.repo = '';
        this.isFecthBranchs = '';
        this.isTimeout = false;
        this.projectCreatedNumber = 100554;
        this.filterTimeout = 0;
        mls.events.addListener(5, 'ProjectSelected', (ev) => this.onProjectSelected(ev));
    }
    onServiceClick(visible, reinit, el) {
    }
    //---------- WEBCOMPONENT----------------------
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.getLastProject();
        return html `
            <section>
                ${this.renderScenario()}
            </section>
        `;
    }
    renderScenario() {
        switch (this.currentScenario) {
            case 'details':
                return html `
                    ${this.renderDetails()}
                `;
            case 'select':
                return html `
                    ${this.renderSelectProject()}
                `;
            case 'add':
                return html `
                    ${this.renderAdd()}
                `;
        }
    }
    renderDetails() {
        this.projectCreated = false;
        if (this.lastPrjId)
            this.getDetailsProject(+this.lastPrjId);
        else {
            this.changeScenario('select');
            return;
        }
        this.menu.title.text = this.msg.project + ' : ' + this.lastPrjId;
        this.menu.title.icon = '&#xf053';
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        return html `
            ${!this.lastPrjId
            ?
                html `<h4> ${this.msg.noProjectSelected}</h4>`
            :
                html `
                <section class="section-details">
                    <h4>${this.msg.resume}</h4>
                    <ul class="listInfo">
                        <li>
                            <b>${icons.collab_file}${this.msg.name}:</b> 
                            ${this.name}
                        </li>
                        <li style="display:flex">
                            <div style="width:18px">${icons.collab_gear}</div>
                            <b>${this.msg.projectDriver}:</b> 
                            ${this.projectDriver}
                        </li>
                        <li>
                            <b>
                                ${icons.collab_folder_tree}
                                ${this.msg.projectURL}:
                            </b>
                            ${this.projectURL}
                        </li>
                        <li>
                            <b>${icons.collab_book}${this.msg.designSystems}:</b> 
                            ${this.designSystems}
                        </li>
                        <li>
                            <b>
                                ${icons.collab_file_signature}
                                ${this.msg.files}:
                            </b>
                            ${this.files}
                        </li>
                    </ul>

                    <details>
                        <summary>Config:</summary>
                        ${this.renderConfigKey()}
                    </details>

                    ${this.renderCreateTreeFork()}
                </section>
                
                
                `}`;
    }
    renderConfigKey() {
        if (!this.projectDriver && !this.keyLocalHistory[this.projectDriver])
            return html ``;
        return html `
            <div class="section-config-github">
                <label>${this.keyLocalHistory[this.projectDriver]}</label>
                <div class="cls_key">
                    <input .value=${this.showString(this.actualKeyDriver, this.showKey)} @input="${this.handleInputChangeKey}"></input rows=4>
                    <button @click="${this.clickShowEye}">${this.showKey ? icons.collab_eye : icons.collab_eye_slash}</button>
                </div>
                <button @click=${this.handleChangeKey}>${this.msg.btnChange}</button>
            </div>
            `;
    }
    renderCreateTreeFork() {
        return html `
            <details>
                <summary>Branchs:</summary>
                <div class="grp_show_branches">
                    ${this.renderBranchs()}
                </div>
            </details>
        `;
    }
    renderBranchs() {
        return html `
        <ul>
            ${repeat(this.branchMain, ((key) => key), ((item, index) => {
            return this.renderItem(item, index);
        }))}
            ${repeat(this.listForks, ((key) => key), ((item, index) => {
            return this.renderItemForks(item, index);
        }))}
        </ul>`;
    }
    renderItem(obj, index) {
        return html `
            <li .info=${obj}>
                <input type="radio" id="item-${index}" name="optBranch" value="${obj.name}">
                <label for="item-${index}">
                    ${obj.name}
                </label>
            
            </li>
        
        `;
    }
    renderItemForks(obj, index) {
        return html `
            <li .info=${obj}>
                <input type="radio" id="itemf-${index}" name="optBranch" value="${obj.nameWithOwner}">
                <label for="itemf-${index}">
                    ${obj.nameWithOwner}
                </label>
            
            </li>
        
        `;
    }
    renderSelectProject() {
        this.menu.title.text = this.msg.selectProject;
        this.menu.title.icon = '';
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        this.getOrgsAndProjects();
        this.state.history = this.loadHistory();
        return html `
            <div class="scroll-custom l5-project-list">
                <div class="filter-container" style="display:flex">
                    <input style="width:calc(100% - 160px)" type="text" placeholder="Filter" @input=${this._filterProjects}>
                    <button style="margin-left:5px; width:150px;" @click=${this.onAddNewProjectClick}>${this.msg.btnAddNewProject}</button>
                </div>
                <div class="l5-project-list-history" style="${this.state.history.length === 0 ? 'display:none' : 'display: block'}">
                    <div class="serviceListTitle">History</div>
                    <ul class="serviceListList">
                        ${this.state.history.map((his) => html `
                            <li class=${this.lastPrjId && +this.lastPrjId === his.project ? "selected" : ""} @click=${() => { this.onHistoryClick(his); }}>
                                <div>
                                    <span>${his.name + ' (' + his.project.toString() + ')'}</span>
                                </div>
                                <span>${icons.collab_chevron_right}</span>
                            </li>
                        `)}
                    </ul>
                </div>
                <div class="serviceListProjects">
                    ${this.state.orgs.map((org) => {
            return html `
                            <div class="serviceListTitle">${org.key}</div>
                            <ul class="serviceListList">
                                ${org.projects.map((prj) => html `
                                <li class=${this.lastPrjId && +this.lastPrjId === prj.id ? "selected" : ""} @click=${() => this.onProjectClick(prj)}>
                                    <div>
                                        <span>${prj.name + ' (' + prj.id.toString() + ')'}</span>
                                    </div>
                                <span>${icons.collab_chevron_right}</span>
                                </li>
                            `)}
                            </ul>
                            `;
        })}
                
                </div>
            </div>
        `;
    }
    renderAdd() {
        this.menu.title.text = this.msg.addProject;
        this.menu.title.icon = '';
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        return html `
        <collab-new-project-100554 @collab-new-project=${this.onProjectCreated}></collab-new-project-100554>
        <div style="display:flex; justify-content:center;">
            ${this.projectCreated ? html `<button id="button-see-project" @click=${this.onSeeProjectClick}>${this.msg.btnOpenProject}</button>` : ''}
        </div>
        `;
    }
    async setInfoInitial() {
        if (this.isTimeout || this.lastPrjId === this.isFecthBranchs)
            return;
        this.isTimeout = true;
        setTimeout(() => {
            const prj = mls.actual[5].project;
            if (!prj)
                return;
            if (!this.driver || this.driver.shortName !== this.projectDriver)
                this.driver = mls.stor.others.getDefaultDriver(prj);
            const info = mls.l5.getProjectSettings(prj);
            let str = info.projectURL.split('/');
            str = str.filter((item) => item.trim() !== "");
            this.branch = str[0];
            this.owner = str[1];
            this.repo = str[2];
            this.getInfosRepo();
        }, 500);
    }
    async getInfosRepo() {
        if (!this.driver) {
            this.branchMain = [];
            this.listForks = [];
            return;
        }
        const ret = await this.driver.listBranches(this.owner, this.repo);
        const forks = await this.driver.listForks(this.owner, this.repo);
        this.isFecthBranchs = this.lastPrjId;
        this.listForks = forks;
        this.branchMain = ret;
        this.isTimeout = false;
    }
    //--
    async changeScenario(scenario) {
        this.currentScenario = scenario;
    }
    async getDetailsProject(project) {
        let details = mls.l5.getProjectSettings(project);
        this.designSystems = details.designSystems ? details.designSystems.length : 0;
        this.name = details.name;
        this.projectDriver = details.projectDriver;
        this.projectURL = details.projectURL;
        this.files = Object.keys(mls.stor.files).filter((item => item.startsWith(project.toString()))).length;
        if (this.keyLocalHistory[details.projectDriver]) {
            this.actualKeyDriver = localStorage?.getItem(this.keyLocalHistory[details.projectDriver]);
        }
        await this.setInfoInitial();
    }
    onProjectSelected(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        this.getDetailsProject(data.value);
    }
    getLastProject() {
        this.lastPrjId = localStorage.getItem('l5-last-project');
        return this.lastPrjId;
    }
    handleChangeKey() {
        if (this.actualKeyDriver && this.projectDriver && this.keyLocalHistory[this.projectDriver]) {
            localStorage?.setItem(this.keyLocalHistory[this.projectDriver], this.actualKeyDriver);
        }
    }
    handleInputChangeKey(value) {
        this.actualKeyDriver = value;
    }
    async onProjectCreated(ev) {
        this.projectCreated = true;
        this.projectCreatedNumber = ev.detail;
        setTimeout(() => {
            if (this.buttonSeePrj)
                this.buttonSeePrj.scrollIntoView();
        }, 150);
    }
    async onSeeProjectClick() {
        this.setProjectActual(this.projectCreatedNumber);
        this._fireEventProjectSelected(this.projectCreatedNumber);
        this.changeScenario('details');
        await this.loadProjectActual(this.projectCreatedNumber);
        this.projectCreated = false;
    }
    // LIST
    onAddNewProjectClick() {
        this.changeScenario('add');
    }
    async onProjectClick(item) {
        this.setProjectActual(item.id);
        this.setOrgActual(item.id);
        this.addOnHistory(item);
        this._fireEventProjectSelected(item.id);
        this.changeScenario('details');
        await this.loadProjectActual(item.id);
    }
    async onHistoryClick(item) {
        this.setProjectActual(item.project);
        this.setOrgActual(item.project);
        this._fireEventProjectSelected(item.project);
        this.changeScenario('details');
        await this.loadProjectActual(item.project);
    }
    async loadProjectActual(project) {
        await mls.stor.server.loadProjectInfoIfNeeded(project);
    }
    setOrgActual(project) {
        const orgIndex = mls.l5.getProjectOrgIndex(project);
        mls.l5.setActualOrg(orgIndex);
    }
    setProjectActual(project) {
        mls.actual[5].project = project;
        this.state.projectSelected = project;
        localStorage.setItem('l5-last-project', project.toString());
    }
    addOnHistory(item) {
        const indexInHistory = this.state.history.findIndex((his) => his.name === item.name && his.project === item.id);
        if (indexInHistory > -1)
            this.state.history.splice(indexInHistory, 1);
        const historyItem = {
            project: item.id,
            name: item.name
        };
        this.state.history.unshift(historyItem);
        if (this.state.history.length > 9)
            this.state.history.pop();
        localStorage.setItem('l5-projects-history', JSON.stringify(this.state.history));
    }
    _filterProjects(ev) {
        const filterText = ev.target.value;
        clearTimeout(this.filterTimeout);
        this.filterTimeout = setTimeout(() => {
            if (filterText) {
                this.titleList?.forEach((item) => { item.style.display = 'none'; });
                if (this.historieEl)
                    this.historieEl.style.display = 'none';
            }
            else {
                this.titleList?.forEach((item) => { item.style.display = ''; });
                if (this.historieEl)
                    this.historieEl.style.display = 'block';
            }
            this.list?.forEach((li) => {
                li.style.display = '';
                const text = li.querySelector('span')?.innerText;
                if (text && text.toLowerCase().indexOf(filterText.toLowerCase()) < 0)
                    li.style.display = 'none';
            });
        }, 100);
    }
    _fireEventProjectSelected(project) {
        const params = {
            emitter: 'left',
            value: project
        };
        mls.events.fire(5, ['ProjectSelected'], JSON.stringify(params));
    }
    clearState() {
        this.state.history = [];
        this.state.orgs = [];
    }
    loadHistory() {
        const lcHistory = localStorage.getItem('l5-projects-history');
        let rc = [];
        if (!lcHistory)
            return rc;
        try {
            rc = JSON.parse(lcHistory);
        }
        catch (err) {
            throw new Error('Error on load l5 project history');
        }
        return rc;
    }
    getOrgsAndProjects() {
        this.clearState();
        Object.keys(mls.stor.orgs).forEach((org, index) => {
            const { name, description, created_at, projects } = mls.stor.orgs[org].sett;
            const prj = [];
            projects.forEach((p) => {
                try {
                    const json = JSON.parse(p.value);
                    if (!json.l5_actionPrjSettings ||
                        !json.l5_actionPrjSettings.projectDriver ||
                        json.l5_actionPrjSettings.projectDriver === 'mls')
                        return;
                    prj.push(p);
                }
                catch (e) {
                    //console.info('Erro to parse' + p.name);
                }
            });
            if (prj.length <= 0)
                return;
            const obj = {
                name,
                created_at,
                description,
                key: org,
                projects: prj
            };
            this.state.orgs.push(obj);
        });
    }
    clickShowEye(e) {
        e.stopPropagation();
        if (this.showKey)
            this.showKey = false;
        else
            this.showKey = true;
        this.requestUpdate();
    }
    showString(input, show) {
        if (!input)
            return '';
        if (show)
            return input;
        else
            return this.maskString(input);
    }
    maskString(input) {
        return '*'.repeat(input.length);
    }
};
ServiceProjectDetails100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "name", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "projectDriver", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "projectURL", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "designSystems", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "projectCreated", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "files", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "actualKeyDriver", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "state", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "lastPrjId", void 0);
__decorate([
    property({ type: String })
], ServiceProjectDetails100554.prototype, "currentScenario", void 0);
__decorate([
    queryAll('.serviceListProjects .serviceListList li')
], ServiceProjectDetails100554.prototype, "list", void 0);
__decorate([
    queryAll('.serviceListProjects .serviceListTitle')
], ServiceProjectDetails100554.prototype, "titleList", void 0);
__decorate([
    query('.l5-project-list-history')
], ServiceProjectDetails100554.prototype, "historieEl", void 0);
__decorate([
    query('#button-see-project')
], ServiceProjectDetails100554.prototype, "buttonSeePrj", void 0);
__decorate([
    property()
], ServiceProjectDetails100554.prototype, "branchMain", void 0);
ServiceProjectDetails100554 = __decorate([
    customElement('service-project-details-100554')
], ServiceProjectDetails100554);
export { ServiceProjectDetails100554 };
