/// <mls shortName="serviceDsComponentsList" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { collab_cubes, collab_caret_righttv } from './_100554_collabIcons';
import { getDSInstance } from './_100554_libDesignSystem';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsComponentsList100554 = class ServiceDsComponentsList100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.itens = [];
        this.error = '';
        this.details = {
            icon: '&#xf1b3',
            state: 'foreground',
            position: 'left',
            tooltip: 'Components',
            visible: true,
            tags: ['ds_components'],
            widget: '_100554_serviceDsComponentsList',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Details',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.timeShowLoader = -1;
        this.myMsg = {
            noItems: 'No items'
        };
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            this.init();
            mls.events.fire([this.level], ['DSWidgetsSelected'], '', 300);
        }
        else {
            mls.events.fire([this.level], ['DSWidgetsUnSelected'], '', 0);
        }
    }
    //--------------- COMPONENTE---------------
    connectedCallback() {
        super.connectedCallback();
        this.updateMyMessages();
        this.init();
    }
    render() {
        if (this.error !== '') {
            setTimeout(() => this.error = '', 3000);
            return html `${this.error}`;
        }
        return html ` ${this.itens
            ? this.renderItens() : this.renderNoItens()}
            
        `;
    }
    renderNoItens() {
        return html `
            <span>${this.myMsg.noItems}</span>  
        `;
    }
    renderItens() {
        return html `
            
                <ul>
                    ${repeat(this.itens.sort((a, b) => a.group.localeCompare(b.group)), ((i) => i.group), ((item, index) => {
            return this.renderGroup(item, index);
        }))}
                </ul> 
        
        `;
    }
    renderGroup(item, index) {
        return html `
        <li @click=${this.openMeList}>

            <div style="display:flex; align-items:center;">
                ${collab_caret_righttv}
                <label style="font-weight:500">${item.group}</label>
            </div>
            <ul>
                ${repeat(item.components.sort((a, b) => a.name.localeCompare(b.name)), ((i) => i.name), ((it, indexI) => {
            return this.renderComponent(it, indexI);
        }))}
            </ul>
        </li>
        `;
    }
    renderComponent(item, index) {
        return html `
        <li
            style="padding-left: 1.1rem;"
            class=${item.name === this.selectWidget ? 'selected' : ''} 
            .item=${item} 
            @click=${(e) => { this.openComponent(e, item.name); }}
        > 
            <div style="display:flex;align-items:center;gap:.5rem">
                ${collab_cubes}
                <span>${item.name}</span>
            </div>
        </li>
        `;
    }
    //------------------- EVENTS---------------
    setEvents() {
        mls.events.addListener(3, 'DSWidgetsChanged', (ev) => this.onDsWidgetsChanged(ev));
    }
    //----------- IMPLEMENTATION---------------
    async init() {
        try {
            this.showLoader(true);
            const { project } = mls.actual[5];
            const { mode } = mls.actual[3];
            this.ds = await getDSInstance(project, mode);
            if (!this.ds)
                throw new Error('No found getDSInstance:' + mode + ',' + project);
            await this.ds.init();
            this.setList();
            this.showLoader(false);
        }
        catch (e) {
            console.info(e);
            this.showLoader(false);
        }
    }
    setList() {
        if (!this.ds || !this.ds.components)
            return;
        const { list } = this.ds.components;
        const components = [];
        Object.keys(list).forEach((comp) => {
            components.push(list[comp]);
        });
        const groupedData = components.reduce((acc, obj) => {
            const key = obj.group;
            if (!acc[key]) {
                acc[key] = [];
            }
            acc[key].push(obj);
            return acc;
        }, {});
        const rc = [];
        Object.keys(groupedData).forEach((group) => {
            const obj = {
                group,
                icon: 'fa-solid fa-bolt',
                components: groupedData[group]
            };
            rc.push(obj);
        });
        this.itens = rc;
    }
    onDsWidgetsChanged(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (data.position === this.position)
            return;
        if (data.op === 'update')
            this.setList();
    }
    openComponent(e, widget) {
        e.stopPropagation();
        let el = e.target;
        if (!el)
            return;
        el = el.closest('li');
        if (!el)
            return;
        this.selectWidget = widget;
        const info = el.item;
        this.fireComunication(info);
    }
    openMeList(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const li = el.closest('li');
        if (!li)
            return;
        li.classList.toggle('open');
    }
    showLoader(show) {
        clearTimeout(this.timeShowLoader);
        this.timeShowLoader = setTimeout(() => {
            this.loading = show;
        }, 200);
    }
    updateMyMessages() {
        if (!window['message'])
            return;
        const m = window['message'];
        if (m.noItems)
            this.myMsg.noItems = m.noItems;
    }
    fireComunication(info) {
        const obj = {
            op: 'widgets',
            position: this.position,
            value: info
        };
        mls.events.fire([this.level], ['DSWidgetsChanged'], JSON.stringify(obj), 300);
    }
};
ServiceDsComponentsList100554.styles = css ` :host{font-family:var(--font-family-primary);display:block;padding:1rem;overflow-y:auto;height:calc(100% - 2rem)} svg{fill:var(--text-primary-color)} ul{margin-top:.5rem;margin-left:0;padding-left:0px !important;list-style:none;user-select:none} li{padding:.2rem .2rem;cursor:pointer} li ul{list-style:none;user-select:none;border-left:1px solid var(--text-primary-color);margin-left:.2rem;display:none} li ul li{padding:.3rem .2rem} li ul li:hover, li ul.selected{background:var(--text-primary-color-darker) !important} li ul li.selected{background:var(--text-primary-color-darker) !important} li.open>ul{display:block} li>div{display:flex;flex-direction:row;gap:.5rem} li>div input, li>div label{cursor:pointer;display:flex;justify-content:center;align-items:center;gap:.5rem} li.open .fatv{transform:rotate(90deg);user-select:none} .fatv{user-select:none} .fatv.fa-caret-righttv{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' height='1em' viewBox='0 0 256 512'><path d='M246.6 278.6c12.:host(.5) 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z'/><path d='M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z'/></svg>");background-repeat:no-repeat;width:10px;background-position-y:center;padding:0;cursor:pointer} .fatv.fa-caret-righttv.rotate{transform:rotate(90deg)} .fa-undo:hover, .fa-clone:hover, .fa-file-pen:hover, .fa-trash:hover{filter:invert(39%) sepia(22%) saturate(4456%) hue-rotate(194deg) brightness(103%) contrast(101%)} .fa{display:flex;justify-content:center;align-items:center} .fa.fa-cubes{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M290.8 48.6l78.4 29.7L288 109.5 206.8 78.3l78.4-29.7c1.8-.7 3.8-.7 5.7 0zM136 92.5V204.7c-1.3 .4-2.6 .8-3.9 1.3l-96 36.4C14.4 250.6 0 271.5 0 294.7V413.9c0 22.2 13.1 42.3 33.5 51.3l96 42.2c14.4 6.3 30.7 6.3 45.1 0L288 457.5l113.5 49.9c14.4 6.3 30.7 6.3 45.1 0l96-42.2c20.3-8.9 33.5-29.1 33.5-51.3V294.7c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-1.3-.5-2.6-.9-3.9-1.3V92.5c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-12.8-4.8-26.9-4.8-39.7 0l-96 36.4C150.4 48.4 136 69.3 136 92.5zM392 210.6l-82.4 31.2V152.6L392 121v89.6zM154.8 250.9l78.4 29.7L152 311.7 70.8 280.6l78.4-29.7c1.8-.7 3.8-.7 5.7 0zm18.8 204.4V354.8L256 323.2v95.9l-82.4 36.2zM421.2 250.9c1.8-.7 3.8-.7 5.7 0l78.4 29.7L424 311.7l-81.2-31.1 78.4-29.7zM523.2 421.2l-77.6 34.1V354.8L528 323.2v90.7c0 3.2-1.9 6-4.8 7.3z'/></svg>");background-repeat:no-repeat;width:17px !important;height:17px;background-position-y:center;display:block}`;
__decorate([
    property()
], ServiceDsComponentsList100554.prototype, "itens", void 0);
__decorate([
    property()
], ServiceDsComponentsList100554.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsComponentsList100554.prototype, "selectWidget", void 0);
ServiceDsComponentsList100554 = __decorate([
    customElement('service-ds-components-list-100554')
], ServiceDsComponentsList100554);
export { ServiceDsComponentsList100554 };
