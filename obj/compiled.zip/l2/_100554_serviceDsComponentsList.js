/// <mls shortName="serviceDsComponentsList" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { collab_cubes, collab_caret_righttv } from './_100554_collabIcons';
import { getDSInstance } from './_100554_libDesignSystem';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsComponentsList100554 = class ServiceDsComponentsList100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.itens = [];
        this.error = '';
        this.details = {
            icon: '&#xf1b3',
            state: 'foreground',
            position: 'left',
            tooltip: 'Components',
            visible: true,
            tags: ['ds_components'],
            widget: '_100554_serviceDsComponentsList',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Details',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.timeShowLoader = -1;
        this.myMsg = {
            noItems: 'No items'
        };
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            this.init();
            mls.events.fire([this.level], ['DSWidgetsSelected'], '', 300);
        }
        else {
            mls.events.fire([this.level], ['DSWidgetsUnSelected'], '', 0);
        }
    }
    //--------------- COMPONENTE---------------
    connectedCallback() {
        super.connectedCallback();
        this.updateMyMessages();
        this.init();
    }
    render() {
        if (this.error !== '') {
            setTimeout(() => this.error = '', 3000);
            return html `${this.error}`;
        }
        return html ` ${this.itens
            ? this.renderItens() : this.renderNoItens()}
            
        `;
    }
    renderNoItens() {
        return html `
            <span>${this.myMsg.noItems}</span>  
        `;
    }
    renderItens() {
        return html `
            
                <ul>
                    ${repeat(this.itens.sort((a, b) => a.group.localeCompare(b.group)), ((i) => i.group), ((item, index) => {
            return this.renderGroup(item, index);
        }))}
                </ul> 
        
        `;
    }
    renderGroup(item, index) {
        return html `
        <li @click=${this.openMeList}>

            <div style="display:flex; align-items:center;">
                ${collab_caret_righttv}
                <label style="font-weight:500">${item.group}</label>
            </div>
            <ul>
                ${repeat(item.components.sort((a, b) => a.name.localeCompare(b.name)), ((i) => i.name), ((it, indexI) => {
            return this.renderComponent(it, indexI);
        }))}
            </ul>
        </li>
        `;
    }
    renderComponent(item, index) {
        return html `
        <li
            style="padding-left: 1.1rem;"
            class=${item.name === this.selectWidget ? 'selected' : ''} 
            .item=${item} 
            @click=${(e) => { this.openComponent(e, item.name); }}
        > 
            <div style="display:flex;align-items:center;gap:.5rem">
                ${collab_cubes}
                <span>${item.name}</span>
            </div>
        </li>
        `;
    }
    //------------------- EVENTS---------------
    setEvents() {
        mls.events.addListener(3, 'DSWidgetsChanged', (ev) => this.onDsWidgetsChanged(ev));
    }
    //----------- IMPLEMENTATION---------------
    async init() {
        try {
            this.showLoader(true);
            const { project } = mls.actual[5];
            const { mode } = mls.actual[3];
            this.ds = await getDSInstance(project, mode);
            if (!this.ds)
                throw new Error('No found getDSInstance:' + mode + ',' + project);
            await this.ds.init();
            this.setList();
            this.showLoader(false);
        }
        catch (e) {
            console.info(e);
            this.showLoader(false);
        }
    }
    setList() {
        if (!this.ds)
            return;
        const { list } = this.ds.components;
        const components = [];
        Object.keys(list).forEach((comp) => {
            components.push(list[comp]);
        });
        const groupedData = components.reduce((acc, obj) => {
            const key = obj.group;
            if (!acc[key]) {
                acc[key] = [];
            }
            acc[key].push(obj);
            return acc;
        }, {});
        const rc = [];
        Object.keys(groupedData).forEach((group) => {
            const obj = {
                group,
                icon: 'fa-solid fa-bolt',
                components: groupedData[group]
            };
            rc.push(obj);
        });
        this.itens = rc;
    }
    onDsWidgetsChanged(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (data.position === this.position)
            return;
        if (data.op === 'update')
            this.setList();
    }
    openComponent(e, widget) {
        e.stopPropagation();
        let el = e.target;
        if (!el)
            return;
        el = el.closest('li');
        if (!el)
            return;
        this.selectWidget = widget;
        const info = el.item;
        this.fireComunication(info);
    }
    openMeList(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const li = el.closest('li');
        if (!li)
            return;
        li.classList.toggle('open');
    }
    showLoader(show) {
        clearTimeout(this.timeShowLoader);
        this.timeShowLoader = setTimeout(() => {
            this.loading = show;
        }, 200);
    }
    updateMyMessages() {
        if (!window['message'])
            return;
        const m = window['message'];
        if (m.noItems)
            this.myMsg.noItems = m.noItems;
    }
    fireComunication(info) {
        const obj = {
            op: 'widgets',
            position: this.position,
            value: info
        };
        mls.events.fire([this.level], ['DSWidgetsChanged'], JSON.stringify(obj), 300);
    }
};
ServiceDsComponentsList100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsComponentsList100554.prototype, "itens", void 0);
__decorate([
    property()
], ServiceDsComponentsList100554.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsComponentsList100554.prototype, "selectWidget", void 0);
ServiceDsComponentsList100554 = __decorate([
    customElement('service-ds-components-list-100554')
], ServiceDsComponentsList100554);
export { ServiceDsComponentsList100554 };
