/// <mls shortName="testGenerateDefs" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { addMessage } from './_100554_collabMessageHelper';
let TestGenerateDefs100554 = class TestGenerateDefs100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`test-generate-defs-100554{display:block;background-color:gray;color:yellow;height:100%}`);
        this.project = 100554;
        this.threadId = "20250521144240.1000";
        this.filePrefix = "plugin";
        this.max = 2;
        this.log = [];
    }
    render() {
        return html `
         <p> pressione o botão para iniciar o processamenteo</p>
         <p> Vários arquivos serão analisados para o projeto ${this.project} e prefixo ${this.filePrefix}</p>
         <p> Até no máximo ${this.max} arquivos serão processados para gerar o .defs</p>
         <button @click=${this.handleClickIniciar}> Iniciar </button>
         <button @click=${this.handleClickSimular}> Simular </button>
         <pre>${this.log.join('\n')}</pre>
         `;
    }
    handleClickIniciar() {
        this.executar(false);
    }
    handleClickSimular() {
        this.executar(true);
    }
    async executar(simular) {
        const keys = Object.keys(mls.stor.files);
        this.log = [];
        this.log.push(`analisando ${keys.length} files`);
        this.requestUpdate();
        const shortNames = new Set();
        for (const key of keys) {
            if (mls.stor.files[key].project !== this.project)
                continue;
            if (mls.stor.files[key].level !== 2)
                continue;
            if (mls.stor.files[key].shortName.startsWith(this.filePrefix) === false)
                continue;
            shortNames.add(mls.stor.files[key].shortName);
        }
        this.log.push(`analisando ${shortNames.size} files apos filtragem`);
        this.requestUpdate();
        const updateDefsAfter = new Date("2025-07-01");
        const files = [];
        for (const shortName of shortNames) {
            const info = await mls.stor.getFiles({ project: this.project, shortName: shortName, folder: "", loadContent: false });
            if (info.defs && info.defs.updatedAt && (new Date(info.defs.updatedAt)) > updateDefsAfter) {
                continue;
            }
            if (files.length >= this.max)
                break;
            this.log.push("added " + shortName + "," + (!!info.defs) + "," + info?.defs?.updatedAt);
            files.push(info);
        }
        this.log.push(`preparando ${files.length} files limitado por max`);
        this.requestUpdate();
        const batchSize = 3;
        let batch = [];
        for await (const file of files) {
            if (!file || !file.ts)
                continue;
            const command = `@@GenerateDefs gerar o arquivo de definição: {"project":${file.ts.project}, "shortName":"${file.ts.shortName}" }`;
            if (!simular) {
                batch.push((async () => {
                    if (!file || !file.ts)
                        return;
                    try {
                        await addMessage(this.threadId, command);
                        await sleep(1000);
                        this.log.push("added message: " + command);
                    }
                    catch (e) {
                        this.log.push("erro ao adicionar mensagem: " + (e?.message || e));
                    }
                    this.requestUpdate();
                })());
                if (batch.length === batchSize) {
                    await Promise.all(batch);
                    this.requestUpdate();
                    batch = [];
                }
            }
            else {
                this.log.push(command);
                this.requestUpdate();
            }
        }
        // Espera o resto
        if (batch.length > 0) {
            await Promise.all(batch);
        }
        this.log.push("end");
        this.requestUpdate();
    }
};
TestGenerateDefs100554 = __decorate([
    customElement('test-generate-defs-100554')
], TestGenerateDefs100554);
export { TestGenerateDefs100554 };
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
