/// <mls shortName="tsTestASTTeste" project="100554" enhancement="_blank" />
import { setState } from './_100554_libManagementCan';
export const integrations = [
    {
        enabled: false,
        name: "adicionar usuario com parametros basicos",
        page: "pageTest1",
        functionName: "testAddUser",
        params: {
            solicitante: "{String}",
            phone: "{Number, optional}"
        }
    },
];
export const tests = [
    {
        title: "Test add",
        functionName: "",
        params: {
            solicitante: "Guilherme",
            _phone: "169999999"
        }
    },
    {
        title: "Test add 2",
        functionName: "",
        params: {
            solicitante: "Guilherme",
            _phone: "169999999"
        }
    },
];
export function testAddUser(args) {
    try {
        setState('projectTest.page1.newRequest.solicitante', args.solicitante);
        return 'ok';
    }
    catch (e) {
        return e.message;
    }
}
function testAddUserFull(args) {
    try {
        setState('projectTest.page1.newRequest.solicitante', args.solicitante);
        return 'ok';
    }
    catch (e) {
        return e.message;
    }
}
