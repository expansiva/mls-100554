/// <mls shortName="tsTestASTTeste" project="100554" enhancement="_blank" />
export const integrations = [];
export const tests = [
    {
        functionName: "testAddUser",
        params: [
            { solicitante: "Guilherme", phone: "169999999" },
            { solicitante: "Guilherme", phone: "" }
        ]
    },
];
export function testAddUser(args) {
    try {
        console.info('testAddUser');
        return 'ok';
    }
    catch (e) {
        return e.message;
    }
}
