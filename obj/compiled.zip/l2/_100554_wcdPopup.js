/// <mls shortName="wcdPopup" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let WCDPopup = class WCDPopup extends LitElement {
    constructor() {
        super(...arguments);
        this.x = 0;
        this.y = 0;
        this.buttons = '';
    }
    // Render the popup at the specified position
    render() {
        return html `
      <div class="popup-content" style="top: ${this.y}px; left: ${this.x}px; height: 40px; width: 100px">
            <wcd-popup-item-bold-100554></wcd-popup-item-bold-100554>
      </div>
    `;
    }
    // Update position based on x and y properties
    updated(changedProperties) {
        if (changedProperties.has('x') || changedProperties.has('y')) {
            this.style.left = `${this.x}px`;
            this.style.top = `${this.y}px`;
        }
    }
};
WCDPopup.styles = css `
    :host {
      position: absolute;
      display: block;
      background-color: black;
      color: white;
      padding: 8px;
      border-radius: 5px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
      font-family: sans-serif;
      z-index: 1000;
    }
    .popup-content {
      display: flex;
      align-items: center;
    }
    ::slotted(*) {
      margin: 0 4px;
    }
  `;
__decorate([
    property({ type: Number })
], WCDPopup.prototype, "x", void 0);
__decorate([
    property({ type: Number })
], WCDPopup.prototype, "y", void 0);
__decorate([
    property({ type: String })
], WCDPopup.prototype, "buttons", void 0);
WCDPopup = __decorate([
    customElement('wcd-popup-100554')
], WCDPopup);
export { WCDPopup };
