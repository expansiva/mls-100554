/// <mls shortName="wcdPopup" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
export function initWcdPopup() {
    return true;
}
let WCDPopup = class WCDPopup extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.x = 0;
        this.y = 0;
        this.buttons = 'bold,italic,dropcap,link,separator,h1,h2,h3,h4,separator,blockquote';
    }
    changeType(tp) {
        if (!this.myParent)
            return;
        this.myParent.changeType(tp);
    }
    async loadComponent(button) {
        switch (button) {
            case 'bold':
                await import('./_100554_wcdPopupItemBold');
                return 'wcd-popup-item-bold-100554';
            case 'italic':
                await import('./_100554_wcdPopupItemItalic');
                return 'wcd-popup-item-italic-100554';
            case 'link':
                await import('./_100554_wcdPopupItemLink');
                return 'wcd-popup-item-link-100554';
            case 'separator':
                await import('./_100554_wcdPopupItemSeparator');
                return 'wcd-popup-item-separator-100554';
            case 'h1':
                await import('./_100554_wcdPopupItemH1');
                return 'wcd-popup-item-h1-100554';
            case 'h2':
                await import('./_100554_wcdPopupItemH2');
                return 'wcd-popup-item-h2-100554';
            case 'h3':
                await import('./_100554_wcdPopupItemH3');
                return 'wcd-popup-item-h3-100554';
            case 'h4':
                await import('./_100554_wcdPopupItemH4');
                return 'wcd-popup-item-h4-100554';
            case 'blockquote':
                await import('./_100554_wcdPopupItemBlockQuote');
                return 'wcd-popup-item-block-quote-100554';
            case 'dropcap':
                await import('./_100554_wcdPopupItemDropCap');
                return 'wcd-popup-item-drop-cap-100554';
            default:
                console.error('invalid button name: "' + button + '"');
                return null;
        }
    }
    async firstUpdated() {
        const buttonsArray = this.buttons.split(',').map(button => button.trim());
        const components = await Promise.all(buttonsArray.map(button => this.loadComponent(button)));
        this.shadowRoot.innerHTML = `
      <div class="popup-content" style="top: ${this.y}px; left: ${this.x}px; height: 40px">
        ${components.filter(Boolean).map(button => {
            const valid = this.isValid(button);
            return `<${button} ${!valid ? 'style="display:none"' : ''}></${button}>`;
        }).join('')}
      </div>
    `;
    }
    render() {
        return html `<div class="popup-content" style="height: 40px;"></div>`;
    }
    // Update position based on x and y properties
    updated(changedProperties) {
        if (changedProperties.has('x') || changedProperties.has('y')) {
            this.style.left = `${this.x}px`;
            this.style.top = `${this.y}px`;
        }
    }
    isValid(name) {
        if (!name)
            return false;
        if (name !== 'wcd-popup-item-drop-cap-100554')
            return true;
        return this.checkIsValidDropCap();
    }
    checkIsValidDropCap() {
        const contentEditable = this.parentElement?.querySelector('[contenteditable="true"]');
        if (!contentEditable)
            return false;
        if (!window.wcdState.elMain || window.wcdState.elMain.getAttribute('type') !== "p")
            return false;
        const isFirstWordSelected = this.isFirstWordSelected(contentEditable);
        return isFirstWordSelected;
    }
    isFirstWordSelected(contentEditableElement) {
        const selection = window.getSelection();
        if (!selection || !contentEditableElement)
            return false;
        const range = selection.getRangeAt(0);
        if (!contentEditableElement.contains(range.commonAncestorContainer))
            return false;
        const textContent = contentEditableElement.textContent?.trim() || '';
        const firstWord = textContent.split(/\s+/)[0];
        const firstWordStart = textContent.indexOf(firstWord);
        const firstWordEnd = firstWordStart + firstWord.length;
        const isFirstLetterUppercase = firstWord.charAt(0) === firstWord.charAt(0).toUpperCase();
        const selectionStart = range.startOffset;
        const selectionEnd = range.endOffset;
        const isPartOfFirstWordSelected = (selectionStart < firstWordEnd && selectionEnd > firstWordStart);
        return isPartOfFirstWordSelected && isFirstLetterUppercase;
    }
};
WCDPopup.styles = css `
    :host {
      position: absolute;
      display: block;
      background-color: black;
      color: white;
      padding: 8px;
      border-radius: 5px;
      box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
      font-family: sans-serif;
      z-index: 1000;
    }

    :host::after {
      content: '';
      position: absolute;
      left: 50%;
      bottom: -8px;
      transform: translateX(-50%);
      width: 0;
      height: 0;
      border-left: 8px solid transparent;
      border-right: 8px solid transparent;
      border-top: 8px solid black;
    }

    .popup-content {
      display: flex;
      align-items: center;
    }

    ::slotted(*) {
      margin: 0 4px;
    }
  `;
__decorate([
    property({ type: Number })
], WCDPopup.prototype, "x", void 0);
__decorate([
    property({ type: Number })
], WCDPopup.prototype, "y", void 0);
__decorate([
    property({ type: String })
], WCDPopup.prototype, "buttons", void 0);
WCDPopup = __decorate([
    customElement('wcd-popup-100554')
], WCDPopup);
export { WCDPopup };
