/// <mls shortName="servicePage" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { convertFileNameToTag } from './_100554_utilsLit';
/// **collab_i18n_start**
const message_pt = {
    detailsHint: 'Detalhes do objeto selecionado na página, - help , - ajustes widget como mutations (ica), - ajustes dinâmicos (wcd) , por favor selecione um item na página',
    selectPlugin: 'Por favor selecione um plugin IA',
    loading: 'Carregando...'
};
const message_en = {
    detailsHint: 'Details of the selected object on the page, - help , - widget settings like mutations (ica), - dynamic settings (wcd), please select an item on the page',
    selectPlugin: 'Please select a plugin IA',
    loading: 'Loading...'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePage100554 = class ServicePage100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.details = {
            icon: '&#xf15b',
            state: 'foreground',
            position: 'right',
            tooltip: 'Page',
            visible: true,
            widget: '_100554_servicePage',
            level: [5]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            this.activeTab = op;
        };
        this.menu = {
            title: '',
            actions: {},
            icons: {
                icDetails: 'Details;3f',
                icNavigation: 'Navigation;f041',
                icProperties: 'Properties;f0ce',
                icIA: 'IA;f5dc',
            },
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.activeTab = 'icDetails';
        this.pluginNav = '';
        this.pluginProp = '';
        this.pluginsIA = {};
        this.pluginIALoaded = false;
    }
    createRenderRoot() {
        return this;
    }
    onServiceClick(visible, reinit, el) {
    }
    async firstUpdated() {
        if (this.menu.setIconActive)
            this.menu.setIconActive(this.activeTab);
        await this.loadPlugins();
        await this.setPluginIA();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'icNavigation':
                return this.renderNavigation();
            case 'icProperties':
                return this.renderProperties();
            case 'icDetails':
                return this.renderDetails();
            case 'icIA':
                return this.renderIA();
            default:
                return html ``;
        }
    }
    renderNavigation() {
        this.openService('_100554_servicePreview', 'right', 3);
        return html ` ${this.pluginNav ? unsafeHTML(`<${this.pluginNav} .service=${this}></${this.pluginNav}>`) : `<div>${this.msg.loading}</div>`}`;
    }
    renderProperties() {
        this.openService('_100554_servicePreview', 'right', 3);
        return html ` ${this.pluginProp ? unsafeHTML(`<${this.pluginProp} .service=${this}></${this.pluginProp}>`) : `<div>${this.msg.loading}</div>`}`;
    }
    renderDetails() {
        return html `<div>${this.msg.detailsHint}</div>`;
    }
    renderIA() {
        const keys = Object.keys(this.pluginsIA);
        return html `

            ${!this.pluginIALoaded
            ? html `<div>${this.msg.loading}</div>`
            : html `
                <div>
                    ${repeat(keys, ((key, idx) => key + idx), ((item, index) => {
                return html `<collab-panel-100554 .myData=${this.pluginsIA[item]}>
                    </collab-panel-100554>`;
            }))}
                </div>`}
        `;
    }
    async loadPlugins() {
        const { project } = mls.actual[5];
        if (!project)
            return;
        await mls.plugin.loadAll(project, true);
        const plgNav = mls.plugin.getAllMenuActions(project, { scope: 'l3PageNavigation' });
        const plgProp = mls.plugin.getAllMenuActions(project, { scope: 'l3PageProperties' });
        const plgNavName = plgNav[0] ? plgNav[0].widget : '';
        const plgPropName = plgProp[0] ? plgProp[0].widget : '';
        if (plgNavName) {
            await import(`./${plgNavName}`);
            this.pluginNav = convertFileNameToTag(plgNavName);
        }
        if (plgPropName) {
            await import(`./${plgPropName}`);
            this.pluginProp = convertFileNameToTag(plgPropName);
        }
    }
    async setPluginIA() {
        const { project } = mls.actual[5];
        if (!project)
            return;
        let array = [];
        await mls.plugin.loadAll(project, false);
        array = mls.plugin.getAllMenuActions(project, { scope: 'l3PageAI' });
        array.forEach((item) => {
            const cat = item.category;
            if (!this.pluginsIA[cat])
                this.pluginsIA[cat] = [item];
            else
                this.pluginsIA[cat].push(item);
        });
        this.pluginIALoaded = true;
        this.requestUpdate();
    }
};
__decorate([
    property()
], ServicePage100554.prototype, "activeTab", void 0);
__decorate([
    property()
], ServicePage100554.prototype, "pluginNav", void 0);
__decorate([
    property()
], ServicePage100554.prototype, "pluginProp", void 0);
__decorate([
    property()
], ServicePage100554.prototype, "pluginsIA", void 0);
__decorate([
    property()
], ServicePage100554.prototype, "pluginIALoaded", void 0);
ServicePage100554 = __decorate([
    customElement('service-page-100554')
], ServicePage100554);
export { ServicePage100554 };
