/// <mls shortName="aiAgentCustom" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { collab_trash } from './_100554_collabIcons';
import { updateHTML } from './_100554_collabDOMSync';
let CollabFCATree = class CollabFCATree extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ai-agent-custom-100554{display:block;overflow-y:auto;height:100%}ai-agent-custom-100554 .header{display:flex;justify-content:space-between;align-items:center;padding:12px 20px;background-color:#f9f9f9;border-bottom:1px solid #ddd;font-family:sans-serif;gap:16px;margin-bottom:12px}ai-agent-custom-100554 .header .header>div{display:flex;align-items:center;gap:10px}ai-agent-custom-100554 .header label{font-weight:500;margin-right:6px}ai-agent-custom-100554 .header input[type="text"],ai-agent-custom-100554 .header select{padding:6px 10px;border:1px solid #ccc;border-radius:4px;min-width:180px;outline:none}ai-agent-custom-100554 .header .model{background-color:#ccc;color:#020202;padding:7px 10px;border-radius:4px;font-size:14px;margin-right:5px;outline:none;border:none}ai-agent-custom-100554 .header button{padding:6px 12px;background-color:#007acc;color:white;border:none;border-radius:4px;cursor:pointer;font-weight:500;transition:background-color .2s ease}ai-agent-custom-100554 .header button:hover{background-color:#005fa3}ai-agent-custom-100554 .header .groupInputs{display:flex;gap:.3rem}ai-agent-custom-100554 .header .groupInputs div{width:min-content;padding:.2rem}ai-agent-custom-100554 details{border:1px solid #ddd;border-radius:6px;padding:10px 14px;background-color:#ffffff;font-family:sans-serif;margin-bottom:12px;transition:all .2s ease}ai-agent-custom-100554 details summary{font-weight:bold;cursor:pointer;list-style:none;position:relative;padding-left:20px}ai-agent-custom-100554 details summary::before{content:"▶";position:absolute;left:0;transition:transform .2s ease}details[open] ai-agent-custom-100554 details summary::before{transform:rotate(90deg)}ai-agent-custom-100554 details summary:hover{color:#007acc}ai-agent-custom-100554 details>*:not(summary){margin-top:10px;line-height:1.5}ai-agent-custom-100554 details button{padding:6px 12px;background-color:#007acc;color:white;border:none;border-radius:4px;cursor:pointer;font-weight:500;transition:background-color .2s ease}ai-agent-custom-100554 details button:hover{background-color:#005fa3}ai-agent-custom-100554 .input{padding:.5rem;border-radius:8px;border:1px solid #f0f0f0;border-left:4px solid #f0f0f0;margin-bottom:10px;display:flex;gap:.5rem}ai-agent-custom-100554 .input input{padding:6px 10px;border-radius:4px;width:80%;border:none;outline:none}ai-agent-custom-100554 .prompt{padding:.5rem 1rem 1rem 1rem;border-radius:8px;border:1px solid #f0f0f0;border-left:4px solid #f0f0f0;margin-bottom:10px}ai-agent-custom-100554 .prompt .pheader{display:flex;align-items:center;justify-content:space-between}ai-agent-custom-100554 .prompt .pheader .trash{cursor:pointer}ai-agent-custom-100554 .content{display:flex;flex-direction:column;background-color:#f0f0f0;padding:.5rem;border-radius:5px;width:calc(100% - 1rem);border:none;min-height:80px;outline:none}ai-agent-custom-100554 .type{font-weight:bold;font-size:.9em;margin-bottom:10px}ai-agent-custom-100554 .type select{padding:6px 10px;border:1px solid #ccc;border-radius:4px;min-width:120px;outline:none}ai-agent-custom-100554 .containerLoading{display:flex;justify-content:center;align-items:center;flex-direction:column;width:100%;height:99%}ai-agent-custom-100554 .loading-container{text-align:center}ai-agent-custom-100554 .spinner{width:60px;height:60px;border:6px solid #ccc;border-top:6px solid #3498db;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 20px}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}ai-agent-custom-100554 p{font-size:18px;color:#555}`);
        this.prompts = [];
        this.inputs = [];
        this.user = { userId: "", threads: [] };
        this.inLoader = true;
        this.models = [
            { k: "gpt-4.1-nano", v: "cost" },
            { k: "reasoner", v: "reasoner" },
            { k: "image", v: "image" },
            { k: "code", v: "code" },
            { k: "gpt-4.1-mini", v: "executor" },
            { k: "writer", v: "writer" },
            { k: "grok-2-latest", v: "latency" },
            { k: "translate", v: "translate" },
        ];
    }
    //--------------COMPONENT---------------
    firstUpdated() {
        this.loadPrompts();
    }
    render() {
        return html `
            <div class="containerLoading" style="${this.inLoader ? "" : "display:none"}">
                <div class="loading-container">
                    <div class="spinner"></div>
                    <p>Loading...</p>
                </div>
            </div>

            <div class="header" style="${this.inLoader ? "display:none" : ""}">
                <div class="groupInputs">
                    <div>
                        <label>Agent name:</label>
                        <input type="text" value="agentJohn" id="agentName"></input>
                    </div>
                    <div>
                        <label>Thread:</label>
                        ${this.renderThreads()}
                    </div>
                    <div>
                        <label>UserId:</label>
                        <input type="text" id="userId" .value="${this.user.userId}"></input>
                    </div>
                </div>
                <div style=" margin-top: 16px;">
                    ${this.renderModels()}
                    <button @click="${this.saveHTML}">Save</button>
                    <button style="background-color: #348e0f;" @click="${this.start}">Start</button>
                </div>
            </div>
            <details style="${this.inLoader ? "display:none" : ""}">
                <summary> Prompts </summary>
                <div class="container">
                    ${repeat(this.prompts, ((key) => key.type + Date.now()), ((p, idx) => { return this.renderPrompt(p, idx); }))}
                </div>
                <button style="background-color: #348e0f;" @click="${this.addMessage}">
                    Add Message
                </button>
            </details>
            <details style="${this.inLoader ? "display:none" : ""}">
                <summary> Inputs </summary>
                <div class="container">
                    ${repeat(this.inputs, ((key) => key.text + Date.now()), ((i) => { return this.renderInput(i); }))}
                </div>
            </details>
            <hr/>
            <details open style="${this.inLoader ? "display:none" : ""}">
                <summary> Output </summary>
                <div id="result">
                </div>
            </details>
        `;
    }
    renderPrompt(prompt, idx) {
        let pp = prompt.content.trim();
        if (idx === 0 && this.selModels) { //* <!-- modelType: reasoner -->
            pp = `//* <!-- modelType: ${this.selModels.value} -->\n${pp}`;
        }
        return html `
            <div class="prompt ${prompt.type}">
                <div class="pheader">
                    <div class="type">
                        ${this.renderSelect(prompt)}
                    </div>
                    <div class="trash" @click="${() => this.trashClick(prompt)}">${collab_trash}</div>
                </div>
                <textarea class="content" @blur="${(e) => this.promptEvent(e, prompt)}">${pp}</textarea>
            </div>
        `;
    }
    renderSelect(prompt) {
        return html `
            <select .value=${prompt.type.trim()} @change=${(e) => this.updateSelect(e, prompt)}>
                <option value="system">System</option>
                <option value="human">Human</option>
                <option value="ai">AI</option>
            </select>
        `;
    }
    renderInput(ipt) {
        return html `
            <div class="input">
                <label>${ipt.text}</label>
                <input type="text" .info="${ipt}" @blur="${(e) => this.inputEvent(e, ipt)}" .value="${ipt.value}" placeholder="Enter variable value..."></input>
            </div>
        `;
    }
    renderModels() {
        return html `
            <select class="model" id="selModels" @change=${(e) => this.requestUpdate()}>
                ${repeat(this.models, ((key) => key.k), ((i) => html `<option value="${i.v}">${i.k}</option>`))}
            </select>
        `;
    }
    renderThreads() {
        return html `
            <select id="threadId">
                ${repeat(this.user.threads, ((key) => key), ((i) => html `<option value="${i}">${i}</option>`))}
            </select>
        `;
    }
    //------------IMPLEMENTS--------------
    async loadPrompts() {
        const myPP = [];
        const myIp = [];
        Array.from(this.children).forEach((c) => {
            const tp = c.getAttribute('type');
            const pp = c.innerHTML;
            if (!tp || !pp)
                return;
            const p = {
                type: tp,
                content: pp
            };
            c.remove();
            const placeholders = this.getPlaceholders(p.content);
            placeholders.forEach((i) => myIp.push({ text: i, value: '' }));
            myPP.push(p);
        });
        const info = await this.getIdUSer();
        this.user = info;
        this.prompts = myPP;
        this.inputs = myIp;
        this.inLoader = false;
    }
    getPlaceholders(text) {
        const regex = /{{\s*[^}]+?\s*}}/g;
        return text.match(regex) || [];
    }
    async getIdUSer() {
        let ret = {
            userId: "",
            threads: []
        };
        const info = await mls.api.msgGetUserUpdate({ userId: "" });
        ret.userId = info.user.userId || "";
        ret.threads = info.user.threads || [];
        return ret;
    }
    trashClick(pp) {
        const myPP = [];
        const myIp = [];
        this.prompts.forEach((p, idx) => {
            if (p.content !== pp.content || p.type !== pp.type) {
                myPP.push({ ...p });
                const placeholders = this.getPlaceholders(p.content);
                placeholders.forEach((i) => myIp.push({ text: i, value: '' }));
            }
        });
        this.prompts = myPP;
        this.inputs = myIp;
    }
    addMessage() {
        const myPP = [...this.prompts];
        myPP.push({
            type: "system",
            content: ""
        });
        this.prompts = myPP;
    }
    promptEvent(e, prompt) {
        const el = e.target;
        if (!el)
            return;
        const myIp = [];
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.content = el.value;
            const placeholders = this.getPlaceholders(p.content);
            placeholders.forEach((i) => myIp.push({ text: i, value: '' }));
        });
        this.inputs = myIp;
    }
    updateSelect(e, prompt) {
        const el = e.target;
        if (!el)
            return;
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.type = el.value;
        });
    }
    inputEvent(e, ipt) {
        const el = e.target;
        if (!el)
            return;
        this.inputs.forEach((i) => {
            if (i.text === ipt.text)
                i.value = el.value;
        });
    }
    async start() {
        if (!this.result) {
            console.info('not found result');
            return;
        }
        if (!this.agentName || !this.agentName.value) {
            this.result.innerHTML = 'Not found agentName';
            return;
        }
        if (!this.threadId || !this.threadId.value) {
            this.result.innerHTML = 'Not found threadId';
            return;
        }
        if (!this.userId || !this.userId.value) {
            this.result.innerHTML = 'Not found userId';
            return;
        }
        const myPP = this.prompts.map(obj => ({ ...obj }));
        myPP.forEach((p, idx) => {
            this.inputs.forEach((i) => {
                p.content = p.content.replace(i.text, i.value);
            });
            if (idx === 0 && this.selModels) {
                p.content = `<!-- modelType: ${this.selModels.value} -->\n${p.content}`;
            }
        });
        try {
            this.inLoader = true;
            const args = {
                action: "addMessageAI",
                threadId: this.threadId.value,
                userId: this.userId.value,
                taskTitle: "Custom: " + this.agentName.value,
                userMessage: "Custom: " + this.agentName.value,
                agentName: this.agentName.value,
                inputAI: myPP,
            };
            const value = await mls.api.msgAddMessageAI(args);
            this.result.innerText = JSON.stringify(value, null, 2);
            console.info(value);
            this.inLoader = false;
        }
        catch (e) {
            this.inLoader = false;
            this.result.innerText = e;
        }
    }
    saveHTML() {
        let txt = '<ai-agent-custom-100554>';
        this.prompts.forEach((p) => {
            txt = txt + `
            <promptcustom type="${p.type}">
                ${p.content}
            </promptcustom>
            `;
        });
        txt = txt + '</ai-agent-custom-100554>';
        updateHTML(txt);
    }
};
__decorate([
    query('#agentName')
], CollabFCATree.prototype, "agentName", void 0);
__decorate([
    query('#threadId')
], CollabFCATree.prototype, "threadId", void 0);
__decorate([
    query('#userId')
], CollabFCATree.prototype, "userId", void 0);
__decorate([
    query('#result')
], CollabFCATree.prototype, "result", void 0);
__decorate([
    query('#selModels')
], CollabFCATree.prototype, "selModels", void 0);
__decorate([
    property({ reflect: true })
], CollabFCATree.prototype, "prompts", void 0);
__decorate([
    property({ reflect: true })
], CollabFCATree.prototype, "inputs", void 0);
__decorate([
    property({ reflect: true })
], CollabFCATree.prototype, "user", void 0);
__decorate([
    property({ reflect: true })
], CollabFCATree.prototype, "inLoader", void 0);
CollabFCATree = __decorate([
    customElement('ai-agent-custom-100554')
], CollabFCATree);
export { CollabFCATree };
