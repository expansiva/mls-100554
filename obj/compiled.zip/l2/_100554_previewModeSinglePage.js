/// <mls shortName="previewModeSinglePage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { convertTagToFileName } from './_100554_utilsLit';
import * as util from './_100554_previewModeUtil';
export class PreviewModeSinglePage {
    constructor(_j, _i, _l, _s, _f, _m) {
        this.isService = false;
        this.models = undefined;
        this.file = undefined;
        this.json = _j;
        this.ifr = _i;
        this.level = _l;
        this.isService = _s;
        this.file = _f;
        this.models = _m;
    }
    async init() {
        if (!this.json || !this.ifr)
            return;
        await this.loadEsbuild();
        setTimeout(async () => await this.configIframe(), 100);
    }
    async configIframe() {
        if (!this.json || !this.ifr || !this.esbuild || !this.models)
            return;
        const myMap = this.parseImportsMap(this.json.importsMap);
        const find = this.findWidgets(this.ifr.contentDocument?.body);
        let valids = [...Object.keys(myMap), ...this.json.importsJs, ...find];
        valids = [...new Set(valids)];
        const virtualFsPlugin = {
            name: 'virtual-fs',
            setup(build) {
                build.onResolve({ filter: /.*/ }, (args) => {
                    if (valids.includes(args.path)) {
                        return {
                            path: args.path,
                            namespace: 'virtual',
                        };
                    }
                    if (args.path.startsWith("./") &&
                        !args.importer.startsWith("https://")) {
                        return {
                            path: args.path.replace('./', '/'),
                            namespace: 'virtual',
                        };
                    }
                    if ((args.path.startsWith("./") ||
                        args.path.startsWith("../") ||
                        args.path.startsWith("/")) &&
                        myMap[args.importer]) {
                        const url = new URL(args.path, myMap[args.importer]);
                        return { path: url.href, namespace: 'virtual' };
                    }
                    if ((args.path.startsWith("./") ||
                        args.path.startsWith("../") ||
                        args.path.startsWith("/")) &&
                        args.importer.startsWith("https://")) {
                        const url = new URL(args.path, args.importer);
                        return { path: url.href, namespace: 'virtual' };
                    }
                    if (args.path.startsWith("http")) {
                        return { path: args.path, namespace: 'virtual' };
                    }
                    return null;
                });
                build.onLoad({ filter: /.*/, namespace: 'virtual' }, async (args) => {
                    try {
                        let path = myMap[args.path] ? myMap[args.path] : args.path;
                        const res = await fetch(path);
                        if (!res.ok)
                            throw new Error(`Error get ${args.path}`);
                        const text = await res.text();
                        return { contents: text, loader: 'js' };
                    }
                    catch (e) {
                        console.info('erro:' + args.path);
                        return { contents: '', loader: 'js' };
                    }
                });
            },
        };
        let allImports = [...this.json.importsJs, ...find];
        allImports = [...new Set(allImports)];
        const virtualEntryPath = "virtual-entry.js";
        const virtualEntryContent = allImports.map(path => `import "${path}";`).join("\n");
        const result = await this.esbuild.build({
            stdin: {
                contents: virtualEntryContent,
                resolveDir: "/",
                sourcefile: virtualEntryPath,
                loader: "js"
            },
            bundle: true,
            minify: true,
            format: "esm",
            write: false,
            plugins: [virtualFsPlugin]
        });
        util.mountJSImporMap(this.json, this.ifr);
        util.mountTokens(this.json.tokens || '', this.models);
        util.addJsReference(this.ifr, this.level || '2');
        const s = document.createElement('script');
        s.textContent = result.outputFiles[0].text;
        this.ifr.contentDocument?.body.appendChild(s);
        if (this.isService && this.file)
            util.simulateService(this.json, this.ifr, this.file);
    }
    parseImportsMap(importsArray) {
        return Object.fromEntries(importsArray.map(str => {
            const match = str.match(/^"(.+?)":\s*"(.+?)"$/);
            if (!match)
                throw new Error("Formato inválido: " + str);
            const [, key, value] = match;
            return [key, value];
        }));
    }
    findWidgets(rootElement) {
        if (!rootElement)
            return [];
        const els = rootElement.querySelectorAll('[widget]');
        const array = Array.from(els)
            .map((el) => {
            if (!el.tagName.toLocaleLowerCase().startsWith('ica-'))
                return '';
            return '/' + convertTagToFileName(el.getAttribute('widget') || '');
        })
            .filter(Boolean);
        const ret = [...new Set(array)];
        return ret;
    }
    async loadEsbuild() {
        if (mls.esbuild)
            this.esbuild = mls.esbuild;
        else if (!mls.esbuildInLoad)
            await this.initializeEsBuild();
    }
    async initializeEsBuild() {
        mls.esbuildInLoad = true;
        const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
        if (!this.esbuild) {
            this.esbuild = await import(url);
            await this.esbuild.initialize({
                wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
            });
            mls.esbuild = this.esbuild;
            mls.esbuildInLoad = false;
        }
    }
}
