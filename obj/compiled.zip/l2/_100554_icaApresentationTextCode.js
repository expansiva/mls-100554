/// <mls shortName="icaApresentationTextCode" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElementBase } from './_100554_icaLitElementBase';
let IcaApresentationTextCode = class IcaApresentationTextCode extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.language = 'typescript';
        this.languages = [];
        this.text = '';
        this.mySymbol = 'fa-code';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "menu" },
            { name: "size" },
            { name: "edit-code" },
            { name: "title" },
            { name: "code-language" },
        ];
    }
    setDefaultAttributes() {
        this.setAttribute('text', `const example = '123';`);
    }
    changeStateHtml(html) {
    }
    allowCommand(cmd, scope, target) {
        if (cmd === 'move')
            return this.commandMove(scope, target);
        return { inside: false, before: false, after: false };
    }
    // ----------- IMPLEMENTATION ---------------
    commandMove(scope, target) {
        return { inside: false, before: false, after: false };
    }
};
__decorate([
    property({ type: String, reflect: true })
], IcaApresentationTextCode.prototype, "language", void 0);
__decorate([
    property({ type: Array })
], IcaApresentationTextCode.prototype, "languages", void 0);
__decorate([
    property({ type: String, reflect: true })
], IcaApresentationTextCode.prototype, "text", void 0);
IcaApresentationTextCode = __decorate([
    customElement('ica-apresentation-text-code-100554')
], IcaApresentationTextCode);
export { IcaApresentationTextCode };
