var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="wcdAdd" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { getMessageKey } from "./_100554_collabLitElement";
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
import * as commandDivider from './_100554_wcdCommandAddDivider';
import * as commandCode from './_100554_wcdCommandAddCodeBlock';
import { collab_xmark, collab_image, collab_unsplash, collab_video, collab_code, collab_ellipsis, collab_link } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    image: 'Adicionar uma imagem',
    video: 'Adicionar um video',
    embed: 'Adicionar um link incorporado',
    unsplash: 'Adicionar uma imagem do Unsplash',
    code: 'Adicionar um novo bloco de código',
    newPart: 'Adicionar uma nova parte',
};
const message_en = {
    image: 'Add an image',
    video: 'Add a video',
    embed: 'Add an embed',
    unsplash: 'Add an imagem from Unsplash',
    code: 'Add a new code block',
    newPart: 'Add a new part',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdAdd100554 = class WcdAdd100554 extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.importsInfo = {
            unsplash: '_100554_wcdDialogImageUnsplash',
            image: '_100554_wcdDialogImage',
            video: '_100554_wcdDialogVideo',
            embed: '_100554_wcdDialogEmbedLink',
        };
        this.widthMarginOfError = 10;
        this.styles = `
        .add-button{
            position:relative;
        }
        button span {
            color: var(--text-primary-color);
        }
        button svg{
            fill: var(--text-primary-color);
        }
        button {
            width: 32px;
            height: 32px;
            line-height: 30px;
            padding: 0;
            font-size: 15px;
            background: var(--bg-primary-color-lighter);
            border-radius: 100%;
            border: 1px solid rgba(0,0,0,.68);
            text-decoration: none;
            cursor: pointer;
            vertical-align: bottom;
            white-space: nowrap;
            display: inline-block;
            position: relative;
            box-sizing: border-box;
            letter-spacing: 0;
            font-weight: 400;
            font-style: normal;
            text-rendering: optimizeLegibility;
            -webkit-font-smoothing: antialiased;
        }
        .add-button:not(.close) .buttons-actions{
            opacity: 1;
            display:inline-block;
        }
        .buttons-actions{
            position:relative;
            display:none;
            padding-left: 22px;
        }
        button svg{
            transition:transform .1s,-webkit-transform .1s;
        }
        .add-button.close svg{
            transform:rotate(-45deg);
        }
        button span {
            vertical-align: middle;
        }
        add-tooltip {
            display:block;
            position: absolute;
            will-change: transform;
            white-space: nowrap;
            top: 0px;
            left: 0px;
            transform: translate3d(-13px, 5px, 0px);
            z-index: 9999;
            font-size:14px;
        }
        add-tooltip > div {
            top: -8px;
            position: absolute;
            display: block;
            width: 100%;
            height: 0.4rem;
        }
        add-tooltip > div::before {
            position: absolute;
            content: "";
            border-color: transparent;
            border-style: solid;
            bottom: -1px;
            left: 5px;
            border-width: 0 0.4rem 0.4rem;
            border-bottom-color: #000;
        }
        add-tooltip > div.open-to-right::before {
            left: 0;
            content: none;
        }
        add-tooltip > div.open-to-right::after {
            position: absolute;
            content: "";
            border-color: transparent;
            border-style: solid;
            right: 8px;
            bottom: -1px;
            border-width: 0 0.4rem 0.4rem;
            border-bottom-color: #000;
        }
        add-tooltip > span {
            max-width: 200px;
            padding: 0.25rem 0.5rem;
            color: #fff;
            text-align: center;
            background-color: #000;
            border-radius: 0.25rem;
        }
        add-toolti a[title]:hover::after {
            display: none;
        }
        .scale-in-center {
            -webkit-animation: scale-in-center 0.2s cubic-bezier(0.250, 0.460, 0.450, 0.940) both;
                    animation: scale-in-center 0.2s cubic-bezier(0.250, 0.460, 0.450, 0.940) both;
        }
        @-webkit-keyframes scale-in-center {
            0% {
                -webkit-transform: scale(0);
                        transform: scale(0);
                opacity: 1;
            }
            100% {
                -webkit-transform: scale(1);
                        transform: scale(1);
                opacity: 1;
            }
            }
            @keyframes scale-in-center {
            0% {
                -webkit-transform: scale(0);
                        transform: scale(0);
                opacity: 1;
            }
            100% {
                -webkit-transform: scale(1);
                        transform: scale(1);
                opacity: 1;
            }
        }
    `;
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        const allBtns = this.containerButtons?.querySelectorAll('button');
        if (!allBtns)
            return;
        allBtns.forEach((btn) => { this.tooltipElement(btn); });
        this.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }
    render() {
        const lang = getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="add-button close">
            <button @click=${this.onButtonClick} >
                <span>
                    ${collab_xmark}
                </span>
            </button>
            <div class="buttons-actions">
                <button @click=${this.handleImageClick} data-tooltip=${this.msg.image} ><span>${collab_image}</span></button>
                <button @click=${this.handleUnsplashClick} data-tooltip=${this.msg.unsplash}><span>${collab_unsplash}</span></button>
                <button @click=${this.handleVideoClick} data-tooltip=${this.msg.video}><span>${collab_video}</span></button>
                <button @click=${this.handleEmbedClick} data-tooltip=${this.msg.embed}><span>${collab_link}</span></button>
                <button @click=${this.handleCodeClick} data-tooltip=${this.msg.code}><span>${collab_code}</span></button>
                <button @click=${this.handleNewPartClick} data-tooltip=${this.msg.newPart}><span>${collab_ellipsis}</span></button>
                <add-tooltip></add-tooltip>
            </div>
        </div>

        <div class="add-button-helper">
            <div data-helper="image"></div>
            <div data-helper="unsplash"></div>
        </div>
        <style>${this.styles}</style>
        `;
    }
    async handleUnsplashClick(e) {
        e.stopPropagation();
        this.showHelper('unsplash');
    }
    async handleImageClick(e) {
        e.stopPropagation();
        this.showHelper('image');
    }
    async handleNewPartClick(e) {
        commandDivider.execute({
            args: {},
            overlay: this.myParent.parentElement?.parentElement,
            selectedIca: this.elICA,
        });
    }
    async handleCodeClick(e) {
        commandCode.execute({
            args: {},
            overlay: this.myParent.parentElement?.parentElement,
            selectedIca: this.elICA,
        });
    }
    async handleEmbedClick(e) {
        this.showHelper('embed');
    }
    async handleVideoClick(e) {
        this.showHelper('video');
    }
    showHelper(helper) {
        if (!this.myParent)
            return;
        this.myParent.onclick = undefined;
        this.myParent.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: this.importsInfo[helper],
                args: '',
                position: 'p-l1',
                level: [2],
                toolboxOptions: { background: '#fff', border: 'none' }
            },
        ], false, 'size');
    }
    tooltipElement(el) {
        if (this.addTooltip && el)
            this.tooltip(el);
    }
    tooltip(el) {
        el.addEventListener('mouseover', this.show.bind(this), false);
        el['element'] = el;
        el.addEventListener('mouseleave', this.destroy.bind(this), false);
    }
    destroy(evt) {
        if (!this.addTooltip)
            return;
        this.addTooltip.innerHTML = '';
        this.addTooltip.style.top = '0px';
        this.addTooltip.style.left = '0px';
    }
    show(evt) {
        if (!this.addTooltip || !this.containerButtons)
            return;
        this.addTooltip.innerHTML = '';
        const el = evt.currentTarget['element'];
        if (!el)
            return;
        const title = el.getAttribute('data-tooltip');
        const arrow = document.createElement('div');
        const content = document.createElement('span');
        content.innerHTML = title || '';
        const position = el.getBoundingClientRect();
        const positionContainer = this.containerButtons.getBoundingClientRect();
        const positionDocument = document.body.getBoundingClientRect();
        const { width } = positionDocument;
        this.addTooltip.appendChild(arrow);
        this.addTooltip.appendChild(content);
        const positionContent = content.getBoundingClientRect();
        if (positionContent.width + position.left > (width - this.widthMarginOfError)) {
            arrow.classList.add('open-to-right');
            this.addTooltip.style.left = ((position.left - positionContainer.left) + (position.width / 2) - (positionContent.width - 30)) + 'px';
            this.addTooltip.style.top = '35px';
        }
        else {
            this.addTooltip.style.top = '35px';
            this.addTooltip.style.left = ((position.left - positionContainer.left) + (position.width / 2)) + 'px';
        }
    }
    onButtonClick(e) {
        e.stopPropagation();
        const target = e.target;
        const btn = target.closest('.add-button');
        if (!btn)
            return;
        btn.classList.toggle('close');
        if (!this.containerButtons)
            return;
        const allBtns = this.containerButtons.querySelectorAll('button');
        allBtns.forEach((bt) => bt.classList.toggle('scale-in-center', !btn.classList.contains('close')));
    }
};
__decorate([
    query('.buttons-actions')
], WcdAdd100554.prototype, "containerButtons", void 0);
__decorate([
    query('add-tooltip')
], WcdAdd100554.prototype, "addTooltip", void 0);
__decorate([
    query('.add-button-helper')
], WcdAdd100554.prototype, "helperContainer", void 0);
WcdAdd100554 = __decorate([
    customElement('wcd-add-100554')
], WcdAdd100554);
export { WcdAdd100554 };
