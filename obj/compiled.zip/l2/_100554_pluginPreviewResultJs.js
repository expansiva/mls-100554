/// <mls shortName="pluginPreviewResultJs" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { property, query } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { getDependenciesByMFile } from './_100554_libCompile';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item ICA foi encontrado!'
};
const message_en = {
    noItens: 'No ICA items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export class PluginPreviewResultJs extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.hasError = false;
        this.results = {
            devDoc: '',
            devJS: '',
            devTS: '',
            errors: '',
            prodJS: '',
            references: [],
            configTS: '',
            libTS: '',
            jsonImport: '',
        };
        this.msize = '';
    }
    get confE() { return `l2_left`; }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            this.editor?.setAttribute('msize', this.msize);
        }
    }
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        this.createEditor();
        const editor = mls.l2.editor.editors[this.confE];
        if (!editor)
            return;
        const { project, shortName } = editor;
        this.setInitialModelProdJS(project, shortName, 'compiling...');
        await this.getCompileResults(project, shortName);
        this.setInitialModelProdJS(project, shortName, this.results.prodJS);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<mls-editor-100529></mls-editor-100529>`;
    }
    createEditor() {
        if (!this.editor || this._ed1)
            return;
        this._ed1 = monaco.editor.create(this.editor, mls.editor.conf[this.confE]);
        monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
            noImplicitAny: true
        });
        this._ed1.updateOptions({ readOnly: true });
        this.editor.mlsEditor = this._ed1;
    }
    async getCompileResults(project, shortName) {
        const mfile = mls.l2.editor.get({ shortName, project });
        if (!mfile)
            return;
        if (mfile.compilerResults && !mfile.compilerResults.prodJS)
            mfile.compilerResults.modelNeedCompile = true;
        const results = await mls.l2.editor.getCompilerResultTS(mfile);
        const errs = {
            Errors: results.errors
        };
        const libs = monaco.languages.typescript.typescriptDefaults.getExtraLibs();
        const libs2 = {};
        Object.keys(libs).forEach((key) => {
            libs2[key] = {
                version: libs[key].version
            };
        });
        this.hasError = results.errors.length > 0;
        const jsonImp = await getDependenciesByMFile(mfile);
        this.results = {
            ...results,
            errors: JSON.stringify(errs, null, 2),
            references: [],
            configTS: JSON.stringify(monaco.languages.typescript.typescriptDefaults.getCompilerOptions(), null, 2),
            libTS: JSON.stringify(libs2, null, 2),
            jsonImport: JSON.stringify(jsonImp, null, 2),
        };
    }
    setInitialModelProdJS(project, shortName, src) {
        const model1 = this.createOrGetModel(project, shortName, 'javascript', src);
        if (!model1)
            return;
        if (this._ed1)
            this._ed1.setModel(model1);
    }
    getUri(shortFN) {
        return monaco.Uri.parse(`file://server/${shortFN}_results_js.ts`);
    }
    createOrGetModel(project, shortName, editorType, src) {
        const uri = this.getUri(`_${project}_${shortName}`);
        let modelResultJS = monaco.editor.getModel(uri);
        if (modelResultJS) {
            modelResultJS.setValue(src);
            return modelResultJS;
        }
        modelResultJS = monaco.editor.createModel(src, editorType, uri);
        return modelResultJS;
    }
}
__decorate([
    property({ type: String })
], PluginPreviewResultJs.prototype, "msize", void 0);
__decorate([
    query('mls-editor-100529')
], PluginPreviewResultJs.prototype, "editor", void 0);
if (!customElements.get('plugin-preview-result-js-100554')) {
    customElements.define('plugin-preview-result-js-100554', PluginPreviewResultJs);
}
