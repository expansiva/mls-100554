/// <mls shortName="wcdCommandDel" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { dispatchEventConciliate } from './_100554_wcdCommandBase';
import { findParentElementWithTagName } from './_100554_wcdGlobal';
export function execute(param) {
    if (!param?.selectedIca)
        throw new Error('invalid param.selectedIca');
    if (!param.overlay || typeof param.overlay.selectItem !== 'function')
        throw new Error('invalid param.overlay');
    if (!param.args || !(param.args instanceof KeyboardEvent))
        throw new Error('invalid param.args');
    const e = param.args;
    const ica = param.selectedIca;
    const overlay = param.overlay;
    e.preventDefault();
    if (!ica || !ica.overlayRef)
        return;
    if (e.key.toLocaleLowerCase() === 'backspace')
        onBackspace(ica, overlay);
    else
        onDel(ica, overlay);
    dispatchEventConciliate();
}
function onDel(ica, overlay) {
    let sibling = ica.previousElementSibling;
    const sectionParent = findParentElementWithTagName(ica, 'ica-layout-flow-section-100554');
    ica.remove();
    if (sectionParent)
        sibling = checkParentSection(sectionParent, sibling);
    overlay.refreshOverlay();
    setTimeout(() => {
        if (sibling && sibling.overlayRef) {
            sibling.overlayRef.click();
            sibling.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }, 100);
}
function onBackspace(ica, overlay) {
    let sibling = ica.previousElementSibling;
    if (!sibling || !sibling.overlayRef) {
        sibling = findIcaParentSibling(ica);
        if (!sibling || !sibling.overlayRef)
            return;
    }
    const sectionParent = findParentElementWithTagName(sibling, 'ica-layout-flow-section-100554');
    sibling.remove();
    if (sectionParent)
        sibling = checkParentSection(sectionParent, sibling);
    overlay.refreshOverlay();
    setTimeout(() => {
        if (sibling && sibling.overlayRef) {
            sibling.overlayRef.click();
            sibling.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }, 100);
}
function checkParentSection(sectionParent, sibling) {
    if (sectionParent) {
        const sectionWidgetName = sectionParent.getAttribute('widget') || '';
        const sectionEl = sectionParent.querySelector(sectionWidgetName);
        if (sectionEl && sectionEl.children.length === 0) {
            const previousOrNextSection = sectionParent.previousElementSibling || sectionParent.nextElementSibling;
            if (previousOrNextSection) {
                const sectionpreviousOrNextWidgetName = previousOrNextSection.getAttribute('widget') || '';
                if (sectionpreviousOrNextWidgetName) {
                    const sectionpreviousOrNextEl = previousOrNextSection.querySelector(sectionpreviousOrNextWidgetName);
                    if (sectionpreviousOrNextEl)
                        sibling = sectionpreviousOrNextEl.children[sectionpreviousOrNextEl.childElementCount - 1];
                }
            }
            sectionParent.remove();
        }
    }
    return sibling;
}
function findIcaParentSibling(icaBase) {
    let parentElement = icaBase.parentElement;
    if (parentElement && !parentElement.tagName.toLocaleLowerCase().startsWith('ica-')) {
        return findIcaParentSibling(parentElement);
    }
    parentElement = parentElement.previousElementSibling;
    if (!parentElement)
        return undefined;
    const tag = parentElement.widget;
    const elPR = parentElement.querySelector(tag);
    if (elPR && elPR.children.length > 1)
        return elPR.children[elPR.children.length - 1];
    else if (parentElement)
        return parentElement;
    return undefined;
}
