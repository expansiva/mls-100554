/// <mls shortName="serviceDsAssetsEditor" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ServiceDsAssetsEditor100554_1;
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
let ServiceDsAssetsEditor100554 = ServiceDsAssetsEditor100554_1 = class ServiceDsAssetsEditor100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.details = {
            icon: '&#xf121',
            state: 'foreground',
            tooltip: 'Assets Editor',
            visible: false,
            position: "right",
            tags: ['ds_assets'],
            widget: '_100554_serviceDsAssetsEditor',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (op === 'opEditor')
                return this.showEditor();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Assets Editor',
            actions: {
                opEditor: 'Editor',
            },
            icons: {},
            actionDefault: 'opEditor', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.msize = '';
        this.editorTypeByExtensions = {
            '.json': 'json',
            '.txt': 'plaintext',
            '.ts': 'typescript',
            '.js': 'javascript',
            '.css': 'css',
            '.less': 'less',
            '.html': 'html',
            '.java': 'java',
            '.scss': 'scss',
            '.xml': 'xml',
        };
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible) {
            this.createEditor();
            this.showEditor2();
            setTimeout(() => {
                if (el && typeof el.layout === 'function')
                    el.layout();
            }, 100);
        }
    }
    setEvents() {
        mls.events.addEventListener([this.level], ['DSAssetsUnSelected'], (ev) => {
            this.onDsAssetsUnSelected(ev);
        });
        mls.events.addEventListener([this.level], ['DSAssetsChanged'], (ev) => {
            this.onDsAssetsChanged(ev);
        });
    }
    createRenderRoot() {
        return this;
    }
    onDsAssetsUnSelected(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.service.includes('_100554_serviceDsAssetsEditor'))
            return;
        this.showNav2Item(false);
    }
    onDsAssetsChanged(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.position === 'right')
            return;
        if (params.info.helper.includes('_100554_serviceDsAssetsEditor')) {
            this.data = params;
            this.showNav2Item(true);
            this.openMe();
        }
        else
            this.showNav2Item(false);
    }
    createEditor() {
        if (!this.c2)
            return;
        if (this._ed1) {
            this.setInitialModels('Loading...', 'textplain');
            this.setMsizeEditor();
            return;
        }
        this._ed1 = monaco.editor.create(this.c2, mls.editor.conf['l3_assets_visualization_editor']);
        this.c2['mlsEditor'] = this._ed1;
        this.setMsizeEditor();
    }
    getUri(shortFN) {
        ServiceDsAssetsEditor100554_1.modelCount = ServiceDsAssetsEditor100554_1.modelCount + 1 || 1;
        return monaco.Uri.parse(`file://server/${shortFN}_${ServiceDsAssetsEditor100554_1.modelCount}.ts`);
    }
    setInitialModels(src, mode) {
        const uri = this.getUri('l3_assets_visualization_editor');
        this.model = monaco.editor.getModel(uri);
        let val = src;
        if (mode === 'json')
            val = JSON.stringify(JSON.parse(src), null, 2);
        if (this.model)
            this.model.setValue(src);
        else
            this.model = monaco.editor.createModel(val, mode, uri);
    }
    setMsizeEditor() {
        if (!this.visible)
            return;
        this.c2?.setAttribute('msize', this.msize);
    }
    showEditor() {
        this.menu.title = 'Editor';
        this.showEditor2();
        return true;
    }
    async showEditor2() {
        const obj = await this.getValue();
        if (!obj || !this._ed1)
            return;
        this.setInitialModels(obj.value, obj.mode);
        this._ed1.setModel(this.model);
        return true;
    }
    async getValue() {
        if (!this.data)
            return;
        if (!this.data.info.filesSelectedArr)
            return undefined;
        const [fileSelected] = this.data.info.filesSelectedArr;
        if (!fileSelected)
            return undefined;
        const { folder, extension, level, project, shortName } = fileSelected;
        const keyFile = mls.stor.getKeyToFiles(project, level, shortName, folder, extension);
        const value = await mls.stor.files[keyFile]?.getContent();
        const mode = this.editorTypeByExtensions[extension] ? this.editorTypeByExtensions[extension] : 'plaintext';
        return new Promise((resolve, reject) => {
            if (typeof value === 'string') {
                resolve({ value, mode });
                return;
            }
            const file = value;
            const reader = new FileReader();
            reader.addEventListener('load', () => {
                resolve({ value: reader.result, mode });
            });
            reader.readAsBinaryString(file);
        });
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            this.setMsizeEditor();
        }
    }
    render() {
        return html `<mls-editor-100529 ismls2="true"></mls-editor-100529>`;
    }
};
__decorate([
    property({ type: String })
], ServiceDsAssetsEditor100554.prototype, "msize", void 0);
__decorate([
    query('mls-editor-100529')
], ServiceDsAssetsEditor100554.prototype, "c2", void 0);
ServiceDsAssetsEditor100554 = ServiceDsAssetsEditor100554_1 = __decorate([
    customElement('service-ds-assets-editor-100554')
], ServiceDsAssetsEditor100554);
export { ServiceDsAssetsEditor100554 };
