/// <mls shortName="pluginOrganismProperty" project="100554" enhancement="_blank" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
/// **collab_i18n_start** 
const message_pt = {
    inDev: 'Em desenvolvimento!',
};
const message_en = {
    inDev: 'In develpoment',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginOrganisAdd = class PluginOrganisAdd extends CollabLitElement {
    render() {
        return html `In development`;
    }
};
PluginOrganisAdd = __decorate([
    customElement('plugin-organism-property-100554')
], PluginOrganisAdd);
export { PluginOrganisAdd };
