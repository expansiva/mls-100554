/// <mls shortName="collabTilesItem" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let CollabTilesItem = class CollabTilesItem extends LitElement {
    constructor() {
        super(...arguments);
        this.position = '';
        this.plugin = '';
    }
    //---------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    render() {
        //let [ row, col ] = this.position.split(' ');
        //this.style.gridColumn =  (col ? col : '1')
        //this.style.gridRow =  (row ? row : '1');
        this.style.gridArea = this.position;
        return html `${unsafeHTML(this.plugin)}`;
    }
};
__decorate([
    property({ type: String, reflect: true })
], CollabTilesItem.prototype, "position", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabTilesItem.prototype, "plugin", void 0);
CollabTilesItem = __decorate([
    customElement('collab-tiles-item-100554')
], CollabTilesItem);
export { CollabTilesItem };
