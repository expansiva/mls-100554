/// <mls shortName="serviceDsStyleTesxtshadow" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabDSInputRange } from './_100554_collabDsInputRange';
import { initCollabDsInputSelectColor } from './_100554_collabDsInputSelectColor';
/// **collab_i18n_start**
const message_pt = {
    textShadow: 'Sombra do texto',
    xOffset: 'X Offset',
    yOffset: 'Y Offset',
    blur: 'Desfoque',
    color: 'Cor',
};
const message_en = {
    textShadow: 'Text Shadow',
    xOffset: 'X Offset',
    yOffset: 'Y Offset',
    blur: 'Blur',
    color: 'Color',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleTextShadow = class ServiceDsStyleTextShadow extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.myUpp = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleTesxtshadow';
        this.details = {
            icon: '&#x54',
            state: 'foreground',
            position: 'right',
            tooltip: 'Text Shadow',
            visible: false,
            tags: ['ds_styles'],
            widget: '_100554_serviceDsStyleTesxtshadow',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Shadow',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //-------------IMPLEMENTS--------------
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        this.arrayGallery = [
            '',
            'text-shadow: 2px 2px;',
            'text-shadow: 2px 2px 5px;',
            'text-shadow: 0 0 3px',
            'text-shadow: 3px 3px 3px;',
            'text-shadow: 3px -3px 3px;'
        ];
        initCollabDSInputRange();
        initCollabDsInputSelectColor();
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    setValues(ar) {
        if (!this.shadowRoot)
            return;
        const textShadowLine = ar.find((item) => item.key === 'text-shadow');
        if (!textShadowLine)
            return;
        this.myUpp = true;
        let { value } = textShadowLine;
        let vColor = '';
        if (value.indexOf('rgb') >= 0) {
            vColor = value.substr(value.indexOf('rgb'), value.indexOf(')') + 1);
            value = value.replace(vColor, '').trim();
        }
        else if (value.indexOf('#') >= 0) {
            vColor = value.substr(value.indexOf('#'), value.indexOf(' ') + 1).trim();
            value = value.replace(vColor, '').trim();
        }
        else if (/[a-z]/.test(value.substr(0, 1))) {
            vColor = value.substr(value.indexOf(value.substr(0, 2)), value.indexOf(' ') + 1).trim();
            value = value.replace(vColor, '').trim();
        }
        const arrayValues = value.split(' ');
        const elX = this.shadowRoot.querySelector('*[prop="x"]');
        const elY = this.shadowRoot.querySelector('*[prop="y"]');
        const elC = this.shadowRoot.querySelector('*[prop="color"]');
        const elB = this.shadowRoot.querySelector('*[prop="blur"]');
        if (elX && arrayValues.length > 0)
            elX.value = arrayValues[0];
        else
            elX.value = '';
        if (elY && arrayValues.length > 1)
            elY.value = arrayValues[1];
        else
            elY.value = '';
        if (elB && arrayValues.length > 2)
            elB.value = arrayValues[2];
        else
            elB.value = '';
        if (elC)
            elC.value = vColor;
        this.myUpp = false;
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `${this.renderColumn()}${this.renderGallery()}`;
    }
    renderColumn() {
        return html `
            <div>
                <h5>${this.msg.textShadow}</h5>
                <div class="groupEdit">
                    <span>${this.msg.xOffset}</span>
                    <collab-ds-input-range-100554 prop="x" value="0px" .arraySelect=${this.tpMeasures}  @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.yOffset}</span>
                    <collab-ds-input-range-100554 prop="y" value="0px" .arraySelect=${this.tpMeasures}  @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.blur}</span>
                    <collab-ds-input-range-100554 prop="blur" value="0px" .arraySelect=${this.tpMeasures}  @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.color}</span>
                    <collab-ds-input-select-color-100554 prop="color" useInput="false" useSelect="false" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-select-color-100554>
                </div>
                
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">
                ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `
                        <h5 style="${css}" @click="${this.clickGallery}" .gallery=${css}>Text</h5>
                        `;
        }))}
            </div>
        
        `;
    }
    onChangeProp(obj) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.mountValue();
        }, 500);
    }
    mountValue() {
        if (!this.shadowRoot)
            return;
        const elX = this.shadowRoot.querySelector('*[prop="x"]');
        const elY = this.shadowRoot.querySelector('*[prop="y"]');
        const elC = this.shadowRoot.querySelector('*[prop="color"]');
        const elB = this.shadowRoot.querySelector('*[prop="blur"]');
        let value = '';
        if (elC)
            value += elC.value;
        if (elX)
            value += ' ' + elX.value;
        if (elY)
            value += ' ' + elY.value;
        if (elB)
            value += ' ' + elB.value;
        const change = {
            key: 'text-shadow',
            value
        };
        this.emitEvent(change);
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
    clickGallery(e) {
        const el = e.target;
        if (!el)
            return;
        const css = el.gallery;
        //if (!css) return;
        const commands = css.split(';');
        const changes = [];
        commands.forEach((item) => {
            const [key, value] = item.split(':');
            if (!key)
                return;
            changes.push({
                key: key.trim(),
                value: value.trim()
            });
        });
        const rc = {
            emitter: 'right',
            value: changes,
            helper: this.helper
        };
        if (changes.length <= 0)
            changes.push({ key: 'text-shadow', value: '' });
        this.setValues(changes);
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
};
ServiceDsStyleTextShadow.styles = css ` :host{padding:1rem;display:block} :host>div{margin-bottom:1rem;border-bottom:1px solid #bcb9b9} input, select, textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none} .groupEdit{display:flex;flex-direction:row;margin-bottom:.5rem} .groupEdit span{width:150px;font-size:90%}`;
__decorate([
    property()
], ServiceDsStyleTextShadow.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleTextShadow.prototype, "helper", void 0);
ServiceDsStyleTextShadow = __decorate([
    customElement('service-ds-style-tesxtshadow-100554')
], ServiceDsStyleTextShadow);
export { ServiceDsStyleTextShadow };
