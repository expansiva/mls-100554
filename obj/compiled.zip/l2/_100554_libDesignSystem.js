/// <mls shortName="libDesignSystem" project="100554" enhancement="_blank" groupName="other" />
import { getConfigProject } from './_100554_libProjectConfig';
const instanceCache = {};
export async function list(project) {
    const config = await getConfigProject(project);
    if (!config)
        return [];
    const ds = config.designSystems || [];
    return ds;
}
export async function getDSInstance(project, dsindex) {
    const instance = await _getDsInstance(project, dsindex);
    return instance;
}
async function _getDsInstance(project, dsindex) {
    const dsProjectList = await list(project);
    const dsInfo = dsProjectList[dsindex];
    if (!dsInfo)
        throw new Error(`Design system: ${dsindex} dont exist in project: ${project}`);
    //const instance: DesignSystemIO = mls.l3['getOrCreateDSInstanceIO'](project, dsindex, dsInfo.widgetIOName);
    const instance = await getOrCreateDSInstanceIO(project, dsindex, '_100554_configDsDefault');
    if (!instance)
        throw new Error('Invalid ds instance!');
    return instance;
}
export async function getOrCreateDSInstanceIO(project, dsindex, widgetIOName) {
    const dskey = getKeyDs(project, dsindex);
    if (!instanceCache[dskey]) {
        const importKey = './' + widgetIOName;
        const dsImport = await import(importKey);
        const instance = new dsImport[widgetIOName](project, dsindex);
        instanceCache[dskey] = instance;
    }
    return instanceCache[dskey];
}
;
function getKeyDs(project, dsindex) {
    const key = `_${project}_${dsindex}`;
    return key;
}
;
