/// <mls shortName="libDesignSystem" project="100554" enhancement="_blank" groupName="other" />
const instanceCache = {};
export async function list(project) {
    const config = await getConfigProject(project);
    const ds = config.designSystems || [];
    return ds;
}
export async function getDSInstance(project, dsindex) {
    const instance = await _getDsInstance(project, dsindex);
    return instance;
}
async function _getDsInstance(project, dsindex) {
    const dsProjectList = await list(project);
    const dsInfo = dsProjectList[dsindex];
    if (!dsInfo)
        throw new Error(`Design system: ${dsindex} dont exist in project: ${project}`);
    //const instance: DesignSystemIO = mls.l3['getOrCreateDSInstanceIO'](project, dsindex, dsInfo.widgetIOName);
    const instance = await getOrCreateDSInstanceIO(project, dsindex, '_100554_configDsDefault');
    if (!instance)
        throw new Error('Invalid ds instance!');
    return instance;
}
async function getConfigProject(project) {
    const shortName = 'project';
    if (project === undefined)
        throw new Error('No project selected!');
    const key = mls.stor.getKeyToFiles(project, 5, shortName, '', '.json');
    let configFile = mls.stor.files[key];
    if (!configFile)
        throw new Error('No config file!');
    const content = await configFile.getContent();
    if (!content || typeof content !== 'string')
        throw new Error('Invalid config file!');
    return JSON.parse(content);
}
export async function getOrCreateDSInstanceIO(project, dsindex, widgetIOName) {
    const dskey = getKeyDs(project, dsindex);
    if (!instanceCache[dskey]) {
        const importKey = './' + widgetIOName;
        const dsImport = await import(importKey);
        const instance = new dsImport[widgetIOName](project, dsindex);
        instanceCache[dskey] = instance;
    }
    return instanceCache[dskey];
}
;
function getKeyDs(project, dsindex) {
    const key = `_${project}_${dsindex}`;
    return key;
}
;
export class DesignSystemIO {
}
export class TokenIO {
    constructor(ds) {
        this._ds = ds;
    }
    ;
}
export class DocIO {
    constructor(ds) {
        this._ds = ds;
    }
}
export class AssetIO {
    constructor(ds) {
        this._ds = ds;
    }
}
export class CssIO {
    constructor(ds) {
        this._ds = ds;
    }
}
export class ComponentIO {
    constructor(ds) {
        this._ds = ds;
    }
}
export class ExampleIO {
    constructor(ds) {
        this._ds = ds;
    }
}
export class StyleIO {
    constructor(ds) {
        this._ds = ds;
    }
}
