/// <mls shortName="beProviderIndexedDB" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { BEIndexedDBBase } from "./_100554_beIndexedDBBase";
import { prismaToFieldTable } from "./_100554_beHelper";
export class BEProviderIndexedDB {
    constructor() {
        this.dbName = "";
        this.tableName = "";
        this.fields = [];
        this.db = new BEIndexedDBBase();
    }
    async ensureTable(dbName, tableName, modelPrisma) {
        this.dbName = dbName;
        this.tableName = tableName;
        this.fields = prismaToFieldTable(modelPrisma);
        this.db.dbName = dbName;
        await this.db.createTable(tableName, this.fields);
    }
    async read(filter, range, sort) {
        const filters = filter
            ? Object.entries(filter).map(([field, value]) => ({ field, value }))
            : [];
        const rows = await this.db.query(this.tableName, filters);
        // Sort and range em memória
        let result = [...rows];
        if (sort) {
            result.sort((a, b) => {
                if (a[sort.field] < b[sort.field])
                    return sort.direction === "asc" ? -1 : 1;
                if (a[sort.field] > b[sort.field])
                    return sort.direction === "asc" ? 1 : -1;
                return 0;
            });
        }
        if (range) {
            result = result.slice(range.start, range.end);
        }
        return result;
    }
    async add(item) {
        // Gera um id fake se não houver (IndexedDB normalmente auto incrementa, mas garanta que seja retornado)
        const newItem = { ...item };
        await this.db.post(this.tableName, newItem);
        // Busca o último registro inserido (ou idealmente pega o id gerado pelo store, mas IndexedDB não retorna direto)
        const all = await this.db.query(this.tableName, []);
        const last = all[all.length - 1];
        return last;
    }
    async update(id, item) {
        const obj = { ...item, id };
        await this.db.put(this.tableName, obj);
        return obj;
    }
    async delete(id) {
        await this.db.delete(this.tableName, [{ field: "id", value: id }]);
    }
}
