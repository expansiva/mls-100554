/// <mls shortName="beIndexedDBBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { DatabaseClient } from './_100554_beDatabaseBase';
export class BEIndexedDBBase extends DatabaseClient {
    constructor() {
        super(...arguments);
        this.dbName = '';
    }
    createTable(tableName, fields) {
        return this._createTable(tableName, fields);
    }
    get(table, key) {
        return this._get(table, key);
    }
    put(table, item) {
        return this._put(table, item);
    }
    post(table, item) {
        return this._post(table, item);
    }
    patch(table, item) {
        return this._put(table, item);
    }
    delete(table, key) {
        return this._delete(table, key);
    }
    query(table, filters) {
        return this._get(table, filters);
    }
    async _createTable(tableName, fields) {
        await this.createDB();
        if (!this.request)
            throw new Error('Not found db');
        this.request.onupgradeneeded = (event) => {
            let db = event.target.result;
            if (db.objectStoreNames.contains(tableName)) {
                return;
            }
            const primary = fields.find((f) => f.primaryKey === true);
            let store;
            if (primary) {
                store = db.createObjectStore(tableName, { keyPath: primary.field, autoIncrement: primary.autoIncrement });
            }
            else {
                store = db.createObjectStore(tableName);
            }
            fields.forEach((f) => {
                if (primary && primary.field === f.field)
                    return;
                store.createIndex(f.field, f.field, { unique: false });
            });
        };
        this.request.onsuccess = () => {
            console.log(`Success update db`);
        };
        this.request.onerror = (event) => {
            console.log(`Erro update db:` + event.target.error);
        };
    }
    async _get(table, key) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            let ret = [];
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let tx = db.transaction(table, "readonly");
                let store = tx.objectStore(table);
                let cursorRequest = store.openCursor();
                cursorRequest.onsuccess = (csEvt) => {
                    let cursor = csEvt.target.result;
                    if (cursor) {
                        let filter = true;
                        key.forEach((f) => {
                            if (!filter)
                                return;
                            if (cursor.value[f.field] !== f.value)
                                filter = false;
                        });
                        if (filter)
                            ret.push({ ...cursor.value });
                        cursor.continue();
                    }
                    else {
                        resolve(ret);
                    }
                };
                cursorRequest.onerror = (errEv) => {
                    reject(errEv.target.error);
                };
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    async _put(table, item) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let transaction = db.transaction(table, "readwrite");
                let store = transaction.objectStore(table);
                let updateRequest = store.put(item);
                updateRequest.onsuccess = () => {
                    resolve();
                };
                updateRequest.onerror = (errEv) => {
                    reject(errEv.target.error);
                };
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    async _post(table, item) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let tx = db.transaction(table, "readwrite");
                let store = tx.objectStore(table);
                store.add(item);
                tx.oncomplete = () => resolve();
                tx.onerror = (erEV) => reject(erEV.target.error);
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    async _delete(table, key) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let tx = db.transaction(table, "readwrite");
                let store = tx.objectStore(table);
                let cursorRequest = store.openCursor();
                cursorRequest.onsuccess = (csEvt) => {
                    let cursor = csEvt.target.result;
                    if (cursor) {
                        let filter = true;
                        key.forEach((f) => {
                            if (!filter)
                                return;
                            if (cursor.value[f.field] !== f.value)
                                filter = false;
                        });
                        if (filter) {
                            cursor.delete();
                            resolve();
                        }
                        ;
                        cursor.continue();
                    }
                    else {
                        resolve();
                    }
                };
                cursorRequest.onerror = (errEv) => {
                    reject(errEv.target.error);
                };
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    async createDB() {
        if (!this.dbName)
            throw new Error('Name db invalid');
        let currentVs = await this.getCurrentVerson();
        if (!currentVs)
            currentVs = 0;
        this.request = indexedDB.open(this.dbName, currentVs + 1);
    }
    async openDB() {
        if (!this.dbName)
            throw new Error('Name db invalid');
        let currentVs = await this.getCurrentVerson();
        this.request = indexedDB.open(this.dbName, currentVs);
    }
    async getCurrentVerson() {
        if (!this.dbName)
            throw new Error('Name db invalid');
        const dbs = await indexedDB.databases();
        const db = dbs.find(i => i.name === this.dbName);
        return db ? db.version : 0; // Retorna 0 se o banco não existir
    }
}
