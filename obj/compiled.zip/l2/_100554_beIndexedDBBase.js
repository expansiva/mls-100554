/// <mls shortName="beIndexedDBBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { DatabaseClient } from './_100554_beDatabaseBase';
export class BEIndexedDBBase extends DatabaseClient {
    constructor() {
        super(...arguments);
        this.dbName = '';
    }
    createTable(tableName, fields) {
        return this._ensureTable(tableName, fields);
    }
    get(table, key) {
        return this._get(table, key);
    }
    put(table, item) {
        return this._put(table, item);
    }
    post(table, item) {
        return this._post(table, item);
    }
    patch(table, item) {
        return this._put(table, item);
    }
    delete(table, key) {
        return this._delete(table, key);
    }
    query(table, filters) {
        return this._get(table, filters);
    }
    async _ensureTable(tableName, fields) {
        console.log("on beIndexedDBBase ensureTable");
        let db = undefined;
        try {
            db = await this.openReadonly();
            const tx = db.transaction(tableName, 'readonly');
            tx.objectStore(tableName);
            db.close();
        }
        catch (err) {
            if (db)
                db.close();
            if (err.name === 'NotFoundError') {
                console.log(`Table '${tableName}' not found, creating...`);
                if (this.request?.result) {
                    try {
                        this.request.result.close();
                        console.log('Closed old DB connection before upgrade');
                    }
                    catch (e) {
                        console.warn('Failed to close old connection', e);
                    }
                }
                await this._createTable(tableName, fields);
                console.log(`Table '${tableName}' created`);
            }
            else {
                throw err;
            }
        }
    }
    openReadonly() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(this.dbName);
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }
    async _createTable(tableName, fields) {
        const currentVersion = await this.getCurrentVersionSafe();
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, currentVersion + 1);
            request.onblocked = () => {
                console.log('_createTable blocked');
            };
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (db.objectStoreNames.contains(tableName))
                    return;
                const primary = fields.find((f) => f.primaryKey === true);
                const store = primary
                    ? db.createObjectStore(tableName, {
                        keyPath: primary.field,
                        autoIncrement: primary.autoIncrement,
                    })
                    : db.createObjectStore(tableName);
                fields.forEach((f) => {
                    if (!primary || f.field !== primary.field) {
                        store.createIndex(f.field, f.field, { unique: false });
                    }
                });
            };
            request.onsuccess = () => {
                console.log(`Success update db`);
                request.result.close();
                resolve();
            };
            request.onerror = () => {
                console.log(`Erro update db:`, request.error);
                reject(request.error);
            };
        });
    }
    async _get(table, key) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            let ret = [];
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let tx = db.transaction(table, "readonly");
                let store = tx.objectStore(table);
                let cursorRequest = store.openCursor();
                cursorRequest.onsuccess = (csEvt) => {
                    let cursor = csEvt.target.result;
                    if (cursor) {
                        let filter = true;
                        key.forEach((f) => {
                            if (!filter)
                                return;
                            if (cursor.value[f.field] !== f.value)
                                filter = false;
                        });
                        if (filter)
                            ret.push({ ...cursor.value });
                        cursor.continue();
                    }
                    else {
                        resolve(ret);
                    }
                };
                cursorRequest.onerror = (errEv) => {
                    reject(errEv.target.error);
                };
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    async _put(table, item) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let transaction = db.transaction(table, "readwrite");
                let store = transaction.objectStore(table);
                let updateRequest = store.put(item);
                updateRequest.onsuccess = () => {
                    resolve();
                };
                updateRequest.onerror = (errEv) => {
                    reject(errEv.target.error);
                };
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    async _post(table, item) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let tx = db.transaction(table, "readwrite");
                let store = tx.objectStore(table);
                store.add(item);
                tx.oncomplete = () => resolve();
                tx.onerror = (erEV) => reject(erEV.target.error);
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    async _delete(table, key) {
        return new Promise(async (resolve, reject) => {
            await this.openDB();
            if (!this.request)
                throw new Error('Not found db');
            this.request.onsuccess = (event) => {
                let db = event.target.result;
                let tx = db.transaction(table, "readwrite");
                let store = tx.objectStore(table);
                let cursorRequest = store.openCursor();
                cursorRequest.onsuccess = (csEvt) => {
                    let cursor = csEvt.target.result;
                    if (cursor) {
                        let filter = true;
                        key.forEach((f) => {
                            if (!filter)
                                return;
                            if (cursor.value[f.field] !== f.value)
                                filter = false;
                        });
                        if (filter) {
                            cursor.delete();
                            resolve();
                        }
                        ;
                        cursor.continue();
                    }
                    else {
                        resolve();
                    }
                };
                cursorRequest.onerror = (errEv) => {
                    reject(errEv.target.error);
                };
            };
            this.request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    /**
     * createDB or open
     */
    async createDB(version) {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, version);
            request.onsuccess = () => {
                resolve(request);
            };
            request.onerror = () => {
                reject(request.error);
            };
        });
    }
    async openDB() {
        if (!this.dbName)
            throw new Error('Name db invalid');
        let currentVs = await this.getCurrentVerson();
        this.request = indexedDB.open(this.dbName, currentVs);
    }
    async getCurrentVerson() {
        if (!this.dbName)
            throw new Error('Name db invalid');
        const dbs = await indexedDB.databases();
        const db = dbs.find(i => i.name === this.dbName);
        return db ? db.version || 0 : 0;
    }
    async getCurrentVersionSafe() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(this.dbName);
            req.onsuccess = () => {
                const db = req.result;
                const version = db.version;
                db.close();
                resolve(version);
            };
            req.onerror = () => reject(req.error);
        });
    }
}
