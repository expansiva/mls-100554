/// <mls shortName="collabIcaConfigAttributes" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
export const initCollabICATree = '';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item ICA foi encontrado!'
};
const message_en = {
    noItens: 'No ICA items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabICAAttributes = class CollabICAAttributes extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.myAttributes = [];
    }
    //--------------COMPONENT---------------
    createRenderRoot() {
        return this;
    }
    shouldUpdate(changedProperties) {
        super.shouldUpdate(changedProperties);
        this.setServicePreview();
        return true;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.getMyAttributes();
        if (this.myAttributes && this.myAttributes.length > 0)
            return this.createItens();
        return html `<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
    }
    createItens() {
        const obj = html `
            <ul>
                ${repeat(this.myAttributes, ((key, idx) => key.key + idx), ((item, index) => {
            return this.renderItem(item, index);
        }))}
            </ul>
        `;
        return obj;
    }
    renderItem(item, idx) {
        return html `
            <li>
                <span>${item.key}</span>
                <input type="text" value="${item.value}"></input>
            </li>
        `;
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.requestUpdate();
    }
    setServicePreview() {
        if (this.servicePreview || !this.myParent)
            return;
        const nav3 = this.myParent.nav3Service;
        if (!nav3)
            return;
        const wc = nav3.getActiveInstance('right');
        if (!wc)
            return;
        if (wc.tagName.toLowerCase() === 'service-preview-100554') {
            this.servicePreview = wc;
        }
    }
    getMyAttributes() {
        this.myAttributes = [];
        if (!this.servicePreview || !this.servicePreview.serviceContent)
            return;
        const pvv = this.servicePreview.serviceContent.querySelector('service-preview-view-100554');
        if (!pvv || !pvv.shadowRoot)
            return;
        const iframe = pvv.shadowRoot.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        const wcd = iframe.contentDocument.body.querySelector('wcd-toolbox-100554');
        if (!wcd)
            return;
        const parent = wcd.parentElement;
        if (!parent || !parent.info)
            return;
        const attrs = parent.info.element.getAtributtes();
        const ret = [];
        attrs.forEach((i) => {
            ret.push({
                key: i,
                value: parent.info.element.getAttribute(i)
            });
        });
        this.myAttributes = ret;
    }
};
CollabICAAttributes = __decorate([
    customElement('collab-ica-config-attributes-100554')
], CollabICAAttributes);
export { CollabICAAttributes };
