var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="serviceDsAssetsImage" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
import { html, css } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
let ServiceDsAssetsImage100554 = class ServiceDsAssetsImage100554 extends ServiceBase {
    constructor() {
        super();
        this.details = {
            icon: '&#xf03e',
            state: 'foreground',
            tooltip: 'Assets Image',
            visible: false,
            position: "right",
            tags: ['ds_assets'],
            widget: '_100554_serviceDsAssetsImage',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (op === 'opHelper')
                return this.showInitial();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Assets Image',
            actions: {
                opHelper: 'Assets Image',
            },
            icons: {},
            actionDefault: 'opHelper', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible) {
            this.setImage();
            if (el && typeof el.layout === 'function')
                el.layout();
        }
    }
    setEvents() {
        mls.events.addEventListener([this.level], ['DSAssetsUnSelected'], (ev) => {
            this.onDsAssetsUnSelected(ev);
        });
        mls.events.addEventListener([this.level], ['DSAssetsChanged'], (ev) => {
            this.onDsAssetsChanged(ev);
        });
    }
    onDsAssetsUnSelected(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.service.includes('_100554_serviceDsAssetsImage'))
            return;
        this.showNav2Item(false);
    }
    onDsAssetsChanged(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.position === 'right')
            return;
        if (params.info.helper.includes('_100554_serviceDsAssetsImage')) {
            this.data = params;
            this.showNav2Item(true);
            this.openMe();
        }
        else
            this.showNav2Item(false);
    }
    showInitial() {
        this.menu.title = 'Assets Image';
        this.setImage();
        return true;
    }
    async setImage() {
        if (!this.data)
            return;
        if (!this.data.info.filesSelectedArr)
            return undefined;
        console.info(Array.from(this.data.info.filesSelectedArr));
        const [fileSelected] = this.data.info.filesSelectedArr;
        if (!fileSelected)
            return undefined;
        const { folder, extension, level, project, shortName } = fileSelected;
        const keyFile = mls.stor.getKeyToFiles(project, level, shortName, folder, extension);
        const value = await mls.stor.files[keyFile]?.getContent();
        const file = value;
        const reader = new FileReader();
        if (!file)
            return;
        reader.addEventListener('load', () => {
            const base64String = btoa(reader.result);
            const base64Full = `data:${file.type};base64,${base64String}`;
            if (this.imageEl)
                this.imageEl.src = base64Full;
        });
        reader.readAsBinaryString(file);
    }
    render() {
        return html `
        <div class="service_assets_image">
            <div class="zoom-outer">
                <div class="zoom">
                    <img id="serviceassetsimage_img">
                </div>
            </div>
        </div>`;
    }
};
ServiceDsAssetsImage100554.styles = css ` .service_assets_image{padding:2rem} .service_assets_image .zoom{display:flex;justify-content:center;align-items:center} .service_assets_image .zoom img{height:auto}`;
__decorate([
    query('#serviceassetsimage_img')
], ServiceDsAssetsImage100554.prototype, "imageEl", void 0);
ServiceDsAssetsImage100554 = __decorate([
    customElement('service-ds-assets-image-100554')
], ServiceDsAssetsImage100554);
export { ServiceDsAssetsImage100554 };
