/// <mls shortName="pluginStyleBoxShadow" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { propertyDataSource } from './_100554_collabDecorators';
import { globalState } from './_100554_collabState';
import { getMessageKey } from './_100554_collabLitElement';
import { convertColorToHex } from './_100554_libCommom';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    advanced: 'Avançado',
    offSetX: 'X Offset',
    offSetY: 'Y Offset',
    blur: 'Blur ',
    spread: 'Spread',
    color: 'Cor',
    description: 'Um plugin intuitivo para gerenciar e personalizar sombras em elementos com box-shadow. Ajuste cores, deslocamento, desfoque, expansão e modo (inset/outset) de maneira simples e eficaz. Ideal para criar interfaces visuais modernas e estilosas.'
};
const message_en = {
    advanced: 'Advanced',
    offSetX: 'X Offset',
    offSetY: 'Y Offset',
    blur: 'Blur ',
    spread: 'Spread',
    color: 'Color',
    description: 'An intuitive plugin to manage and customize shadows on elements using box-shadow. Easily adjust color, offset, blur, spread, and mode (inset/outset). Perfect for crafting modern and stylish visual interfaces.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['box-shadow'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleBoxShadow = class PluginStyleBoxShadow extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-box-shadow-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-box-shadow-100554 details summary{cursor:pointer}plugin-style-box-shadow-100554 details>div{margin-left:var(--space-16)}plugin-style-box-shadow-100554 .group{margin-top:var(--space-8);display:flex;flex-direction:column;font-size:var(--font-size-12)}plugin-style-box-shadow-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-box-shadow-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-box-shadow-100554 .gallery{margin-bottom:var(--space-16);display:flex;justify-content:start;align-items:center;gap:3rem;padding:1rem;flex-wrap:wrap}plugin-style-box-shadow-100554 .gallery .gallery-item{width:30px;height:20px;cursor:pointer}`);
        this.showFull = 'true';
        this.position = 'left';
        this.shadowMode = 'outset';
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.msg = messages['en'];
        this.timeonChangeProp = -1;
        this.gallery = [
            {
                state: { boxShadow: '0 10px 10px -5px;' },
                style: 'box-shadow: 0 10px 10px -5px;'
            },
            {
                state: { boxShadow: '0 0 10px 5px' },
                style: 'box-shadow: 0 0 10px 5px;'
            },
            {
                state: { boxShadow: '5px 5px 20px' },
                style: 'box-shadow: 5px 5px 20px;'
            },
            {
                state: { boxShadow: '5px -5px' },
                style: 'box-shadow: 5px -5px;'
            },
            {
                state: { boxShadow: '5px 5px' },
                style: 'box-shadow: 5px 5px;'
            },
            {
                state: { boxShadow: '-5px -5px 10px' },
                style: 'box-shadow: -5px -5px 10px;'
            },
            {
                state: { boxShadow: '5px 5px 10px' },
                style: 'box-shadow: 5px 5px 10px;'
            },
            {
                state: { boxShadow: 'inset 0 0 10px' },
                style: 'box-shadow: inset 0 0 10px;'
            },
            {
                state: { boxShadow: '0 0 10px' },
                style: 'box-shadow: 0 0 10px;'
            },
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!_value.selector || !_value.lessCSS || !_value.lessCSS.lessAST || !_value.lessCSS.lessAST.ast[_value.selector])
            return;
        const actualAst = _value.lessCSS.lessAST.ast[_value.selector];
        if (!actualAst)
            return;
        let hasRuleBoxInAST = false;
        Object.keys(actualAst).forEach((prop) => {
            if (tags.includes(prop))
                hasRuleBoxInAST = true;
        });
        this.clear();
        if (hasRuleBoxInAST) {
            this._onIcaStateChange();
        }
    }
    clear() {
        this.boxShadow = undefined;
        this.color = undefined;
        this.spread = undefined;
        this.boxBlur = undefined;
        this.offsetY = undefined;
        this.offsetX = undefined;
        this.shadowMode = 'outset';
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    setValues2() {
        let value = this.boxShadow || '';
        if (!value)
            return;
        let vColor = '';
        if (value.indexOf('rgb') >= 0) {
            vColor = value.substring(value.indexOf('rgb'), value.indexOf(')') + 1);
            value = value.replace(vColor, '').trim();
        }
        else if (value.indexOf('#') >= 0) {
            vColor = value.substring(value.indexOf('#'), value.indexOf(' ') + 1).trim();
            value = value.replace(vColor, '').trim();
        }
        else if (/[a-z]/.test(value.substring(0, 1))) {
            vColor = value.substring(value.indexOf(value.substring(0, 2)), value.indexOf(' ') + 1).trim();
            value = value.replace(vColor, '').trim();
        }
        const arrayValues = value.split(' ');
        this.offsetX = arrayValues.length > 0 ? arrayValues[0] : '';
        this.offsetY = arrayValues.length > 1 ? arrayValues[1] : '';
        this.boxBlur = arrayValues.length > 2 ? arrayValues[2] : '';
        this.spread = arrayValues.length > 3 ? arrayValues[3] : '';
        this.color = vColor;
        if (value.indexOf('inset') >= 0)
            this.shadowMode = 'inset';
    }
    setValues(rule) {
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (propertyName === 'box-shadow') {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                }
            }
        }
        this.setValues2();
    }
    mountValue() {
        let value = '';
        value += this.offsetX ? this.offsetX : '0px';
        value += this.offsetY ? ' ' + this.offsetY : ' 0px';
        value += this.boxBlur ? ' ' + this.boxBlur : ' 0px';
        value += this.spread ? ' ' + this.spread : ' 0px';
        value += this.color ? ' ' + this.color : '';
        value += this.shadowMode ? this.shadowMode === 'outset' ? '' : ' ' + this.shadowMode : '';
        if (!this.offsetX || !this.offsetY)
            value = '';
        this.boxShadow = value;
        this.setState();
    }
    setState() {
        globalState._ica.less[this.position].emitter = 'helper';
        const styles = globalState._ica.less[this.position].lessCSS.styles;
        styles.boxShadow = this.boxShadow || '';
    }
    handleChange(e) {
        clearTimeout(this.timeonChangeProp);
        const el = e.detail ? e.detail.target : e.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        this.timeonChangeProp = setTimeout(() => {
            this[prop] = el.value;
            this.mountValue();
        }, 100);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.showFull === 'true' ?
            html `
                    ${this.renderGallery()}
                    ${this.renderBoxShadow()}

                ` :
            html `
                    ${this.renderGallery()}
                `}
        `;
    }
    renderBoxShadow() {
        return html `
            <div class="group">
                <div class="group-edit">
                    <input type="radio" prop="shadowMode" ?checked=${this.shadowMode === 'outset'} id="outset" name="rgHcTypeBoxShadow" value="outset" @change=${this.handleChange}>
                    <label for="outset" >outset</label>
                    <input type="radio" prop="shadowMode" ?checked=${this.shadowMode === 'inset'} id="inset" name="rgHcTypeBoxShadow" value="inset" @change=${this.handleChange}>
                    <label for="inset" >inset</label>
                </div>
                <span>${this.msg.offSetX}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554
                    @onchange=${this.handleChange} 
                    prop="offsetX"
                    value=${this.offsetX} 
                    .arraySelect=${this.tpMeasures}  
                    ></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.offSetY}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554
                    @onchange=${this.handleChange} 
                    prop="offsetY"
                    value=${this.offsetY} 
                    .arraySelect=${this.tpMeasures}  
                    ></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.blur}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554
                    @onchange=${this.handleChange} 
                    prop="boxBlur"
                    value=${this.boxBlur} 
                    .arraySelect=${this.tpMeasures}  
                    ></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.spread}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554
                    @onchange=${this.handleChange} 
                    prop="spread"
                    value=${this.spread} 
                    .arraySelect=${this.tpMeasures}  
                    ></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.color}</span>
                <div class="group-edit">
                    <collab-ds-input-select-color-100554 
                        prop="color" 
                        useInput="false"
                        useSelect="false" 
                        _valueColor=${convertColorToHex(this.color || '')}
                        @onchange=${this.handleChange}
                    ></collab-ds-input-select-color-100554>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `<div class="gallery-item" style="${galleryItem.style}" @click=${() => { this.onGalleryClick(galleryItem); }}></div>`;
        }))}
            </div>
        
        `;
    }
    async onGalleryClick(item) {
        this.boxShadow = item.state.boxShadow;
        this.setValues2();
        await this.updateComplete;
        this.setState();
    }
};
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "showFull", void 0);
__decorate([
    propertyDataSource()
], PluginStyleBoxShadow.prototype, "state", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "position", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "boxShadow", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "color", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "spread", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "boxBlur", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "offsetY", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "offsetX", void 0);
__decorate([
    property()
], PluginStyleBoxShadow.prototype, "shadowMode", void 0);
PluginStyleBoxShadow = __decorate([
    customElement('plugin-style-box-shadow-100554')
], PluginStyleBoxShadow);
export { PluginStyleBoxShadow };
