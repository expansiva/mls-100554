/// <mls shortName="wcdToolboxItemActionEvents" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { unsafeHTML } from 'lit';
import { customElement, query, property } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
import { initCollabSelectOneWithDescription } from './_100554_collabSelectOneWithDescription';
//version 4
let WcdToolboxItemActionEvents = class WcdToolboxItemActionEvents extends WcdToolboxItemBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        const a = initCollabSelectOneWithDescription;
    }
    //-----------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        this.getEvents();
    }
    render() {
        this.title = 'Events';
        return unsafeHTML(`<collab-select-one-with-description-100554></collab-select-one-with-description-100554>`);
    }
    //--------IMPLEMENTATION-------------
    getEvents() {
        if (this.elICA && this.elICA.id && this.elICA.getMyEvents && this.elICA.getDefinitionFromEvent) {
            const events = this.elICA.getMyEvents();
            const opt = [];
            events.split(',').forEach((ev) => {
                const info = {
                    key: ev.trim(),
                    value: ev.trim(),
                    description: this.elICA?.getDefinitionFromEvent(ev.trim()) || ''
                };
                opt.push(info);
            });
            this.options = opt;
        }
        else if (this.elICA && !this.elICA.id) {
            const opt = [];
            opt.push({
                key: 'id',
                value: 'id',
                description: 'Please set id in element for create events'
            });
            this.options = opt;
        }
        if (this.elEvents) {
            this.elEvents.options = this.options;
            this.elEvents.addEventListener('select-change', (e) => {
                this.selectItem(e.detail);
            });
        }
    }
    selectItem(event) {
        if (!this.elICA || (this.elICA && this.elICA.level !== '2'))
            return;
        mls.events.fire(2, 'WidgetAction', `{"op":"OpenScenario", "widget":"_100554_scenarioInsertEventOrChange", "value":"${event}", "id":"${this.elICA.id}"}`);
    }
};
__decorate([
    query('collab-select-one-with-description-100554')
], WcdToolboxItemActionEvents.prototype, "elEvents", void 0);
__decorate([
    property({ reflect: true })
], WcdToolboxItemActionEvents.prototype, "options", void 0);
WcdToolboxItemActionEvents = __decorate([
    customElement('wcd-toolbox-item-action-events-100554')
], WcdToolboxItemActionEvents);
export { WcdToolboxItemActionEvents };
