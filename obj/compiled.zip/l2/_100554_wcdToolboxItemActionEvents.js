/// <mls shortName="wcdToolboxItemActionEvents" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { initCollabSelectOneWithDescription } from './_100554_collabSelectOneWithDescription';
//version 4
export const getTemplate = (mode = '', position = '') => {
    let ret = templateActionEvents.event;
    if (position !== '')
        ret.position = position;
    const a = initCollabSelectOneWithDescription;
    return ret;
};
const templateActionEvents = {
    event: {
        position: 'p-r1',
        tp: 'event',
        format: '',
        title: '',
        iconSvg: '',
        onclick: (e, wc) => {
            debugger;
            if (wc.level === '2') {
                const overlayItem = wc.parentElement;
                if (!overlayItem)
                    return;
                const elIca = overlayItem.info?.element;
                if (!elIca || !elIca.id)
                    return;
                mls.events.fire(2, 'WidgetAction', `{"op":"OpenScenario", "widget":"_100554_scenarioInsertEventOrChange", "value":"${e.detail}", "id":"${elIca.id}"}`);
            }
        },
        menuItens: [],
        menuSubItens: [],
        widget: 'collab-select-one-with-description-100554',
        cursor: 'pointer',
        attrs: undefined,
        isDblClick: false
    }
};
