/// <mls shortName="icaLitElementBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { convertFileNameToTag, convertTagToFileName } from './_100554_utilsLit';
import * as globalIca from './_100554_icaGlobal';
export class IcaLitElementBase extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.id = '';
        this.styleel = '';
        this.internalInnerHTML = '';
        this.lastWidget = '';
        this.styleElMain = undefined;
        this.excludesProps = ['rendertype', 'level', 'widget', 'style', 'styleel', 'id', globalIca.ATTRGROUP];
    }
    //--------COMPONENT-----------------
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        this.setInitialConfigs();
    }
    attributeChangedCallback(name, oldValue, newValue) {
        super.attributeChangedCallback(name, oldValue, newValue);
        if (!this.excludesProps.includes(name) && oldValue !== newValue && newValue) {
            this.updateAttrInWc(name, newValue);
        }
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        const tempeEl = document.createElement('span');
        tempeEl.style.cssText = this.styleel ? this.styleel : '';
        this.styleElMain = tempeEl.style;
        await this.performPreSlotAllocationOperations();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        const hasLevel = changedProperties.has('level');
        const hasStyleEl = changedProperties.has('styleel');
        if (this.widget && this.lastWidget !== this.widget) {
            this.lastWidget = this.widget;
            customElements.whenDefined(this.lastWidget).then(() => {
                this.updateStyleDisplay();
            });
        }
        if (hasLevel) {
            const valLevel = changedProperties.get('level');
            if (this.level === valLevel)
                return;
            this.updateLevelIcas();
        }
        if (hasStyleEl) {
            const valStyleEl = changedProperties.get('styleel');
            if (this.styleel === valStyleEl)
                return;
            this.updateStyleEl();
        }
    }
    render() {
        this.style.display = 'block';
        if (!this.style.width)
            this.style.width = 'inherit';
        if (!this.style.height)
            this.style.height = 'inherit';
        const attrs = this.getAttributes();
        let code = `
            <${this.widget} ${attrs}>
            </${this.widget}>
        `;
        return html `${unsafeHTML(code)}`;
    }
    //---------IMPLEMENTATION-------------
    changeStateStyle(style) {
        if (!this.styleElMain || !style)
            return;
        const el = this.querySelector(`${this.widget}:first-child`);
        if (el) {
            this.styleElMain.cssText = el.style.cssText;
            Object.assign(this.styleElMain, style);
            el.style.cssText = this.styleElMain.cssText;
            this.styleel = el.style.cssText;
        }
    }
    updateStyleEl() {
        if (!this.widget)
            return;
        const widgetEl = this.querySelector(this.widget);
        if (!widgetEl)
            return;
        widgetEl.style.cssText = this.styleel || '';
    }
    updateLevelIcas() {
        if (!this.level)
            return;
        const traverseShadowRoot = (element) => {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                element.setAttribute('level', this.level);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    if (item.tagName.toLowerCase().startsWith('ica')) {
                        item.setAttribute('level', this.level);
                    }
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => {
                        if (child.tagName.toLowerCase().startsWith('ica')) {
                            child.setAttribute('level', this.level);
                        }
                    });
                }
            }
        };
        if (!this.widget)
            return;
        const widgetEl = this.querySelector(this.widget);
        if (!widgetEl)
            return;
        traverseShadowRoot(widgetEl);
    }
    updateAttrInWc(prop, value) {
        const el = this.querySelector(this.widget);
        if (el)
            el.setAttribute(prop, value);
    }
    updateStyleDisplay() {
        const el = this.querySelector(this.widget);
        if (el) {
            const d = window.getComputedStyle(el);
            this.style.display = d.display;
        }
    }
    doChangeState(js) {
        const info = JSON.parse(js);
        switch (info.tp) {
            case "menu":
                // console.info(info.menu);
                break;
            case "style":
                this.changeStateStyle(info.style);
                break;
            case "html":
                this.changeStateHtml(info.html);
                break;
            default:
                '';
                break;
        }
        //mls.events.fire((+(this.level as any)) as any, 'WCDEventChange' as any, `{"op":"Navigation"}`);
    }
    getICAComponents(scope) {
        let ret = [];
        const reentrance = (el) => {
            const tag = el.tagName.toLowerCase();
            if (tag.startsWith(`${globalIca.PREFIX}-`)) {
                ret.push(el);
            }
            const isGroup = el.getAttribute(`${globalIca.ATTRGROUP}`);
            if (!isGroup || isGroup === 'false') {
                Array.from(el.children).forEach(i => {
                    reentrance(i);
                });
            }
        };
        Array.from(scope.children).forEach(i => {
            reentrance(i);
        });
        return ret;
    }
    getMyScope() {
        let ret = this.closest(`${globalIca.ICAPAGE}`);
        if (!ret)
            ret = this.closest('body');
        return ret;
    }
    getIcaParent(target) {
        const parent = target.parentElement;
        if (!parent)
            return;
        const tag = parent.tagName.toLowerCase();
        if (!tag.startsWith(`${globalIca.PREFIX}-`))
            return this.getIcaParent(parent);
        else if (tag.startsWith(`${globalIca.PREFIX}-`))
            return parent;
    }
    async performPreSlotAllocationOperations() {
        if (!this.widget)
            return;
        const tag = convertFileNameToTag(this.widget);
        if (tag.startsWith(globalIca.PREFIX) || tag.startsWith(globalIca.PREFIXWCD))
            return;
        Promise.all([tag].map((wc) => customElements.whenDefined(wc))).then(async () => {
            let childrens = Array.from(this.children).filter((child) => child.tagName !== tag.toUpperCase());
            const widgetElement = this.querySelector(tag);
            if (!widgetElement || !childrens || childrens.length === 0)
                return;
            childrens.forEach((child) => {
                if (child.tagName.toLowerCase().startsWith(globalIca.PREFIXWCD))
                    return;
                child.remove();
                widgetElement.appendChild(child);
            });
            const slots = widgetElement.shadowRoot ?
                Array.from(widgetElement.shadowRoot.querySelectorAll(`slot`)) :
                Array.from(widgetElement.querySelectorAll(`slot`));
            if (!slots || slots.length === 0)
                return;
            const slotWithoutName = slots.find((slot) => !slot.getAttribute('name'));
            childrens.forEach(element => {
                const elementSlotName = element.getAttribute('slot');
                if (elementSlotName) {
                    const slotByName = slots.find((slot) => slot.getAttribute('name') === elementSlotName);
                    if (slotByName)
                        slotByName.parentNode?.insertBefore(element, slotByName);
                }
                else if (slotWithoutName) {
                    slotWithoutName.parentNode?.insertBefore(element, slotWithoutName);
                }
            });
            slots.forEach((sl) => sl.remove());
        });
    }
    async setInitialConfigs() {
        if (this.widget) {
            const fileName = convertTagToFileName(this.widget);
            await import('./' + fileName);
        }
    }
    getAttributes() {
        const language = this.closest('html')?.lang || 'en';
        const attributes = [];
        const attributeNames = this.getAttributeNames();
        for (let attrName of attributeNames) {
            if (this.excludesProps.includes(attrName))
                continue;
            let attrValue = this.getAttribute(attrName);
            if (attrName === 'idel')
                attrName = 'id';
            if (attrValue !== null) {
                attributes.push({
                    name: attrName,
                    value: attrValue
                });
            }
        }
        const attrsByVariation = this.filterAttributes(attributes, language);
        let attributesStr = '';
        attrsByVariation.forEach((item) => attributesStr += `${item.name}="${item.value}"`);
        return attributesStr;
    }
    filterAttributes(attributes, variation) {
        const variationSuffix = `-${variation.toLowerCase()}`; // -en
        const variationAttributes = attributes.filter(attr => attr.name.endsWith(variationSuffix));
        const nonVariationAttributes = attributes.filter(attr => {
            if (attr.name.includes('-') && attr.name.endsWith(variationSuffix))
                return false;
            const split = attr.name.split('-');
            if (split.length > 1)
                split.pop();
            const attrBase = split.join('-');
            return !attributes.some(a => a.name.startsWith(attrBase) && a !== attr && variationAttributes.includes(a));
        });
        let aux = [...nonVariationAttributes, ...variationAttributes];
        aux.forEach(attr => {
            const split = attr.name.split('-');
            if (split.length > 0) {
                const language = split.pop();
                if (language === variation)
                    attr.name = split.join('-');
            }
        });
        return aux;
    }
}
__decorate([
    property({ type: String, reflect: true })
], IcaLitElementBase.prototype, "widget", void 0);
__decorate([
    property({ type: String, reflect: true })
], IcaLitElementBase.prototype, "id", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], IcaLitElementBase.prototype, "isICAGroup", void 0);
__decorate([
    property({ type: String })
], IcaLitElementBase.prototype, "renderType", void 0);
__decorate([
    property({ type: String })
], IcaLitElementBase.prototype, "level", void 0);
__decorate([
    property({ type: String })
], IcaLitElementBase.prototype, "styleel", void 0);
