/// <mls shortName="pageTest1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState } from './_100554_icaState';
import { initTestState, adicionarSolicitacao } from './_100554_testPagesState';
let PageTest1100554 = class PageTest1100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        initTestState();
        initState('projectTest.page1', {
            newRequest: {
                id: 0,
                solicitante: '',
                item: 'Computadores e notebooks',
                quantidade: 1,
                data: new Date().toISOString().split('T')[0],
                status: 'Pendente',
                depto: 'Tecnologia da Informação',
                justificativa: '',
            }
        });
    }
    clear() {
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.id', 0);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.solicitante', '');
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.item', 'Computadores e notebooks');
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.quantidade', 1);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.data', new Date().toISOString().split('T')[0]);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.status', 'Pendente');
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.depto', 'Tecnologia da Informação');
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.justificativa', '');
    }
    /// **collab_events_start**
    async handleClickBtnSave(e) {
        const novaSolicitacao = globalState._ica.projectTest.page1.newRequest;
        adicionarSolicitacao(novaSolicitacao);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest', {
            id: 0,
            solicitante: '',
            item: 'Computadores e notebooks',
            quantidade: 0,
            data: new Date().toISOString().split('T')[0],
            status: 'Pendente',
            depto: 'Tecnologia da Informação',
            justificativa: '',
        });
        this.clear();
    }
    async handleClickBtnCancel(e) {
        this.clear();
    }
};
PageTest1100554 = __decorate([
    customElement('page-test1-100554')
], PageTest1100554);
export { PageTest1100554 };
