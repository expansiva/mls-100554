/// <mls shortName="pageTest1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState } from './_100554_icaState';
import { initTestState, adicionarSolicitacao } from './_100554_testPagesState';
let PageTest1100554 = class PageTest1100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        initTestState();
        initState('projectTest.page1', {
            saving: false,
            canceling: false,
            newRequest: {
                id: 0,
                solicitante: '',
                item: 'Computadores e notebooks',
                quantidade: 1,
                data: new Date().toISOString().split('T')[0],
                status: 'Pendente',
                depto: 'Tecnologia da Informação',
                justificativa: '',
            }
        });
        globalState.globalStateManagment.subscribe([
            'state/0;projectTest.page1.saving',
            'state/0;projectTest.page1.canceling',
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'projectTest.page1.saving' && _value === true) {
            this.handleClickBtnSave();
        }
        else if (_key === 'projectTest.page1.canceling' && _value == true) {
            this.handleClickBtnCancel();
        }
    }
    clear() {
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.id', 0, true);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.solicitante', '', true);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.item', 'Computadores e notebooks', true);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.quantidade', '1', true);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.data', new Date().toISOString().split('T')[0], true);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.status', 'Pendente', true);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.depto', 'Tecnologia da Informação', true);
        globalState.globalStateManagment.setState('projectTest.page1.newRequest.justificativa', '', true);
    }
    async handleClickBtnSave() {
        const novaSolicitacao = globalState._ica.projectTest.page1.newRequest;
        adicionarSolicitacao(novaSolicitacao);
        this.clear();
        globalState.globalStateManagment.setState('projectTest.page1.saving', false, true);
    }
    async handleClickBtnCancel() {
        this.clear();
        globalState.globalStateManagment.setState('projectTest.page1.canceling', false, true);
    }
};
PageTest1100554 = __decorate([
    customElement('page-test1-100554')
], PageTest1100554);
export { PageTest1100554 };
