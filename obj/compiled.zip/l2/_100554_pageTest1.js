/// <mls shortName="pageTest1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { initState } from './_100554_icaState';
let PageTest1100554 = class PageTest1100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        initState('tables.depto', [
            { key: 'Tecnologia da Informação (TI)', value: 'TI' },
            { key: 'Administração', value: 'Admin' },
            { key: 'Contabilidade', value: 'Cont' },
            { key: 'Recursos Humanos (RH)', value: 'RH' },
        ]);
        initState('tables.products', [
            {
                "key": "Computadores e notebooks",
                "value": "Computadores e notebooks",
                "category": "Tecnologia",
                "description": "Equipamentos para uso pessoal e profissional, incluindo desktops, laptops e workstations."
            },
            {
                "key": "Impressoras",
                "value": "Impressoras",
                "category": "Escritório",
                "description": "Impressoras a laser, jato de tinta e térmicas para diversos tipos de impressão."
            },
            {
                "key": "Cadeira",
                "value": "Cadeira",
                "category": "Móveis",
                "description": "Cadeiras ergonômicas e convencionais para escritórios e residências."
            },
            {
                "key": "Mouse",
                "value": "Mouse",
                "category": "Periféricos",
                "description": "Dispositivos apontadores para computadores, incluindo mouses com e sem fio."
            },
            {
                "key": "Teclado",
                "value": "Teclado",
                "category": "Periféricos",
                "description": "Teclados mecânicos e de membrana para escritórios e gamers."
            },
            {
                "key": "Monitor",
                "value": "Monitor",
                "category": "Tecnologia",
                "description": "Monitores de diversos tamanhos e resoluções para uso profissional e doméstico."
            },
            {
                "key": "Mesa para escritório",
                "value": "Mesa para escritório",
                "category": "Móveis",
                "description": "Mesas de trabalho com diferentes tamanhos e materiais."
            },
            {
                "key": "Fones de ouvido",
                "value": "Fones de ouvido",
                "category": "Periféricos",
                "description": "Headsets com e sem fio para comunicação e entretenimento."
            },
        ]);
    }
    /// **collab_events_start**
    async handleClickbtnSave(e) {
        console.info('click save');
    }
};
PageTest1100554 = __decorate([
    customElement('page-test1-100554')
], PageTest1100554);
export { PageTest1100554 };
