/// <mls shortName="pluginTaskPreviewFlexible" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let pluginTaskPreviewFlexible = class pluginTaskPreviewFlexible extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-task-preview-flexible-100554{display:block;background:#ffffff;position:relative;height:100%;color:#3c3c3c}plugin-task-preview-flexible-100554 .tab-header{display:flex;justify-content:space-between;border-bottom:1px solid #ccc;background-color:#f0f0f0;overflow:hidden;flex-shrink:0}plugin-task-preview-flexible-100554 .tab-group-left{display:flex;overflow-x:auto;flex:1;min-width:0;scrollbar-width:thin}plugin-task-preview-flexible-100554 .tab-group-left::-webkit-scrollbar{height:6px}plugin-task-preview-flexible-100554 .tab-group-left::-webkit-scrollbar-thumb{background-color:var(--grey-color-darker);border-radius:4px}plugin-task-preview-flexible-100554 .tab-group-right{display:flex;flex-shrink:0}plugin-task-preview-flexible-100554 .tab-button{padding:10px 16px;cursor:pointer;background:none;border:none;border-right:1px solid #ddd;font-size:14px;transition:background-color .2s ease;display:flex;flex-direction:column}plugin-task-preview-flexible-100554 .tab-button:hover{background-color:#e0e0e0}plugin-task-preview-flexible-100554 .tab-button.active{background-color:#ffffff;font-weight:bold;border-bottom:2px solid #007bff}plugin-task-preview-flexible-100554 .tab-content{position:relative;padding:0;margin:0;background-color:#ffffff;display:flex;height:100%;flex-direction:column;font-size:14px;overflow-y:auto}plugin-task-preview-flexible-100554 .containerinputs{display:flex;flex-direction:column;gap:.5rem;align-items:center;padding:1rem}plugin-task-preview-flexible-100554 .containerinputs details{width:100%;max-width:900px;border:1px solid #e0e0e0;border-radius:8px;background-color:#fafafa;box-shadow:0 2px 8px rgba(0,0,0,0.05);font-family:'Inter',sans-serif;transition:all .3s ease}plugin-task-preview-flexible-100554 .containerinputs details[open] .title{display:none}plugin-task-preview-flexible-100554 .containerinputs details .chevron{transition:transform .3s}plugin-task-preview-flexible-100554 .containerinputs details[open] .chevron{transform:rotate(90deg)}plugin-task-preview-flexible-100554 .containerinputs details[open] .moveelement{display:none !important}plugin-task-preview-flexible-100554 .containerinputs details summary{position:relative;cursor:pointer;padding:1rem;border-bottom:1px solid #e0e0e0;display:flex;align-items:center;justify-content:space-between}plugin-task-preview-flexible-100554 .containerinputs details summary:hover .moveelement{display:flex}plugin-task-preview-flexible-100554 .containerinputs details summary .trash{z-index:9999}plugin-task-preview-flexible-100554 .containerinputs details summary .pheader{width:100%;display:flex;justify-content:space-between;align-items:center}plugin-task-preview-flexible-100554 .containerinputs details summary .pheader .title{margin-left:1rem}plugin-task-preview-flexible-100554 .containerinputs details summary .pheader .type .typeMode{appearance:none;padding:.4rem 1rem;font-size:.95rem;border:1px solid #ccc;border-radius:6px;background-color:white;transition:border .3s ease}plugin-task-preview-flexible-100554 .containerinputs details>div{padding:1rem}plugin-task-preview-flexible-100554 .containerinputs details>div pre.content{width:calc(100% - 2rem);border:none;resize:vertical;padding:1rem;font-size:.95rem;font-family:'Fira Code',monospace;background-color:#fff;border-radius:6px;color:#333;box-shadow:inset 0 1px 2px rgba(0,0,0,0.05);line-height:1.5;word-break:break-word;white-space:pre-wrap}plugin-task-preview-flexible-100554 ul{list-style:none;padding:1rem;margin:1rem 0;border-radius:12px;color:#333}plugin-task-preview-flexible-100554 ul li{margin-bottom:.75rem;padding:.5rem .75rem;background:white;border-radius:8px;transition:background .3s}plugin-task-preview-flexible-100554 ul li code{font-family:'Courier New',monospace;background-color:#eee;padding:2px 6px;border-radius:4px}`);
        this.message = null;
        this.task = null;
        this.step = null;
        this.mode = 'flexible';
    }
    render() {
        if (!this.step) {
            return html `<p>Step not Found.</p>`;
        }
        return html `
            <div style="height: calc(100% - 41px);">
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button
                            class="tab-button ${this.mode === 'info' ? 'active' : ''}" @click=${() => this.selectTabInfo()} >
                            Info                            
                        </button>
                        <button
                            class="tab-button ${this.mode === 'flexible' ? 'active' : ''}" @click=${() => this.selectTabFlexible()} >
                            Flexible                            
                        </button>
                    </div>
                </div>
                <div class="tab-content">
                    ${this.renderMode()}
                    
                </div>
            </div>
        `;
    }
    renderMode() {
        switch (this.mode) {
            case 'flexible': return this.renderFlexible();
            case 'info': return this.renderInfo();
            case 'result': return this.renderResults();
            default: return this.renderInfo();
        }
    }
    renderInfo() {
        if (!this.task || !this.step)
            return html `Not found!`;
        return html `
        <div class="containerinputs">
            <details open>
                <summary> ${this.renderSummary('Flexible')} </summary>
                <ul>
                    <li>
                        #${this.step.stepId} - ${this.step.type} - ${this.step.status} - $${this.step.interaction ? this.step.interaction.cost : '0'}
                    </li>
                </ul>
            </details>
            <details>
                <summary> ${this.renderSummary('Task details')}</summary>
                <ul>
                    <li>
                        <header>
                                <h2>${this.task.PK}</h2>
                                <small>Status: ${this.task.status} | Última atualização: ${new Date(this.task.last_updated).toLocaleString()}</small>
                        <br/><small>${this.task.title}</small>
                        </header>
                    </li>
                </ul>
            </details>
            <details>
                <summary> ${this.renderSummary('Message details')}</summary>
                <ul>
                    <li>
                        <pre>
                            ${JSON.stringify(this.message, null, 2)}
                        </pre>
                    </li>
                </ul>
            </details>
        </div>
        `;
    }
    renderSummary(title) {
        return html `
            <div class="pheader">
                <div style="display:flex; align-items: center;gap:.5rem">
                    <span>
                        ${title}
                    </span>
                </div>
                <div style="display:flex; gap:.5rem">
                    <div class="chevron">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                    </div>
                </div>
            </div>
        `;
    }
    renderFlexible() {
        if (!this.step)
            return html `
            <div class="containerinputs">
                <h3>No input found!</h3>
            </div>
        `;
        return html `<pre>${JSON.stringify(this.step.result, null, 2)}</pre>`;
    }
    renderResults() {
        if (!this.step)
            return html `Not found step`;
        const nextOptions = [];
        if (this.step.interaction?.payload) {
            nextOptions.push(...this.step.interaction.payload);
        }
        if (this.step.nextSteps) {
            nextOptions.push(...this.step.nextSteps);
        }
        return html `
        <ul>
            ${nextOptions.length === 0 ? html `<li><em>Not next step</em></li>`
            : nextOptions.map((ns) => html ` <li> [${ns.stepId}] ${ns.type} - ${ns.agentName} </li> `)}
        </ul>
        `;
    }
    //------IMPLEMENTATION----------
    selectTabFlexible() {
        this.mode = 'flexible';
    }
    selectTabInfo() {
        this.mode = 'info';
    }
    selectTabResult() {
        this.mode = 'result';
    }
};
__decorate([
    property({ type: Object })
], pluginTaskPreviewFlexible.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], pluginTaskPreviewFlexible.prototype, "task", void 0);
__decorate([
    property({ type: Object })
], pluginTaskPreviewFlexible.prototype, "step", void 0);
__decorate([
    state()
], pluginTaskPreviewFlexible.prototype, "mode", void 0);
pluginTaskPreviewFlexible = __decorate([
    customElement('plugin-task-preview-flexible-100554')
], pluginTaskPreviewFlexible);
export { pluginTaskPreviewFlexible };
