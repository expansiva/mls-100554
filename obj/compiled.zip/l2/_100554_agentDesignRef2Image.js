/// <mls shortName="agentDesignRef2Image" project="100554" enhancement="_blank" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import { getNextInProgressStepByAgentName, getAgentStepByAgentName, updateStepStatus, updateTaskTitle, getNextStepIdAvaliable } from "./_100554_aiAgentHelper";
import { startNewAiTask, addNewStep, executeNextStep } from "./_100554_aiAgentOrchestration";
const agentName = "agentDesignRef2Image";
const nextAgentName = "agentDesignRef2Image2";
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "DesignRef 2 Hero Image",
        visibility: "public",
        scope: [],
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
    };
}
;
const _beforePrompt = async (context) => {
    const taskTitle = "Creating";
    if (!context || !context.message)
        throw new Error(`[${agentName}.beforePrompt] Invalid context`);
    if (!context.task) {
        const inputs = await getPrompts(context.message.content);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt).catch((err) => {
            throw new Error(err.message);
        });
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error(`[${agentName}.afterPrompt] Invalid context`);
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}.afterPrompt] No pending interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    if (!context.task)
        throw new Error(`[${agentName}.afterPrompt]Invalid context task`);
    context.task = await updateTaskTitle(context.task, "Prompt Image created");
    const stepIdPayLoad = step.interaction?.payload?.[0]?.stepId || -1;
    if (stepIdPayLoad <= 0) {
        throw new Error(`[${agentName}.afterPrompt] No payload found`);
    }
    const newStep = {
        type: 'agent',
        agentName: nextAgentName,
        status: 'pending',
        prompt: "...",
        stepId: getNextStepIdAvaliable(context.task),
        interaction: null,
        nextSteps: null,
        rags: null
    };
    // complete this step (payload) and push another step
    await addNewStep(context, stepIdPayLoad, [newStep], "Imaging ...");
    await executeNextStep(context);
};
async function getPrompts(data) {
    const dataPrompt = {
        userPrompt: JSON.stringify(data)
    };
    const rc = await getPromptByHtml({ folder: '', project: 100554, shortName: agentName, data: dataPrompt });
    return rc;
}
export function getPayload1(context) {
    if (!context || !context.task)
        throw new Error(`[${agentName}] [getPayload] Invalid context`);
    const agentStep = getAgentStepByAgentName(context.task, agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agentName}] [getPayload] no agent found`);
    // get result
    const resultStep = agentStep.interaction?.payload?.[0];
    if (!resultStep || resultStep.type !== "flexible" || !resultStep.result)
        throw new Error(`[${agentName}] [getPayload] No step flexible found for this agent.`);
    return { prompt: resultStep.result || "" };
}
