/// <mls shortName="pluginEditStyleL3" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, query, property, state } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item foi encontrado!'
};
const message_en = {
    noItens: 'No items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginEditStyleL3 = class PluginEditStyleL3 extends PluginBaseModule {
    //-----------INIT------------
    get getKeyEditor() { return 'l3_left'; }
    ;
    get confE() { return `l3_left`; }
    constructor() {
        super();
        this.msize = '';
        this.error = '';
        this.msg = messages['en'];
        this.setEvents();
    }
    //--------EVENTS-------------
    setEvents() {
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onlevelChange(ev));
        mls.events.addListener(3, 'L3EditEvents', this.onL3EditEvents.bind(this));
    }
    onL3EditEvents(ev) {
        if (!ev.desc || ev.level !== 3)
            return;
        const info = JSON.parse(ev.desc);
        if (!info || !info.action || !info.position || info.position === 'left')
            return;
    }
    onlevelChange(ev) {
        if (!ev.desc)
            return;
        const j = JSON.parse(ev.desc);
        if (j.level === 3) {
            this.forceUpdate();
        }
    }
    //-------COMPONENT----------
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('msize')) {
            this.updatedMSizeEditor();
        }
    }
    render() {
        setTimeout(() => { this.initMonaco(); }, 500);
        this.style.display = 'block';
        if (this.error)
            return html `<h3 style="color:red">${this.error}</h3>`;
        return html `
            <mls-editor-100529 slot="left" msize="${this.msize}"></mls-editor-100529>
        `;
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.requestUpdate();
    }
    async initMonaco() {
        if (!this._ed1) {
            await this.initMonaco_Editor();
        }
        this.openFile();
    }
    async initMonaco_Editor() {
        if (!this.editorEl)
            return;
        this._ed1 = monaco.editor.create(this.editorEl, mls.editor.conf[this.confE]);
        this.editorEl['mlsEditor'] = this._ed1;
        mls.editor.instances[this.confE] = this._ed1;
        mls.editor.InitEditor(this._ed1);
    }
    async openFile() {
        if (!mls.actual[2].left) {
            this.error = 'Not found storfile';
            return;
        }
        const scope = window.preview?.iframe?.contentDocument?.body;
        const iframeDoc = window.preview?.iframe?.contentWindow;
        if (!scope || !iframeDoc) {
            this.error = 'Not found preview';
            return;
        }
        if (!this.model)
            this.model = await this.createModel(mls.actual[2].left);
        if (!this._ed1 || !this.model) {
            this.error = 'Not found model';
            return;
        }
        this._ed1.setModel(this.model);
        this.setContent(scope, iframeDoc);
        this.updatedMSizeEditor();
    }
    setContent(scope, iframeDoc) {
        const active = scope.querySelector('*[clb_mode]');
        if (!active) {
            this.error = 'Not found element';
            return;
        }
        const sel = this.getMatchingRulesForElement(active, iframeDoc);
        console.info(sel);
    }
    async createModel(storFile) {
        try {
            const uri = monaco.Uri.parse(`file://server/_${storFile.project}_l3_editor.less`);
            let model = monaco.editor.getModel(uri);
            if (!model)
                model = monaco.editor.createModel('', 'less', uri);
            return model;
        }
        catch (e) {
            this.error = e.message;
        }
    }
    getMatchingRulesForElement(element, iframeDoc) {
        if (!iframeDoc.getMatchingRulesForElement)
            return;
        return iframeDoc.getMatchingRulesForElement(element);
    }
    updatedMSizeEditor() {
        this.editorEl?.setAttribute('msize', this.msize);
    }
};
__decorate([
    query('mls-editor-100529')
], PluginEditStyleL3.prototype, "editorEl", void 0);
__decorate([
    property({ type: String })
], PluginEditStyleL3.prototype, "msize", void 0);
__decorate([
    state()
], PluginEditStyleL3.prototype, "error", void 0);
PluginEditStyleL3 = __decorate([
    customElement('plugin-edit-style-l3-100554')
], PluginEditStyleL3);
export { PluginEditStyleL3 };
