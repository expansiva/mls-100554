/// <mls shortName="serviceIca" project="100554" enhancement="_100554_enhancementLitService" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabICATree } from './_100554_collabIcaTree';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceFca100554 = class ServiceFca100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.activeTab = 'AboutICA';
        this.details = {
            icon: '&#xf2db',
            state: 'background',
            position: 'left',
            tooltip: 'Service ICA',
            visible: true,
            widget: '_100554_serviceIca',
            level: [4]
        };
        this.onClickIcon = (op) => {
            this.activeTab = op;
        };
        this.menu = {
            title: '',
            actions: {},
            icons: {
                AboutICA: 'About ICA;3f',
                Navigation: 'Navigation;f041',
                Properties: 'Properties;f0ce',
                Styles: 'Styles;f5ad',
                Animation: 'Animation;f5ae',
            },
            actionDefault: '', // call after close icon clicked
            iconDefault: 'AboutFCA',
            setMode: undefined, // child will set this
            onClickIcon: this.onClickIcon,
            getLastMode: undefined,
            updateTitle: undefined
        };
        initCollabICATree;
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        if (visible && reinit) {
            //if (this.activeTab !== 'Navigation') return;
            const elTree = this.querySelector('collab-ica-tree-100554');
            if (elTree && elTree.forceUpdate)
                elTree.forceUpdate();
        }
    }
    //--------------COMPONENT---------------
    createRenderRoot() {
        return this;
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'Navigation':
                return this.renderNavigation();
            case 'Properties':
                return this.renderProperties();
            case 'Styles':
                return this.renderStyles();
            case 'Animation':
                return this.renderAnimation();
            case 'AboutICA':
                return this.renderAboutICA();
            default:
                return html ``;
        }
    }
    renderNavigation() {
        return html `<collab-ica-tree-100554 "scroll-custom" style=" height: calc(100vh - 140px); overflow-y: auto;" .myParent=${this}></collab-ica-tree-100554>`;
    }
    renderProperties() {
        return html `<div>In development: Properties</div>`;
    }
    renderStyles() {
        return html `<div></div>`;
    }
    renderAnimation() {
        return html `<div>In development: Animation</div>`;
    }
    renderAboutICA() {
        return html `<div>In develpoment: AboutICA</div>`;
    }
    //------------IMPLEMENTATION------------------
    setEvents() {
        mls.events.addListener(4, 'WCDEvent', (ev) => this.onWCDEvent(ev));
        mls.events.addListener(4, 'WCDEventChange', (ev) => this.onWCDEventChange(ev));
    }
    onWCDEvent(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (this.menu.setIconActive) {
            this.openMe();
            this.menu.setIconActive(data.op);
        }
    }
    onWCDEventChange(ev) {
        if (this.activeTab !== 'Navigation')
            return;
        const elTree = this.querySelector('collab-ica-tree-100554');
        if (elTree && elTree.forceUpdate)
            elTree.forceUpdate();
    }
};
ServiceFca100554.styles = css ``;
__decorate([
    property()
], ServiceFca100554.prototype, "activeTab", void 0);
ServiceFca100554 = __decorate([
    customElement('service-ica-100554')
], ServiceFca100554);
export { ServiceFca100554 };
