/// <mls shortName="serviceIca" project="100554" enhancement="_100554_enhancementLitService" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabICATree } from './_100554_collabIcaTree';
import { getAllWebComponentsInSource } from './_100554_libCompile';
import { convertTagToFileName } from './_100554_utilsLit';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceFca100554 = class ServiceFca100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.activeTab = 'AboutICA';
        this.details = {
            icon: '&#xf2db',
            state: 'background',
            position: 'left',
            tooltip: 'ICA',
            visible: true,
            widget: '_100554_serviceIca',
            level: [4]
        };
        this.onClickIcon = (op) => {
            this.activeTab = op;
        };
        this.menu = {
            title: '',
            actions: {},
            icons: {
                AboutICA: 'Help;3f',
                Navigation: 'Navigation;f041',
                Properties: 'Properties;f0ce',
                Styles: 'Styles;f5ad',
                Animation: 'Animation;f5ae',
            },
            actionDefault: '', // call after close icon clicked
            iconDefault: 'AboutFCA',
            setMode: undefined, // child will set this
            onClickIcon: this.onClickIcon,
            getLastMode: undefined,
            updateTitle: undefined
        };
        initCollabICATree;
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        if (visible && reinit) {
            //if (this.activeTab !== 'Navigation') return;
            const elTree = this.querySelector('collab-ica-tree-100554');
            if (elTree && elTree.forceUpdate)
                elTree.forceUpdate();
        }
    }
    //--------------COMPONENT---------------
    createRenderRoot() {
        return this;
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'Navigation':
                return this.renderNavigation();
            case 'Properties':
                return this.renderProperties();
            case 'Styles':
                return this.renderStyles();
            case 'Animation':
                return this.renderAnimation();
            case 'AboutICA':
                return this.renderAboutICA();
            default:
                return html ``;
        }
    }
    renderNavigation() {
        return html `<collab-ica-tree-100554 "scroll-custom" style=" height: calc(100vh - 140px); overflow-y: auto;" .myParent=${this}></collab-ica-tree-100554>`;
    }
    renderProperties() {
        return html `<collab-ica-config-attributes-100554 .myParent=${this} ></collab-ica-config-attributes-100554>`;
    }
    renderStyles() {
        return html `<div></div>`;
    }
    renderAnimation() {
        return html `<div>In development: Animation</div>`;
    }
    renderAboutICA() {
        const { shortName, project } = mls.actual[2].left;
        const mfile = mls.l2.editor.get({ shortName, project });
        if (!mfile)
            return html `<div>No file opened</div>`;
        const modelHTML = mfile.modelHTML;
        if (!modelHTML)
            return html `<div>No html source founded in opened file</div>`;
        const htmlFile = modelHTML.getValue() || '';
        const div = document.createElement('div');
        div.innerHTML = htmlFile;
        this.loadHelpPage('wcdOverlayModeStoryPage', 100554);
        return html `<div id="helpDiv"></div>`;
    }
    //------------IMPLEMENTATION------------------
    async loadHelpPage(shortName, project) {
        const keyFile = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (storFile) {
            const content = await storFile.getContent();
            if (this.helpDiv && typeof content === 'string') {
                const allWcs = getAllWebComponentsInSource(content);
                allWcs.forEach((wc) => {
                    const fileName = convertTagToFileName(wc);
                    const script = document.createElement('script');
                    script.type = 'module';
                    script.id = fileName;
                    script.src = (`/${fileName}`);
                    this.helpDiv?.appendChild(script);
                });
                const div = document.createElement('div');
                div.innerHTML = content;
                div.children[0].setAttribute('level', '7');
                this.helpDiv.innerHTML = '';
                this.helpDiv.appendChild(div);
            }
        }
    }
    setEvents() {
        mls.events.addListener(4, 'WCDEvent', (ev) => this.onWCDEvent(ev));
        mls.events.addListener(4, 'WCDEventChange', (ev) => this.onWCDEventChange(ev));
    }
    onWCDEvent(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (this.menu.setIconActive) {
            this.openMe();
            this.menu.setIconActive(data.op);
        }
    }
    onWCDEventChange(ev) {
        if (this.activeTab !== 'Navigation')
            return;
        const elTree = this.querySelector('collab-ica-tree-100554');
        if (elTree && elTree.forceUpdate)
            elTree.forceUpdate();
    }
};
ServiceFca100554.styles = css ``;
__decorate([
    property()
], ServiceFca100554.prototype, "activeTab", void 0);
__decorate([
    query('#helpDiv')
], ServiceFca100554.prototype, "helpDiv", void 0);
ServiceFca100554 = __decorate([
    customElement('service-ica-100554')
], ServiceFca100554);
export { ServiceFca100554 };
