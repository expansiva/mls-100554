/// <mls shortName="pluginProjectRunTest" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { query, property } from 'lit/decorators.js';
import { forceServiceInstance } from './_100554_libCommom';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { TsTestAst } from './_100554_tsTestAST';
import { collab_fileTest } from './_100554_collabIcons';
import './_100554_collabResultTest';
/// **collab_i18n_start**
const message_pt = {
    title: 'Executar testes',
    info: 'Este plugin executa automaticamente todos os testes disponíveis para a todas as páginas com teste no projeto.',
    page: 'Página'
};
const message_en = {
    title: 'Run Tests',
    info: 'This plugin automatically runs all available tests for all pages with tests in the project.',
    page: 'Page'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Run Tests",
    getSvg() {
        return collab_fileTest;
    }
};
export class PluginProjectRunTest extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-project-run-test-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-project-run-test-100554 button{background-color:var(--active-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#fff;cursor:pointer;min-width:80px}plugin-project-run-test-100554 button:hover{background-color:var(--active-color-hover)}plugin-project-run-test-100554 .actions{margin:1rem 0}plugin-project-run-test-100554 .progress-container{margin:1rem 0;width:100%;background-color:#eee;border-radius:8px;overflow:hidden}plugin-project-run-test-100554 .progress-bar{height:8px;width:0%;background-color:#007bff;transition:width .3s ease-in-out}plugin-project-run-test-100554 .final-resume{border:1px solid #cecece;padding:1rem;margin-top:1rem}plugin-project-run-test-100554 .failed{color:var(--error-color)}plugin-project-run-test-100554 .success{color:var(--success-color)}plugin-project-run-test-100554 .summary-title{display:inline-flex;align-items:center;gap:1rem}plugin-project-run-test-100554 .summary-title small,plugin-project-run-test-100554 .summary-title h3{display:inline-block}plugin-project-run-test-100554 .container-test{padding-top:.5rem;margin-left:1rem}plugin-project-run-test-100554 collab-result-container-100554{display:flex;overflow:auto;padding:1rem;background:#f4f4f4;flex-direction:column;gap:.6rem}plugin-project-run-test-100554 collab-result-container-100554>div i{cursor:pointer}plugin-project-run-test-100554 collab-result-container-100554>div .icon{font-size:24px;animation:spin 5s linear infinite}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}`);
        this.msg = messages['en'];
        this.progress = 0;
        this.totalTest = 0;
        this.totalTestPass = 0;
        this.totalTestFailed = 0;
        this.startTime = 0;
        this.endTime = 0;
        this.actualAllPagesTests = 0;
        this.filesWithTest = [];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `

            <div>
                <h1>${this.msg.title}</h1>
                <small>${this.msg.info}</small>
                <div class="actions">
                    <button @click=${this.exec}>${this.msg.title}</button>
                </div>
            </div>


            <div class="progress-container">
				<div class="progress-bar" style="width: ${this.progress}%;"></div>
			</div>
            <collab-result-container-100554>
            
            </collab-result-container-100554>
        `;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.init();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('actualAllPagesTests')) {
            this.calcProgress(this.totalTest, this.actualAllPagesTests);
        }
    }
    async init() {
        try {
            const { project } = mls.actual[5];
            if (!project)
                return;
            this.clear();
            this.filesWithTest = await this.getStorFilesWithTest(project);
        }
        catch (err) {
            console.info(err);
        }
    }
    async exec() {
        this.clear();
        this.startTime = performance.now();
        console.info("[DEBUG] Start:", new Date().toISOString());
        const modelsStart = performance.now();
        const models = await this.createModelsIfNeeded(this.filesWithTest);
        console.info(`[DEBUG] createModelsIfNeeded took ${(performance.now() - modelsStart).toFixed(2)}ms`);
        const testsStart = performance.now();
        const tests = await this.getTestsByFile(models);
        console.info(`[DEBUG] getTestsByFile took ${(performance.now() - testsStart).toFixed(2)}ms`);
        this.totalTest = this.countTotalTests(tests);
        const forceServiceStart = performance.now();
        await forceServiceInstance(5, '_100554_servicePreview');
        console.info(`[DEBUG] forceServiceInstance took ${(performance.now() - forceServiceStart).toFixed(2)}ms`);
        const runTestsStart = performance.now();
        await this.runAllTests(tests);
        console.info(`[DEBUG] runAllTests took ${(performance.now() - runTestsStart).toFixed(2)}ms`);
        this.endTime = performance.now();
        console.info("[DEBUG] End:", new Date().toISOString());
        this.onFinishTest();
    }
    clear() {
        if (this.collabResultContainer)
            this.collabResultContainer.innerHTML = '';
        this.progress = 0;
        this.actualAllPagesTests = 0;
        this.totalTest = 0;
        this.totalTestPass = 0;
        this.totalTestFailed = 0;
        this.startTime = 0;
        this.endTime = 0;
    }
    countTotalTests(tests) {
        let total = 0;
        Object.keys(tests).forEach((test) => {
            tests[test].tests.forEach((testData) => {
                let lengthTest = testData.params.length;
                total += lengthTest;
            });
        });
        return total;
    }
    calcProgress(total, actual) {
        if (total <= 0)
            return;
        const part = 100 / total;
        const percent = actual * part;
        this.progress = percent;
    }
    async createModelsIfNeeded(files) {
        await forceServiceInstance(2, '_100554_serviceSource');
        const instance = mls.services['100554_serviceSource_left'];
        if (!instance)
            throw new Error('Invalid instance for service source');
        if (!instance.createModels || typeof instance.createModels !== 'function')
            throw new Error(`Invalid function createModels`);
        const rc = [];
        for await (let key of files) {
            const storFile = mls.stor.files[key];
            if (!storFile)
                continue;
            await instance.createModels(storFile);
            const keyModel = mls.editor.getKeyModel(storFile.project, storFile.shortName);
            if (mls.editor.models[keyModel] && mls.editor.models[keyModel].test)
                rc.push(mls.editor.models[keyModel].test);
        }
        return rc;
    }
    async getTestsByFile(models) {
        const rc = {};
        for await (let modelTest of models) {
            const ast = new TsTestAst(modelTest, monaco.editor.create(document.createElement('div')));
            if (!ast)
                continue;
            const tests = ast.getTests();
            if (tests && tests.length > 0)
                rc[`_${modelTest.storFile.project}_${modelTest.storFile.shortName}`] = {
                    tests,
                    ast,
                    storFile: modelTest.storFile
                };
        }
        return rc;
    }
    async getStorFilesWithTest(project) {
        const filesWithTest = Object.keys(mls.stor.files).filter((key) => {
            const file = mls.stor.files[key];
            return file.project === project && file.extension === '.test.ts';
        }).map((item) => item.replace('.test.ts', '.ts'));
        return filesWithTest;
    }
    addTestResultItem(container, title, status) {
        if (!this.collabResultContainer)
            return;
        const item = document.createElement('collab-result-test-100554');
        item.setAttribute('testName', title);
        item.setAttribute('status', status);
        container.appendChild(item);
        return item;
    }
    createPageContainer(pageName) {
        const el = document.createElement('div');
        const icon = document.createElement('i');
        icon.className = 'icon fa-solid fa-spinner';
        const span = document.createElement('h3');
        const br = document.createElement('br');
        const containerTest = document.createElement('div');
        containerTest.className = 'container-test';
        const details = document.createElement('details');
        details.open = false;
        const summary = document.createElement('summary');
        const summaryContent = document.createElement('div');
        summaryContent.className = 'summary-title';
        span.innerHTML = `${this.msg.page}: ${pageName}`;
        span.style.display = 'inline-block';
        const result = document.createElement('small');
        result.className = 'test-result';
        details.appendChild(summary);
        details.appendChild(containerTest);
        summaryContent.appendChild(span);
        summaryContent.appendChild(icon);
        summaryContent.appendChild(result);
        summary.appendChild(summaryContent);
        el.appendChild(details);
        return el;
    }
    async runTest(actualData, index, ast, containerTestDiv) {
        const testItem = this.addTestResultItem(containerTestDiv, actualData.functionName + `(${index})`, 'running');
        if (!testItem)
            return;
        try {
            const result = await ast.runTest(actualData.functionName, index);
            testItem.setAttribute('resultStatus', 'pass');
            testItem.setAttribute('result', result);
        }
        catch (err) {
            testItem.setAttribute('resultStatus', 'failed');
            testItem.setAttribute('result', err.message);
            throw new Error();
        }
        finally {
            testItem.setAttribute('status', 'finished');
        }
    }
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    async runAllTests(allTests) {
        this.actualAllPagesTests = 0;
        for (let key of Object.keys(allTests)) {
            const testData = allTests[key];
            const container = this.createPageContainer(testData.storFile.shortName);
            this.collabResultContainer?.appendChild(container);
            const containerTestDiv = container.querySelector('.container-test');
            const icon = container.querySelector('.icon');
            const result = container.querySelector('.test-result');
            this.fireEvents(testData.storFile);
            await this.waitForPreviewLoaded();
            const iframe = window.preview.iframe;
            if (iframe)
                await this.waitForLitComponentsInIframe(iframe);
            // await this.delay(5000);
            let totalTest = 0;
            let success = 0;
            let failed = 0;
            for (let i = 0; i < testData.tests.length; i++) {
                const data = testData.tests[i];
                for (let j = 0; j < data.params.length; j++) {
                    if (!data.functionName)
                        continue;
                    try {
                        await this.runTest(data, j, testData.ast, containerTestDiv);
                        this.totalTestPass++;
                        success++;
                    }
                    catch (error) {
                        this.totalTestFailed++;
                        failed++;
                        continue;
                    }
                    finally {
                        totalTest++;
                        this.actualAllPagesTests++;
                        icon.remove();
                    }
                }
            }
            const resume = this.createResume(totalTest, success, failed);
            result.appendChild(resume);
        }
    }
    createResume(totalTest, success, failed) {
        const resume = document.createElement('span');
        resume.innerHTML = `${totalTest} tests executed — ${success > 0 ? '<i class="success fa fa-check"></i>' : ''} ${success} passed, ${failed > 0 ? '<i class="failed fa fa-times"></i>' : ''} ${failed} failed.`;
        return resume;
    }
    createResumeFinal(totalTest, success, failed, start, end) {
        const executionTimeMs = end - start;
        const executionTime = executionTimeMs >= 1000
            ? `${(executionTimeMs / 1000).toFixed(2)}s`
            : `${executionTimeMs.toFixed(2)}ms`;
        const avgTestTime = (totalTest > 0) ? (executionTimeMs / totalTest).toFixed(2) : 'N/A';
        const failRate = (totalTest > 0) ? ((failed / totalTest) * 100).toFixed(1) : '0';
        const message = `
    <b>Result:</b> ${totalTest} tests executed — 
    ${success > 0 ? '<i class="success fa fa-check"></i>' : ''} <b>${success} passed</b>, 
    ${failed > 0 ? '<i class="failed fa fa-times"></i>' : ''} <b>${failed} failed.</b> 
    <br><b>Execution Time:</b> ${executionTime} 
    <br><b>Average Time per Test:</b> ${avgTestTime} ms
    <br><b>Failure Rate:</b> ${failRate}% 
`;
        const resume = document.createElement('span');
        resume.className = 'final-resume';
        resume.innerHTML = message;
        return resume;
    }
    waitForPreviewLoaded() {
        return new Promise((resolve) => {
            window.addEventListener('preview-loaded', (e) => { resolve(); }, { once: true });
        });
    }
    async waitForLitComponentsInIframe(iframe) {
        return new Promise((resolve) => {
            const iframeDoc = iframe.contentWindow?.document;
            if (!iframeDoc)
                return resolve();
            const checkLitComponents = async () => {
                const elements = Array.from(iframeDoc.querySelectorAll('*'))
                    .filter(el => el.tagName.includes('-'));
                if (elements.length === 0) {
                    resolve();
                    return;
                }
                const litElementsWithOutRegister = elements.filter(el => iframe.contentWindow?.customElements.get(el.tagName.toLowerCase()) === undefined);
                await Promise.all(litElementsWithOutRegister.map(async (el) => {
                    await iframe.contentWindow?.customElements.whenDefined(el.tagName.toLowerCase());
                }));
                const litElements2 = elements.filter(el => 'updateComplete' in el && 'initPage' in el);
                await Promise.all(litElements2.map(el => el.updateComplete));
                await Promise.all(litElements2.map(el => el.initPageComplete));
                resolve();
            };
            checkLitComponents();
        });
    }
    fireEvents(file) {
        const params = {};
        params.action = 'openBackground';
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = file.extension;
        params.folder = file.folder;
        params.position = 'left';
        mls.actual[2].setFullName(`_${file.project}_${file.shortName}`);
        mls.actual[2].left = {
            project: file.project,
            shortName: file.shortName,
            extension: file.extension,
            folder: file.folder,
        };
        mls.events.fire([5], ['FileAction'], JSON.stringify(params), 0);
    }
    onFinishTest() {
        const resume = this.createResumeFinal(this.totalTest, this.totalTestPass, this.totalTestFailed, this.startTime, this.endTime);
        this.collabResultContainer?.appendChild(resume);
        mls.actual[2].left = undefined;
        window.preview.iframe?.remove();
        window.preview.iframe = undefined;
    }
}
__decorate([
    query('collab-result-container-100554')
], PluginProjectRunTest.prototype, "collabResultContainer", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "progress", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "totalTest", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "totalTestPass", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "totalTestFailed", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "startTime", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "endTime", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "actualAllPagesTests", void 0);
__decorate([
    property()
], PluginProjectRunTest.prototype, "filesWithTest", void 0);
if (!customElements.get('plugin-project-run-test-100554')) {
    customElements.define('plugin-project-run-test-100554', PluginProjectRunTest);
}
