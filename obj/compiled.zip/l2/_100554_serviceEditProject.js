/// <mls shortName="serviceEditProject" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ServiceEditProject100554_1;
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import * as libProjectConfig from './_100554_libProjectConfig';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    menu_title: 'Configuração do projeto'
};
const message_en = {
    loading: 'Loading...',
    menu_title: 'Project Configs'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceEditProject100554 = ServiceEditProject100554_1 = class ServiceEditProject100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.details = {
            icon: '&#xf085',
            state: 'foreground',
            position: 'right',
            tooltip: 'Service Edit Project',
            visible: true,
            widget: '_100554_serviceEditProject',
            level: [5]
        };
        this.onClickLink = (op) => {
            if (op === 'opConfig')
                return this.showStart();
            if (op === 'opClear')
                return this.clearChanges();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: this.msg.menu_title,
            actions: {
                opClear: 'Clear changes',
            },
            icons: {},
            actionDefault: 'opConfig', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.msize = '';
        this.template = `window.project_config`;
        this.timeoutChangesEditorStyle = 0;
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            setTimeout(() => {
                this.setMsizeEditor();
            }, 100);
        }
        const { project } = mls.actual[5];
        if (reinit) {
            this.refreshIfNeeded(project);
        }
    }
    async setEvents() {
        mls.events.addEventListener([5], ['ProjectSelected'], (ev) => {
            if (!ev.desc)
                return;
            const desc = JSON.parse(ev.desc);
            this.refreshIfNeeded(desc.value);
        });
    }
    showStart() {
        if (this._ed1) {
            const [width, height] = this.msize.split(',');
            this._ed1.layout({ width: +width, height: +height });
        }
        return true;
    }
    clearChanges() {
        this._clearChanges();
        if (this.menu.setMode)
            this.menu.setMode('initial');
        return false;
    }
    _clearChanges() {
        this.loadProjectConfigs(true);
        if (this.lastProject)
            libProjectConfig.clearLocalChanges(this.lastProject);
    }
    refreshIfNeeded(project) {
        if (this.lastProject !== project) {
            this.loadProjectConfigs();
        }
    }
    setMsizeEditor() {
        if (!this.visible)
            return;
        this.c2?.setAttribute('msize', this.msize);
    }
    createEditor() {
        if (!this.c2 || this._ed1)
            return;
        const opt = {
            automaticLayout: true,
        };
        this._ed1 = monaco.editor.create(this.c2, opt);
        this.c2['mlsEditor'] = this._ed1;
        this.setMsizeEditor();
    }
    async loadProjectConfigs(ignoreLocal = false) {
        const { project } = mls.actual[5];
        if (!project)
            return;
        this.lastProject = project;
        let config = await libProjectConfig.getConfigProject(project, ignoreLocal);
        if (!config)
            config = await libProjectConfig.createConfigFile(project);
        this.setInitialConfig(JSON.stringify(config, null, 2), project);
    }
    setInitialConfig(value, project) {
        const newValue = this.template + ' = ' + value;
        this.model = this.createOrGetModel('typescript', newValue, project);
        if (!this.model || !this._ed1)
            return;
        this._ed1.setModel(this.model);
    }
    createOrGetModel(editorType, src, project) {
        const uri = this.getUri(`${this.constructor.name}_${project}}`);
        let model1 = monaco.editor.getModel(uri);
        if (!model1) {
            model1 = monaco.editor.createModel(src, editorType, uri);
            this.setEventsModel(model1);
        }
        else {
            model1.setValue(src);
        }
        return model1;
    }
    setEventsModel(model) {
        model.onDidChangeContent((event) => {
            if (this.timeoutChangesEditorStyle)
                clearTimeout(this.timeoutChangesEditorStyle);
            this.timeoutChangesEditorStyle = setTimeout(() => {
                this.onEditorChange();
            }, 1000);
        });
    }
    async onEditorChange() {
        if (!this.model)
            return;
        const val = this.model.getValue();
        const errors = monaco.editor.getModelMarkers(({ resource: this.model.uri }));
        if (errors && errors.length > 0)
            return;
        const that = this;
        (async function scope() {
            eval(val); // eslint-disable-line no-eval
            if (window.project_config && typeof window.project_config === 'object' && that.lastProject) {
                libProjectConfig.updateConfigProject(that.lastProject, window.project_config);
            }
        }).call(this);
    }
    getUri(shortFN) {
        ServiceEditProject100554_1.modelCount = ServiceEditProject100554_1.modelCount + 1 || 1;
        return monaco.Uri.parse(`file://server/${shortFN}_${ServiceEditProject100554_1.modelCount}.ts`);
    }
    firstUpdated() {
        this.createEditor();
        this.loadProjectConfigs();
    }
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            this.setMsizeEditor();
        }
    }
    render() {
        return html `
            <mls-editor-100529 ismls2="true"></mls-editor-100529>
        `;
    }
};
__decorate([
    property({ type: String })
], ServiceEditProject100554.prototype, "msize", void 0);
__decorate([
    query('mls-editor-100529')
], ServiceEditProject100554.prototype, "c2", void 0);
ServiceEditProject100554 = ServiceEditProject100554_1 = __decorate([
    customElement('service-edit-project-100554')
], ServiceEditProject100554);
export { ServiceEditProject100554 };
