/// <mls shortName="pluginTestDashboard4" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let PluginTestDashboard1100554 = class PluginTestDashboard1100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.dashboardindex = '';
        this.scope = 'dashboard';
        this.chartData = {};
    }
    createRenderRoot() {
        return this;
    }
    async prepare() {
        await this.delay(1000);
        await import('./_100554_wcChart');
        this.chartData = {
            "series": [
                {
                    "type": "gauge",
                    "progress": {
                        "show": true,
                        "width": 18
                    },
                    "axisLine": {
                        "lineStyle": {
                            "width": 18
                        }
                    },
                    "axisTick": {
                        "show": false
                    },
                    "splitLine": {
                        "length": 15,
                        "lineStyle": {
                            "width": 2,
                            "color": "#999"
                        }
                    },
                    "axisLabel": {
                        "distance": 25,
                        "color": "#999",
                        "fontSize": 20,
                        "formatter": function (value) {
                            return value + '%';
                        }
                    },
                    "anchor": {
                        "show": true,
                        "showAbove": true,
                        "size": 25,
                        "itemStyle": {
                            "borderWidth": 10
                        }
                    },
                    "title": {
                        "show": false
                    },
                    "detail": {
                        "valueAnimation": true,
                        "fontSize": 30,
                        "formatter": function (value) {
                            return value + '%';
                        },
                        "offsetCenter": [0, "70%"]
                    },
                    "data": [
                        {
                            "value": 75,
                            "formatter": function (value) {
                                return value + '%';
                            }
                        }
                    ]
                }
            ]
        };
        this.innerHTML = `<wc-chart-100554 datasource=${JSON.stringify(this.chartData)}></wc-chart-100554>`;
    }
    async delay(timeout) {
        await new Promise((resolve) => setTimeout(resolve, timeout));
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        return html ``;
    }
};
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "dashboardindex", void 0);
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "scope", void 0);
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "chartData", void 0);
PluginTestDashboard1100554 = __decorate([
    customElement('plugin-test-dashboard4-100554')
], PluginTestDashboard1100554);
export { PluginTestDashboard1100554 };
