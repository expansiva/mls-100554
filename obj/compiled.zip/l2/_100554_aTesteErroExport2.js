/// <mls shortName="aTesteErroExport2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export function teste() {
    const obj = {
        args: '',
        param: '',
        el: undefined
    };
    console.info(obj.el);
    return obj;
}
