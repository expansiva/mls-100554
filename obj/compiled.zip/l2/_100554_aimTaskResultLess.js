/// <mls shortName="aimTaskResultLess" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeDiff100554 } from './_100554_collabShowCodeDiff';
import { getActiveOpServiceIfIsValid, isValidRef } from './_100554_aimActionStyleNew';
/// **collab_i18n_start**
const message_pt = {
    title: 'View Less Result',
    p1: 'Por favor digite as mudanças necessárias abaixo.',
    cancel: 'Cancelar',
    confirm: 'Confirmar'
};
const message_en = {
    title: 'Ver Resultado do Less',
    p1: 'Por favor, digite as mudanças necessárias abaixo.',
    cancel: 'Cancelar',
    confirm: 'Confirmar'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let AimTaskResultLess = class AimTaskResultLess extends AimTaskBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.withDiff = false;
        this.isTryAgain = false;
        this.result = '';
        this.alreadyInit = false;
        initCollabShowCodeDiff100554();
    }
    onInitializing() {
        if (this.taskChild.mode !== 'error' && this.taskChild.mode !== 'processed') {
            this.modeInternal = this.taskRoot.mode = this.taskChild.mode = 'waiting for user';
        }
        this.openMe();
    }
    async setValues() {
        if (!this.codeDiff)
            return;
        this.codeDiff.actualTextResult = this.result.trim();
        this.codeDiff.actualTextDiffModified = this.result.trim();
        const activeOpService = getActiveOpServiceIfIsValid(this);
        if (!activeOpService)
            return;
        const isValid = isValidRef(this.taskRoot, activeOpService);
        this.withDiff = isValid;
        if (this.withDiff)
            this.codeDiff.setAttribute('withdiff', 'true');
        if (this.modeInternal === 'waiting for user') {
            this.codeDiff.setAttribute('withaccept', 'true');
            this.codeDiff.setAttribute('withreject', 'true');
            this.codeDiff.setAttribute('withtryagain', 'true');
        }
        const value = activeOpService.getEditorComponentSource();
        this.codeDiff.actualTextDiffOriginal = value.trim();
    }
    handleClick(e) {
        this.setValues();
        if (this.alreadyInit)
            return;
        this.codeDiff?.init();
        this.alreadyInit = true;
    }
    renderBody(taskRoot, child) {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const body = child._tempResult || '';
        const { contentLess, contentsAfterLess, contentsBeforeLess } = this.extractBlocks(body);
        this.result = contentLess;
        return html `
        <details @click=${this.handleClick}>
            <summary>${this.msg.title}</summary>
            <div style=${!this.isTryAgain ? 'display: block' : 'display:none'}>
                <div>${contentsBeforeLess}</div>
                <div style='margin: 10px;'>
                    <collab-show-code-diff-100554
                        language="less"
                        .onAccept=${this.onAccept.bind(this)}
                        .onTryAgain=${this.onTryAgain.bind(this)}
                        .onReject=${this.onReject.bind(this)}
                        ${this.withDiff ? 'withdiff' : ''}      
                    ></collab-show-code-diff-100554>
                </div> 
                <div>${contentsAfterLess}</div>
            </div>

            <div style=${this.isTryAgain ? 'display: block' : 'display:none'}>
                <div>
                    <div>${this.msg.p1}</div>
                    <div style='margin: 10px;'>
                        <div>
                            <label>Prompt:</label>
                            <textarea rows="5" placeholder="Digite aqui seu prompt" style="width:100%"></textarea>
                        </div>
                        <br>
                        <div class="buttonGroup">
                            <button @click="${this.handleCancelTryAgain}">${this.msg.cancel}</button>
                            <button @click="${this.handleConfirmTryAgain}">${this.msg.confirm}</button>
                        </div>
                    </div> 
                </div> 
            </div>
        </details>
        `;
    }
    closeMe() {
        const det = this.querySelector('details');
        if (det)
            det.open = false;
    }
    openMe() {
        const det = this.closest('details');
        if (det)
            det.open = true;
    }
    handleCancelTryAgain() {
        this.isTryAgain = false;
    }
    handleConfirmTryAgain() {
        let prompt = '';
        if (this.textarea)
            prompt = this.textarea.value;
        this.isTryAgain = false;
        this.notifyCompleteByStatus('userEvent', this.result, prompt);
        this.closeMe();
    }
    onAccept() {
        this.notifyCompleteByStatus('ok', this.result);
        this.modeInternal = 'processed';
        this.closeMe();
    }
    onReject() {
        this.notifyCompleteByStatus('rejected', '');
        this.modeInternal = 'processed';
        this.closeMe();
    }
    onTryAgain(e) {
        if (this.detailsResult)
            this.detailsResult.open = false;
        this.isTryAgain = true;
    }
    extractBlocks(src) {
        const regex = /^(.*?)```less(.*)```(.*)/s;
        const matches = src.match(regex);
        let contentLess = '';
        let contentsBeforeLess = '';
        let contentsAfterLess = '';
        if (matches) {
            contentsBeforeLess = matches[1] || '';
            contentLess = matches[2] || '';
            contentsAfterLess = matches[3] || '';
        }
        return { contentLess, contentsAfterLess, contentsBeforeLess };
    }
};
__decorate([
    query('collab-show-code-diff-100554')
], AimTaskResultLess.prototype, "codeDiff", void 0);
__decorate([
    query('#details_result')
], AimTaskResultLess.prototype, "detailsResult", void 0);
__decorate([
    query('textarea')
], AimTaskResultLess.prototype, "textarea", void 0);
__decorate([
    property({ type: Boolean })
], AimTaskResultLess.prototype, "withDiff", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], AimTaskResultLess.prototype, "isTryAgain", void 0);
__decorate([
    property({ type: String, reflect: true })
], AimTaskResultLess.prototype, "modeInternal", void 0);
AimTaskResultLess = __decorate([
    customElement('aim-task-result-less-100554')
], AimTaskResultLess);
export { AimTaskResultLess };
