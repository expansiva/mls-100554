/// <mls shortName="wcRow" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLayoutFlowRowBase } from './_100554_icaLayoutFlowRowBase';
let WcRow = class WcRow extends IcaLayoutFlowRowBase {
    render() {
        return html `
        <slot></slot>
       `;
    }
};
WcRow.styles = css `
        :host {
            margin-top:.5rem;
            height: 100%;
            width:100%;
            display:flex; 
            gap:1rem;
        }
    `;
__decorate([
    property()
], WcRow.prototype, "hint", void 0);
WcRow = __decorate([
    customElement('wc-row-100554')
], WcRow);
export { WcRow };
