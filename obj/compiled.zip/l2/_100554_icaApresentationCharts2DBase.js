/// <mls shortName="icaApresentationCharts2DBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElement } from './_100554_icaLitElement';
export class IcaApresentationCharts2DBase extends IcaLitElement {
}
