/// <mls shortName="serviceSource" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ServiceSource100554_1;
import { html } from 'lit';
import { customElement, query, property } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { ServiceBase } from './_100554_serviceBase';
import { getEventName } from './_100554_collabPageElement';
import { formatHtml, sync } from './_100554_collabDOMSync';
import { getAddNewFileDetails, removeTokensFromSource } from './_100554_enhancementStyle';
let ServiceSource100554 = ServiceSource100554_1 = class ServiceSource100554 extends ServiceBase {
    constructor() {
        super();
        this.msize = '';
        this.onClickLink = (op) => {
            if (op === 'opTS2')
                return true;
            if (op === 'opTheme')
                return this.showPageTheme();
            if (op === 'opMonacoConfig')
                return this.showConfEditor();
            if (op === 'opMonacoReset')
                return this.showMonacoReset();
            if (op === 'opHistory')
                return this.showHistory();
            if (op === 'opView')
                return this.openRepo();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            if (op === 'icTs')
                this.showActiveModel();
            if (op === 'icHTML')
                this.createOrShowModelHtmlOrCss(true, '.html');
            if (op === 'icCss')
                this.createOrShowModelHtmlOrCss(true, '.less');
        };
        this.onClickTitle = () => {
            this.openService('_100554_serviceProject', this.position, 2, { activeTab: 'Explore' });
        };
        this.details = {
            icon: '&#xf121',
            state: 'background',
            tooltip: 'Source',
            visible: true,
            position: "all",
            widget: '_100554_serviceSource',
            level: [2]
        };
        this.menu = {
            title: {
                icon: '&#xf053',
                text: 'L2 - widget1'
            },
            actions: {
                opTheme: 'Editor - Themes',
                opMonacoConfig: 'Editor - config',
                opMonacoReset: 'Editor - reset',
                opHistory: 'History',
                opView: 'View on repository',
            },
            icons: {
                icTs: 'Typescript;f121',
                icHTML: 'HTML;f13b',
                icCss: 'Css;f38b'
            },
            actionDefault: '', // call after close icon clicked
            iconDefault: 'icTs',
            setMode: undefined, // child will set this
            updateTitle: undefined, // child will set this
            getLastMode: undefined, // child will set this
            lastIcon: undefined, // child will set this
            setIconActive: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
            onClickTitle: this.onClickTitle
        };
        this.last = undefined;
        this.htmlModelAlreadyProcessed = {};
        this._onChangedContent = undefined;
        this.onModelChange = (e, activeModel, storFile) => {
            // some changes is to simulate changes to force compile
            clearTimeout(this._onChangedContent);
            this._onChangedContent = window.setTimeout(async () => {
                await this.updateModelStatus(activeModel, true);
                const ignoreChanges = (e.changes.length === 1 && e.changes[0].range.startLineNumber === 1 && e.changes[0].range.endLineNumber === 1 && e.changes[0].range.endColumn <= 2);
                if (ignoreChanges)
                    return;
                let position;
                if (mls.l2.editor.editors[this.confE2('left')]?.model.id === activeModel.model.id) {
                    position = 'left';
                }
                else {
                    position = 'right';
                }
                mls.events.fireFileAction('changed', storFile, position);
            }, 400);
        };
        this.getValueInfo = async (activeModel) => {
            const rc = {
                content: activeModel.model.getValue(),
                contentType: 'string',
                originalShortName: activeModel.originalShortName,
                originalProject: activeModel.originalProject,
                originalCRC: activeModel.originalCRC
            };
            return rc;
        };
        this.onProjectLoadedEvents = async (ev) => {
            if (ev.level !== this.level)
                return;
            if (!ev.desc)
                return;
            try {
                const projectLoadedInfo = JSON.parse(ev.desc);
                await this.readProjectTypescriptAndCompile(projectLoadedInfo.project, '', projectLoadedInfo.needCompile);
            }
            catch (e) {
                console.error('Error on serviceSource_onProjectLoadedEvents: ', e);
            }
        };
        this.isNewFile = false;
        this.onMLSEvents = async (ev) => {
            if (ev.level !== 2 || (ev.type !== 'FileAction'))
                return;
            if (!ev.desc)
                return;
            const fileAction = JSON.parse(ev.desc);
            if (fileAction.position !== this.position)
                return;
            let keyFiles; // set on getStorFile 
            let keyFilesHTML; // set on getStorFile 
            let keyFilesCss; // set on getStorFile 
            const getStorFile = () => {
                keyFiles = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, fileAction.extension);
                const storFile = mls.stor.files[keyFiles];
                if (!storFile)
                    throw new Error('Error on open, mls.stor.files dont exists, key:' + keyFiles);
                return storFile;
            };
            const getStorFileHTML = () => {
                keyFilesHTML = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, '.html');
                return mls.stor.files[keyFilesHTML];
            };
            const getStorFileCss = () => {
                keyFilesCss = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, '.less');
                return mls.stor.files[keyFilesCss];
            };
            const onNew = async () => {
                await this.newFiles(fileAction.newshortName, fileAction.newProject, fileAction.newEnhancement, fileAction.newTSSource);
            };
            const onOpen = async () => {
                const storFile = getStorFile();
                const storFileHTML = getStorFileHTML();
                const storFileCss = getStorFileCss();
                await this.openFiles(storFileHTML, storFile, storFileCss, fileAction.position);
            };
            const onDelete = async () => {
                const storFile = getStorFile();
                const storFileHTML = getStorFileHTML();
                const storFileCss = getStorFileCss();
                await this.deleteFiles(storFileHTML, storFile, storFileCss);
                await mls.stor.localDB.removePrjInfo(storFile.project);
            };
            const onUndo = async () => {
                const storFile = getStorFile();
                const storFileHTML = getStorFileHTML();
                const storFileCss = getStorFileCss();
                await this.undoFiles(storFileHTML, storFile, storFileCss, keyFilesHTML, keyFiles, keyFilesCss);
            };
            const onRename = async () => {
                const storFile = getStorFile();
                const storFileHTML = getStorFileHTML();
                const storFileCss = getStorFileCss();
                await this.renameFiles(storFileHTML, storFile, storFileCss, fileAction.newProject, fileAction.newshortName, fileAction);
                await mls.stor.localDB.removePrjInfo(storFile.project);
            };
            const onClone = async () => {
                const storFile = getStorFile();
                await this.cloneFiles(storFile, fileAction.newProject, fileAction.newshortName, fileAction);
            };
            const onUpdatedOnServer = async () => {
                await this.updatedOnServer();
            };
            if (mls.istrace)
                console.time('onAction_' + fileAction.action + '_' + fileAction.position);
            // if (fileAction.action !== 'preLoadProject') await this.initMonaco(false); // init if needed
            await this.initMonaco(); // init if needed
            switch (fileAction.action) {
                case 'new':
                    await onNew();
                    break;
                case 'open':
                    await onOpen();
                    break;
                case 'delete':
                    await onDelete();
                    break;
                case 'undo':
                    await onUndo();
                    break;
                case 'rename':
                    await onRename();
                    break;
                case 'clone':
                    await onClone();
                    break;
                case 'updatedOnServer':
                    await onUpdatedOnServer();
                    break;
                default: {
                    // console.error('invalid action: ' + fileAction.action);
                }
            }
            if (mls.istrace)
                console.timeEnd('onAction_' + fileAction.action + '_' + fileAction.position);
        };
        this.monacoGlobalInitialized = false;
        this.timeHtmlChangeCursor = 0;
        this.lastIdSelected = null;
        this.onFirtModel = true;
        this.timeout_compileConfEditor = 0;
        this.getValueInfoHtmlOrCss = async (activeModel, originalShortName, originalProject, originalCRC) => {
            const rc = {
                content: activeModel.getValue(),
                contentType: 'string',
                originalShortName,
                originalProject,
                originalCRC
            };
            return rc;
        };
        this._onChangedContentHtmlOrCss = undefined;
        //--------------WidgetAction--------------
        this.lastScenario = '';
        this.lastOrigin = 'editor';
        this.isHTMLSystemChange = false;
        this.syncDom = async (ev) => {
            if (this.position === 'right')
                return;
            try {
                this.isHTMLSystemChange = true;
                sync();
            }
            catch (e) {
                console.error('Error on syncDom: ', e);
            }
        };
        mls.events.addListener(2, 'WidgetAction', this.onWidgetActionEvents.bind(this));
        mls.events.addListener(2, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(2, 'MonacoAction', (ev) => this.onMonacoEvents(ev));
        mls.events.addListener(2, 'ProjectLoaded', (ev) => this.onProjectLoadedEvents(ev));
        mls.events.addListener(2, 'DomAction', (ev) => this.syncDom(ev));
        mls.events.addListener(2, 'CreateModelHTML', (ev) => this.checkToCreateModelHTML(ev));
        this.initMonaco_GlobalEditor();
    }
    createRenderRoot() {
        return this;
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (!visible) {
            this.saveViewState();
            return;
        }
        await this.initMonaco();
        if (this.menu.setIconActive)
            this.menu.setIconActive('icTs');
        this.c2?.setAttribute('msize', this.msize);
    }
    //---------- Handling Editor --------
    getEditorValue() {
        if (!this._ed1)
            return '';
        const model = this._ed1.getModel();
        if (!model)
            return '';
        return model.getValue();
    }
    setEditorValue(val) {
        if (!this._ed1)
            return false;
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.ts');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return false;
        this.setValueInModeKeepingUndo(model, val, true);
    }
    setEditorValueByLineTs(val, line) {
        if (!this._ed1)
            return false;
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.ts');
        if (this.menu.setIconActive)
            this.menu.setIconActive('icTs');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return false;
        this.setValueInModelInSpecificLine(val, line);
    }
    setEditorValueByLineHtml(val, line) {
        if (!this._ed1)
            return false;
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.html');
        if (this.menu.setIconActive)
            this.menu.setIconActive('icHTML');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return false;
        this.setValueInModelInSpecificLine(val, line);
    }
    replaceEditorLineHTML(val, line) {
        if (!this._ed1)
            return false;
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.html');
        if (this.menu.setIconActive)
            this.menu.setIconActive('icHTML');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return false;
        this.replaceLineValueInModelInSpecificLine(val, line);
    }
    searchLineByStringTs(search) {
        if (!this._ed1)
            return;
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.ts');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return;
        const matches = model.findMatches(search, false, false, false, null, true);
        if (!matches || matches.length === 0)
            return;
        return matches[0].range.startLineNumber;
    }
    goToLine(line) {
        if (!this._ed1)
            return;
        const model = this._ed1.getModel();
        if (!model)
            return;
        const content = model.getLineContent(line);
        const range = new monaco.Range(line, 1, line, content.length + 1);
        this._ed1.setSelection(range);
        this._ed1.revealLineInCenter(line);
    }
    setEditorHTMLValue(val) {
        if (!this._ed1)
            return false;
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.html');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return false;
        this.setValueInModeKeepingUndo(model, val, false);
    }
    getEditorHTMLValue() {
        if (!this._ed1)
            return '';
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.html');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return '';
        return model.getValue();
    }
    setValueInModeKeepingUndo(model, val, checkFirstLine) {
        let fullRange = model.getFullModelRange();
        let newText = val;
        if (checkFirstLine && !(val.trim().startsWith('/// <mls shortName'))) {
            const firstLine = model.getLineContent(1);
            newText = firstLine + '\n' + newText;
        }
        const lines = newText.split('\n');
        const operations = [{
                range: fullRange,
                text: '',
                forceMoveMarkers: true
            }, {
                range: { startLineNumber: 1, startColumn: 1 },
                text: lines.join('\n'),
                forceMoveMarkers: true
            }];
        model.pushEditOperations([], operations, () => []);
        this._ed1?.setPosition({ lineNumber: 1, column: 1 });
    }
    setValueInModelInSpecificLine(content, line) {
        if (!this._ed1)
            return;
        this._ed1.executeEdits('my-source', [
            {
                range: new monaco.Range(line, 1, line, 1),
                text: `${content}\n`,
                forceMoveMarkers: true
            }
        ]);
        this._ed1.revealLineInCenter(line);
        this.formatMonaco();
    }
    replaceLineValueInModelInSpecificLine(content, line) {
        if (!this._ed1)
            return;
        const model = this._ed1.getModel();
        if (!model)
            return;
        const lineLength = model.getLineLength(5);
        this._ed1.executeEdits('my-source', [
            {
                range: new monaco.Range(line, 1, line, lineLength + 1),
                text: content,
                forceMoveMarkers: true
            }
        ]);
        this._ed1.revealLine(line);
        this.formatMonaco();
    }
    formatMonaco() {
        if (!this._ed1)
            return;
        this._ed1.trigger('anyString', 'editor.action.formatDocument', null);
    }
    confE2(positionToolbar) { return `l${this.level}_${positionToolbar}`; }
    get confE() { return `l${this.level}_${this.position}`; }
    get confETS() { return this.confE + '_TS'; }
    get confEJS() { return this.confE + '_JS'; }
    saveViewState() {
        if (!this._ed1)
            return;
        const activeModel = mls.l2.editor.editors[this.confE];
        if (!activeModel)
            return;
        activeModel[`${this.position}_viewState`] = this._ed1.saveViewState();
    }
    restaureViewState() {
        if (!this._ed1)
            return;
        const activeModel = mls.l2.editor.editors[this.confE];
        if (!activeModel)
            return;
        const viewState = activeModel[`${this.position}_viewState`];
        if (viewState)
            this._ed1.restoreViewState(viewState);
    }
    openRepo() {
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const ext = this.menu.lastIcon === 'icTs' ? '.ts' : '.html';
        const keyToFile = mls.stor.getKeyToFiles(project, 2, shortName, '', ext);
        const file = mls.stor.files[keyToFile];
        if (!file) {
            window.collabMessages.add('Invalid File', 'information');
            throw new Error('invalid file');
        }
        const driver = mls.stor.others.getDefaultDriver(project);
        if (!driver) {
            window.collabMessages.add('Driver not found', 'information');
            throw new Error('Driver not found');
        }
        let url = '';
        url = driver.getUrl(file);
        window.open(url, '_blank');
        if (this.menu.closeMenu)
            this.menu.closeMenu();
        return true;
    }
    showHistory() {
        this.showHistorie2();
        return true;
    }
    async showHistorie2() {
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const div = document.createElement('div');
        const scr = document.createElement('script');
        const i2 = `/_${'100554'}_${'mlsHistoryList'}`;
        scr.type = 'module';
        scr.id = i2.replace('/', '');
        scr.src = i2;
        div.appendChild(scr);
        const obj = {
            icTs: '.ts',
            icHTML: '.html',
        };
        const wc = document.createElement('mls-history-list-100554');
        wc.setAttribute('project', project.toString());
        wc.setAttribute('shortName', shortName);
        wc.setAttribute('level', '2');
        if (this.menu.lastIcon)
            wc.setAttribute('extension', obj[this.menu.lastIcon]);
        wc.setAttribute('position', this.position);
        div.appendChild(wc);
        if (this.menu.setMode)
            this.menu.setMode('page', div);
    }
    showPageTheme() {
        if (this.menu.setMode)
            this.menu.setMode('page', this.getGlobalPageSetTHeme());
        return true;
    }
    showMonacoReset() {
        // reset editor configurations 
        mls.editor.conf[this.confE] = undefined;
        this.loadMonacoConfigurations();
        if (this.menu.setMode)
            this.menu.setMode('initial');
        this.updateMonacoConfigutarions();
        this.saveConfEditorToLocalStorage();
        return true;
    }
    showConfEditor() {
        if (this.menu.setMode)
            this.menu.setMode('editor');
        this.setModelConfEditor();
        return true;
    }
    async readProjectTypescriptAndCompile(project, shortName, needCompile = true) {
        // load all typescripts dependencies (in development) of project , except shortName
        if (ServiceSource100554_1.projectsLoaded.includes(project))
            return;
        if (mls.istrace)
            console.log('loading files from project ' + project);
        ServiceSource100554_1.projectsLoaded.push(project);
        const promises = [];
        const keys = Object.keys(mls.stor.files);
        if (window.traceLivecicle)
            console.info('creating: files model ', project);
        for (const key of keys) {
            const storFile = mls.stor.files[key];
            if (storFile.project === project
                && storFile.level === 2
                && storFile.extension === '.ts'
                && storFile.inLocalStorage
                && storFile.shortName !== shortName) {
                promises.push(this.createModelTS2(storFile, false, false));
            }
        }
        const info = await mls.stor.localDB.readPrjInfo(100554);
        if (info && info.indexModules && info.indexModules !== '') {
            promises.push(this.createProjectModel(project, info.indexModules));
        }
        if (mls.istrace)
            console.time('creating models');
        await Promise.all(promises);
        if (mls.istrace)
            console.timeEnd('creating models');
        if (window.traceLivecicle)
            console.info('firing: mls.l2.editor.compileAllProjectIfNeed ', project);
        if (needCompile)
            await mls.l2.editor.compileAllProjectIfNeed(project, true);
    }
    async createProjectModel(prj, contentTS) {
        let model1 = mls.l2.editor.get({ project: prj, shortName: '' });
        if (model1)
            return model1;
        const ftype = ".d.ts";
        const uri = this.getUri(`_${prj}_`, ftype);
        const model = monaco.editor.createModel(contentTS, 'typescript', uri);
        model1 = {
            changed: false, // not changed in this section, but storFile.changed is about all sections
            error: false,
            project: prj,
            shortName: '',
            extension: ftype,
            model,
            storFile: undefined,
            originalCRC: undefined,
            originalProject: undefined,
            originalShortName: undefined,
            codeLens: [],
        };
        mls.l2.editor.add(model1);
        return model1;
    }
    async deleteFile(storFile) {
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        const activeModel = mls.l2.editor.editors[this.confE];
        if (activeModel.project === storFile.project && activeModel.shortName === storFile.shortName)
            await this.createModelTS_testFile(); // show test file
        mls.l2.editor.remove(storFile);
        this.removeEventsModelTS(storFile);
        const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
        delete mls.stor.files[keyFiles];
    }
    async afterUpdate(storFile) {
        const mmodel = mls.l2.editor.get(storFile);
        if (!mmodel)
            return;
        if (storFile.status === 'deleted') {
            this.deleteFile(storFile);
            return;
        }
        if (storFile.status === 'renamed') {
            mmodel.originalProject = undefined;
            mmodel.originalShortName = undefined;
            mmodel.originalCRC = mls.common.crc.crc32(mmodel.model.getValue()).toString(16);
        }
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        storFile.status = 'nochange';
    }
    addEventsModelTS(storFile, model1) {
        storFile.onAction = (action) => this.afterUpdate(storFile);
        storFile.getValueInfo = () => this.getValueInfo(model1);
        model1.model.onDidChangeContent((e) => this.onModelChange(e, model1, storFile));
    }
    removeEventsModelTS(storFile) {
        storFile.onAction = undefined;
        storFile.getValueInfo = undefined;
    }
    onMonacoEvents(ev) {
        if (!ev.desc)
            return;
        const args = JSON.parse(ev.desc);
        if (!args)
            return;
        const { action, filePosition, position, project, shortName } = args;
        if (position !== this.position)
            return;
        if (action === 'gotoPosition') {
            this.goToPosition(filePosition, position);
        }
        if (mls.istrace)
            console.info('received monaco actions', args);
    }
    goToPosition(position, editorPosition) {
        if (!this._ed1)
            return;
        const confInvert = `l${this.level}_${editorPosition === 'left' ? 'right' : 'left'}`;
        const offset = position - 1;
        const { lineNumber, column } = mls.l2.editor.editors[confInvert].model.getPositionAt(offset);
        this._ed1.revealPositionInCenter({ lineNumber, column }, monaco.editor.ScrollType.Immediate);
        const lineLength = mls.l2.editor.editors[confInvert].model.getLineContent(lineNumber).length + 1;
        const range = new monaco.Range(lineNumber, column, lineNumber, lineLength);
        this._ed1.setSelection(new monaco.Selection(range.startLineNumber, 0, range.startLineNumber, lineLength));
    }
    async deleteFiles(storFileHTML, storFileTS, storFileCss) {
        for await (let storFile of [storFileHTML, storFileTS, storFileCss]) {
            if (!storFile)
                continue;
            if (storFile.status === 'new')
                this.deleteFile(storFile);
            else
                storFile.status = 'deleted';
            mls.events.fireFileAction('statusOrErrorChanged', storFile, this.position);
        }
    }
    async cloneFiles(storFileTS, newProject, newShortName, oldFileAction) {
        await this.createModelTS_loading();
        this.activeThisService();
        await this.createModelTS_clone(storFileTS, newProject, newShortName);
        mls.actual[this.level][this.position] = {
            project: newProject,
            shortName: newShortName
        };
        const fileAction = {
            ...oldFileAction,
            project: newProject,
            shortName: newShortName,
            action: 'open',
            newProject: undefined,
            newshortName: undefined,
        };
        const ev = {
            level: this.level,
            type: 'FileAction',
            desc: JSON.stringify(fileAction)
        };
        this.onMLSEvents(ev);
    }
    async newFiles(newShortName, newProject, newEnhancement, tsSource) {
        this.isNewFile = true;
        this.activeThisService();
        this.closeMenu();
        const newTSSource = tsSource
            || `/// <mls shortName="${newShortName}" project="${newProject}" enhancement="${newEnhancement}" />
				\n// typescript new file\n`;
        await this.createModelTS1(newShortName, newProject, newTSSource, true);
        await this.createOrShowModelHtmlOrCss(false, '.html');
        await this.createOrShowModelHtmlOrCss(false, '.less');
        this.showActiveModel();
        this.isNewFile = false;
    }
    async openFiles(storFileHTML, storFileTS, storFileCss, position) {
        await this.createModelTS_loading();
        this.activeThisService();
        this.closeMenu();
        const fileModel = mls.l2.editor.get(storFileTS);
        if (!fileModel) {
            await this.createModelTS2(storFileTS, true, true);
            this.showActiveModel();
            await this.readProjectTypescriptAndCompile(storFileTS.project, storFileTS.shortName, true).then(async () => {
                await this.createOrShowModelHtmlOrCss(false, '.html');
                await this.createOrShowModelHtmlOrCss(false, '.less');
            });
        }
        else {
            mls.l2.editor.editors[this.confE] = fileModel;
            mls.l2.editor.forceModelUpdate(fileModel.model);
            await this.createOrShowModelHtmlOrCss(false, '.html');
            await this.createOrShowModelHtmlOrCss(false, '.less');
            this.showActiveModel();
        }
        [storFileCss, storFileTS, storFileHTML].forEach((storF) => {
            if (storF && !storF.inLocalStorage && storF.isLocalVersionOutdated)
                storF.isLocalVersionOutdated = false;
        });
        this.saveLocalStorageLastOpen(storFileTS, position);
        if (!this._ed1)
            return;
        this.restaureViewState();
    }
    async renameFiles(storFileHTML, storFileTS, storFileCss, newProject, newShortName, oldFileAction) {
        await this.createModelTS_loading();
        this.activeThisService();
        let mfile = mls.l2.editor.get(storFileTS);
        if (!mfile)
            mfile = await this.createModelTS2(storFileTS, false, true);
        this.renameTSFile(mfile, storFileTS, newProject, newShortName);
        mls.l2.editor.editors[this.confE] = mfile;
        this.renameHTMLOrCssFile(mfile, storFileHTML, newProject, newShortName, '.html');
        this.renameHTMLOrCssFile(mfile, storFileCss, newProject, newShortName, '.less');
        mls.actual[this.level][this.position] = {
            project: newProject,
            shortName: newShortName
        };
        const fileAction = {
            ...oldFileAction,
            project: newProject,
            shortName: newShortName,
            action: 'open',
            newProject: undefined,
            newshortName: undefined,
        };
        const ev = {
            level: this.level,
            type: 'FileAction',
            desc: JSON.stringify(fileAction)
        };
        this.onMLSEvents(ev);
    }
    async updatedOnServer() {
        try {
            const keys = Object.keys(mls.stor.files);
            const arr = [];
            let needMsg = false;
            keys.forEach((key) => {
                const f = mls.stor.files[key];
                if (!f)
                    return;
                if (f.inLocalStorage || !f.isLocalVersionOutdated)
                    return;
                arr.push(f);
            });
            await mls.l2.editor.compileAllProjectIfNeed(mls.actual[5].project, true, false);
            for await (const storFile of arr) {
                mls.l2.editor.remove(storFile);
                this.removeEventsModelTS(storFile);
                await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
                await this.createModelTS2(storFile, false, true);
                if (storFile.project === 100554)
                    needMsg = true;
            }
            if (needMsg) {
                window.collabMessages.add("Files changed in server , please use F5 to reload", 'information', { autoClose: false, clearOnClose: false });
            }
        }
        catch (e) {
            console.info('Erro service source: onUpdatedOnServer');
        }
    }
    async undoFiles(storFileHTML, storFileTS, storFileCss, keyFileHTML, keyFileTS, keyFileCss) {
        for await (let data of [{ storFile: storFileHTML, keyFiles: keyFileHTML }, { storFile: storFileTS, keyFiles: keyFileTS }, { storFile: storFileCss, keyFiles: keyFileCss }]) {
            if (!data.storFile)
                continue;
            if (data.storFile.status === 'deleted') {
                data.storFile.status = 'changed';
                mls.events.fireFileAction('statusOrErrorChanged', data.storFile, this.position);
                continue;
            }
            if (data.storFile.status === 'renamed') {
                throw new Error('not implemented');
            }
            if (data.storFile.extension === '.ts') {
                // clear memory changes and localstor changes
                const imFile = mls.l2.editor.editors[this.confE];
                if (imFile.project === data.storFile.project && imFile.shortName === data.storFile.shortName)
                    await this.createModelTS_testFile(); // show test file
                mls.l2.editor.remove(data.storFile);
                this.removeEventsModelTS(data.storFile);
            }
            await mls.stor.localStor.setContent(data.storFile, { contentType: 'string', content: null });
            if (data.storFile.status === 'new') {
                delete mls.stor.files[data.keyFiles];
                mls.events.fireFileAction('statusOrErrorChanged', data.storFile, this.position);
                continue;
            }
            if (data.storFile.status === 'changed') {
                data.storFile.status = 'nochange';
                if (data.storFile.isLocalVersionOutdated && data.storFile.newVersionRefIfOutdated) {
                    data.storFile.versionRef = data.storFile.newVersionRefIfOutdated;
                    data.storFile.isLocalVersionOutdated = false;
                    data.storFile.newVersionRefIfOutdated = undefined;
                }
            }
            else {
                data.storFile.status = 'changed';
            }
            if (data.storFile.extension === '.ts')
                await this.createModelTS2(data.storFile, false, true);
            else {
                const uri = this.getUri(`_${data.storFile.project}_${data.storFile.shortName}`, '.html');
                const model = monaco.editor.getModel(uri);
                if (model)
                    model.dispose();
                await this.createOrShowModelHtmlOrCss(false, '.html');
                await this.createOrShowModelHtmlOrCss(false, '.less');
            }
            mls.events.fireFileAction('statusOrErrorChanged', data.storFile, this.position);
        }
        ;
    }
    activeThisService() {
        this.openMe();
        mls.editor.setActiveInstance(this.level, this.position);
    }
    closeMenu() {
        if (this.menu.closeMenu)
            this.menu.closeMenu();
    }
    async updateModelStatus(mfile, changed) {
        if (mfile.project === 0)
            changed = true; // always in localstorage
        mfile.changed = changed;
        const cr = await mls.l2.editor.getCompilerResultTS({ project: mfile.project, shortName: mfile.shortName }, true);
        let hasError = cr.errors.length > 0;
        mfile.error = hasError;
        const key = mls.stor.getKeyToFiles(mfile.project, this.level, mfile.shortName, '', mfile.extension);
        const storFile = mls.stor.files[key];
        if (!hasError) {
            const enhancementInstance = await mls.l2.enhancement.getEnhancementInstance(mfile).catch((e) => undefined);
            if (enhancementInstance)
                await enhancementInstance.onAfterChange(mfile);
            hasError = storFile.hasError;
        }
        await this.changeStatusFile(mfile, storFile, cr.tripleSlashMLS?.variables, hasError);
    }
    async changeStatusFile(mfile, storFile, variables, hasError) {
        if (!storFile)
            return; // new file dont have storFile ???
        const oldStatus = storFile.status;
        storFile.hasError = hasError;
        const sameContent = mfile.originalCRC === mls.common.crc.crc32(mfile.model.getValue()).toString(16);
        if (sameContent) {
            if (storFile.status !== 'new')
                storFile.status = 'nochange';
            await mls.stor.localStor.setContent(storFile, { content: null }); // clear localstorage
        }
        else {
            if (storFile.status !== 'renamed' && (storFile.status !== 'new'))
                storFile.status = 'changed';
            await mls.stor.localStor.setContent(storFile, await this.getValueInfo(mfile));
        }
        if (oldStatus !== storFile.status) {
            mls.events.fireFileAction('statusOrErrorChanged', storFile, this.position);
        }
    }
    renameTSFile(mfile, storFile, newProject, newShortName) {
        if (storFile.hasError)
            throw new Error('Error on rename, clear errors before rename');
        if (!this.isNewNameValid(newShortName))
            throw new Error('Error on rename, new shortName is a invalid name');
        const newSts = { shortName: newShortName, project: newProject };
        if (!mls.l2.editor.rename(mfile, newSts))
            throw new Error('Error on rename mls.l2.editor.mfiles');
        if (!mls.stor.renameFile(storFile, newSts))
            throw new Error('Error on rename mls.stor.files');
        mls.common.tripleslash.changeVariable(mfile, 'shortName', newShortName);
        mls.common.tripleslash.changeVariable(mfile, 'project', newProject.toString());
        if (storFile.status === 'new')
            return;
        storFile.status = 'renamed';
    }
    isNewNameValid(newShortName) {
        if (newShortName.length === 0 || newShortName.length > 255)
            return false;
        const invalidCharacters = /[_\/{}\t\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        return (!invalidCharacters.test(newShortName));
    }
    showActiveModel() {
        let activeModel = mls.l2.editor.editors[this.confE];
        if (activeModel && activeModel.project === 0 && activeModel.shortName === 'testFile' && !this.isNewFile) {
            const ret = this.openLastFile(this.level, this.position);
            if (ret)
                activeModel = mls.l2.editor.editors[this.confE];
        }
        if (!this._ed1 || !activeModel || !this.menu.getLastMode)
            return false;
        const changedFile = this.menu.title !== activeModel.shortName;
        this.menu.title.text = `_${activeModel.project}_${activeModel.shortName}`;
        const lastMode = this.menu.getLastMode();
        if (changedFile && lastMode !== 'initial') {
            // user choice another file, goto initial editor
            this._ed1.setModel(activeModel.model);
            if (this.menu.setMode)
                this.menu.setMode('initial');
        }
        else if (lastMode === 'initial') {
            this._ed1.setModel(activeModel.model);
            if (this.menu.updateTitle)
                this.menu.updateTitle();
        }
        else if (lastMode === 'editor') {
            // dont change model , ex TS Config
        }
        else if (lastMode === 'page') {
            // in page, ex About, prepare model to after close hamburger
            this._ed1.setModel(activeModel.model);
        }
        this.c2?.setAttribute('msize', this.msize);
        return true;
    }
    async initMonaco() {
        if (!this._ed1) {
            await this.initMonaco_Editor();
            if (this.serviceContent && typeof this.serviceContent.layout === 'function')
                this.serviceContent.layout();
        }
    }
    async initMonaco_GlobalEditor() {
        this.loadMonacoConfigurations();
        if (this.monacoGlobalInitialized)
            return;
        this.monacoGlobalInitialized = true;
        this.loadMonacoThemeFromLocalStorage();
        this.updateMonacoGlobalTheme();
        mls.editor.InitMonaco();
    }
    async initMonaco_Editor() {
        const addEventsEditor = () => {
            if (!this._ed1)
                return;
            this._ed1.onDidFocusEditorWidget(() => {
                if (this.menu.lastIcon === 'icHTML')
                    return;
                mls.editor.setActiveInstance(this.level, this.position);
            });
            this._ed1.onDidChangeCursorPosition((e) => {
                this._ed1?.updateOptions({ readOnly: false });
                clearTimeout(this.timeHtmlChangeCursor);
                if (!this._ed1)
                    return;
                if (this.menu.lastIcon === 'icCss') {
                    const position = e.position;
                    const { lineNumber } = position;
                    const isReadOnlyArea = this.isReadOnlyArea(lineNumber);
                    this._ed1.updateOptions({ readOnly: isReadOnlyArea });
                    return;
                }
                if (!this._ed1 || this.menu.lastIcon !== 'icHTML')
                    return;
                const model = this._ed1.getModel();
                const position = e.position;
                if (!model)
                    return;
                this.timeHtmlChangeCursor = setTimeout(() => {
                    const lineContent = model.getLineContent(position.lineNumber);
                    if (lineContent.includes('id="')) {
                        const idValue = this.extractIdValue(lineContent);
                        if (this.lastIdSelected === idValue)
                            return;
                        this.lastIdSelected = idValue;
                        if (idValue && this.lastOrigin === 'editor') {
                            mls.events.fire(2, 'WidgetAction', `{"op":"SelectWidget", "id":"${idValue}", "origin":"editor"}`);
                        }
                        else {
                            this.lastOrigin = 'editor';
                        }
                    }
                }, 500);
            });
        };
        if (!this.c2)
            return;
        this._ed1 = monaco.editor.create(this.c2, mls.editor.conf[this.confE]);
        this.c2['mlsEditor'] = this._ed1;
        mls.editor.instances[this.confE] = this._ed1;
        mls.editor.InitEditor(this._ed1);
        addEventsEditor();
        this.createModelTS_loading();
        this.createModelConf('// loading ...'); // model 
        // global routines dont need this._ed1
        await this.createModelTS_testFile();
    }
    extractIdValue(line) {
        const idRegex = /id="([^"]*)"/;
        const match = line.match(idRegex);
        return match ? match[1] : null;
    }
    loadMonacoConfigurations() {
        if (!mls.editor.conf || Object.keys(mls.editor.conf).length === 0) {
            this.loadConfEditorFromLocalStorage();
        }
        if (mls.editor.conf[this.confE])
            return;
        mls.editor.conf[this.confE] = {
            contextmenu: true,
            autoIndent: 'full',
            wordWrap: 'on',
            wrappingIndent: 'indent',
            tabCompletion: 'on',
            renderControlCharacters: false,
            showUnused: true,
            glyphMargin: true,
            // acceptSuggestionOnEnter: "off",  // "on", "smart" -> ex: "dd" , invalid work will be get for next suggestion, bad
            minimap: { enabled: false },
            useTabStops: true,
            scrollBeyondLastColumn: 2,
            scrollBeyondLastLine: false,
            formatOnType: true,
            fixedOverflowWidgets: true,
            codeLens: true,
            showFoldingControls: 'mouseover',
            suggestSelection: 'first',
            stickyScroll: { enabled: false, maxLineCount: 3 },
            stickyTabStops: true,
            fontSize: 20,
            automaticLayout: true,
        };
    }
    getUri(shortFN, ftype) {
        return monaco.Uri.parse(`file://server/${shortFN}${ftype}`);
    }
    async createModelTS_testFile() {
        const shortName = 'testFile';
        const project = 0; // localstorage project
        const defaultTS = `/// <mls shortName="${shortName}" project="${project}" enhancement="_blank" />\n// typescript example`;
        await this.createModelTS1(shortName, project, defaultTS, true);
    }
    async createModelTS_loading() {
        const shortName = 'loading...';
        const project = 0; // localstorage project
        const defaultTS = 'wait...';
        const mfile = await this.createModelTS1(shortName, project, defaultTS, true);
        if (this.onFirtModel && this._ed1) {
            this.onFirtModel = false;
            this._ed1.setModel(mfile.model);
        }
    }
    async createModelTS_clone(storFile, newProject, newShortName) {
        let model1 = mls.l2.editor.get(storFile);
        if (!model1)
            model1 = await this.createModelTS2(storFile, false, true);
        let defaultTS = model1.model.getValue();
        const baseTag = convertFileNameToTag(`_${storFile.project}_${storFile.shortName}`);
        const newTag = convertFileNameToTag(`_${newProject}_${newShortName}`);
        const regex = new RegExp(baseTag, 'g');
        defaultTS = defaultTS.replace(regex, newTag);
        defaultTS = this.changeClassName(defaultTS, newProject, newShortName);
        model1 = await this.createModelTS1(newShortName, newProject, defaultTS, true);
        mls.common.tripleslash.changeVariable(model1, 'shortName', newShortName);
        mls.common.tripleslash.changeVariable(model1, 'project', newProject.toString());
    }
    changeClassName(source, project, shortname) {
        const regex = /export\s+class\s+(\w+)\s+extends/g;
        const match = regex.exec(source);
        const newClassName = shortname.charAt(0).toUpperCase() + shortname.substring(1, shortname.length) + project.toString();
        if (match) {
            const originalTag = match[1];
            const replacedSource = source.replace(originalTag, newClassName);
            return replacedSource;
        }
        return source;
    }
    async createModelTS1(shortName, project, defaultTS, activateModel) {
        // create new file or load project 0 file
        const level = 2;
        const extension = '.ts';
        if (project > 1)
            await mls.stor.server.loadProjectInfoIfNeeded(project);
        const key = mls.stor.getKeyToFiles(project, level, shortName, '', extension);
        let storFile = mls.stor.files[key];
        // if (storFile && project !== 0) throw new Error('Error on createModelTS1, model already exists: ' + key);
        if (!storFile) {
            storFile = await mls.stor.addOrUpdateFile({ project, level, shortName, extension, versionRef: new Date().toISOString(), folder: '' });
            if (!storFile)
                throw new Error('Invalid storFile');
            storFile.status = 'new';
        }
        let model1 = mls.l2.editor.get({ project, shortName });
        if (!model1) {
            const src = storFile ? (await storFile.getContent(defaultTS)) || defaultTS : defaultTS;
            const ftype = src.split("\n")[0].indexOf(' type="definition"') > 0 ? ".d.ts" : ".ts";
            const uri = this.getUri(`_${project}_${shortName}`, ftype);
            model1 = mls.l2.editor.get({ project, shortName });
            if (model1)
                return model1; // created in another instance
            const model = monaco.editor.createModel(src, 'typescript', uri);
            model1 = {
                changed: true,
                error: false,
                project,
                shortName,
                extension,
                model,
                storFile,
                codeLens: [],
            };
            mls.l2.editor.add(model1);
            this.addEventsModelTS(storFile, model1);
        }
        await this.updateModelStatus(model1, false); // first compilation
        if (activateModel)
            mls.l2.editor.editors[this.confE] = model1;
        return model1;
    }
    async createModelTS2(storFile, activedModel, compile) {
        // load source from repository
        const { project, shortName, extension } = storFile;
        let model1 = mls.l2.editor.get({ project, shortName });
        if (model1)
            return model1;
        const info = storFile.getValueInfo ? await storFile.getValueInfo() : null;
        const haveInfo = info && !!info.content;
        const src = haveInfo ? info?.content : await storFile.getContent();
        if (src instanceof Blob)
            throw new Error('ts file must be string');
        if (!src)
            throw new Error('ts file is undefined');
        ;
        const originalCRC = haveInfo ? info?.originalCRC : mls.common.crc.crc32(src).toString(16);
        const originalProject = haveInfo ? info?.originalProject : undefined;
        const originalShortName = haveInfo ? info?.originalShortName : undefined;
        const ftype = src.split("\n")[0].indexOf(' type="definition"') > 0 ? ".d.ts" : ".ts";
        const uri = this.getUri(`_${project}_${shortName}`, ftype);
        const model = monaco.editor.createModel(src, 'typescript', uri);
        model1 = {
            changed: false, // not changed in this section, but storFile.changed is about all sections
            error: false,
            project,
            shortName,
            extension,
            model,
            storFile,
            originalCRC,
            originalProject,
            originalShortName,
            codeLens: [],
        };
        mls.l2.editor.add(model1);
        this.addEventsModelTS(storFile, model1);
        const keyFileHtml = mls.stor.getKeyToFiles(storFile.project, 2, storFile.shortName, '', '.html');
        const keyFileCss = mls.stor.getKeyToFiles(storFile.project, 2, storFile.shortName, '', '.less');
        const storFileHtml = mls.stor.files[keyFileHtml];
        const storFileCss = mls.stor.files[keyFileCss];
        if (storFileHtml) {
            if (!this.htmlModelAlreadyProcessed[keyFileHtml]) {
                this.htmlModelAlreadyProcessed[keyFileHtml] = true;
                await this.getOrCreateModelHtmlOrCss(storFile.shortName, storFile.project, '.html', storFileHtml);
            }
        }
        if (storFileCss)
            await this.getOrCreateModelHtmlOrCss(storFile.shortName, storFile.project, '.less', storFileCss);
        if (compile) {
            await this.updateModelStatus(model1, false);
        }
        if (activedModel) {
            mls.l2.editor.editors[this.confE] = model1;
        }
        return model1;
    }
    setModelConfEditor() {
        if (!this._ed1 || !this.mConfEditor)
            return;
        const src = this.getConfEditorToTypescript();
        this.mConfEditor['mlsConf'] = 'confEditor';
        this.mConfEditor.setValue(src);
        this._ed1.setModel(this.mConfEditor);
    }
    async createModelConf(src) {
        if (mls.istrace)
            console.log(`ServiceSource, createModelConf_${this.position}, ${!!this.mConfEditor}`);
        if (this.mConfEditor)
            return;
        const shortName = this.confE + '_service_source.confEditor';
        const level = 2;
        const project = 0;
        const extension = '.ts';
        const storFile = await mls.stor.addOrUpdateFile({ project, level, shortName, extension, versionRef: new Date().toISOString(), folder: '' });
        if (!storFile)
            throw new Error('Invalid storFile');
        const uri = this.getUri(shortName, extension);
        const model = monaco.editor.getModel(uri);
        if (model) {
            this.mConfEditor = model;
        }
        else
            this.mConfEditor = monaco.editor.createModel(src, 'typescript', uri);
        mls.l2.editor.add({
            changed: false,
            error: false,
            model: this.mConfEditor,
            storFile,
            project: 0,
            shortName,
            extension,
            codeLens: [],
        });
        this.mConfEditor.onDidChangeContent((e) => {
            const mode = this.mConfEditor['mlsConf'];
            if (!mode || !this.mConfEditor)
                return;
            src = this.mConfEditor.getValue();
            this.compileSrcEditor(mode, src);
        });
    }
    compileSrcEditor(mode, src) {
        // wait 500ms to get diagnostics
        clearTimeout(this.timeout_compileConfEditor);
        this.timeout_compileConfEditor = window.setTimeout(async () => {
            if (!this.mConfEditor)
                return;
            const mmodel = mls.l2.editor.find(this.mConfEditor.id);
            // console.info(`js compiled, model id=${this.mConfEditor.id}, model found=${!!mmodel}`);
            if (!mmodel)
                return; // not in model
            const rcc = await mls.l2.editor.getCompilerResultTS(mmodel, true);
            if (rcc.errors.length !== 0 || !rcc.prodJS)
                return;
            if (mode === 'confEditor')
                this.setConfEditorFromJavascript(rcc.prodJS, src);
        }, 500);
    }
    loadConfEditorFromLocalStorage() {
        const json = localStorage.getItem('mlsConfEditor');
        if (json) {
            mls.editor.loadConfFromJSON(json);
        }
    }
    saveConfEditorToLocalStorage() {
        localStorage.setItem('mlsConfEditor', JSON.stringify(mls.editor.conf));
    }
    loadMonacoThemeFromLocalStorage() {
        if (!mls.editor.themeName)
            mls.editor.setThemeName(localStorage.getItem('mlsConfTheme'));
    }
    saveMonacoGlobalThemeToLS() {
        localStorage.setItem('mlsConfTheme', mls.editor.themeName);
    }
    getConfEditorToTypescript() {
        return `/// <mls shortName="config_monaco_editor" project="0" enhancement="_blank" />
		
mls.editor.conf['${this.confE}'] = ` + JSON.stringify(mls.editor.conf[this.confE], null, 2) + ';\n';
    }
    setConfEditorFromJavascript(javastr, src) {
        if (this.level < 1)
            return;
        const that = this;
        (function scope() {
            eval(javastr); // eslint-disable-line no-eval
            if (mls.editor.conf[that.confE] && typeof mls.editor.conf[that.confE] === 'object') {
                // mls.editor.loadConf(that.confETS, src);
                that.updateMonacoConfigutarions();
                that.saveConfEditorToLocalStorage();
            }
        }).call(this); // eval in context scopeDesenv https://stackoverflow.com/questions/8403108/calling-eval-in-particular-context
    }
    async updateMonacoConfigutarions() {
        if (this._ed1)
            this._ed1.updateOptions(mls.editor.conf[this.confE]);
    }
    updateMonacoGlobalTheme() {
        let rc = true;
        if (mls.istrace)
            console.log(`service source, updating monaco theme: ${this.position}`);
        const internalThemes = ['VS', 'VS Dark', 'High Contrast (Dark)'];
        const internalThemes2 = ['vs', 'vs-dark', 'hc-black', 'hc-light'];
        let name2 = ''; // name to use , internal name or mytheme
        try {
            const internalIndex = internalThemes.indexOf(mls.editor.themeName);
            if (internalIndex < 0) {
                // load and define theme
                name2 = 'mytheme';
                const path = mls.baseMonaco + '../themes/' + mls.editor.themeName + '.json';
                mls.api.base.get(path, {}, (data) => {
                    const json = JSON.parse(data);
                    monaco.editor.defineTheme(name2, json);
                    monaco.editor.setTheme(name2);
                });
            }
            else {
                name2 = internalThemes2[internalIndex];
                monaco.editor.setTheme(name2);
            }
        }
        catch (ex) {
            console.error('error on set theme ' + name2, ex);
            rc = false;
        }
        return rc;
    }
    getGlobalPageSetTHeme() {
        const div1 = document.createElement('div');
        div1.innerHTML = `<div>` // eslint-disable-line
            + `<p id='theme-actual'>Theme actual: ${mls.editor.themeName} </p><br>`
            + `<p>Set Theme (only 1 theme in all editors)</p>` // eslint-disable-line
            // eslint-disable-next-line
            + `<select class="hidden" id="theme-select" style="display: initial;"><option>select ...</option><option value="vs">VS</option><option value="vs-dark">VS Dark</option><option value="hc-black">High Contrast (Dark)</option><option value="active4d">Active4D</option><option value="all-hallows-eve">All Hallows Eve</option><option value="amy">Amy</option><option value="birds-of-paradise">Birds of Paradise</option><option value="blackboard">Blackboard</option><option value="brilliance-black">Brilliance Black</option><option value="brilliance-dull">Brilliance Dull</option><option value="chrome-devtools">Chrome DevTools</option><option value="clouds-midnight">Clouds Midnight</option><option value="clouds">Clouds</option><option value="cobalt">Cobalt</option><option value="cobalt2">Cobalt2</option><option value="dawn">Dawn</option><option value="dracula">Dracula</option><option value="dreamweaver">Dreamweaver</option><option value="eiffel">Eiffel</option><option value="espresso-libre">Espresso Libre</option><option value="github">GitHub</option><option value="idle">IDLE</option><option value="katzenmilch">Katzenmilch</option><option value="kuroir-theme">Kuroir Theme</option><option value="lazy">LAZY</option><option value="magicwb--amiga-">MagicWB (Amiga)</option><option value="merbivore-soft">Merbivore Soft</option><option value="merbivore">Merbivore</option><option value="monokai-bright">Monokai Bright</option><option value="monokai">Monokai</option><option value="night-owl">Night Owl</option><option value="oceanic-next">Oceanic Next</option><option value="pastels-on-dark">Pastels on Dark</option><option value="slush-and-poppies">Slush and Poppies</option><option value="solarized-dark">Solarized-dark</option><option value="solarized-light">Solarized-light</option><option value="spacecadet">SpaceCadet</option><option value="sunburst">Sunburst</option><option value="textmate--mac-classic-">Textmate (Mac Classic)</option><option value="tomorrow-night-blue">Tomorrow-Night-Blue</option><option value="tomorrow-night-bright">Tomorrow-Night-Bright</option><option value="tomorrow-night-eighties">Tomorrow-Night-Eighties</option><option value="tomorrow-night">Tomorrow-Night</option><option value="tomorrow">Tomorrow</option><option value="twilight">Twilight</option><option value="upstream-sunburst">Upstream Sunburst</option><option value="vibrant-ink">Vibrant Ink</option><option value="xcode-default">Xcode_default</option><option value="zenburnesque">Zenburnesque</option><option value="iplastic">iPlastic</option><option value="idlefingers">idleFingers</option><option value="krtheme">krTheme</option><option value="monoindustrial">monoindustrial</option></select>`;
        const sel = div1.querySelector('#theme-select');
        if (!sel)
            return div1;
        sel.oninput = (ev) => {
            if (ev?.srcElement?.localName === 'select') {
                const el = ev.srcElement;
                const actual = div1.querySelector('#theme-actual');
                if (el.selectedIndex < 1)
                    return; // option 0 is select ...
                mls.editor.setThemeName(el.options?.[el.selectedIndex].text || 'default');
                this.saveMonacoGlobalThemeToLS();
                this.updateMonacoGlobalTheme();
                if (actual)
                    actual.innerHTML = `Theme changed to: ${mls.editor.themeName}`;
            }
        };
        return div1;
    }
    // HTML LESS
    async createOrShowModelHtmlOrCss(open, mode, fileInfo) {
        let shortName = '';
        let project = 0;
        const conf = mls.l2.editor.editors[this.confE];
        shortName = conf.shortName;
        project = conf.project;
        const uri = this.getUri(`_${project}_${shortName}`, mode);
        let model = monaco.editor.getModel(uri);
        const key = mls.stor.getKeyToFiles(project, this.level, shortName, '', mode);
        let storFile = mls.stor.files[key];
        if (!storFile) {
            if (mode === '.less') {
                const newLess = await this.prepareInitialLess(shortName, project);
                await this.createHtmlOrCssFile(project, shortName, newLess, mode);
            }
            else {
                await this.createHtmlOrCssFile(project, shortName, `<h1>_${project}_${shortName}</h1>`, mode);
            }
            storFile = mls.stor.files[key];
        }
        if (!model) {
            model = await this.getOrCreateModelHtmlOrCss(shortName, project, mode, storFile, fileInfo);
            let mfile = mls.l2.editor.get({ project, shortName });
            if (mfile)
                mfile.modelHTML = model;
        }
        if (open && this._ed1)
            this._ed1.setModel(model);
        if (mode === '.html' && this._ed1 && this._ed1.getModel()?.id !== model.id) {
            mls.events.fireFileAction('modeCreated', storFile, this.position);
            this.registerProviderHTML();
        }
        return storFile;
    }
    async prepareInitialLess(shortName, project) {
        const details = await getAddNewFileDetails();
        const tag = convertFileNameToTag(`_${project}_${shortName}`);
        const newStyle = details[0].example
            .replace('[shortName]', shortName)
            .replace('[project]', project.toString())
            .replace('[tag]', tag);
        return newStyle;
    }
    async createHtmlOrCssFile(project, shortName, content, extension) {
        const params = {
            project,
            level: 2,
            shortName,
            extension,
            versionRef: '0',
            folder: ''
        };
        const file = await mls.stor.addOrUpdateFile(params);
        if (!file)
            throw new Error('Invalid storFile');
        file.status = 'new';
        const fileInfo = {
            content,
            contentType: 'string',
        };
        await mls.stor.localStor.setContent(file, fileInfo);
    }
    async getOrCreateModelHtmlOrCss(shortName, project, ext, storFile, fileInfo) {
        let mfile = mls.l2.editor.get({ project, shortName });
        if (!mfile)
            throw new Error('Invalid mfile');
        const uri = this.getUri(`_${project}_${shortName}`, ext);
        let language = ext.substring(1, ext.length);
        const modelName = `model${ext === '.html' ? 'HTML' : 'LESS'}`;
        let model = monaco.editor.getModel(uri);
        if (model)
            return model;
        const content = fileInfo ? fileInfo.content : await storFile.getContent();
        if (content instanceof Blob)
            throw new Error('less file must be string');
        if (!content)
            throw new Error('less file is undefined');
        ;
        model = monaco.editor.createModel(content, language, uri);
        if (mfile)
            mfile[modelName] = model;
        model['position'] = this.position;
        const originalCRC = fileInfo ? fileInfo?.originalCRC : mls.common.crc.crc32(content).toString(16);
        model['originalCRC'] = originalCRC;
        storFile['originalCRC'] = storFile.inLocalStorage ? 'undefined' : mls.common.crc.crc32(model.getValue()).toString(16);
        if (storFile.status === 'renamed' && fileInfo) {
            this.setEventsModelHTMLOrCss(mfile, model, storFile, fileInfo.originalShortName, fileInfo.originalProject, ext);
            model.setValue(fileInfo.content);
        }
        else {
            this.setEventsModelHTMLOrCss(mfile, model, storFile, storFile.shortName, storFile.project, ext);
        }
        return model;
    }
    setEventsModelHTMLOrCss(mfile, model, storFile, shortName, project, ext) {
        storFile.onAction = (action) => this.afterUpdateHtmlOrCss(storFile, model);
        storFile.getValueInfo = () => this.getValueInfoHtmlOrCss(model, shortName, project, storFile['originalCRC']);
        if (!model)
            return;
        model.onDidChangeContent((e) => this.onModelHtmlOrCssChange(e, mfile, storFile, model, ext));
    }
    async afterUpdateHtmlOrCss(storFile, model) {
        if (storFile.status === 'deleted') {
            await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
            const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
            delete mls.stor.files[keyFiles];
            return;
        }
        if (storFile.status === 'renamed') {
            storFile['originalCRC'] = mls.common.crc.crc32(model.getValue()).toString(16);
        }
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        storFile.status = 'nochange';
    }
    onModelHtmlOrCssChange(e, mfile, storFile, model, ext) {
        // some changes is to simulate changes to force compile
        clearTimeout(this._onChangedContentHtmlOrCss);
        this._onChangedContentHtmlOrCss = window.setTimeout(async () => {
            const enhancementInstance = await mls.l2.enhancement.getEnhancementInstance(mfile).catch((e) => undefined);
            if (enhancementInstance)
                await enhancementInstance.onAfterChange(mfile);
            let modelValue = model.getValue();
            if (ext === '.less') {
                modelValue = removeTokensFromSource(modelValue);
            }
            const sameContent = storFile['originalCRC'] === mls.common.crc.crc32(modelValue).toString(16);
            if (sameContent) {
                if (storFile.status !== 'new' && storFile.status !== 'renamed')
                    storFile.status = 'nochange';
                if (storFile.status !== 'renamed')
                    await mls.stor.localStor.setContent(storFile, { content: null }); // clear localstorage
            }
            else {
                if (storFile.status !== 'renamed' && (storFile.status !== 'new'))
                    storFile.status = 'changed';
                await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: modelValue });
            }
            if (mls.istrace)
                console.info('fire model html');
            if (this.isHTMLSystemChange) {
                this.isHTMLSystemChange = false;
                return;
            }
            mls.events.fireFileAction('statusOrErrorChanged', storFile, this.position);
        }, 400);
    }
    ;
    async renameHTMLOrCssFile(mfile, storFile, newProject, newShortName, ext) {
        if (!storFile)
            return;
        const newSts = { shortName: newShortName, project: newProject };
        await this.getOrCreateModelHtmlOrCss(storFile.shortName, storFile.project, ext, storFile);
        if (!storFile.getValueInfo)
            return;
        const valueInfo = await storFile.getValueInfo();
        const { status } = storFile;
        if (!mls.stor.renameFile(storFile, newSts))
            throw new Error('Error on rename mls.stor.files');
        const key = mls.stor.getKeyToFiles(newProject, this.level, newShortName, '', ext);
        const newStorFile = mls.stor.files[key];
        newStorFile.status = 'renamed';
        if (ext === '.less') {
            const modelStyle = mfile['modelStyle'];
            mls.common.tripleslash.changeVariable(modelStyle, 'shortName', newShortName);
            mls.common.tripleslash.changeVariable(modelStyle, 'project', newProject.toString());
        }
        await mls.stor.localStor.setContent(newStorFile, valueInfo);
        setTimeout(async () => {
            const file = await this.createOrShowModelHtmlOrCss(false, ext, valueInfo);
            if (status === 'new')
                file.status = status;
        }, 500);
    }
    isReadOnlyArea(lineNumber) {
        const obj = this.getIntervalLinesReadOnly();
        if (!obj)
            return false;
        if (!obj.end || !obj.start)
            return false;
        if (lineNumber >= obj.start && lineNumber <= obj.end)
            return true;
        return false;
    }
    getIntervalLinesReadOnly() {
        if (!this._ed1)
            return;
        const model = this._ed1.getModel();
        if (!model)
            return;
        const [startLine] = model.findMatches(`//Start Less Tokens`, true, false, false, null, true);
        const [endLine] = model.findMatches(`//End Less Tokens`, true, false, false, null, true);
        return {
            end: endLine ? endLine.range.startLineNumber : undefined,
            start: startLine ? startLine.range.startLineNumber : undefined
        };
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            this.c2?.setAttribute('msize', this.msize);
        }
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.registerProviderHTML();
    }
    render() {
        return html `
            <mls-editor-100529 ismls2="true"></mls-editor-100529>
        `;
    }
    saveLocalStorageLastOpen(storFile, position) {
        try {
            let last = localStorage.getItem('_100554_serviceSource');
            last = last ? last : '{}';
            const info = JSON.parse(last);
            const keyLocal = 'last_' + this.level + '_' + position;
            if (info[keyLocal]) {
                info[keyLocal].project = storFile.project;
                info[keyLocal].shortName = storFile.shortName;
                info[keyLocal].extension = storFile.extension;
                info[keyLocal].level = storFile.level;
                info[keyLocal].folder = storFile.folder;
            }
            else {
                info[keyLocal] = {
                    project: storFile.project,
                    shortName: storFile.shortName,
                    extension: storFile.extension,
                    level: storFile.level,
                    folder: storFile.folder,
                };
            }
            localStorage.setItem('_100554_serviceSource', JSON.stringify(info));
        }
        catch (e) {
            localStorage.setItem('_100554_serviceSource', JSON.stringify({}));
        }
    }
    openLastFile(level, position) {
        try {
            let last = localStorage.getItem('_100554_serviceSource');
            last = last ? last : '{}';
            const info = JSON.parse(last);
            const keyLocal = 'last_' + level + '_' + position;
            if (!info[keyLocal])
                return false;
            const key = mls.l2.getKey({
                project: +info[keyLocal].project,
                shortName: info[keyLocal].shortName
            });
            const model = mls.l2.editor.mfiles[key];
            if (!model)
                return false;
            mls.l2.editor.editors[this.confE] = model;
            mls.actual[this.level].setFullName(`_${info[keyLocal].project}_${info[keyLocal].shortName}`);
            mls.actual[this.level][position] = {
                project: model.storFile.project,
                shortName: model.storFile.shortName,
                extension: model.storFile.extension,
                folder: model.storFile.folder
            };
            return true;
        }
        catch (e) {
            return false;
        }
    }
    getActualRef() {
        try {
            let ret = '';
            if (!mls.actual[2] || !mls.actual[2][this.position])
                return ret;
            const actual = mls.actual[2][this.position];
            const ext = this.menu.lastIcon === 'icTs' ? '.ts' : '.html';
            if (!actual)
                return ret;
            ret = mls.stor.getKeyToFiles(actual.project, 2, actual.shortName, actual.folder, ext);
            return ret;
        }
        catch (e) {
            return '';
        }
    }
    onWidgetActionEvents(ev) {
        if (this.position === 'right')
            return;
        if (ev.level !== this.level)
            return;
        if (!ev.desc)
            return;
        const json = JSON.parse(ev.desc);
        switch (json.op) {
            case 'SelectWidget':
                break;
            case 'SelectLine':
                this.selectLineinHTML(json.line, json.origin);
                break;
            case 'OpenScenario':
                this.openScenario(json);
                break;
            case 'CreateOrSetEvent':
                this.createOrSetEvent(json);
                break;
            case 'CreateOrSetEventPR':
                this.createOrSetEventPR(json);
                break;
            default:
                console.info('Erro: opção invalida');
        }
    }
    selectLineinHTML(line, origin) {
        if (this.menu.lastIcon !== 'icHTML' || !this._ed1)
            return;
        this.lastOrigin = origin;
        if (origin === 'editor')
            return;
        this.goToLine(line);
    }
    openScenario(json) {
        window.infoScenarioInsertOrCreateEvent = {
            id: json.id,
            value: json.value
        };
        this.lastScenario = json.widget;
        this.addScenario(json.widget);
    }
    closeScenario() {
        if (!this.lastScenario)
            return;
        this.removeScenario(this.lastScenario);
    }
    createOrSetEvent(json) {
        //{"op":"CreateOrSetEvent", "id":"test", "event":"click", "device":"desktop"}
        let isExistEVentInHTML = this.isEventExist(json.id, json.event);
        let isExistEVentInTS = false;
        const nameFc = getEventName(json.event, json.id, json.device);
        if (isExistEVentInHTML) {
            const line = this.searchLineByStringTs(nameFc);
            if (line && this.menu.setIconActive) {
                isExistEVentInTS = true;
                this.menu.setIconActive('icTs');
                this.goToLine(line);
            }
        }
        if (!isExistEVentInTS) {
            if (!isExistEVentInHTML)
                this.setEventInHTml(json.id, json.event);
            setTimeout(() => {
                const str = `private ${nameFc}(){\n//Edit here your event ${json.event} code\n\n}`;
                const line = this.searchLineByStringTs('/// **collab_events_start**');
                if (!line)
                    throw new Error('Not found collab_events_start');
                this.setEditorValueByLineTs(str, line + 1);
            }, 500);
        }
        this.closeScenario();
    }
    createOrSetEventPR(json) {
        //{"op":"CreateOrSetEvent", "id":"test", "event":"click", "device":"desktop", "func":""}
        let isExistEventInHTML = this.isEventExist(json.id, json.event);
        let isExistEventInTS = false;
        const nameFc = getEventName(json.event, json.id, json.device);
        if (isExistEventInHTML) {
            const line = this.searchLineByStringTs(nameFc);
            if (line && this.menu.setIconActive) {
                isExistEventInTS = true;
                this.menu.setIconActive('icTs');
                this.goToLine(line);
            }
        }
        if (!isExistEventInTS) {
            if (!isExistEventInHTML)
                this.setEventInHTml(json.id, json.event);
            setTimeout(() => {
                const str = `private ${nameFc}${json.func}`;
                const line = this.searchLineByStringTs('/// **collab_events_start**');
                if (!line)
                    throw new Error('Not found collab_events_start');
                this.setEditorValueByLineTs(str, line + 1);
            }, 500);
        }
        this.closeScenario();
    }
    isEventExist(id, event) {
        let isExist = false;
        const strHtml = this.getEditorHTMLValue();
        const html = document.createElement('div');
        html.innerHTML = strHtml;
        const el = html.querySelector('#' + id);
        if (el && el.dataset && el.dataset.event) {
            const events = el.dataset.event.split(' ');
            isExist = events.includes(event);
        }
        return isExist;
    }
    setEventInHTml(id, event) {
        const strHtml = this.getEditorHTMLValue();
        const html = document.createElement('div');
        html.innerHTML = strHtml;
        const el = html.querySelector('#' + id);
        if (!el)
            return;
        if (el.dataset && el.dataset.event) {
            const events = el.dataset.event.split(' ');
            if (!events.includes(event)) {
                events.push(event);
                el.dataset.event = events.join(' ');
            }
        }
        else {
            el.setAttribute('data-event', event);
        }
        if (!this._ed1)
            return;
        const { shortName, project } = mls.l2.editor.editors[this.confE];
        const uri = this.getUri(`_${project}_${shortName}`, '.html');
        if (this.menu.setIconActive)
            this.menu.setIconActive('icHTML');
        let model = monaco.editor.getModel(uri);
        if (!model)
            return;
        model.setValue(html.innerHTML);
    }
    registerProviderHTML() {
        monaco.languages.registerDocumentFormattingEditProvider('html', {
            provideDocumentFormattingEdits: (model) => {
                const value = model.getValue();
                const formattedValue = formatHtml(value);
                return [{
                        range: model.getFullModelRange(),
                        text: formattedValue
                    }];
            }
        });
    }
    async checkToCreateModelHTML(ev) {
        if (!ev.desc)
            return;
        if (this.position === 'right')
            return;
        try {
            const iPath = JSON.parse(ev.desc);
            if (!iPath || !iPath.project || !iPath.shortName)
                return;
            const keyStorFile = mls.stor.getKeyToFiles(iPath.project, 2, iPath.shortName, '', '.html');
            const storFile = mls.stor.files[keyStorFile];
            if (!storFile)
                throw new Error('Invalid stor file for path:' + keyStorFile);
            if (!this.htmlModelAlreadyProcessed[keyStorFile]) {
                this.htmlModelAlreadyProcessed[keyStorFile] = true;
                await this.getOrCreateModelHtmlOrCss(storFile.shortName, storFile.project, '.html', storFile);
            }
            mls.events.fire([2, 3, 4, 5, 6, 7], 'ModelHTMLCreated', ev.desc);
        }
        catch (err) {
            throw new Error(err);
        }
    }
};
ServiceSource100554.projectsLoaded = [];
__decorate([
    property({ type: String })
], ServiceSource100554.prototype, "msize", void 0);
__decorate([
    query('mls-editor-100529')
], ServiceSource100554.prototype, "c2", void 0);
ServiceSource100554 = ServiceSource100554_1 = __decorate([
    customElement('service-source-100554')
], ServiceSource100554);
export { ServiceSource100554 };
