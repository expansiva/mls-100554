/// <mls shortName="serviceSource" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ServiceSource100554_1;
import { html } from 'lit';
import { customElement, query, property } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { ServiceBase } from './_100554_serviceBase';
import { formatHtml, sync } from './_100554_collabDOMSync';
import { removeTokensFromSource } from './_100554_enhancementStyle';
import { getTokensLess } from './_100554_designSystemBase';
import { LessCSS } from "./_100554_lessCSS";
import { getEnhancementName } from './_100554_libCommom';
import { globalState } from './_100554_collabState';
import { propertyDataSource } from './_100554_collabDecorators';
import { setErrorOnModel } from './_100554_validateLit';
import { collab_html, collab_typescript, collab_less, collab_fileTest, collab_file_code } from './_100554_collabIcons';
import { createAgent } from './_100554_agentFix';
import { getUserIdLocalStorage, getTemporaryContext } from './_100554_aiAgentHelper';
import { loadChatPreferences } from './_100554_collabMessageHelper';
import './_100554_collabSpliterVerticalVarFixed';
import './_100554_collabSpliterHorizontalVarFixed';
import './_100554_cssHelperIndex';
/// **collab_i18n_start**
const message_pt = {
    historyOpen: 'Aberto',
    historyClose: 'Fechado',
};
const message_en = {
    historyOpen: 'Closed',
    historyClose: 'Opened',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceSource100554 = ServiceSource100554_1 = class ServiceSource100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-nav-3-service[data-service="_100554_serviceSource"] .tabs li{display:flex;align-items:center}collab-nav-3-service[data-service="_100554_serviceSource"] .tabs li:not(.active) svg{filter:grayscale(100%) brightness(100%) opacity(90%)}collab-nav-3-service[data-service="_100554_serviceSource"] svg{display:flex;width:16px !important;height:16px !important;fill:currentColor}service-source-100554 .overlay-loading{position:absolute;width:100%;height:100%;top:38px;background:#cecece;z-index:9998;opacity:.9}service-source-100554 .overlay-loading>span{display:flex;justify-content:center;align-items:center;width:100%;height:100%}service-source-100554 .overlay-loading .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}`);
        this.msize = '';
        this.panelRightOpened = false;
        this.isModeHistory = false;
        this.mode = 'icTs';
        this.textOverlayLoading = '';
        this.currentHistorySourceWithoutSave = undefined;
        this.previousHistorySourceWithoutSave = undefined;
        this.currentHistorySource = undefined;
        this.previousHistorySource = undefined;
        this.historyLanguage = 'typescript';
        this.lockMap = new Map();
        this.MINWIDTHTPANELRIGHT = 500;
        this.viewState = {};
        this.msg = messages['en'];
        this.onClickTabs = (op) => {
            this.saveViewState();
            this.mode = EToolsSource[op];
            this.selectedMode = EToolsSource[op];
            if (this.isModeHistory && this.menu.selectTool)
                this.menu.selectTool('History');
            if (op === EToolsSource.icTs)
                this.showActiveModel();
            if (op === EToolsSource.icHTML) {
                if (!this.activeModels || !this.activeModels.html || !this.activeModels.html.storFile)
                    return;
                this.createOrShowModelHtmlCssTestDefs(this.activeModels.html.storFile.shortName, this.activeModels.html.storFile.project, true, '.html');
            }
            if (op === EToolsSource.icStyle) {
                if (!this.activeModels || !this.activeModels.html || !this.activeModels.html.storFile)
                    return;
                this.createOrShowModelHtmlCssTestDefs(this.activeModels.html.storFile.shortName, this.activeModels.html.storFile.project, true, '.less');
            }
            if (op === EToolsSource.icTest) {
                if (!this.activeModels || !this.activeModels.ts || !this.activeModels.ts.storFile)
                    return;
                this.createOrShowModelTsTest(this.activeModels.ts.storFile.shortName, this.activeModels.ts.storFile.project, true);
            }
            if (op === EToolsSource.icDefs) {
                if (!this.activeModels || !this.activeModels.ts || !this.activeModels.ts.storFile)
                    return;
                this.createOrShowModelTsDefs(this.activeModels.ts.storFile.shortName, this.activeModels.ts.storFile.project, true);
            }
        };
        this.onClickTitle = () => {
            this.openService('_100554_serviceProject', this.position, 2, { activeTab: 'Explore' });
        };
        this.details = {
            icon: '&#xf121',
            state: 'background',
            tooltip: 'Source',
            visible: true,
            position: "all",
            widget: '_100554_serviceSource',
            level: [2]
        };
        this.menu = {
            title: {
                icon: '&#xf053',
                text: 'L2 - widget1'
            },
            main: {
                opTheme: 'Editor - Themes',
                opMonacoConfig: 'Editor - config',
                opMonacoReset: 'Editor - reset',
                opHistory: 'History',
                opView: 'View on repository',
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [
                    { text: 'Typescript', icon: collab_typescript.strings[0].trim() },
                    { text: 'HTML', icon: collab_html.strings[0].trim() },
                    { text: 'Style', icon: collab_less.strings[0].trim() },
                    { text: 'Test', icon: collab_fileTest.strings[0].trim() },
                    { text: 'Defs', icon: collab_file_code.strings[0].trim() },
                ]
            },
            tools: {
                History: {
                    type: 'cycle',
                    selected: 0,
                    options: [
                        { text: this.msg.historyOpen, icon: 'f017' },
                        { text: this.msg.historyClose, icon: 'f057' },
                    ]
                },
            },
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
            onClickTools: this.onClickTools.bind(this),
            onClickTitle: this.onClickTitle.bind(this),
        };
        this.last = undefined;
        this._onChangedContent = undefined;
        this.onModelChange = (e, activeModel, storFile) => {
            // some changes is to simulate changes to force compile
            clearTimeout(this._onChangedContent);
            this._onChangedContent = window.setTimeout(async () => {
                const ignoreChanges = (e.changes.length === 1 && e.changes[0].range.startLineNumber === 1 && e.changes[0].range.endLineNumber === 1 && e.changes[0].range.endColumn <= 2);
                await this.updateModelStatus(activeModel, !ignoreChanges);
            }, 400);
        };
        this.getValueInfo = async (activeModel) => {
            const rc = {
                content: activeModel.model.getValue(),
                contentType: 'string',
                originalShortName: activeModel.originalShortName,
                originalProject: activeModel.originalProject,
                originalCRC: activeModel.originalCRC
            };
            return rc;
        };
        this.onProjectLoadedEvents = async (ev) => {
            if (ev.level !== this.level)
                return;
            if (!ev.desc)
                return;
            if (this.position === 'right')
                return;
            try {
                const projectLoadedInfo = JSON.parse(ev.desc);
                await this.readProjectTypescriptAndCompile(projectLoadedInfo.project, '', projectLoadedInfo.needCompile);
            }
            catch (e) {
                console.error('Error on serviceSource_onProjectLoadedEvents: ', e);
            }
        };
        this.onMLSEvents = async (ev) => {
            if (ev.level !== 2 || (ev.type !== 'FileAction'))
                return;
            if (!ev.desc)
                return;
            const fileAction = JSON.parse(ev.desc);
            if (fileAction.position !== this.position)
                return;
            let keyFiles; // set on getStorFile 
            let keyFilesHTML; // set on getStorFile 
            let keyFilesCss; // set on getStorFile 
            let keyFileTsTest; // set on getStorFile 
            let keyFileTsDefs; // set on getStorFile ;
            const getStorFile = () => {
                keyFiles = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, fileAction.extension);
                const storFile = mls.stor.files[keyFiles];
                if (!storFile)
                    throw new Error('Error on open, mls.stor.files dont exists, key:' + keyFiles);
                return storFile;
            };
            const getStorFileHTML = () => {
                keyFilesHTML = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, '.html');
                return mls.stor.files[keyFilesHTML];
            };
            const getStorFileCss = () => {
                keyFilesCss = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, '.less');
                return mls.stor.files[keyFilesCss];
            };
            const getStorFileTsTest = () => {
                keyFileTsTest = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, '.test.ts');
                return mls.stor.files[keyFileTsTest];
            };
            const getStorFileTsDefs = () => {
                keyFileTsDefs = mls.stor.getKeyToFiles(fileAction.project, fileAction.level, fileAction.shortName, fileAction.folder, '.defs.ts');
                return mls.stor.files[keyFileTsDefs];
            };
            const onNew = async () => {
                this.loading = true;
                const openPreview = fileAction.openPreview != undefined ? fileAction.openPreview : true;
                await this.newFiles(fileAction.newshortName, fileAction.newProject, fileAction.newEnhancement, fileAction.newTSSource, fileAction.newHtmlSource, fileAction.newHtmlLess, fileAction.newHtmlTest, fileAction.newHtmlDefs, openPreview);
                this.loading = false;
            };
            const onOpen = async () => {
                this.loading = true;
                const storFile = getStorFile();
                const storFileHTML = getStorFileHTML();
                const storFileCss = getStorFileCss();
                const storFileTsTest = getStorFileTsTest();
                const storFileTsDefs = getStorFileTsDefs();
                await this.openFiles(storFileHTML, storFile, storFileCss, storFileTsTest, storFileTsDefs, fileAction.position);
                mls.events.fireFileAction('statusOrErrorChanged', storFile, this.position);
                this.updatedMSizeEditor();
                this.toogleIconsError(this.position);
                const pageActual = this.getActualL2File();
                if (pageActual) {
                    const isLocked = this.isEditorLocked(pageActual);
                    if (isLocked)
                        this.lockEditorForFile(pageActual);
                    else
                        this.unlockEditorForFile(pageActual);
                    this.toogleOverlayLoading(isLocked, 'Executing agent Fix...');
                }
                if (this.horizontalSpliter && this.horizontalSpliter.resizeItens)
                    this.horizontalSpliter.resizeItens();
                this.loading = false;
            };
            const onDelete = async () => {
                const storFile = getStorFile();
                const storFileHTML = getStorFileHTML();
                const storFileCss = getStorFileCss();
                const storFileTsTest = getStorFileTsTest();
                const storFileTsDefs = getStorFileTsDefs();
                await this.deleteFiles(storFileHTML, storFile, storFileCss, storFileTsTest, storFileTsDefs);
                await mls.stor.localDB.removePrjInfo(storFile.project);
            };
            const onUndo = async () => {
                const storFile = getStorFile();
                const storFileHTML = getStorFileHTML();
                const storFileCss = getStorFileCss();
                const storFileTsTest = getStorFileTsTest();
                const storFileTsDefs = getStorFileTsDefs();
                const undoType = fileAction.undoType;
                if (storFile.status === 'new') {
                    if (!undoType || undoType === 'all') {
                        await this.deleteFiles(storFileHTML, storFile, storFileCss, storFileTsTest, storFileTsDefs);
                        await mls.stor.localDB.removePrjInfo(storFile.project);
                    }
                    else if (undoType === '.ts') {
                        await this.deleteFiles(undefined, storFile, undefined, undefined, undefined);
                    }
                    else if (undoType === '.html') {
                        await this.deleteFiles(storFileHTML, undefined, undefined, undefined, undefined);
                    }
                    else if (undoType === '.less') {
                        await this.deleteFiles(undefined, undefined, storFileCss, undefined, undefined);
                    }
                    else if (undoType === '.test.ts') {
                        await this.deleteFiles(undefined, undefined, undefined, storFileTsTest, undefined);
                    }
                    else if (undoType === '.defs.ts') {
                        await this.deleteFiles(undefined, undefined, undefined, undefined, storFileTsDefs);
                    }
                    return;
                }
                if (!undoType || undoType === 'all') {
                    await this.undoFiles(storFileHTML, storFile, storFileCss, storFileTsTest, storFileTsDefs, keyFilesHTML, keyFiles, keyFilesCss, keyFileTsTest, keyFileTsDefs, 'all');
                }
                else if (undoType === '.ts') {
                    await this.undoFiles(undefined, storFile, undefined, undefined, undefined, keyFilesHTML, keyFiles, keyFilesCss, keyFileTsTest, keyFileTsDefs, 'ts');
                }
                else if (undoType === '.html') {
                    await this.undoFiles(storFileHTML, undefined, undefined, undefined, undefined, keyFilesHTML, keyFiles, keyFilesCss, keyFileTsTest, keyFileTsDefs, 'html');
                }
                else if (undoType === '.less') {
                    await this.undoFiles(undefined, undefined, storFileCss, undefined, undefined, keyFilesHTML, keyFiles, keyFilesCss, keyFileTsTest, keyFileTsDefs, 'less');
                }
                else if (undoType === '.test.ts') {
                    await this.undoFiles(undefined, undefined, undefined, storFileTsTest, undefined, keyFilesHTML, keyFiles, keyFilesCss, keyFileTsTest, keyFileTsDefs, 'test');
                }
                else if (undoType === '.defs.ts') {
                    await this.undoFiles(undefined, undefined, undefined, undefined, storFileTsDefs, keyFilesHTML, keyFiles, keyFilesCss, keyFileTsTest, keyFileTsDefs, 'defs');
                }
            };
            const onRename = async () => {
                const storFile = getStorFile();
                await this.renameFiles(storFile, fileAction.newProject, fileAction.newshortName, fileAction);
                await mls.stor.localDB.removePrjInfo(storFile.project);
            };
            const onClone = async () => {
                const storFile = getStorFile();
                await this.cloneFiles(storFile, fileAction.newProject, fileAction.newshortName, fileAction);
            };
            const onUpdatedOnServer = async () => {
                await this.updatedOnServer();
            };
            if (mls.istrace)
                console.time('onAction_' + fileAction.action + '_' + fileAction.position);
            // if (fileAction.action !== 'preLoadProject') await this.initMonaco(false); // init if needed
            await this.initMonaco(); // init if needed
            switch (fileAction.action) {
                case 'new':
                    await onNew();
                    break;
                case 'open':
                    await onOpen();
                    break;
                case 'delete':
                    await onDelete();
                    break;
                case 'undo':
                    await onUndo();
                    break;
                case 'rename':
                    await onRename();
                    break;
                case 'clone':
                    await onClone();
                    break;
                case 'updatedOnServer':
                    await onUpdatedOnServer();
                    break;
                default: {
                    // console.error('invalid action: ' + fileAction.action);
                }
            }
            if (mls.istrace)
                console.timeEnd('onAction_' + fileAction.action + '_' + fileAction.position);
        };
        this.monacoGlobalInitialized = false;
        this.timeHtmlChangeCursor = 0;
        this.lastIdSelected = null;
        this.onFirtModel = true;
        this.timeout_compileConfEditor = 0;
        this._onChangedContentHtmlOrCss = undefined;
        this._onChangedContentTsTest = undefined;
        this._onChangedContentTsDefs = undefined;
        this._getValueInfo = async (activeModel, originalShortName, originalProject, originalCRC) => {
            const rc = {
                content: activeModel.getValue(),
                contentType: 'string',
                originalShortName,
                originalProject,
                originalCRC
            };
            return rc;
        };
        this.tripleslashChangeVariable = (model, variableName, newValue) => {
            const lines = (model.getValue() || '').split('\n');
            const line = lines[0];
            if (!line.startsWith('/// <'))
                throw new Error('line must start with "/// <" (triple slash and xml');
            const regex = new RegExp(`(${variableName}\\s*=\\s*["'])([^"']*)`, "i");
            const match = line.match(regex);
            if (!match)
                return false;
            lines[0] = line.replace(regex, `$1${newValue}`);
            model.setValue(lines.join(('\n')));
            return true;
        };
        //--------------WidgetAction--------------
        this.lastOrigin = 'editor';
        this.isHTMLSystemChange = false;
        this.syncDom = async (ev) => {
            if (this.position === 'right')
                return;
            try {
                this.isHTMLSystemChange = true;
                sync();
            }
            catch (e) {
                console.error('Error on syncDom: ', e);
            }
        };
        mls.events.addListener(2, 'WidgetAction', this.onWidgetActionEvents.bind(this));
        mls.events.addListener(2, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(2, 'MonacoAction', (ev) => this.onMonacoEvents(ev));
        mls.events.addListener(2, 'ProjectLoaded', (ev) => this.onProjectLoadedEvents(ev));
        mls.events.addListener(2, 'DomAction', (ev) => this.syncDom(ev));
        mls.events.addListener(2, 'CreateModelHTML', (ev) => this.checkToCreateModelHTML(ev));
        this.initMonaco_GlobalEditor();
    }
    ;
    ;
    onClickMain(op) {
        if (op === 'opTS2')
            return;
        else if (op === 'opTheme')
            this.showPageTheme();
        else if (op === 'opMonacoConfig')
            this.showConfEditor();
        else if (op === 'opMonacoReset')
            this.showMonacoReset();
        else if (op === 'opHistory')
            this.showHistory();
        else if (op === 'opView')
            this.openRepo();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTools(op) {
        if (op === 'History')
            return this.toogleHistory();
        else
            throw new Error('Invalid option');
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (!visible) {
            this.saveViewState();
            return;
        }
        await this.initMonaco();
        if (this.menu.setTabActive)
            this.menu.setTabActive(EToolsSource.icTs);
        this.updatedMSizeEditor();
        if (this.editorEl) {
            const bgEl = this.editorEl.querySelector('.monaco-editor-background');
            if (bgEl) {
                const bg = getComputedStyle(bgEl).backgroundColor;
                if (bg && this.horizontalSpliter && this.verticalSpliter) {
                    this.horizontalSpliter.setAttribute('complementcolor', bg);
                    this.verticalSpliter.setAttribute('complementcolor', bg);
                }
            }
        }
    }
    async createModels(storFile) {
        let fileModels = mls.editor.getModels(storFile.project, storFile.shortName);
        if (!fileModels) {
            await this.createModelTS2(storFile, false, false);
        }
    }
    //---------- Handling Editor --------
    getEditorValue() {
        if (!this._ed1)
            return '';
        const model = this._ed1.getModel();
        if (!model)
            return '';
        return model.getValue();
    }
    setEditorValue(val) {
        if (!this._ed1)
            return false;
        if (!this.activeModels || !this.activeModels.ts || !this.activeModels.ts.model)
            return false;
        this.setValueInModeKeepingUndo(this.activeModels.ts.model, val, true);
    }
    setEditorValueByLineTs(val, line) {
        if (!this._ed1)
            return false;
        if (!this.activeModels || !this.activeModels.ts || !this.activeModels.ts.model)
            return false;
        if (this.menu.setTabActive)
            this.menu.setTabActive(EToolsSource.icTs);
        this.setValueInModelInSpecificLine(val, line);
    }
    setEditorValueByLineHtml(val, line) {
        if (!this._ed1)
            return false;
        if (!this.activeModels || !this.activeModels.html || !this.activeModels.html.model)
            return false;
        if (this.menu.setTabActive)
            this.menu.setTabActive(EToolsSource.icHTML);
        this.setValueInModelInSpecificLine(val, line);
    }
    replaceEditorLineHTML(val, line) {
        if (!this._ed1)
            return false;
        if (!this.activeModels || !this.activeModels.html || !this.activeModels.html.model)
            return false;
        if (this.menu.setTabActive)
            this.menu.setTabActive(EToolsSource.icHTML);
        this.replaceLineValueInModelInSpecificLine(val, line);
    }
    searchLineByStringTs(search) {
        if (!this._ed1)
            return;
        if (!this.activeModels || !this.activeModels.ts || !this.activeModels.ts.model)
            return;
        const matches = this.activeModels.ts.model.findMatches(search, false, false, false, null, true);
        if (!matches || matches.length === 0)
            return;
        return matches[0].range.startLineNumber;
    }
    goToLine(line) {
        if (!this._ed1)
            return;
        const model = this._ed1.getModel();
        if (!model)
            return;
        const content = model.getLineContent(line);
        const range = new monaco.Range(line, 1, line, content.length + 1);
        this._ed1.setSelection(range);
        this._ed1.revealLineInCenter(line);
    }
    setEditorHTMLValue(val) {
        if (!this._ed1)
            return false;
        if (!this.activeModels || !this.activeModels.html || !this.activeModels.html.model)
            return false;
        this.setValueInModeKeepingUndo(this.activeModels.html.model, val, false);
    }
    getEditorHTMLValue() {
        if (!this._ed1)
            return '';
        if (!this.activeModels || !this.activeModels.html || !this.activeModels.html.model)
            return '';
        return this.activeModels.html.model.getValue();
    }
    setValueInModeKeepingUndo(model, val, checkFirstLine) {
        let fullRange = model.getFullModelRange();
        let newText = val;
        if (checkFirstLine && !(val.trim().startsWith('/// <mls shortName'))) {
            const firstLine = model.getLineContent(1);
            newText = firstLine + '\n' + newText;
        }
        const lines = newText.split('\n');
        const operations = [{
                range: fullRange,
                text: '',
                forceMoveMarkers: true
            }, {
                range: { startLineNumber: 1, startColumn: 1 },
                text: lines.join('\n'),
                forceMoveMarkers: true
            }];
        model.pushEditOperations([], operations, () => []);
        this._ed1?.setPosition({ lineNumber: 1, column: 1 });
    }
    setValueInModelInSpecificLine(content, line) {
        if (!this._ed1)
            return;
        this._ed1.executeEdits('my-source', [
            {
                range: new monaco.Range(line, 1, line, 1),
                text: `${content}\n`,
                forceMoveMarkers: true
            }
        ]);
        this._ed1.revealLineInCenter(line);
        this.formatMonaco();
    }
    replaceLineValueInModelInSpecificLine(content, line) {
        if (!this._ed1)
            return;
        const model = this._ed1.getModel();
        if (!model)
            return;
        const lineLength = model.getLineLength(5);
        this._ed1.executeEdits('my-source', [
            {
                range: new monaco.Range(line, 1, line, lineLength + 1),
                text: content,
                forceMoveMarkers: true
            }
        ]);
        this._ed1.revealLine(line);
        this.formatMonaco();
    }
    formatMonaco() {
        if (!this._ed1)
            return;
        this._ed1.trigger('anyString', 'editor.action.formatDocument', null);
    }
    confE2(positionToolbar) { return `l${this.level}_${positionToolbar}`; }
    get confE() { return `l${this.level}_${this.position}`; }
    get confETS() { return this.confE + '_TS'; }
    get confEJS() { return this.confE + '_JS'; }
    saveViewState() {
        const activeModel = this.activeModels;
        if (!activeModel)
            return;
        if (!this._ed1 || !this.mode || !activeModel || !activeModel.ts)
            return;
        const obj = {
            icTs: 'ts',
            icHTML: 'html',
            icStyle: 'style',
            icTest: 'test',
            icDefs: 'defs',
        };
        const mode = obj[this.mode];
        const keyViewState = `${activeModel.ts.storFile.project}_${activeModel.ts.storFile.shortName}`;
        if (!this.viewState[keyViewState]) {
            this.viewState[keyViewState] = {
                html: null,
                ts: null,
                style: null,
                test: null,
                defs: null
            };
        }
        this.viewState[keyViewState][mode] = this._ed1.saveViewState();
    }
    restaureViewState() {
        const activeModel = this.activeModels;
        if (!activeModel)
            return;
        if (!this._ed1 || !this.mode || !activeModel || !activeModel.ts)
            return;
        const obj = {
            icTs: 'ts',
            icHTML: 'html',
            icStyle: 'style',
            icTest: 'test',
            icDefs: 'defs',
        };
        const mode = obj[this.mode];
        const keyViewState = `${activeModel.ts.storFile.project}_${activeModel.ts.storFile.shortName}`;
        if (this.viewState[keyViewState] && this.viewState[keyViewState][mode])
            this._ed1.restoreViewState(this.viewState[keyViewState][mode]);
    }
    toogleHistory() {
        this.updatedMSizeEditor();
        this.isModeHistory = this.menu.tools.History.selected === 1;
        if (!this.isModeHistory && this.menu.setTabActive) {
            this.menu.setTabActive(EToolsSource[this.mode]);
        }
        else {
            this.getHistories();
        }
        this.verticalSpliter?.updatePanelsMSize();
    }
    async getHistories() {
        this.setHistories('Loading...', '', 'text');
        const obj = {
            icTs: 'ts',
            icHTML: 'html',
            icStyle: 'style',
            icTest: 'test',
            icDefs: 'defs',
        };
        const mode = obj[this.mode];
        if (!this.activeModels || !this.activeModels[mode]) {
            console.error('No active model');
            return;
        }
        const storFile = this.activeModels[mode]?.storFile;
        const model = this.activeModels[mode]?.model;
        if (!storFile) {
            console.error('No storfile');
            return;
        }
        ;
        if (!model) {
            console.error(`No model for ${mode} file`);
            return;
        }
        ;
        const oldStatus = storFile.inLocalStorage;
        storFile.inLocalStorage = false;
        let originalValue = '';
        if (storFile.status !== 'new') {
            originalValue = await storFile.getContent();
        }
        if (typeof originalValue !== 'string') {
            console.error('invalid content');
            return;
        }
        storFile.inLocalStorage = oldStatus;
        this.previousHistorySourceWithoutSave = originalValue;
        this.currentHistorySourceWithoutSave = model.getValue();
        const editorType = {
            '.ts': 'typescript',
            '.html': 'html',
            '.less': 'less',
            '.test.ts': 'typescript',
            '.defs.ts': 'typescript',
        };
        this.setHistories(this.previousHistorySourceWithoutSave || '', this.currentHistorySourceWithoutSave || '', editorType[storFile.extension]);
    }
    openRepo() {
        if (!this.menu.tabs)
            return;
        if (this.menu.tabs.selected === undefined)
            return false;
        if (!this.activeModels || !this.activeModels.ts || !this.activeModels.ts.storFile)
            return false;
        const { shortName, project } = this.activeModels.ts.storFile;
        const obj = {
            0: '.ts',
            1: '.html',
            2: '.less',
            3: '.test.ts',
            4: '.defs.ts',
        };
        const ext = obj[this.menu.tabs.selected];
        const keyToFile = mls.stor.getKeyToFiles(project, 2, shortName, '', ext);
        const file = mls.stor.files[keyToFile];
        if (!file) {
            window.collabMessages.add('Invalid File', 'information');
            throw new Error('invalid file');
        }
        const driver = mls.stor.others.getDefaultDriver(project);
        if (!driver) {
            window.collabMessages.add('Driver not found', 'information');
            throw new Error('Driver not found');
        }
        let url = '';
        url = driver.getUrl(file);
        window.open(url, '_blank');
        if (this.menu.closeMenu)
            this.menu.closeMenu();
        return true;
    }
    showHistory() {
        this.showHistorie2();
        return true;
    }
    async showHistorie2() {
        if (!this.menu.tabs || !this.activeModels || !this.activeModels.ts || !this.activeModels.ts.storFile)
            return;
        const { shortName, project } = this.activeModels.ts.storFile;
        const div = document.createElement('div');
        const scr = document.createElement('script');
        const i2 = `/_${'100554'}_${'mlsHistoryList'}`;
        scr.type = 'module';
        scr.id = i2.replace('/', '');
        scr.src = i2;
        div.appendChild(scr);
        const obj = {
            0: '.ts',
            1: '.html',
            2: '.less',
            3: '.test.ts',
            4: '.defs.ts',
        };
        const wc = document.createElement('mls-history-list-100554');
        wc.setAttribute('project', project.toString());
        wc.setAttribute('shortName', shortName);
        wc.setAttribute('level', '2');
        if (this.menu.tabs.selected !== undefined)
            wc.setAttribute('extension', obj[this.menu.tabs.selected]);
        wc.setAttribute('position', this.position);
        div.appendChild(wc);
        if (this.menu.setMode)
            this.menu.setMode('page', div);
    }
    showPageTheme() {
        if (this.menu.setMode)
            this.menu.setMode('page', this.getGlobalPageSetTHeme());
        return true;
    }
    showMonacoReset() {
        // reset editor configurations 
        mls.editor.conf[this.confE] = undefined;
        this.loadMonacoConfigurations();
        if (this.menu.setMode)
            this.menu.setMode('initial');
        this.updateMonacoConfigutarions();
        this.saveConfEditorToLocalStorage();
        return true;
    }
    showConfEditor() {
        if (this.menu.setMode)
            this.menu.setMode('editor');
        this.setModelConfEditor();
        return true;
    }
    async readProjectTypescriptAndCompile(project, shortName, needCompile = true) {
        // load all typescripts dependencies (in development) of project , except shortName
        if (ServiceSource100554_1.projectsLoaded.includes(project))
            return;
        if (mls.istrace)
            console.log('loading files from project ' + project);
        ServiceSource100554_1.projectsLoaded.push(project);
        const promises = [];
        const keys = Object.keys(mls.stor.files);
        if (window.traceLivecicle)
            console.info('creating: files model ', project);
        for (const key of keys) {
            const storFile = mls.stor.files[key];
            if (storFile.project === project
                && storFile.level === 2
                && storFile.extension === '.ts'
                && (mls.istrace || storFile.inLocalStorage)
                && storFile.shortName !== shortName) {
                promises.push(this.createModelTS2(storFile, false, false));
            }
        }
        const info = await mls.stor.localDB.readPrjInfo(100554);
        if (info && info.indexModules && info.indexModules !== '') {
            promises.push(this.createProjectModel(project, info.indexModules));
        }
        if (mls.istrace)
            console.time('creating models');
        await Promise.all(promises);
        if (mls.istrace)
            console.timeEnd('creating models');
        if (needCompile) {
            // await mls.l2.editor.compileAllProjectIfNeed(project, true);
            //await mls.l2.typescript.compileAll(project);
        }
    }
    async createProjectModel(project, contentTS) {
        let projectModel = mls.editor.getModels(project, '');
        if (projectModel && projectModel.ts)
            return projectModel;
        const ftype = ".d.ts";
        const modelsBase = await this.createModel(project, '', ftype, contentTS);
        if (!modelsBase)
            throw new Error(`invalid mls.editor.models for file: _${project}_.d.ts`);
        return projectModel;
    }
    async deleteFile(storFile) {
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        mls.editor.deleteModels(storFile.project, storFile.shortName, true);
        this.removeEventsStorFile(storFile);
        const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
        delete mls.stor.files[keyFiles];
    }
    addEventsModelTS(storFile, model1) {
        storFile.onAction = (action) => this._afterUpdate(storFile, model1.model, 'ts');
        storFile.getValueInfo = () => this.getValueInfo(model1);
        model1.model.onDidChangeContent((e) => this.onModelChange(e, model1, storFile));
    }
    removeEventsStorFile(storFile) {
        storFile.onAction = undefined;
        storFile.getValueInfo = undefined;
    }
    onMonacoEvents(ev) {
        if (!ev.desc)
            return;
        const args = JSON.parse(ev.desc);
        if (!args)
            return;
        const { action, filePosition, position, project, shortName } = args;
        if (position !== this.position)
            return;
        if (action === 'gotoPosition') {
            this.goToPosition(filePosition, position);
        }
        if (mls.istrace)
            console.info('received monaco actions', args);
    }
    goToPosition(position, editorPosition) {
        if (!this._ed1)
            return;
        const offset = position - 1;
        const model = mls.editor.editors[editorPosition]?.ts?.model;
        if (!model)
            return;
        const { lineNumber, column } = model.getPositionAt(offset);
        this._ed1.revealPositionInCenter({ lineNumber, column }, monaco.editor.ScrollType.Immediate);
        const lineLength = model.getLineContent(lineNumber).length + 1;
        const range = new monaco.Range(lineNumber, column, lineNumber, lineLength);
        this._ed1.setSelection(new monaco.Selection(range.startLineNumber, 0, range.startLineNumber, lineLength));
    }
    async deleteFiles(storFileHTML, storFileTS, storFileCss, storFileTsTest, storFileTsDefs) {
        for await (let storFile of [storFileHTML, storFileTS, storFileCss, storFileTsTest, storFileTsDefs]) {
            if (!storFile)
                continue;
            if (storFile.status === 'new')
                this.deleteFile(storFile);
            else
                storFile.status = 'deleted';
            mls.events.fireFileAction('statusOrErrorChanged', storFile, this.position);
        }
    }
    async cloneFiles(storFileTS, newProject, newShortName, oldFileAction) {
        await this.createModelTS_loading();
        this.activeThisService();
        await this.createModelTS_clone(storFileTS, newProject, newShortName);
        mls.actual[this.level][this.position] = {
            project: newProject,
            shortName: newShortName
        };
        const fileAction = {
            ...oldFileAction,
            project: newProject,
            shortName: newShortName,
            action: 'open',
            newProject: undefined,
            newshortName: undefined,
        };
        const ev = {
            level: this.level,
            type: 'FileAction',
            desc: JSON.stringify(fileAction)
        };
        this.onMLSEvents(ev);
    }
    async newFiles(newShortName, newProject, newEnhancement, tsSource, htmlSource, lessSource, testSource, defsSource, open = true) {
        if (open)
            this.activeThisService();
        this.closeMenu();
        const newTSSource = tsSource
            || `/// <mls shortName="${newShortName}" project="${newProject}" enhancement="${newEnhancement}" />
				\n// typescript new file\n`;
        const modelTS = await this.createModelTS1(newShortName, newProject, newTSSource, true);
        await this.createOrShowModelHtmlCssTestDefs(newShortName, newProject, false, '.html', htmlSource);
        await this.createOrShowModelHtmlCssTestDefs(newShortName, newProject, false, '.less', lessSource);
        if (testSource)
            await this.createOrShowModelHtmlCssTestDefs(newShortName, newProject, false, '.test.ts', testSource);
        if (defsSource)
            await this.createOrShowModelHtmlCssTestDefs(newShortName, newProject, false, '.defs.ts', defsSource);
        if (open)
            this.showActiveModel();
        await mls.stor.localStor.setContent(modelTS.storFile, await this.getValueInfo(modelTS));
    }
    async openFiles(storFileHTML, storFileTS, storFileCss, storFileTsTest, storFileTsDefs, position) {
        try {
            await this.createModelTS_loading();
            this.activeThisService();
            this.closeMenu();
            let fileModels = mls.editor.getModels(storFileTS.project, storFileTS.shortName);
            if (!fileModels || !fileModels.ts || !fileModels.html || !fileModels.style) {
                await this.createModelTS2(storFileTS, true, true);
                fileModels = mls.editor.getModels(storFileTS.project, storFileTS.shortName);
                if (!fileModels)
                    console.info('No file models');
                this.activeModels = fileModels;
                mls.editor.editors[this.position] = fileModels;
                this.showActiveModel();
                await this.readProjectTypescriptAndCompile(storFileTS.project, storFileTS.shortName, true);
                const modelTs = this.activeModels?.ts?.model;
                if (!modelTs)
                    throw new Error('Invalid model TS');
                mls.editor.forceModelUpdate(modelTs);
            }
            else {
                this.activeModels = fileModels;
                mls.editor.editors[this.position] = fileModels;
                const modelTs = this.activeModels.ts?.model;
                if (!modelTs)
                    throw new Error('Invalid model TS');
                mls.editor.forceModelUpdate(modelTs);
                this.showActiveModel();
            }
            [storFileCss, storFileTS, storFileHTML, storFileTsTest, storFileTsDefs].forEach((storF) => {
                if (storF && !storF.inLocalStorage && storF.isLocalVersionOutdated)
                    storF.isLocalVersionOutdated = false;
            });
            this.saveLocalStorageLastOpen(storFileTS, position);
            if (!this._ed1)
                return;
            this.restaureViewState();
        }
        catch (e) {
            this.loading = false;
            this.setError(e.message);
        }
    }
    async renameFiles(storFileTS, newProject, newShortName, oldFileAction) {
        await this.createModelTS_loading();
        this.activeThisService();
        let fileModels = mls.editor.getModels(storFileTS.project, storFileTS.shortName);
        if (!fileModels)
            fileModels = await this.createModelTS2(storFileTS, false, true);
        this.renameAllFiles(fileModels, newProject, newShortName);
        this.activeModels = fileModels;
        mls.actual[this.level][this.position] = {
            project: newProject,
            shortName: newShortName
        };
        const fileAction = {
            ...oldFileAction,
            project: newProject,
            shortName: newShortName,
            action: 'open',
            newProject: undefined,
            newshortName: undefined,
        };
        const ev = {
            level: this.level,
            type: 'FileAction',
            desc: JSON.stringify(fileAction)
        };
        this.onMLSEvents(ev);
    }
    async updatedOnServer() {
        // try {
        //     const keys = Object.keys(mls.stor.files);
        //     const arr: mls.stor.IFileInfo[] = [];
        //     let needMsg = false;
        //     keys.forEach((key) => {
        //         const f = mls.stor.files[key];
        //         if (!f) return;
        //         if (f.inLocalStorage || !f.isLocalVersionOutdated) return;
        //         arr.push(f);
        //     });
        //     await mls.l2.editor.compileAllProjectIfNeed(mls.actual[5].project as number, true, false);
        //     for await (const storFile of arr) {
        //         mls.l2.editor.remove(storFile);
        //         this.removeEventsStorFile(storFile);
        //         await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        //         await this.createModelTS2(storFile, false, true);
        //         if (storFile.project === 100554) needMsg = true;
        //     }
        //     if (needMsg) {
        //         // window.collabMessages.add("Files changed in server , please use F5 to reload", 'information', { autoClose: false, clearOnClose: false });
        //     }
        // } catch (e) {
        //     console.info('Erro service source: onUpdatedOnServer')
        // }
    }
    async undoFiles(storFileHTML, storFileTS, storFileCss, storFileTsTest, storFileTsDefs, keyFileHTML, keyFileTS, keyFileCss, keyFileTsTest, keyFileTsDefs, tp = 'all') {
        for await (let data of [
            { storFile: storFileHTML, keyFiles: keyFileHTML },
            { storFile: storFileCss, keyFiles: keyFileCss },
            { storFile: storFileTS, keyFiles: keyFileTS },
            { storFile: storFileTsTest, keyFiles: keyFileTsTest },
            { storFile: storFileTsDefs, keyFiles: keyFileTsDefs },
        ]) {
            if (!data.storFile)
                continue;
            if (data.storFile.status === 'deleted') {
                data.storFile.status = 'changed';
                continue;
            }
            if (data.storFile.status === 'renamed') {
                throw new Error('not implemented');
            }
            if (data.storFile.extension === '.ts' && tp === 'all') {
                mls.editor.deleteModels(data.storFile.project, data.storFile.shortName, true);
            }
            else if (data.storFile.extension === '.ts' && tp === 'ts') {
                const keyToModel = mls.editor.getKeyModel(data.storFile.project, data.storFile.shortName);
                if (!mls.editor.models[keyToModel])
                    return false;
                if (data.storFile.extension === '.ts') {
                    mls.editor.models[keyToModel].ts?.model.dispose();
                    delete mls.editor.models[keyToModel].ts;
                }
            }
            this.removeEventsStorFile(data.storFile);
            await mls.stor.localStor.setContent(data.storFile, { contentType: 'string', content: null });
            if (data.storFile.status === 'new') {
                delete mls.stor.files[data.keyFiles];
                continue;
            }
            if (data.storFile.status === 'changed') {
                data.storFile.status = 'nochange';
                if (data.storFile.isLocalVersionOutdated && data.storFile.newVersionRefIfOutdated) {
                    data.storFile.versionRef = data.storFile.newVersionRefIfOutdated;
                    data.storFile.isLocalVersionOutdated = false;
                    data.storFile.newVersionRefIfOutdated = undefined;
                }
            }
            else {
                data.storFile.status = 'changed';
            }
            if (['.less', '.html', '.defs.ts', '.test.ts'].includes(data.storFile.extension)) {
                const keyToModel = mls.editor.getKeyModel(data.storFile.project, data.storFile.shortName);
                if (!mls.editor.models[keyToModel])
                    return false;
                if (data.storFile.extension === '.html') {
                    mls.editor.models[keyToModel].html?.model.dispose();
                    delete mls.editor.models[keyToModel].html;
                }
                if (data.storFile.extension === '.less') {
                    mls.editor.models[keyToModel].style?.model.dispose();
                    delete mls.editor.models[keyToModel].style;
                }
                if (data.storFile.extension === '.test.ts') {
                    mls.editor.models[keyToModel].test?.model.dispose();
                    delete mls.editor.models[keyToModel].test;
                }
                if (data.storFile.extension === '.defs.ts') {
                    mls.editor.models[keyToModel].defs?.model.dispose();
                    delete mls.editor.models[keyToModel].defs;
                }
            }
        }
        ;
    }
    activeThisService() {
        this.openMe();
        mls.editor.setActiveInstance(this.level, this.position);
    }
    closeMenu() {
        if (this.menu.closeMenu)
            this.menu.closeMenu();
    }
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    async updateModelStatus(modelBaseTS, changed) {
        if (!modelBaseTS.storFile)
            throw new Error('Invalid stor file');
        const { project, shortName } = modelBaseTS.storFile;
        if (project === 0 && (shortName === 'loading' || shortName === 'testFile'))
            return;
        modelBaseTS.storFile.hasError = false;
        const ok = await mls.l2.typescript.compileAndPostProcess(modelBaseTS, true, true);
        let hasError = ok === false;
        if (!hasError && this.activeModels && this.activeModels.ts && !this.activeModels.ts.model.isDisposed()) {
            const enhacementName = await getEnhancementName({ project, shortName }).catch((e) => undefined);
            if (enhacementName && enhacementName !== "_blank") {
                const path = mls.l2.getPath(enhacementName);
                const enhancementInstance = await mls.l2.enhancement.getEnhancementModule(path).catch((e) => { console.error('Error on getEnhancementModule: ' + e.message); return undefined; });
                if (enhancementInstance)
                    await enhancementInstance.onAfterChange(this.activeModels.ts);
            }
            hasError = modelBaseTS.storFile.hasError;
        }
        await this.changeStatusFile(modelBaseTS, modelBaseTS.storFile, modelBaseTS.compilerResults?.tripleSlashMLS?.variables, hasError, changed);
    }
    async changeStatusFile(modelBaseTS, storFile, variables, hasError, changed) {
        if (!storFile)
            return; // new file dont have storFile ???
        const position = this.getPosition(modelBaseTS.model.id, 'ts');
        storFile.hasError = hasError;
        this.toogleIconsError(position);
        this.updateActionBasedOnError();
        if (!hasError)
            monaco.editor.setModelMarkers(modelBaseTS.model, 'markerSource', []);
        const sameContent = modelBaseTS.originalCRC === mls.common.crc.crc32(modelBaseTS.model.getValue()).toString(16);
        if (sameContent) {
            if (storFile.status !== 'new') {
                storFile.status = 'nochange';
                await mls.stor.localStor.setContent(storFile, { content: null }); // clear localstorage
            }
        }
        else {
            if (storFile.status !== 'renamed' && (storFile.status !== 'new'))
                storFile.status = 'changed';
            await mls.stor.localStor.setContent(storFile, await this.getValueInfo(modelBaseTS));
        }
        if (hasError) {
            this.setErrorOnEditor(modelBaseTS);
            this.dispatchEventStatusOrErrorChanged(position, storFile);
            return;
        }
        if (changed) {
            this.dispatchEventStatusOrErrorChanged(position, storFile);
        }
    }
    async renameFile(models, newProject, newShortName) {
        if (!models || !models.storFile)
            return;
        const newSts = { shortName: newShortName, project: newProject };
        if (!models.storFile.getValueInfo)
            return;
        const valueInfo = await models.storFile.getValueInfo();
        const { status } = models.storFile;
        const ext = models.storFile.extension;
        if (!mls.stor.renameFile(models.storFile, newSts))
            throw new Error('Error on rename mls.stor.files');
        const key = mls.stor.getKeyToFiles(newProject, this.level, newShortName, '', ext);
        const newStorFile = mls.stor.files[key];
        newStorFile.status = 'renamed';
        const oldKey = `_${models.storFile.project}_${models.storFile.shortName}`;
        const newKey = `_${newProject}_${newShortName}`;
        if (mls.editor.models[oldKey]) {
            mls.editor.models[newKey] = mls.editor.models[oldKey];
            delete mls.editor.models[oldKey];
        }
        setTimeout(async () => {
            if (ext === '.less' || ext === '.ts') {
                await mls.l2.less.parseTripleSlash(models);
                this.tripleslashChangeVariable(models.model, 'shortName', newShortName);
                this.tripleslashChangeVariable(models.model, 'project', newProject.toString());
            }
            await mls.stor.localStor.setContent(newStorFile, valueInfo);
            if (!models.storFile)
                return;
            if (status === 'new')
                models.storFile.status = status;
        }, 500);
    }
    renameAllFiles(models, newProject, newShortName) {
        const { html, style, ts, test } = models;
        if (!ts)
            throw new Error('Invalid ts file to rename');
        if (!ts.storFile)
            throw new Error('Invalid stor file to rename');
        if (ts.storFile.hasError)
            throw new Error('Error on rename, clear errors before rename');
        if (!this.isNewNameValid(newShortName))
            throw new Error('Error on rename, new shortName is a invalid name');
        this.renameFile(html, newProject, newShortName);
        this.renameFile(style, newProject, newShortName);
        this.renameFile(ts, newProject, newShortName);
        this.renameFile(test, newProject, newShortName);
    }
    isNewNameValid(newShortName) {
        if (newShortName.length === 0 || newShortName.length > 255)
            return false;
        const invalidCharacters = /[_\/{}\t\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        return (!invalidCharacters.test(newShortName));
    }
    showActiveModel() {
        if (!this.activeModels || !this.activeModels.ts || !this.activeModels.ts.storFile)
            return false;
        const { shortName, project, status } = this.activeModels.ts.storFile;
        if (!mls.actual[2][this.position]) {
            this.openLastFile(this.level, this.position);
        }
        const model = this.activeModels.ts.model;
        mls.editor.editors[this.position] = this.activeModels;
        if (model.isDisposed())
            return false;
        if (!this._ed1 || !this.menu.getLastMode)
            return false;
        const changedFile = this.menu.title !== shortName;
        this.menu.title.text = `_${project}_${shortName}`;
        const lastMode = this.menu.getLastMode();
        if (changedFile && lastMode !== 'initial') {
            // user choice another file, goto initial editor
            this._ed1.setModel(model);
            if (this.menu.setMode)
                this.menu.setMode('initial');
        }
        else if (lastMode === 'initial') {
            this._ed1.setModel(model);
            if (this.menu.updateTitle)
                this.menu.updateTitle();
        }
        else if (lastMode === 'editor') {
            // dont change model , ex TS Config
        }
        else if (lastMode === 'page') {
            // in page, ex About, prepare model to after close hamburger
            this._ed1.setModel(model);
        }
        this.updatedMSizeEditor();
        this.restaureViewState();
        this._formatIfNeeded(model);
        return true;
    }
    async initMonaco() {
        if (!this._ed1) {
            await this.initMonaco_Editor();
            await this.initMonaco_EditorDiff();
            if (this.serviceContent && typeof this.serviceContent.layout === 'function')
                this.serviceContent.layout();
        }
    }
    async initMonaco_GlobalEditor() {
        this.loadMonacoConfigurations();
        if (this.monacoGlobalInitialized)
            return;
        this.monacoGlobalInitialized = true;
        this.loadMonacoThemeFromLocalStorage();
        this.updateMonacoGlobalTheme();
        mls.editor.InitMonaco();
    }
    async initMonaco_Editor() {
        const addEventsEditor = () => {
            if (!this._ed1)
                return;
            this._ed1.onDidFocusEditorWidget(() => {
                if (!this.menu.tabs)
                    return '';
                if (this.menu.tabs.selected === EToolsSource.icHTML)
                    return;
                mls.editor.setActiveInstance(this.level, this.position);
            });
            this._ed1.onDidChangeCursorPosition((e) => {
                const pageActual = this.getActualL2File();
                if (pageActual) {
                    const isLocked = this.isEditorLocked(pageActual);
                    if (isLocked) {
                        this._ed1?.updateOptions({ readOnly: true });
                        return;
                    }
                }
                this._ed1?.updateOptions({ readOnly: false });
                clearTimeout(this.timeHtmlChangeCursor);
                if (!this._ed1 || !this.menu.tabs)
                    return;
                const model = this._ed1.getModel();
                if (this.menu.tabs.selected === EToolsSource.icStyle) {
                    const position = e.position;
                    const { lineNumber } = position;
                    const isReadOnlyArea = this.isReadOnlyArea(lineNumber);
                    this._ed1.updateOptions({ readOnly: isReadOnlyArea });
                    if (!isReadOnlyArea) {
                        if (this.lessCSS && this.lessCSS.setStateByLine && typeof this.lessCSS.setStateByLine === 'function') {
                            const content = model?.getLineContent(lineNumber) || '';
                            this.lessCSS.setStateByLine(lineNumber, content, 'editor');
                        }
                    }
                    return;
                }
                if (!this._ed1 || this.menu.tabs.selected !== EToolsSource.icHTML)
                    return;
                const position = e.position;
                if (!model)
                    return;
                this.timeHtmlChangeCursor = setTimeout(() => {
                    const lineContent = model.getLineContent(position.lineNumber);
                    if (lineContent.includes('id="')) {
                        const idValue = this.extractIdValue(lineContent);
                        if (this.lastIdSelected === idValue)
                            return;
                        this.lastIdSelected = idValue;
                        if (idValue && this.lastOrigin === 'editor') {
                            mls.events.fire(2, 'WidgetAction', `{"op":"SelectWidget", "id":"${idValue}", "origin":"editor"}`);
                        }
                        else {
                            this.lastOrigin = 'editor';
                        }
                    }
                }, 500);
            });
            monaco.editor.onDidChangeMarkers(async (uris) => {
                if (this.mode !== 'icStyle' || !this.activeModels || !this.activeModels.style)
                    return;
                const uriActual = this.activeModels.style.model.uri.toString();
                if (uris.some(uri => uri.toString() === uriActual)) {
                    const enhancementInstanceLess = await import('./_100554_enhancementStyle');
                    if (enhancementInstanceLess && this.activeModels)
                        await enhancementInstanceLess.onAfterMarkersChange(this.activeModels);
                }
            });
        };
        if (!this.editorEl)
            return;
        this._ed1 = monaco.editor.create(this.editorEl, mls.editor.conf[this.confE]);
        this.updateActionBasedOnError();
        this.editorEl['mlsEditor'] = this._ed1;
        mls.editor.instances[this.confE] = this._ed1;
        mls.editor.InitEditor(this._ed1);
        addEventsEditor();
        this.createModelTS_loading();
        this.createModelConf('// loading ...'); // model 
        // global routines dont need this._ed1
        await this.createModelTS_testFile();
    }
    addFixAction() {
        if (!this._ed1)
            return;
        this.actionAgentFix = (this._ed1).addAction({
            id: "action-agent-fix",
            label: "Fix(agentFix)",
            keybindings: [
                monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyM // Ctrl+M
            ],
            contextMenuGroupId: "Fix",
            contextMenuOrder: 1.5,
            run: (ed) => {
                this.fireAgentFix();
            }
        });
    }
    lockEditorForFile(page) {
        this.lockMap.set(page, true);
        if (this._ed1)
            this._ed1.updateOptions({ readOnly: true });
    }
    isEditorLocked(fileId) {
        return this.lockMap.get(fileId) === true;
    }
    unlockEditorForFile(fileId) {
        this.lockMap.set(fileId, false);
        this._ed1?.updateOptions({ readOnly: false });
    }
    removeFixAction() {
        if (!this._ed1)
            return;
        const actions = this._ed1._actions;
        if (actions && actions.has('action-agent-fix'))
            actions.delete('action-agent-fix');
        if (this.actionAgentFix)
            this.actionAgentFix.dispose();
    }
    updateActionBasedOnError() {
        if (!this._ed1)
            return;
        if (!this.activeModels)
            return;
        this.removeFixAction();
        const markersTs = this.activeModels.ts ? monaco.editor.getModelMarkers({ resource: this.activeModels.ts.model.uri }) : [];
        const markersHtml = this.activeModels.html ? monaco.editor.getModelMarkers({ resource: this.activeModels.html.model.uri }) : [];
        const markersLess = this.activeModels.style ? monaco.editor.getModelMarkers({ resource: this.activeModels.style.model.uri }) : [];
        const markersErrorsTS = markersTs.some(marker => marker.severity === monaco.MarkerSeverity.Error);
        const markersErrorsHTML = markersHtml.some(marker => marker.severity === monaco.MarkerSeverity.Error);
        const markersErrorsLess = markersLess.some(marker => marker.severity === monaco.MarkerSeverity.Error);
        const compileErrorsTs = ((this.activeModels.ts?.compilerResults?.errors?.length || 0) > 0);
        let hasErrors = compileErrorsTs || markersErrorsTS || markersErrorsHTML || markersErrorsLess;
        if (hasErrors) {
            this.addFixAction();
        }
    }
    getActualL2File() {
        if (!mls.actual[2] || !mls.actual[2][this.position])
            return;
        const actual = mls.actual[2][this.position];
        const { project, shortName } = actual;
        if (!project || !shortName)
            return;
        const page = `_${project}_${shortName}`;
        return page;
    }
    async fireAgentFix() {
        const page = this.getActualL2File();
        if (!page)
            return;
        const pref = loadChatPreferences();
        const modeBy = {
            'icTs': 'typescript',
            'icHTML': 'html',
            'icStyle': 'less',
            'icTest': '',
            'icDefs': '',
        };
        const data = { page, prompt: 'Fix errors in files', position: this.position, mode: modeBy[this.mode] };
        if (!pref.threadMaintenance) {
            this.setError('Please configure your maintenance thread at: CollabMessage > Settings > Chat Preferences');
            return;
        }
        const userId = getUserIdLocalStorage();
        const threadId = pref.threadMaintenance;
        if (!userId)
            return;
        this.lockEditorForFile(page);
        this.toogleOverlayLoading(true, 'Executing agent Fix...');
        const context = getTemporaryContext(threadId, userId, '@@ agentFix ' + JSON.stringify(data));
        const agent = createAgent();
        await agent.beforePrompt(context);
    }
    toogleOverlayLoading(show, msg) {
        if (!this.overlayLoading)
            return;
        if (show) {
            this.overlayLoading.style.display = 'flex';
            this.textOverlayLoading = msg || '';
        }
        else {
            this.overlayLoading.style.display = 'none';
            this.textOverlayLoading = '';
        }
    }
    initMonaco_EditorDiff() {
        if (!this.editorHistoryEl)
            return;
        const opt = {
            ...mls.editor.conf[this.confE],
            automaticLayout: true,
            renderSideBySide: false
        };
        this._edDiff = monaco.editor.createDiffEditor(this.editorHistoryEl, opt);
        this.editorHistoryEl['mlsEditor'] = this._edDiff;
        this.setHistories('no file A', 'no file B', 'typescript');
    }
    setHistories(srcOriginal, srcModified, language) {
        const modelOriginal = this.createOrGetModelHistory(language, srcOriginal, 'original');
        const modelModified = this.createOrGetModelHistory(language, srcModified, 'modified');
        if (!this._edDiff)
            return;
        this._edDiff.updateOptions({ readOnly: true });
        this._edDiff.setModel({
            original: modelOriginal,
            modified: modelModified,
        });
    }
    createOrGetModelHistory(editorType, src, tp) {
        const shortFN = `SourceHistory_${this.position}_${tp}`;
        const uri = monaco.Uri.parse(`file://server/${shortFN}.ts`);
        let model1 = monaco.editor.getModel(uri);
        if (!model1)
            model1 = monaco.editor.createModel(src, editorType, uri);
        else {
            model1.setValue(src);
            monaco.editor.setModelLanguage(model1, editorType);
        }
        return model1;
    }
    extractIdValue(line) {
        const idRegex = /id="([^"]*)"/;
        const match = line.match(idRegex);
        return match ? match[1] : null;
    }
    loadMonacoConfigurations() {
        if (!mls.editor.conf || Object.keys(mls.editor.conf).length === 0) {
            this.loadConfEditorFromLocalStorage();
        }
        if (mls.editor.conf[this.confE])
            return;
        mls.editor.conf[this.confE] = {
            contextmenu: true,
            autoIndent: 'full',
            wordWrap: 'on',
            wrappingIndent: 'indent',
            tabCompletion: 'on',
            renderControlCharacters: false,
            showUnused: true,
            glyphMargin: true,
            // acceptSuggestionOnEnter: "off",  // "on", "smart" -> ex: "dd" , invalid work will be get for next suggestion, bad
            minimap: { enabled: false },
            useTabStops: true,
            scrollBeyondLastColumn: 2,
            scrollBeyondLastLine: false,
            formatOnType: true,
            fixedOverflowWidgets: true,
            codeLens: true,
            showFoldingControls: 'mouseover',
            suggestSelection: 'first',
            stickyScroll: { enabled: false, maxLineCount: 3 },
            stickyTabStops: true,
            fontSize: 20,
            automaticLayout: true,
        };
    }
    getUri(shortFN, ftype) {
        return monaco.Uri.parse(`file://server/${shortFN}${ftype}`);
    }
    async createModelTS_testFile() {
        const shortName = 'testFile';
        const project = 0; // localstorage project
        const defaultTS = `/// <mls shortName="${shortName}" project="${project}" enhancement="_blank" />\n// typescript example`;
        await this.createModelTS1(shortName, project, defaultTS, true);
    }
    async createModelTS_loading() {
        const shortName = 'loading';
        const project = 0; // localstorage project
        const defaultTS = 'wait...';
        const mfile = await this.createModelTS1(shortName, project, defaultTS, true);
        if (this.onFirtModel && this._ed1) {
            this.onFirtModel = false;
            this._ed1.setModel(mfile.model);
        }
    }
    async createModelTS_clone(storFile, newProject, newShortName) {
        const { project, shortName } = storFile;
        let fileModels = mls.editor.getModels(project, shortName);
        if (!fileModels || !fileModels.ts)
            fileModels = await this.createModelTS2(storFile, false, true);
        let modelTS = fileModels.ts;
        if (!modelTS)
            throw new Error('Invalid models ts');
        let defaultTS = modelTS.model.getValue();
        const baseTag = convertFileNameToTag(`_${storFile.project}_${storFile.shortName}`);
        const newTag = convertFileNameToTag(`_${newProject}_${newShortName}`);
        const regex = new RegExp(baseTag, 'g');
        defaultTS = defaultTS.replace(regex, newTag);
        defaultTS = this.changeClassName(defaultTS, newProject, newShortName);
        modelTS = await this.createModelTS1(newShortName, newProject, defaultTS, true);
        this.tripleslashChangeVariable(modelTS.model, 'shortName', newShortName);
        this.tripleslashChangeVariable(modelTS.model, 'project', newProject.toString());
    }
    changeClassName(source, project, shortname) {
        const regex = /export\s+class\s+(\w+)\s+extends/g;
        const match = regex.exec(source);
        const newClassName = shortname.charAt(0).toUpperCase() + shortname.substring(1, shortname.length) + project.toString();
        if (match) {
            const originalTag = match[1];
            const replacedSource = source.replace(originalTag, newClassName);
            return replacedSource;
        }
        return source;
    }
    async createModelTS1(shortName, project, defaultTS, activateModel) {
        const level = 2;
        const extension = '.ts';
        if (project > 1)
            await mls.stor.server.loadProjectInfoIfNeeded(project);
        const key = mls.stor.getKeyToFiles(project, level, shortName, '', extension);
        let storFile = mls.stor.files[key];
        if (!storFile) {
            storFile = await mls.stor.addOrUpdateFile({ project, level, shortName, extension, versionRef: new Date().toISOString(), folder: '' });
            if (!storFile)
                throw new Error('Invalid storFile');
            storFile.status = 'new';
        }
        let fileModels = mls.editor.getModels(project, shortName);
        if (fileModels && fileModels.ts)
            return fileModels.ts;
        const src = storFile ? (await storFile.getContent(defaultTS)) || defaultTS : defaultTS;
        const ftype = src.split("\n")[0].indexOf(' type="definition"') > 0 ? ".d.ts" : ".ts";
        const modelBase = await this.createModel(project, shortName, ftype, src);
        if (!modelBase)
            throw new Error(`invalid mls.editor.models for file: _${project}_${shortName}${ftype}`);
        this.addEventsModelTS(storFile, modelBase);
        await this.updateModelStatus(modelBase, false); // first compilation
        fileModels = mls.editor.getModels(project, shortName);
        if (activateModel)
            this.activeModels = fileModels;
        return modelBase;
    }
    async createModelTS2(storFile, activedModel, compile) {
        // load source from repository
        const { project, shortName, extension } = storFile;
        let fileModels = mls.editor.getModels(project, shortName);
        if (fileModels && fileModels.ts && fileModels.html && fileModels.style)
            return fileModels;
        let modelTS;
        if (!fileModels || !fileModels.ts)
            modelTS = await this.createModel(project, shortName, '.ts');
        else
            modelTS = fileModels.ts;
        if (!modelTS)
            throw new Error(`invalid mls.editor.models for file: _${project}_${shortName}.ts`);
        this.addEventsModelTS(storFile, modelTS);
        const extFiles = ['.html', '.less'];
        for await (let ext of extFiles) {
            const keyFile1 = mls.stor.getKeyToFiles(storFile.project, 2, storFile.shortName, '', ext);
            let storFile1 = mls.stor.files[keyFile1];
            if (!storFile1)
                storFile1 = await this.createOrShowModelHtmlCssTestDefs(shortName, project, false, ext);
            await this.getOrCreateModelHtmlOrCss(storFile1);
        }
        const keyFileTsTest = mls.stor.getKeyToFiles(storFile.project, 2, storFile.shortName, '', '.test.ts');
        let storFileTsTest = mls.stor.files[keyFileTsTest];
        if (storFileTsTest) {
            await this.getOrCreateModelTsTest(storFileTsTest);
        }
        const keyFileTsDefs = mls.stor.getKeyToFiles(storFile.project, 2, storFile.shortName, '', '.defs.ts');
        let storFileTsDefs = mls.stor.files[keyFileTsDefs];
        if (storFileTsDefs) {
            await this.getOrCreateModelTsDefs(storFileTsDefs);
        }
        if (compile)
            await this.updateModelStatus(modelTS, false);
        fileModels = mls.editor.getModels(project, shortName);
        if (activedModel)
            this.activeModels = fileModels;
        if (!fileModels)
            throw new Error(`Invalid models for file: _${project}_${shortName}.ts`);
        return fileModels;
    }
    async createModel(project, shortName, ext, content) {
        try {
            let src = undefined;
            let haveInfo = false;
            let info = null;
            let storFile;
            if (ext !== '.d.ts') {
                const keyToFile = mls.stor.getKeyToFiles(project, 2, shortName, '', ext);
                storFile = mls.stor.files[keyToFile];
                if (!storFile)
                    throw new Error(`Invalid file: ${ext}`);
                if (!content) {
                    info = storFile.getValueInfo ? await storFile.getValueInfo() : null;
                    haveInfo = !!info && !!info.content;
                    src = haveInfo ? info?.content : await storFile.getContent();
                }
                else
                    src = content;
            }
            else {
                src = content || '';
            }
            if (src instanceof Blob)
                throw new Error(`${ext} file must be string`);
            if (!src)
                throw new Error(`${ext} file is undefined`);
            const originalCRC = haveInfo ? info?.originalCRC : mls.common.crc.crc32(src).toString(16);
            const originalProject = haveInfo ? info?.originalProject : undefined;
            const originalShortName = haveInfo ? info?.originalShortName : undefined;
            let model;
            if (ext === '.html' && storFile)
                model = mls.editor.createModelHTML(storFile, src);
            else if (ext === '.ts' && storFile)
                model = mls.editor.createModelTS(storFile, src);
            else if (ext === '.test.ts' && storFile)
                model = mls.editor.createModelTest(storFile, src);
            else if (ext === '.defs.ts' && storFile)
                model = mls.editor.createModelDefs(storFile, src);
            else if (ext === '.d.ts')
                model = mls.editor.createModelProjectDefinition(project, src);
            else if (ext === '.less' && storFile) {
                const lessTokens = await getTokensLess(project, 'Default');
                const lineTokens = `\n\n//Start Less Tokens\n${lessTokens}\n//End Less Tokens\n`;
                src = src.trim().concat(lineTokens);
                model = mls.editor.createModelStyle(storFile, src);
            }
            if (!model)
                throw new Error(`Model invalid`);
            if (ext !== '.d.ts') {
                model.originalCRC = originalCRC;
                model.originalProject = originalProject;
                model.originalShortName = originalShortName;
            }
            model.needFormat = true;
            return model;
        }
        catch (e) {
            this.setError(e.message);
        }
    }
    setModelConfEditor() {
        if (!this._ed1 || !this.mConfEditor)
            return;
        const src = this.getConfEditorToTypescript();
        this.mConfEditor['mlsConf'] = 'confEditor';
        this.mConfEditor.setValue(src);
        this._ed1.setModel(this.mConfEditor);
    }
    async createModelConf(src) {
        if (mls.istrace)
            console.log(`ServiceSource, createModelConf_${this.position}, ${!!this.mConfEditor}`);
        if (this.mConfEditor)
            return;
        const shortName = this.confE + '_service_source.confEditor';
        const level = 2;
        const project = 0;
        const extension = '.ts';
        const storFile = await mls.stor.addOrUpdateFile({ project, level, shortName, extension, versionRef: new Date().toISOString(), folder: '' });
        if (!storFile)
            throw new Error('Invalid storFile');
        const uri = this.getUri(shortName, extension);
        let model = monaco.editor.getModel(uri);
        if (model) {
            this.mConfEditor = model;
        }
        else {
            const modelBase = await this.createModel(project, shortName, '.ts', src);
            if (!modelBase)
                throw new Error(`invalid mls.editor.models for file: _${project}_${shortName}.ts`);
            model = modelBase.model;
            this.mConfEditor = model;
        }
        this.mConfEditor.onDidChangeContent((e) => {
            const mode = this.mConfEditor['mlsConf'];
            if (!mode || !this.mConfEditor)
                return;
            src = this.mConfEditor.getValue();
            this.compileSrcEditor(mode, src);
        });
    }
    compileSrcEditor(mode, src) {
        // wait 500ms to get diagnostics
        clearTimeout(this.timeout_compileConfEditor);
        this.timeout_compileConfEditor = window.setTimeout(async () => {
            if (!this.mConfEditor)
                return;
            const mmodel = mls.editor.getModelById(this.mConfEditor.id);
            if (!mmodel || !mmodel.storFile)
                return; // not in model
            const ok = await mls.l2.typescript.compileAndPostProcess(mmodel, false, true);
            if (!ok)
                return;
            if (mode === 'confEditor'
                && mmodel.compilerResults?.prodJS)
                this.setConfEditorFromJavascript(mmodel.compilerResults?.prodJS || '', src);
        }, 500);
    }
    loadConfEditorFromLocalStorage() {
        const info = this.getLocalStorageInfo();
        const json = info.confEditor;
        mls.editor.loadConfFromJSON(json);
    }
    saveConfEditorToLocalStorage() {
        const info = this.getLocalStorageInfo();
        info.confEditor = JSON.stringify(mls.editor.conf);
        this.saveLocalStorageInfo(info);
    }
    getActualTheme() {
        const html = this.closest('html');
        if (!html)
            return 'light';
        const dataTheme = html.getAttribute('data-theme');
        return dataTheme || 'light';
    }
    loadMonacoThemeFromLocalStorage() {
        const info = this.getLocalStorageInfo();
        const theme = this.getActualTheme();
        if (!mls.editor.themeName)
            mls.editor.setThemeName(info.confTheme[theme]);
    }
    saveMonacoGlobalThemeToLS() {
        const info = this.getLocalStorageInfo();
        const theme = this.getActualTheme();
        info.confTheme[theme] = mls.editor.themeName;
        this.saveLocalStorageInfo(info);
    }
    getConfEditorToTypescript() {
        return `/// <mls shortName="config_monaco_editor" project="0" enhancement="_blank" />
		
mls.editor.conf['${this.confE}'] = ` + JSON.stringify(mls.editor.conf[this.confE], null, 2) + ';\n';
    }
    setConfEditorFromJavascript(javastr, src) {
        if (this.level < 1)
            return;
        const that = this;
        (function scope() {
            eval(javastr); // eslint-disable-line no-eval
            if (mls.editor.conf[that.confE] && typeof mls.editor.conf[that.confE] === 'object') {
                // mls.editor.loadConf(that.confETS, src);
                that.updateMonacoConfigutarions();
                that.saveConfEditorToLocalStorage();
            }
        }).call(this); // eval in context scopeDesenv https://stackoverflow.com/questions/8403108/calling-eval-in-particular-context
    }
    async updateMonacoConfigutarions() {
        if (this._ed1)
            this._ed1.updateOptions(mls.editor.conf[this.confE]);
    }
    updateMonacoGlobalTheme() {
        let rc = true;
        if (mls.istrace)
            console.log(`service source, updating monaco theme: ${this.position}`);
        const internalThemes = ['VS', 'VS Dark', 'High Contrast (Dark)'];
        const internalThemes2 = ['vs', 'vs-dark', 'hc-black', 'hc-light'];
        let name2 = ''; // name to use , internal name or mytheme
        try {
            const internalIndex = internalThemes.indexOf(mls.editor.themeName);
            if (internalIndex < 0) {
                // load and define theme
                name2 = 'mytheme';
                const path = mls.baseMonaco + '../themes/' + mls.editor.themeName + '.json';
                mls.api.base.get(path, {}, (data) => {
                    const json = JSON.parse(data);
                    monaco.editor.defineTheme(name2, json);
                    monaco.editor.setTheme(name2);
                });
            }
            else {
                name2 = internalThemes2[internalIndex];
                monaco.editor.setTheme(name2);
            }
        }
        catch (ex) {
            console.error('error on set theme ' + name2, ex);
            rc = false;
        }
        return rc;
    }
    getGlobalPageSetTHeme() {
        const div1 = document.createElement('div');
        div1.innerHTML = `<div>` // eslint-disable-line
            + `<p id='theme-actual'>Theme actual: ${mls.editor.themeName} </p><br>`
            + `<p>Set Theme (only 1 theme in all editors)</p>` // eslint-disable-line
            // eslint-disable-next-line
            + `<select class="hidden" id="theme-select" style="display: initial;"><option>select ...</option><option value="vs">VS</option><option value="vs-dark">VS Dark</option><option value="hc-black">High Contrast (Dark)</option><option value="active4d">Active4D</option><option value="all-hallows-eve">All Hallows Eve</option><option value="amy">Amy</option><option value="birds-of-paradise">Birds of Paradise</option><option value="blackboard">Blackboard</option><option value="brilliance-black">Brilliance Black</option><option value="brilliance-dull">Brilliance Dull</option><option value="chrome-devtools">Chrome DevTools</option><option value="clouds-midnight">Clouds Midnight</option><option value="clouds">Clouds</option><option value="cobalt">Cobalt</option><option value="cobalt2">Cobalt2</option><option value="dawn">Dawn</option><option value="dracula">Dracula</option><option value="dreamweaver">Dreamweaver</option><option value="eiffel">Eiffel</option><option value="espresso-libre">Espresso Libre</option><option value="github">GitHub</option><option value="idle">IDLE</option><option value="katzenmilch">Katzenmilch</option><option value="kuroir-theme">Kuroir Theme</option><option value="lazy">LAZY</option><option value="magicwb--amiga-">MagicWB (Amiga)</option><option value="merbivore-soft">Merbivore Soft</option><option value="merbivore">Merbivore</option><option value="monokai-bright">Monokai Bright</option><option value="monokai">Monokai</option><option value="night-owl">Night Owl</option><option value="oceanic-next">Oceanic Next</option><option value="pastels-on-dark">Pastels on Dark</option><option value="slush-and-poppies">Slush and Poppies</option><option value="solarized-dark">Solarized-dark</option><option value="solarized-light">Solarized-light</option><option value="spacecadet">SpaceCadet</option><option value="sunburst">Sunburst</option><option value="textmate--mac-classic-">Textmate (Mac Classic)</option><option value="tomorrow-night-blue">Tomorrow-Night-Blue</option><option value="tomorrow-night-bright">Tomorrow-Night-Bright</option><option value="tomorrow-night-eighties">Tomorrow-Night-Eighties</option><option value="tomorrow-night">Tomorrow-Night</option><option value="tomorrow">Tomorrow</option><option value="twilight">Twilight</option><option value="upstream-sunburst">Upstream Sunburst</option><option value="vibrant-ink">Vibrant Ink</option><option value="xcode-default">Xcode_default</option><option value="zenburnesque">Zenburnesque</option><option value="iplastic">iPlastic</option><option value="idlefingers">idleFingers</option><option value="krtheme">krTheme</option><option value="monoindustrial">monoindustrial</option></select>`;
        const sel = div1.querySelector('#theme-select');
        if (!sel)
            return div1;
        sel.oninput = (ev) => {
            if (ev?.srcElement?.localName === 'select') {
                const el = ev.srcElement;
                const actual = div1.querySelector('#theme-actual');
                if (el.selectedIndex < 1)
                    return; // option 0 is select ...
                mls.editor.setThemeName(el.options?.[el.selectedIndex].text || 'default');
                this.saveMonacoGlobalThemeToLS();
                this.updateMonacoGlobalTheme();
                if (actual)
                    actual.innerHTML = `Theme changed to: ${mls.editor.themeName}`;
            }
        };
        return div1;
    }
    // HTML LESS
    async createOrShowModelHtmlCssTestDefs(shortName, project, open, mode, source = '', fileInfo) {
        const key = mls.stor.getKeyToFiles(project, this.level, shortName, '', mode);
        let storFile = mls.stor.files[key];
        if (!storFile) {
            if (mode === '.less') {
                const newLess = await this.prepareInitialLess(shortName, project, source);
                await this.createStorFile(project, shortName, newLess, mode);
            }
            else if (mode === '.test.ts') {
                const newTest = await this.prepareInitialTest(shortName, project, source);
                await this.createStorFile(project, shortName, newTest, mode);
            }
            else if (mode === '.defs.ts') {
                const newTest = await this.prepareInitialDefs(shortName, project, source);
                await this.createStorFile(project, shortName, newTest, mode);
            }
            else {
                const newHTML = await this.prepareInitiaHTML(source, shortName, project);
                await this.createStorFile(project, shortName, newHTML, mode);
            }
            storFile = mls.stor.files[key];
        }
        const uri = this.getUri(`_${project}_${shortName}`, mode);
        let model = monaco.editor.getModel(uri);
        let createNow = false;
        if (!model && ['.less', '.html'].includes(mode)) {
            model = await this.getOrCreateModelHtmlOrCss(storFile, fileInfo);
            createNow = true;
        }
        else if (!model && mode === '.test.ts') {
            model = await this.getOrCreateModelTsTest(storFile, fileInfo);
            createNow = true;
        }
        else if (!model && mode === '.defs.ts') {
            model = await this.getOrCreateModelTsDefs(storFile, fileInfo);
            createNow = true;
        }
        if (!model)
            throw new Error("[createOrShowModelHtmlCssTestDefs] Erro get or create model");
        if (open && this._ed1 && this.activeModels) {
            this._ed1.setModel(model);
            this.restaureViewState();
            this.updatedMSizeEditor();
            if (mode === '.less') {
                this.initModelStyle(uri, model);
            }
            if (mode === ".html") {
                this.registerProviderHTML();
            }
        }
        if (mode === '.html' && this._ed1 && this._ed1.getModel()?.id !== model.id) {
            this.registerProviderHTML();
        }
        if (!createNow)
            this._formatIfNeeded(model);
        return storFile;
    }
    async initModelStyle(uri, model) {
        if (!this._ed1)
            return;
        this.lessCSS = new LessCSS(uri.toString(), this._ed1, this.position);
        this.lessCSS.setEditor(this._ed1);
        const actualLine = this._ed1.getPosition();
        const lineNumber = this.lessCSS.lessAST.findFirstSelectorAfterRoot(this.lessCSS.lessAST.ast);
        if (lineNumber && actualLine && actualLine.lineNumber === 1) {
            const line = model.getLineContent(lineNumber);
            this._ed1.setSelection(new monaco.Selection(lineNumber, 1, lineNumber, line.length + 1));
            const enhancementInstanceLess = await import('./_100554_enhancementStyle');
            if (enhancementInstanceLess && this.activeModels)
                await enhancementInstanceLess.onAfterChange(this.activeModels);
        }
    }
    async prepareInitialTest(shortName, project, source = "") {
        const tag = convertFileNameToTag(`_${project}_${shortName}`);
        const example = `/// <mls shortName="[shortName]" project="[project]" enhancement="_blank" />
				
                \nimport { ICANTest, ICANIntegration } from './_100554_tsTestAST'; 
                \n
                \nexport const integrations: ICANIntegration[] = []; 
                \nexport const tests: ICANTest[] = [];
                \n[source]
                
                `;
        const newTest = example
            .replace('[shortName]', shortName)
            .replace('[project]', project.toString())
            .replace('[source]', source);
        return newTest;
    }
    async prepareInitialDefs(shortName, project, source = "") {
        const tag = convertFileNameToTag(`_${project}_${shortName}`);
        const example = `/// <mls shortName="[shortName]" project="[project]" enhancement="_blank" />
				
                // TODO: InDevelpoment
                
                `;
        const newTest = example
            .replace('[shortName]', shortName)
            .replace('[project]', project.toString())
            .replace('[source]', source);
        return newTest;
    }
    async prepareInitialLess(shortName, project, source = "") {
        const tag = convertFileNameToTag(`_${project}_${shortName}`);
        let example = '';
        if (source.indexOf(tag) >= 0) {
            example = `/// <mls shortName="[shortName]" project="[project]" enhancement="enhancementStyle" />

                \n[source]
                `;
        }
        else {
            example = `/// <mls shortName="[shortName]" project="[project]" enhancement="enhancementStyle" />
				\n[tag] {
                \n // Here your less
                \n[source]
                \n}`;
        }
        const newStyle = example
            .replace('[shortName]', shortName)
            .replace('[project]', project.toString())
            .replace('[tag]', tag)
            .replace('[source]', source);
        return newStyle;
    }
    async prepareInitiaHTML(source, shortName, project) {
        if (source)
            return source;
        const newHTML = `<h1>_${project}_${shortName}</h1>`;
        return newHTML;
    }
    async getOrCreateModelHtmlOrCss(storFile, fileInfo) {
        const { project, shortName, extension } = storFile;
        let fileModels = mls.editor.getModels(project, shortName);
        const typeModel = storFile.extension === '.html' ? 'html' : 'style';
        if (fileModels && fileModels[typeModel] && fileModels[typeModel]?.model) {
            if (this.visible === 'true' && typeModel === 'html')
                mls.events.fire([2, 3, 4, 5, 6, 7], 'ModelHTMLCreated', JSON.stringify(storFile));
            return fileModels[typeModel]?.model;
        }
        const content = fileInfo ? fileInfo.content : await storFile.getContent();
        if (content instanceof Blob)
            throw new Error('less file must be string');
        if (!content)
            throw new Error('less file is undefined');
        const ext = extension;
        if (!['.html', '.less'].includes(ext))
            throw new Error('Invalid extension');
        const modelBase = await this.createModel(project, shortName, ext);
        if (!modelBase)
            throw new Error(`invalid mls.editor.models for file: _${project}_${shortName}${ext}`);
        if (this.visible === 'true' && typeModel === 'html')
            mls.events.fire([2, 3, 4, 5, 6, 7], 'ModelHTMLCreated', JSON.stringify(storFile));
        const { model } = modelBase;
        const originalCRC = fileInfo ? fileInfo?.originalCRC : mls.common.crc.crc32(content).toString(16);
        modelBase.originalCRC = originalCRC;
        if (storFile.status === 'renamed' && fileInfo) {
            this.setEventsModelHTMLOrCss(modelBase, fileInfo.originalShortName, fileInfo.originalProject, ext);
            model.setValue(fileInfo.content);
        }
        else {
            this.setEventsModelHTMLOrCss(modelBase, storFile.shortName, storFile.project, ext);
        }
        return model;
    }
    setEventsModelHTMLOrCss(modelBase, shortName, project, ext) {
        const { storFile, model, originalCRC } = modelBase;
        if (!storFile)
            throw new Error(`Invalid stor file for: ${project}_${shortName}`);
        storFile.onAction = (action) => this._afterUpdate(storFile, model, ext === '.html' ? 'html' : 'style');
        storFile.getValueInfo = () => this._getValueInfo(model, shortName, project, originalCRC);
        if (!model)
            return;
        model.onDidChangeContent((e) => this.onModelHtmlOrCssChange(e, modelBase, storFile, model, ext));
    }
    onModelHtmlOrCssChange(e, modelBase, storFile, model, ext) {
        // some changes is to simulate changes to force compile
        clearTimeout(this._onChangedContentHtmlOrCss);
        this._onChangedContentHtmlOrCss = window.setTimeout(async () => {
            let modelValue = model.getValue();
            if (ext === '.less') {
                const enhancementInstanceLess = await import('./_100554_enhancementStyle');
                if (enhancementInstanceLess && this.activeModels)
                    await enhancementInstanceLess.onAfterChange(this.activeModels);
                await mls.l2.less.compileStyle(modelBase);
                modelValue = removeTokensFromSource(modelValue);
                if (this.activeModels && this.activeModels.ts) {
                    if (this.activeModels.ts.compilerResults) {
                        this.activeModels.ts.compilerResults.modelNeedCompile = true;
                    }
                    await mls.l2.typescript.compileAndPostProcess(this.activeModels.ts, true, true);
                }
                const lastemitter = globalState._ica.less[this.position]?.emitter || 'editor';
                if (this.lessCSS && this._ed1) {
                    const uri = this.getUri(`_${modelBase.storFile.project}_${modelBase.storFile.shortName}`, '.less');
                    const lastSelector = this.lessCSS.selector;
                    this.lessCSS = new LessCSS(uri.toString(), this._ed1, this.position);
                    this.lessCSS.setEditor(this._ed1);
                    this.lessCSS.setSelector(lastSelector);
                    const monacoPosition = this._ed1.getPosition();
                    if (!monacoPosition)
                        return;
                    const lineContent = model.getLineContent(monacoPosition.lineNumber);
                    this.lessCSS.setStateByLine(monacoPosition.lineNumber, lineContent, lastemitter);
                }
            }
            const sameContent = modelBase.originalCRC === mls.common.crc.crc32(modelValue).toString(16);
            if (sameContent) {
                if (storFile.status !== 'new' && storFile.status !== 'renamed')
                    storFile.status = 'nochange';
                if (storFile.status !== 'renamed')
                    await mls.stor.localStor.setContent(storFile, { content: null }); // clear localstorage
            }
            else {
                if (storFile.status !== 'renamed' && (storFile.status !== 'new'))
                    storFile.status = 'changed';
                await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: modelValue });
            }
            if (this.isHTMLSystemChange) {
                this.isHTMLSystemChange = false;
                return;
            }
            let mode = ext === '.html' ? 'html' : 'style';
            let position = this.getPosition(modelBase.model.id, mode);
            if (ext === '.html')
                this.dispatchEventStatusOrErrorChanged(position, storFile);
            else
                this.dispatchEventStyleChanged(position, storFile);
            this.toogleIconsError(position);
            this.updateActionBasedOnError();
        }, 400);
    }
    ;
    // Model Test
    async createOrShowModelTsTest(shortName, project, open, fileInfo) {
        const ext = '.test.ts';
        const key = mls.stor.getKeyToFiles(project, this.level, shortName, '', ext);
        let storFile = mls.stor.files[key];
        if (!storFile) {
            const newTest = await this.prepareInitialTsTest(shortName, project);
            await this.createStorFile(project, shortName, newTest, ext);
            storFile = mls.stor.files[key];
        }
        const uri = this.getUri(`_${project}_${shortName}`, ext);
        let model = monaco.editor.getModel(uri);
        if (!model)
            model = await this.getOrCreateModelTsTest(storFile, fileInfo);
        if (open && this._ed1 && this.activeModels) {
            this._ed1.setModel(model);
            this.restaureViewState();
            this.updatedMSizeEditor();
        }
        this._formatIfNeeded(model);
        return storFile;
    }
    async getOrCreateModelTsTest(storFile, fileInfo) {
        const { project, shortName, extension } = storFile;
        const content = fileInfo ? fileInfo.content : await storFile.getContent();
        if (content instanceof Blob)
            throw new Error('test file must be string');
        if (!content)
            throw new Error('test file is undefined');
        const ext = extension;
        const modelBase = await this.createModel(project, shortName, ext);
        if (!modelBase)
            throw new Error(`invalid mls.editor.models for file: _${project}_${shortName}${ext}`);
        const { model } = modelBase;
        const originalCRC = fileInfo ? fileInfo?.originalCRC : mls.common.crc.crc32(content).toString(16);
        modelBase.originalCRC = originalCRC;
        if (storFile.status === 'renamed' && fileInfo) {
            this.setEventsModelTsTest(modelBase, fileInfo.originalShortName, fileInfo.originalProject);
            model.setValue(fileInfo.content);
        }
        else {
            this.setEventsModelTsTest(modelBase, storFile.shortName, storFile.project);
        }
        return model;
    }
    setEventsModelTsTest(modelBase, shortName, project) {
        const { storFile, model, originalCRC } = modelBase;
        if (!storFile)
            throw new Error(`Invalid stor file for: ${project}_${shortName}`);
        storFile.onAction = (action) => this._afterUpdate(storFile, model, 'test');
        storFile.getValueInfo = () => this._getValueInfo(model, shortName, project, originalCRC);
        if (!model)
            return;
        model.onDidChangeContent((e) => this.onModelTsTestChange(e, modelBase, storFile, model));
    }
    onModelTsTestChange(e, modelBase, storFile, model) {
        clearTimeout(this._onChangedContentTsTest);
        this._onChangedContentTsTest = window.setTimeout(async () => {
            let modelValue = model.getValue();
            const ok = await mls.l2.typescript.compileAndPostProcess(modelBase, false, true);
            let hasError = ok === false;
            storFile.hasError = hasError;
            const sameContent = modelBase.originalCRC === mls.common.crc.crc32(modelValue).toString(16);
            if (sameContent) {
                if (storFile.status !== 'new' && storFile.status !== 'renamed')
                    storFile.status = 'nochange';
                if (storFile.status !== 'renamed')
                    await mls.stor.localStor.setContent(storFile, { content: null }); // clear localstorage
            }
            else {
                if (storFile.status !== 'renamed' && (storFile.status !== 'new'))
                    storFile.status = 'changed';
                await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: modelValue });
            }
            let position = this.getPosition(modelBase.model.id, 'defs');
            this.dispatchEventTsTestChanged(position, storFile);
            this.toogleIconsError(position);
            this.updateActionBasedOnError();
        });
    }
    ;
    async prepareInitialTsTest(shortName, project) {
        const example = `/// <mls shortName="[shortName]" project="[project]" enhancement="_blank" />
				\nimport { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST'; \n\nexport const integrations: ICANIntegration[] = []; \nexport const tests: ICANTest[] = [];`;
        const newTest = example
            .replace('[shortName]', shortName)
            .replace('[project]', project.toString());
        return newTest;
    }
    //  Defs
    async createOrShowModelTsDefs(shortName, project, open, fileInfo) {
        const ext = '.defs.ts';
        const key = mls.stor.getKeyToFiles(project, this.level, shortName, '', ext);
        let storFile = mls.stor.files[key];
        if (!storFile) {
            const newTest = await this.prepareInitialDefs(shortName, project);
            await this.createStorFile(project, shortName, newTest, ext);
            storFile = mls.stor.files[key];
        }
        const uri = this.getUri(`_${project}_${shortName}`, ext);
        let model = monaco.editor.getModel(uri);
        if (!model)
            model = await this.getOrCreateModelTsDefs(storFile, fileInfo);
        if (open && this._ed1 && this.activeModels) {
            this._ed1.setModel(model);
            this.restaureViewState();
            this.updatedMSizeEditor();
        }
        this._formatIfNeeded(model);
        return storFile;
    }
    async getOrCreateModelTsDefs(storFile, fileInfo) {
        const { project, shortName, extension } = storFile;
        const content = fileInfo ? fileInfo.content : await storFile.getContent();
        if (content instanceof Blob)
            throw new Error('test file must be string');
        if (!content)
            throw new Error('test file is undefined');
        const ext = extension;
        const modelBase = await this.createModel(project, shortName, ext);
        if (!modelBase)
            throw new Error(`invalid mls.editor.models for file: _${project}_${shortName}${ext}`);
        const { model } = modelBase;
        const originalCRC = fileInfo ? fileInfo?.originalCRC : mls.common.crc.crc32(content).toString(16);
        modelBase.originalCRC = originalCRC;
        if (storFile.status === 'renamed' && fileInfo) {
            this.setEventsModelTsDefs(modelBase, fileInfo.originalShortName, fileInfo.originalProject);
            model.setValue(fileInfo.content);
        }
        else {
            this.setEventsModelTsDefs(modelBase, storFile.shortName, storFile.project);
        }
        return model;
    }
    setEventsModelTsDefs(modelBase, shortName, project) {
        const { storFile, model, originalCRC } = modelBase;
        if (!storFile)
            throw new Error(`Invalid stor file for: ${project}_${shortName}`);
        storFile.onAction = (action) => this._afterUpdate(storFile, model, 'defs');
        storFile.getValueInfo = () => this._getValueInfo(model, shortName, project, originalCRC);
        if (!model)
            return;
        model.onDidChangeContent((e) => this.onModelTsDefsChange(e, modelBase, storFile, model));
    }
    onModelTsDefsChange(e, modelBase, storFile, model) {
        clearTimeout(this._onChangedContentTsDefs);
        this._onChangedContentTsDefs = window.setTimeout(async () => {
            let modelValue = model.getValue();
            const ok = await mls.l2.typescript.compileAndPostProcess(modelBase, false, true);
            let hasError = ok === false;
            storFile.hasError = hasError;
            const sameContent = modelBase.originalCRC === mls.common.crc.crc32(modelValue).toString(16);
            if (sameContent) {
                if (storFile.status !== 'new' && storFile.status !== 'renamed')
                    storFile.status = 'nochange';
                if (storFile.status !== 'renamed')
                    await mls.stor.localStor.setContent(storFile, { content: null }); // clear localstorage
            }
            else {
                if (storFile.status !== 'renamed' && (storFile.status !== 'new'))
                    storFile.status = 'changed';
                await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: modelValue });
            }
            let position = this.getPosition(modelBase.model.id, 'defs');
            this.dispatchEventTsDefsChanged(position, storFile);
            this.toogleIconsError(position);
            this.updateActionBasedOnError();
        });
    }
    ;
    //Commum
    dispatchEventStatusOrErrorChanged(position, storFile) {
        if (position === 'all') {
            mls.events.fireFileAction('statusOrErrorChanged', storFile, 'left');
            mls.events.fireFileAction('statusOrErrorChanged', storFile, 'right');
            return;
        }
        mls.events.fireFileAction('statusOrErrorChanged', storFile, position);
    }
    dispatchEventStyleChanged(position, storFile) {
        if (position === 'all') {
            mls.events.fire([2], ['styleChanged'], JSON.stringify({ position: 'left', storFile }));
            mls.events.fire([2], ['styleChanged'], JSON.stringify({ position: 'right', storFile }));
            return;
        }
        mls.events.fire([2], ['styleChanged'], JSON.stringify({ position: 'right', storFile }));
    }
    dispatchEventTsTestChanged(position, storFile) {
        if (position === 'all') {
            mls.events.fire([2], ['tsTestChanged'], JSON.stringify({ position: 'left', storFile }));
            mls.events.fire([2], ['tsTestChanged'], JSON.stringify({ position: 'right', storFile }));
            return;
        }
        mls.events.fire([2], ['tsTestChanged'], JSON.stringify({ position: 'right', storFile }));
    }
    dispatchEventTsDefsChanged(position, storFile) {
        if (position === 'all') {
            mls.events.fire([2], ['tsDefsChanged'], JSON.stringify({ position: 'left', storFile }));
            mls.events.fire([2], ['tsDefsChanged'], JSON.stringify({ position: 'right', storFile }));
            return;
        }
        mls.events.fire([2], ['tsDefsChanged'], JSON.stringify({ position: 'right', storFile }));
    }
    async _afterUpdate(storFile, model, tp) {
        if (storFile.status === 'deleted') {
            await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
            const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
            delete mls.stor.files[keyFiles];
            return;
        }
        if (storFile.status === 'renamed') {
            const models = mls.editor.getModels(storFile.project, storFile.shortName);
            if (!models || models[tp] === undefined)
                return;
            const modelByType = models[tp];
            if (!modelByType)
                return;
            modelByType.originalCRC = mls.common.crc.crc32(model.getValue()).toString(16);
        }
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        storFile.status = 'nochange';
    }
    _formatIfNeeded(model) {
        if (model.needFormat && this._ed1) {
            this.formatMonaco();
            model.needFormat = false;
        }
    }
    getPosition(modeIld, tp) {
        let position;
        const idLeft = mls.editor.editors.left?.[tp]?.model.id;
        const idRight = mls.editor.editors.right?.[tp]?.model.id;
        const idActive = modeIld;
        if (idLeft === idActive && idRight === idActive)
            position = 'all';
        else if (idLeft === idActive)
            position = 'left';
        else
            position = 'right';
        return position;
    }
    setErrorOnEditor(modelBaseTS) {
        const errors = modelBaseTS.compilerResults?.errors;
        if (errors && errors.length > 0) {
            errors.forEach((err) => {
                if (err.start === 0 && err.file?.fileName === '') {
                    setErrorOnModel(modelBaseTS.model, 1, 0, modelBaseTS.model.getLineContent(1).length, err.messageText, monaco.MarkerSeverity.Error);
                }
            });
        }
    }
    async createStorFile(project, shortName, content, extension) {
        const params = {
            project,
            level: 2,
            shortName,
            extension,
            versionRef: '0',
            folder: ''
        };
        const file = await mls.stor.addOrUpdateFile(params);
        if (!file)
            throw new Error('Invalid storFile');
        file.status = 'new';
        const fileInfo = {
            content,
            contentType: 'string',
        };
        await mls.stor.localStor.setContent(file, fileInfo);
    }
    getLocalStorageInfo() {
        const ls = localStorage.getItem('serviceSource');
        if (ls)
            return JSON.parse(ls);
        const oldConfigEditor = localStorage.getItem('mlsConfEditor');
        const rc = {
            confTheme: { light: 'VS', dark: 'VS Dark' },
            confEditor: oldConfigEditor ? oldConfigEditor : '',
            lastOpened: {},
        };
        if (oldConfigEditor) {
            this.saveLocalStorageInfo(rc);
            localStorage.removeItem('mlsConfEditor');
        }
        return rc;
    }
    saveLocalStorageInfo(data) {
        localStorage.setItem('serviceSource', JSON.stringify(data));
    }
    isReadOnlyArea(lineNumber) {
        const obj = this.getIntervalLinesReadOnly();
        if (!obj)
            return false;
        if (!obj.end || !obj.start)
            return false;
        if (lineNumber >= obj.start && lineNumber <= obj.end)
            return true;
        return false;
    }
    getIntervalLinesReadOnly() {
        if (!this._ed1)
            return;
        const model = this._ed1.getModel();
        if (!model)
            return;
        const [startLine] = model.findMatches(`//Start Less Tokens`, true, false, false, null, true);
        const [endLine] = model.findMatches(`//End Less Tokens`, true, false, false, null, true);
        return {
            end: endLine ? endLine.range.startLineNumber : undefined,
            start: startLine ? startLine.range.startLineNumber : undefined
        };
    }
    updatedMSizeEditor() {
        this.editorEl?.setAttribute('msize', this.msize);
        this.editorHistoryEl?.setAttribute('msize', this.msize);
    }
    toogleIconsError(position) {
        const servicesToChange = [];
        if (position === 'all') {
            const serviceL = mls.services[`${'100554_serviceSource'}_right`];
            const serviceR = mls.services[`${'100554_serviceSource'}_left`];
            if (serviceL)
                servicesToChange.push(serviceL);
            if (serviceR)
                servicesToChange.push(serviceR);
        }
        else {
            const service = mls.services[`${'100554_serviceSource'}_${position}`];
            if (service)
                servicesToChange.push(service);
        }
        servicesToChange.forEach((serv) => {
            if (!serv.menu || !serv.menu.toggleErrorTab || !serv.activeModels)
                return;
            if (serv.activeModels.html && serv.activeModels.html.storFile)
                serv.menu.toggleErrorTab(EToolsSource.icHTML, serv.activeModels.html.storFile.hasError);
            if (serv.activeModels.ts && serv.activeModels.ts.storFile)
                serv.menu.toggleErrorTab(EToolsSource.icTs, serv.activeModels.ts.storFile.hasError);
            if (serv.activeModels.style && serv.activeModels.style.storFile)
                serv.menu.toggleErrorTab(EToolsSource.icStyle, serv.activeModels.style.storFile.hasError);
            if (serv.activeModels.test && serv.activeModels.test.storFile)
                serv.menu.toggleErrorTab(EToolsSource.icTest, serv.activeModels.test.storFile.hasError);
            if (serv.activeModels.defs && serv.activeModels.defs.storFile)
                serv.menu.toggleErrorTab(EToolsSource.icDefs, serv.activeModels.defs.storFile.hasError);
        });
    }
    changeMode(mode) {
        if (!this.menu || !this.menu.setTabActive || !this.menu.selectTool || this.mode === mode)
            return;
        if (mode.startsWith('ic')) {
            if (this.isModeHistory)
                this.menu.selectTool('History');
            this.menu.setTabActive(EToolsSource[mode]);
        }
        else {
            this.menu.selectTool(mode);
        }
    }
    saveLocalStorageLastOpen(storFile, position) {
        const infoByUser = this.getLocalStorageInfo();
        let lastOpened = infoByUser.lastOpened;
        const keyLocal = this.confE;
        if (!lastOpened[keyLocal])
            lastOpened[keyLocal] = {
                extension: '',
                folder: '',
                level: 0,
                project: 0,
                shortName: ''
            };
        lastOpened[keyLocal].project = storFile.project;
        lastOpened[keyLocal].shortName = storFile.shortName;
        lastOpened[keyLocal].extension = storFile.extension;
        lastOpened[keyLocal].level = storFile.level;
        lastOpened[keyLocal].folder = storFile.folder;
        this.saveLocalStorageInfo(infoByUser);
    }
    openLastFile(level, position) {
        try {
            const infoByUser = this.getLocalStorageInfo();
            let lastOpened = infoByUser.lastOpened;
            const keyLocal = this.confE;
            if (!lastOpened[keyLocal])
                return false;
            const { project, shortName } = lastOpened[keyLocal];
            const models = mls.editor.getModels(project, shortName);
            if (!models)
                return false;
            this.activeModels = models;
            mls.actual[this.level].setFullName(`_${project}_${shortName}`);
            mls.actual[this.level][position] = {
                project,
                shortName,
                extension: '.ts',
                folder: ''
            };
            return true;
        }
        catch (e) {
            return false;
        }
    }
    getActualRef() {
        if (!this.menu.tabs)
            return '';
        try {
            let ret = '';
            if (!mls.actual[2] || !mls.actual[2][this.position])
                return ret;
            const actual = mls.actual[2][this.position];
            const ext = this.menu.tabs.selected === EToolsSource.icTs ? '.ts' : '.html';
            if (!actual)
                return ret;
            ret = mls.stor.getKeyToFiles(actual.project, 2, actual.shortName, actual.folder, ext);
            return ret;
        }
        catch (e) {
            return '';
        }
    }
    onWidgetActionEvents(ev) {
        if (this.position === 'right')
            return;
        if (ev.level !== this.level)
            return;
        if (!ev.desc)
            return;
        const json = JSON.parse(ev.desc);
        switch (json.op) {
            case 'SelectWidget':
                break;
            case 'SelectLine':
                this.selectLineinHTML(json.line, json.origin);
                break;
            default:
                console.info('Erro: opção invalida');
        }
    }
    selectLineinHTML(line, origin) {
        if (!this.menu.tabs)
            return;
        if (this.menu.tabs.selected !== EToolsSource.icHTML || !this._ed1)
            return;
        this.lastOrigin = origin;
        if (origin === 'editor')
            return;
        this.goToLine(line);
    }
    registerProviderHTML() {
        monaco.languages.registerDocumentFormattingEditProvider('html', {
            provideDocumentFormattingEdits: async (model) => {
                const value = model.getValue();
                const formattedValue = formatHtml(value);
                return [{
                        range: model.getFullModelRange(),
                        text: formattedValue
                    }];
            }
        });
    }
    async checkToCreateModelHTML(ev) {
        if (!ev.desc)
            return;
        if (this.position === 'right')
            return;
        try {
            const iPath = JSON.parse(ev.desc);
            if (!iPath || !iPath.project || !iPath.shortName)
                return;
            const keyStorFile = mls.stor.getKeyToFiles(iPath.project, 2, iPath.shortName, '', '.html');
            const storFile = mls.stor.files[keyStorFile];
            if (!storFile)
                throw new Error('Invalid stor file for path:' + keyStorFile);
            await this.getOrCreateModelHtmlOrCss(storFile);
        }
        catch (err) {
            throw new Error(err);
        }
    }
    // Ica States
    handleIcaStateChange(_key, _value) {
        const keyState = `serviceSource.${this.position}`;
        if (!_key.startsWith(keyState))
            return;
        if (_key === `${keyState}.selectedMode` && ['icTs', 'icStyle', 'icHTML', 'icTest', 'History'].includes(_value)) {
            this.changeMode(_value);
        }
        if (_key === `${keyState}.lockMap` && _value) {
            const pageActual = this.getActualL2File();
            if (pageActual) {
                const isLocked = this.isEditorLocked(pageActual);
                if (isLocked)
                    this.lockEditorForFile(pageActual);
                else
                    this.unlockEditorForFile(pageActual);
                this.toogleOverlayLoading(isLocked, 'Executing agent Fix...');
            }
        }
    }
    // Lit rendering
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('msize')) {
            const [w, h, t, l] = this.msize.split(',');
            if (w)
                this.panelRightOpened = (+w) >= this.MINWIDTHTPANELRIGHT;
            if (!this.visible)
                return;
            this.updatedMSizeEditor();
        }
    }
    connectedCallback() {
        if (!globalState._ica)
            globalState._ica = {};
        if (!globalState._ica.less) {
            globalState._ica.less = {
                left: {},
                right: {},
            };
        }
        if (!globalState._ica.serviceSource) {
            globalState._ica.serviceSource = {
                left: {
                    selectedMode: 'icTS',
                    historyLanguage: 'typescript',
                    service: mls.services['100554_serviceSource_left'],
                    lockMap: new Map()
                },
                right: {
                    selectedMode: 'icTS',
                    historyLanguage: 'typescript',
                    service: mls.services['100554_serviceSource_right'],
                    lockMap: new Map()
                },
            };
        }
        this.setAttribute('selectedMode', `{{serviceSource.${this.position}.selectedMode}}`);
        this.setAttribute('historyLanguage', `{{serviceSource.${this.position}.historyLanguage}}`);
        this.setAttribute('lockMap', `{{serviceSource.${this.position}.lockMap}}`);
        super.connectedCallback();
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.registerProviderHTML();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.display = 'block';
        return html `
             <div class="overlay-loading"> <span>${this.textOverlayLoading} <span class="loader"></span> </span> </div>
             <collab-spliter-vertical-var-fixed-100554 msize=${this.msize} withresize="false" fixedheight="100" complementcolor="#1e1e1e">
                <collab-spliter-horizontal-var-fixed-100554
                    slot="top"
                    complementcolor="#1e1e1e"
                    fixedwidth="30%"
                    fixedvisible=${this.mode !== 'icStyle' || this.isModeHistory ? 'hidden' : `${this.panelRightOpened === true ? 'visible' : 'closed'}`} 
                >
                    <mls-editor-100529 style=${this.isModeHistory ? 'display:none;' : 'display:block;'} slot="left"></mls-editor-100529>
                    <mls-editor-100529 style=${this.isModeHistory ? 'display:block;' : 'display:none;'} class="history" slot="left"></mls-editor-100529>
                    <css-helper-index-100554 state="{{ less.${this.position} }}" slot="right" position=${this.position} style="height:100%;"></css-helper-index-100554>
                    
                </collab-spliter-horizontal-var-fixed-100554>

                <div slot="bottom"></div>
        </collab-spliter-vertical-var-fixed-100554>`;
    }
};
ServiceSource100554.projectsLoaded = [];
__decorate([
    property({ type: String })
], ServiceSource100554.prototype, "msize", void 0);
__decorate([
    property({ type: Boolean })
], ServiceSource100554.prototype, "panelRightOpened", void 0);
__decorate([
    property({ type: String })
], ServiceSource100554.prototype, "activeModels", void 0);
__decorate([
    property()
], ServiceSource100554.prototype, "isModeHistory", void 0);
__decorate([
    property({ type: String })
], ServiceSource100554.prototype, "mode", void 0);
__decorate([
    property({ type: String })
], ServiceSource100554.prototype, "textOverlayLoading", void 0);
__decorate([
    property({ type: String })
], ServiceSource100554.prototype, "currentHistorySourceWithoutSave", void 0);
__decorate([
    property({ type: String })
], ServiceSource100554.prototype, "previousHistorySourceWithoutSave", void 0);
__decorate([
    propertyDataSource({ type: String })
], ServiceSource100554.prototype, "currentHistorySource", void 0);
__decorate([
    propertyDataSource({ type: String })
], ServiceSource100554.prototype, "previousHistorySource", void 0);
__decorate([
    propertyDataSource({ type: String })
], ServiceSource100554.prototype, "historyLanguage", void 0);
__decorate([
    propertyDataSource({ type: String })
], ServiceSource100554.prototype, "selectedMode", void 0);
__decorate([
    propertyDataSource()
], ServiceSource100554.prototype, "lockMap", void 0);
__decorate([
    query('mls-editor-100529')
], ServiceSource100554.prototype, "editorEl", void 0);
__decorate([
    query('mls-editor-100529.history')
], ServiceSource100554.prototype, "editorHistoryEl", void 0);
__decorate([
    query('.overlay-loading')
], ServiceSource100554.prototype, "overlayLoading", void 0);
__decorate([
    query('collab-spliter-vertical-var-fixed-100554')
], ServiceSource100554.prototype, "verticalSpliter", void 0);
__decorate([
    query('collab-spliter-horizontal-var-fixed-100554')
], ServiceSource100554.prototype, "horizontalSpliter", void 0);
ServiceSource100554 = ServiceSource100554_1 = __decorate([
    customElement('service-source-100554')
], ServiceSource100554);
export { ServiceSource100554 };
var EToolsSource;
(function (EToolsSource) {
    EToolsSource[EToolsSource["icTs"] = 0] = "icTs";
    EToolsSource[EToolsSource["icHTML"] = 1] = "icHTML";
    EToolsSource[EToolsSource["icStyle"] = 2] = "icStyle";
    EToolsSource[EToolsSource["icTest"] = 3] = "icTest";
    EToolsSource[EToolsSource["icDefs"] = 4] = "icDefs";
})(EToolsSource || (EToolsSource = {}));
