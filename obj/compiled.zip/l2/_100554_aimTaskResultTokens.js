/// <mls shortName="aimTaskResultTokens" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
import { getInfoMyService } from "./_100554_aimHelper";
import { initCollabShowCodeSnippet100554 } from './_100554_collabShowCodeSnippet';
import { initCollabShowCodeDiff100554 } from './_100554_collabShowCodeDiff';
let AimTaskResultTokens = class AimTaskResultTokens extends AimTaskBase {
    constructor() {
        super();
        this.result = '';
        initCollabShowCodeSnippet100554();
        initCollabShowCodeDiff100554();
    }
    onInitializing() {
        this.notifyCompleteByStatus('ok', '');
    }
    firstUpdated(a) {
        super.firstUpdated(a);
        if (this.codeSnippet)
            this.codeSnippet.textIn = this.result;
    }
    renderBody(taskRoot, child) {
        const title = child.title;
        const body = child._tempResult || '';
        const { contentLess, contentsAfterLess, contentsBeforeLess } = this.extractBlocks(body);
        this.result = contentLess;
        return html `
        <details open>
            <summary>${title}</summary>
            <div style='margin: 10px'>
                <div>${contentsBeforeLess}</div>
                <collab-show-code-snippet-100554 language="less" withAccept="true" .onAccept=${this.onAccept.bind(this)}></collab-show-code-snippet-100554>
                <div>${contentsAfterLess}</div>
            </div>
        </details>
            
        `;
    }
    onToogleDetails(event) {
        let detailsElement = event.target;
        detailsElement = detailsElement.closest('details');
        if (!detailsElement)
            return;
        if (!detailsElement.open) {
            this.setTokensDiff();
        }
    }
    async setTokensDiff() {
        if (!this.codeDiff)
            return;
        const activeOpService = this.getActiveOpServiceIfIsValid();
        if (!activeOpService) {
            // this.codeDiff.setInitialHistories('', this.result);
            return;
        }
        ;
        const value = activeOpService.getEditorSource();
        // this.codeDiff.setInitialHistories(value.trim(), this.result.trim());
    }
    getActiveOpServiceIfIsValid() {
        const info = getInfoMyService(this);
        if (!info)
            return undefined;
        const activeServiceOp = info.actServiceOp;
        if (activeServiceOp.tagName !== 'SERVICE-DS-TOKENS-100554')
            return undefined;
        return activeServiceOp;
    }
    onAccept() {
        const activeOpService = this.getActiveOpServiceIfIsValid();
        if (!activeOpService) {
            window.collabMessages.add('The service in the opposite position does not refer to this action', 'error');
            return;
        }
        ;
        const taskWithRef = this.taskRoot.children.find((task) => task.widget === "_100554_aimTaskDsTokens");
        if (!taskWithRef || !taskWithRef.ref) {
            window.collabMessages.add('This action dont have any file ref', 'error');
            return;
        }
        ;
        const actualRef = activeOpService.getActualRef();
        if (taskWithRef.ref !== actualRef) {
            window.collabMessages.add(`The current reference: ${actualRef},  does not match the action reference:${taskWithRef.ref}`, 'error');
            return;
        }
        ;
        const tokensType = taskWithRef.ref.split('_').pop() || '';
        activeOpService.setEditorSource(this.result, tokensType);
    }
    extractBlocks(src) {
        const regex = /^(.*?)```less(.*)```(.*)/s;
        const matches = src.match(regex);
        let contentLess = '';
        let contentsBeforeLess = '';
        let contentsAfterLess = '';
        if (matches) {
            contentsBeforeLess = matches[1] || '';
            contentLess = matches[2] || '';
            contentsAfterLess = matches[3] || '';
        }
        return { contentLess, contentsAfterLess, contentsBeforeLess };
    }
};
__decorate([
    query('collab-show-code-diff-100554')
], AimTaskResultTokens.prototype, "codeDiff", void 0);
__decorate([
    query('collab-show-code-snippet-100554')
], AimTaskResultTokens.prototype, "codeSnippet", void 0);
AimTaskResultTokens = __decorate([
    customElement('aim-task-result-tokens-100554')
], AimTaskResultTokens);
export { AimTaskResultTokens };
