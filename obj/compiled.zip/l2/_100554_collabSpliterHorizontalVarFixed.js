/// <mls shortName="collabSpliterHorizontalVarFixed" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { collab_chevron_right } from './_100554_collabIcons';
let CollabSpliterHorizontalVarFixed100554 = class CollabSpliterHorizontalVarFixed100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.fixedwidth = '0';
        this.complementcolor = '#000';
        this.fixedvisible = 'visible';
        this.spliterWidth = 20;
        this.actualfixedwidth = this.fixedwidth;
        this.msize = '';
        this.open = true;
        this.styles = `
    collab-spliter-horizontal-var-fixed-100554 {
      display: flex;
      height: var(--max-height);
      width: var(--max-width);
      max-width: var(--max-width);
      max-height: var(--max-height);
      position: relative;
    }
    collab-spliter-horizontal-var-fixed-100554 > .spliter {
      display: flex;
      align-items: center;
      width: 20px;
      background-color: var(--complement-color);
      position: relative;
      z-index: 1;
    }
    collab-spliter-horizontal-var-fixed-100554 > .spliter .spliter-button {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 20px;
      height:60px;
      background-color: var(--collab-nav-bg-1);
      cursor: pointer;
      position: relative;
      z-index: 1;
      border-top-left-radius: 5px;
      border-bottom-left-radius: 5px;
    }

    collab-spliter-horizontal-var-fixed-100554 > .spliter .spliter-button i {
      transition: transform 0.8s ease;
    }

    collab-spliter-horizontal-var-fixed-100554 > .spliter .spliter-button.closed i {
      transform: rotate(180deg);
    }

    collab-spliter-horizontal-var-fixed-100554 > .spliter .spliter-button i {
      cursor: pointer;
    }

    collab-spliter-horizontal-var-fixed-100554 > .left-pane, .right-pane {
      overflow: auto;
    }
    collab-spliter-horizontal-var-fixed-100554 > .left-pane {
      background-color: var(--complement-color);
      flex-grow: 1;
    }
    collab-spliter-horizontal-var-fixed-100554 > .right-pane {
      background-color: var(--collab-nav-bg-1);
      transition: width 0.8s;
      max-width: var(--fixed-width);
      width: var(--right-pane-width, var(--fixed-width));
    }
    collab-spliter-horizontal-var-fixed-100554 > .right-pane.closed {
      transition: width 0s;
      width: 0;
    }
  `;
    }
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        if (changedProperties.has('fixedvisible')) {
            this.open = this.fixedvisible === 'visible' ? true : false;
        }
        if (changedProperties.has('open')) {
            this.updatePanelsMSize();
        }
        if (changedProperties.has('msize')) {
            this.setFixedValueInPx();
            this.updatePanelsMSize(!this.open);
        }
        if ((changedProperties.has('fixedvisible') && changedProperties.get('fixedvisible') === 'hidden' && this.fixedvisible === 'visible') ||
            (changedProperties.has('fixedvisible') && this.fixedvisible === 'closed')) {
            this.setFixedValueInPx();
            this.updatePanelsMSize();
        }
        if (changedProperties.has('fixedwidth')) {
            this.setFixedValueInPx();
            this.updatePanelsMSize();
        }
        if (changedProperties.has('complementcolor')) {
            this.style.setProperty('--complement-color', this.complementcolor);
        }
    }
    setFixedValueInPx() {
        if (this.fixedwidth.endsWith('%')) {
            const msize = this.getMSize();
            const percent = this.fixedwidth.replace('%', '');
            const percentInPx = ((+msize.width) / 100) * (+percent);
            const percentInPx2 = Number.parseFloat(percentInPx.toFixed(2));
            this.actualfixedwidth = this.open ? percentInPx2.toString() : '0';
            this.style.setProperty('--fixed-width', this.actualfixedwidth + 'px');
            if (this.open)
                this.style.setProperty('--right-pane-width', this.actualfixedwidth + 'px');
            return;
        }
        this.style.setProperty('--fixed-width', this.actualfixedwidth + 'px');
        if (this.open)
            this.style.setProperty('--right-pane-width', this.actualfixedwidth + 'px');
        this.actualfixedwidth = this.fixedwidth;
    }
    getMSize() {
        const [w, h, t, l] = this.msize.split(',');
        return {
            heigth: h,
            width: w,
            top: t,
            left: l
        };
    }
    getMSizeLeft() {
        const msize = this.getMSize();
        let newWidth = '';
        let newMsize = [];
        if (this.fixedvisible === 'visible')
            newWidth = (+(msize.width) - (+this.actualfixedwidth) - (this.spliterWidth)).toString();
        else if (this.fixedvisible === 'closed')
            newWidth = (+(msize.width) - (+this.spliterWidth)).toString();
        else
            newWidth = msize.width;
        newMsize = [`${newWidth}`, msize.heigth, msize.top, msize.left];
        return newMsize.join(',');
    }
    getMSizeRight() {
        const msize = this.getMSize();
        let newWidth = '';
        let newMsize = [];
        if (this.fixedvisible === 'visible')
            newWidth = this.actualfixedwidth;
        else if (this.fixedvisible === 'closed')
            newWidth = '0';
        else
            newWidth = '0';
        newMsize = [`${newWidth}`, msize.heigth, msize.top, msize.left];
        return newMsize.join(',');
    }
    async delay() {
        await new Promise((resolve) => setTimeout(resolve, 50));
    }
    async updatePanelsMSize(reset = true) {
        if (reset) {
            this.slotLeft?.setAttribute('msize', '');
            this.slotRight?.setAttribute('msize', '');
            await this.delay();
        }
        if (this.slotLeft)
            this.slotLeft.setAttribute('msize', this.getMSizeLeft());
        if (this.slotRight)
            this.slotRight.setAttribute('msize', this.getMSizeRight());
    }
    _applyMSize() {
        const [maxWidth, maxHeight] = this.msize.split(',').map(Number);
        if (!isNaN(maxHeight) && !isNaN(maxWidth)) {
            this.style.setProperty('--max-width', `${maxWidth}px`);
            this.style.setProperty('--max-height', `${maxHeight}px`);
        }
        this.updatePanelsMSize();
    }
    _onSpliterClick(event) {
        const spliter = event.target;
        const button = spliter.closest('.spliter-button');
        if (button) {
            this.fixedvisible = 'visible';
            const rightPane = this.querySelector('.right-pane');
            this.open = !this.open;
            if (this.open) {
                rightPane.classList.remove('closed');
                this.setFixedValueInPx();
                this.style.setProperty('--right-pane-width', this.actualfixedwidth + 'px');
            }
            else {
                this.actualfixedwidth = '0';
                rightPane.classList.add('closed');
                this.style.setProperty('--right-pane-width', '0px');
            }
            this.updatePanelsMSize();
        }
    }
    _distributeContent() {
        const leftPane = this.querySelector('.left-pane');
        const rightPane = this.querySelector('.right-pane');
        const children = Array.from(this.children);
        let msizeNew = this.msize;
        children.forEach(child => {
            const slotName = child.getAttribute('slot');
            if (slotName === 'left' && leftPane) {
                leftPane.appendChild(child);
            }
            else if (slotName === 'right' && rightPane) {
                rightPane.appendChild(child);
            }
        });
        this.updatePanelsMSize();
    }
    firstUpdated() {
        this._distributeContent();
        this.updatePanelsMSize();
    }
    render() {
        return html `
      <div class="left-pane"></div>

      ${(this.fixedvisible === 'visible' || this.fixedvisible === 'closed') ?
            html `<div class="spliter">
                  <div @click=${this._onSpliterClick} class="spliter-button ${!this.open ? "closed" : ""}">
                      <i>${collab_chevron_right}</i>          
                  </div>
              </div>
              <div class="right-pane ${this.fixedvisible === 'closed' ? "closed" : ""}"></div>`
            :
                html ``}
      <style>${this.styles}</style>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabSpliterHorizontalVarFixed100554.prototype, "fixedwidth", void 0);
__decorate([
    property({ type: String })
], CollabSpliterHorizontalVarFixed100554.prototype, "complementcolor", void 0);
__decorate([
    property({ type: String })
], CollabSpliterHorizontalVarFixed100554.prototype, "fixedvisible", void 0);
__decorate([
    property({ type: Number })
], CollabSpliterHorizontalVarFixed100554.prototype, "spliterWidth", void 0);
__decorate([
    property({ type: String })
], CollabSpliterHorizontalVarFixed100554.prototype, "actualfixedwidth", void 0);
__decorate([
    property({ type: String })
], CollabSpliterHorizontalVarFixed100554.prototype, "msize", void 0);
__decorate([
    property()
], CollabSpliterHorizontalVarFixed100554.prototype, "open", void 0);
__decorate([
    query('[slot="left"]')
], CollabSpliterHorizontalVarFixed100554.prototype, "slotLeft", void 0);
__decorate([
    query('[slot="right"]')
], CollabSpliterHorizontalVarFixed100554.prototype, "slotRight", void 0);
CollabSpliterHorizontalVarFixed100554 = __decorate([
    customElement('collab-spliter-horizontal-var-fixed-100554')
], CollabSpliterHorizontalVarFixed100554);
export { CollabSpliterHorizontalVarFixed100554 };
