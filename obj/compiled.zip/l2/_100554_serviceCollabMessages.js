/// <mls shortName="serviceCollabMessages" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { addCoachMark } from './_100554_coachMarks';
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { listThreads, addThread, syncThreads, listUsers, syncUsers } from './_100554_msgDBController';
import './_100554_collabMessagesAdd';
import './_100554_collabMessagesConnect';
import './_100554_wcImage';
import './_100554_collabTasks';
import './_100554_collabMessagesSettings';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Conectar',
    apps: 'Apps',
};
const message_en = {
    loading: 'Loading...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Connect',
    apps: 'Apps',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceCollabMessages100554 = class ServiceCollabMessages100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav-3-service[data-service="_100554_serviceCollabMessages"] .tools collab-nav-3-menu-tools-link[key="toolAdd"] .icon-link{display:none}service-collab-messages-100554 .section-add{padding:1rem}`);
        this.msg = messages['en'];
        this.activeTab = 'CRM';
        this.activeScenerie = 'tabs';
        this.userThreads = {};
        this.details = {
            icon: '&#xf086',
            state: 'foreground',
            position: 'right',
            tooltip: 'Collab Messages',
            visible: true,
            widget: '_100554_serviceCollabMessages',
            level: [0, 2, 3, 5]
        };
        this.menu = {
            title: '',
            main: {
                opReset: { text: 'Reset onboarding', icon: 'f2ea' },
                opSettings: { text: 'Settings', icon: 'f085' },
            },
            tools: {
                toolAdd: {
                    type: 'link',
                    options: [
                        { text: 'Add Thread', icon: '2b' },
                    ]
                }
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: ETabs.CRM,
                options: [
                    { text: this.msg.crm, icon: 'f095' },
                    { text: this.msg.tasks, icon: 'f0ae' },
                    { text: this.msg.docs, icon: 'f02d' },
                    { text: this.msg.connect, icon: 'f0c1' },
                    { text: this.msg.apps, icon: 'f7d9' },
                ]
            },
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
            onClickTools: this.onClickTools.bind(this),
        };
    }
    onClickTabs(index) {
        if (this.activeTab === ETabs[index])
            return;
        this.activeTab = ETabs[index];
    }
    onClickMain(op) {
        if (op === 'opReset')
            this.resetOnBoarding();
        if (op === 'opSettings')
            this.openSettings();
    }
    onClickTools(op) {
        if (op === 'toolAdd')
            this.openAdd();
        else
            throw new Error('Invalid option');
    }
    onServiceClick(visible, reinit, el) {
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.userPerfil = await this.getUser();
        await this.getThreadFromLocalDB();
        this.updateThreads();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.menu.setTabActive)
            this.menu.setTabActive(ETabs[this.activeTab]);
        return this.renderTabs();
    }
    renderTabs() {
        switch (this.activeTab) {
            case 'CRM':
                return this.renderCRM();
            case 'Tasks':
                return this.renderTasks();
            case 'Apps':
                return this.renderApps();
            case 'Docs':
                return this.renderDocs();
            case 'Connect':
                return this.renderConnect();
            case 'Add':
                return this.renderAdd();
            default:
                return html ``;
        }
    }
    renderCRM() {
        this.execCoachMarks('CRM');
        return html `CRM`;
    }
    renderTasks() {
        this.execCoachMarks('Tasks');
        return html `<collab-tasks-100554></collab-tasks-100554>`;
    }
    renderApps() {
        this.execCoachMarks('Apps');
        return html `Apps`;
    }
    renderDocs() {
        this.execCoachMarks('Docs');
        return html `Docs`;
    }
    renderConnect() {
        this.execCoachMarks('Connect');
        return html `<collab-messages-connect-100554 
            style="height:${this.style.height}"
            .userThreads=${{
            CONNECT: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'CONNECT')
                .map((key) => this.userThreads[key])
        }} 
            userId=${this.userPerfil?.userId} 
        ></collab-messages-connect-100554>`;
    }
    renderAdd() {
        return html `
            <collab-messages-add-100554 
                userId=${this.userPerfil?.userId} 
                .afterAdd=${this.onAfterAdd}
            ></collab-messages-add-100554>`;
    }
    openAdd() {
        this.activeTab = 'Add';
        if (this.menu.tabs)
            this.menu.tabs.selected = ETabs.Add;
        if (this.menu.closeMenu)
            this.menu.closeMenu();
    }
    onAfterAdd(response) {
        if (!response.ok) {
            this.setError(response.msg || 'Error on add thread');
            console.error(response.msg);
            return;
        }
        if (response.data)
            addThread(response.data);
    }
    async getUser() {
        try {
            const response = await mls.api.msgGetUserUpdate({ userId: "" });
            return response.user;
        }
        catch (err) {
            this.setError(err.message);
            throw new Error(err.message);
        }
    }
    async updateThreads() {
        if (!this.userPerfil?.userId) {
            this.setError('Invalid userId');
            return;
        }
        const userId = this.userPerfil.userId;
        const userThreads = this.userPerfil.threads;
        for await (let threadId of userThreads) {
            if (this.userThreads[threadId]) {
                continue;
            }
            const threadInfo = await this.getThreadInfo(threadId, userId);
            this.userThreads[threadId] = threadInfo;
            syncThreads([threadInfo.thread]);
            syncUsers(threadInfo.users);
        }
    }
    async getThreadFromLocalDB() {
        const threads = await listThreads();
        const users = await listUsers();
        for (let thread of threads) {
            if (this.userThreads[thread.threadId]) {
                return;
            }
            const threadUsers = [];
            thread.users.forEach((user) => {
                const userDB = users.find((us) => us.userId === user.userId);
                if (userDB)
                    threadUsers.push(userDB);
            });
            this.userThreads[thread.threadId] = {
                thread: thread,
                users: threadUsers
            };
        }
    }
    async getThreadInfo(threadId, userId) {
        try {
            const response = await mls.api.msgGetThreadUpdate({
                threadId,
                userId
            });
            return response;
        }
        catch (err) {
            this.setError('Erro ao buscar threads: ' + err);
            throw new Error(err.message);
        }
    }
    execCoachMarks(name) {
        if (this.visible === 'false')
            return;
        const infoMark = {
            key: `serviceCollabMessage${name}`,
            transparency: "normal",
            fontSize: "1.1em",
            timeClose: 15,
            steps: [
                {
                    elementRef: `collab-nav-3-menu li[data-tooltip="${name}"]`,
                    text: `<div style="padding:1rem;"><wc-image-100554 src="/100554/l3/assets/coachMarkCollabMessages${name}.png"  style="display: block; max-width: 100%; height: auto;"></wc-image-100554></div>`,
                    position: "bottom",
                    marginV: 25,
                    marginH: 25,
                    arrow: "up",
                    duration: 15,
                    autoClose: true,
                },
            ]
        };
        addCoachMark(infoMark);
    }
    resetOnBoarding() {
        const ls = localStorage.getItem('coach-marks-100554');
        if (!ls)
            return;
        const data = JSON.parse(ls);
        ['CRM', 'Tasks', 'Docs', 'Connect', 'Apps'].forEach((tab) => {
            const indexToRemove = data.findIndex((item) => item === `serviceCollabMessage${tab}`);
            if (indexToRemove !== -1) {
                data.splice(indexToRemove, 1);
            }
        });
        localStorage.setItem('coach-marks-100554', JSON.stringify(data));
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    openSettings() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(-1);
        if (this.menu.setMode) {
            const settings = document.createElement('collab-messages-settings-100554');
            settings['serviceBase'] = this;
            this.menu.setMode('page', settings);
        }
        return true;
    }
};
__decorate([
    property()
], ServiceCollabMessages100554.prototype, "activeTab", void 0);
__decorate([
    property()
], ServiceCollabMessages100554.prototype, "activeScenerie", void 0);
__decorate([
    state()
], ServiceCollabMessages100554.prototype, "userPerfil", void 0);
__decorate([
    state()
], ServiceCollabMessages100554.prototype, "userThreads", void 0);
ServiceCollabMessages100554 = __decorate([
    customElement('service-collab-messages-100554')
], ServiceCollabMessages100554);
export { ServiceCollabMessages100554 };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["CRM"] = 0] = "CRM";
    ETabs[ETabs["Tasks"] = 1] = "Tasks";
    ETabs[ETabs["Docs"] = 2] = "Docs";
    ETabs[ETabs["Connect"] = 3] = "Connect";
    ETabs[ETabs["Apps"] = 4] = "Apps";
    ETabs[ETabs["Add"] = 5] = "Add";
})(ETabs || (ETabs = {}));
