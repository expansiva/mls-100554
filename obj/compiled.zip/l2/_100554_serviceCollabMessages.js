/// <mls shortName="serviceCollabMessages" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { addCoachMark } from './_100554_coachMarks';
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { saveUserIdLocalStorage } from "./_100554_aiAgentHelper";
import { listThreads, addThread, listUsers, updateUsers } from './_100554_msgDBController';
import './_100554_collabMessagesAdd';
import './_100554_collabMessagesChat';
import './_100554_collabTasks';
import './_100554_collabMessagesSettings';
import './_100554_collabMessagesFindtask';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Conectar',
};
const message_en = {
    loading: 'Loading...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Connect',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const LOCAL_STORAGE_KEY = '_100554_serviceCollabMessages';
let ServiceCollabMessages100554 = class ServiceCollabMessages100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav-3-service[data-service="_100554_serviceCollabMessages"] .tools collab-nav-3-menu-tools-link[key="toolAdd"] .icon-link{display:none}service-collab-messages-100554{display:block}service-collab-messages-100554 .section-add{padding:1rem}`);
        this.msg = messages['en'];
        this.dataLocal = { lastTab: 'CRM' };
        this.activeTab = 'CRM';
        this.activeScenerie = 'tabs';
        this.isLoadingThread = false;
        this.userThreads = {};
        this.groupSelected = 'CRM';
        this.details = {
            icon: '&#xf086',
            state: 'foreground',
            position: 'right',
            tooltip: 'Collab Messages',
            visible: true,
            widget: '_100554_serviceCollabMessages',
            level: [0, 2, 3, 5]
        };
        this.menu = {
            title: '',
            main: {
                opReset: { text: 'Reset onboarding', icon: 'f2ea' },
                opSettings: { text: 'Settings', icon: 'f085' },
                opFindTask: { text: 'Find Task', icon: 'f002' },
            },
            tools: {
                toolAdd: {
                    type: 'link',
                    options: [
                        { text: 'Add Thread', icon: '2b' },
                    ]
                }
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: ETabs.Loading,
                options: [
                    { text: this.msg.crm, icon: 'f095' },
                    { text: this.msg.tasks, icon: 'f0ae' },
                    { text: this.msg.connect, icon: 'f0c1' },
                    { text: this.msg.docs, icon: 'f02d' },
                ]
            },
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
            onClickTools: this.onClickTools.bind(this),
        };
    }
    onClickTabs(index) {
        if (this.activeTab === ETabs[index]) {
            this.activeTab = 'Loading';
            setTimeout(() => {
                this.activeTab = ETabs[index];
            }, 0);
            return;
        }
        ;
        this.activeTab = ETabs[index];
        this.saveLocalStorage({ lastTab: this.activeTab });
    }
    onClickMain(op) {
        if (op === 'opReset')
            this.resetOnBoarding();
        if (op === 'opSettings')
            this.openSettings();
        if (op === 'opFindTask')
            this.openFindTask();
    }
    onClickTools(op) {
        if (op === 'toolAdd')
            this.openAdd();
        else
            throw new Error('Invalid option');
    }
    onServiceClick(visible, reinit, el) {
    }
    connectedCallback() {
        super.connectedCallback();
        this.loadLocalStorage();
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('activeTab') && ['CRM', 'TASK', 'DOCS', 'CONNECT', 'APPS'].includes(this.activeTab)) {
            this.userPerfil = await this.getUser();
            saveUserIdLocalStorage(this.userPerfil.userId);
            await this.getThreadFromLocalDB();
            this.updateThreads();
        }
        if (changedProperties.has('dataLocal')) {
            if (this.menu.setTabActive && this.activeTab !== 'Loading')
                this.menu.setTabActive(ETabs[this.dataLocal.lastTab]);
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.renderTabs();
    }
    renderTabs() {
        switch (this.activeTab) {
            case 'CRM':
                return this.renderCRM();
            case 'TASK':
                return this.renderTasks();
            case 'DOCS':
                return this.renderDocs();
            case 'CONNECT':
                return this.renderConnect();
            case 'Add':
                return this.renderAdd();
            case 'Loading':
                return html `${this.msg.loading}`;
            default:
                return html ``;
        }
    }
    renderCRM() {
        this.groupSelected = 'CRM';
        this.execCoachMarks('CRM');
        return html `<collab-messages-chat-100554 
            
            .isLoadingThread= ${this.isLoadingThread}
            group="CRM"
            .userThreads=${{
            CRM: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'CRM')
                .map((key) => this.userThreads[key])
        }} 
            userId=${this.userPerfil?.userId} 
        ></collab-messages-chat-100554>`;
    }
    renderTasks() {
        this.groupSelected = 'TASK';
        this.execCoachMarks('Tasks');
        return html `<collab-tasks-100554></collab-tasks-100554>`;
    }
    //style="height:${this.style.height}"
    renderDocs() {
        this.groupSelected = 'DOCS';
        this.execCoachMarks('Docs');
        return html `<collab-messages-chat-100554 
            
            .isLoadingThread= ${this.isLoadingThread}
            group="DOCS"
            .userThreads=${{
            DOCS: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'DOCS')
                .map((key) => this.userThreads[key])
        }} 
            userId=${this.userPerfil?.userId} 
        ></collab-messages-chat-100554>`;
    }
    renderConnect() {
        this.groupSelected = 'CONNECT';
        this.execCoachMarks('Connect');
        return html `<collab-messages-chat-100554 
            
            .isLoadingThread= ${this.isLoadingThread}
            group="CONNECT"
            .userThreads=${{
            CONNECT: Object.keys(this.userThreads)
                .filter((key) => this.userThreads[key].thread.group === 'CONNECT')
                .map((key) => this.userThreads[key])
        }} 
            userId=${this.userPerfil?.userId} 
        ></collab-messages-chat-100554>`;
    }
    renderAdd() {
        const onAddSuccess = () => {
            this.activeTab = this.groupSelected;
        };
        return html `
            <collab-messages-add-100554 
                .onAddSuccess=${onAddSuccess.bind(this)}
                .group=${this.groupSelected}
                userId=${this.userPerfil?.userId} 
            ></collab-messages-add-100554>`;
    }
    openAdd() {
        this.activeTab = 'Add';
        if (this.menu.tabs)
            this.menu.tabs.selected = ETabs.Add;
        if (this.menu.closeMenu)
            this.menu.closeMenu();
    }
    async getUser() {
        try {
            const response = await mls.api.msgGetUserUpdate({ userId: "" });
            return response.user;
        }
        catch (err) {
            this.setError(err.message);
            throw new Error(err.message);
        }
    }
    async updateThreads() {
        if (!this.userPerfil?.userId) {
            this.setError('Invalid userId');
            return;
        }
        this.isLoadingThread = true;
        const userId = this.userPerfil.userId;
        const userThreads = this.userPerfil.threads;
        for await (let threadId of userThreads) {
            if (this.userThreads[threadId]) {
                continue;
            }
            const threadInfo = await this.getThreadInfo(threadId, userId);
            this.userThreads[threadId] = threadInfo;
            addThread(threadInfo.thread);
            updateUsers(threadInfo.users);
        }
        this.isLoadingThread = false;
        this.requestUpdate();
    }
    async getThreadFromLocalDB() {
        const threads = await listThreads();
        const users = await listUsers();
        for (let thread of threads) {
            if (this.userThreads[thread.threadId]) {
                return;
            }
            const threadUsers = [];
            thread.users.forEach((user) => {
                const userDB = users.find((us) => us.userId === user.userId);
                if (userDB)
                    threadUsers.push(userDB);
            });
            this.userThreads[thread.threadId] = {
                thread: thread,
                users: threadUsers
            };
        }
    }
    async getThreadInfo(threadId, userId) {
        try {
            const response = await mls.api.msgGetThreadUpdate({
                threadId,
                userId
            });
            return response;
        }
        catch (err) {
            this.setError('Erro ao buscar threads: ' + err);
            throw new Error(err.message);
        }
    }
    execCoachMarks(name) {
        if (this.visible === 'false')
            return;
        const infoMark = {
            key: `serviceCollabMessage${name}`,
            transparency: "normal",
            fontSize: "1.1em",
            timeClose: 15,
            steps: [
                {
                    elementRef: `collab-nav-3-menu li[data-tooltip="${name}"]`,
                    text: `<div style="padding:1rem;"><img src="/100554/l3/assets/coachMarkCollabMessages${name}.png"  style="display: block; max-width: 100%; height: auto;"></img></div>`,
                    position: "bottom",
                    marginV: 25,
                    marginH: 25,
                    arrow: "up",
                    duration: 15,
                    autoClose: true,
                },
            ]
        };
        addCoachMark(infoMark);
    }
    resetOnBoarding() {
        const ls = localStorage.getItem('coach-marks-100554');
        if (!ls)
            return;
        const data = JSON.parse(ls);
        ['CRM', 'Tasks', 'Docs', 'Connect', 'Apps'].forEach((tab) => {
            const indexToRemove = data.findIndex((item) => item === `serviceCollabMessage${tab}`);
            if (indexToRemove !== -1) {
                data.splice(indexToRemove, 1);
            }
        });
        localStorage.setItem('coach-marks-100554', JSON.stringify(data));
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    openSettings() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(-1);
        if (this.menu.setMode) {
            const settings = document.createElement('collab-messages-settings-100554');
            settings['serviceBase'] = this;
            this.menu.setMode('page', settings);
        }
        return true;
    }
    openFindTask() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(-1);
        if (this.menu.setMode) {
            const settings = document.createElement('collab-messages-findtask-100554');
            settings['serviceBase'] = this;
            this.menu.setMode('page', settings);
        }
        return true;
    }
    saveLocalStorage(data) {
        try {
            localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(data));
        }
        catch (e) {
            console.error('Erro ao salvar no localStorage:', e);
        }
    }
    loadLocalStorage() {
        try {
            const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
            if (stored) {
                this.dataLocal = JSON.parse(stored);
            }
        }
        catch (e) {
            console.error('Erro ao carregar do localStorage:', e);
        }
    }
};
__decorate([
    property()
], ServiceCollabMessages100554.prototype, "dataLocal", void 0);
__decorate([
    property()
], ServiceCollabMessages100554.prototype, "activeTab", void 0);
__decorate([
    property()
], ServiceCollabMessages100554.prototype, "activeScenerie", void 0);
__decorate([
    state()
], ServiceCollabMessages100554.prototype, "isLoadingThread", void 0);
__decorate([
    state()
], ServiceCollabMessages100554.prototype, "userPerfil", void 0);
__decorate([
    state()
], ServiceCollabMessages100554.prototype, "userThreads", void 0);
ServiceCollabMessages100554 = __decorate([
    customElement('service-collab-messages-100554')
], ServiceCollabMessages100554);
export { ServiceCollabMessages100554 };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["CRM"] = 0] = "CRM";
    ETabs[ETabs["TASK"] = 1] = "TASK";
    ETabs[ETabs["CONNECT"] = 2] = "CONNECT";
    ETabs[ETabs["DOCS"] = 3] = "DOCS";
    ETabs[ETabs["Add"] = 4] = "Add";
    ETabs[ETabs["Loading"] = 5] = "Loading";
})(ETabs || (ETabs = {}));
