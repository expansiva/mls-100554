/// <mls shortName="serviceCollabMessages" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { addCoachMark } from './_100554_coachMarks';
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { propertyDataSource } from './_100554_icaLitElement';
import * as chatHelper from './_100554_aimChatHelper';
import './_100554_aimChatHeader';
import './_100554_aimChatRooms';
import './_100554_aimChatMessages';
import './_100554_aimChatMessage';
import './_100554_wcImage';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Conectar',
    apps: 'Apps',
};
const message_en = {
    loading: 'Loading...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Connect',
    apps: 'Apps',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceCollabMessages100554 = class ServiceCollabMessages100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.activeTab = 'CRM';
        this.details = {
            icon: '&#xf086',
            state: 'foreground',
            position: 'right',
            tooltip: 'Collab Messages',
            visible: true,
            widget: '_100554_serviceCollabMessages',
            level: [0, 2, 3, 5]
        };
        this.menu = {
            title: '',
            main: {},
            tools: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: ETabs.CRM,
                options: [
                    { text: this.msg.crm, icon: 'f095' },
                    { text: this.msg.tasks, icon: 'f0ae' },
                    { text: this.msg.docs, icon: 'f02d' },
                    { text: this.msg.connect, icon: 'f0c1' },
                    { text: this.msg.apps, icon: 'f7d9' },
                ]
            },
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.activeRoom = chatHelper.pathActiveRoom;
        this.activeMessage = chatHelper.pathActiveMessage;
        this.activeFilterRooms = chatHelper.pathActiveFilterRooms;
    }
    onClickTabs(index) {
        if (this.activeTab === ETabs[index])
            return;
        this.activeTab = ETabs[index];
    }
    onServiceClick(visible, reinit, el) {
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.menu.setTabActive)
            this.menu.setTabActive(ETabs[this.activeTab]);
        switch (this.activeTab) {
            case 'CRM':
                return this.renderCRM();
            case 'Tasks':
                return this.renderTasks();
            case 'Apps':
                return this.renderApps();
            case 'Docs':
                return this.renderDocs();
            case 'Connect':
                return this.renderConnect();
            default:
                return html ``;
        }
    }
    renderCRM() {
        this.execCoachMarks('CRM');
        return html `CRM`;
    }
    renderTasks() {
        this.execCoachMarks('Tasks');
        const pathRoom = this.getAttribute('activeRoom');
        const pathMessage = this.getAttribute('activeMessage');
        const pathFilter = this.getAttribute('activeFilterRooms');
        const renderRooms = () => {
            return html `<aim-chat-rooms-100554 activeRoom="${pathRoom}" activeMessage="${pathMessage}" activeFilterRooms="${pathFilter}"></aim-chat-rooms-100554>`;
        };
        const renderMessages = () => {
            return html `<aim-chat-messages-100554 activeRoom="${pathRoom}" activeMessage="${pathMessage}" activeFilterRooms="${pathFilter}"></aim-chat-messages-100554>`;
        };
        const renderMessage = () => {
            return html `<aim-chat-message-100554 activeRoom="${pathRoom}" activeMessage="${pathMessage}" activeFilterRooms="${pathFilter}"></aim-chat-message-100554>`;
        };
        console.log('render servicecollabmessages, activerrom=', this.activeRoom, ', activeMessage=', this.activeMessage);
        return html `
            <aim-chat-header-100554
                activeRoom="${pathRoom}"
                activeMessage="${pathMessage}"
                activeFilterRooms="${pathFilter}">
            </aim-chat-header-100554>
            ${!this.activeRoom ? renderRooms() : !this.activeMessage ? renderMessages() : renderMessage()}
        `;
    }
    renderApps() {
        this.execCoachMarks('Apps');
        return html `Apps`;
    }
    renderDocs() {
        this.execCoachMarks('Docs');
        return html `Docs`;
    }
    renderConnect() {
        this.execCoachMarks('Connect');
        return html `Connect`;
    }
    execCoachMarks(name) {
        const infoMark = {
            key: `serviceCollabMessage${name}`,
            transparency: "normal",
            fontSize: "1.1em",
            timeClose: 15,
            steps: [
                {
                    elementRef: `collab-nav-3-menu li[data-tooltip="${name}"]`,
                    text: `<div style="padding:1rem;"><wc-image-100554 src="/100554/l3/assets/coachMarkCollabMessages${name}.png"  style="display: block; max-width: 100%; height: auto;"></wc-image-100554></div>`,
                    position: "bottom",
                    marginV: 25,
                    marginH: 25,
                    arrow: "up",
                    duration: 15,
                    autoClose: true,
                },
            ]
        };
        addCoachMark(infoMark);
    }
};
__decorate([
    property()
], ServiceCollabMessages100554.prototype, "activeTab", void 0);
__decorate([
    propertyDataSource({ type: String, reflect: true })
], ServiceCollabMessages100554.prototype, "activeRoom", void 0);
__decorate([
    propertyDataSource({ type: String, reflect: true })
], ServiceCollabMessages100554.prototype, "activeMessage", void 0);
__decorate([
    propertyDataSource({ type: String, reflect: true })
], ServiceCollabMessages100554.prototype, "activeFilterRooms", void 0);
ServiceCollabMessages100554 = __decorate([
    customElement('service-collab-messages-100554')
], ServiceCollabMessages100554);
export { ServiceCollabMessages100554 };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["CRM"] = 0] = "CRM";
    ETabs[ETabs["Tasks"] = 1] = "Tasks";
    ETabs[ETabs["Docs"] = 2] = "Docs";
    ETabs[ETabs["Connect"] = 3] = "Connect";
    ETabs[ETabs["Apps"] = 4] = "Apps";
})(ETabs || (ETabs = {}));
