/// <mls shortName="serviceCollabMessages" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { addCoachMark } from './_100554_coachMarks';
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Conectar',
    apps: 'Apps',
    titleTasks: 'Todas as tarefas de AI, últimas',
    chats: 'Chats',
    project: 'Projeto',
    titleProject: 'Salas com referencias ao projeto atual',
    titleDocs: 'Salas com documentações e guias',
    add: 'Adicionar',
    titleAdd: 'por favor selecione abaixo para adicionar',
    notFoundReference: 'Referência não encontrada',
    noActionsToAdd: 'Nenhuma ação para adicionar',
    selectColumnsYouWant: 'Selecione as colunas que deseja visualizar',
    save: 'Salvar',
    cancel: 'Cancelar'
};
const message_en = {
    loading: 'Loading...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Connect',
    apps: 'Apps',
    titleTasks: 'All AI Tasks, last',
    chats: 'Chats',
    project: 'Project',
    titleProject: 'Rooms with references to the current project',
    titleDocs: 'Rooms with documentation and guides',
    add: 'Add',
    titleAdd: 'please select below to add',
    notFoundReference: 'Not found reference',
    noActionsToAdd: 'No Actions to Add',
    selectColumnsYouWant: 'Select the columns you want to view',
    save: 'Save',
    cancel: 'Cancel'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceCollabMessages100554 = class ServiceCollabMessages100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.activeTab = 'CRM';
        this.details = {
            icon: '&#xf086',
            state: 'foreground',
            position: 'all',
            tooltip: 'Collab Chat',
            visible: true,
            widget: '_100554_serviceAim',
            level: [0, 2, 3, 5]
        };
        this.menu = {
            title: '',
            main: {},
            tools: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: ETabs.CRM,
                options: [
                    { text: this.msg.crm, icon: 'f095' },
                    { text: this.msg.tasks, icon: 'f0ae' },
                    { text: this.msg.docs, icon: 'f02d' },
                    { text: this.msg.connect, icon: 'f0c1' },
                    { text: this.msg.apps, icon: 'f7d9' },
                ]
            },
            onClickTabs: this.onClickTabs.bind(this),
        };
    }
    onClickTabs(index) {
        if (this.activeTab === ETabs[index])
            return;
        this.activeTab = ETabs[index];
    }
    onServiceClick(visible, reinit, el) {
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.menu.setTabActive)
            this.menu.setTabActive(ETabs[this.activeTab]);
        switch (this.activeTab) {
            case 'CRM':
                return this.renderCRM();
            case 'Tasks':
                return this.renderTasks();
            case 'Apps':
                return this.renderApps();
            case 'Docs':
                return this.renderDocs();
            case 'Connect':
                return this.renderConnect();
            default:
                return html ``;
        }
    }
    renderCRM() {
        return html `CRM`;
    }
    renderTasks() {
        const infoMark = {
            key: "serviceCollabMessageTasks",
            transparency: "normal",
            fontSize: "1.1em",
            timeClose: 12,
            steps: [
                {
                    elementRef: `collab-nav-3-menu li[data-tooltip="Tasks"]`,
                    text: 'Teste',
                    position: "bottom",
                    marginV: 25,
                    marginH: 25,
                    arrow: "up",
                    duration: 3,
                    autoClose: true
                },
            ]
        };
        addCoachMark(infoMark);
        return html `Tasks`;
    }
    renderApps() {
        return html `Apps`;
    }
    renderDocs() {
        return html `Docs`;
    }
    renderConnect() {
        return html `Connect`;
    }
};
__decorate([
    property()
], ServiceCollabMessages100554.prototype, "activeTab", void 0);
ServiceCollabMessages100554 = __decorate([
    customElement('service-collab-messages-100554')
], ServiceCollabMessages100554);
export { ServiceCollabMessages100554 };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["CRM"] = 0] = "CRM";
    ETabs[ETabs["Tasks"] = 1] = "Tasks";
    ETabs[ETabs["Docs"] = 2] = "Docs";
    ETabs[ETabs["Connect"] = 3] = "Connect";
    ETabs[ETabs["Apps"] = 4] = "Apps";
})(ETabs || (ETabs = {}));
