/// <mls shortName="pluginSiteMonitorDashboardErrors" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, svg } from 'lit';
import { property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
export const pluginData = {
    title: "Errors",
    getSvg() {
        return svg `
      <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
        <text x="3" y="17" font-size="14" font-weight="bold">E</text>
      </svg>
    `;
    }
};
export class PluginSiteMonitorDashboardErrors extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.filter = "last 30 days";
    }
    render() {
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <icon>${pluginData.getSvg()}</icon>
                <h2>${this.title}</h2>
                <small>Filter: ${this.filter}</small>
            </header>
        `;
    }
    renderBody() {
        return html `<p>Billing data is in development...</p>`;
    }
}
PluginSiteMonitorDashboardErrors.styles = css `
        .plugin-container {
            background-color: #f4f5ff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        header {
            display: flex;
            align-items: center;
            margin-bottom: 16px;
        }

        icon {
            margin-right: 10px;
        }

        h2 {
            font-size: 18px;
            font-weight: bold;
            margin: 0;
            color: #333;
        }

        small {
            color: #888;
            margin-left: auto;
            font-size: 14px;
        }

        p {
            font-size: 16px;
            color: #555;
        }
    `;
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardErrors.prototype, "filter", void 0);
if (!customElements.get('plugin-site-monitor-dashboard-errors-100554')) {
    customElements.define('plugin-site-monitor-dashboard-errors-100554', PluginSiteMonitorDashboardErrors);
}
