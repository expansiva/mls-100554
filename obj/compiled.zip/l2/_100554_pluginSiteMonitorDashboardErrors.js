/// <mls shortName="pluginSiteMonitorDashboardErrors" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, svg } from 'lit';
import { query, property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
export const pluginData = {
    title: "Errors",
    getSvg() {
        return svg `
     <svg svg width="22" height="22"  style="overflow:visible;enable-background:new 0 0 32 32" viewBox="0 0 32 32" width="32" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g><g id="Error_1_"><g id="Error"><circle cx="16" cy="16" id="BG" r="16" style="fill:#D72828;"/><path d="M14.5,25h3v-3h-3V25z M14.5,6v13h3V6H14.5z" id="Exclamatory_x5F_Sign" style="fill:#E6E6E6;"/></g></g></g></svg>
    `;
    }
};
export class PluginSiteMonitorDashboardErrors extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.filter = "today";
        this.chartData = {};
    }
    async prepare() {
        await import('./_100554_wcChart');
        const dataByFilter = {
            today: [
                ['400', 3],
                ['401', 3],
                ['402', 0],
                ['403', 2],
                ['404', 3],
                ['405', 8],
                ['409', 3],
            ],
            week: [
                ['400', 14],
                ['401', 13],
                ['402', 16],
                ['403', 12],
                ['404', 13],
                ['405', 13],
                ['409', 13],
            ],
            mounth: [
                ['400', 43],
                ['401', 83],
                ['402', 86],
                ['403', 72],
                ['404', 43],
                ['405', 83],
                ['409', 43],
            ],
            all: [
                ['400', 143],
                ['401', 183],
                ['402', 186],
                ['403', 172],
                ['404', 143],
                ['405', 183],
                ['409', 143],
            ],
        };
        this.chartData = {
            legend: {},
            tooltip: {},
            dataset: {
                source: dataByFilter[this.filter || 'today']
            },
            xAxis: { type: 'category' },
            yAxis: {},
            series: [{
                    type: 'bar',
                    itemStyle: {
                        color: (p) => {
                            const colorList = ["#f68a55"];
                            return colorList[p.dataIndex];
                        }
                    }
                }],
        };
        await this.updateComplete;
        if (this.body)
            this.body.innerHTML = `<wc-chart-100554 renderer="svg" datasource=${JSON.stringify(this.chartData)}></wc-chart-100554>`;
    }
    // firstUpdated() {
    //     if (!this.body) return;
    //     this.body.style.height = '500px';
    //     this.body.style.width = '800px';
    //     this.prepare();
    // }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body"></div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
}
PluginSiteMonitorDashboardErrors.styles = css `

        .plugin-body{
            height:100%;
            width:100%;
        }
        .plugin-container {
            background-color: #f4f5ff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            height:100%;
            width:100%;
        }

        header {
            display: flex;
            align-items: center;
            gap:3rem;
            margin-bottom: 16px;
        }
        header > div{
            display:flex;
            gap:.5rem;
        }

        icon {
            margin-right: 10px;
        }

        h2 {
            font-size: 18px;
            font-weight: bold;
            margin: 0;
            color: #333;
        }

        small {
            color: #888;
            margin-left: auto;
            font-size: 14px;
        }

        p {
            font-size: 16px;
            color: #555;
        }
        select {
            border-radius: 13px;
            border: 1px solid #cecece;
            padding: .3rem;
            cursor: pointer;
            outline: none;
        }
    `;
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardErrors.prototype, "filter", void 0);
__decorate([
    property()
], PluginSiteMonitorDashboardErrors.prototype, "chartData", void 0);
__decorate([
    query('.plugin-body')
], PluginSiteMonitorDashboardErrors.prototype, "body", void 0);
if (!customElements.get('plugin-site-monitor-dashboard-errors-100554')) {
    customElements.define('plugin-site-monitor-dashboard-errors-100554', PluginSiteMonitorDashboardErrors);
}
