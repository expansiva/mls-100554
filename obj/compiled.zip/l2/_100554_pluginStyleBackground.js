/// <mls shortName="pluginStyleBackground" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
import { IcaLitElement, propertyDataSource } from './_100554_icaLitElement';
import { getMessageKey } from './_100554_collabLitElement';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    gallery: 'Galeria',
    background: 'Background',
    angle: 'Anglo',
    color: 'Cor',
    transparency: 'Transparencia',
    stop: 'Parar',
    add: 'Add',
    del: 'Del',
    description: 'Um plugin robusto para gerenciar e personalizar propriedades de plano de fundo. Lide facilmente com cores de fundo, imagens, gradientes e padrões para criar designs de UI visualmente atraentes e dinâmicos.'
};
const message_en = {
    gallery: 'Gallery',
    background: 'Background',
    angle: 'Angle',
    color: 'Color',
    transparency: 'Transparency',
    stop: 'Stop',
    add: 'Add',
    del: 'Del',
    description: 'A robust plugin for managing and customizing background properties. Effortlessly handle background colors, images, gradients, and patterns to create visually appealing and dynamic UI designs.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['background', 'background-image'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginCssTokens = class PluginCssTokens extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-background-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);display:block;width:100%}plugin-style-background-100554 input,plugin-style-background-100554 select,plugin-style-background-100554 textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}plugin-style-background-100554 input[type="range"]{width:100%}plugin-style-background-100554 input[type="color"]{min-width:40px}plugin-style-background-100554 .container{display:flex;flex-direction:column;justify-content:center;align-items:center;position:relative}plugin-style-background-100554 .container .showtransparent{content:' ';position:absolute;top:0;left:0;width:100%;height:250px;z-index:0;background-image:linear-gradient(45deg, hsl(0,0%,80%) 25%, transparent 25%),linear-gradient(-45deg, #ccc 25%, transparent 25%),linear-gradient(45deg, transparent 75%, #ccc 75%),linear-gradient(-45deg, transparent 75%, #ccc 75%);background-size:20px 20px;background-position:0 0,0 10px,10px -10px,-10px 0}plugin-style-background-100554 .container .showres{width:100%;height:250px;z-index:1;position:relative}plugin-style-background-100554 .container .showConfigContainer{margin-top:-70px;width:80%;min-height:250px;z-index:2;position:relative;background:white;border-radius:5px;padding:1rem;border:1px solid #dfe1e6;display:flex;flex-wrap:wrap}plugin-style-background-100554 .container .showConfigContainer .showConfig{min-width:50%;padding:.5rem;flex:1}plugin-style-background-100554 .container .showConfigContainer .showConfig .showConfigItem{width:100%;display:flex;flex-direction:column;justify-content:center;align-items:center}plugin-style-background-100554 .container .showConfigContainer .showConfig .showConfigItem .active{background:#c6c5c5;color:#191919}`);
        this.msg = messages['en'];
        this.showFull = 'true';
        this.position = 'left';
        this.info = { tp: 'background', aux: '', itens: [] };
        this.css = '';
        this.actualKey = 'background';
        this.timeonChangeProp = -1;
        this.arrayGallery = [
            'background: radial-gradient(circle, rgb(2, 0, 36) 36%, rgb(60, 70, 193) 66%);',
            'background: linear-gradient(342deg, rgba(34, 193, 195, 0.76) 50%, rgba(45, 253, 121, 0.24) 100%);',
            'background: radial-gradient(circle, rgb(63, 94, 251) 0%, rgb(252, 70, 107) 100%);',
            'background: linear-gradient(342deg, rgb(131, 58, 180) 0%, rgb(253, 29, 29) 50%, rgb(252, 176, 69) 100%);',
            'background: radial-gradient(circle, rgb(238, 174, 202) 0%, rgb(148, 187, 233) 100%);',
            'background: linear-gradient(135deg, rgba(30, 87, 153,1) 0%, rgba(41, 137, 216,1) 50%, rgba(32, 124, 202,1) 51%, rgba(125, 185, 232,1) 100%)',
            'background: linear-gradient(135deg, rgba(76, 76, 76,1) 0%, rgba(89, 89, 89,1) 12%, rgba(102, 102, 102,1) 25%, rgba(71, 71, 71,1) 39%, rgba(44, 44, 44,1) 50%, rgba(0, 0, 0,1) 51%, rgba(17, 17, 17,1) 60%, rgba(43, 43, 43) 76%, rgba(28, 28, 28,1) 91%, rgba(19, 19, 19,1) 100%)',
            'background: linear-gradient(135deg, rgba(243, 197, 189,1) 0%, rgba(232, 108, 87,1) 50%, rgba(234, 40, 3,1) 51%, rgba(255, 102, 0,1) 75%, rgba(199, 34, 0,1) 100%)',
            'background: linear-gradient(90deg, rgba(2, 0, 36,1) 0%, rgba(9, 9, 121,1) 35%, rgba(0, 212, 255,1) 100%)',
            'background: linear-gradient(0deg, rgba(34, 193, 195,1) 0%, rgba(253, 187, 45,1) 100%)',
            'background: linear-gradient(90deg, rgba(131, 58, 180,1) 0%, rgba(253, 29, 29,1) 50%, rgba(252, 176, 69,1) 100%)',
            'background: linear-gradient(310deg, rgba(5, 25, 55, 1) 0%, rgba(0, 77, 122,1) 20%, rgba(0, 135, 147, 1) 40%, rgba(0, 191 ,114, 1) 60%, rgba(168, 235 ,18, 1) 80%)',
            'background: linear-gradient(270deg, rgba(112, 225, 245, 1), rgba(255, 209, 148, 1))',
            'background: linear-gradient(90deg, rgba(85, 98, 112, 1), rgba(255, 107, 107, 1))',
            'background: linear-gradient(90deg, rgba(120, 2, 6,1), rgba(6, 17, 97,1))',
            'background: linear-gradient(120deg, rgba(45, 195, 195,1), rgba(158, 17, 17,1))',
            'background: linear-gradient(90deg, rgba(255, 78, 80,1), rgba(249, 212, 35,1))',
            'background: linear-gradient(90deg, rgba(255,239,0,1) 0%, rgba(127,164,8,1) 35%, rgba(0,212,255,1) 100%)',
            'background: rgba(240, 236, 227,1)',
            'background: rgba(223, 211, 195, 1)',
            'background: rgba(199, 177, 152,1)',
            'background: rgba(221, 221, 221,1)',
            'background: rgba(243, 225, 225, 1)',
            'background: rgba(249, 249, 249, 1)',
            'background: rgba(252, 247, 187, 1)',
            'background: rgba(255, 236, 199, 1)',
            'background: rgba(181, 144, 202, 1)',
            'background: rgba(166, 177, 225, 1)',
            'background: rgba(229, 138, 138, 1)',
            'background: rgba(212, 235, 208, 1)',
            'background: rgba(186, 223, 219, 1)',
            'background: rgba(255, 241, 172, 1)',
            'background: rgba(249, 188, 221, 1)',
            'background: rgba(56, 81, 112, 1)',
            'background: rgba(238, 238, 238, 1)',
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value || !_value.key)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!tags.includes(_value.key))
            return;
        this.actualKey = _value.key;
        this._onIcaStateChange();
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS || !this.state.value)
            return;
        this.configString(`${this.state.key} : ${this.state.value}`);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<div class="container">${this.renderBody()}</div>`;
    }
    renderBody2() {
        return html `

        
            <div class="showtransparent"></div>
            <div class="showres" style="background:${this.css}"></div>
            <div class="showConfigContainer" >
                
                <div class="showConfig" >
                    ${this.renderConfig()}
                    ${this.renderItens()}
                </div>
                <div class="showConfig" >
                    <h4 style="text-align:center;margin-bottom:1rem">${this.msg.gallery}</h4>
                    ${this.renderGallery()}
                </div>
            </div>

        `;
    }
    renderBody() {
        return html `

        ${this.showFull === 'true' ?
            html `
                ${this.renderBody2()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderConfig() {
        if (this.info.tp === 'background') {
            return html `
                <div class="showConfigItem">
                    <div class="active" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-radius: 5px; text-align:center; cursor:pointer">${this.msg.background}</div>
                </div>
            `;
        }
        else if (this.info.tp !== '') {
            return html `
                <div class="showConfigItem" style="display: flex;flex-direction:row; margin-bottom:10px">
                    <div class="${this.info.tp === 'linear-gradient' ? 'active' : ''}" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-top-left-radius: 5px; border-bottom-left-radius: 5px; border-right:0px;  text-align:center; cursor:pointer" @click="${() => this.changeType('linear-gradient')}">Linear-gradient</div>
                    <div class="${this.info.tp === 'radial-gradient' ? 'active' : ''}" style="border: 1px solid #d0cccc; font-size: 80%; padding: 0.2rem; border-top-right-radius: 5px; border-bottom-right-radius: 5px;  text-align:center; cursor:pointer" @click="${() => this.changeType('radial-gradient')}">Radial-gradient</div>
                </div>
                ${this.renderAux()}
            `;
        }
        else {
            return html ``;
        }
    }
    renderAux() {
        if (this.info.tp !== 'linear-gradient')
            return html ``;
        return html `
            <div class="showConfigItem" style="flex-direction:row;  margin-bottom:10px">
                <span style=text-align:center;font-size:80%; color:#6d6d6d;">${this.msg.angle}:</span>
                <input type="number" style="text-align:center;font-size:80%; color:#6d6d6d; " .value=${this.onlyNumber(this.info.aux)} prop="aux" @input="${(e) => this.onChangeAux('aux')}"/>
            </div>
        `;
    }
    renderItens() {
        return html `
            <div class="showConfigItem">
                <div style="display:flex; gap:.5rem; font-size:80%; color:#6d6d6d;margin-bottom:.5rem">
                    <div style="text-align:center; ">${this.msg.color}/${this.msg.transparency}/${this.msg.stop}/</div> 
                    <div style="text-align:center; cursor:pointer" @click="${this.add}">${this.msg.add}</div>
                </div>  
                ${repeat(this.info.itens, ((key) => key.value), ((i, index) => {
            return html `
                        <div style="display:flex; gap:.5rem;margin-bottom:.5rem" index="${index}" class="groupEdit">
                            <input type="color" .value="${i.value}"  prop="color" index="${index}" @change="${(e) => this.onChangeProp(index)}"/> 
                            <input type="range" min="0" max="100" .value="${i.transp}" prop="transp" index="${index}" @input="${(e) => this.onChangeProp(index)}"/> 
                            <input type="number"  min="0" max="100" .value="${i.stop}" prop="stop" index="${index}" @input="${(e) => this.onChangeProp(index)}"></input>
                            <div style="text-align:center;font-size:80%; color:#6d6d6d;cursor:pointer" @click="${(e) => this.del(index)}">${this.msg.del}</div>
                        </div>    
                    `;
        }))}
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div style="display:flex; gap:.5rem; flex-wrap:wrap">
            ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `<div style="width:40px; border-radius:5px; height:30px; cursor:pointer;${css}" @click="${this.clickGallery}" .gallery=${css}></div>`;
        }))}
            </div>
        `;
    }
    //-------------IMPLEMENTS--------------
    clickGallery(e) {
        const el = e.target;
        if (!el)
            return;
        const css = el['gallery'];
        this.actualKey = 'background';
        this.configString(css);
        this.mountMyValue();
    }
    onlyNumber(str) {
        const regexNum = /(\d+(?:\.\d+)?)/;
        const res = str.match(regexNum);
        return res && res[0] ? res[0] : '';
    }
    changeType(tp) {
        if (this.info.tp === tp)
            return;
        if (tp === 'linear-gradient') {
            this.info.tp = 'linear-gradient';
            this.info.aux = '90deg';
        }
        else if (tp === 'radial-gradient') {
            this.info.tp = 'radial-gradient';
            this.info.aux = 'circle';
        }
        this.mountMyValue();
    }
    add() {
        this.info.itens.push({ value: '#000000', transp: '100', stop: '100' });
        if (this.info.itens.length >= 2 && this.info.tp === 'background') {
            this.info.tp = 'linear-gradient';
            this.info.aux = '84deg';
        }
        this.mountMyValue();
    }
    del(index) {
        this.info.itens.splice(index, 1);
        if (this.info.itens.length <= 1 && this.info.tp !== 'background') {
            this.info.tp = 'background';
            this.info.aux = '';
        }
        this.mountMyValue();
    }
    configString(str) {
        this.css = str;
        this.info = { tp: '', aux: '', itens: [] };
        if (str.indexOf('linear-gradient') >= 0) {
            this.info.tp = 'linear-gradient';
        }
        else if (str.indexOf('radial-gradient') >= 0) {
            this.info.tp = 'radial-gradient';
        }
        else {
            this.info.tp = 'background';
        }
        if (this.info.tp === 'background') {
            let cl = str.split(':')[1];
            if (cl.indexOf('rgb') >= 0)
                cl = this.rgbaToHex(cl).vl;
            this.info.itens = [{ value: cl, transp: '100', stop: '' }];
        }
        else {
            let ar = [];
            str = str.substr(str.indexOf('('));
            str = this.changeStr(str);
            ar = str.split(',');
            const auxCount = 100 / (ar.length - 1);
            ar.forEach((i, idx) => {
                if (idx === 0) {
                    this.info.aux = i;
                    return;
                }
                if (i.indexOf('#') >= 0 || i.indexOf('abgr') >= 0 || i.indexOf('bgr') >= 0) {
                    let vl = '';
                    let start = (auxCount * idx) + '';
                    const a2 = i.trim().split(' ');
                    if (a2.length > 0)
                        vl = a2[0].replace('abgr', 'rgba').replace('bgr', 'rgb').replace(/;/g, ',');
                    if (a2.length > 1)
                        start = a2[1].replace('%', '');
                    if (vl === '')
                        return;
                    let vlI = { vl: vl, transp: '100' };
                    if (vl.indexOf('rgb') >= 0) {
                        vlI = this.rgbaToHex(vl);
                    }
                    if (!this.info.itens)
                        this.info.itens = [{ value: vlI.vl, transp: vlI.transp, stop: start }];
                    else
                        this.info.itens.push({ value: vlI.vl, transp: vlI.transp, stop: start });
                }
            });
        }
    }
    rgbaToHex(rgbaString) {
        const match = rgbaString.match(/(\d+(?:\.\d+)?)/g);
        if (!match) {
            return { vl: '', transp: '' };
        }
        const r = parseInt(match[0], 10);
        const g = parseInt(match[1], 10);
        const b = parseInt(match[2], 10);
        const a = match[3] ? (+match[3] * 100).toString() : '100';
        // Converte os componentes RGB para hexadecimal
        const toHex = (component) => {
            const hex = component.toString(16);
            return hex.length === 1 ? '0' + hex : hex;
        };
        // Converte os componentes para hexadecimal
        const hexR = toHex(r);
        const hexG = toHex(g);
        const hexB = toHex(b);
        const hexColor = `#${hexR}${hexG}${hexB}`;
        return { vl: hexColor, transp: a };
    }
    hexToRgba(hex, alpha = 1) {
        // Remove o '#' se estiver presente
        hex = hex.replace(/^#/, '');
        // Converte para r, g, b
        const bigint = parseInt(hex, 16);
        const r = (bigint >> 16) & 255;
        const g = (bigint >> 8) & 255;
        const b = bigint & 255;
        // Retorna a string RGBA
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
    changeStr(s) {
        if (s.indexOf('rgba') >= 0 || s.indexOf('rgb') >= 0) {
            let tp = s.indexOf('rgba') >= 0 ? 'rgba' : 'rgb';
            let tpR = s.indexOf('rgba') >= 0 ? 'abgr' : 'bgr';
            let newst = '';
            let oldstr = '';
            let st = s.indexOf(tp);
            let ste = -1;
            st = s.substr(st).indexOf('(') + st;
            ste = s.substr(st).indexOf(')') + st;
            newst = s.slice(st, ste);
            oldstr = newst;
            newst = newst.replace(/ ,/g, ',').replace(/, /g, ',').replace(/,/g, ';');
            s = s.replace(oldstr, newst).replace(tp, tpR);
            return this.changeStr(s);
        }
        else {
            if (s.indexOf('(') === 0)
                s = s.substr(1);
            if (s.lastIndexOf(')') === s.length - 1)
                s = s.substring(0, s.length - 1);
            if (s.lastIndexOf(');') === s.length - 2)
                s = s.substring(0, s.lastIndexOf(');'));
            return s;
        }
    }
    onChangeProp(index) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            const el = this.querySelector('.groupEdit[index="' + index + '"]');
            if (!el)
                return;
            this.changeValues(el, index);
        }, 500);
    }
    onChangeAux(prop) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            const el = this.querySelector('*[prop="' + prop + '"]');
            this.info.aux = el.value + 'deg';
            this.mountMyValue();
        }, 500);
    }
    changeValues(el, idx) {
        const elC = el.querySelector('input[prop="color"]');
        const elT = el.querySelector('input[prop="transp"]');
        const elS = el.querySelector('input[prop="stop"]');
        if (!elC || !elT || !elS || !this.info.itens[idx])
            return;
        this.info.itens[idx].value = elC.value;
        this.info.itens[idx].transp = elT.value;
        this.info.itens[idx].stop = elS.value;
        this.info.itens.sort((a, b) => a.stop - b.stop);
        this.mountMyValue();
    }
    mountMyValue() {
        let text = '';
        if (this.info.tp === 'background' && this.info.itens.length > 0) {
            text = this.hexToRgba(this.info.itens[0].value, +this.info.itens[0].transp / 100);
        }
        else if (this.info.itens.length > 0) {
            text = `${this.info.tp.trim()}(${this.info.aux.trim()},`;
            this.info.itens.forEach((i, idx) => {
                const aux = idx === this.info.itens.length - 1 ? '' : ',';
                text = text + ` ${this.hexToRgba(i.value, +i.transp / 100)} ${i.stop}%${aux}`;
            });
            text = text + ')';
        }
        this.css = text;
        this.info = Object.assign({}, this.info);
        this.setState();
    }
    setState() {
        window.globalState.less[this.position].emitter = 'helper';
        const styles = window.globalState.less[this.position].lessCSS.styles;
        styles[this.actualKey] = this.css || '';
    }
};
__decorate([
    property()
], PluginCssTokens.prototype, "showFull", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "position", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "info", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "css", void 0);
__decorate([
    propertyDataSource()
], PluginCssTokens.prototype, "state", void 0);
PluginCssTokens = __decorate([
    customElement('plugin-style-background-100554')
], PluginCssTokens);
export { PluginCssTokens };
