/// <mls shortName="collabMessagesConnect" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { collab_chevron_left, collab_user_plus, collab_gear, collab_translate } from './_100554_collabIcons';
import { createAgent } from './_100554_agentPlanner1';
import { getTemporaryContext, formatTimestamp } from './_100554_aiAgentHelper';
import { addOrUpdateTask, addMessages, addMessage, getAllMessagesByThreadId, updateThread, updateUsers, updateThreads } from './_100554_msgDBController';
import { loadChatPreferences } from './_100554_collabMessageHelper';
import './_100554_widgetAiInteraction';
import './_100554_widgetAiTask';
import './_100554_collabMessagesPrompt';
import './_100554_collabMessagesAvatar';
import { IcaLitElement } from './_100554_icaLitElement';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    btnAddParticipant: 'Adicionar participante',
    labelUserId: 'Nome do usuario ou Id',
    labelPermission: 'Autoridade:',
    errorFieldsAddParticipant: 'Preencha todos os campos!',
    successAddParticipant: 'Usuário adicionado com sucesso',
    threadDetails: 'Detalhes da sala'
};
const message_en = {
    loading: 'Loading...',
    btnAddParticipant: 'Add Participant',
    labelUserId: 'User id or name',
    labelPermission: 'Auth:',
    errorFieldsAddParticipant: 'Fill in all fields!',
    successAddParticipant: 'User added sucessfully',
    threadDetails: 'Thread details'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesConnect100554 = class CollabMessagesConnect100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-connect-100554{display:flex;flex-direction:column;height:100%}collab-messages-connect-100554 .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-connect-100554 .header{height:30px;background-color:var(--grey-color-lighter);cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:var(--font-size-12);text-transform:uppercase}collab-messages-connect-100554 .header svg{fill:currentColor}collab-messages-connect-100554 .header .header-actions{margin-left:auto;margin-right:1rem;display:flex;gap:.5rem}collab-messages-connect-100554 .header .header-actions span{cursor:pointer}collab-messages-connect-100554 .header>span{display:flex;align-items:center;gap:.5rem;flex:1;justify-content:center}collab-messages-connect-100554 .thread-list{list-style:none;margin:0;padding:0}collab-messages-connect-100554 .thread-item:hover{background-color:var(--bg-primary-color-focus)}collab-messages-connect-100554 .thread-item{cursor:pointer;transition:background-color .5s;display:flex;align-items:center;padding:.1rem;position:relative;width:100%}collab-messages-connect-100554 .thread-item .back-button{cursor:pointer}collab-messages-connect-100554 .thread-item .avatar{flex:0 0 auto;width:48px;height:48px;border-radius:50%;margin-right:1rem}collab-messages-connect-100554 .thread-item .thread-content{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;border-bottom:1px solid var(--grey-color);padding:.9rem}collab-messages-connect-100554 .thread-item .thread-item-header{display:flex;justify-content:space-between;margin-bottom:.5rem}collab-messages-connect-100554 .thread-item .thread-item-header .thread-name{font-size:1rem;font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-item-header .last-update{font-size:.875rem;color:var(--grey-color-dark);white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-summary{display:flex;justify-content:space-between;align-items:center}collab-messages-connect-100554 .thread-item .thread-summary .last-message{font-size:.875rem;color:var(--text-primary-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}collab-messages-connect-100554 .thread-item .thread-summary .unread-count{background-color:var(--success-color);color:#fff;font-size:.75rem;font-weight:bold;padding:.25rem .5rem;border-radius:12px;margin-left:1rem;white-space:nowrap}collab-messages-connect-100554 .chat-container{display:flex;flex:1;flex-direction:column;padding:10px;width:calc(100% - 20px);overflow-y:auto;max-height:100%}collab-messages-connect-100554 .chat-container .message-time{text-align:center;font-size:.85rem;color:gray;margin-bottom:5px}collab-messages-connect-100554 .chat-container .message{display:flex;flex-direction:column;align-items:flex-start;width:100%;margin-bottom:10px}collab-messages-connect-100554 .chat-container .message.user{align-items:flex-end}collab-messages-connect-100554 .chat-container .message .message-row{max-width:80%;margin-bottom:3px;margin-right:50px;margin-left:50px;position:relative}collab-messages-connect-100554 .chat-container .message .message-row .message-card{display:flex;flex-direction:column;background-color:#f9f9f9;border-radius:8px;padding:.5rem;position:relative;font-size:14px}collab-messages-connect-100554 .chat-container .message .message-row .message-card.system:not(.same):before{content:'';position:absolute;top:10px;left:-7px;width:0;height:0;border-top:8px solid transparent;border-right:8px solid #f9f9f9;border-bottom:8px solid transparent}collab-messages-connect-100554 .chat-container .message .message-row .message-card.user{background-color:#daf8cb;align-self:flex-end}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-title{color:#be069c}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-ai{margin-top:.3rem;display:flex;margin-left:auto}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-content{padding-right:4em;margin-top:.4rem;color:#000;display:flex;align-items:center;gap:.4rem}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-content svg{width:12px;fill:var(--active-color)}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-content.translate{padding:0;margin:0;font-size:11px;font-style:italic;color:#717070;padding-inline-start:6px;border-left:2px solid #717070}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-footer{font-size:.75rem;color:gray;text-align:right}collab-messages-connect-100554 .chat-container .message .message-row collab-messages-avatar-100554{position:absolute;top:3px;left:-40px}collab-messages-connect-100554 .chat-container .message .message-group{display:contents}collab-messages-connect-100554 .add-participant{display:flex;flex-direction:column;gap:1rem;padding:1rem}collab-messages-connect-100554 .add-participant .add-participant-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-connect-100554 .add-participant .add-participant-error{color:var(--error-color);font-size:var(--font-size-12)}collab-messages-connect-100554 .add-participant input,collab-messages-connect-100554 .add-participant select{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;height:30px}collab-messages-connect-100554 .add-participant button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}collab-messages-connect-100554 .add-participant button:hover{background-color:var(--info-color-hover)}`);
        this.msg = messages['en'];
        this.activeScenerie = 'list';
        this.actualMessages = [];
        this.actualMessagesParsed = {};
        this.isLoadingMessages = false;
        this.isAddParticipant = false;
        this.labelOkAddParticipant = '';
        this.labelErrorAddParticipant = '';
        this.userIdOrName = '';
        this.auth = 'write';
        this.userThreads = {
            CONNECT: [{ "thread": { "history": [{ "action": "created", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "update_group", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_language ${language}", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120844.1000", "timestamp": "20250417172252" }, { "action": "add_user", "userId": "20250417004803.1000", "timestamp": "20250417174719" }], "languages": ["pt"], "status": "active", "visibility": "private", "group": "CONNECT", "threadId": "20250417135645.1000", "users": [{ "userId": "20250417120841.1000", "auth": "admin" }, { "userId": "20250417120844.1000", "auth": "write" }, { "userId": "20250417004803.1000", "auth": "write" }], "name": "" }, "users": [{ "threads": ["20250417135645.1000", "20250417180232.1000", "20250417133813.1000"], "name": "Guilherme Pereira", "userId": "20250417120841.1000", "status": "active" }, { "threads": ["20250417133813.1000", "20250417180232.1000"], "name": "Santiago", "userId": "20250417120844.1000", "status": "active" }, { "threads": ["20250417135645.1000"], "name": "Wagner", "userId": "20250417004803.1000", "status": "active" }] }]
        };
        this.savedScrollTop = 0;
        this.messagesLimit = 5;
        this.messagesOffset = 0;
        this.isLoadingMoreMessages = false;
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (this.unreadEl) {
            this.unreadEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }
        if (changedProperties.has('activeScenerie')
            && (changedProperties.get('activeScenerie') === 'task'
                || changedProperties.get('activeScenerie') === 'addParticipant'
                || changedProperties.get('activeScenerie') === 'threadDetails')
            && this.activeScenerie === 'details') {
            this.restoreScrollPosition();
        }
        if (changedProperties.has('actualMessagesParsed') && changedProperties.get('actualMessagesParsed') !== undefined) {
            if (this.messageContainer) {
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            }
        }
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        window.addEventListener('task-change', async (e) => {
            const customEvent = e;
            await this.updateMessageAI(customEvent.detail, false);
            if (customEvent.detail.task) {
                await addOrUpdateTask(customEvent.detail.task);
            }
        });
        window.addEventListener('task-details-close', async (e) => {
            this.onTitleClick();
        });
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.activeScenerie === 'loading') {
            return html `<div class="loading">${this.msg.loading}</div>`;
        }
        return html `
            ${this.renderHeader()}
            ${this.renderContent()}
        `;
    }
    renderHeader() {
        switch (this.activeScenerie) {
            case 'task':
                return html `
                <div class="header">
                    <span @click=${this.onTitleClick}>${collab_chevron_left} Task: ${this.actualTask?.PK || ''}</span>
                </div>`;
            case 'details':
                return html `
                <div class="header">
                    <span @click=${this.onTitleClick}>${collab_chevron_left} Thread: ${this.actualThread?.thread.name || this.actualThread?.thread.threadId}</span>
                    <div class="header-actions">
                        <span @click=${this.onThreadDetailsClick}>${collab_gear}</span>
                        <span @click=${this.onAddParticipantClick}>${collab_user_plus}</span>
                        
                    </div>
                </div>`;
            case 'list':
                return html `<div class="header">Threads</div>`;
            case 'addParticipant':
                return html `
                <div class="header">
                    <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.btnAddParticipant}</span>
                </div>`;
            case 'threadDetails':
                return html `
                <div class="header">
                    <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadDetails}</span>
                </div>`;
            default:
                return null;
        }
    }
    renderContent() {
        switch (this.activeScenerie) {
            case 'list':
                return this.renderListThreads();
            case 'details':
                return this.renderChatMessages();
            case 'task':
                return this.renderTaskDetails();
            case 'addParticipant':
                return this.renderAddParticipant();
            case 'threadDetails':
                return this.renderThreadDetails();
            default:
                return null;
        }
    }
    renderChatMessages() {
        this.userPreferenceChat = loadChatPreferences();
        return html `
            <div class="chat-container">    
                ${Object.keys(this.actualMessagesParsed).map((key) => {
            const threadMessages = this.actualMessagesParsed[key];
            const messageTime = this.parseLocalDate(key);
            return html `
                    <div class="message-time">${messageTime.date}</div>
                            ${threadMessages.map((message) => {
                const dateFormated = formatTimestamp(message.createAt);
                const userName = this.actualThread?.users.find((user) => user.userId === message.senderId)?.name || message.senderId;
                const userAvatar = this.actualThread?.users.find((user) => user.userId === message.senderId)?.avatar_url || '';
                const cls = message.senderId === this.userId ? 'user' : 'system';
                const isSame = message.isSame;
                return html `
                    <div class="message ${cls}">
                        <div class="message-group">
                            <div class="message-row">
                                <div class="message-card ${cls} ${isSame ? 'same' : ''}">
                                    ${!isSame ? html `<div class="message-title">@${userName}</div>` : ``}
                                    ${this.renderMessageByLanguage(message)}
                                    <div class="message-footer">${dateFormated?.time}</div>
                                    ${message.taskId
                    ? html `
                                            <div class="message-ai">
                                                <widget-ai-task-100554 
                                                    messageId=${message.createAt}
                                                    .context= ${message.context}
                                                    lastChanged= ${message.lastChanged}
                                                    taskId=${message.taskId}
                                                    @taskclick=${() => this.onTaskClick(message?.taskId || '', message.threadId, message.createAt)}
                                                    >
                                                </widget-ai-task-100554>
                                            </div>                                            `
                    : html ``}
                                </div> 
                                ${cls === 'system' && !isSame ? html `<collab-messages-avatar-100554 avatar=${userAvatar}></collab-messages-avatar-100554>` : ''} 
                            </div>    
                        </div>
                    </div>`;
            })}`;
        })}
        ${this.isLoadingMessages ? html `<div class="unread-messages" id="unread">Loading messages...</div>` : html ``}
        </div> 

        ${this.renderPrompt()}
                `;
    }
    renderMessageByLanguage(message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.translations) {
            return html `<div class="message-content">${message.content}</div>`;
        }
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.translations ? message.translations[language] : '';
        const isSameLanguege = language === message.language_detected;
        switch (mode) {
            case 'icon':
                return html `
                <div class="message-content">${messageByLanguagePref || message.content} ${!isSameLanguege ? collab_translate : ''}</div>`;
            case 'text':
                return html `
                <div class="message-content">${messageByLanguagePref || message.content}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${message.content}</small>` : ''}`;
            case 'iconText':
                return html `
                <div class="message-content">${messageByLanguagePref || message.content} ${!isSameLanguege ? collab_translate : ''}</div>
                ${!isSameLanguege ? html `<small class="message-content translate">${message.content}</small>` : ''}`;
            default:
                return null;
        }
    }
    renderPrompt() {
        return html `<collab-messages-prompt-100554 .allUsers=${this.actualThread?.users || []} .onSend=${this.handleSend.bind(this)} ></collab-messages-prompt-100554>`;
    }
    renderListThreads() {
        const unreadCount = 1;
        return html ` <ul class="thread-list">
                ${this.userThreads.CONNECT.map((item) => {
            return html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">${item.thread.name || item.thread.threadId}</span>
                                    <span class="last-update">${item.thread.lastMessageTime ? formatTimestamp(item.thread.lastMessageTime)?.date : formatTimestamp(item.thread.history[0].timestamp)?.date}</span>
                                </div>
                                <div class="thread-summary">
                                    <span class="last-message">${item.thread.lastMessage || ''}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : ''}
                                </div>
                            </div>
                        </li>
                    `;
        })}
            </ul>`;
    }
    renderTaskDetails() {
        return html `
            <widget-ai-interaction-100554 .task=${this.actualTask} taskId=${this.actualTask?.PK}></widget-ai-interaction-100554>`;
    }
    renderThreadDetails() {
        return html `In develpoment`;
    }
    renderAddParticipant() {
        this.labelErrorAddParticipant = '';
        this.labelOkAddParticipant = '';
        return html `
        <div class="add-participant">
            <label>
                ${this.msg.labelUserId}
                <input 
                    type="text"
                    .value=${this.userIdOrName}
                    @input=${(e) => this.userIdOrName = e.target.value}
                />
            </label>

            <label>
                ${this.msg.labelPermission}
                <select
                    .value=${this.auth}
                    @change=${(e) => this.auth = e.target.value}
                >
                    <option value="admin">Admin</option>
                    <option value="moderator">Moderator</option>
                    <option value="none">None</option>
                    <option value="read">Read</option>
                    <option value="write">Write</option>
                </select>
            </label>

            <button
                @click=${this.onSubmitAddParticipant}
                ?disabled=${this.isAddParticipant}
            >
                ${this.isAddParticipant ? html `<span class="loader"></span>` : this.msg.btnAddParticipant}
            </button>
            
            ${this.labelOkAddParticipant ? html `<small class="add-participant-ok">${this.labelOkAddParticipant}<small>` : ''}
            ${this.labelErrorAddParticipant ? html `<small class="add-participant-error">${this.labelErrorAddParticipant}<small>` : ''}
        </div>
    `;
    }
    async onChatScroll(e) {
        const container = e.target;
        if (container.scrollTop === 0 && !this.isLoadingMoreMessages && this.actualThread) {
            this.isLoadingMoreMessages = true;
            const previousHeight = container.scrollHeight;
            const newOffset = this.messagesOffset + this.messagesLimit;
            //const newMessages = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, newOffset);
            const newMessages = await getAllMessagesByThreadId(this.actualThread.thread.threadId);
            this.messagesOffset = newOffset;
            this.actualMessages = this.mergeMessages(newMessages, this.actualMessages);
            this.actualMessagesParsed = this.parseMessages(this.actualMessages);
            await this.updateComplete;
            const newHeight = container.scrollHeight;
            container.scrollTop = newHeight - previousHeight;
            this.isLoadingMoreMessages = false;
        }
    }
    async onSubmitAddParticipant() {
        this.labelErrorAddParticipant = '';
        this.labelOkAddParticipant = '';
        if (!this.actualThread || !this.userId) {
            return;
        }
        if (!this.userIdOrName || !this.auth) {
            this.labelErrorAddParticipant = this.msg.errorFieldsAddParticipant;
            return;
        }
        this.isAddParticipant = true;
        try {
            const response = await mls.api.msgAddUserInThread({
                auth: this.auth,
                userIdOrName: this.userIdOrName,
                threadId: this.actualThread?.thread.threadId,
                userId: this.userId,
            });
            if (response.statusCode !== 200) {
                this.labelErrorAddParticipant = `${response.msg}`;
                this.isAddParticipant = false;
                return;
            }
            this.labelOkAddParticipant = `${this.msg.successAddParticipant}`;
            this.userIdOrName = '';
            this.auth = 'write';
            this.isAddParticipant = false;
        }
        catch (error) {
            console.error('Error on add user:', error);
            this.labelErrorAddParticipant = error.message;
            this.isAddParticipant = false;
        }
    }
    async getMessages(thread, lastOrderAt = '') {
        if (!this.userId) {
            return [];
        }
        const response = await mls.api.msgGetNextMessages({
            lastOrderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        return response.data;
    }
    parseMessages(rawData) {
        const groupedByDay = {};
        rawData.forEach(msg => {
            const dateKey = msg.createAt.slice(0, 8).replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
            if (!groupedByDay[dateKey]) {
                groupedByDay[dateKey] = [];
            }
            groupedByDay[dateKey].push(msg);
        });
        for (const day in groupedByDay) {
            groupedByDay[day].sort((a, b) => a.orderAt.localeCompare(b.orderAt));
        }
        return this.groupMessages(groupedByDay);
    }
    groupMessages(groupedByDay) {
        const result = {};
        Object.keys(groupedByDay).forEach((key) => {
            result[key] = groupedByDay[key].map((msg, index, arr) => {
                const isSame = index > 0 && msg.senderId === arr[index - 1].senderId;
                return { ...msg, isSame };
            });
        });
        return result;
    }
    parseLocalDate(dateString) {
        const [year, month, day] = dateString.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        return {
            dateObject: date,
            datafull: date.toLocaleString(), // Ex: "22/04/2025 00:00:00"
            date: date.toLocaleDateString(), // Ex: "22/04/2025"
            time: date.toTimeString().split(' ')[0] // Ex: "00:00:00"
        };
    }
    async onThreadClick(threadInfo) {
        this.activeScenerie = 'loading';
        this.messagesOffset = 0;
        this.actualThread = threadInfo;
        const messagesInDb = await getAllMessagesByThreadId(threadInfo.thread.threadId);
        this.actualMessages = messagesInDb;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages);
        console.info(this.actualMessagesParsed);
        this.activeScenerie = 'details';
        this.isLoadingMessages = true;
        try {
            const messages = await this.getMessages(threadInfo.thread, threadInfo.thread.lastMessageTime || '');
            this.actualMessages = this.mergeMessages(this.actualMessages, messages);
            addMessages(messages);
            this.actualMessagesParsed = this.parseMessages(this.actualMessages);
            const lastMessage = this.actualMessages.length > 0 ? this.actualMessages[this.actualMessages.length - 1] : undefined;
            if (!this.userId || !this.actualThread.thread.threadId)
                return;
            const threadByServer = await this.getThreadInfo(this.actualThread.thread.threadId, this.userId);
            await updateThreads([threadByServer.thread]);
            if (lastMessage && threadByServer) {
                const thread = await updateThread(threadByServer.thread.threadId, lastMessage.content, lastMessage.createAt, 0);
                threadInfo.thread = thread;
            }
            threadInfo.users = threadByServer.users;
            updateUsers(threadInfo.users);
        }
        catch (err) {
            throw new Error('Error on loading messages: ' + err.message);
        }
        finally {
            this.isLoadingMessages = false;
        }
    }
    mergeMessages(array1, array2) {
        const map = new Map();
        for (const item of array1) {
            map.set(`${item.threadId}/${item.createAt}`, item);
        }
        for (const item of array2) {
            map.set(`${item.threadId}/${item.createAt}`, { ...map.get(`${item.threadId}/${item.createAt}`), ...item });
        }
        return Array.from(map.values());
    }
    onTitleClick() {
        if (this.activeScenerie === 'task') {
            this.activeScenerie = 'details';
            return;
        }
        if (this.activeScenerie === 'details') {
            this.activeScenerie = 'list';
            return;
        }
        if (this.activeScenerie === 'addParticipant' || this.activeScenerie === 'threadDetails') {
            this.activeScenerie = 'details';
            return;
        }
    }
    onAddParticipantClick() {
        this.saveScrollPosition();
        this.activeScenerie = 'addParticipant';
    }
    onThreadDetailsClick() {
        this.saveScrollPosition();
        this.activeScenerie = 'threadDetails';
    }
    async handleSend(value, opt) {
        try {
            if (!opt.isSpecialMention) {
                await this.addMessage(value);
            }
            else {
                await this.addMessageIA(value);
            }
        }
        catch (err) {
            throw new Error(err.message);
        }
    }
    async addMessage(prompt) {
        if (!this.userId || !this.actualThread)
            return;
        const params = {
            action: 'addMessage',
            content: prompt,
            threadId: this.actualThread.thread.threadId,
            userId: this.userId
        };
        const response = await mls.api.msgAddMessage(params);
        const { content, createAt, orderAt, senderId, threadId } = response.message;
        this.updateMessage(false, content, createAt, orderAt, senderId, threadId);
    }
    async addMessageIA(prompt) {
        if (!this.userId || !this.actualThread)
            return;
        const context = getTemporaryContext(this.actualThread.thread.threadId, this.userId, prompt);
        const agent = createAgent();
        await agent.beforePrompt(context);
    }
    async updateMessageAI(context, updateThreadDB) {
        if (!context.message && !context.task)
            return;
        const { content, createAt, orderAt, senderId, threadId, taskId } = context.message;
        let messageAdded = this.actualMessages.find((item) => item.content === content &&
            item.senderId === senderId &&
            item.createAt === createAt &&
            item.threadId === threadId);
        if (!messageAdded) {
            const newMessage = {
                content,
                createAt,
                orderAt,
                senderId,
                threadId,
            };
            if (updateThreadDB) {
                const thread = await updateThread(threadId, content, createAt, 0);
                if (this.actualThread)
                    this.actualThread.thread = thread;
            }
            if (taskId)
                newMessage.taskId = taskId;
            this.actualMessages.push({ context, lastChanged: new Date().getTime(), ...newMessage });
            this.actualMessagesParsed = this.parseMessages(this.actualMessages);
            await addMessage(newMessage);
            if (this.collabMessagesPrompt) {
                this.collabMessagesPrompt.text = '';
                this.collabMessagesPrompt.isSending = false;
            }
            this.requestUpdate();
        }
        else {
            messageAdded.content = content;
            messageAdded.senderId = senderId;
            messageAdded.createAt = createAt;
            messageAdded.threadId = threadId;
            messageAdded.orderAt = orderAt;
            messageAdded.context = context;
            messageAdded.lastChanged = new Date().getTime();
            const cloned = structuredClone(messageAdded);
            delete cloned.context;
            delete cloned.lastChanged;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages);
            await addMessage(cloned);
            this.requestUpdate();
        }
    }
    async updateMessage(updateThreadDB, content, createAt, orderAt, senderId, threadId, taskId) {
        const newMessage = {
            content,
            createAt,
            orderAt,
            senderId,
            threadId,
        };
        if (updateThreadDB) {
            const thread = await updateThread(threadId, content, createAt, 0);
            if (this.actualThread)
                this.actualThread.thread = thread;
        }
        if (taskId)
            newMessage.taskId = taskId;
        this.actualMessages.push(newMessage);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages);
        addMessage(newMessage);
        this.requestUpdate();
    }
    async onTaskClick(taskId, messageId, threadId) {
        this.saveScrollPosition();
        this.activeScenerie = 'loading';
        const task = await this.getTaskUpdate(taskId, threadId, messageId);
        addOrUpdateTask(task);
        this.actualTask = task;
        this.activeScenerie = 'task';
    }
    async getTaskUpdate(taskId, threadId, createdAt) {
        if (!taskId || !createdAt || !threadId)
            throw new Error('Invalid args');
        if (!this.userId)
            throw new Error('Invalid userId');
        const taskData = await mls.api.msgGetTaskUpdate({
            taskId,
            messageId: `${createdAt}/${threadId}`,
            userId: this.userId
        });
        if (taskData.statusCode !== 200)
            throw new Error("error on AI get taskUpdate , stoped");
        return taskData.task;
    }
    async getThreadInfo(threadId, userId) {
        try {
            const response = await mls.api.msgGetThreadUpdate({
                threadId,
                userId
            });
            return response;
        }
        catch (err) {
            throw new Error(err.message);
        }
    }
    saveScrollPosition() {
        if (this.messageContainer) {
            this.savedScrollTop = this.messageContainer.scrollTop;
        }
    }
    async restoreScrollPosition() {
        if (this.messageContainer) {
            await this.updateComplete;
            this.messageContainer.scrollTop = this.savedScrollTop;
        }
    }
};
__decorate([
    query('collab-messages-prompt-100554')
], CollabMessagesConnect100554.prototype, "collabMessagesPrompt", void 0);
__decorate([
    query('#unread')
], CollabMessagesConnect100554.prototype, "unreadEl", void 0);
__decorate([
    query('.chat-container')
], CollabMessagesConnect100554.prototype, "messageContainer", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "userPreferenceChat", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "activeScenerie", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualTask", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualMessages", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualMessagesParsed", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "isLoadingMessages", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "isAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "labelOkAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "labelErrorAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "userIdOrName", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "auth", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesConnect100554.prototype, "userThreads", void 0);
CollabMessagesConnect100554 = __decorate([
    customElement('collab-messages-connect-100554')
], CollabMessagesConnect100554);
export { CollabMessagesConnect100554 };
