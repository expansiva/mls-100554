/// <mls shortName="collabMessagesConnect" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_chevron_left, collab_arrow_up_long } from './_100554_collabIcons';
import { createAgent } from './_100554_agentPlanner1';
import { getTemporaryContext } from './_100554_aiAgentHelper';
import { addTask, syncTask, addMessages, addMessage, getMessagesByThreadId, updateThread } from './_100554_msgDBController';
import { formatTimestamp } from './_100554_iaChatBase';
import './_100554_widgetAiInteraction';
import './_100554_widgetAiTask';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
};
const message_en = {
    loading: 'Loading...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesConnect100554 = class CollabMessagesConnect100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-connect-100554{display:flex;flex-direction:column;height:100%}collab-messages-connect-100554 .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-connect-100554 .header{height:30px;background-color:var(--grey-color-lighter);cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:var(--font-size-12);text-transform:uppercase}collab-messages-connect-100554 .thread-list{list-style:none;margin:0;padding:0}collab-messages-connect-100554 .thread-item:hover{background-color:var(--bg-primary-color-focus)}collab-messages-connect-100554 .thread-item{cursor:pointer;transition:background-color .5s;display:flex;align-items:center;padding:.1rem;position:relative;width:100%}collab-messages-connect-100554 .thread-item .back-button{cursor:pointer}collab-messages-connect-100554 .thread-item .avatar{flex:0 0 auto;width:48px;height:48px;border-radius:50%;margin-right:1rem}collab-messages-connect-100554 .thread-item .thread-content{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;border-bottom:1px solid var(--grey-color);padding:.9rem}collab-messages-connect-100554 .thread-item .thread-item-header{display:flex;justify-content:space-between;margin-bottom:.5rem}collab-messages-connect-100554 .thread-item .thread-item-header .thread-name{font-size:1rem;font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-item-header .last-update{font-size:.875rem;color:var(--grey-color-dark);white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-summary{display:flex;justify-content:space-between;align-items:center}collab-messages-connect-100554 .thread-item .thread-summary .last-message{font-size:.875rem;color:var(--text-primary-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}collab-messages-connect-100554 .thread-item .thread-summary .unread-count{background-color:var(--success-color);color:#fff;font-size:.75rem;font-weight:bold;padding:.25rem .5rem;border-radius:12px;margin-left:1rem;white-space:nowrap}collab-messages-connect-100554 .chat-container{display:flex;flex:1;flex-direction:column;padding:10px;width:calc(100% - 20px);overflow-y:auto;max-height:100%}collab-messages-connect-100554 .chat-container .message-time{text-align:center;font-size:.85rem;color:gray;margin-bottom:5px}collab-messages-connect-100554 .chat-container .message{display:flex;flex-direction:column;align-items:flex-start;width:100%;margin-bottom:10px}collab-messages-connect-100554 .chat-container .message.user{align-items:flex-end}collab-messages-connect-100554 .chat-container .message .message-row{max-width:80%;margin-bottom:3px;margin-right:50px;margin-left:50px}collab-messages-connect-100554 .chat-container .message .message-row .message-card{display:flex;flex-direction:column;background-color:#f9f9f9;border:1px solid #ddd;border-radius:8px;padding:1rem;position:relative}collab-messages-connect-100554 .chat-container .message .message-row .message-card.user{background-color:#daf8cb;align-self:flex-end}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-title{color:#be069c}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-ai{margin-top:.3rem;display:flex;margin-left:auto}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-content{padding-right:4em;margin-top:.4rem}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-footer{font-size:.75rem;color:gray;text-align:right}collab-messages-connect-100554 .chat-container .message .message-group{display:contents}collab-messages-connect-100554 .wrapper{position:relative;display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-radius:12px;height:100px}collab-messages-connect-100554 .wrapper textarea{padding:10px 15px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none}collab-messages-connect-100554 .wrapper .suggestions{position:absolute;bottom:53%;left:5%;right:0;background:white;border:1px solid #ccc;z-index:10;display:block;width:200px;border-radius:10px}collab-messages-connect-100554 .wrapper .suggestion{padding:5px 10px;cursor:pointer}collab-messages-connect-100554 .wrapper .suggestion:hover{background:#f0f0f0}collab-messages-connect-100554 .wrapper button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease}collab-messages-connect-100554 .wrapper button:disabled{background-color:#e0e0e0;cursor:not-allowed}`);
        this.msg = messages['en'];
        this.activeScenerie = 'list';
        this.actualMessages = [];
        this.actualMessagesParsed = {};
        this.isSending = false;
        this.isLoadingMessages = false;
        this.text = '';
        this.suggestions = [];
        this.mentionList = ['collabIA'];
        this.showSuggestions = false;
        this.userThreads = {
            CONNECT: [{ "thread": { "history": [{ "action": "created", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "update_group", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_language ${language}", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120844.1000", "timestamp": "20250417172252" }, { "action": "add_user", "userId": "20250417004803.1000", "timestamp": "20250417174719" }], "languages": ["pt"], "status": "active", "visibility": "private", "group": "CONNECT", "threadId": "20250417135645.1000", "users": [{ "userId": "20250417120841.1000", "auth": "admin" }, { "userId": "20250417120844.1000", "auth": "write" }, { "userId": "20250417004803.1000", "auth": "write" }], "name": "" }, "users": [{ "threads": ["20250417135645.1000", "20250417180232.1000", "20250417133813.1000"], "name": "Guilherme Pereira", "userId": "20250417120841.1000", "status": "active" }, { "threads": ["20250417133813.1000", "20250417180232.1000"], "name": "Santiago", "userId": "20250417120844.1000", "status": "active" }, { "threads": ["20250417135645.1000"], "name": "Wagner", "userId": "20250417004803.1000", "status": "active" }] }]
        };
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (this.unreadEl) {
            this.unreadEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.activeScenerie === 'loading') {
            return html `<div class="loading">${this.msg.loading}</div>`;
        }
        return html `
            <div class="header">
                ${this.activeScenerie === 'task'
            ? html `<span @click=${this.onTitleClick}>${collab_chevron_left} Task: ${this.actualTask?.PK || ''}</span>`
            : this.activeScenerie === 'details'
                ? html `<span @click=${this.onTitleClick}>${collab_chevron_left} Thread: ${this.actualThread?.thread.name || this.actualThread?.thread.threadId}</span>`
                : this.activeScenerie === 'list'
                    ? html `Threads`
                    : ''}
                </div>

                ${this.activeScenerie === 'list'
            ? this.renderListThreads()
            : this.activeScenerie === 'details'
                ? this.renderChatMessages()
                : this.activeScenerie === 'task'
                    ? this.renderTaskDetails()
                    : ''}
        `;
    }
    renderChatMessages() {
        return html `
            <div class="chat-container">    
                ${Object.keys(this.actualMessagesParsed).map((key) => {
            const threadMessages = this.actualMessagesParsed[key];
            const messageTime = this.parseLocalDate(key);
            return html `
                        <div class="message-time">${messageTime.date}</div>
                        ${threadMessages.map((message) => {
                const dateFormated = formatTimestamp(message.createAt);
                const userName = this.actualThread?.users.find((user) => user.userId === message.senderId)?.name || message.senderId;
                const cls = message.senderId === this.userId ? 'user' : 'system';
                return html `
                                <div class="message ${cls}">
                                    <div class="message-group">
                                        <div class="message-row">
                                            <div class="message-card ${cls}">
                                                <div class="message-title">@${userName}</div>
                                                <div class="message-content">${message.content}</div>
                                                <div class="message-footer">${dateFormated.time}</div>
                                                ${message.taskId
                    ? html `
                                                    <div class="message-ai">
                                                            <widget-ai-task-100554 
                                                                messageId=${message.createAt}
                                                                taskId=${message.taskId}
                                                                @taskclick=${() => this.onTaskClick(message?.taskId || '', message.threadId, message.createAt)}
                                                                >
                                                            </widget-ai-task-100554>
                                                    </div>
                                                                        `
                    : html ``}
                                            </div>
                                                
                                        </div>
                            
                                </div>
                            </div> 
                    `;
            })}`;
        })}

                ${this.isLoadingMessages
            ? html `<div class="unread-messages" id="unread">Loading messages...</div>`
            : html ``}
                </div> 
                   <div class="wrapper">
                        <textarea
                            .value=${this.text}
                            @input=${this.handleInput}
                            id="prompt_input"
                            ?readonly=${this.isSending}
                            placeholder="Digite aqui... (@ para menções)"
                        >
                        </textarea>
                        ${this.showSuggestions
            ? html `
                                <div class="suggestions">
                                    ${this.suggestions.map((s) => html `
                                        <div class="suggestion" @click=${() => this.selectSuggestion(s)}>
                                        ${s}
                                        </div>
                                    `)}
                                </div>
                                `
            : null}
                        <button 
                            @click=${this.handleSend} 
                            ?disabled=${this.isSending}
                            >
                            ${this.isSending
            ? html `<span class="loader"></span>`
            : collab_arrow_up_long}
                            </button>

                    </div>
                `;
    }
    renderListThreads() {
        const unreadCount = 1;
        return html ` <ul class="thread-list">
                ${this.userThreads.CONNECT.map((item) => {
            return html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">${item.thread.name || item.thread.threadId}</span>
                                    <span class="last-update">${item.thread.lastMessageTime ? formatTimestamp(item.thread.lastMessageTime).date : formatTimestamp(item.thread.history[0].timestamp).date}</span>
                                </div>
                                <div class="thread-summary">
                                <span class="last-message">${item.thread.lastMessage || ''}</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : ''}
                                </div>
                            </div>
                        </li>
                    `;
        })}
            </ul>`;
    }
    renderTaskDetails() {
        //stepId=${this.stepIdSelected}
        return html `
            <widget-ai-interaction-100554 .task=${this.actualTask} taskId=${this.actualTask?.PK} .payloads=${this.actualTask?.iaCompressed?.nextSteps}></widget-ai-interaction-100554>
        `;
    }
    async getMessages(thread, lastOrderAt = '') {
        if (!this.userId) {
            return [];
        }
        const response = await mls.api.msgGetNextMessages({
            action: 'getNextMessages',
            lastOrderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        return response.data;
    }
    parseMessages(rawData) {
        const groupedByDay = {};
        rawData.forEach(msg => {
            const dateKey = msg.createAt.slice(0, 8).replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
            if (!groupedByDay[dateKey]) {
                groupedByDay[dateKey] = [];
            }
            groupedByDay[dateKey].push(msg);
        });
        for (const day in groupedByDay) {
            groupedByDay[day].sort((a, b) => a.orderAt.localeCompare(b.orderAt));
        }
        return groupedByDay;
    }
    parseLocalDate(dateString) {
        const [year, month, day] = dateString.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        return {
            dateObject: date,
            datafull: date.toLocaleString(), // Ex: "22/04/2025 00:00:00"
            date: date.toLocaleDateString(), // Ex: "22/04/2025"
            time: date.toTimeString().split(' ')[0] // Ex: "00:00:00"
        };
    }
    async onThreadClick(threadInfo) {
        this.activeScenerie = 'loading';
        this.actualThread = threadInfo;
        const messagesInDb = await getMessagesByThreadId(threadInfo.thread.threadId);
        this.actualMessages = messagesInDb;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages);
        this.activeScenerie = 'details';
        this.isLoadingMessages = true;
        try {
            const messages = await this.getMessages(threadInfo.thread, threadInfo.thread.lastMessageTime || '');
            this.actualMessages = [...this.actualMessages, ...messages];
            //this.actualMessages = messages;
            addMessages(messages);
            this.actualMessagesParsed = this.parseMessages(this.actualMessages);
            const lastMessage = this.actualMessages.length > 0 ? this.actualMessages[this.actualMessages.length - 1] : undefined;
            if (lastMessage) {
                const thread = await updateThread(threadInfo.thread.threadId, lastMessage.content, lastMessage.createAt, 0);
                threadInfo.thread = thread;
            }
            console.info({
                actual: this.actualThread,
                actualMessages: this.actualMessages,
                actualMessagesParsed: this.actualMessagesParsed
            });
        }
        catch (err) {
            throw new Error('Error on loading messages: ' + err.message);
        }
        finally {
            this.isLoadingMessages = false;
        }
    }
    onTitleClick() {
        if (this.activeScenerie === 'task') {
            this.activeScenerie = 'details';
            return;
        }
        if (this.activeScenerie === 'details') {
            this.activeScenerie = 'list';
            return;
        }
    }
    handleInput(e) {
        const target = e.target;
        this.text = target.value;
        const cursorPos = target.selectionStart;
        const textBeforeCursor = this.text.slice(0, cursorPos);
        if (textBeforeCursor.startsWith('@')) {
            const match = textBeforeCursor.match(/^@(\w*)$/);
            if (match) {
                const query = match[1].toLowerCase();
                this.suggestions = this.mentionList.filter(opt => opt.toLowerCase().startsWith(query));
                this.showSuggestions = this.suggestions.length > 0;
            }
            else {
                this.showSuggestions = false;
            }
        }
        else {
            this.showSuggestions = false;
        }
    }
    selectSuggestion(option) {
        const textarea = this.renderRoot.querySelector('textarea');
        if (!textarea)
            return;
        const cursorPos = textarea.selectionStart;
        const textBefore = this.text.slice(0, cursorPos);
        const match = textBefore.match(/@(\w*)$/);
        const beforeMention = this.text.slice(0, match?.index);
        const afterText = this.text.slice(cursorPos);
        this.text = `${beforeMention}@${option} ${afterText}`;
        this.showSuggestions = false;
        textarea.value = this.text;
        textarea.focus();
    }
    async handleSend() {
        if (this.isSending)
            return;
        const trimmed = this.text.trim();
        const mentionMatch = trimmed.match(/^@(\w+)/);
        const mention = mentionMatch ? mentionMatch[1] : null;
        if (!this.text)
            return;
        this.isSending = true;
        try {
            if (!mention) {
                await this.addMessage(this.text);
            }
            else if (mention && mention === 'collabIA') {
                await this.addMessageIA(this.text);
            }
        }
        catch (err) {
            throw new Error(err.message);
        }
        finally {
            this.isSending = false;
        }
    }
    async addMessage(prompt) {
        if (!this.userId || !this.actualThread)
            return;
        const params = {
            action: 'addMessage',
            content: prompt,
            threadId: this.actualThread.thread.threadId,
            userId: this.userId
        };
        const response = await mls.api.msgAddMessage(params);
        const { content, createAt, orderAt, senderId, threadId } = response.message;
        this.updateMessage(content, createAt, orderAt, senderId, threadId);
    }
    async addMessageIA(prompt) {
        if (!this.userId || !this.actualThread)
            return;
        const text = this.preparePromptIA(prompt);
        const context = getTemporaryContext(this.actualThread.thread.threadId, this.userId, text);
        const agent = createAgent();
        await agent.beforePrompt(context);
        const { content, createAt, orderAt, senderId, threadId, taskId } = context.message;
        if (context.task)
            await addTask(context.task);
        this.updateMessage(content, createAt, orderAt, senderId, threadId, taskId);
    }
    preparePromptIA(prompt) {
        return prompt.replace('@collabIA', '');
    }
    async updateMessage(content, createAt, orderAt, senderId, threadId, taskId) {
        const newMessage = {
            content,
            createAt,
            orderAt,
            senderId,
            threadId,
        };
        if (taskId)
            newMessage.taskId = taskId;
        this.actualMessages.push(newMessage);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages);
        this.text = '';
        addMessage(newMessage);
        this.requestUpdate();
    }
    async onTaskClick(taskId, messageId, threadId) {
        this.activeScenerie = 'loading';
        const task = await this.getTaskUpdate(taskId, threadId, messageId);
        task.status;
        syncTask(task);
        this.actualTask = task;
        this.activeScenerie = 'task';
    }
    async getTaskUpdate(taskId, threadId, createdAt) {
        if (!taskId || !createdAt || !threadId)
            throw new Error('Invalid args');
        if (!this.userId)
            throw new Error('Invalid userId');
        const taskData = await mls.api.msgGetTaskUpdate({
            action: 'getTaskUpdate',
            taskId,
            messageId: `${createdAt}/${threadId}`,
            userId: this.userId
        });
        if (taskData.statusCode !== 200)
            throw new Error("error on AI get taskUpdate , stoped");
        return taskData.task;
    }
};
__decorate([
    query('#prompt_input')
], CollabMessagesConnect100554.prototype, "promptInput", void 0);
__decorate([
    query('#unread')
], CollabMessagesConnect100554.prototype, "unreadEl", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "activeScenerie", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualTask", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualMessages", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualMessagesParsed", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "isSending", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "isLoadingMessages", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "text", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "suggestions", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "mentionList", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "showSuggestions", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesConnect100554.prototype, "userThreads", void 0);
CollabMessagesConnect100554 = __decorate([
    customElement('collab-messages-connect-100554')
], CollabMessagesConnect100554);
export { CollabMessagesConnect100554 };
