/// <mls shortName="collabMessagesConnect" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_chevron_left } from './_100554_collabIcons';
let CollabMessagesConnect100554 = class CollabMessagesConnect100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-connect-100554{display:block;padding:1rem 0}collab-messages-connect-100554 .header{height:30px;background-color:var(--grey-color-lighter);cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:var(--font-size-12);text-transform:uppercase}collab-messages-connect-100554 .thread-list{list-style:none;margin:0;padding:0}collab-messages-connect-100554 .thread-item:hover{background-color:var(--bg-primary-color-focus)}collab-messages-connect-100554 .thread-item{cursor:pointer;transition:background-color .5s;display:flex;align-items:center;padding:.1rem;position:relative;width:100%}collab-messages-connect-100554 .thread-item .back-button{cursor:pointer}collab-messages-connect-100554 .thread-item .avatar{flex:0 0 auto;width:48px;height:48px;border-radius:50%;margin-right:1rem}collab-messages-connect-100554 .thread-item .thread-content{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;border-bottom:1px solid var(--grey-color);padding:.9rem}collab-messages-connect-100554 .thread-item .thread-item-header{display:flex;justify-content:space-between;margin-bottom:.5rem}collab-messages-connect-100554 .thread-item .thread-item-header .thread-name{font-size:1rem;font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-item-header .last-update{font-size:.875rem;color:var(--grey-color-dark);white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-summary{display:flex;justify-content:space-between;align-items:center}collab-messages-connect-100554 .thread-item .thread-summary .last-message{font-size:.875rem;color:var(--text-primary-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}collab-messages-connect-100554 .thread-item .thread-summary .unread-count{background-color:var(--success-color);color:#fff;font-size:.75rem;font-weight:bold;padding:.25rem .5rem;border-radius:12px;margin-left:1rem;white-space:nowrap}`);
        this.activeScenerie = 'list';
        this.userThreads = { "CONNECT": [{ "history": [{ "action": "created", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "update_group", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_language ${language}", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120844.1000", "timestamp": "20250417172252" }, { "action": "add_user", "userId": "20250417004803.1000", "timestamp": "20250417174719" }], "languages": ["pt"], "status": "active", "visibility": "private", "group": "CONNECT", "threadId": "20250417135645.1000", "users": [{ "userId": "20250417120841.1000", "auth": "admin" }, { "userId": "20250417120844.1000", "auth": "write" }, { "userId": "20250417004803.1000", "auth": "write" }], "name": "" }] };
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
    }
    render() {
        const unreadCount = 6;
        console.info(this.userThreads);
        return html `

        <div class="header">
            ${this.activeScenerie === 'details'
            ? html `<span @click=${this.onTitleClick} >${collab_chevron_left} Thread: ${this.actualThread?.name || this.actualThread?.threadId}</span>`
            : html `Threads`}
            
        </div>

        ${this.activeScenerie === 'list'
            ? html `
                <ul class="thread-list">
                ${this.userThreads?.CONNECT.map((thread) => {
                return html `
                        <li @click=${() => this.onThreadClick(thread)} class="thread-item">
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">${thread.name || thread.threadId}</span>
                                    <span class="last-update">2025-04-01</span>
                                </div>
                                <div class="thread-summary">
                                <span class="last-message">In develpoment</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : ''}
                                </div>
                            </div>
                        </li>
                    `;
            })}
            </ul>`
            : html `
                <div>In develpoment</div>
            `}
        
    `;
    }
    onThreadClick(thread) {
        this.actualThread = thread;
        this.activeScenerie = 'details';
    }
    onTitleClick() {
        this.activeScenerie = 'list';
    }
};
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "activeScenerie", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualThread", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesConnect100554.prototype, "userThreads", void 0);
CollabMessagesConnect100554 = __decorate([
    customElement('collab-messages-connect-100554')
], CollabMessagesConnect100554);
export { CollabMessagesConnect100554 };
