/// <mls shortName="collabMessagesConnect" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_chevron_left, collab_arrow_up_long } from './_100554_collabIcons';
import { createAgent } from './_100554_agentPlanner1';
import { getTemporaryContext } from './_100554_aiAgentHelper';
import './_100554_widgetAiTask';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
};
const message_en = {
    loading: 'Loading...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesConnect100554 = class CollabMessagesConnect100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-connect-100554{display:flex;flex-direction:column;padding:1rem 0;height:100%}collab-messages-connect-100554 .header{height:30px;background-color:var(--grey-color-lighter);cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:var(--font-size-12);text-transform:uppercase}collab-messages-connect-100554 .thread-list{list-style:none;margin:0;padding:0}collab-messages-connect-100554 .thread-item:hover{background-color:var(--bg-primary-color-focus)}collab-messages-connect-100554 .thread-item{cursor:pointer;transition:background-color .5s;display:flex;align-items:center;padding:.1rem;position:relative;width:100%}collab-messages-connect-100554 .thread-item .back-button{cursor:pointer}collab-messages-connect-100554 .thread-item .avatar{flex:0 0 auto;width:48px;height:48px;border-radius:50%;margin-right:1rem}collab-messages-connect-100554 .thread-item .thread-content{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;border-bottom:1px solid var(--grey-color);padding:.9rem}collab-messages-connect-100554 .thread-item .thread-item-header{display:flex;justify-content:space-between;margin-bottom:.5rem}collab-messages-connect-100554 .thread-item .thread-item-header .thread-name{font-size:1rem;font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-item-header .last-update{font-size:.875rem;color:var(--grey-color-dark);white-space:nowrap}collab-messages-connect-100554 .thread-item .thread-summary{display:flex;justify-content:space-between;align-items:center}collab-messages-connect-100554 .thread-item .thread-summary .last-message{font-size:.875rem;color:var(--text-primary-color);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}collab-messages-connect-100554 .thread-item .thread-summary .unread-count{background-color:var(--success-color);color:#fff;font-size:.75rem;font-weight:bold;padding:.25rem .5rem;border-radius:12px;margin-left:1rem;white-space:nowrap}collab-messages-connect-100554 .chat-container{display:flex;flex:1;flex-direction:column;padding:10px;width:calc(100% - 20px);overflow-y:auto;max-height:100%}collab-messages-connect-100554 .chat-container .message-time{text-align:center;font-size:.85rem;color:gray;margin-bottom:5px}collab-messages-connect-100554 .chat-container .message{display:flex;flex-direction:column;align-items:flex-start;width:100%;margin-bottom:10px}collab-messages-connect-100554 .chat-container .message.user{align-items:flex-end}collab-messages-connect-100554 .chat-container .message .message-row{max-width:80%;margin-bottom:3px;margin-right:50px;margin-left:50px}collab-messages-connect-100554 .chat-container .message .message-row .message-card{display:flex;flex-direction:column;background-color:#f9f9f9;border:1px solid #ddd;border-radius:8px;padding:1rem;position:relative}collab-messages-connect-100554 .chat-container .message .message-row .message-card.user{background-color:#daf8cb;align-self:flex-end}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-title{color:#be069c}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-content{padding-right:4em;margin-top:.4rem}collab-messages-connect-100554 .chat-container .message .message-row .message-card .message-footer{font-size:.75rem;color:gray;position:absolute;bottom:5px;right:10px;text-align:right}collab-messages-connect-100554 .chat-container .message .message-group{display:contents}collab-messages-connect-100554 .wrapper{position:relative;display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-radius:12px;height:100px}collab-messages-connect-100554 .wrapper textarea{padding:10px 15px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none}collab-messages-connect-100554 .wrapper .suggestions{position:absolute;bottom:53%;left:5%;right:0;background:white;border:1px solid #ccc;z-index:10;display:block;width:200px;border-radius:10px}collab-messages-connect-100554 .wrapper .suggestion{padding:5px 10px;cursor:pointer}collab-messages-connect-100554 .wrapper .suggestion:hover{background:#f0f0f0}collab-messages-connect-100554 .wrapper button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease}collab-messages-connect-100554 .wrapper button:disabled{background-color:#e0e0e0;cursor:not-allowed}`);
        this.msg = messages['en'];
        this.activeScenerie = 'list';
        this.actualMessages = [];
        this.actualMessagesParsed = {};
        this.text = '';
        this.suggestions = [];
        this.mentionList = ['collabIA'];
        this.showSuggestions = false;
        this.userThreads = {
            CONNECT: [{ "thread": { "history": [{ "action": "created", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "update_group", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_language ${language}", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120841.1000", "timestamp": "20250417135645" }, { "action": "add_user", "userId": "20250417120844.1000", "timestamp": "20250417172252" }, { "action": "add_user", "userId": "20250417004803.1000", "timestamp": "20250417174719" }], "languages": ["pt"], "status": "active", "visibility": "private", "group": "CONNECT", "threadId": "20250417135645.1000", "users": [{ "userId": "20250417120841.1000", "auth": "admin" }, { "userId": "20250417120844.1000", "auth": "write" }, { "userId": "20250417004803.1000", "auth": "write" }], "name": "" }, "users": [{ "threads": ["20250417135645.1000", "20250417180232.1000", "20250417133813.1000"], "name": "Guilherme Pereira", "userId": "20250417120841.1000", "status": "active" }, { "threads": ["20250417133813.1000", "20250417180232.1000"], "name": "Santiago", "userId": "20250417120844.1000", "status": "active" }, { "threads": ["20250417135645.1000"], "name": "Wagner", "userId": "20250417004803.1000", "status": "active" }] }]
        };
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const unreadCount = 6;
        if (this.activeScenerie === 'loading') {
            return html `<div class="loading">${this.msg.loading}</div>`;
        }
        return html `

        <div class="header">
            ${this.activeScenerie === 'details'
            ? html `<span @click=${this.onTitleClick} >${collab_chevron_left} Thread: ${this.actualThread?.thread.name || this.actualThread?.thread.threadId}</span>`
            : html `Threads`}
            
        </div>

        ${this.activeScenerie === 'list'
            ? html `
                <ul class="thread-list">
                ${this.userThreads.CONNECT.map((item) => {
                return html `
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">${item.thread.name || item.thread.threadId}</span>
                                    <span class="last-update">2025-04-01</span>
                                </div>
                                <div class="thread-summary">
                                <span class="last-message">In develpoment</span>
                                    ${unreadCount > 0 ? html `<span class="unread-count">${unreadCount}</span>` : ''}
                                </div>
                            </div>
                        </li>
                    `;
            })}
            </ul>`
            : html `
                <div class="chat-container">
                    
                ${Object.keys(this.actualMessagesParsed).map((key) => {
                const threadMessages = this.actualMessagesParsed[key];
                const messageTime = this.parseLocalDate(key);
                return html `
                        <div class="message-time">${messageTime.date}</div>
                        ${threadMessages.map((message) => {
                    const dateFormated = this.formatTimestamp(message.createAt);
                    const userName = this.actualThread?.users.find((user) => user.userId === message.senderId)?.name || message.senderId;
                    const cls = message.senderId === this.userId ? 'user' : 'system';
                    return html `
                                ${message.taskId
                        ? html `
                                        <div class="message ${cls}">
                                            <widget-ai-task-100554 
                                                taskTitle=${message.content}
                                                taskTime=${dateFormated.time}
                                                taskUserName=${userName}
                                                taskId=${message.taskId}>
                                            </widget-ai-task-100554>
                                        </div>`
                        : html `
                                        <div class="message ${cls}">
                                            <div class="message-group">
                                                <div class="message-row">
                                                <div class="message-card ${cls}">
                                                    <div class="message-title">@${userName}</div>
                                                    <div class="message-content">${message.content}</div>
                                                    <div class="message-footer">${dateFormated.time}</div>
                                                </div>
                                                </div>
                                            </div>
                                        </div> 
                                    `}`;
                })}
                    
                    `;
            })}    
                </div> 
                   <div class="wrapper">
                        <textarea
                            .value=${this.text}
                            @input=${this.handleInput}
                            id="prompt_input"
                            placeholder="Digite aqui... (@ para menções)"
                        >
                        </textarea>
                        ${this.showSuggestions
                ? html `
                                <div class="suggestions">
                                    ${this.suggestions.map((s) => html `
                                        <div class="suggestion" @click=${() => this.selectSuggestion(s)}>
                                        ${s}
                                        </div>
                                    `)}
                                </div>
                                `
                : null}
                        <button @click=${this.handleSend}>
                            ${collab_arrow_up_long}
                        </button>
                    </div>
                `}
        `;
    }
    async getMessages(thread) {
        if (!this.userId) {
            return [];
        }
        const response = await mls.api.msgGetNextMessages({
            action: 'getNextMessages',
            lastOrderAt: '',
            threadId: thread.threadId,
            userId: this.userId
        });
        return response.data;
    }
    parseMessages(rawData) {
        const groupedByDay = {};
        rawData.forEach(msg => {
            const dateKey = msg.createAt.slice(0, 8).replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
            if (!groupedByDay[dateKey]) {
                groupedByDay[dateKey] = [];
            }
            groupedByDay[dateKey].push(msg);
        });
        for (const day in groupedByDay) {
            groupedByDay[day].sort((a, b) => a.orderAt.localeCompare(b.orderAt));
        }
        return groupedByDay;
    }
    parseLocalDate(dateString) {
        const [year, month, day] = dateString.split('-').map(Number);
        const date = new Date(year, month - 1, day);
        return {
            dateObject: date,
            datafull: date.toLocaleString(), // Ex: "22/04/2025 00:00:00"
            date: date.toLocaleDateString(), // Ex: "22/04/2025"
            time: date.toTimeString().split(' ')[0] // Ex: "00:00:00"
        };
    }
    formatTimestamp(timestamp) {
        if (!timestamp || timestamp.length !== 14) {
            throw new Error("Formato de timestamp inválido");
        }
        const year = timestamp.slice(0, 4);
        const month = timestamp.slice(4, 6);
        const day = timestamp.slice(6, 8);
        const hour = timestamp.slice(8, 10);
        const minute = timestamp.slice(10, 12);
        const second = timestamp.slice(12, 14);
        // Cria o objeto Date no formato UTC
        const utcDate = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, // Meses são indexados de 0 a 11
        parseInt(day), parseInt(hour), parseInt(minute), parseInt(second)));
        // Converte para o horário local
        const localDate = utcDate.toLocaleString('pt-BR', {
            timeZoneName: 'short'
        });
        // Converte os componentes individuais para o formato local
        const localYear = utcDate.getFullYear();
        const localMonth = (utcDate.getMonth() + 1).toString().padStart(2, '0');
        const localDay = utcDate.getDate().toString().padStart(2, '0');
        const localHour = utcDate.getHours().toString().padStart(2, '0');
        const localMinute = utcDate.getMinutes().toString().padStart(2, '0');
        const localSecond = utcDate.getSeconds().toString().padStart(2, '0');
        const date = `${localYear}-${localMonth}-${localDay}`;
        const time = `${localHour}:${localMinute}:${localSecond}`;
        const dateFull = `${date} ${time}`;
        return { dateFull, date, time };
    }
    async onThreadClick(threadInfo) {
        this.activeScenerie = 'loading';
        this.actualThread = threadInfo;
        const messages = await this.getMessages(threadInfo.thread);
        this.actualMessages = messages;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages);
        console.info({
            actual: this.actualThread,
            actualMessages: this.actualMessages,
            actualMessagesParsed: this.actualMessagesParsed
        });
        this.activeScenerie = 'details';
    }
    onTitleClick() {
        this.activeScenerie = 'list';
    }
    handleInput(e) {
        const target = e.target;
        this.text = target.value;
        const cursorPos = target.selectionStart;
        const textBeforeCursor = this.text.slice(0, cursorPos);
        if (textBeforeCursor.startsWith('@')) {
            const match = textBeforeCursor.match(/^@(\w*)$/);
            if (match) {
                const query = match[1].toLowerCase();
                this.suggestions = this.mentionList.filter(opt => opt.toLowerCase().startsWith(query));
                this.showSuggestions = this.suggestions.length > 0;
            }
            else {
                this.showSuggestions = false;
            }
        }
        else {
            this.showSuggestions = false;
        }
    }
    selectSuggestion(option) {
        const textarea = this.renderRoot.querySelector('textarea');
        if (!textarea)
            return;
        const cursorPos = textarea.selectionStart;
        const textBefore = this.text.slice(0, cursorPos);
        const match = textBefore.match(/@(\w*)$/);
        const beforeMention = this.text.slice(0, match?.index);
        const afterText = this.text.slice(cursorPos);
        this.text = `${beforeMention}@${option} ${afterText}`;
        this.showSuggestions = false;
        textarea.value = this.text;
        textarea.focus();
    }
    handleSend() {
        const trimmed = this.text.trim();
        const mentionMatch = trimmed.match(/^@(\w+)/);
        const mention = mentionMatch ? mentionMatch[1] : null;
        console.info({
            message: this.text,
            mention
        });
        if (!this.text)
            return;
        if (!mention) {
            this.addMessage(this.text);
            return;
        }
        if (mention && mention === 'collabIA') {
            this.addMessageIA(this.text);
        }
    }
    async addMessage(prompt) {
        if (!this.userId || !this.actualThread)
            return;
        const params = {
            action: 'addMessage',
            content: prompt,
            threadId: this.actualThread.thread.threadId,
            userId: this.userId
        };
        const response = await mls.api.msgAddMessage(params);
        const { content, createAt, orderAt, senderId, threadId } = response.message;
        const newMessage = {
            content,
            createAt,
            orderAt,
            senderId,
            threadId,
        };
        this.actualMessages.push(newMessage);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages);
        this.text = '';
        this.requestUpdate();
        console.info({
            addMessage: response
        });
    }
    async addMessageIA(prompt) {
        if (!this.userId || !this.actualThread)
            return;
        const context = getTemporaryContext(this.actualThread.thread.threadId, this.userId, prompt);
        const agent = createAgent();
        await agent.beforePrompt(context);
        console.info(context);
        this.text = '';
        this.requestUpdate();
    }
};
__decorate([
    query('#prompt_input')
], CollabMessagesConnect100554.prototype, "promptInput", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "activeScenerie", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualThread", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualMessages", void 0);
__decorate([
    property()
], CollabMessagesConnect100554.prototype, "actualMessagesParsed", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "text", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "suggestions", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "mentionList", void 0);
__decorate([
    state()
], CollabMessagesConnect100554.prototype, "showSuggestions", void 0);
__decorate([
    property({ attribute: false })
], CollabMessagesConnect100554.prototype, "userThreads", void 0);
CollabMessagesConnect100554 = __decorate([
    customElement('collab-messages-connect-100554')
], CollabMessagesConnect100554);
export { CollabMessagesConnect100554 };
