/// <mls shortName="aimActionUpdateLit" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { tasks, updateTaskOnServer } from './_100554_aimHelper';
import { AimActionBase } from './_100554_aimActionBase';
const myName = '_100554_aimActionUpdateLit';
/// **collab_i18n_start**
const message_pt = {
    title: 'Permitir atualizar o lit do file selecionado',
    prompt: 'Prompt',
    cancel: 'Cancelar',
    confirm: 'Confirmar'
};
const message_en = {
    title: 'Allow updating the lit of the selected file',
    prompt: 'Prompt',
    cancel: 'Cancel',
    confirm: 'Confirm'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let AimActionUpdateLit = class AimActionUpdateLit extends AimActionBase {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.assistant = "gpt_ts";
        this.title = "Update Lit";
        this.language = 'english';
    }
    getRules() {
        return [{
                level: 2,
                tags: ["*serviceSource*"]
            }];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return super.render();
    }
    handleCancel() {
        this.dispatchEvent(new CustomEvent('add-task', {
            detail: { cancel: 'true' }, bubbles: true, composed: true
        }));
    }
    handleAdd() {
        const taskRoot = {
            mode: 'initializing',
            title: 'update Lit',
            widget: myName,
            children: [],
            args: this.textarea?.value || '',
            trace: [new Date().toISOString() + ': trask created at ']
        };
        tasks.unshift(taskRoot);
        this.prepareTask1(taskRoot);
        this.dispatchEvent(new CustomEvent('finished-add-task-root', {
            detail: taskRoot, bubbles: true, composed: true
        }));
    }
    renderAdd() {
        return html `
        <p style="margin-bottom:0rem">${this.msg.title}</p>
        <br>
        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
          <label>${this.msg.prompt}</label>
          <textarea></textarea>
        </div>
        <br>
        <div class="buttonGroup">
          <button @click="${this.handleCancel}">${this.msg.cancel}</button>
          <button @click="${this.handleAdd}">${this.msg.confirm}</button>
        </div>
    `;
    }
    getPrompt(source, user) {
        const prompt = `
        User Instructions:\n
        ${user}\n\n
        Source:\n
        \`\`\`typescript
        ${source}
        \`\`\``;
        return prompt;
    }
    prepareTask1(taskRoot) {
        // create task to get typescript source from another side
        this.mode = taskRoot.mode = 'in progress';
        this.addTaskAndWaitForCompletion(taskRoot, {
            mode: 'initializing',
            title: 'get typescript source',
            widget: '_100554_aimTaskTSSource',
            trace: [],
            nextStep: this.prepareTask2.name // danger, loop
        });
    }
    prepareTask2(taskFinishResult) {
        // call LLM on server with prompt
        const child = taskFinishResult.taskChild;
        if (taskFinishResult.status === 'error') {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            return;
        }
        const source = taskFinishResult.result;
        if (!source) {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            child.trace.push('invalid finish , must be notify finish with result field');
            this.requestUpdate();
            return;
        }
        child.mode = 'processed';
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
            mode: 'initializing',
            title: 'exec prompt',
            widget: '_100554_aimTaskExecLLM',
            agent: this.assistant,
            prompt: this.getPrompt(source, taskFinishResult.taskRoot.args || ''),
            trace: [],
            nextStep: this.prepareTask3.name // danger, loop
        });
    }
    prepareTask3(taskFinishResult) {
        // show result
        const child = taskFinishResult.taskChild;
        const result = child.result || '';
        if (taskFinishResult.status === 'error' || !result) {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            return;
        }
        child.mode = 'processed';
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
            mode: 'initializing',
            title: 'result',
            widget: '_100554_aimTaskResultCode',
            trace: [],
            _tempResult: result,
            nextStep: this.endTasks.name // danger, loop
        });
        this.requestUpdate();
    }
    endTasks(taskFinishResult) {
        const child = taskFinishResult.taskChild;
        if (taskFinishResult.status === 'error')
            child.mode = 'error';
        else
            child.mode = 'processed';
        this.mode = taskFinishResult.taskRoot.mode = child.mode;
        this.requestUpdate();
        updateTaskOnServer(taskFinishResult.taskIndex);
    }
};
__decorate([
    query('textarea')
], AimActionUpdateLit.prototype, "textarea", void 0);
AimActionUpdateLit = __decorate([
    customElement('aim-action-update-lit-100554')
], AimActionUpdateLit);
export { AimActionUpdateLit };
