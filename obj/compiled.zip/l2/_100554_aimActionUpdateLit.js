/// <mls shortName="aimActionUpdateLit" project="100554" enhancement="_100554_enhancementLit" />
import { html } from 'lit';
import { tasks, updateTaskOnServer, extractScript } from './_100554_aimHelper';
import { AimActionBase } from './_100554_aimActionBase';
import { convertFileNameToTag } from './_100554_utilsLit';
const myName = '_100554_aimActionUpdateLit';
export class AimActionUpdateLit extends AimActionBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.assistant = "gpt_ts";
        this.title = 'user Prompt';
        this.language = 'english';
    }
    getRules() {
        return [{
                level: 2,
                tags: []
            }];
    }
    handleCancel() {
        this.dispatchEvent(new CustomEvent('add-task', {
            detail: { cancel: 'true' }, bubbles: true, composed: true
        }));
    }
    renderAdd() {
        return html ``;
    }
    // public function
    // return task created or -1
    add(args) {
        if (!!args.error || !args.prompt) {
            console.error(' error on prompt: ', args.error);
            return -1;
        }
        const taskRoot = {
            mode: 'initializing',
            title: args.title,
            widget: myName,
            children: [],
            args: JSON.stringify(args),
            trace: [new Date().toISOString() + ': trask created at ']
        };
        const taskid = tasks.push(taskRoot) - 1;
        this.mode = taskRoot.mode = 'in progress';
        this.prepareTaskExe(args, taskRoot);
        return taskid;
    }
    prepareTaskExe(args, taskRoot) {
        // call LLM on server with prompt
        this.addTaskAndWaitForCompletion(taskRoot, {
            mode: 'initializing',
            title: 'exec prompt',
            ref: args.fileRef,
            widget: '_100554_aimTaskExecLLM',
            agent: this.assistant,
            prompt: args.prompt,
            trace: [],
            nextStep: this.prepareTaskResult.name // danger, loop
        });
    }
    prepareTaskResult(taskFinishResult) {
        // show result
        const child = taskFinishResult.taskChild;
        const result = child.result || '';
        if (taskFinishResult.status === 'error' || !result) {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            return;
        }
        child.mode = 'processed';
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
            mode: 'initializing',
            title: 'result',
            widget: '_100554_aimTaskResultText',
            trace: [],
            _tempResult: result,
            nextStep: this.endTasks.name // danger, loop
        });
        this.requestUpdate();
        const args = JSON.parse(taskFinishResult.taskRoot.args || '');
        this.updateModelTS(result, args.fileRef, taskFinishResult.taskRoot.key || '', args.modelType);
    }
    endTasks(taskFinishResult) {
        const child = taskFinishResult.taskChild;
        if (taskFinishResult.status === 'error')
            child.mode = 'error';
        else
            child.mode = 'processed';
        this.mode = taskFinishResult.taskRoot.mode = child.mode;
        this.requestUpdate();
        updateTaskOnServer(taskFinishResult.taskIndex);
    }
    async updateModelTS(newContent, fileRef, key, modelType) {
        if (!fileRef || !fileRef.startsWith('_'))
            throw new Error('Invalid fileRef in taskRoot:' + key + ', fileRef:' + fileRef);
        const ts = extractScript(newContent, /```typescript([\s\S]+?)```/g);
        let eModel = mls.editor.models[fileRef];
        if (!eModel || !eModel.ts) {
            await this.loadModelTS(fileRef);
            eModel = mls.editor.models[fileRef];
        }
        if (!eModel || !eModel.ts)
            throw new Error('invalid fileRef in taskRoot, model dont exists: ' + fileRef);
        if (modelType !== 'ts')
            throw new Error('invalid modelType in taskRoot, must be "ts": ' + key);
        const model = eModel.ts?.model;
        model.setValue(ts);
    }
    async loadModelTS(fileRef) {
        // fileRef, ex _[project]_shortName
        mls.actual[0].setFullName(fileRef);
        const key = mls.stor.getKeyToFiles(mls.actual[0].project || 0, 2, /* level */ mls.actual[0].path || '', '', /** folder */ '.ts' /** extension */);
        const file = mls.stor.files[key];
        if (!file)
            throw new Error('file dont exists: key=' + key);
        const content = await file.getContent('') || '';
        if (typeof content !== 'string')
            throw new Error('invalid file string in key ' + key);
        mls.editor.createModelTS(file, content);
    }
}
const tag = convertFileNameToTag(myName);
if (!customElements.get(tag)) {
    customElements.define(tag, AimActionUpdateLit);
}
const cl = new AimActionUpdateLit();
export const add = (args) => cl.add(args);
