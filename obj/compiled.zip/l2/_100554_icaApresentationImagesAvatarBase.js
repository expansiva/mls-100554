/// <mls shortName="icaApresentationImagesAvatarBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { StateLitElement } from './_100554_stateLitElement';
export class IcaApresentationImagesAvatarBase extends StateLitElement {
}
