/// <mls shortName="aimTaskPrepareIcaSource" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { getInfoMyService } from "./_100554_aimHelper";
import { AimTaskBase } from "./_100554_aimTaskBase";
import { convertFileNameToTag } from "./_100554_utilsLit";
import { getAttributeDefinitionsLit } from './_100554_icaBaseDescription';
let AimTaskPrepareIcaSource = class AimTaskPrepareIcaSource extends AimTaskBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    onInitializing() {
        this.getSource();
    }
    getSource() {
        const promp = this.taskChild.prompt;
        if (!promp) {
            this.notifyCompleteByStatus('error', 'Invalid data in prompt');
            return;
        }
        const obj = JSON.parse(promp);
        this._getSource(obj).then((ret) => {
            const result = ret;
            this.notifyCompleteByStatus('ok', result);
        }).catch((e) => {
            this.notifyCompleteByStatus('error', e);
        });
    }
    _getSource(data) {
        return new Promise(async (resolve, reject) => {
            try {
                const info = getInfoMyService(this);
                if (!info) {
                    reject('Not found info');
                    return;
                }
                const { path, project } = mls.actual[2];
                if (!path || !project) {
                    reject('Not found path or project');
                    return;
                }
                const fullName = mls.actual[2].getFullName();
                const mfile = mls.l2.editor.mfiles[fullName];
                if (!mfile) {
                    reject('Not found mfile');
                    return;
                }
                const tps = mfile.compilerResults?.tripleSlashMLS;
                if (!tps) {
                    reject('Not found tripleSlashMLS in mfile compilerResults');
                    return;
                }
                const activeServiceOp = info.actServiceOp;
                if (activeServiceOp.tagName !== 'SERVICE-SOURCE-100554') {
                    reject('100554_ServiceSource is not active in level 2');
                    return;
                }
                const regexRemoveSpaces = /\s+/g;
                const group = (data.group.join('')).replace(regexRemoveSpaces, '');
                const tagName = convertFileNameToTag(fullName);
                const className = path.charAt(0).toUpperCase() + path.substring(1, path.length);
                const importFile = `_100554_ica${group}`;
                const extend = `Ica${group}`;
                const [root, subgroup, finalgroup] = data.group;
                const props = getAttributeDefinitionsLit(root, subgroup, finalgroup);
                const template = `
/// <mls shortName="${tps.variables.shortName}" project="${tps.variables.project}" enhancement="${tps.variables.enhancement}" groupName="${group}" />

import { html, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { propertyDataSource } from './_100554_icaLitElement';
import { ${extend} } from './${importFile}';

@customElement('${tagName}')
export class ${className} extends ${extend} {
    
    static styles = css\`\`;
    
    ${props.join('\n')}   
                        
}
`;
                this.taskChild.ref = activeServiceOp.getActualRef() || '';
                resolve(template);
            }
            catch (e) {
                reject(e);
            }
        });
    }
};
AimTaskPrepareIcaSource = __decorate([
    customElement('aim-task-prepare-ica-source-100554')
], AimTaskPrepareIcaSource);
export { AimTaskPrepareIcaSource };
