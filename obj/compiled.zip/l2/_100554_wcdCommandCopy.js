/// <mls shortName="wcdCommandCopy" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var infoCopy = undefined;
export function execute(param) {
    const e = param.args;
    const ica = param.selectedIca;
    const overlay = param.overlay;
    e.preventDefault();
    if (!ica)
        return;
    if (!e.ctrlKey && !e.metaKey)
        return;
    if (e.key.toLocaleLowerCase() === 'c')
        excCopy(ica);
    else if (e.key.toLocaleLowerCase() === 'v')
        excPaste(overlay, ica);
}
function excCopy(ica) {
    infoCopy = ica;
}
function excPaste(overlay, ica) {
    if (!infoCopy)
        return;
    const elAdd = infoCopy.cloneNode(false);
    ica.insertAdjacentElement('afterend', elAdd);
    setTimeout(() => {
        const { x, y, height, width } = elAdd.getBoundingClientRect();
        overlay.myItens.push({ element: elAdd, depth: 0, x, y, height, width, opacity: elAdd.style.opacity });
        overlay.createOverlayItems();
        setTimeout(() => { elAdd.overlayRef?.click(); }, 500);
    }, 500);
}
