/// <mls shortName="pluginTestDashboard3" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let PluginTestDashboard1100554 = class PluginTestDashboard1100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.dashboardindex = '';
        this.scope = 'dashboard';
        this.chartData = {};
    }
    createRenderRoot() {
        return this;
    }
    async prepare() {
        await this.delay(3000);
        await import('./_100554_wcChart');
        this.chartData = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                top: '3%',
                bottom: '10%',
                containLabel: true,
            },
            xAxis: [
                {
                    type: 'value'
                }
            ],
            yAxis: [
                {
                    type: 'category',
                    data: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLabel: {
                        formatter: function (value) {
                            return `{value|${value}}`;
                        },
                        rich: {
                            value: {
                                color: '#000',
                                align: 'center',
                                padding: [5, 0, 0, 0]
                            }
                        }
                    }
                }
            ],
            series: [
                {
                    name: 'Direct',
                    type: 'bar',
                    barWidth: '20%', // Ajuste a largura da barra
                    data: [10, 52, 200, 334, 390, 330, 220],
                    itemStyle: {
                        borderRadius: [4, 4, 4, 4] // Borda arredondada para as barras
                    },
                    label: {
                        show: true,
                        position: 'right' // Posição do rótulo à direita de cada barra
                    }
                }
            ]
        };
        this.innerHTML = `<wc-chart-100554 datasource=${JSON.stringify(this.chartData)}></wc-chart-100554>`;
    }
    async delay(timeout) {
        await new Promise((resolve) => setTimeout(resolve, timeout));
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        return html ``;
    }
};
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "dashboardindex", void 0);
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "scope", void 0);
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "chartData", void 0);
PluginTestDashboard1100554 = __decorate([
    customElement('plugin-test-dashboard3-100554')
], PluginTestDashboard1100554);
export { PluginTestDashboard1100554 };
