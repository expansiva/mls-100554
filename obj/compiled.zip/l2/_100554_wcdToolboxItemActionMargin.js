/// <mls shortName="wcdToolboxItemActionMargin" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, render } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
//version 4
/// **collab_i18n_start**
const message_pt = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const message_en = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WCDToolboxItemActionMargin = class WCDToolboxItemActionMargin extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.myMsg = messages['en'];
        this.startX = 0;
        this.startY = 0;
        this.startTop = 0;
        this.startBottom = 0;
        this.startLeft = 0;
        this.startRight = 0;
        //------EXTERAL SCENARY----------------
        this.hasRenderOutdoor = false;
        this.timeonChangeProp = -1;
    }
    //-------COMPONENT---------------------
    disconnectedCallback() {
        if (this.elExternal && this.hasRenderOutdoor) {
            render('', this.elExternal);
        }
        super.disconnectedCallback();
    }
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.elMain || !this.myParent)
            return;
        if (this.args && ['top', 'bottom', 'left', 'right'].includes(this.args)) {
            this.myParent.updateSize(this.elMain, this.myParent, true);
            this.onmousedown = (e) => this.initDragging(e);
        }
    }
    render() {
        switch (this.args) {
            case 'top':
                return this.renderOne('top');
            case 'bottom':
                return this.renderOne('bottom');
            case 'left':
                return this.renderOne('left');
            case 'right':
                return this.renderOne('right');
            case 'all':
                return this.renderAll();
            default: return this.renderButton();
        }
    }
    renderButton() {
        this.title = 'Margin';
        this.onclick = (e) => this.clickButton(e);
        this.classList.add('f-button');
        return html `<svg xmlns="http://www.w3.org/2000/svg" height="15px" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M192 32h64H416c17.7 0 32 14.3 32 32s-14.3 32-32 32H384l0 352c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-352H288V448c0 17.7-14.3 32-32 32s-32-14.3-32-32V352H192c-88.4 0-160-71.6-160-160s71.6-160 160-160z"/></svg>`;
    }
    renderOne(pos) {
        this.classList.add('f-square');
        switch (this.args) {
            case 'top':
                this.style.cursor = 'ns-resize';
                break;
            case 'bottom':
                this.style.cursor = 'ns-resize';
                break;
            case 'left':
                this.style.cursor = 'ew-resize';
                break;
            case 'right':
                this.style.cursor = 'ew-resize';
                break;
            default: '';
        }
        return html ``;
    }
    renderAll() {
        return html ``;
    }
    //------IMPLEMENTATION----------------
    clickButton(e) {
        e.stopPropagation();
        if (!this.myParent)
            return;
        this.myParent.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: 'margin',
                args: 'top',
                position: 'p-m1'
            },
            {
                name: 'margin',
                args: 'right',
                position: 'p-r2'
            },
            {
                name: 'margin',
                args: 'bottom',
                position: 'p-m3'
            },
            {
                name: 'margin',
                args: 'left',
                position: 'p-l2'
            }
        ], false, 'size');
        this.hasRenderOutdoor = false;
        const params = {
            level: 3,
            position: 'right',
            wdcPath: this.myParent.title,
            op: 'Styles',
        };
        mls.events.fire([3], 'WCDEvent', JSON.stringify(params));
    }
    async renderOutdoorScenary() {
        if (!this.myParent || this.myParent.level !== '3')
            return;
        this.elExternal = await this.myParent.getAndSetScenaryOutDoor('Styles');
        if (!this.elExternal)
            return;
        if (!this.hasRenderOutdoor)
            render('', this.elExternal);
        this.hasRenderOutdoor = true;
        render(this.renderMargin(), this.elExternal); // external scneary
    }
    renderMargin() {
        if (!this.elMain)
            return html ``;
        return html `
            <div style="display:flex; flex-direction:column; gap:.5rem ;padding:1rem" class="myAuxGroup">
                <p style=" margin-bottom: 5px;">A propriedade <b>margin</b> do CSS define a área de margem nos quatro lados do elemento. </p>
                <h4 style="display:flex; gap:1.5rem;margin:0px" >${this.myMsg.margin}<input type="checkbox" prop="margin"></h4>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.top}</div>
                    <input prop="marginTop" type="text" .value="${this.elMain.style.marginTop}"  group="margin" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.right}</div>
                    <input prop="marginRight" type="text" .value="${this.elMain.style.marginRight}"  group="margin" @input="${(e) => this.onChangeProp(e)}" />
                </div> 
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.bottom}</div>
                    <input prop="marginBottom" type="text" .value="${this.elMain.style.marginBottom}"  group="margin" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.left}</div>
                    <input prop="marginLeft" type="text" .value="${this.elMain.style.marginLeft}"  group="margin" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                
            </div>
        `;
    }
    onChangeProp(e) {
        const el = e.currentTarget;
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.changeEl(el);
        }, 500);
    }
    changeEl(el) {
        const prop = el.getAttribute('prop');
        const group = el ? el.getAttribute('group') : '';
        const elGroup = el.closest('.myAuxGroup')?.querySelector(`input[prop="${group}"]`);
        let isGroup = false;
        if (elGroup)
            isGroup = elGroup.checked;
        if (!prop || !this.elMain || !this.myParent)
            return;
        if (isGroup) {
            this.elMain.style.margin = el.value;
            ['marginTop', 'marginBottom', 'marginLeft', 'marginRight'].forEach((pr) => {
                const field = el.closest('.myAuxGroup')?.querySelector(`input[prop="${pr}"]`);
                if (field)
                    field.value = el.value;
            });
            this.myParent.updateSize(this.elMain, this.myParent, true);
            this.fireEvent(`margin: ${this.elMain.style.padding};`);
            return;
        }
        this.elMain.style[prop] = el.value;
        this.myParent.updateSize(this.elMain, this.myParent, true);
        this.fireEvent();
    }
    //---------DRAG------------------
    initDragging(e) {
        if (!this.elMain || !document.defaultView)
            return;
        this.startX = e.clientX;
        this.startY = e.clientY;
        const st = document.defaultView.getComputedStyle(this.elMain);
        this.startTop = parseInt(st.marginTop, 10);
        this.startBottom = parseInt(st.marginBottom, 10);
        this.startLeft = parseInt(st.marginLeft, 10);
        this.startRight = parseInt(st.marginRight, 10);
        const doDragging = (e) => {
            if (!this.elMain || !this.myParent)
                return;
            this.myParent.style.background = '#f9cc9d80';
            const deltaX = (e.clientX - this.startX);
            const deltaY = (e.clientY - this.startY);
            if (!this.args || ['top'].includes(this.args)) {
                this.elMain.style.marginTop = (this.startTop + deltaY * -1) + 'px';
            }
            if (!this.args || ['bottom'].includes(this.args)) {
                this.elMain.style.marginBottom = (this.startBottom + deltaY) + 'px';
            }
            if (!this.args || ['left'].includes(this.args)) {
                this.elMain.style.marginLeft = (this.startLeft + deltaX) + 'px';
            }
            if (!this.args || ['right'].includes(this.args)) {
                this.elMain.style.marginRight = (this.startRight + deltaX) + 'px';
            }
            this.renderOutdoorScenary();
            this.myParent.updateSize(this.elMain, this.myParent, true);
        };
        const stopDragging = (e) => {
            if (!this.elMain || !this.myParent)
                return;
            this.myParent.style.background = '';
            document.body.removeEventListener('mousemove', doDragging, false);
            document.body.removeEventListener('mouseup', stopDragging, false);
            this.fireEvent();
        };
        document.body.addEventListener('mousemove', doDragging, false);
        document.body.addEventListener('mouseup', stopDragging, false);
    }
    //----------FIRE-----------------
    fireEvent(ret = '') {
        if (!this.elMain || !this.myParent)
            return;
        if (ret === '') {
            if (this.args === 'top')
                ret = `margin-top: ${this.elMain.style.marginTop};`;
            if (this.args === 'bottom')
                ret = `margin-bottom: ${this.elMain.style.marginBottom};`;
            if (this.args === 'left')
                ret = `margin-left: ${this.elMain.style.marginLeft};`;
            if (this.args === 'right')
                ret = `margin-right: ${this.elMain.style.marginRight};`;
        }
        this.myParent.setStyle(ret);
    }
};
WCDToolboxItemActionMargin = __decorate([
    customElement('wcd-toolbox-item-action-margin-100554')
], WCDToolboxItemActionMargin);
export { WCDToolboxItemActionMargin };
