/// <mls shortName="widgetAiInteraction" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { getNextResultStep, getNextPendentStep, getNextClarificationStep, getInteractionStepId, getStepById } from './_100554_aiAgentHelper';
import { getClarification } from './_100554_aiAgentOrchestration';
let WidgetAiInteraction100554 = class WidgetAiInteraction100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ai-interaction-100554{height:100%;overflow:auto;padding:0 .5rem}widget-ai-interaction-100554 details>div{font-size:calc(.25rem * 3);margin-left:1rem;padding:.5rem}widget-ai-interaction-100554 details summary{cursor:pointer}widget-ai-interaction-100554 .formated-details-json pre{background:#f8f8f8;padding:12px;border-radius:6px;overflow-x:auto;font-family:monospace;font-size:14px;white-space:pre-wrap;word-break:break-word;color:#000}widget-ai-interaction-100554 .formated-details-json .json-key{color:brown}widget-ai-interaction-100554 .formated-details-json .json-string{color:olive}widget-ai-interaction-100554 .formated-details-json .json-value{color:navy}widget-ai-interaction-100554 .breadcrumb{margin-bottom:1rem;display:flex;flex-wrap:wrap;align-items:center;font-size:14px;color:#403f3f}widget-ai-interaction-100554 .breadcrumb span{cursor:pointer;color:#1890FF;transition:color .2s ease}widget-ai-interaction-100554 .breadcrumb span:hover{color:#000000}widget-ai-interaction-100554 .breadcrumb span:last-child{font-weight:bold;color:#000000;cursor:default}widget-ai-interaction-100554 .breadcrumb span+span::before{content:'>';margin:0 8px;color:#E6E6E6}widget-ai-interaction-100554 .prompts-content{display:flex;flex-direction:column;gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item{display:flex;flex-direction:column;border:1px solid #F2F2F2;padding:calc(.25rem * 4);gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-type{text-transform:uppercase;font-size:calc(.25rem * 3);color:#535353}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-content pre{font-size:calc(.25rem * 3);white-space:break-spaces;overflow:hidden}widget-ai-interaction-100554 .interactions .trace-content pre{font-size:calc(.25rem * 3);white-space:break-spaces}widget-ai-interaction-100554 .clarification-details pre{font-size:calc(.25rem * 3);white-space:break-spaces;max-height:200px;overflow-y:scroll}widget-ai-interaction-100554 .flexible-details pre{font-size:calc(.25rem * 3);white-space:break-spaces;max-height:200px;overflow:auto}widget-ai-interaction-100554 .result pre{font-size:calc(.25rem * 3);white-space:break-spaces}`);
        // @property() payloads: mls.msg.AIPayload[] | undefined = undefined;
        this.task = undefined;
        this.stepid = '';
        this.seen = new Set();
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.interactionClarification) {
            this.setClarification();
        }
    }
    render() {
        if (!this.task)
            return html `No task.`;
        let isClarificationPending = false;
        if (this.task) {
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                isClarificationPending = true;
        }
        return html `        
            <details class="details-task">
                <summary>Details</summary>
                <div>
                    ${this.renderTaskModeDetails()}
                </div>
            </details>

            <details class="details-task">
                <summary>Details2</summary>
                <div>
                    ${this.renderTaskModeJson()}
                </div>
            </details>
            
            ${this.task?.status === "done"
            ? this.renderDirectResult()
            : html ``}

            ${isClarificationPending
            ? this.renderDirectClarification()
            : html ``}

            `;
    }
    renderTaskModeJson() {
        if (!this.task)
            return html ``;
        const formattedJson = this.syntaxHighlight(this.task);
        return html `<div class="formated-details-json"><pre .innerHTML=${formattedJson}></pre></div>`;
    }
    renderTaskModeDetails() {
        return html `
            ${this.renderTaskInfo()}
            ${this.renderlLongMemory()}
            ${this.task?.iaCompressed?.nextSteps ? this.renderTaskInteractions(this.task?.iaCompressed?.nextSteps) : ''}
        `;
    }
    renderDirectResult() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextResultStep(this.task);
        if (!payload)
            return html ``;
        return this.renderResult(payload);
    }
    renderDirectClarification() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextClarificationStep(this.task);
        if (!payload)
            return html ``;
        return html `<div class="direct-clarification">${this.renderClarification(payload)}</div>`;
    }
    renderlLongMemory() {
        if (!this.task || !this.task.iaCompressed?.longMemory)
            return html ``;
        return html `
            <h4>LongMemory</h4>
            <ul>
                ${Object.keys(this.task.iaCompressed?.longMemory).map((key) => {
            return html `<li>${key}:${this.task?.iaCompressed?.longMemory[key]}</li>`;
        })}
            </ul>
        `;
    }
    renderTaskInfo() {
        if (!this.task)
            return html ``;
        const cloneTask = Object.assign({}, this.task);
        delete cloneTask.iaCompressed;
        return html `
            <div class="task-info">
                <ul>
                    ${Object.keys(cloneTask).map((key) => {
            return html `
                            <li>${key}: 
                            ${cloneTask && typeof cloneTask[key] === 'string'
                ? cloneTask[key]
                : cloneTask[key].toString()} </li>`;
        })}
                </ul>             
            </div>
        `;
    }
    renderTaskInteractions(payloads) {
        return html `
            <div class="payload-content">
                ${payloads.map((payload) => {
            return html `
                <div>
                    ${this.renderPayload(payload)}
                </div>`;
        })}
            </div>
        `;
    }
    renderPayload(payload, isDirect = false) {
        switch (payload.type) {
            case 'agent':
                return html `
                    <details ?open=${isDirect}>
                        <summary>${payload.type}(${payload.agentName})</summary>
                        ${this.renderAgent(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
                    </details>`;
            case 'tool':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderTool(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
                    </details>
                `;
            case 'clarification':
                console.info(payload.nextSteps);
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderClarificationDetails(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}
                    </details>
                `;
            case 'result':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderResult(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
                    </details>
                `;
            case 'flexible':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderFlexible(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
                    </details>
                `;
            default:
                return html `<p>Tipo de resultado desconhecido.</p>`;
        }
    }
    renderInteration(interaction, stepId) {
        return html ` 
            <div class="interactions">
                <details>
                    <summary>Inputs</summary>
                    <div>
                        <div class="prompts-content">
                            ${interaction.input.map((result, index) => html `
                                <div class="prompts-input-item">
                                    <span class="prompts-input-type">${result.type}</span>
                                    <span class="prompts-input-content"><pre>${result.content}</pre></span>
                                </details>
                            `)}
                        </div>
                    </div>
                </details>

                <details>
                    <summary>Trace</summary>
                    <div>
                        <div class="trace-content">
                            <pre>${interaction?.trace?.join('\n')}</pre>
                        </div>
                    </div>
                </details>

                ${interaction.payload && interaction.payload.length > 0
            ? html `
                        <details>
                            <summary>Payload</summary>
                            <div>
                                <div class="payload-content">
                                    ${interaction.payload?.map((payl) => { return this.renderPayload(payl); })}
                                </div>
                            </div>
                        </details>`
            : html ``}
                
            </div>`;
    }
    renderAgent(payload) {
        return html `
            <ul>
                <li>agentName: ${payload.agentName}</li>
                <li>stepId: ${payload.stepId}</li>
                <li>prompt: ${payload.prompt}</li>
                <li>status: ${payload.status}</li>
            </ul>
        `;
    }
    renderTool(payload) {
        return html `
            <ul>
                <li>toolName: ${payload.toolName}</li>
                <li>stepId: ${payload.stepId}</li>
                <li>status: ${payload.status}</li>
            </ul>
            <div class="clarification-details">
                <pre>${JSON.stringify(payload)}</pre>
            </div>`;
    }
    renderClarificationDetails(payload) {
        return html `
            <ul>
                <li>clarificationMessage: ${payload.clarificationMessage}</li>
                <li>htmlForm: ${payload.htmlForm}</li>
                <li>stepId: ${payload.stepId}</li>
                <li>status: ${payload.status}</li>
            </ul>
            ${payload.json ? html `<div class="clarification-details"><pre>${JSON.stringify(payload.json)}</pre></div>` : ''}
            `;
    }
    renderFlexible(payload) {
        return html `
            <div class="flexible-details">
                <pre>${JSON.stringify(payload)}</pre>
            </div>
            `;
    }
    renderClarification(payload) {
        if (!this.task)
            return html `Invalid task`;
        const parentInteraction = getInteractionStepId(this.task, payload.stepId);
        if (!parentInteraction)
            return html `No found parentInteraction ${payload.stepId} on task: ${this.task.PK} `;
        const interaction = getStepById(this.task, parentInteraction);
        this.interactionClarification = interaction;
        if (!interaction)
            return html `Invalid interaction id:${parentInteraction} on task: ${this.task.PK} `;
        if (!interaction.agentName)
            return html `Invalid agent name for step id:${interaction.stepId} on task: ${this.task.PK} `;
        return html `<div class="content"> Processing...</div>`;
    }
    renderResult(payload) {
        return html `
            <div class="result">
                <pre>${typeof payload.result === 'object' ? JSON.stringify(payload.result) : payload.result}</pre>
            </div>`;
    }
    async setClarification() {
        if (!this.directClarificationContent || !this.task)
            return;
        const clarification = await getClarification(this.task.PK);
        if (!clarification)
            return;
        this.directClarificationContent.innerHTML = '';
        this.directClarificationContent.appendChild(clarification);
        this.executeHTMLClarificationScript();
    }
    executeHTMLClarificationScript() {
        this.directClarification?.querySelectorAll('script').forEach(oldScript => {
            const newScript = document.createElement('script');
            newScript.type = oldScript.type || 'text/javascript';
            if (!newScript.type) {
                newScript.type = 'text/javascript';
            }
            if (oldScript.hasAttribute('type') && oldScript.getAttribute('type') === 'module') {
                newScript.type = 'module';
            }
            if (oldScript.src) {
                newScript.src = oldScript.src;
            }
            else {
                newScript.textContent = oldScript.textContent;
            }
            oldScript.replaceWith(newScript);
        });
    }
    syntaxHighlight(json) {
        if (typeof json !== 'string') {
            json = JSON.stringify(json, null, 2);
        }
        json = json
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        return json.replace(/("(\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*"(?:\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g, (match) => {
            let cls = 'json-value';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'json-key';
                }
                else {
                    cls = 'json-string';
                }
            }
            else if (/true|false/.test(match)) {
                cls = 'json-boolean';
            }
            else if (/null/.test(match)) {
                cls = 'json-null';
            }
            return `<span class="${cls}">${match}</span>`;
        });
    }
};
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "task", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], WidgetAiInteraction100554.prototype, "seen", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "interactionClarification", void 0);
__decorate([
    query('.direct-clarification')
], WidgetAiInteraction100554.prototype, "directClarification", void 0);
__decorate([
    query('.direct-clarification .content')
], WidgetAiInteraction100554.prototype, "directClarificationContent", void 0);
WidgetAiInteraction100554 = __decorate([
    customElement('widget-ai-interaction-100554')
], WidgetAiInteraction100554);
export { WidgetAiInteraction100554 };
