/// <mls shortName="widgetAiInteraction" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { getNextResultStep, getNextPendentStep, getNextClarificationStep, getInteractionStepId, getStepById } from './_100554_aiAgentHelper';
let WidgetAiInteraction100554 = class WidgetAiInteraction100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ai-interaction-100554{height:100%;overflow:auto;padding:0 .5rem}widget-ai-interaction-100554 details>div{font-size:var(--font-size-12);margin-left:1rem;padding:.5rem}widget-ai-interaction-100554 details summary{cursor:pointer}widget-ai-interaction-100554 .breadcrumb{margin-bottom:1rem;display:flex;flex-wrap:wrap;align-items:center;font-size:14px;color:var(--text-primary-color)}widget-ai-interaction-100554 .breadcrumb span{cursor:pointer;color:var(--active-color);transition:color .2s ease}widget-ai-interaction-100554 .breadcrumb span:hover{color:var(--text-primary-color-darker)}widget-ai-interaction-100554 .breadcrumb span:last-child{font-weight:bold;color:var(--text-primary-color-darker);cursor:default}widget-ai-interaction-100554 .breadcrumb span+span::before{content:'>';margin:0 8px;color:var(--grey-color)}widget-ai-interaction-100554 .prompts-content{display:flex;flex-direction:column;gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item{display:flex;flex-direction:column;border:1px solid var(--grey-color-light);padding:var(--space-16);gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-type{text-transform:uppercase;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-content pre{font-size:var(--font-size-12);white-space:break-spaces}widget-ai-interaction-100554 .interactions .trace-content pre{font-size:var(--font-size-12);white-space:break-spaces}widget-ai-interaction-100554 .clarification-details pre{font-size:var(--font-size-12);white-space:break-spaces}widget-ai-interaction-100554 .result pre{font-size:var(--font-size-12);white-space:break-spaces}`);
        this.payloads = undefined;
        this.task = undefined;
        this.stepid = '';
        this.seen = new Set();
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.interactionClarification) {
            this.getHTMLFromAgent(this.interactionClarification.agentName);
        }
    }
    render() {
        if (!this.payloads)
            return html ``;
        let isClarificationPending = false;
        if (this.task) {
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                isClarificationPending = true;
        }
        console.info({
            payloads: this.payloads,
            task: this.task
        });
        return html `        
        <details class="details-task">
            <summary>Details</summary>
            <div>
                ${this.renderTaskInfo()}
                ${this.renderlLongMemory()}
                ${this.renderTaskInteractions()}
            </div>
        </details>
        
        ${this.task?.status === "done"
            ? this.renderDirectResult()
            : html ``}

        ${isClarificationPending
            ? this.renderDirectClarification()
            : html ``}

        `;
    }
    renderDirectResult() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextResultStep(this.task);
        if (!payload)
            return html ``;
        return this.renderResult(payload);
    }
    renderDirectClarification() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextClarificationStep(this.task);
        if (!payload)
            return html ``;
        return html `<div class="direct-clarification">${this.renderClarification(payload)}</div>`;
    }
    renderlLongMemory() {
        if (!this.task || !this.task.iaCompressed?.longMemory)
            return html ``;
        return html `
            <h4>LongMemory</h4>
            <ul>
                ${Object.keys(this.task.iaCompressed?.longMemory).map((key) => {
            return html `<li>${key}:${this.task?.iaCompressed?.longMemory[key]}</li>`;
        })}
            </ul>
        `;
    }
    renderTaskInfo() {
        return html `
            <div class="task-info">
                <ul>
                    <li>
                        <span>Id:</span>
                        <span>${this.task?.PK}</span>
                    </li>
                    <li>
                        <span>Status:</span>
                        <span>${this.task?.status}</span>
                    </li>
                </ul>                
            </div>
        `;
    }
    renderTaskInteractions() {
        return html `
            <div class="payload-content">
                ${this.payloads?.map((payload) => {
            return html `
                                    <div>
                                        ${this.renderPayload(payload)}
                                    </div>`;
        })}
            </div>
        `;
    }
    renderPayload(payload, isDirect = false) {
        switch (payload.type) {
            case 'agent':
                return html `
                    <details ?open=${isDirect}>
                        <summary>${payload.type}(${payload.agentName})</summary>
                        ${this.renderAgent(payload)}
                    </details>`;
            case 'tool':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderTool(payload)}
                    </details>
                `;
            case 'clarification':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderClarificationDetails(payload)}
                    </details>
                `;
            case 'result':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderResult(payload)}
                    </details>
                `;
            default:
                return html `<p>Tipo de resultado desconhecido.</p>`;
        }
    }
    renderInteration(interaction, stepId) {
        return html ` 
            <div class="interactions">
                <details>
                    <summary>Inputs</summary>
                    <div>
                        <div class="prompts-content">
                            ${interaction.input.map((result, index) => html `
                                <div class="prompts-input-item">
                                    <span class="prompts-input-type">${result.type}</span>
                                    <span class="prompts-input-content"><pre>${result.content}</pre></span>
                                </details>
                            `)}
                        </div>
                    </div>
                </details>

                <details>
                    <summary>Trace</summary>
                    <div>
                        <div class="trace-content">
                            <pre>${interaction?.trace?.join('\n')}</pre>
                        </div>
                    </div>
                </details>

                ${interaction.payload && interaction.payload.length > 0
            ? html `
                        <details>
                            <summary>Payload</summary>
                            <div>
                                <div class="payload-content">
                                    ${interaction.payload?.map((payl) => { return this.renderPayload(payl); })}
                                </div>
                            </div>
                        </details>`
            : html ``}
                
            </div>`;
    }
    renderNextSteps(steps, stepId) {
        return html ` 
        <div>
            <details>
                <summary>Next Steps</summary>
                <div>
                    <ul>
                        ${steps.map((step) => {
            return html `<li @click=${this.onNextStepClick(step.interaction, step.stepId)}> ${step.stepId}</li>`;
        })}       
                    </ul>
                </div> 
            </details>
        </div> 
            `;
    }
    onNextStepClick(interaction, stepId) {
        if (!interaction || !interaction.payload)
            return;
        this.requestUpdate();
    }
    renderAgent(payload) {
        return html `
            ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
            ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderNextSteps(payload.nextSteps, payload.stepId) : html ``}
        `;
    }
    renderTool(payload) {
        return html `
            <div class="clarification-details">
                <pre>${JSON.stringify(payload)}</pre>
            </div>`;
    }
    renderClarificationDetails(payload) {
        return html `
            <div class="clarification-details">
                <pre>${JSON.stringify(payload)}</pre>
            </div>`;
    }
    renderClarification(payload) {
        if (!this.task)
            return html `Invalid task`;
        const parentInteraction = getInteractionStepId(this.task, payload.stepId);
        if (!parentInteraction)
            return html `No found parentInteraction ${payload.stepId} on task: ${this.task.PK} `;
        const interaction = getStepById(this.task, parentInteraction);
        this.interactionClarification = interaction;
        if (!interaction)
            return html `Invalid interaction id:${parentInteraction} on task: ${this.task.PK} `;
        if (!interaction.agentName)
            return html `Invalid agent name for step id:${interaction.stepId} on task: ${this.task.PK} `;
        return html `<div class="content"> Processing...</div>`;
    }
    renderResult(payload) {
        return html `
            <div class="result">
                <pre>${typeof payload.result === 'object' ? JSON.stringify(payload.result) : payload.result}</pre>
            </div>`;
    }
    async getHTMLFromAgent(agentName) {
        if (!this.directClarificationContent)
            return;
        const project = 100554;
        const keyFile = mls.stor.getKeyToFiles(project, 2, agentName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (!storFile)
            this.directClarificationContent.innerHTML = `Agent: ${project}_${agentName} not found`;
        const content = await storFile.getContent();
        if (typeof content !== 'string')
            this.directClarificationContent.innerHTML = `Content must be string`;
        else {
            this.directClarificationContent.innerHTML = content;
            this.executeHTMLClarificationScript();
        }
    }
    executeHTMLClarificationScript() {
        this.directClarification?.querySelectorAll('script').forEach(oldScript => {
            const newScript = document.createElement('script');
            newScript.type = oldScript.type || 'text/javascript';
            if (!newScript.type) {
                newScript.type = 'text/javascript';
            }
            if (oldScript.hasAttribute('type') && oldScript.getAttribute('type') === 'module') {
                newScript.type = 'module';
            }
            if (oldScript.src) {
                newScript.src = oldScript.src;
            }
            else {
                newScript.textContent = oldScript.textContent;
            }
            oldScript.replaceWith(newScript);
        });
    }
};
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "payloads", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "task", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], WidgetAiInteraction100554.prototype, "seen", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "interactionClarification", void 0);
__decorate([
    query('.direct-clarification')
], WidgetAiInteraction100554.prototype, "directClarification", void 0);
__decorate([
    query('.direct-clarification .content')
], WidgetAiInteraction100554.prototype, "directClarificationContent", void 0);
WidgetAiInteraction100554 = __decorate([
    customElement('widget-ai-interaction-100554')
], WidgetAiInteraction100554);
export { WidgetAiInteraction100554 };
