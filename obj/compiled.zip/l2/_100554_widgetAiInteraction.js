/// <mls shortName="widgetAiInteraction" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { getNextResultStep, getNextPendentStep, getNextClarificationStep, getInteractionStepId, getStepById } from './_100554_aiAgentHelper';
let WidgetAiInteraction100554 = class WidgetAiInteraction100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ai-interaction-100554{height:100%;overflow:auto;padding:0 .5rem}widget-ai-interaction-100554 details{margin-bottom:1rem}widget-ai-interaction-100554 details>div{margin-left:1rem;padding:.5rem}widget-ai-interaction-100554 details summary{cursor:pointer}widget-ai-interaction-100554 .breadcrumb{margin-bottom:1rem;display:flex;flex-wrap:wrap;align-items:center;font-size:14px;color:var(--text-primary-color)}widget-ai-interaction-100554 .breadcrumb span{cursor:pointer;color:var(--active-color);transition:color .2s ease}widget-ai-interaction-100554 .breadcrumb span:hover{color:var(--text-primary-color-darker)}widget-ai-interaction-100554 .breadcrumb span:last-child{font-weight:bold;color:var(--text-primary-color-darker);cursor:default}widget-ai-interaction-100554 .breadcrumb span+span::before{content:'>';margin:0 8px;color:var(--grey-color)}widget-ai-interaction-100554 .prompts-content{display:flex;flex-direction:column;gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item{display:flex;flex-direction:column;border:1px solid var(--grey-color-light);padding:var(--space-16);gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-type{text-transform:uppercase;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-content pre{font-size:var(--font-size-12);white-space:break-spaces}widget-ai-interaction-100554 .interactions .trace-content pre{font-size:var(--font-size-12);white-space:break-spaces}widget-ai-interaction-100554 .clarification input:not([type="submit"]),widget-ai-interaction-100554 .clarification select,widget-ai-interaction-100554 .clarification textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}widget-ai-interaction-100554 .clarification button,widget-ai-interaction-100554 .clarification input[type="submit"]{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}widget-ai-interaction-100554 .clarification button:hover,widget-ai-interaction-100554 .clarification input[type="submit"]:hover{background-color:var(--info-color-hover)}widget-ai-interaction-100554 .result pre{font-size:var(--font-size-12);white-space:break-spaces}`);
        this.payloads = undefined;
        this.task = undefined;
        this.stepid = '';
        this.seen = new Set();
        this.breadcrumb = [];
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        console.info(this.formClarification);
        if (this.formClarification) {
            this.formClarification.addEventListener('submit', this.handleFormSubmit.bind(this));
        }
    }
    render() {
        if (!this.payloads)
            return html ``;
        if (this.breadcrumb.length === 0) {
            this.breadcrumb = [
                { data: this.payloads, title: 'root' }
            ];
        }
        let isClarificationPending = false;
        if (this.task) {
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                isClarificationPending = true;
        }
        console.info({
            payloads: this.payloads,
            task: this.task
        });
        return html `        
        <div class="breadcrumb">
            ${this.breadcrumb.map((step, index) => html `
                <span @click=${() => this.onBreadcrumbClick(index)}>${step.title}</span>   
            `)}
        </div>
        <div class="payload-content">
            ${this.payloads.map((payload) => {
            return html `
                <div>
                    ${this.renderPayload(payload)}
                </div>`;
        })}
        </div>

        ${this.task?.status === "done"
            ? this.renderDirectResult()
            : html ``}

        ${isClarificationPending
            ? this.renderDirectClarification()
            : html ``}

        `;
    }
    handleFormSubmit(e) {
        e.preventDefault();
        if (!this.task)
            return;
        const nextStepPending = getNextPendentStep(this.task);
        if (!nextStepPending || nextStepPending?.type !== 'clarification')
            return;
        const message = nextStepPending.clarificationMessage;
        const form = e.target;
        const formData = new FormData(form);
        const prompt = Array.from(formData.entries())
            .map(([key, value]) => `${key}: ${value}`)
            .join('\n');
        console.info('Prompt gerado:', `${message}\n\n${prompt}`);
    }
    renderDirectResult() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextResultStep(this.task);
        if (!payload)
            return html ``;
        return this.renderResult(payload);
    }
    renderDirectClarification() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextClarificationStep(this.task);
        if (!payload)
            return html ``;
        return html `<div class="direct-clarification">${this.renderClarification(payload)}</div>`;
    }
    renderPayload(payload, isDirect = false) {
        switch (payload.type) {
            case 'agent':
                return html `
                    <details ?open=${isDirect}>
                        <summary>${payload.type}(${payload.agentName})</summary>
                        ${this.renderAgent(payload)}
                    </details>`;
            case 'tool':
                return html ``;
            case 'clarification':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderClarification(payload)}
                    </details>
                `;
            case 'result':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderResult(payload)}
                    </details>
                `;
            default:
                return html `<p>Tipo de resultado desconhecido.</p>`;
        }
    }
    renderInteration(interaction, stepId) {
        return html ` 
            <div class="interactions">
                <details>
                    <summary>Inputs</summary>
                    <div>
                        <div class="prompts-content">
                            ${interaction.input.map((result, index) => html `
                                <div class="prompts-input-item">
                                    <span class="prompts-input-type">${result.type}</span>
                                    <span class="prompts-input-content"><pre>${result.content}</pre></span>
                                </details>
                            `)}
                        </div>
                    </div>
                </details>

                <details>
                    <summary>Trace</summary>
                    <div>
                        <div class="trace-content">
                            <pre>${interaction?.trace?.join('\n')}</pre>
                        </div>
                    </div>
                </details>

                ${interaction.payload && interaction.payload.length > 0
            ? html `
                        <details>
                            <summary>Payload</summary>
                            <div>
                                <div class="payload-content">
                                    ${interaction.payload?.map((payl) => { return this.renderPayload(payl); })}
                                </div>
                            </div>
                        </details>`
            : html ``}
                
            </div>`;
    }
    renderNextSteps(steps, stepId) {
        return html ` 
            <details>
                <summary>Next Steps</summary>
                <div>
                    <ul>
                        ${steps.map((step) => {
            return html `<li @click=${this.onNextStepClick(step.interaction, step.stepId)}> ${step.stepId}</li>`;
        })}       
                    </ul>
                </div> 
            </details>`;
    }
    onNextStepClick(interaction, stepId) {
        if (!interaction || !interaction.payload)
            return;
        this.breadcrumb = [...this.breadcrumb, { title: `Interaction: ${stepId}`, data: interaction.payload }];
        this.requestUpdate();
    }
    onBreadcrumbClick(index) {
        // this.breadcrumb = this.breadcrumb.slice(0, index + 1);
        // this.interaction = this.breadcrumb[this.breadcrumb.length - 1].data;
    }
    renderAgent(payload) {
        return html `
            ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
            ${payload.nextSteps ? this.renderNextSteps(payload.nextSteps, payload.stepId) : html ``}
        `;
    }
    renderTool(payload) {
        return html ``;
    }
    renderClarification(payload) {
        if (!this.task)
            return;
        const parentInteraction = getInteractionStepId(this.task, payload.stepId);
        if (parentInteraction) {
            const interaction = getStepById(this.task, parentInteraction);
            console.info({
                parentInteraction,
                interaction
            });
        }
        return html `
            <div class="clarification">
                <p><strong>Clarification:</strong> ${payload.clarificationMessage}</p>
                ${payload.htmlForm
            ? html `<div .innerHTML=${payload.htmlForm}></div>`
            : html `<form>
                        <textarea></textarea>
                        <button>Enviar<button>
                    </form>
            </div>
            
            `}
      `;
    }
    renderResult(payload) {
        return html `

        <div class="result">
            <pre>${payload.result}</pre>
        </div>
        

        `;
    }
};
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "payloads", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "task", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], WidgetAiInteraction100554.prototype, "seen", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "breadcrumb", void 0);
__decorate([
    query('.direct-clarification form')
], WidgetAiInteraction100554.prototype, "formClarification", void 0);
WidgetAiInteraction100554 = __decorate([
    customElement('widget-ai-interaction-100554')
], WidgetAiInteraction100554);
export { WidgetAiInteraction100554 };
