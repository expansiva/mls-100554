/// <mls shortName="widgetAiInteraction" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_chevron_right } from './_100554_collabIcons';
import { getInteractionByStep } from './_100554_iaChatBase';
let WidgetAiInteraction100554 = class WidgetAiInteraction100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ai-interaction-100554 details{margin-bottom:1rem}widget-ai-interaction-100554 details>div{margin-left:1rem;padding:.5rem}widget-ai-interaction-100554 details summary{cursor:pointer}widget-ai-interaction-100554 .breadcrumb{margin-bottom:1rem;display:flex;flex-wrap:wrap;align-items:center;font-size:14px;color:var(--text-primary-color)}widget-ai-interaction-100554 .breadcrumb span{cursor:pointer;color:var(--active-color);transition:color .2s ease}widget-ai-interaction-100554 .breadcrumb span:hover{color:var(--text-primary-color-darker)}widget-ai-interaction-100554 .breadcrumb span:last-child{font-weight:bold;color:var(--text-primary-color-darker);cursor:default}widget-ai-interaction-100554 .breadcrumb span+span::before{content:'>';margin:0 8px;color:var(--grey-color)}widget-ai-interaction-100554 .prompts-content{display:flex;flex-direction:column;gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item{display:flex;flex-direction:column;border:1px solid var(--grey-color-light);padding:var(--space-16);gap:1rem}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-type{text-transform:uppercase;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}widget-ai-interaction-100554 .prompts-content .prompts-input-item .prompts-input-content pre{font-size:var(--font-size-12)}widget-ai-interaction-100554 .payload-content .payload-details-item{flex:1;width:calc(100% - var(--space-16)*2);padding:var(--space-16);border-radius:10px;background:var(--bg-secondary-color-lighter)}widget-ai-interaction-100554 .payload-content .payload-details-item .clarification input:not([type="submit"]),widget-ai-interaction-100554 .payload-content .payload-details-item .clarification select,widget-ai-interaction-100554 .payload-content .payload-details-item .clarification textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}widget-ai-interaction-100554 .payload-content .payload-details-item .clarification button,widget-ai-interaction-100554 .payload-content .payload-details-item .clarification input[type="submit"]{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}widget-ai-interaction-100554 .payload-content .payload-details-item .clarification button:hover,widget-ai-interaction-100554 .payload-content .payload-details-item .clarification input[type="submit"]:hover{background-color:var(--info-color-hover)}widget-ai-interaction-100554 .payload-content .payload-details-item-link{display:flex;justify-content:space-between;width:calc(100% - var(--space-16)*2);padding:var(--space-16);border-radius:10px;background:var(--bg-secondary-color-lighter);cursor:pointer;position:relative}`);
        this.interaction = undefined;
        this.payload = undefined;
        this.stepid = '';
        this.seen = new Set();
        this.breadcrumb = [];
    }
    firstUpdated(a) {
        super.firstUpdated(a);
        if (this.stepid && this.interaction) {
            this.payload = getInteractionByStep(this.interaction, Number.parseInt(this.stepid));
        }
    }
    render() {
        if (this.payload) {
            return html `
                <div class="payload-content">
                    ${this.renderPayload(this.payload, true)}
                </div>`;
        }
        if (!this.interaction)
            return html ``;
        if (this.breadcrumb.length === 0) {
            this.breadcrumb = [
                { data: this.interaction, title: 'root' }
            ];
        }
        return html `        
        <div class="breadcrumb">
            ${this.breadcrumb.map((step, index) => html `
                <span @click=${() => this.onBreadcrumbClick(index)}>${step.title}</span>
               
            `)}
        </div>

        <details>
            <summary>Inputs</summary>
            <div>
                <div class="prompts-content">
                    ${this.interaction?.input.map((result, index) => html `
                            <div class="prompts-input-item">
                                <span class="prompts-input-type">${result.type}</span>
                                <span class="prompts-input-content"><pre>${result.content}</pre></span>
                            </details>
                        `)}
                </div>
            </div>
        </details>

        <details>
            <summary>Trace</summary>
            <div>
                <div class="trace-content">
                    <pre>${this.interaction?.trace?.join('\n')}</pre>
                </div>
            </div>
        </details>

        <details>
            <summary>Payload</summary>
            <div>
                <div class="payload-content">
                    ${this.interaction?.payload?.map((payload) => {
            return this.renderPayload(payload);
        })}
                </div>
            </div>
        </details>`;
    }
    renderPayload(payload, isDirect = false) {
        switch (payload.type) {
            case 'agent':
                return html `
                    <details ?open=${isDirect} class="payload-details-item">
                        <summary>${payload.type}</summary>
                        ${this.renderAgent(payload)}
                    </details>`;
            case 'tool':
                return html `
                    <details ?open=${isDirect} class="payload-details-item">
                        <summary>${payload.type}</summary>
                        ${this.renderTool(payload)}
                    </details>`;
            case 'clarification':
                return html `
                    <details ?open=${isDirect} class="payload-details-item">
                        <summary>${payload.type}</summary>
                        <div class="clarification">
                            ${this.renderClarification(payload)}
                        </div>
                    </details>
                    ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : ''}
                    ${payload.nextSteps ? this.renderNextSteps(payload.nextSteps, payload.stepId) : ''}

                    `;
            case 'result':
                return html `
                    <details ?open=${isDirect} class="payload-details-item">
                        <summary>${payload.type}</summary>
                        ${this.renderResult(payload)}
                    </details>
                    ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : ''}
                    ${payload.nextSteps ? this.renderNextSteps(payload.nextSteps, payload.stepId) : ''}
                    `;
            default:
                return html `<p>Tipo de resultado desconhecido.</p>`;
        }
    }
    renderInteration(interaction, stepId) {
        return html ` 
            <div class="payload-details-item-link" @click=${() => this.onInteractionClick(interaction, stepId)}>
                <span>Interactions</span> 
                <span>${collab_chevron_right}</span> 
            </div>`;
    }
    renderNextSteps(steps, stepId) {
        return html ` 
            <details class="payload-details-item">
                <summary>Next Steps</summary>
                <div>
                    <ul>
                        ${steps.map((step) => {
            return html `<li> ${step.title}</li>`;
        })}
                    </ul>
                </div> 
            </details>`;
    }
    onInteractionClick(interaction, stepId) {
        this.interaction = interaction;
        this.breadcrumb = [...this.breadcrumb, { title: `Interaction: ${stepId}`, data: interaction }];
        this.requestUpdate();
    }
    onBreadcrumbClick(index) {
        this.breadcrumb = this.breadcrumb.slice(0, index + 1);
        this.interaction = this.breadcrumb[this.breadcrumb.length - 1].data;
    }
    renderAgent(payload) {
        return html ``;
    }
    renderTool(payload) {
        return html ``;
    }
    renderClarification(payload) {
        return html `
        <p><strong>Clarification:</strong> ${payload.clarificationMessage}</p>
        ${payload.htmlForm
            ? html `<div .innerHTML=${payload.htmlForm}></div>`
            : html `<form>
                <textarea></textarea>
                <button>Enviar<button>
            </form>`}
      `;
    }
    renderResult(payload) {
        return html `<pre>${payload.result}</pre>`;
    }
};
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "interaction", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "payload", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], WidgetAiInteraction100554.prototype, "seen", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "breadcrumb", void 0);
WidgetAiInteraction100554 = __decorate([
    customElement('widget-ai-interaction-100554')
], WidgetAiInteraction100554);
export { WidgetAiInteraction100554 };
