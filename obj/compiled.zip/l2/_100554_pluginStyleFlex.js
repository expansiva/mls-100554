/// <mls shortName="pluginStyleFlex" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement, getMessageKey } from './_100554_collabLitElement';
import './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    flex: 'Flex',
    flexItem: 'Flex item',
    display: 'Display',
    flexDirection: 'Flex direction',
    flexWrap: 'Flex wrap',
    justifyContent: 'Justify content',
    alignItems: 'Align items',
    alignContent: 'Align content',
    alignSelf: 'Align self',
    order: 'Order',
    description: 'Este plugin permite criar e ajustar colunas de texto de forma prática e eficiente. Com ele, é possível definir o número de colunas, o espaçamento entre elas e outros detalhes de formatação, proporcionando um layout organizado e facilitando a leitura.'
};
const message_en = {
    flex: 'Flex',
    flexItem: 'Flex item',
    display: 'Display',
    flexDirection: 'Flex direction',
    flexWrap: 'Flex wrap',
    justifyContent: 'Justify content',
    alignItems: 'Align items',
    alignContent: 'Align content',
    alignSelf: 'Align self',
    order: 'Order',
    description: 'This plugin allows for easy and efficient creation and adjustment of text columns. It lets you set the number of columns, spacing between them, and other formatting details, providing an organized layout and enhancing readability.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['flex*', 'gap', 'align-items', 'justify-content'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleFlex = class PluginStyleFlex extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-flex-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-flex-100554 .helper-group-title{margin:0;margin-top:var(--space-16);margin-bottom:var(--space-8);display:flex;gap:1.5rem}plugin-style-flex-100554 .group{margin-bottom:var(--space-8);display:flex;flex-direction:column;font-size:var(--font-size-12)}plugin-style-flex-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-flex-100554 .group .group-edit .group-select{width:150px;display:block;font-size:1rem;background-color:#fff;background-clip:padding-box;border:1px solid #b5b4b4;border-radius:.25rem;transition:border-color .15s ease-in-out 0s,box-shadow .15s ease-in-out 0s;outline:none}plugin-style-flex-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-flex-100554 .gallery{margin-bottom:var(--space-16);display:flex;justify-content:start;align-items:center;gap:1rem;padding-top:1rem;flex-wrap:wrap;cursor:pointer;zoom:.5}plugin-style-flex-100554 .gallery .gallery-item-1{border:1px solid #cccccc;margin-left:10px;width:120px;padding:5px;cursor:pointer;background:white}plugin-style-flex-100554 .gallery .gallery-item-2{border:1px solid #cccccc;margin-left:10px;width:60px;height:100px;padding:5px;cursor:pointer;background:white}`);
        this.msg = messages['en'];
        this.showFull = 'true';
        this.arrayGallery = [
            'display: flex;flex-direction: row; justify-content: flex-start;',
            'display: flex; flex-direction: row; justify-content: flex-end;',
            'display: flex; flex-direction: row; justify-content: center;',
            'display: flex; flex-direction: row; justify-content: space-between;',
            'display: flex;flex-direction: column; justify-content: flex-start;',
            'display: flex;flex-direction: column; justify-content: flex-end;',
            'display: flex;flex-direction: column; justify-content: center;',
            'display: flex;flex-direction: column; justify-content: space-between;'
        ];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
             ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderFlex()}
                ${this.renderFlexItem()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderFlex() {
        return html `
            <h5 class="helper-group-title" >${this.msg.flex}</h5>
            <div class="group">
            
                <span>${this.msg.display}</span>
                  <div class="group-edit">
                    <select prop="display">
                        <option value=""></option>
                        <option value="flex">Flex</option>
                        <option value="inline-flex">Inline Flex</option>
                    </select>
                </div>

                <span>${this.msg.flexDirection}</span>
                <div class="group-edit">
                    <select class="group-select" prop="flex-direction">
                        <option value=""></option>
                        <option value="row">Row</option>
                        <option value="row-reverse">Row Reverse</option>
                        <option value="column">Column</option>
                        <option value="column-reverse">Column Reverse</option>
                    </select>   
                </div>

                <span>${this.msg.flexWrap}</span>
                <div class="group-edit">
                    <select class="group-select" prop="flex-wrap">
                        <option value=""></option>
                        <option value="nowrap">Nowrap</option>
                        <option value="wrap">Wrap</option>
                        <option value="wrap-reverse">Wrap Reverse</option>
                    </select>  
                </div>

                <span>${this.msg.justifyContent}</span>
                <div class="group-edit">
                    <select class="group-select" prop="justify-content">
                        <option value=""></option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="space-between">Space between</option>
                        <option value="space-around">Space around</option>
                    </select>  
                </div>

                <span>${this.msg.alignItems}</span>
                <div class="group-edit">
                    <select class="group-select" prop="align-items">
                        <option value=""></option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="baseline">Baseline</option>
                        <option value="stretch">Stretch</option>
                    </select>  
                </div>

                <span>${this.msg.alignContent}</span>
                <div class="group-edit">
                    <select class="group-select" prop="align-content">
                        <option value=""></option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="space-between">Space between</option>
                        <option value="space-around">Space around</option>
                        <option value="stretch">Stretch</option>
                    </select>  
                </div>
            </div>
        `;
    }
    renderFlexItem() {
        return html `
            <h5 class="helper-group-title" >${this.msg.flexItem}</h5>
            <div class="group">

                <span>${this.msg.alignSelf}</span>
                <div class="group-edit">
                    <select class="group-select" prop="align-self">
                        <option value=""></option>
                        <option value="auto">auto</option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="baseline">Baseline</option>
                        <option value="stretch">Stretch</option>
                    </select>
                </div>

                <span>${this.msg.order}</span>
                <div class="group-edit">
                    <select class="group-select" prop="order">
                        <option value=""></option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        
                    </select>   
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
        
            <div class="gallery" >
                ${repeat(this.arrayGallery.slice(0, 4), ((key) => key), ((css, index) => {
            return html `<div class="gallery-item-1" style="${css}" .gallery=${css}>
                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                        </div>`;
        }))}
            </div>
            <div  class="gallery">
                ${repeat(this.arrayGallery.slice(4, 8), ((key) => key), ((css, index) => {
            return html `<div class="gallery-item-2" style="${css}" .gallery=${css}>
                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                </div>`;
        }))}
            </div>
        
        `;
    }
};
__decorate([
    property()
], PluginStyleFlex.prototype, "showFull", void 0);
PluginStyleFlex = __decorate([
    customElement('plugin-style-flex-100554')
], PluginStyleFlex);
export { PluginStyleFlex };
