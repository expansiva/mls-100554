/// <mls shortName="icaApresentationTextCodeBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from './_100554_icaLitElementBase';
export class IcaApresentationTextCodeBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaApresentationTextCodeBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "menu" },
            { name: "size" },
            { name: "edit-code" },
            { name: "title" },
            { name: "code-language" },
        ];
    }
    setDefaultAttributes() {
        this.setAttribute('text', `const example = '123';`);
    }
}
