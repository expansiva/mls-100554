/// <mls shortName="pluginSiteMonitorDashboardSpikes" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
export const pluginData = {
    title: "Spikes",
    getSvg() {
        return svg `
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M64 116.8c0-15.8 20.5-22 29.3-8.9L192 256l0-139.2c0-15.8 20.5-22 29.3-8.9L320 256l0-139.2c0-15.8 20.5-22 29.3-8.9L448 256l0-139.2c0-15.8 20.5-22 29.3-8.9L606.8 302.2c14.2 21.3-1.1 49.7-26.6 49.7L512 352l-64 0-64 0-64 0-64 0-64 0L64 352l0-235.2zM32 384l576 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 448c-17.7 0-32-14.3-32-32s14.3-32 32-32z"/></svg>
    `;
    }
};
export class PluginSiteMonitorDashboardSpikes extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-site-monitor-dashboard-spikes-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-site-monitor-dashboard-spikes-100554 .plugin-body{height:100%;width:100%}plugin-site-monitor-dashboard-spikes-100554 .plugin-container{background-color:#f4f5ff;padding:10px 0;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);display:flex;flex-direction:column;align-items:flex-start;height:100%;width:100%}plugin-site-monitor-dashboard-spikes-100554 header{display:flex;align-items:center;gap:3rem;margin-bottom:16px}plugin-site-monitor-dashboard-spikes-100554 header>div{display:flex;gap:.5rem}plugin-site-monitor-dashboard-spikes-100554 icon{margin-right:10px}plugin-site-monitor-dashboard-spikes-100554 h2{font-size:18px;font-weight:bold;margin:0;color:#333}plugin-site-monitor-dashboard-spikes-100554 small{color:#888;margin-left:auto;font-size:14px}plugin-site-monitor-dashboard-spikes-100554 p{font-size:16px;color:#555}plugin-site-monitor-dashboard-spikes-100554 select{border-radius:13px;border:1px solid #cecece;padding:.3rem;cursor:pointer;outline:none}`);
        this.filter = "today";
        this.chartData = {};
        this.autoPrepare = false;
        this.mode = 'simplified';
    }
    async prepare() {
        await import('./_100554_wcChart');
        this.chartData = {
            "tooltip": {
                "trigger": "axis"
            },
            "legend": {
                "data": ["Number of Requests"]
            },
            "xAxis": {
                "type": "category",
                "boundaryGap": false,
                "data": ["00:00", "01:00", "02:00", "03:00", "04:00", "05:00", "06:00", "07:00", "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00", "23:00"]
            },
            "yAxis": {
                "type": "value",
                "name": "Number of Requests"
            },
            "series": [
                {
                    "name": "Number of Requests",
                    "type": "line",
                    "data": [50, 45, 60, 80, 120, 140, 200, 300, 250, 230, 210, 180, 170, 150, 130, 100, 90, 160, 220, 260, 300, 320, 340, 280],
                    "markPoint": {
                        "data": [
                            { "type": "max", "name": "Max Traffic" },
                            { "type": "min", "name": "Min Traffic" }
                        ]
                    },
                    "markLine": {
                        "data": [
                            { "type": "average", "name": "Average Traffic" }
                        ]
                    },
                    "smooth": true,
                    "lineStyle": {
                        "width": 2
                    }
                }
            ],
        };
        if (this.mode === 'full') {
            this.chartData.title = {
                text: "Hourly Traffic Spikes"
            };
        }
        await this.updateComplete;
        const data = JSON.stringify(this.chartData);
        function escapeHTML(str) {
            return str
                .replace(/&/g, "&amp;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;");
        }
        if (this.body)
            this.body.innerHTML = `<wc-chart-100554 renderer="svg" data="${escapeHTML(data)}"></wc-chart-100554>`;
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    createRenderRoot() {
        return this;
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <select @change=${this.handleChange}>
                    <option value="today">Today</option>
                    <option value="week">Week</option>
                    <option value="mounth">Last 30 days</option>
                    <option value="all">All Time</option>
                </select>
            </header>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body"></div>`;
    }
    handleChange(e) {
        const target = e.target;
        const value = target.value;
        this.filter = value;
        this.prepare();
    }
}
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardSpikes.prototype, "filter", void 0);
__decorate([
    property()
], PluginSiteMonitorDashboardSpikes.prototype, "chartData", void 0);
__decorate([
    property({ type: Boolean })
], PluginSiteMonitorDashboardSpikes.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: String })
], PluginSiteMonitorDashboardSpikes.prototype, "mode", void 0);
__decorate([
    query('.plugin-body')
], PluginSiteMonitorDashboardSpikes.prototype, "body", void 0);
if (!customElements.get('plugin-site-monitor-dashboard-spikes-100554')) {
    customElements.define('plugin-site-monitor-dashboard-spikes-100554', PluginSiteMonitorDashboardSpikes);
}
