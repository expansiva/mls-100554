/// <mls shortName="serviceNotification" project="100554" enhancement="_100554_enhancementLitService" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceNotification100554 = class ServiceNotification100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-notification-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}`);
        this.msg = messages['en'];
        this.details = {
            icon: '&#xf0f3',
            state: 'foreground',
            position: 'right',
            tooltip: 'Notification',
            visible: true,
            widget: '_100554_serviceNotification',
            level: [0]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Notifications',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
    }
    onServiceClick(visible, reinit, el) {
    }
    createRenderRoot() {
        return this;
    }
    render() {
        return html `<p>In develpoment</p>`;
    }
};
ServiceNotification100554 = __decorate([
    customElement('service-notification-100554')
], ServiceNotification100554);
export { ServiceNotification100554 };
