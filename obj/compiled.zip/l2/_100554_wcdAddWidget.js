/// <mls shortName="wcdAddWidget" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { collab_plus } from './_100554_collabIcons';
import { CollabLitElement } from './_100554_collabLitElement';
import { globalWcd } from './_100554_wcdState';
/// **collab_i18n_start**
const message_pt = {
    widget: 'Adicionar um widget',
};
const message_en = {
    widget: 'Add an widget',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdAddWidget100554 = class WcdAddWidget100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
    }
    //-------COMPONENT----------
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <wcd-add-button @keydown=${this.handleKeyDown} @click=${this.handleClick} data-tooltip=${this.msg.widget} ><span>${collab_plus}</span></wcd-add-button>`;
    }
    //------IMPLEMENTS----------
    async handleClick(e) {
        e.stopPropagation();
        this.showHelper();
    }
    async handleKeyDown(e) {
        e.stopPropagation();
        if (e.key === 'Enter') {
            this.handleClick(new MouseEvent('click'));
        }
    }
    showHelper() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.myParent)
            throw new Error('Invalid window.wcdState.myParent');
        globalWcd.myParent.onclick = null;
        globalWcd.myParent?.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: '_100554_wcdAddWidgetDialog',
                args: '',
                position: 'p-l1',
                level: [1, 2, 3, 4, 5, 6, 7],
                toolboxOptions: { background: '#fff', border: 'none' }
            },
        ], false, 'size');
    }
};
WcdAddWidget100554 = __decorate([
    customElement('wcd-add-widget-100554')
], WcdAddWidget100554);
export { WcdAddWidget100554 };
