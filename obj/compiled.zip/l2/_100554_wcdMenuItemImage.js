/// <mls shortName="wcdMenuItemImage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
let WcdAdd100554 = class WcdAdd100554 extends WcdToolboxItemBase {
    //---------------COMPONENT----------------
    render() {
        switch (this.args) {
            case ('big'):
                return this.renderBig();
            default:
                return html `Invalid args`;
        }
    }
    renderBig() {
        this.onclick = (e) => this.clickBig();
        return html `
            A
        `;
    }
    //---------------IMPLEMENTS----------------
    clickBig() {
        console.info('clicou em big');
    }
};
WcdAdd100554 = __decorate([
    customElement('wcd-menu-item-image-100554')
], WcdAdd100554);
export { WcdAdd100554 };
