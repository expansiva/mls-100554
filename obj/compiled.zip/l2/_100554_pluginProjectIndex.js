/// <mls shortName="pluginProjectIndex" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
// To improve system performance, avoid using imports, as this file is loaded during initialization.
import { PluginBaseIndex } from './_100554_pluginBaseIndex';
export class PluginProjectIndex extends PluginBaseIndex {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    getMenus() {
        return [
        /*{
            category: 'Details',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectUsage'
        },
        {
            category: 'Details',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectConfig'
        },
        {
            category: 'Details',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectInfo'
        },
        {
            category: 'About',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectReadMe'
        },
        {
            category: 'Helpers',
            scope: ['l5Project'],
            priority: 1,
            auth: ['*'],
            widget: '_100554_pluginProjectFindFiles'
        },*/
        ];
    }
    getHooks() {
        return [];
    }
    getServices() {
        return [];
    }
}
export default new PluginProjectIndex();
