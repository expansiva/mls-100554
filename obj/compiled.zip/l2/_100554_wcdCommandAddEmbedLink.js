/// <mls shortName="wcdCommandAddEmbedLink" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { dispatchEventConciliate, importFilesIfNeeded } from './_100554_wcdCommandBase';
import { PREFIX_ICA_ID } from './_100554_collabPageElement';
import { countElementsWithTagName } from './_100554_wcdGlobal';
export async function execute(param) {
    if (!param?.selectedIca)
        throw new Error('invalid param.selectedIca');
    if (!param.overlay || typeof param.overlay.selectItem !== 'function')
        throw new Error('invalid param.overlay');
    const args = param.args;
    if (!args.url || typeof args.url !== 'string')
        throw new Error('Invalid args: url is missing or invalid');
    const icaTagName = 'ica-apresentation-embeds-social-media-100554';
    const wcTagName = 'widget-embeds-social-media-100554';
    importFilesIfNeeded([icaTagName, wcTagName]);
    const elEmbedSocialMedia = document.createElement(icaTagName);
    elEmbedSocialMedia.setAttribute('widget', wcTagName);
    elEmbedSocialMedia.setAttribute('url', args.url || '');
    const allEmbedLinks = countElementsWithTagName(param.overlay, icaTagName);
    const id = 'apEmbedLink' + (allEmbedLinks + 1);
    ;
    elEmbedSocialMedia.id = PREFIX_ICA_ID + id;
    elEmbedSocialMedia.setAttribute('idEl', id);
    param.selectedIca.insertAdjacentElement('afterend', elEmbedSocialMedia);
    await elEmbedSocialMedia.updateComplete;
    param.selectedIca.remove();
    const { x, y, height, width } = elEmbedSocialMedia.getBoundingClientRect();
    if (!param.overlay.myItens)
        param.overlay.myItens = [];
    param.overlay.myItens.push({ element: elEmbedSocialMedia, depth: 0, x, y, height, width, opacity: elEmbedSocialMedia.style.opacity });
    param.overlay.createOverlayItems();
    setTimeout(() => { param.overlay.selectItem(elEmbedSocialMedia); }, 500);
    dispatchEventConciliate();
}
