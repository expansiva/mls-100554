/// <mls shortName="icaApresentationTextBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from './_100554_icaLitElementBase';
export class IcaApresentationTextBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaApresentationTextBase';
    }
    getActionsTags() {
        let isBlankLine = !this.getAttribute('text');
        if (isBlankLine) {
            let auxEdt = '{"tp":"edit", "attr":"text"}';
            let auxAdd = '';
            const addOpen = this.getAttribute('addOpen');
            this.removeAttribute('addOpen');
            if (addOpen) {
                auxAdd = '{"open":true, "buttons" : "image,unsplash,video,embed,code,part"}';
                auxEdt = '{"tp":"click", "attr":"text"}';
            }
            return [
                { name: "add", args: auxAdd },
                { name: "edit", args: auxEdt, position: 'p-l2' },
                { name: "backButton" }
            ];
        }
        let rc = [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "edit", args: '{"tp":"edit", "attr":"text"}' },
            { name: "title" },
        ];
        return rc;
    }
}
