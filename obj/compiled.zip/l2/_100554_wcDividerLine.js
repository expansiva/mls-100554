/// <mls shortName="wcDividerLine" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let WcDivider100554 = class WcDivider100554 extends LitElement {
    createRenderRoot() {
        return this;
    }
    render() {
        return html `<hr></hr>`;
    }
};
__decorate([
    property()
], WcDivider100554.prototype, "text", void 0);
WcDivider100554 = __decorate([
    customElement('wc-divider-line-100554')
], WcDivider100554);
export { WcDivider100554 };
