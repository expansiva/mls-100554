var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="aimTaskResultLanguageHtml" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeDiff100554 } from './_100554_collabShowCodeDiff';
let AimTaskResultLanguageTypescript = class AimTaskResultLanguageTypescript extends AimTaskBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.result = '';
        this.original = '';
        this.alreadyInit = false;
        initCollabShowCodeDiff100554();
    }
    onInitializing() {
        this.changeFile(this.taskRoot);
    }
    changeFile(taskRoot) {
        if (!taskRoot.args) {
            this.taskChild.trace.push(new Date().toISOString() + ': taskroot args is missing');
            this.notifyCompleteByStatus('error', '');
            return;
        }
        const args = JSON.parse(taskRoot.args);
        // args.fileName, ex: _100111_shortName
        const { project, shortName } = mls.l2.getPath(args.fileName);
        const models = mls.editor.getModels(project, shortName);
        if (!models || !models.html) {
            this.taskChild.trace.push(new Date().toISOString() + `: no model html find to this file: ${args.fileName}`);
            this.notifyCompleteByStatus('error', '');
            return;
        }
        const result = this.taskChild._tempResult;
        if (!result) {
            this.taskChild.trace.push(new Date().toISOString() + ': no result find is taskchild');
            this.notifyCompleteByStatus('error', '');
            return;
        }
        const html = this.extractHtml(result);
        this.original = models.html.model.getValue();
        const startLineNumber = 1;
        const startColumn = 1;
        const endLineNumber = models.html.model.getLineCount();
        const endColumn = models.html.model.getLineMaxColumn(endLineNumber);
        const newText = html;
        const editOperation = {
            range: new monaco.Range(startLineNumber, startColumn, endLineNumber, endColumn),
            text: newText,
            forceMoveMarkers: true
        };
        models.html.model.pushEditOperations([], [editOperation], () => null);
        this.notifyCompleteByStatus('ok', '');
    }
    extractHtml(src) {
        const regex = /```html([\s\S]+?)```/g;
        const matches = src.match(regex);
        const contents = [];
        let ret = src;
        if (matches) {
            for (const m of matches) {
                const conteudo = m.replace(/```html|```/g, '').trim();
                contents.push(conteudo);
            }
            ret = contents[0];
        }
        return ret;
    }
    handleClick(taskRoot) {
        this.setValues(taskRoot);
        if (this.alreadyInit)
            return;
        this.codeDiff?.init();
        this.alreadyInit = true;
    }
    async setValues(taskRoot) {
        if (!taskRoot.args)
            return;
        const args = JSON.parse(taskRoot.args);
        if (!this.codeDiff)
            return;
        this.codeDiff.actualTextResult = this.result.trim();
        this.codeDiff.actualTextDiffModified = this.result.trim();
        this.codeDiff.actualTextDiffOriginal = args.html;
    }
    renderBody(taskRoot, child) {
        const body = child._tempResult || '';
        const h = this.extractHtml(body);
        this.result = h;
        return html `
        <details @click=${() => this.handleClick(taskRoot)}>
            <summary>Result</summary>
            <div>
                <div style='margin: 10px;'>
                    <collab-show-code-diff-100554
                        language="html"
                        withdiff  
                    ></collab-show-code-diff-100554>
                </div> 
            </div>
        </details>
        `;
    }
    onIconClick(action) {
        console.error('dont implemented');
    }
};
__decorate([
    query('collab-show-code-diff-100554')
], AimTaskResultLanguageTypescript.prototype, "codeDiff", void 0);
AimTaskResultLanguageTypescript = __decorate([
    customElement('aim-task-result-language-html-100554')
], AimTaskResultLanguageTypescript);
export { AimTaskResultLanguageTypescript };
