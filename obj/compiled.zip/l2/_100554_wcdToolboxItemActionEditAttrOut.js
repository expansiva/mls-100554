/// <mls shortName="wcdToolboxItemActionEditAttrOut" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
import { dispatchEventConciliate } from './_100554_wcdCommandBase';
import { getAtributtesByTag, checkAttributteHasVariation } from './_100554_icaBaseDescription';
import { getConfigProject } from './_100554_libProjectConfig';
let WCDToolboxItemActionEditAttrOut = class WCDToolboxItemActionEditAttrOut extends WcdToolboxItemBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`wcd-toolbox-item-action-edit-attr-out-100554 *{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif}wcd-toolbox-item-action-edit-attr-out-100554 .sidebar{width:100%;background:#fff;box-shadow:2px 0 10px rgba(0,0,0,0.1);padding:20px;overflow-y:auto}wcd-toolbox-item-action-edit-attr-out-100554 .sidebar h2{font-size:18px;margin-bottom:15px;color:#333}wcd-toolbox-item-action-edit-attr-out-100554 .atributo{background:#f9f9f9;border:1px solid #ddd;padding:10px;margin-bottom:10px;border-radius:5px}wcd-toolbox-item-action-edit-attr-out-100554 .atributo label{font-size:14px;font-weight:bold;display:block;margin-bottom:5px}wcd-toolbox-item-action-edit-attr-out-100554 .atributo input{width:100%;padding:8px;border:1px solid #ccc;border-radius:4px;font-size:14px}wcd-toolbox-item-action-edit-attr-out-100554 details{margin-top:5px;background:#eee;padding:5px;border-radius:4px}wcd-toolbox-item-action-edit-attr-out-100554 summary{font-size:14px;font-weight:bold;cursor:pointer}wcd-toolbox-item-action-edit-attr-out-100554 summary select{border:1px solid #a6a4a4;border-radius:3px;height:19px;outline:none}wcd-toolbox-item-action-edit-attr-out-100554 summary addvariation{display:flex;gap:1rem;align-items:center;float:right}wcd-toolbox-item-action-edit-attr-out-100554 summary addvariationitem{display:flex;gap:.5rem;align-items:center;width:0px;height:19px;opacity:0;transform:width .6s ease-out,opacity .6s ease-out}wcd-toolbox-item-action-edit-attr-out-100554 summary addvariationitem button{padding:0 .3rem;background-color:#1890FF;color:white;border:none;border-radius:2px;cursor:pointer}wcd-toolbox-item-action-edit-attr-out-100554 summary addvariationitem button:hover{opacity:.5}wcd-toolbox-item-action-edit-attr-out-100554 summary addvariation.active addvariationitem{width:max-content;opacity:1;transition:width .6s ease-out,opacity .6s ease-out}wcd-toolbox-item-action-edit-attr-out-100554 attrvariations{display:block;margin-top:.5rem}wcd-toolbox-item-action-edit-attr-out-100554 attrvariations label{font-size:12px !important;padding-left:3px}`);
        this.attrs = [];
        this.mode = 'loading';
        this.languages = {};
        this.timeKeydown = -1;
        this.setEvents();
        this.setLanguages();
    }
    setEvents() {
        mls.events.addListener(3, 'WCDEventChange', (ev) => this.onWCDEventChange(ev));
    }
    //-------COMPONENT---------------------
    createRenderRoot() {
        return this;
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.elMain || !this.myParent)
            return;
    }
    render() {
        if (this.mode === 'loading') {
            return html `<div>Loading</div>`;
        }
        else if (this.mode === 'notFound') {
            return html `<h2>Not found ica</h2>`;
        }
        return this.renderAttr();
    }
    renderAttr() {
        if (this.attrs.length === 0) {
            return html `<h3>Any attributes</h3>`;
        }
        return html `
            <div class="sidebar">
                ${repeat(this.attrs, ((key) => key.attr), ((k, index) => { return this.renderIten(k); }))}
            </div>
        `;
    }
    renderIten(info) {
        return html `
            <div class="atributo">
                <label for="label">${info.attr}</label>
                <input type="text" .info=${info} value="${info.vl}" @keydown="${this.onKeydown}">
                ${this.renderVariation(info)}
                
            </div>
        `;
    }
    renderVariation(info) {
        if (!info.hasVariation)
            return html ``;
        return html `
            <details>
                <summary><span>Variações</span> ${this.renderAddVariation(info)}</summary>
                ${repeat(info.variations, ((key) => key.attr), ((k, index) => { return this.renderVariantItem(k); }))}
            </details>
        `;
    }
    renderVariantItem(v) {
        return html `
            <attrvariations>
                <label for="${v.attr}">${v.attr}</label>
                <input type="text" .info=${v} id="${v.attr}" value="${v.vl}" @keydown="${this.onKeydown}">
            </attrvariations>
        `;
    }
    renderAddVariation(info) {
        const array = Object.keys(this.languages);
        if (array.length <= 1)
            return;
        return html `
            <addvariation .info=${info}>
                <span @click="${this.clickOptVariation}">+</span> 
                <addvariationitem>
                    <select>
                        ${repeat(array, ((key) => key), ((k, index) => { return this.renderOptVariant(k, index); }))}
                    </select>
                    <button @click="${this.clickAddVariation}">+</button>
                <addvariationitem>
            </addvariation>
        
        `;
    }
    renderOptVariant(v, index) {
        let stl = '';
        const i = this.languages[v];
        let item = i.name;
        if (index === 0) {
            stl = 'display:none';
            item = '';
        }
        return html `
            <option value="${v}" style="${stl}">${item}</option>
        
        `;
    }
    //---------IMPLEMENTATION-----------------
    clickAddVariation(e) {
        e.preventDefault();
        e.stopPropagation();
        const elBtn = e.target;
        const father = elBtn.closest('addvariation');
        const sel = father?.querySelector('select');
        const info = father.info;
        const l = this.languages[sel.value];
        if (!elBtn || !father || !sel || !info || !this.elIca)
            return;
        const key = info.attr + '-' + l.acronym;
        const vl = this.elIca.getAttribute(key);
        if (vl) {
            return;
        }
        this.elIca.setAttribute(key, l.name);
        dispatchEventConciliate();
        this.forceUpdate();
    }
    clickOptVariation(e) {
        e.preventDefault();
        e.stopPropagation();
        const elBtn = e.target;
        const father = elBtn.closest('addvariation');
        if (!elBtn || !father)
            return;
        const inAdd = father.classList.contains('active');
        if (!inAdd) {
            elBtn.innerText = 'x';
            father.classList.add('active');
        }
        else {
            elBtn.innerText = '+';
            father.classList.remove('active');
        }
    }
    getMyAtributtes() {
        try {
            const state = this.getState();
            if (!state) {
                this.mode = 'notFound';
                return;
            }
            this.elIca = state.elICA;
            if (!this.elIca) {
                this.mode = 'notFound';
                return;
            }
            const order = { vl: [], nvl: [] };
            const objAllAttr = {};
            const mainAttrs = getAtributtesByTag(this.elIca.tagName);
            mainAttrs.forEach((a) => {
                const vl = this.elIca?.getAttribute(a);
                objAllAttr[a] = vl || '';
            });
            const elAttrs = this.elIca.getAttributeNames();
            elAttrs.forEach((a) => {
                const vl = this.elIca?.getAttribute(a);
                if (!vl)
                    return;
                objAllAttr[a] = vl;
            });
            mainAttrs.forEach((a) => {
                const vr = this.findVariation(objAllAttr, a);
                const vl = objAllAttr[a];
                const obj = {
                    attr: a,
                    vl: vl || '',
                    hasVariation: checkAttributteHasVariation(a),
                    variations: []
                };
                vr.forEach((v) => {
                    const vlr = objAllAttr[v];
                    const vari = {
                        attr: v,
                        vl: vlr
                    };
                    obj.variations.push(vari);
                });
                if (!vl)
                    order.nvl.push(obj);
                else
                    order.vl.push(obj);
            });
            const ret = [...order.vl, ...order.nvl];
            this.attrs = ret;
            this.mode = 'show';
        }
        catch (e) {
            console.info(e);
            this.mode = 'notFound';
        }
    }
    getState() {
        if (window.wcdState && !window.preview) {
            return window.wcdState;
        }
        const preview = window.preview?.iframe;
        if (!preview) {
            this.mode = 'notFound';
            return undefined;
        }
        return preview.contentWindow?.wcdState;
    }
    findVariation(obj, keyBase) {
        return Object.keys(obj)
            .filter(key => key.startsWith(keyBase + '-') && key !== keyBase);
    }
    onWCDEventChange(ev) {
        this.forceUpdate();
    }
    forceUpdate() {
        this.getMyAtributtes();
        this.requestUpdate();
    }
    onKeydown(e) {
        e.stopPropagation();
        clearTimeout(this.timeKeydown);
        const el = e.target;
        if (!el)
            return;
        this.timeKeydown = setTimeout(() => {
            if (!this.elIca)
                return;
            const info = el.info;
            this.elIca.setAttribute(info.attr, el.value);
            dispatchEventConciliate();
            this.elIca.requestUpdate();
        }, 500);
    }
    async setLanguages() {
        const { project } = mls.actual[5];
        if (!project) {
            this.languages = {
                'English': { acronym: 'en', name: 'English' }
            };
        }
        else {
            const config = await getConfigProject(project);
            if (!config || !config.languages || config.languages.length === 0) {
                this.languages = {
                    'English': { acronym: 'en', name: 'English' }
                };
            }
            else {
                config.languages.forEach((entry, index) => {
                    this.languages[`${entry.name}`] = {
                        acronym: entry.language,
                        name: entry.name,
                    };
                });
            }
        }
        this.getMyAtributtes();
    }
};
__decorate([
    property({ type: Array, reflect: true })
], WCDToolboxItemActionEditAttrOut.prototype, "attrs", void 0);
WCDToolboxItemActionEditAttrOut = __decorate([
    customElement('wcd-toolbox-item-action-edit-attr-out-100554')
], WCDToolboxItemActionEditAttrOut);
export { WCDToolboxItemActionEditAttrOut };
