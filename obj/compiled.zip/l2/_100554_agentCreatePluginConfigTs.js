/// <mls shortName="agentCreatePluginConfigTs" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { AgentBase } from './_100554_iaAgentBase';
export class agentCreatePluginConfigTs extends AgentBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.visibility = 'private';
    }
    getPrompt(prompt) {
        return this.getMyImputs(prompt || '');
    }
    async afterPrompt(payload) {
        return this._afterPrompt(payload);
    }
    //---------IMPLEMENTS-------------
    async _afterPrompt(payload) {
    }
    getMyImputs(prompt) {
        return [
            {
                type: 'system',
                content: `
Você é um especialista em desenvolvimento de plugins usando TypeScript e Lit. Sua função é criar um arquivo TypeScript que define um web Component que será um plugin e implementar a lógica de acordo com o prompt
`
            },
            {
                type: 'system',
                content: `## REGRAS

 - O plugin deve estender do arquiv _100554_pluginBaseModule
 - Será usado o Lit versão 3 
 - Não se deve usar shadow DOM 
 - Não criar styles css nesse momento
 - Definir um svg de acordo com a funcionalidade do plugin
 - A primeira linha do arquivo .ts deve ser o tripleslash conforme a regra : /// <mls shortName="{{nome_da_pagina}}" project="{{projeto}}" enhancement="_100554_enhancementLit" `
            },
            {
                type: 'system',
                content: `## MODELO DE EXEMPLO

\`\`\`typescript

/// <mls shortName="pluginXxx project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, css, svg, TemplateResult } from 'lit';
import { query, property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';

export const pluginData: mls.plugin.IPluginData = {
    title: "xxx",
    description: "xxx",
    tags: ["system", "config"],
    type: "config"
    getSvg(): TemplateResult {
        return svg\`
     <svg svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480L40 480c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24l0 112c0 13.3 10.7 24 24 24s24-10.7 24-24l0-112c0-13.3-10.7-24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"/></svg>
    \`;
    }
};


@customElement('plugin-xxx-100554')
export class PageTest1100554 extends PluginBaseModule {

    render(): TemplateResult {
 
        return html\`
            // criar a logica do plugin
        \`;
    }

}
\`\`\``
            },
            {
                type: 'human',
                content: prompt || ''
            },
        ];
    }
}
