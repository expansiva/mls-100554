/// <mls shortName="wcClarification" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { postBackClarification } from "./_100554_aiAgentOrchestration";
let CollabFCATree = class CollabFCATree extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-clarification-100554{color:var(--text-primary-color);background-color:var(--bg-primary-color)}wc-clarification-100554 input,wc-clarification-100554 textarea{width:calc(100% - .5rem);padding:.3rem;border:1px solid #dcdbdb;border-radius:5px}wc-clarification-100554 .agentPlannerNewPageClarification{font-family:Arial,sans-serif;padding:20px;background:var(--bg-primary-color-darker);font-size:var(--font-size-12)}wc-clarification-100554 .section{background:var(--bg-primary-color-lighter);margin-bottom:20px;padding:15px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}wc-clarification-100554 .section h2{margin-top:0}wc-clarification-100554 .property,wc-clarification-100554 .requirement{margin-top:5px}wc-clarification-100554 .buttons{margin-top:30px}wc-clarification-100554 button{padding:10px 20px;margin-right:10px;border:none;border-radius:5px;cursor:pointer;font-size:16px}wc-clarification-100554 .cancel{background-color:#ccc}wc-clarification-100554 .continue{background-color:#4CAF50;color:white}`);
        this.clarificationData = {
            type: 'clarification',
            taskId: '',
            stepId: '',
            clarificationMessage: '',
            json: []
        };
    }
    render() {
        return html `
      <div class="agentPlannerNewPageClarification">
        <div id="content2">
          ${this.clarificationData.json.map((item) => this.renderItem(item))}
        </div>
        <div class="buttons">
          <button class="cancel" @click=${() => this.handleAction('cancel')}>
            Cancelar
          </button>
          <button class="continue" @click=${() => this.handleAction('continue')}>
            Continuar
          </button>
        </div>
      </div>
    `;
    }
    renderItem(cl) {
        return html `
            <div class="section">
              <h2>${cl.sectionName}</h2>
              <p>${cl.description}</p>
              ${Array.isArray(cl.value)
            ? html `<textarea class="requirement" rows="2" @blur=${(e) => this.fireBlur(e, cl)}>${cl.value.join('\n')}</textarea>`
            : html `<input type="text" .value=${cl.value} @blur=${(e) => this.fireBlur(e, cl)}>`}
            </div>
          `;
    }
    async handleAction(action) {
        console.info(action, this.clarificationData);
        await postBackClarification(action, this.clarificationData);
    }
    fireBlur(ev, cl) {
        const el = ev.target;
        if (!el || el.value === undefined)
            return;
        cl.value = el.value;
    }
};
__decorate([
    property()
], CollabFCATree.prototype, "clarificationData", void 0);
CollabFCATree = __decorate([
    customElement('wc-clarification-100554')
], CollabFCATree);
export { CollabFCATree };
[
    {
        "sectionName": "pageName",
        "description": "Nome da pagina",
        "value": "[pageLogin]"
    },
    {
        "sectionName": "requirements",
        "description": "requisitos para esta pagina, altere se necessário",
        "value": [
            "[suporte para autenticação de usuário]",
            "[validação de campos de entrada]"
        ]
    }
];
