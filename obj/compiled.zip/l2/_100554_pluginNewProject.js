/// <mls shortName="pluginNewProject" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { template_package, template_build, template_tsconfig, template_ds, template_l5Project, template_coreIndex } from './_100554_pluginNewProjectTemplate';
import { collab_pull_request, collab_commit, collab_arrows_rotate } from './_100554_collabIcons';
import './_100554_pluginNewProjectLog';
/// **collab_i18n_start**
const message_pt = {
    btnCreateProject: 'Criar projeto',
    btnRefreshOrg: 'Atualizar',
    push: 'Permite que os desenvolvedores façam push diretamente para a branch principal.',
    pullRequest: 'Exige que todas as mudanças sejam feitas através de Pull Requests, permitindo revisões de código e aprovação antes da integração na branch principal.',
    projectNameLabel: 'Nome do projeto',
    errorProjectName: 'Por favor, entre com um nome de projeto valido',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organização',
    visibilityLabel: 'Visibilidade do projeto',
    visibilityPublicOption: 'Público - Qualquer pessoa pode ver este repositório.',
    visibilityPrivateOption: 'Privado - Você escolhe quem pode ver.',
    teamLabel: 'Time',
    loadingAddText1: 'Buscando informações do usuário',
    loadingAddText2: 'Buscando organizações do usuário',
    step1Title: 'Passo 1',
    step2Title: 'Passo 2',
    step3Title: 'Passo 3',
    step1Msg: 'Escolha o driver para carregar suas organizações existentes.',
    step2Msg: 'Agora selecione a organização e o modo de atualização.',
    step3Msg: 'Finalmente, selecione a equipe e a visibilidade do projeto.',
    log_init: "Processando",
    log_error: "Erro",
    log_ok: "Concluido",
    log_0: "Verificando repositório",
    log_1: "Criando repositório",
    log_2: "Criando arquivo de validação",
    log_3: "Criando projeto no collab.codes",
    log_4: "Configurando visibilidade do projeto",
    log_5: "Renomeando projeto",
    log_6: "Criando arquivo de configuração",
    log_7: "Projeto criado com sucesso!",
    log_8: "Criando arquivo inicial README.md",
    log_9: "Criando arquivo inicial package.json",
    log_10: "Criando arquivo inicial build.yml",
    log_11: "Criando arquivo inicial tsconfig.json",
    log_12: "Criando arquivo inicial project.json file",
    log_13: "Criando arquivo inicial designSystem.ts file",
    log_14: "Setando permissão ao action",
    log_15: "Setando variavel no action",
    log_16: "Criando arquivo inicial pluginCollabCoreIndex.ts file",
    log_error_03: "Por favor espere, outro usuário esta utilizando o repositório.",
    log_error_04: "Existe um repositório, mas não foi possível validar o usuário",
};
const message_en = {
    btnCreateProject: 'Create project',
    btnRefreshOrg: 'Refresh',
    push: 'Allows developers to push directly to the main branch.',
    pullRequest: 'Requires all changes to be made through Pull Requests, allowing code reviews and approval before integration into the main branch.',
    projectNameLabel: 'Project name',
    errorProjectName: 'Please, enter with a valid project name',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organization',
    visibilityLabel: 'Project visibility',
    visibilityPublicOption: 'Public - Anyone can see this repository.',
    visibilityPrivateOption: 'Private - You choose who can see.',
    teamLabel: 'Team',
    loadingAddText1: 'Loading user informations',
    loadingAddText2: 'Loading user organizations',
    step1Title: 'Step 1',
    step2Title: 'Step 2',
    step3Title: 'Step 3',
    step1Msg: 'Choose the driver to load your existing organizations.',
    step2Msg: 'Now select the organization and the update mode.',
    step3Msg: 'Finally select the team and the visibility of the project.',
    log_init: "Processing",
    log_error: "Error",
    log_ok: "Completed",
    log_0: "Verify repository",
    log_1: "Creating repository",
    log_2: "Creating validation file",
    log_3: "Creating project on collab.codes",
    log_4: "Setting project visibility",
    log_5: "Renaming project",
    log_6: "Creating configuration file",
    log_7: "Project created successfully!",
    log_8: "Creating initial README.md file",
    log_9: "Creating initial package.json file",
    log_10: "Creating initial build.yml file",
    log_11: "Creating initial tsconfig.json file",
    log_12: "Creating initial project.json file",
    log_13: "Creating initial designSystem.ts file",
    log_14: "Setting permission to action",
    log_15: "Setting variable in action",
    log_16: "Creating initial pluginCollabCoreIndex.ts file",
    log_error_03: "Please wait, another user is creating; ",
    log_error_04: " There is a repository, but I was unable to validate the user",
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabNewProject = class CollabNewProject extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-project-100554 .add-container{padding:1rem;position:relative;margin-right:auto}plugin-new-project-100554 .add-container hr{box-sizing:content-box;height:0;overflow:visible;margin-top:1rem;border-width:1px 0px 0px;border-right-style:initial;border-bottom-style:initial;border-left-style:initial;border-right-color:initial;border-bottom-color:initial;border-left-color:initial;border-image:initial;border-top-style:solid;border-top-color:rgba(0,0,0,0.1);margin-bottom:1rem}plugin-new-project-100554 .add-container input,plugin-new-project-100554 .add-container select{width:100%}plugin-new-project-100554 .add-container label{font-size:var(--font-size-12)}plugin-new-project-100554 .add-container input{display:block;width:100%;padding:.375rem .75rem;font-size:1rem;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;margin:0;box-sizing:border-box}plugin-new-project-100554 .add-container select{display:block;padding:.375rem 2.25rem .375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;background-color:#fff;background-position:right .75rem center;background-size:16px 12px;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;box-sizing:border-box;text-transform:none;margin:0;word-wrap:normal}plugin-new-project-100554 .add-container .form-disabled{pointer-events:none;opacity:.5}plugin-new-project-100554 .add-container .cards-update-mode{margin-top:2rem;display:flex;flex-wrap:wrap;gap:3rem}plugin-new-project-100554 .add-container .cards-update-mode .card-update-mode{background-color:var(--grey-color-lighter);cursor:pointer;border-radius:10px;flex:1;display:flex;align-items:center;gap:3rem;padding:1rem .5rem;border:1px solid var(--grey-color-light);font-size:var(--font-size-16)}plugin-new-project-100554 .add-container .cards-update-mode .card-update-mode>input{cursor:pointer;width:30px}plugin-new-project-100554 .add-container .cards-update-mode .card-update-mode .card-update-mode-title{font-weight:var(--font-weight-bold)}plugin-new-project-100554 .add-container .cards-update-mode .card-update-mode:hover{background-color:var(--grey-color-light)}plugin-new-project-100554 .add-container small.error{color:var(--error-color);font-size:var(--font-size-12)}plugin-new-project-100554 .add-container .orgs-select{display:flex;gap:1rem}plugin-new-project-100554 .add-container .step:not(:first-child){margin-top:var(--space-48)}plugin-new-project-100554 .add-container .step h5{background-color:var(--grey-color-lighter);padding:var(--space-8);border-radius:5px}plugin-new-project-100554 .add-container .step small{font-size:var(--font-size-16)}plugin-new-project-100554 .add-container .actions-btn{margin-top:var(--space-48);display:flex;justify-content:center}plugin-new-project-100554 .add-container .actions-btn button{width:300px}plugin-new-project-100554 .add-container .progress{display:flex;height:1rem;overflow:hidden;font-size:.75rem;background-color:var(--grey-color-light);border-radius:.25rem;transition:width .6s ease;margin-bottom:1rem}plugin-new-project-100554 .add-container .progress>div{background-color:var(--success-color)}plugin-new-project-100554 .add-container .progress>div:not(plugin-new-project-100554 .add-container .progress>div.finished){animation:progress-bar-stripes 1s linear infinite;background-image:linear-gradient(45deg, rgba(255,255,255,0.15) 25%, transparent 25%, transparent 50%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.15) 75%, transparent 75%, transparent);background-size:1rem 1rem}plugin-new-project-100554 .add-container .progress>div.error{background-color:var(--error-color);opacity:.7}plugin-new-project-100554 .add-container .logs-container{min-height:200px;margin-top:2rem;background:#fcfcfc;padding:2rem;border-radius:20px}plugin-new-project-100554 .add-container .msg-loading{display:flex;justify-content:center;align-items:center;font-size:var(--font-size-12);flex-direction:column;margin-top:1rem}plugin-new-project-100554 .add-container .msg-loading>div{margin-left:1rem}plugin-new-project-100554 .add-container .msg-loading .dot{width:8px;height:8px;margin:0 2px;background-color:#333;border-radius:50%;opacity:0;animation:fade 1.5s infinite;display:inline-block}plugin-new-project-100554 .add-container .msg-loading .dot:nth-child(1){animation-delay:0s}plugin-new-project-100554 .add-container .msg-loading .dot:nth-child(2){animation-delay:.3s}plugin-new-project-100554 .add-container .msg-loading .dot:nth-child(3){animation-delay:.6s}@keyframes fade{0%,100%{opacity:0}50%{opacity:1}}@keyframes progress-bar-stripes{0%{background-position:1rem 0}100%{background-position:0 0}}`);
        this.msg = messages['en'];
        this.NEWREPONAME = 'mls-new';
        this.VALIDADEFILE = 'validate.json';
        this.driverSelected = false;
        this.orgSelected = false;
        this.loadingAdd1Msg = '';
        this.orgsLoaded = false;
        this.actualOrgs = [];
        this.actualTeams = [];
        this.isValidProjectName = true;
        this.errorDriver = '';
        this.logs = [];
        this.newProjectName = '';
        this.newProjectNumber = 0;
        this.newProjectTeam = 'admin';
        this.newProjectVisibility = 'public';
        this.newProjectUpdateMode = 'pullRequest';
        this.driverName = '';
        this.orgName = '';
        this.login = '';
        this.secret = '';
        this.drivers = {
            'github': 'GitHub',
            'gitlab': 'GitLab',
        };
        this.urls = {
            'github': 'https://github.com/',
            'gitlab': 'https://gitlab.com/',
        };
    }
    //-------COMPONENT------------
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="add-container">
                <form>
                    ${this.renderStep1()}  
                    ${this.renderStep2()} 
                    ${this.renderStep3()}
                </form>
                ${this.renderLogs()}
            </div>
        `;
    }
    renderStep1() {
        return html `
            <div class="step step1">
                <h5>${this.msg.step1Title}</h5>
                <small>${this.msg.step1Msg}</small>
                <hr>
            </div>
            <div>
                <label>${this.msg.projectNameLabel}</label>
                <input id="input_project_name" type="text" @input=${(e) => { this.newProjectName = e.target.value; }}>
                ${!this.isValidProjectName ? html `<small class="error"> ${this.msg.errorProjectName}</small>` : ''}
            </div>

            <div>
                <label>${this.msg.driverNameLabel}</label>
                <select @change=${this.onSelectDriverChange}>
                    <option value=""></option>
                    <option value="github">GitHub</option>
                    <option value="gitlab">GitLab</option>
                </select>
                ${!!this.errorDriver ? html `<small class="error"> ${this.errorDriver}</small>` : ''}

            </div>

        `;
    }
    renderStep2() {
        if (!this.driverSelected)
            return html ``;
        if (!this.orgsLoaded) {
            return html `
                <div class="msg-loading">
                    ${this.loadingAdd1Msg}
                    <div>
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                    </div>
                </div>
            `;
        }
        return html `
            <div class="step step2">
                <h5>${this.msg.step2Title}</h5>
                <small>${this.msg.step2Msg}</small>
                <hr>
            </div>
            <div class="cards-update-mode">
                <div style="display:none" class="card-update-mode" @click=${(ev) => this.onCardClick('push', ev)}>
                    <input name="update_mode" type="radio" ></input>
                    <div>
                        <div class="card-update-mode-title">
                            <span>${collab_commit}</span>
                            <span >Push</span>
                        </div>
                        <span>${this.msg.push}</span>
                    </div>
                </div>
                <div class="card-update-mode" @click=${(ev) => this.onCardClick('pullRequest', ev)}>
                    <input name="update_mode" type="radio" checked></input>
                    <div>
                        <div class="card-update-mode-title">
                            <span>${collab_pull_request}</span>
                            <span>Pull Request</span>
                        </div>
                        <span> ${this.msg.pullRequest}</span>
                    </div>
                </div>
            </div>
            <div>
                <label>${this.msg.organizationLabel}</label>
                <div class="orgs-select">
                    <select @change=${this.onOrgChanged}>
                        <option></option>
                        ${this.actualOrgs.map((org) => html `<option value="${org.id}">${org.name}</option>`)}
                    </select>
                    <button @click=${this.onRefreshOrgsClick}>${this.msg.btnRefreshOrg} ${collab_arrows_rotate}</button>
                </div>
                
            </div>
        `;
    }
    renderStep3() {
        if (!this.driverSelected || !this.orgSelected || !this.orgName)
            return html ``;
        return html `
            <div class="step step3">
                <h5>${this.msg.step3Title}</h5>
                <small>${this.msg.step3Msg}</small>
                <hr>
            </div>
            <div>
                <label>${this.msg.teamLabel}</label>
                <select @change=${(e) => { this.newProjectTeam = e.target.value; }}>
                    ${this.actualTeams.map((team) => html `<option value="${team}">${team}</option>`)}
                </select>
            </div>
            <div>
                <label>${this.msg.visibilityLabel}</label>
                <select @change=${(e) => { this.newProjectVisibility = e.target.value; }}>
                    <option value="public">${this.msg.visibilityPublicOption}</option>
                    <option value="private">${this.msg.visibilityPrivateOption}</option>
                </select>
            </div>

            <div class="actions-btn">
                <button @click=${this.onCreateProjectClick}>
                    ${this.msg.btnCreateProject}
                </button>
            </div>
        `;
    }
    renderLogs() {
        if (this.logs.length <= 0)
            return html ``;
        return html `
        <div class="logs-container">
            <div class="progress">
                <div class="progress-line"></div>
            </div>
            ${this.logs.map((log) => html `<plugin-new-project-log-100554 status=${log.status} text=${log.pre}:${log.log}></plugin-new-project-log-100554>`)}
        </div>
        `;
    }
    //------IMPLEMENTATION-----------
    toogleForm(disabled) {
        if (this.form) {
            this.form.classList.toggle('form-disabled');
        }
    }
    onSelectDriverChange(e) {
        this.errorDriver = '';
        const value = e.target.value;
        this.driverSelected = !!value;
        this.orgsLoaded = false;
        this.orgName = '';
        this.driverName = value;
        if (value) {
            this.loadOrgsByDriver(value);
        }
        else {
            this.orgSelected = false;
        }
    }
    onOrgChanged(e) {
        const value = e.target.value;
        this.orgSelected = !!value;
        this.orgName = value;
        if (this.login !== this.orgName) {
            const ref = this.actualOrgs.find((o) => o.id === value);
            if (!ref)
                throw new Error('Not found orgName');
            this.orgName = ref.name;
        }
        if (value) {
            this.loadTeamByOrg(value);
            setTimeout(() => this.step3?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
        }
    }
    async loadOrgsByDriver(driver) {
        try {
            this.instanceDriver = mls.stor.others.getDriver(driver);
            if (!this.instanceDriver)
                throw new Error('Invalid driver instance');
            this.loadingAdd1Msg = this.msg.loadingAddText1;
            const userInfo = await this.instanceDriver.getUserInfo();
            this.loadingAdd1Msg = this.msg.loadingAddText2;
            if (!userInfo.login)
                throw new Error('Invalid user login');
            this.login = userInfo.login;
            this.actualOrgs = await this.getOrgsByUser(this.login);
            this.orgsLoaded = true;
            setTimeout(() => this.step2?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
        }
        catch (err) {
            this.driverSelected = false;
            this.errorDriver = err.message;
            console.error(err.message);
        }
    }
    async getOrgsByUser(user) {
        if (!this.instanceDriver)
            throw new Error('Invalid driver instance');
        const orgs = await this.instanceDriver.getOrganizations(user);
        orgs.unshift({ id: user, name: user, avatarUrl: '', visibility: 'public' });
        return orgs;
    }
    loadTeamByOrg(org) {
        this.actualTeams = ['admin'];
    }
    addLog(log) {
        this.logs.push(log);
        this.requestUpdate();
    }
    changeStatusLastLog(status, msg) {
        const lastLog = this.logs[this.logs.length - 1];
        if (lastLog) {
            lastLog.status = status;
            lastLog.pre = status === 'finish' ? this.msg.log_ok : this.msg.log_error;
            if (msg)
                lastLog.log = msg;
            this.requestUpdate();
        }
    }
    async tryItem(fc, log) {
        try {
            this.addLog({ pre: this.msg.log_init, log, status: "inprogress" });
            setTimeout(() => this.logsContainer?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
            const rc = await fc();
            if (rc && rc.statusCode === 400) {
                this.changeStatusLastLog('error', 'Error statuscode 400');
                this.setProgressError(true);
                throw new Error('Error statuscode 400');
            }
            if (rc && rc.error) {
                const msg = log + ':' + rc.error;
                this.changeStatusLastLog('error', msg);
                this.setProgressError(true);
                throw new Error(rc.error);
            }
            this.changeStatusLastLog('finish');
            return rc;
        }
        catch (err) {
            const msg = log + ':' + err.message;
            this.changeStatusLastLog('error', msg);
            this.setProgressError(true);
            throw new Error(err.message);
        }
    }
    setProgress(nr) {
        if (!this.progress)
            return;
        this.progress.style.width = Math.ceil(nr) + '%';
    }
    setProgressError(enabled) {
        if (!this.progress)
            return;
        if (enabled)
            this.progress.classList.add('error');
        else
            this.progress.classList.remove('error');
    }
    setProgressFinished(finished) {
        if (!this.progress)
            return;
        if (finished)
            this.progress.classList.add('finished');
        else
            this.progress.classList.remove('finished');
    }
    checkIsValidProjectName(name) {
        if (!name || name.length <= 3)
            return false;
        const projectNameRegex = /^[a-zA-Z][a-zA-Z0-9_]*$/;
        return projectNameRegex.test(name);
    }
    async onCreateProjectClick(e) {
        e.preventDefault();
        this.logs = [];
        this.toogleForm(true);
        if (!this.checkIsValidProjectName(this.newProjectName)) {
            this.toogleForm(false);
            this.isValidProjectName = false;
            this.inputProjectName?.focus();
            this.inputProjectName?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }
        this.isValidProjectName = true;
        const userNameCollab = this.getLoginUser();
        if (!userNameCollab) {
            this.addLog({ pre: 'Error', log: 'User name not found', status: "error" });
            this.toogleForm(false);
            this.setProgressError(true);
            this.setProgressFinished(true);
            return;
        }
        try {
            let percent = 7.15;
            let newPercent = 0;
            this.setProgressError(false);
            this.setProgressFinished(false);
            this.setProgress(newPercent);
            const rc = await this.tryItem(async () => await this.instanceDriver?.verifyRepositoryNew(this.login, this.NEWREPONAME, userNameCollab), `${this.msg.log_0} ${this.NEWREPONAME}`);
            if (rc === 'reuse')
                percent = 12, 5;
            newPercent += percent;
            this.setProgress(newPercent);
            if (rc === 'error' || rc === 'wait') {
                const obj = {
                    'wait': this.msg.log_error_03,
                    'error': this.msg.log_error_04,
                };
                this.addLog({ pre: this.msg.log_error, log: obj[rc], status: "error" });
                this.toogleForm(false);
                return;
            }
            if (rc === 'free') {
                let orgName = this.orgName;
                if (this.login !== orgName) {
                    const ref = this.actualOrgs.find((o) => o.name === orgName);
                    if (!ref) {
                        this.changeStatusLastLog('error', 'Error not found org name');
                        this.setProgressError(true);
                        throw new Error('Error not found org name');
                    }
                    orgName = ref.id;
                }
                await this.tryItem(async () => await this.instanceDriver?.createRepository(this.login, this.NEWREPONAME, orgName, 'new project in collab.codes', 'PUBLIC'), `${this.msg.log_1} ${this.NEWREPONAME} `);
                newPercent += percent;
                this.setProgress(newPercent);
                await this.tryItem(async () => await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, this.VALIDADEFILE, `{ "users": [ "${userNameCollab}" ] }`), `${this.msg.log_2} ${this.VALIDADEFILE} `);
                newPercent += percent;
                this.setProgress(newPercent);
            }
            this.secret = this.getUniquePassword();
            const newProjectId = await this.tryItem(this.createProjecInCollab.bind(this), `${this.msg.log_3}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            if (this.newProjectVisibility === 'private')
                await this.tryItem(async () => await this.instanceDriver?.changeVisibility(this.orgName, this.NEWREPONAME, 'PRIVATE'), `${this.msg.log_4}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            const newProjectName = `mls-${newProjectId}`;
            await this.tryItem(async () => await this.instanceDriver?.renameRepository(this.orgName, this.NEWREPONAME, newProjectName), `${this.msg.log_5}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.setPermissionAction(this.orgName, newProjectName), `${this.msg.log_14}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.setVariableAction(this.orgName, newProjectName, this.secret), `${this.msg.log_15}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialReadMe(newProjectId), this.msg.log_8);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialBuildFile(newProjectId), this.msg.log_10);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            /*await this.tryItem(async () => await this.createInitialCoreIndex(newProjectId), this.msg.log_16);
            newPercent += percent;
            this.setProgress(newPercent);

            await this.sleep(200);*/
            await this.tryItem(async () => await this.createInitialPackageFile(newProjectId), this.msg.log_9);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialTSConfigFile(newProjectId), this.msg.log_11);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialConfigL5File(newProjectId), this.msg.log_12);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialDSFile(newProjectId), this.msg.log_13);
            newPercent += percent;
            this.setProgress(newPercent);
        }
        catch (err) {
            this.toogleForm(false);
        }
        this.addLog({ pre: this.msg.log_ok, log: this.msg.log_7, status: "finish" });
        this.setProgressFinished(true);
        this.dispatchEvent(new CustomEvent('collab-new-project', {
            detail: this.newProjectNumber, bubbles: true, composed: true
        }));
    }
    async createProjecInCollab() {
        const userNameCollab = this.getLoginUser();
        const param = {
            orgName: this.orgName,
            info: {
                projectDriver: this.drivers[this.driverName],
                projectURL: `${this.urls[this.driverName]}main/${this.orgName}/mls-new/`,
            },
            settings: {
                id: 0,
                name: this.newProjectName,
                owner: userNameCollab,
                userAuth: this.newProjectVisibility,
                archived_at: '',
                created_at: '',
                prj_dependencies: [100554],
                value: '',
                repository_secret: this.secret
            }
        };
        try {
            const res = await mls.api.cbeSaveNewPrj(param);
            console.info({ res });
            return res;
        }
        catch (err) {
            throw new Error('Error on create project in collab' + err.message);
        }
    }
    async setPermissionAction(org, repo) {
        if (this.driverName === 'gitlab' || !this.instanceDriver)
            return;
        return await this.instanceDriver.setPermissionAction(org, repo, '');
    }
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    async setVariableAction(org, repo, psw) {
        if (!this.instanceDriver)
            return;
        return await this.instanceDriver.addVariable2(org, repo, 'COLLAB_TOKEN', psw);
    }
    async createInitialReadMe(project) {
        const fileName = 'README.md';
        const content = `ReadMe: ${project}`;
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialBuildFile(project) {
        const fileName = '.github/workflows/build.yml';
        const content = template_build.template.trim().replace(/\[project\]/g, project.toString());
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialCoreIndex(project) {
        const fileName = 'l2/pluginCollabCoreIndex.ts';
        const content = template_coreIndex.template.trim().replace(/\[project\]/g, project.toString());
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialPackageFile(project) {
        const fileName = 'package.json';
        const content = template_package.template.replace(/\[project\]/g, project.toString()).trim();
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialTSConfigFile(project) {
        const fileName = 'tsconfig.json';
        const content = template_tsconfig.template.trim();
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialConfigL5File(project) {
        const fileName = 'l5/project.json';
        const content = template_l5Project.template.trim().replace(/\[org\]/g, this.orgName);
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialDSFile(project) {
        const fileName = 'l2/designSystem.ts';
        const content = template_ds.template.trim().replace(/\[project\]/g, project.toString());
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    onCardClick(opt, ev) {
        const target = ev.target;
        const input = target.closest('.card-update-mode')?.querySelector('input');
        if (input)
            input.checked = true;
        this.newProjectUpdateMode = opt;
    }
    async onRefreshOrgsClick(ev) {
        ev.preventDefault();
        this.actualOrgs = await this.getOrgsByUser(this.login);
        this.requestUpdate();
    }
    getLoginUser() {
        const userNameCollab = mls.getActualUser();
        return userNameCollab;
    }
    getUniquePassword() {
        const height = Math.floor(Math.random() * (15 - 6 + 1)) + 6;
        const caracters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        const encoder = new TextEncoder();
        const data = encoder.encode(Date.now().toString() + Math.random());
        const hashBuffer = crypto.subtle.digestSync
            ? crypto.subtle.digestSync('SHA-256', data)
            : null;
        const bytes = hashBuffer ? new Uint8Array(hashBuffer) : crypto.getRandomValues(new Uint8Array(32));
        let password = '';
        for (let i = 0; i < height; i++) {
            const idx = bytes[i % bytes.length] % caracters.length;
            password += caracters[idx];
        }
        return password;
    }
};
__decorate([
    property()
], CollabNewProject.prototype, "driverSelected", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "orgSelected", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "loadingAdd1Msg", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "orgsLoaded", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "actualOrgs", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "actualTeams", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "isValidProjectName", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "errorDriver", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "logs", void 0);
__decorate([
    query('#input_project_name')
], CollabNewProject.prototype, "inputProjectName", void 0);
__decorate([
    query('form')
], CollabNewProject.prototype, "form", void 0);
__decorate([
    query('.logs-container')
], CollabNewProject.prototype, "logsContainer", void 0);
__decorate([
    query('.step1')
], CollabNewProject.prototype, "step1", void 0);
__decorate([
    query('.step2')
], CollabNewProject.prototype, "step2", void 0);
__decorate([
    query('.step3')
], CollabNewProject.prototype, "step3", void 0);
__decorate([
    query('.progress-line')
], CollabNewProject.prototype, "progress", void 0);
CollabNewProject = __decorate([
    customElement('plugin-new-project-100554')
], CollabNewProject);
export { CollabNewProject };
