/// <mls shortName="collabDsInputSelectColor" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
export function initCollabDsInputSelectColor() { }
;
let CollabDsInputSelectColor = class CollabDsInputSelectColor extends LitElement {
    constructor() {
        super(...arguments);
        this.arrayInputSelect = [];
        this.arraySelect = [];
        this.valueInput = '';
        this.valueSelect = '';
        this.valueColor = '';
        this.prop = '';
        this.useInput = 'true';
        this.useSelect = 'true';
        this.useColor = 'true';
    }
    get value() { return this.configGetValue(); }
    ;
    set value(str) { this.configSetValue(str); }
    ;
    render() {
        return html `    
            ${this.useInput === 'true' ? this.renderInput() : ''}
            ${this.useSelect === 'true' ? this.renderSelect() : ''}
            ${this.useColor === 'true' ? this.renderColor() : ''}
        `;
    }
    renderInput() {
        return html `
            <div>
                <input type="search" .value="${this.onlyNumber(this.valueInput)}" @input="${this.allChange}">
                <select @change="${this.allChange}" .value="px">
                    ${repeat(this.arrayInputSelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
                </select>
            </div>
        `;
    }
    renderSelect() {
        return html `
            <select @change="${this.allChange}" .value="px" prop="${this.prop}">
                    ${repeat(this.arraySelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
            </select>
        `;
    }
    renderColor() {
        return html `
            <input type="color" .value="${this.valueColor}" @input="${this.allChange}">
        `;
    }
    updated() {
        if (!this.shadowRoot)
            return;
        const sel = this.shadowRoot.querySelector('div select');
        if (sel)
            sel.value = this.onlyTxt(this.valueInput);
        const sel2 = this.shadowRoot.querySelector('select[prop]');
        if (sel2)
            sel2.value = this.onlyTxt(this.valueSelect);
    }
    //---------IMPLEMENTS-------------
    configGetValue() {
        let ret = '';
        if (this.useInput === 'true' && this.valueInput)
            ret = this.valueInput;
        else if (this.useInput === 'true')
            ret = '0px';
        if (this.useSelect === 'true' && this.valueSelect)
            ret += ' ' + this.valueSelect;
        else if (this.useSelect === 'true')
            ret = ' none';
        if (this.useColor === 'true' && this.valueColor)
            ret += ' ' + this.valueColor;
        else if (this.useColor === 'true')
            ret = ' #ffffff';
        return ret.trim();
    }
    configSetValue(str) {
        if (!str)
            return;
        const array = str.split(' ');
        if (this.useInput === 'true' && array.length >= 1) {
            this.valueInput = array[0];
            array.splice(0, 1);
        }
        if (this.useSelect === 'true' && array.length >= 1) {
            this.valueSelect = array[0];
            array.splice(0, 1);
        }
        if (this.useColor === 'true' && array.length >= 1) {
            this.valueColor = array[0];
            array.splice(0, 1);
        }
    }
    onlyNumber(str) {
        const regexNum = /\d+/;
        const res = str.match(regexNum);
        return res && res[0] ? res[0] : '';
    }
    onlyTxt(str) {
        const regexStr = /[a-zA-Z]+/;
        const res = str.match(regexStr);
        return res && res[0] ? res[0] : '';
    }
    allChange(e) {
        e.stopPropagation();
        if (!this.shadowRoot)
            return;
        const parent = this.shadowRoot;
        let input = parent.querySelector('input[type="search"]');
        let sel = parent.querySelector('select');
        let sel2 = parent.querySelector('select[prop]');
        let color = parent.querySelector('input[type="color"]');
        const ret = [];
        if (this.useInput) {
            this.valueInput = input.value + sel.value;
            ret.push({ tp: 'input', value: input.value + sel.value });
        }
        if (this.useSelect) {
            this.valueSelect = sel2.value;
            ret.push({ tp: 'select', value: sel2.value });
        }
        if (this.useColor) {
            this.valueColor = color.value;
            ret.push({ tp: 'color', value: color.value });
        }
        this.fireEvents({
            key: this.prop,
            value: ret
        });
    }
    fireEvents(obj) {
        obj.target = this;
        const onChangePropEvento = new CustomEvent('onchange', {
            bubbles: true,
            detail: obj,
        });
        this.dispatchEvent(onChangePropEvento);
    }
};
CollabDsInputSelectColor.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "valueInput", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "valueSelect", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "valueColor", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "prop", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useInput", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useSelect", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useColor", void 0);
CollabDsInputSelectColor = __decorate([
    customElement('collab-ds-input-select-color-100554')
], CollabDsInputSelectColor);
export { CollabDsInputSelectColor };
