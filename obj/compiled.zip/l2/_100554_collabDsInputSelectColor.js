/// <mls shortName="collabDsInputSelectColor" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
export function initCollabDsInputSelectColor() { }
;
let CollabDsInputSelectColor = class CollabDsInputSelectColor extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-ds-input-select-color-100554{display:grid;grid-template-columns:auto 1fr auto auto;gap:8px;align-items:center}collab-ds-input-select-color-100554 input,collab-ds-input-select-color-100554 select{height:25px}collab-ds-input-select-color-100554 input[type="color"]{display:block;font-size:1rem;background-color:#fff;background-clip:padding-box;border:1px solid #b5b4b4;border-radius:.25rem;transition:border-color .15s ease-in-out 0s,box-shadow .15s ease-in-out 0s;outline:none}collab-ds-input-select-color-100554 select{display:block;font-size:1rem;background-color:#fff;background-clip:padding-box;border:1px solid #b5b4b4;border-radius:.25rem;transition:border-color .15s ease-in-out 0s,box-shadow .15s ease-in-out 0s;outline:none}collab-ds-input-select-color-100554>div{display:flex;border:1px solid #b5b4b4;border-radius:5px}collab-ds-input-select-color-100554>div input[type="search"]{border:none;padding:.1rem .1rem;outline:none;flex:1;width:100%;min-width:30px;max-width:100px}collab-ds-input-select-color-100554>div select{border:0px;border-top-left-radius:0px;border-bottom-left-radius:0px;min-width:30px;padding:.1rem .1rem;outline:none;-webkit-appearance:none;font-size:13px;text-align-last:center;transition:all .3s;user-select:none}collab-ds-input-select-color-100554>div select:hover{background-color:#40404054;color:white;transition:all .3s}`);
        this.arrayInputSelect = [];
        this.arraySelect = [];
        this.valueInput = '';
        this.valueSelect = '';
        this.valueColor = '';
        this.prop = '';
        this.useInput = 'true';
        this.useSelect = 'true';
        this.useColor = 'true';
    }
    get value() { return this.configGetValue(); }
    ;
    set value(str) { this.configSetValue(str); }
    ;
    render() {
        return html `    
            ${this.useInput === 'true' ? this.renderInput() : ''}
            ${this.useSelect === 'true' ? this.renderSelect() : ''}
            ${this.useColor === 'true' ? this.renderColor() : ''}
        `;
    }
    renderInput() {
        return html `
            <div>
                <input type="search" .value="${this.onlyNumber(this.valueInput)}" @input="${this.allChange}">
                <select @change="${this.allChange}" .value="px">
                    ${repeat(this.arrayInputSelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
                </select>
            </div>
        `;
    }
    renderSelect() {
        return html `
            <select @change="${this.allChange}" .value="px" prop="${this.prop}">
                    ${repeat(this.arraySelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
            </select>
        `;
    }
    renderColor() {
        return html `
            <input type="color" .value="${this.valueColor}" @input="${this.allChange}">
        `;
    }
    updated() {
        const sel = this.querySelector('div select');
        if (sel)
            sel.value = this.onlyTxt(this.valueInput);
        const sel2 = this.querySelector('select[prop]');
        if (sel2)
            sel2.value = this.onlyTxt(this.valueSelect);
    }
    //---------IMPLEMENTS-------------
    configGetValue() {
        let ret = '';
        if (this.useInput === 'true' && this.valueInput)
            ret = this.valueInput;
        else if (this.useInput === 'true')
            ret = '0px';
        if (this.useSelect === 'true' && this.valueSelect)
            ret += ' ' + this.valueSelect;
        else if (this.useSelect === 'true')
            ret = ' none';
        if (this.useColor === 'true' && this.valueColor)
            ret += ' ' + this.valueColor;
        else if (this.useColor === 'true')
            ret = ' #ffffff';
        return ret.trim();
    }
    configSetValue(str) {
        if (!str)
            return;
        const array = str.split(' ');
        if (this.useInput === 'true' && array.length >= 1) {
            this.valueInput = array[0];
            array.splice(0, 1);
        }
        if (this.useSelect === 'true' && array.length >= 1) {
            this.valueSelect = array[0];
            array.splice(0, 1);
        }
        if (this.useColor === 'true' && array.length >= 1) {
            this.valueColor = array[0];
            array.splice(0, 1);
        }
    }
    onlyNumber(str) {
        const regexNum = /\d+/;
        const res = str.match(regexNum);
        return res && res[0] ? res[0] : '';
    }
    onlyTxt(str) {
        const regexStr = /[a-zA-Z]+/;
        const res = str.match(regexStr);
        return res && res[0] ? res[0] : '';
    }
    allChange(e) {
        e.stopPropagation();
        let input = this.querySelector('input[type="search"]');
        let sel = this.querySelector('select');
        let sel2 = this.querySelector('select[prop]');
        let color = this.querySelector('input[type="color"]');
        const ret = [];
        if (this.useInput) {
            this.valueInput = input.value + sel.value;
            ret.push({ tp: 'input', value: input.value + sel.value });
        }
        if (this.useSelect) {
            this.valueSelect = sel2.value;
            ret.push({ tp: 'select', value: sel2.value });
        }
        if (this.useColor) {
            this.valueColor = color.value;
            ret.push({ tp: 'color', value: color.value });
        }
        this.fireEvents({
            key: this.prop,
            value: ret
        });
    }
    fireEvents(obj) {
        obj.target = this;
        const onChangePropEvento = new CustomEvent('onchange', {
            bubbles: true,
            detail: obj,
        });
        this.dispatchEvent(onChangePropEvento);
    }
};
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "valueInput", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "valueSelect", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "valueColor", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "prop", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useInput", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useSelect", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useColor", void 0);
CollabDsInputSelectColor = __decorate([
    customElement('collab-ds-input-select-color-100554')
], CollabDsInputSelectColor);
export { CollabDsInputSelectColor };
