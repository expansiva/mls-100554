/// <mls shortName="agentPlannerNewWidget" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { svg_agent } from './_100554_aiAgentBase';
import { getListFilesStart, preferModelType, systemComponentsInstruction } from './_100554_aiPrompts';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, getStepById, updateStepStatus, calculateStepsStatistics, getInteractionStepId, } from "./_100554_aiAgentHelper";
import { startNewAiTask, executeNextStep, startNewInteractionInAiTask, addNewStep } from "./_100554_aiAgentOrchestration";
import './_100554_wcClarificationPlannerNewWidget';
const agentName = "agentPlannerNewWidget";
const widgetPrefix = "widget";
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "criação de novos componentes UI, web components, widgets, estes widgets podem futuramente serem incluidos em uma página html",
        visibility: "public",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async afterClarification(context, stepId, data) {
            return _afterClarification(context, stepId, data);
        },
        async beforeClarification(context, stepId) {
            return _beforeClarification(context, stepId);
        }
    };
}
;
const _beforePrompt = async (context) => {
    const taskTitle = "Planning";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        // using temporary context, create a new task
        const inputs = await getPrompts(context.message.content, null);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
    }
    else {
        const step = getNextPendingStepByAgentName(context.task, agentName);
        if (!step) {
            throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
        }
        context.task = await updateStepStatus(context.task, step.stepId, "in_progress");
        const inputs = await getPrompts(step.prompt, step.rags);
        await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
    const { flexible } = calculateStepsStatistics([step], true);
    if (flexible > 0)
        throw new Error(`[${agentName}] afterPrompt: error, Flexible step found.`);
    context.task = await updateStepStatus(context.task, step.stepId, "completed");
    await executeNextStep(context);
};
const _beforeClarification = async (context, stepId) => {
    if (!context.task)
        throw new Error("[_beforeClarification] Invalid context.task");
    const step = getStepById(context.task, stepId);
    if (!step)
        throw new Error(`[_beforeClarification] Invalid step: ${stepId} on task: ${context.task.PK}`);
    if (!step.json)
        throw new Error(`[_beforeClarification] Invalid step json on task: ${context.task.PK} step ${stepId}`);
    const element = prepareHtmlClarification(step.json, context.task.PK, stepId, step.clarificationMessage);
    return element;
};
const _afterClarification = async (context, stepId, data) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    if (!data.json)
        throw new Error("Invalid json after clarification");
    const step = getStepById(context.task, stepId);
    if (!step) {
        throw new Error(`[${agentName}] _afterClarification: No found step: ${stepId} for this agent.`);
    }
    const interactionId = getInteractionStepId(context.task, step.stepId);
    if (!interactionId)
        throw new Error("[_afterClarification] Not found interactionId in pending step");
    const payload = getStepById(context.task, interactionId);
    if (!payload || payload.type !== "agent")
        throw new Error("[_afterClarification] Clarification or tool step not bellow a agent");
    const promptUser = payload.interaction?.input.find((input) => input.type === 'human')?.content || '';
    const rc = {
        prompt: promptUser,
        json: data.json
    };
    const newStep = {
        agentName: 'agentNewWidget',
        prompt: JSON.stringify(rc),
        status: 'pending',
        stepId: step.stepId + 1,
        interaction: null,
        nextSteps: null,
        rags: null,
        type: 'agent'
    };
    await addNewStep(context, step.stepId, [newStep]);
};
export async function getPrompts(prompt, rags) {
    if (!prompt || prompt.length < 3)
        throw new Error("Invalid Prompt");
    const prompts = [];
    prompts.push(systemMainInstruction());
    prompts.push(systemComponentsInstruction());
    prompts.push(await systemWidgetsPrompt());
    prompts.push({
        type: 'human',
        content: prompt
    });
    return prompts;
}
function systemMainInstruction() {
    return {
        type: 'system',
        content: `${preferModelType("translate")}
Você é um planejador responsável por definir os detalhes de criação de um novo web-componente (widget) que será incluído em uma página HTML.

Tarefas
1. Entenda o propósito do widget passando pelo prompt original do usuário.
2. Escolha o widgetName, evitando colisões com a lista “Widgets existentes”, o widgetName deve iniciar com o prefixo "${widgetPrefix}".
3. Escolha o parentClass base mais adequado na lista “Categorias de widgets”.
4. Cruze os atributos do grupo escolhido com as necessidades do widget:
   • Liste apenas os atributos relevantes que já existirem no grupo.  
   • Para cada necessidade sem atributo correspondente, gere um novo atributo
     e adicione “(essencial)” na descrição.
5. Defina restrições e requisitos técnicos/funcionais.
6. Se o prompt original não tratar da criação de web-componente, retorne um erro pedindo ao usuário refazer o pedido.
7. Caso contrário, devolva um bloco **clarification** com o json base abaixo, usando textos na linguagem do usuário.

## Formato de saida
Você deve retornar um array de objetos no formato JSON. Cada objeto representa uma subtarefa, com **apenas um dos seguintes formatos**:

\`\`\` json
[
  {
    "type": "clarification",
    "clarificationMessage": string,
    "json": TClarification
  },
  {
    "type": "result",
    "result": string
  }
]
\`\`\`

definição de TClarification
\`\`\`json
[
    {
        "sectionName": "resume",
        "description": "[Breve descrição do widget]"
    },
    {
        "sectionName": "parentClass",
        "description": "Component for selecting date ranges, useful for period filters."
        "widgetName": "IcaFormsInputDateRangeBase"
    },
    {
        "sectionName": "widgetName",
        "description": "Nome do Widget",
        "widgetName": "[WidgetName ex: wcDatePickerRangeCustom]"
        "tagName": "[WidgetTagName ex: wc-date-picker-range-custom-100554]"
    },
    {
        "sectionName": "properties",
        "description": "Propriedades do widget",
        "properties": [
            { "propertyName": "[propertyName]", "description": "[description]", "isEssencial": "true|false" }
        ]
    },
    {
        "sectionName": "requirements",
        "description": "requisitos para este widget, altere se necessário",
        "functionalRequirements": [
            "[example 1 - Must support keyboard navigation]",
            "[example 2 - Return ISO-8601 date strings]"
        ],
        "visualRequirements": [
            "[example 1 - Must render two consecutive months side by side]",
            "[example 2 - Must clearly differentiate between selected, hovered, and disabled dates]"
        ],
    }
]
\`\`\`
`
    };
}
async function getWidgetList() {
    const widgets = await getListFilesStart(widgetPrefix);
    return widgets.join('\n');
}
async function systemWidgetsPrompt() {
    return {
        type: 'system',
        content: "## Widgets existentes\n" + await getWidgetList()
    };
}
function prepareHtmlClarification(json, taskId, stepId, clarificationMessage) {
    const div = document.createElement('div');
    if (typeof json === 'string') {
        div.innerHTML = json;
        return div;
    }
    const clarificationData = {
        clarificationMessage,
        stepId: stepId,
        taskId: taskId,
        json: json
    };
    const clariEl = document.createElement('wc-clarification-planner-new-widget-100554');
    clariEl.data = clarificationData;
    div.appendChild(clariEl);
    return div;
}
