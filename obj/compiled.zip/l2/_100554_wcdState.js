/// <mls shortName="wcdState" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
/*declare global {
    interface Window {
        wcdState: {
            myParent: WCDToolboxMethodos | undefined;
            elMain: HTMLElement | undefined;
            elICA: IcaLitElementBaseMethods | undefined;
        }
    }
}*/
export const globalWcd = {};
Object.defineProperty(globalWcd, 'myParent', {
    get: function () {
        return window.wcdState.myParent;
    },
    set: function (v) {
        window.wcdState.myParent = v;
    }
});
Object.defineProperty(globalWcd, 'elMain', {
    get: function () {
        return window.wcdState.elMain;
    },
    set: function (v) {
        window.wcdState.elMain = v;
    }
});
Object.defineProperty(globalWcd, 'elICA', {
    get: function () {
        return window.wcdState.elICA;
    },
    set: function (v) {
        window.wcdState.elICA = v;
    }
});
window.wcdState = {};
