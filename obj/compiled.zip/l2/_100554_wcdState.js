/// <mls shortName="wcdState" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export {};
/*declare global {
    interface Window {
        wcdState: {
            myParent: WCDToolboxMethodos | undefined;
            elMain: HTMLElement | undefined;
            elICA: IcaLitElementBaseMethods | undefined;
        }
    }
}

export { };*/ 
