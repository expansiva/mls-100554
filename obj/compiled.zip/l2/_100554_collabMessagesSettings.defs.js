"use strict";
/// <mls shortName="collabMessagesSettings" project="100554" enhancement="_blank" folder="" />
