/// <mls shortName="serviceUserSettings" project="100554" enhancement="_100554_enhancementLitService" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
/// **collab_i18n_start**
const message_pt = {
    languageLabel: 'Linguagens',
    alterarLabel: 'Alterar',
    themeLabel: 'Tema',
    themeOptDark: 'Escuro',
    themeOptLight: 'Claro',
    themeOptDf: 'Padrão',
};
const message_en = {
    languageLabel: 'Languages',
    alterarLabel: 'Change',
    themeLabel: 'Theme',
    themeOptDark: 'Dark',
    themeOptLight: 'Light',
    themeOptDf: 'Default',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceUserSettings100554 = class ServiceUserSettings100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.myMessage = messages['en-us'];
        this.details = {
            icon: '&#xf4fe',
            state: 'foreground',
            position: 'right',
            tooltip: 'User Settings',
            visible: true,
            widget: '_100554_serviceUserSettings',
            level: [0]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'User Settings',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.actualLanguage = 'pt-BR';
        this.actualTheme = 'default';
    }
    onServiceClick(visible, reinit, el) {
        if (visible && reinit) {
            this.requestUpdate();
        }
    }
    getUserSettings() {
        const userSettings = localStorage.getItem('userSettings');
        if (!userSettings) {
            this.actualLanguage = 'default';
            return;
        }
        const data = JSON.parse(userSettings);
        if (!data || !data.language) {
            this.actualLanguage = 'default';
            return;
        }
        this.actualLanguage = data.language;
        let userTheme = this.getUserTheme();
        if (!userTheme)
            userTheme = this.getUserThemeOS();
        this.actualTheme = userTheme;
    }
    setUserLanguage(language) {
        let data = { language: '' };
        const userSettings = localStorage.getItem('userSettings');
        if (userSettings)
            data = JSON.parse(userSettings);
        if (language === 'default')
            this.actualLanguage = this.getUserDefault();
        else
            this.actualLanguage = language;
        data.language = language;
        localStorage.setItem('userSettings', JSON.stringify(data));
    }
    getNavigatorLanguage() {
        const lg = navigator.language ? navigator.language : '';
        return lg;
    }
    ;
    getUserDefault() {
        const navigatorLanguage = this.getNavigatorLanguage();
        const acceptLanguages = ['en-US', 'pt-BR'];
        const defaultLang = acceptLanguages.includes(navigatorLanguage) ? navigatorLanguage : 'en-US';
        return defaultLang;
    }
    handleChangeLanguageClick() {
        if (!this.selectLanguage)
            return;
        const language = this.selectLanguage.value;
        this.setUserLanguage(language);
        location.reload();
    }
    handleChangeThemeClick() {
        if (!this.selectTheme)
            return;
        const theme = this.selectTheme.value;
        this.setUserTheme(theme);
        location.reload();
    }
    setUserTheme(theme) {
        localStorage.setItem('_100554_serviceUserSettings_theme', theme);
    }
    getUserTheme() {
        return localStorage.getItem('_100554_serviceUserSettings_theme');
    }
    getUserThemeOS() {
        const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        return isDarkMode ? 'dark' : 'light';
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.myMessage = messages[lang];
        this.getUserSettings();
        return html `
        <section>
            <details> 
                <summary>${this.myMessage.languageLabel}</summary>
                <div>
                    <select style="width:200px" .value=${this.actualLanguage} class="select-language">
                        <option value="default">Default</option>
                        <option value="pt-BR">pt-BR</option>
                        <option value="en-US">en-US</option>
                    </select>
                    <button style="margin-top:1rem" @click=${this.handleChangeLanguageClick}>${this.myMessage.alterarLabel}</button>
                </div>
            </details>
            <details> 
                <summary>${this.myMessage.themeLabel}</summary>
                <div>
                    <select style="width:200px" .value=${this.actualTheme} class="select-theme">
                        <option value="default">${this.myMessage.themeOptDf}</option>
                        <option value="dark">${this.myMessage.themeOptDark}</option>
                        <option value="light">${this.myMessage.themeOptLight}</option>
                    </select>
                    <button style="margin-top:1rem" @click=${this.handleChangeThemeClick}>${this.myMessage.alterarLabel}</button>
                </div>
            </details>
        </section>
        `;
    }
};
ServiceUserSettings100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceUserSettings100554.prototype, "actualLanguage", void 0);
__decorate([
    property()
], ServiceUserSettings100554.prototype, "actualTheme", void 0);
__decorate([
    query('.select-language')
], ServiceUserSettings100554.prototype, "selectLanguage", void 0);
__decorate([
    query('.select-theme')
], ServiceUserSettings100554.prototype, "selectTheme", void 0);
ServiceUserSettings100554 = __decorate([
    customElement('service-user-settings-100554')
], ServiceUserSettings100554);
export { ServiceUserSettings100554 };
