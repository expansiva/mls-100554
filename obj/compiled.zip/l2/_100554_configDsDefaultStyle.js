/// <mls shortName="configDsDefaultStyle" project="100554" enhancement="_blank" groupName="other" />
import { Common } from './_100554_configDsDefaultCommon';
import { Token } from './_100554_configDsDefaultTokens';
export class Style extends mls.l3.Style {
    constructor(dsIO, ds, component) {
        super(dsIO);
        this.list = {};
        this.add = (componentName, stylename, less, reference) => this._addComponentStyle(componentName, stylename, less, reference);
        this.rename = (componentName, styleName, newName) => this._renameComponentStyle(componentName, styleName, newName);
        this.remove = (componentName, styleName) => this._removeComponentStyle(componentName, styleName);
        this.find = (componentName, styleName) => this._find(componentName, styleName);
        this.ds = ds;
        this.methods = new Common(ds, dsIO);
        ;
        this.component = component;
        this.token = new Token(dsIO, ds);
        this.prepareStyles();
    }
    prepareStyles() {
        this.list = {};
        this.ds.components.items.forEach((comp) => {
            comp.styles.forEach((style) => {
                this._addComponentStyle2(this.component.list[comp.name], style);
            });
        });
    }
    getKeyComponentStyle(componentName, styleName) {
        return `${componentName}_${styleName}`;
    }
    _find(componentName, exampleName) {
        const key = this.getKeyComponentStyle(componentName, exampleName);
        return this.list[key];
    }
    async _addComponentStyle(componentName, stylename, less, reference) {
        const componentByName = this.component.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        const styleByName = this.find(componentName, stylename);
        if (styleByName)
            throw new Error(`style with name: ${stylename} already exists in component: ${componentName}`);
        const fullpath = this.methods.getDsComponentStyleFilePath(componentName);
        const newStyle = {
            stylename,
            reference,
            setStyleLessIO: () => { return Promise.resolve(true); },
            getStyleLessIO: () => { return Promise.resolve(''); },
        };
        this._addComponentStyle2(componentByName, newStyle);
        try {
            await this.methods.createNewFile(stylename, fullpath, 'less', less);
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on add style:' + err.message));
        }
    }
    _addComponentStyle2(component, style) {
        style.setStyleLessIO = (content) => this._setStyleLessIO(style, component.name, content);
        style.getStyleLessIO = () => this._getStyleLessIO(style, component.name);
        const key = this.getKeyComponentStyle(component.name, style.stylename);
        this.list[key] = style;
    }
    async _removeComponentStyle(componentName, stylename) {
        const componentByName = this.component.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        const styleByName = this.find(componentName, stylename);
        if (!styleByName)
            throw new Error(`style: ${stylename} dont exists`);
        const fullpath = this.methods.getDsComponentStyleFilePath(componentName);
        try {
            if (!styleByName.reference)
                await this.methods.setContentFile(styleByName.stylename, 'less', fullpath, null);
            const key = this.getKeyComponentStyle(componentName, stylename);
            delete this.list[key];
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove style:' + err.message));
        }
    }
    async _renameComponentStyle(componentName, stylename, newName) {
        const componentByName = this.component.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        const styleByName = this.find(componentName, stylename);
        if (!styleByName)
            throw new Error(`style: ${stylename} dont exists`);
        const fullpath = this.methods.getDsComponentStyleFilePath(componentName);
        const oldName = stylename;
        const styleNewName = this.find(componentName, newName);
        if (styleNewName)
            throw new Error(`style with name: ${newName} already exists in component: ${componentName}`);
        styleByName.stylename = newName;
        try {
            await this.methods.renameContentFile(oldName, 'less', fullpath, newName);
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on rename style :' + err.message));
        }
    }
    async _getStyleLessIO(style, componentName) {
        const shortName = style.stylename;
        const fullpath = this.methods.getDsComponentStyleFilePath(componentName);
        const content = await this.methods.getContentFile(shortName, 'less', fullpath);
        return content;
    }
    async _setStyleLessIO(style, componentName, content) {
        const shortName = style.stylename;
        const fullpath = this.methods.getDsComponentStyleFilePath(componentName);
        if (content === null) {
            await this._removeComponentStyle(componentName, style.stylename);
            return true;
        }
        const lessTokens = await this.token.getTokensLess();
        const contentWithLessTokens = content + '\n' + lessTokens;
        await this.methods.setContentFile(shortName, 'less', fullpath, content);
        // await this.methods.setContentFileDsMain();
        return new Promise((resolve, reject) => {
            mls.l2.compileLess(contentWithLessTokens).then(async (res) => {
                this.methods.setFileError(shortName, fullpath, 'less', false);
                resolve(true);
            }).catch((err) => {
                this.methods.setFileError(shortName, fullpath, 'less', true);
                reject(new Error(err.message));
            });
        });
    }
}
