/// <mls shortName="collabStartL0" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
/// **collab_i18n_start**
const message_pt = {
    desc: 'Descrição',
    news: 'Novidades',
    inDevelopment: 'Em desenvolvimento...',
    details1: 'Sobre esse level',
    module1Title: 'Módulo L0 - User: Descrição e Funcionalidades',
    module1Text: 'O módulo L0 é voltado para o usuário geral da plataforma Collab.codes. Este módulo oferece uma visão geral dos projetos em que o usuário está envolvido, além de permitir a gestão de autoridades, escolha de planos e personalização visual da ferramenta.',
    module1List1: 'Visualizar e ver projetos: permite ao usuário uma visão geral e detalhada dos projetos em que está envolvido, facilitando o acompanhamento do progresso',
    module1List2: 'Dar autoridades a outros: oferece a opção de conceder diferentes níveis de autoridade a outros membros da equipe, como administrador, editor ou visualizador',
    module1List3: 'Escolher o plano atual: permite ao usuário selecionar o plano de assinatura mais adequado às suas necessidades e, se necessário, incluir informações de faturamento.',
    module1List4: 'Selecionar preferências visuais: oferece opções para personalizar a aparência da ferramenta, como temas, layout e configurações de exibição.',
    module2Title: 'Fluxo de Uso',
    module2List1: 'O usuário acessa o módulo L0 e tem uma visão geral dos projetos em que está envolvido.',
    module2List2: 'Se necessário, concede autoridades a outros membros da equipe para facilitar a colaboração.',
    module2List3: 'Escolhe o plano de assinatura que melhor atende às suas necessidades e inclui informações de faturamento, se aplicável..',
    module2List4: 'Personaliza a interface da ferramenta de acordo com suas preferências visuais para uma experiência de usuário mais agradável.',
    moduleExplain: 'O módulo L0 serve como um hub central para o usuário, permitindo uma gestão eficaz de projetos, equipes e preferências pessoais. É uma parte crucial para garantir que o usuário tenha controle e visibilidade sobre todos os aspectos relevantes da plataforma.',
};
const message_en = {
    desc: 'Description',
    news: 'News',
    inDevelopment: 'In development...',
    details1: 'About this level',
    module1Title: 'Module L0 - User: Description and Features',
    module1Text: 'The L0 module is designed for the general user of the Collab.codes platform. This module provides an overview of the projects the user is involved in, while enabling authority management, plan selection, and visual customization of the tool.',
    module1List1: 'View and monitor projects: allows the user to have an overview and detailed insight into the projects they are involved in, facilitating progress tracking.',
    module1List2: 'Grant authorities to others: offers the option to assign different levels of authority to other team members, such as administrator, editor, or viewer.',
    module1List3: 'Select the current plan: enables the user to choose the subscription plan that best suits their needs and, if necessary, include billing information.',
    module1List4: 'Choose visual preferences: provides options to customize the tool’s appearance, such as themes, layout, and display settings.',
    module2Title: 'Usage Flow',
    module2List1: 'The user accesses the L0 module and gets an overview of the projects they are involved in.',
    module2List2: 'If needed, grants authority to other team members to facilitate collaboration.',
    module2List3: 'Selects the subscription plan that best meets their needs and includes billing information, if applicable.',
    module2List4: 'Customizes the tool’s interface according to their visual preferences for a more pleasant user experience.',
    moduleExplain: 'The L0 module serves as a central hub for the user, enabling effective management of projects, teams, and personal preferences. It is a crucial part of ensuring that the user has control and visibility over all relevant aspects of the platform.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabStartL0100554 = class CollabStartL0100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-start-l0-100554{line-height:1.15;position:relative;height:100%;overflow:auto;font-family:'Cambria',serif;font-size:var(--font-size-16);font-weight:400}collab-start-l0-100554 details>summary{cursor:pointer;font-size:var(--font-size-20)}collab-start-l0-100554 .collab-codes-banner{margin-left:auto;margin-right:auto;display:block;width:100%;max-width:100%;position:relative}collab-start-l0-100554 .collab-codes-banner img{width:100% !important;height:auto !important}collab-start-l0-100554 .collab-codes-link{display:flex;justify-content:center;gap:2rem;padding:2rem}collab-start-l0-100554 .collab-codes-link button{cursor:pointer;background:none;border:none;text-decoration:underline;color:var(--active-color)}collab-start-l0-100554 .collab-codes-content{padding:0 .5rem;margin-left:auto;margin-right:auto;max-width:800px;justify-content:center}collab-start-l0-100554 .collab-codes-content details{margin-bottom:1rem}collab-start-l0-100554 .collab-codes-content details>div{padding-left:1.5rem}collab-start-l0-100554 .collab-codes-contents{justify-content:center}collab-start-l0-100554 .collab-codes-contents details{margin-bottom:1rem}collab-start-l0-100554 .collab-codes-contents details>div{padding-left:1.5rem}collab-start-l0-100554 .separator{padding-top:24px;padding-bottom:10px;margin-top:32px;margin-bottom:14px;display:flex;justify-content:center}collab-start-l0-100554 .separator>span{width:4px;height:4px;background-color:var(--text-primary-color);border-radius:50%;display:inline-block;margin-right:20px}collab-start-l0-100554 h1{line-height:52px;font-size:42px;font-weight:700;font-style:normal}collab-start-l0-100554 h2{line-height:30px;font-size:24px;font-weight:600;font-style:normal}collab-start-l0-100554 h1,collab-start-l0-100554 h2,collab-start-l0-100554 h3,collab-start-l0-100554 h4,collab-start-l0-100554 h5,collab-start-l0-100554 h6,collab-start-l0-100554 h7{letter-spacing:-0.011em}collab-start-l0-100554 ol>li,collab-start-l0-100554 ul>li{margin-top:1em}collab-start-l0-100554 span,collab-start-l0-100554 p,collab-start-l0-100554 li{line-height:32px;font-size:20px}collab-start-l0-100554 .collab_marca{position:absolute;bottom:10px;right:20px;opacity:.2}`);
        this.msg = messages['en'];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <section class="collab-codes-start">
            <div class="collab-codes-banner">
                <img id="serviceStartL0ImageBanner" src="./l3/_100529_/images/startl0.avif" height="250" width="800" alt="banner">
            </div>
            <div class="collab-codes-content">
                <details id="serviceStartL0DetailsAbout" open="open">
                    <summary>${this.msg.details1}</summary>
                    <div>
                        <h1>${this.msg.module1Title}</h1>
                        <div>
                            <h2>${this.msg.desc}</h2>
                            <span>${this.msg.module1Text}
                                <ol>
                                    <li>${this.msg.module1List1}</li>
                                    <li>${this.msg.module1List2}</li>
                                    <li>${this.msg.module1List3}</li>
                                    <li>${this.msg.module1List4}</li>
                                </ol>
                            </span>
                        </div>
                        <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module2Title}</h3>
                            <ol>
                                <li>${this.msg.module2List1}</li>
                                <li>${this.msg.module2List2}</li>
                                <li>${this.msg.module2List3}</li>
                                <li>${this.msg.module2List4}</li>
                            </ol>
                            <span>${this.msg.moduleExplain}</span>
                        </div>
                    </div>
                </details>
                <details id="serviceStartL0DetailsNews" open="open">
                    <summary>${this.msg.news}</summary>
                    <div>
                        <span>${this.msg.inDevelopment}</span>
                    </div>
                </details>
            </div>
        </section>
        <img class="collab_marca" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==" height="140" width="140" alt="collab codes">
         `;
    }
};
CollabStartL0100554 = __decorate([
    customElement('collab-start-l0-100554')
], CollabStartL0100554);
export { CollabStartL0100554 };
