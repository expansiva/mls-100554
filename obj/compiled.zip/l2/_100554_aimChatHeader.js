/// <mls shortName="aimChatHeader" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { propertyDataSource } from './_100554_collabDecorators';
import './_100554_aimChatHelper';
/// **collab_i18n_start** 
const message_pt = {
    titleRoom: 'Sala',
    titleMessage: 'Mensagem',
};
const message_en = {
    titleRoom: 'Room',
    titleMessage: 'Message',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let AimChatHeader100554 = class AimChatHeader100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aim-chat-header-100554{position:sticky;z-index:1000;top:0;display:block}aim-chat-header-100554 .title{color:#fff;background-image:linear-gradient(to right, #a077c5, #7764bf, #4A90E2);text-align:center;margin:0;height:30px;display:flex;align-items:center;justify-content:center}aim-chat-header-100554 .title.button-back{cursor:pointer;gap:.5em}`);
        this.msg = messages['en'];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        console.log('chat header render, activerrom', this.activeRoom);
        return html `
      <h4
        class="title ${this.activeRoom || this.activeMessage ? 'button-back' : ''}"
        @click=${() => this.handleHeaderClick()}>
        ${this.activeRoom || this.activeMessage
            ? html `<i class="fa">&#xf053;</i>`
            : ''}
        ${this.activeMessage
            ? `${this.msg.titleMessage}: ${this.activeMessage}`
            : this.activeRoom
                ? `${this.msg.titleRoom}: ${this.activeRoom}`
                : "Collab Chat " + this.activeFilterRooms}
      </h4>
    `;
    }
    handleHeaderClick() {
        if (this.activeMessage) {
            this.activeMessage = undefined;
        }
        else if (this.activeRoom) {
            this.activeRoom = undefined;
        }
    }
};
__decorate([
    propertyDataSource({ type: String, reflect: true })
], AimChatHeader100554.prototype, "activeRoom", void 0);
__decorate([
    propertyDataSource({ type: Number, reflect: true })
], AimChatHeader100554.prototype, "activeMessage", void 0);
__decorate([
    propertyDataSource({ type: String, reflect: true })
], AimChatHeader100554.prototype, "activeFilterRooms", void 0);
AimChatHeader100554 = __decorate([
    customElement('aim-chat-header-100554')
], AimChatHeader100554);
export { AimChatHeader100554 };
