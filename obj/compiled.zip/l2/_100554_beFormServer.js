/// <mls shortName="beFormServer" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { BECollabServer } from './_100554_beCollabServer';
import { BeUserRegistration } from './_100554_beUserRegistration';
export class FormServer {
    constructor() {
        this.server = new BECollabServer();
        this.userRegistration = new BeUserRegistration();
        this.setRoutes();
    }
    startServer() {
        return this.server.start('Server no ar');
    }
    //-----IMPLEMENTS------------
    setRoutes() {
        this.server.on('beUserRegistration', 'POST', async (body) => {
            return await this.userRegistration.onsubmit(body);
        });
        this.server.on('beUserRegistration', 'GET', async (body) => {
            return await this.userRegistration.onsubmit({ action: 'get' });
        });
    }
}
window.FormServer = FormServer;
