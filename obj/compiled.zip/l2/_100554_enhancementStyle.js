/// <mls shortName="enhancementStyle" project="100554" enhancement="_blank" groupName="other" />
import { convertFileNameToTag } from './_100554_utilsLit';
import { getCssWithoutTag } from './_100554_processCssLit';
import { preCompileLess as compileLess } from './_100554_designSystemBase';
export const requires = [];
export const onAfterChange = (models) => {
    const modelStyle = models.style;
    if (!modelStyle)
        return '';
    try {
        validateStyle(modelStyle);
        return '';
    }
    catch (e) {
        throw new Error(e);
    }
};
export const onAfterMarkersChange = (models) => {
    const modelStyle = models.style;
    if (!modelStyle)
        return '';
    try {
        verifyMarkersError(modelStyle);
        return '';
    }
    catch (e) {
        throw new Error(e);
    }
};
export const onAfterCompile = async (modelStyle) => {
    return;
};
export const getDesignDetails = (modelStyle) => {
    return new Promise((resolve, reject) => {
        try {
            const ret = {};
            resolve(ret);
        }
        catch (e) {
            reject(e);
        }
    });
};
export async function verifyMarkersError(modelStyle) {
    if (modelStyle && modelStyle.model) {
        const markers = monaco.editor.getModelMarkers({ resource: modelStyle.model.uri });
        const hasError = markers.some(marker => marker.severity === monaco.MarkerSeverity.Error);
        modelStyle.storFile.hasError = hasError;
    }
}
export async function validateStyle(modelStyle) {
    const model = modelStyle.model;
    const { project, shortName } = modelStyle.storFile;
    const keyToStorFileLess = mls.stor.getKeyToFiles(project, 2, shortName, '', '.less');
    const storFileLess = mls.stor.files[keyToStorFileLess];
    if (!model || !storFileLess)
        return;
    storFileLess.hasError = false;
    const formated = await formatTextInMemory(model);
    let text = removeTokensFromSource(formated);
    text = removeCommentLines(text);
    const markers = [];
    const fileName = `_${project}_${shortName}`;
    const tagName = convertFileNameToTag(fileName);
    const nav3MenuSelector = `collab-nav-3-service[data-service="${fileName}"]`;
    const rootSelectorRegex = /^[^\s].*?{/gm;
    const errors = [];
    let match;
    while ((match = rootSelectorRegex.exec(text)) !== null) {
        const selector = match[0].trim().replace(/\{$/, "").trim();
        const isValid = selector === nav3MenuSelector ||
            selector === tagName ||
            new RegExp(`^${tagName}\\.[a-zA-Z0-9_-]+$`).test(selector);
        if (!isValid) {
            const position = getLineSelectorByText(model, selector);
            if (position)
                markers.push(position);
            errors.push(`Invalid root selector: "${selector}"`);
        }
    }
    if (markers.length > 0)
        storFileLess.hasError = true;
    setErrorOnEditor(markers, model, tagName);
}
async function formatTextInMemory(model) {
    const tempModel = monaco.editor.createModel(model.getValue(), 'less');
    const tempEditor = monaco.editor.create(document.createElement("div"), {
        model: tempModel,
    });
    try {
        await tempEditor.getAction('editor.action.formatDocument')?.run();
        const formattedText = tempModel.getValue();
        return formattedText;
    }
    finally {
        tempEditor.dispose();
    }
}
function setErrorOnEditor(position, model, tag) {
    monaco.editor.setModelMarkers(model, 'markerSource', []);
    const markers = [];
    position.forEach((pos) => {
        const markerOptions = {
            severity: monaco.MarkerSeverity.Error,
            message: `Invalid selector, must starting with tag or tag.class ex: '${tag} {' or '${tag}.myclass {'`,
            startLineNumber: pos.lineNumber,
            startColumn: pos.column,
            endLineNumber: pos.lineNumber,
            endColumn: pos.column,
        };
        markers.push(markerOptions);
    });
    monaco.editor.setModelMarkers(model, 'markerSource', markers);
}
export function getLineByText(model, searchText) {
    const lineCount = model.getLineCount();
    for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
        const lineContent = model.getLineContent(lineNumber);
        if (lineContent.trim() === searchText) {
            return new monaco.Position(lineNumber, 1);
        }
    }
    return null;
}
export function getLineSelectorByText(model, searchText) {
    const lineCount = model.getLineCount();
    const s1 = searchText + '{';
    const s2 = s1.replace(/\s+/g, '');
    for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
        const lineContent = model.getLineContent(lineNumber);
        const ln = lineContent.replace(/\s+/g, '').trim();
        if (ln === s2) {
            return new monaco.Position(lineNumber, 1);
        }
    }
    return null;
}
export function removeTokensFromSource(src) {
    const regex = /\/\/Start Less Tokens[\s\S]*?\/\/End Less Tokens/g;
    return src.replace(regex, '');
}
export function removeCommentLines(text) {
    const lines = text.split('\n');
    const lineCount = lines.length - 1;
    const newLines = [];
    for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
        const lineContent = lines[lineNumber];
        if (!isCommentLine(lineContent)) {
            newLines.push(lineContent);
        }
    }
    const newContent = newLines.join('\n');
    return newContent;
}
export function getRootSelectors(lessContent) {
    const rootSelectors = [];
    const regex = /^([^\s{]+(?:\.[^\s{]+)*(?:\s+[^\s{]+)*)\s*\{/gm;
    let match;
    while ((match = regex.exec(lessContent)) !== null) {
        rootSelectors.push((match[1].trim().replace(/\n/g, ' ').replace(/}/g, '') + ' {').trim());
    }
    return rootSelectors;
}
export function isCommentLine(line) {
    if (!line)
        return false;
    if (line.trim().startsWith('//')) {
        return true;
    }
    return line.trim().startsWith('/*') && line.trim().endsWith('*/');
}
export async function compileStyleUsingMFile(modelStyle, theme = 'Default') {
    const model = modelStyle.model;
    const { project, shortName } = modelStyle.storFile;
    const keyToStorFileLess = mls.stor.getKeyToFiles(project, 2, shortName, '', '.less');
    const storFileLess = mls.stor.files[keyToStorFileLess];
    if (!model || !storFileLess)
        return;
    let val = model.getValue();
    val = removeTokensFromSource(val);
    val = removeCommentLines(val);
    try {
        return preCompileLess(project, val, theme, modelStyle);
    }
    catch (err) {
        throw new Error(err.message);
    }
}
export async function compileStyleUsingStorFile(shortName, project, theme = 'Default') {
    const keyToStorFileLess = mls.stor.getKeyToFiles(project, 2, shortName, '', '.less');
    const storFileLess = mls.stor.files[keyToStorFileLess];
    if (!storFileLess)
        return;
    let val = await storFileLess.getContent();
    if (!val || typeof val !== 'string')
        return '';
    val = removeTokensFromSource(val);
    val = removeCommentLines(val);
    try {
        return preCompileLess(project, val, theme);
    }
    catch (err) {
        throw new Error(err.message);
    }
}
async function preCompileLess(project, less, theme, modelStyle) {
    try {
        let newLess = await compileLess(project, less, theme);
        return newLess;
    }
    catch (e) {
        console.info(e);
        if (typeof e === 'string')
            errorCompileLess(e);
        else if (e && e.message)
            errorCompileLess(e.message);
        else
            errorCompileLess(`Error: invalid less`);
        if (modelStyle && modelStyle.storFile) {
            modelStyle.storFile.hasError = true;
        }
        return '';
    }
}
function errorCompileLess(err) {
    const model = mls.editor.instances[mls.editor.activeInstance].getModel();
    if (!model || model.getLanguageId() !== 'less')
        return;
    monaco.editor.setModelMarkers(model, 'markerSource', []);
    const markers = [];
    const markerOptions = {
        severity: monaco.MarkerSeverity.Error,
        message: err,
        startLineNumber: 0,
        startColumn: 0,
        endLineNumber: 0,
        endColumn: 50,
    };
    markers.push(markerOptions);
    monaco.editor.setModelMarkers(model, 'markerSource', markers);
}
export async function setStylesProcessed(newCss, el, tag) {
    const cssWithoutTag = getCssWithoutTag(newCss, tag);
    if (!el.shadowRoot)
        return;
    const stylesheet = createStyleSheet(cssWithoutTag, el.ownerDocument.defaultView);
    if (!stylesheet)
        return;
    el.shadowRoot.adoptedStyleSheets = [stylesheet];
    el.requestUpdate();
}
function createStyleSheet(cssString, defaultView) {
    const sheet = new defaultView.CSSStyleSheet();
    sheet.replaceSync(cssString);
    return sheet;
}
