/// <mls shortName="pluginStyleTextShadow" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    advanced: 'Avançado',
    xOffset: 'X Offset',
    yOffset: 'Y Offset',
    blur: 'Desfoque',
    color: 'Cor',
    gallery: 'Galeria',
};
const message_en = {
    advanced: 'Advanced',
    xOffset: 'X Offset',
    yOffset: 'Y Offset',
    blur: 'Blur',
    color: 'Color',
    gallery: 'Galeria',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['text-shadow'];
export const description = 'A comprehensive plugin for managing and customizing text-shadow properties. Effortlessly apply shadows with adjustable offsets, blur, and color options to enhance text appearance and readability.';
let PluginStyleTextShadow = class PluginStyleTextShadow extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-text-shadow-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-text-shadow-100554 .helper-group-title{margin:0;margin-top:var(--space-16);margin-bottom:var(--space-8);display:flex;gap:1.5rem}plugin-style-text-shadow-100554 details summary{cursor:pointer}plugin-style-text-shadow-100554 details>div{margin-left:var(--space-16)}plugin-style-text-shadow-100554 .group{margin-bottom:var(--space-8);display:flex;flex-direction:column;font-size:var(--font-size-12)}plugin-style-text-shadow-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-text-shadow-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-text-shadow-100554 .gallery{margin-bottom:var(--space-16);display:flex;justify-content:start;align-items:center;gap:1rem;padding-top:1rem;flex-wrap:wrap;cursor:pointer}`);
        this.showFull = 'false';
        this.msg = messages['en'];
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.arrayGallery = [
            '',
            'text-shadow: 2px 2px;',
            'text-shadow: 2px 2px 5px;',
            'text-shadow: 0 0 3px',
            'text-shadow: 3px 3px 3px;',
            'text-shadow: 3px -3px 3px;',
            'text-shadow: 1px 1px 2px #000;',
            'text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);',
            'text-shadow: -2px 2px 4px #333;',
            'text-shadow: 0 0 5px #f00;',
            'text-shadow: 4px 4px 6px rgba(50, 50, 50, 0.75);',
            'text-shadow: -3px -3px 4px #888;',
            'text-shadow: 5px 5px 10px #ff6347;',
            'text-shadow: 1px 2px 0 #000, 2px 3px 0 #ff0;',
            'text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);',
            'text-shadow: 2px 2px 8px #006400;',
            'text-shadow: 6px 6px 10px #0000ff;',
            'text-shadow: 0 0 2px #ccc, 2px 2px 4px #000;',
            'text-shadow: -1px -1px 3px #555;',
            'text-shadow: 2px 2px 5px rgba(100, 100, 100, 0.5);',
            'text-shadow: 0px 1px 1px #999, 0px 2px 2px #666;',
        ];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
             ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderColumn()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderColumn() {
        return html `
            <div>
                <div class="group">
                    <span>${this.msg.xOffset}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554 prop="x" value="0px" .arraySelect=${this.tpMeasures}  ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.yOffset}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554 prop="y" value="0px" .arraySelect=${this.tpMeasures}  ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.blur}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554 prop="blur" value="0px" .arraySelect=${this.tpMeasures}  ></collab-ds-input-range-100554>
                    </div>
                    
                    <span>${this.msg.color}</span>
                    <div class="group-edit">
                        <collab-ds-input-select-color-100554 prop="color" useInput="false" useSelect="false" ></collab-ds-input-select-color-100554>
                    </div>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `
                        <h5 style="${css}" .gallery=${css}>Text</h5>
                        `;
        }))}
            </div>
        
        `;
    }
};
__decorate([
    property()
], PluginStyleTextShadow.prototype, "showFull", void 0);
PluginStyleTextShadow = __decorate([
    customElement('plugin-style-text-shadow-100554')
], PluginStyleTextShadow);
export { PluginStyleTextShadow };
