/// <mls shortName="pluginStyleTextShadow" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['text-shadow'];
let PluginStyleTextShadow = class PluginStyleTextShadow extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    render() {
        return html `TextShadow helper`;
    }
};
PluginStyleTextShadow = __decorate([
    customElement('plugin-style-text-shadow-100554')
], PluginStyleTextShadow);
export { PluginStyleTextShadow };
