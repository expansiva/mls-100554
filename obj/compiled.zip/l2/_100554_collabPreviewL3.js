/// <mls shortName="collabPreviewL3" project="100554" enhancement="_100554_enhancementLit" groupName="other" folder="" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import './_100554_collabL3EditText';
let CollabPreviewL3 = class CollabPreviewL3 extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-preview-l3-100554{--id-name:' '}collab-preview-l3-100554 collab-selected-overlay:before{content:var(--id-name);width:max-content;height:max-content;padding:.1rem;background-color:rgba(0,183,255,0.22);position:absolute;top:-22px;left:0px}`);
        this.init();
    }
    //-------PUBLIC-----------
    setHover(el, active) {
        this._setHover(el, active);
    }
    selectElement(el) {
        this._selectElement(el);
    }
    //-----COMPONENT----------
    render() {
        return html ``;
    }
    //------FUNCTIONS---------
    init() {
        this.createOverlay();
        this.createOverlaySelected();
        this.addEdit();
    }
    createOverlay() {
        if (this.elOverlayHover && this.elOverlayHover.isConnected)
            return;
        const div = document.createElement("collab-aux-overlay");
        div.style.outlineOffset = '-2px';
        div.style.position = 'absolute';
        div.style.backgroundColor = 'rgb(0 183 255 / 22%)';
        div.style.zIndex = '99999';
        div.style.display = 'block';
        this.appendChild(div);
        this.elOverlayHover = div;
    }
    createOverlaySelected() {
        if (this.elOverlaySelected && this.elOverlaySelected.isConnected)
            return;
        const div = document.createElement("collab-selected-overlay");
        div.style.outlineOffset = '-2px';
        div.style.position = 'absolute';
        div.style.background = 'transparent';
        div.style.border = '1px solid rgb(0 183 255 / 22%)';
        div.style.zIndex = '-1';
        div.style.display = 'block';
        this.appendChild(div);
        this.elOverlaySelected = div;
    }
    _setHover(el, active) {
        if (!this.elOverlayHover)
            this.createOverlay();
        if (!this.elOverlayHover)
            return;
        if (!el) {
            if (!active) {
                this.elOverlayHover.style.display = 'none';
            }
            return;
        }
        if (el.hasAttribute('clb_mode')) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        if (!active) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        const rect = el.getBoundingClientRect();
        this.elOverlayHover.style.display = 'block';
        this.elOverlayHover.style.top = `${rect.top + window.scrollY}px`;
        this.elOverlayHover.style.left = `${rect.left + window.scrollX}px`;
        this.elOverlayHover.style.width = `${rect.width}px`;
        this.elOverlayHover.style.height = `${rect.height}px`;
    }
    _selectElement(el) {
        const els = this.querySelectorAll('*[clb_mode="edit"]');
        els.forEach((e) => e.removeAttribute('clb_mode'));
        if (!this.elOverlaySelected)
            this.createOverlaySelected();
        if (!this.elOverlaySelected)
            return;
        const rect = el.getBoundingClientRect();
        this.elOverlaySelected.style.display = 'block';
        this.elOverlaySelected.style.top = `${rect.top + window.scrollY - 2}px`;
        this.elOverlaySelected.style.left = `${rect.left + window.scrollX - 2}px`;
        this.elOverlaySelected.style.width = `${rect.width + 4}px`;
        this.elOverlaySelected.style.height = `${rect.height + 4}px`;
        this.elOverlaySelected.style.setProperty("--id-name", `'${el.id}'`);
        el.setAttribute('clb_mode', 'edit');
    }
    addEdit() {
    }
};
CollabPreviewL3 = __decorate([
    customElement('collab-preview-l3-100554')
], CollabPreviewL3);
export { CollabPreviewL3 };
