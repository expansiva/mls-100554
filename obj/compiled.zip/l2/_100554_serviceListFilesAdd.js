/// <mls shortName="serviceListFilesAdd" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { getAttributeDefinitionsLit, getFormComponentsDescription } from './_100554_icaBaseDescription';
export const initServiceListFilesAdd = () => {
};
/// **collab_i18n_start**
const message_pt = {
    labelProject: "Projeto",
    labelShortName: "Nome curto",
    labelType: "Por favor, selecione um modelo abaixo ou clique",
    btnAdd: "Adicionar",
    btnCancel: "Cancelar",
    please: "Por facor selecione um projeto primeiro!"
};
const message_en = {
    labelProject: "Project",
    labelShortName: "Shortname",
    labelType: "Please select a template below or click",
    btnAdd: "Add",
    btnCancel: "cancel",
    please: "Please select a project first!"
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceListFilesAdd100554 = class ServiceListFilesAdd100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.level = -1;
        this.error = '';
        this.position = '';
        this.templates = [];
        this.loading = true;
        this.enhancementModules = {};
    }
    async connectedCallback() {
        super.connectedCallback();
        await this.init();
    }
    async init() {
        await this.getTemplates();
        this.loading = false;
    }
    render() {
        const lang = this.father?.getMessageKey(messages);
        this.msg = lang ? messages[lang] : message_en;
        const { project } = mls.actual[5];
        return html `
            ${project ? this.renderAdd(project)
            : html `${this.msg.please}`}
        `;
    }
    renderAdd(project) {
        return html `
            <div class="section-add">
                <div class="row-form">
                    <div>
                        <label>${this.msg.labelProject}:</label>
                        <input type="text" disabled value="${project.toString()}"/>
                    </div>
                    <div>
                        <label>${this.msg.labelShortName}:</label>
                        <input type="text" id="iptShortName"/>
                        <span>${this.error}</span>
                    </div>
                </div>
                <hr>
                <div class="row-form">
                    <div>
                        <label>${this.msg.labelType}</label> <button class="btn-cancel" @click="${this.clickCancel}">${this.msg.btnCancel}</button>
                         ${this.renderTemplates()}
                    </div>
                </div>
            </div>

        `;
    }
    renderTemplates() {
        return html `
            <div class="template-container">
             ${this.loading
            ? html `<p>Loading...</p>`
            :
                this.templates.map((template) => {
                    return html `
                        <div  class="template-item" @click=${() => { this.add(template); }}>
                            <div class="template-item-content">
                                <div class="template-item-title">${template.title}</div>
                                <div class="template-item-body">
                                    ${template.description.split('\n').map((paragraph) => html `
                                        <p>${paragraph}</p>
                                    `)}
                                </div>
                                <div class="template-item-tags">
                                        Tags: ${template.tags.join(', ')}
                                </div>
                            </div>
                        </div>
                    `;
                })}
            </div>
        `;
    }
    //--------------- IMPLEMENTS----------------
    async getTemplates() {
        const temp = await this.getAllEnhacementsTemplates();
        this.templates = [...temp];
    }
    clickCancel() {
        if (!this.father)
            return;
        this.father.mode = 'list';
    }
    showLoader(loader) {
        if (!this.father)
            return;
        this.father.loading = loader;
    }
    async add(template) {
        try {
            if (!this.shadowRoot)
                return;
            if (!this.inputShortName)
                return;
            const { project } = mls.actual[5];
            if (!project)
                throw new Error('No project selected');
            if (!this.enhancementModules)
                throw new Error('No modules enhancement loaded');
            const name = this.inputShortName.value;
            const newName = this.getNewNameAndValid(project, name);
            const params = {};
            if (!template.enhancementKey)
                throw new Error('No enhancementKey in template');
            const fEnh = this.enhancementModules[template.enhancementKey];
            if (!fEnh) {
                this.showLoader(false);
                throw new Error('No enhancement founded');
            }
            ;
            this.showLoader(true);
            const ts = this.createContentNewFile(fEnh, template.example, name, project);
            params.action = 'new';
            params.level = +this.level;
            params.project = mls.actual[5].project;
            params.newProject = mls.actual[5].project;
            params.shortName = newName;
            params.newshortName = newName;
            params.folder = '';
            params.newfolder = '';
            params.newEnhancement = fEnh ? `_${fEnh.storFile.project}_${fEnh.storFile.shortName}` : '_blank';
            params.extension = '.ts';
            params.newTSSource = ts;
            mls.actual[this.level].setFullName('_' + params.project + '_' + params.shortName);
            mls.actual[this.level][this.position] = {
                project: params.project,
                shortName: params.shortName
            };
            await this.fireComunication(params);
            const posInv = this.position === 'left' ? 'right' : 'left';
            if (template.aimActionSuggest) {
                this.father?.openService('_100554_serviceAim', posInv, 2);
                const opInstance = this.father?.nav3Service?.getActiveInstance(posInv);
                if (opInstance) {
                    opInstance.setAttribute('actiontoopen', template.aimActionSuggest);
                }
            }
            this.showLoader(false);
            this.saveLocalHistory(params.project, params.shortName, params.extension, params.folder);
        }
        catch (e) {
            setTimeout(() => {
                this.showLoader(false);
                this.error = e.message;
            }, 200);
        }
    }
    createContentNewFile(enhecementModule, template, name, project) {
        let ret = '';
        const grp = 'other';
        let newExample = '';
        newExample = this.checkIfAsIcaAndCreateIfNeeded(name, project);
        if (!newExample) {
            newExample = template;
            newExample = this.changeTagName(newExample, convertFileNameToTag(`_${project}_${name}`));
            newExample = this.changeClassName(newExample, project, name);
            newExample = this.changeWidget(newExample, project, name);
        }
        ret = `/// <mls shortName="${name}" project="${project}" enhancement="_${enhecementModule.storFile.project}_${enhecementModule.storFile.shortName}" groupName="${grp}" />\n${newExample}\n`;
        return ret;
    }
    checkIfAsIcaAndCreateIfNeeded(name, project) {
        if (project !== 100554)
            return '';
        if (!name.startsWith('ica'))
            return '';
        if (!name.endsWith('Base'))
            return '';
        let parts = this.splitStringByUppercase(name.substring(0, name.length - 4));
        if (parts.length < 4)
            return '';
        parts = parts.map((part) => this.capitalizeFirstLetter(part));
        let ica, root, subgroup, finalgroup = '';
        ica = parts.shift();
        root = parts.shift();
        subgroup = parts.shift();
        finalgroup = parts.join(' ');
        const desc = getFormComponentsDescription(root, subgroup, finalgroup);
        if (!desc)
            return '';
        return this.createTemplateIca(root, subgroup, finalgroup);
    }
    splitStringByUppercase(str) {
        return str.split(/(?=[A-Z])/);
    }
    capitalizeFirstLetter(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
    createTemplateIca(root, subgroup, finalgroup) {
        const props = getAttributeDefinitionsLit(root, subgroup, finalgroup);
        const res = props.map(line => {
            let cleanedLine = line.replace(/@property\(\{.*\}\)\s*/, ''); // Remove "@property({...}) "
            cleanedLine = cleanedLine.replace(/=.+?;/, ';'); // Remove tudo após o "=" até o próximo ";"
            cleanedLine = 'abstract ' + cleanedLine;
            return cleanedLine;
        });
        const fg = finalgroup.replace(/\s/g, '');
        const className = `Ica${root}${subgroup}${fg}Base`;
        const extend = 'IcaLitElement';
        const extendFile = './_100554_icaLitElement';
        const interfaces = new Map();
        res.forEach((str, index) => {
            const matches = str.match(/abstract (\w+): ('.*?'(?: \| '.*?')*)/);
            if (matches && matches.length >= 3) {
                const propName = matches[1];
                const types = matches[2].match(/'[^']+'/g);
                if (types && types.length > 1) {
                    const interfaceName = `I${propName.charAt(0).toUpperCase() + propName.slice(1)}`;
                    interfaces.set(interfaceName, types);
                    res[index] = `abstract ${propName}: ${interfaceName} | undefined; // ${matches.input}`;
                }
            }
        });
        let interfaceString = '';
        interfaces.forEach((types, interfaceName) => {
            interfaceString += `export type ${interfaceName} = ${types.join(' | ')};\n`;
        });
        const temp = `
import { ${extend} } from '${extendFile}';

export abstract class ${className} extends ${extend} {
    
    ${res.join('\n\t')}

}

${[interfaceString].join('\n')}
`;
        return temp;
    }
    saveLocalHistory(project, shortName, extension, folder) {
        const info = localStorage.getItem('mlsInfoHistoryL' + this.level);
        const res = info ? JSON.parse(info) : [];
        let idx = -1;
        res.forEach((i, index) => {
            if (i.project !== project || i.shortName !== shortName)
                return;
            idx = index;
        });
        if (idx >= 0)
            res.splice(idx, 1);
        res.unshift({ project, shortName, extension, folder });
        if (res.length > 10)
            res.length = 10;
        localStorage.setItem('mlsInfoHistoryL' + this.level, JSON.stringify(res));
    }
    getNewNameAndValid(prj, name) {
        if (name === '' || !name || name === null)
            throw new Error('Invalid name ');
        const isValidName = this.isValidNewName({
            shortName: name,
            project: prj,
            level: +this.level,
            folder: '',
            extension: '.ts'
        });
        if (!isValidName)
            throw new Error('Invalid name ');
        return name;
    }
    isValidNewName(obj) {
        if (obj.shortName === '')
            return false;
        if (obj.shortName.length === 0 || obj.shortName.length > 255)
            return false;
        const invalidCharacters = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        if (invalidCharacters.test(obj.shortName))
            return false;
        const key = mls.stor.getKeyToFiles(obj.project, obj.level, obj.shortName, obj.folder, obj.extension);
        let find = false;
        const keys = Object.keys(mls.stor.files);
        for (const k of keys) {
            if (key.toLocaleLowerCase() === k.toLocaleLowerCase())
                find = true;
        }
        return !mls.stor.files[key] && !find;
    }
    changeClassName(source, project, shortname) {
        const newClassName = shortname.charAt(0).toUpperCase() + shortname.substring(1, shortname.length) + project.toString();
        const outputString = source.replace(/\[className\]/g, newClassName);
        return outputString;
    }
    changeWidget(source, project, shortname) {
        const newWidget = `_${project.toString()}_${shortname}`;
        const outputString = source.replace(/\[widgetName\]/g, newWidget);
        return outputString;
    }
    changeTagName(source, tagName) {
        const outputString = source.replace(/\[tagName\]/g, tagName);
        return outputString;
    }
    getEnhacementsDetails() {
        const array = [];
        const keys = Object.keys(mls.stor.files);
        keys.forEach((i) => {
            const f = mls.stor.files[i];
            if (f.level !== +this.level || !f.shortName.startsWith('enhancement') || f.extension !== '.ts')
                return;
            const opt = {
                key: `${f.project}_${f.shortName}`,
                value: i
            };
            array.push(opt);
        });
        mls.l2.enhancement.getEnhancementDetails;
        return [...array];
    }
    async getAllEnhacementsTemplates() {
        let templates = [];
        const enhancementDetails = this.getEnhacementsDetails();
        this.enhancementModules = await this.getEnhacementsInstancies(enhancementDetails);
        if (!this.enhancementModules)
            return templates;
        Object.entries(this.enhancementModules).map((entry) => {
            const [entryKey, entryValue] = entry;
            if (!(entryValue.instance.getAddNewFileDetails))
                return;
            const temp = entryValue.instance.getAddNewFileDetails();
            temp.forEach((t) => t.enhancementKey = entryKey);
            templates = [...templates, ...temp];
        });
        return templates;
    }
    tryAccessMFile(project, shortName, maxAttempts) {
        return new Promise((resolve, reject) => {
            let attempts = 0;
            const interval = setInterval(() => {
                const value = mls.l2.editor.get({ project, shortName });
                attempts++;
                if ((value && value.compilerResults && value.compilerResults.prodJS)) {
                    clearInterval(interval);
                    resolve(value);
                }
                if (attempts >= maxAttempts) {
                    clearInterval(interval);
                    reject(new Error('Max attempts reached without finding the variable.'));
                }
            }, 500);
        });
    }
    async delay() {
        await new Promise((resolve) => setTimeout(resolve, 30000));
    }
    async getEnhacementsInstancies(enhancementDetails) {
        const enhancementModules = {};
        for await (let details of enhancementDetails) {
            const { value, key } = details;
            const storFile = mls.stor.files[value];
            if (!storFile)
                return;
            const { project, shortName } = storFile;
            let mfile = mls.l2.editor.get({ project, shortName });
            if (!mfile) {
                this.loadMyMFiles();
                await this.delay();
                mfile = await this.tryAccessMFile(project, shortName, 20);
            }
            if (!mfile)
                continue;
            let enhancementModule = await mls.l2.enhancement.getEnhancementModule(mfile);
            if (!enhancementModule)
                continue;
            enhancementModules[key] = {
                instance: enhancementModule,
                storFile: storFile
            };
        }
        return enhancementModules;
    }
    async fireComunication(obj) {
        obj.position = this.position;
        await mls.events.fire([+this.level], ['FileAction'], JSON.stringify(obj), 0);
    }
    async loadMyMFiles() {
        await mls.events.fire([2], 'ProjectLoaded', JSON.stringify({
            project: 100554,
            level: 2,
            needCompile: true
        }), 0);
    }
};
ServiceListFilesAdd100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "level", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "error", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "position", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "father", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "templates", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceListFilesAdd100554.prototype, "loading", void 0);
__decorate([
    query('#iptShortName')
], ServiceListFilesAdd100554.prototype, "inputShortName", void 0);
ServiceListFilesAdd100554 = __decorate([
    customElement('service-list-files-add-100554')
], ServiceListFilesAdd100554);
export { ServiceListFilesAdd100554 };
