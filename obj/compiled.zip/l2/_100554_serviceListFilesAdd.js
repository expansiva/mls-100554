/// <mls shortName="serviceListFilesAdd" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { CollabLitElement } from './_100554_collabLitElement';
import { propertyDataSource } from './_100554_collabDecorators';
import { setState, initState } from './_100554_collabState';
import { loadPluginProject } from './_100554_libCommom';
/// **collab_i18n_start**
const message_pt = {
    labelProject: "Projeto",
    labelShortName: "Nome",
    invalidName: "Nome invalido",
    labelType: "Por favor, selecione um modelo abaixo ou clique",
    btnAdd: "Adicionar",
    btnCancel: "Cancelar",
    please: "Por facor selecione um projeto primeiro!",
    msgInitial: "Por favor, selecione um modelo",
};
const message_en = {
    labelProject: "Project",
    labelShortName: "Shortname",
    invalidName: "Invalid shortName",
    labelType: "Please select a template below or click",
    btnAdd: "Add",
    btnCancel: "cancel",
    please: "Please select a project first!",
    msgInitial: "Please select a template",
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceListFilesAdd100554 = class ServiceListFilesAdd100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-list-files-add-100554{overflow-y:auto;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}service-list-files-add-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}service-list-files-add-100554 button:hover{background-color:var(--grey-color-light)}service-list-files-add-100554 input,service-list-files-add-100554 select,service-list-files-add-100554 textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}service-list-files-add-100554 .section-add{padding:0 1rem}service-list-files-add-100554 .row-form{display:flex;gap:.5rem}service-list-files-add-100554 .row-form button{display:inline-block;width:80px;height:25px;padding:0;text-align:center}service-list-files-add-100554 .row-form span{color:var(--error-color);width:100px;top:-5px;font-size:12px}service-list-files-add-100554 .row-form .btn-cancel:hover{color:var(--error-color)}service-list-files-add-100554 .template-container{display:flex;flex-wrap:wrap;justify-content:space-around;margin:auto;margin-top:1rem}service-list-files-add-100554 .template-container:hover .template-item:not(:hover){opacity:.5}service-list-files-add-100554 .template-container .template-item{flex:1 1 500px;margin:10px;box-shadow:0 4px 8px 0 rgba(0,0,0,0.2);transition:.3s;cursor:pointer}service-list-files-add-100554 .template-container .template-item:hover{background-color:var(--grey-color-light)}service-list-files-add-100554 .template-container .template-item .template-item-content{padding:20px}service-list-files-add-100554 .template-container .template-item .template-item-content .template-item-title{font-weight:bold;font-size:var(--font-size-24)}service-list-files-add-100554 .template-container .template-item .template-item-content .template-item-body{text-align:justify;font-size:var(--font-size-16)}service-list-files-add-100554 .template-container .template-item .template-item-content .template-item-tags{font-size:var(--font-size-12);text-transform:uppercase;font-weight:bold}service-list-files-add-100554 input,service-list-files-add-100554 select,service-list-files-add-100554 textarea{outline:none}`);
        this.baseProject = 100554;
        this.msg = messages['en'];
        this.level = -1;
        this.error = '';
        this.position = '';
        this.plugins = [];
        this.loading = true;
    }
    async connectedCallback() {
        super.connectedCallback();
        initState('l2.addFile', { shortName: '', project: 0, folder: '' });
        setState('l2.addFile.shortName', '');
        setState('l2.addFile.folder', '');
        await this.init();
    }
    async init() {
        const plugins = await this.getPlugins();
        this.plugins = await this.getPluginsInfo(plugins);
        this.loading = false;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        const options = {
            shortName: '',
            project: '',
            htmlText: `<div>${this.msg.msgInitial}</div>`
        };
        mls.events.fire(2, 'PluginDetails', JSON.stringify(options), 0);
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.father?.getMessageKey(messages);
        this.msg = lang ? messages[lang] : message_en;
        const project = mls.actualProject || 0;
        setState('l2.addFile.project', project);
        return html `
            ${project !== undefined ? this.renderAdd(project)
            : html `${this.msg.please}`}
        `;
    }
    renderAdd(project) {
        return html `
            <div class="section-add">
                <div class="row-form">
                    <div>
                        <label>${this.msg.labelProject}:</label>
                        <input type="text" disabled value="${project.toString()}"/>
                    </div>
                    <div>
                        <label>${this.msg.labelShortName}:</label>
                        <input value=${this.shortName} type="text" id="iptShortName" @input=${this.handleInputInput}/>
                        <span>${this.error}</span>
                    </div>
                </div>
                <hr>
                <div class="row-form">
                    <div>
                        <label>${this.msg.labelType}</label> <button class="btn-cancel" @click="${this.clickCancel}">${this.msg.btnCancel}</button>
                         ${this.renderTemplates()}
                    </div>
                </div>
            </div>

        `;
    }
    renderTemplates() {
        return html `
            <div class="template-container">
             ${this.loading
            ? html `<p>Loading...</p>`
            :
                this.plugins.map((template) => {
                    return html `
                        <div  class="template-item" @click=${() => { this.handleClickTemplate(template); }}>
                            <div class="template-item-content">
                                <div class="template-item-title">${template.title}</div>
                                <div class="template-item-body">
                                    ${template.description.split('\n').map((paragraph) => html `
                                        <p>${paragraph}</p>
                                    `)}
                                </div>
                                <div class="template-item-tags">
                                        Tags: ${template.tags.join(', ')}
                                </div>
                            </div>
                        </div>
                    `;
                })}
            </div>
        `;
    }
    handleInputInput(e) {
        const target = e.target;
        if (!target)
            return;
        const project = mls.actualProject;
        if (project === undefined)
            throw new Error('No project selected');
        const name = this.inputShortName?.value || '';
        this.error = '';
        const isValidName = this.getNewNameAndValid(project, name);
        if (!isValidName) {
            this.error = this.msg.invalidName;
            return;
        }
        const info = mls.l2.getPath(`_${project}_${target.value}`);
        setState('l2.addFile.folder', info.folder);
        setState('l2.addFile.shortName', info.shortName);
    }
    handleClickTemplate(plugin) {
        const { project, shortName, folder } = mls.l2.getPath(plugin.widget);
        const tag = convertFileNameToTag({ project, shortName, folder });
        const options = {
            shortName,
            project,
            folder,
            htmlText: `<${tag} position=${this.position} project="{{ l2.addFile.project }}" shortName="{{ l2.addFile.shortName }}" folder="{{ l2.addFile.folder }}"></${tag}>`
        };
        mls.events.fire(2, 'PluginDetails', JSON.stringify(options), 0);
    }
    //--------------- IMPLEMENTS----------------
    clickCancel() {
        if (!this.father)
            return;
        const options = {
            shortName: '',
            project: '',
            htmlText: `<div></div>`
        };
        mls.events.fire(2, 'PluginDetails', JSON.stringify(options), 0);
        this.father.mode = 'list';
    }
    getNewNameAndValid(prj, name) {
        if (name === '' || !name || name === null)
            return false;
        const split = name.split('/');
        const isValidName = this.isValidNewName({
            shortName: split.pop() || name,
            project: prj,
            level: +this.level,
            folder: split.length > 0 ? split.join('/') : '',
            extension: '.ts'
        });
        if (!isValidName)
            return false;
        return true;
    }
    isValidNewName(obj) {
        if (obj.shortName === '')
            return false;
        if (obj.shortName.length === 0 || obj.shortName.length > 255)
            return false;
        const invalidCharacters = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        if (invalidCharacters.test(obj.shortName))
            return false;
        const key = mls.stor.getKeyToFiles(obj.project, obj.level, obj.shortName, obj.folder, obj.extension);
        let find = false;
        const keys = Object.keys(mls.stor.files);
        for (const k of keys) {
            if (key.toLocaleLowerCase() === k.toLocaleLowerCase())
                find = true;
        }
        return !mls.stor.files[key] && !find;
    }
    async getPlugins() {
        let project = mls.actualProject;
        return await loadPluginProject(project || 0, 'l2NewFile');
    }
    async getPluginsInfo(plugins) {
        const rc = [];
        for await (const plugin of plugins) {
            const instance = await import(`./${plugin.widget}`);
            if (!instance.details ||
                typeof instance.details !== 'object' ||
                !['title', 'description', 'tags'].every(prop => prop in instance.details))
                continue;
            const details = instance.details;
            const item = {
                ...details,
                widget: plugin.widget,
                category: plugin.category,
            };
            rc.push(item);
        }
        return rc;
    }
};
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "level", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "error", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "position", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "father", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "plugins", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceListFilesAdd100554.prototype, "loading", void 0);
__decorate([
    propertyDataSource()
], ServiceListFilesAdd100554.prototype, "shortName", void 0);
__decorate([
    query('#iptShortName')
], ServiceListFilesAdd100554.prototype, "inputShortName", void 0);
ServiceListFilesAdd100554 = __decorate([
    customElement('service-list-files-add-100554')
], ServiceListFilesAdd100554);
export { ServiceListFilesAdd100554 };
