/// <mls shortName="wcAccordionDetails" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let WcAccordionDetails100554 = class WcAccordionDetails100554 extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-accordion-details-100554 details>div{margin-left:2rem}`);
        this.text = '';
        this.open = false;
    }
    render() {
        return html `
        <details .open="${this.open}">
            <summary>${this.text || ''}</summary>
            <div>
                <slot></slot>
            </div>
        </details>
       `;
    }
};
__decorate([
    property({ type: String })
], WcAccordionDetails100554.prototype, "text", void 0);
__decorate([
    property({ type: Boolean })
], WcAccordionDetails100554.prototype, "open", void 0);
WcAccordionDetails100554 = __decorate([
    customElement('wc-accordion-details-100554')
], WcAccordionDetails100554);
export { WcAccordionDetails100554 };
