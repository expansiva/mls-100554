/// <mls shortName="collabMessagesPrompt" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_arrow_up_long } from './_100554_collabIcons';
import './_100554_collabMessagesAvatar';
let CollabMessagesPrompt100554 = class CollabMessagesPrompt100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-prompt-100554{display:block;font-family:'Charlie Display',-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;font-size:calc(.25rem * 4);font-weight:400;line-height:1.5}collab-messages-prompt-100554 .wrapper{position:relative;display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-top-left-radius:12px;border-top-right-radius:12px;height:100px}collab-messages-prompt-100554 .wrapper textarea{padding:10px 15px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none}collab-messages-prompt-100554 .wrapper button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease}collab-messages-prompt-100554 .wrapper button:disabled{background-color:#e0e0e0;cursor:not-allowed}collab-messages-prompt-100554 .mention-suggestions{position:absolute;bottom:53%;left:5%;right:0;background-color:#fff;border:1px solid #ccc;z-index:10;display:block;width:200px;border-radius:10px;padding:0;margin:0;list-style:none;font-size:calc(.25rem * 3)}collab-messages-prompt-100554 .mention-suggestions li{color:#000000;display:flex;padding:5px 10px;cursor:pointer}collab-messages-prompt-100554 .mention-suggestions li collab-messages-avatar-100554{width:30px}collab-messages-prompt-100554 .mention-suggestions li:first-child{border-top-left-radius:10px;border-top-right-radius:10px}collab-messages-prompt-100554 .mention-suggestions li:last-child{border-bottom-left-radius:10px;border-bottom-right-radius:10px}collab-messages-prompt-100554 .mention-suggestions li.active{background-color:#eee}collab-messages-prompt-100554 .mention{color:#1890FF;font-weight:bold}collab-messages-prompt-100554 .special-mention{color:#0a6dc9;font-weight:bold}collab-messages-prompt-100554 .formatted-text{white-space:pre-wrap;word-wrap:break-word;position:absolute;top:0;left:0;pointer-events:none;z-index:-1;font-family:'Arial',sans-serif;padding:8px;min-height:40px;width:100%}`);
        this.isSending = false;
        this.text = '';
        this.mentionActive = false;
        this.mentionQuery = '';
        this.mentionSuggestions = [];
        this.mentionIndex = 0;
        this.allUsers = [];
    }
    render() {
        return html `
        </div> 
            <div class="wrapper">
                <textarea
                    .value=${this.text}
                    @input=${this.handleInput}
                    @keydown=${this.handleKeyDown}
                    id="prompt_input"
                    ?readonly=${this.isSending}
                    placeholder="Digite aqui... (@ para menções)">
                </textarea>
                <button 
                    @click=${this.handleSend} 
                    ?disabled=${this.isSending}
                    >
                    ${this.isSending ? html `<span class="loader"></span>` : collab_arrow_up_long}
                </button>
        
            ${this.mentionActive && this.mentionSuggestions.length > 0 ? html `
            <ul class="mention-suggestions">
                ${this.mentionSuggestions.map((s, i) => html `
                    <li 
                        class="${i === this.mentionIndex ? 'active' : ''}"
                        @click=${() => this.selectMention(s.name)}
                    >
                        ${s.avatar_url ? html `<collab-messages-avatar-100554 width="20px" height="20px" avatar=${s.avatar_url}></collab-messages-avatar-100554>` : ''}
                        ${s.name}
                    </li>
                `)}
            </ul>
        ` : ''}

        </div>`;
    }
    handleInput(e) {
        if (!e.target)
            return;
        const target = e.target;
        const value = target.value;
        this.text = value;
        const cursorPos = target.selectionStart;
        const beforeCursor = value.slice(0, cursorPos);
        const match = beforeCursor.match(/(?:^|\s)(@{1,2})([a-zA-Z]*)$/);
        if (match) {
            const atSymbol = match[1];
            const query = match[2];
            if (atSymbol === '@@') {
                this.mentionActive = false;
                this.mentionQuery = '';
                this.mentionSuggestions = [];
            }
            else {
                this.mentionActive = true;
                this.mentionQuery = query;
                this.mentionSuggestions = this.allUsers.filter(user => user.name.toLowerCase().startsWith(query.toLowerCase()));
            }
        }
        else {
            this.mentionActive = false;
            this.mentionSuggestions = [];
        }
    }
    handleKeyDown(e) {
        if (e.key === "Enter" && !e.shiftKey && !this.isSending) {
            e.preventDefault();
            this.handleSend();
        }
        if (this.mentionActive) {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.mentionIndex = (this.mentionIndex + 1) % this.mentionSuggestions.length;
            }
            else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.mentionIndex =
                    (this.mentionIndex - 1 + this.mentionSuggestions.length) % this.mentionSuggestions.length;
            }
            else if (e.key === 'Tab') {
                e.preventDefault();
                this.selectMention(this.mentionSuggestions[this.mentionIndex].name);
            }
            else if (e.key === 'Enter') {
                if (this.mentionSuggestions.length > 0) {
                    e.preventDefault();
                    this.selectMention(this.mentionSuggestions[this.mentionIndex].name);
                }
            }
        }
    }
    selectMention(suggestion) {
        if (!this.textArea)
            return;
        const cursorPos = this.textArea.selectionStart;
        const beforeCursor = this.text.slice(0, cursorPos);
        const afterCursor = this.text.slice(cursorPos);
        const newText = beforeCursor.replace(/@{1,2}[a-zA-Z]*$/, `@${suggestion} `) + afterCursor;
        this.text = newText;
        this.mentionActive = false;
        this.mentionSuggestions = [];
        this.mentionQuery = '';
        this.mentionIndex = 0;
        setTimeout(() => {
            if (!this.textArea)
                return;
            const newCursorPos = beforeCursor.replace(/@{1,2}[a-zA-Z]*$/, `@${suggestion} `).length;
            this.textArea.selectionStart = this.textArea.selectionEnd = newCursorPos;
            this.textArea.focus();
        });
    }
    async handleSend() {
        if (this.isSending || !this.text)
            return;
        this.isSending = true;
        let finalText = this.text.trim();
        let isSpecialMention = false;
        if (finalText.startsWith('@@')) {
            isSpecialMention = true;
        }
        if (this.onSend && typeof this.onSend === 'function') {
            try {
                await this.onSend(finalText.trim(), { isSpecialMention });
            }
            catch (err) {
                this.isSending = false;
            }
        }
        this.text = '';
        this.isSending = false;
    }
};
__decorate([
    property()
], CollabMessagesPrompt100554.prototype, "isSending", void 0);
__decorate([
    property({ type: Function })
], CollabMessagesPrompt100554.prototype, "onSend", void 0);
__decorate([
    query('textarea')
], CollabMessagesPrompt100554.prototype, "textArea", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "text", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionActive", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionQuery", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionSuggestions", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionIndex", void 0);
__decorate([
    property()
], CollabMessagesPrompt100554.prototype, "allUsers", void 0);
CollabMessagesPrompt100554 = __decorate([
    customElement('collab-messages-prompt-100554')
], CollabMessagesPrompt100554);
export { CollabMessagesPrompt100554 };
