/// <mls shortName="collabMessagesPrompt" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { collab_arrow_up_long } from './_100554_collabIcons';
import { getThread, listUsers } from './_100554_msgDBController';
import './_100554_collabMessagesAvatar';
let CollabMessagesPrompt100554 = class CollabMessagesPrompt100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-prompt-100554{display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5}collab-messages-prompt-100554 .wrapper{display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px 4px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-top-left-radius:12px;border-top-right-radius:12px}collab-messages-prompt-100554 .wrapper textarea{padding:4px 4px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none;overflow-y:auto;resize:none;max-height:200px;min-height:40px;line-height:1.2}collab-messages-prompt-100554 .wrapper button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease}collab-messages-prompt-100554 .wrapper button:disabled{background-color:#e0e0e0;cursor:not-allowed}collab-messages-prompt-100554 .mention-suggestions{position:absolute;left:5%;right:0;background-color:#fff;border:1px solid #ccc;z-index:10;display:block;width:200px;border-radius:10px;padding:0;margin:0;list-style:none;font-size:var(--font-size-12)}collab-messages-prompt-100554 .mention-suggestions li{color:#000000;display:flex;padding:5px 10px;cursor:pointer}collab-messages-prompt-100554 .mention-suggestions li collab-messages-avatar-100554{width:30px}collab-messages-prompt-100554 .mention-suggestions li:first-child{border-top-left-radius:10px;border-top-right-radius:10px}collab-messages-prompt-100554 .mention-suggestions li:last-child{border-bottom-left-radius:10px;border-bottom-right-radius:10px}collab-messages-prompt-100554 .mention-suggestions li.active{background-color:#eee}collab-messages-prompt-100554 .mention{color:var(--active-color);font-weight:bold}collab-messages-prompt-100554 .special-mention{color:var(--info-color);font-weight:bold}collab-messages-prompt-100554 .formatted-text{white-space:pre-wrap;word-wrap:break-word;position:absolute;top:0;left:0;pointer-events:none;z-index:-1;font-family:'Arial',sans-serif;padding:8px;min-height:40px;width:100%}`);
        this.text = '';
        this.mentionActive = false;
        this.mentionQuery = '';
        this.mentionSuggestions = [];
        this.mentionIndex = 0;
        this.allUsers = [];
        this.allAgents = [];
        this.alreadyLoadingAgents = false;
        this.acceptAutoCompleteUser = false;
        this.acceptAutoCompleteAgents = false;
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.adjustTextAreaHeight();
        // if (this.acceptAutoCompleteAgents && !this.scope) this.getAgents();
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('threadId')
            && this.threadId !== ''
            && this.threadId !== changedProperties.get('threadId')
            && this.acceptAutoCompleteUser) {
            this.getUsers();
        }
    }
    async getUsers() {
        if (!this.threadId)
            return;
        const thread = await getThread(this.threadId.trim());
        if (!thread)
            return;
        const users = await listUsers();
        const threadUsers = [];
        thread.users.forEach((user) => {
            const userDB = users.find((us) => us.userId === user.userId);
            if (userDB)
                threadUsers.push(userDB);
        });
        this.allUsers = threadUsers;
    }
    async getAgents() {
        const agentsFiles = await this.getAgentsFiles();
        const agentsPublic = agentsFiles.map((agent) => {
            const { visibility, agentName, avatar_url, agentDescription, scope } = agent;
            if (visibility === 'public') {
                let inScope = this.scope ? false : true;
                if (this.scope && scope) {
                    inScope = scope.includes(this.scope);
                }
                if (!this.scope && scope)
                    inScope = false;
                if (inScope) {
                    return {
                        name: agentName,
                        description: agentDescription,
                        avatar_url,
                        alias: agentName.replace('agent', '')
                    };
                }
            }
        }).filter((item) => !!item);
        this.allAgents = agentsPublic;
    }
    calculatePosition() {
        if (!this.mentionSuggestionsElement || !this.wrapper)
            return;
        const bound1 = this.wrapper.getBoundingClientRect();
        const bound2 = this.mentionSuggestionsElement.getBoundingClientRect();
        let calc = 0;
        if (bound1.top < bound1.height) {
            calc = bound1.top;
        }
        else {
            calc = bound1.top - bound1.height - bound2.height;
        }
        this.mentionSuggestionsElement.style.top = `${calc}px`;
    }
    adjustTextAreaHeight() {
        const maxHeight = 200;
        const minHeight = 40;
        if (this.textArea) {
            const prevHeight = this.textArea.offsetHeight;
            if (this.text === '') {
                this.textArea.style.height = `${minHeight}px`;
            }
            else {
                this.textArea.style.height = 'auto';
                this.textArea.style.height = Math.min(this.textArea.scrollHeight, maxHeight) + 'px';
            }
            const newHeight = this.textArea.offsetHeight;
            if (newHeight !== prevHeight) {
                this.dispatchEvent(new CustomEvent('textarea-resize', {
                    detail: {
                        height: newHeight
                    },
                    bubbles: true,
                    composed: true
                }));
            }
        }
    }
    async getAgentsFiles() {
        const keys = Object.keys(mls.stor.files);
        const ret = [];
        for await (const k of keys) {
            if (k.indexOf('agent') < 0)
                continue;
            const file = mls.stor.files[k];
            const path = `./_${file.project}_${file.shortName}`;
            if (file.extension !== '.ts' || !file.shortName.startsWith('agent'))
                continue;
            try {
                const mdl = await import(path);
                if (!mdl.createAgent)
                    continue;
                const agent = mdl.createAgent();
                ret.push(agent);
            }
            catch (err) {
                continue;
            }
        }
        return ret;
    }
    render() {
        return html `
    </div>
    <div class="wrapper">
        <textarea
            .value=${this.text}
            @input=${this.handleInput}
            @focus=${this.handleFocus}
            @keydown=${this.handleKeyDown}
            id="prompt_input"
            placeholder="Digite aqui... (@ para menções) (@@ para agentes)">
        </textarea>
        <button
            @click=${this.handleSend}
        >
            ${collab_arrow_up_long}
        </button>
        ${this.mentionActive && this.mentionSuggestions.length > 0 ? html `
            <ul class="mention-suggestions">
                ${this.mentionSuggestions.map((s, i) => html `
                    <li
                        class="${i === this.mentionIndex ? 'active' : ''}"
                        title=${s.description}
                        @click=${() => this.selectMention(s)}
                    >
                        ${s.avatar_url ? html `<collab-messages-avatar-100554 width="20px" height="20px" avatar=${s.avatar_url}></collab-messages-avatar-100554>` : ''}
                        ${s.text}
                    </li>
                `)}
            </ul>
        ` : ''}
    </div>`;
    }
    async handleFocus() {
        if (this.acceptAutoCompleteAgents &&
            (!this.alreadyLoadingAgents || this.scope !== this.lastScopeLoaded)) {
            this.lastScopeLoaded = this.scope;
            this.alreadyLoadingAgents = true;
            this.getAgents();
        }
    }
    async handleInput(e) {
        if (!e.target)
            return;
        const target = e.target;
        const value = target.value;
        this.text = value;
        this.adjustTextAreaHeight();
        const cursorPos = target.selectionStart;
        const beforeCursor = value.slice(0, cursorPos);
        const match = beforeCursor.match(/(?:^|\s)(@{1,2})([a-zA-Z]*)$/);
        if (match) {
            const atSymbol = match[1];
            const query = match[2];
            if (atSymbol === '@@' && this.acceptAutoCompleteAgents) {
                this.mentionActive = true;
                this.mentionQuery = query;
                this.mentionSuggestions = (this.allAgents.map(agent => {
                    if (agent.name.toLowerCase().startsWith(query.toLowerCase()) || agent.alias.toLowerCase().startsWith(query.toLowerCase()))
                        return {
                            text: agent.alias,
                            value: agent.name,
                            description: agent.description,
                            avatar_url: agent.avatar_url,
                            type: 'agent'
                        };
                }).filter((item) => item !== undefined));
                await this.updateComplete;
                this.calculatePosition();
            }
            else if (atSymbol === '@' && this.acceptAutoCompleteUser) {
                this.mentionActive = true;
                this.mentionQuery = query;
                this.mentionSuggestions = (this.allUsers.map(user => {
                    if (user.name.toLowerCase().startsWith(query.toLowerCase()))
                        return {
                            avatar_url: user.avatar_url,
                            text: user.name,
                            value: user.name,
                            description: user.name,
                            type: 'user'
                        };
                }).filter((item) => item !== undefined));
                await this.updateComplete;
                this.calculatePosition();
            }
            else {
                this.mentionActive = false;
                this.mentionSuggestions = [];
                this.mentionQuery = '';
            }
        }
        else {
            this.mentionActive = false;
            this.mentionSuggestions = [];
            this.mentionQuery = '';
        }
    }
    async handleKeyDown(e) {
        if (e.key === "Enter" && e.ctrlKey && !e.shiftKey) {
            e.preventDefault();
            await this.handleSend();
            return;
        }
        if (this.mentionActive) {
            const mention = this.mentionSuggestions[this.mentionIndex];
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.mentionIndex = (this.mentionIndex + 1) % this.mentionSuggestions.length;
            }
            else if (e.key === 'ArrowUp') {
                e.preventDefault();
                this.mentionIndex =
                    (this.mentionIndex - 1 + this.mentionSuggestions.length) % this.mentionSuggestions.length;
            }
            else if (e.key === 'Tab') {
                e.preventDefault();
                this.selectMention(mention);
            }
            else if (e.key === 'Enter') {
                if (this.mentionSuggestions.length > 0) {
                    e.preventDefault();
                    this.selectMention(mention);
                }
            }
        }
    }
    selectMention(suggestion) {
        if (!this.textArea)
            return;
        const cursorPos = this.textArea.selectionStart;
        const beforeCursor = this.text.slice(0, cursorPos);
        const afterCursor = this.text.slice(cursorPos);
        const prefix = suggestion.type === 'agent' ? '@@' : '@';
        const newText = beforeCursor.replace(/@{1,2}[a-zA-Z]*$/, `${prefix}${suggestion.text} `) + afterCursor;
        this.text = newText;
        this.mentionActive = false;
        this.mentionSuggestions = [];
        this.mentionQuery = '';
        this.mentionIndex = 0;
        this.actualMention = suggestion;
        setTimeout(() => {
            if (!this.textArea)
                return;
            const newCursorPos = beforeCursor.replace(/@{1,2}[a-zA-Z]*$/, `${prefix}${suggestion.text} `).length;
            this.textArea.selectionStart = this.textArea.selectionEnd = newCursorPos;
            this.textArea.focus();
        });
    }
    extractAgentName(text) {
        const match = text.match(/@@(\w+)/);
        if (!match)
            return undefined;
        let value = match[1];
        if (!value.startsWith('agent')) {
            const capitalized = value.charAt(0).toUpperCase() + value.slice(1);
            value = 'agent' + capitalized;
        }
        return value;
    }
    async handleSend() {
        if (!this.text)
            return;
        let finalText = this.text.trim();
        let isSpecialMention = false;
        let agentName;
        if (finalText.startsWith('@@')) {
            isSpecialMention = true;
            agentName = this.extractAgentName(finalText.trim());
        }
        if (this.onSend && typeof this.onSend === 'function') {
            this.onSend(finalText.trim(), { isSpecialMention, agentName });
        }
        this.text = '';
        this.adjustTextAreaHeight();
    }
};
__decorate([
    query('textarea')
], CollabMessagesPrompt100554.prototype, "textArea", void 0);
__decorate([
    query('.mention-suggestions')
], CollabMessagesPrompt100554.prototype, "mentionSuggestionsElement", void 0);
__decorate([
    query('.wrapper')
], CollabMessagesPrompt100554.prototype, "wrapper", void 0);
__decorate([
    property()
], CollabMessagesPrompt100554.prototype, "text", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "actualMention", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionActive", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionQuery", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionSuggestions", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "mentionIndex", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "allUsers", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "allAgents", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "alreadyLoadingAgents", void 0);
__decorate([
    state()
], CollabMessagesPrompt100554.prototype, "lastScopeLoaded", void 0);
__decorate([
    property({ type: Function })
], CollabMessagesPrompt100554.prototype, "onSend", void 0);
__decorate([
    property()
], CollabMessagesPrompt100554.prototype, "threadId", void 0);
__decorate([
    property()
], CollabMessagesPrompt100554.prototype, "scope", void 0);
__decorate([
    property({
        type: Boolean,
        converter: (value) => value === 'true'
    })
], CollabMessagesPrompt100554.prototype, "acceptAutoCompleteUser", void 0);
__decorate([
    property({
        type: Boolean,
        converter: (value) => value === 'true'
    })
], CollabMessagesPrompt100554.prototype, "acceptAutoCompleteAgents", void 0);
CollabMessagesPrompt100554 = __decorate([
    customElement('collab-messages-prompt-100554')
], CollabMessagesPrompt100554);
export { CollabMessagesPrompt100554 };
