/// <mls shortName="pluginStyleTransform" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
/// **collab_i18n_start**
const message_pt = {
    advanced: 'Avançado',
    scaleX: 'Escala x',
    scaleY: 'Escala y',
    skewX: 'Inclinar x',
    skewY: 'Inclinar y',
    translateX: 'Transladar x',
    translateY: 'Transladar y',
    rotate: 'Rotacionar',
};
const message_en = {
    advanced: 'Advanced',
    scaleX: 'Scale x',
    scaleY: 'Scale y',
    skewX: 'Skew x',
    skewY: 'Skew Y',
    translateX: 'Translate x',
    translateY: 'Translate y',
    rotate: 'Rotate',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['transform'];
export const description = 'A versatile plugin for maintaining and applying CSS transform properties. Easily manage scale, rotate, skew, and translate transformations to create dynamic and interactive UI elements with precision.';
let PluginStyleTransform = class PluginStyleTransform extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-transform-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-transform-100554 details summary{cursor:pointer}plugin-style-transform-100554 details>div{margin-left:var(--space-16)}plugin-style-transform-100554 .group{margin-top:var(--space-8);display:flex;flex-direction:column;font-size:var(--font-size-12)}plugin-style-transform-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-transform-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-transform-100554 .gallery{margin-bottom:var(--space-16);display:flex;justify-content:start;align-items:center;gap:3rem;padding:1rem;flex-wrap:wrap;cursor:pointer}`);
        this.showFull = 'false';
        this.msg = messages['en'];
        this.arrayGallery = [
            '',
            'transform: scale(1.5);',
            'transform: rotate(90deg);',
            'transform: rotate(181deg);',
            'transform: rotate(270deg);',
            'transform: skew(50deg);',
            'transform: skew(50deg, -50deg);',
            'transform: skew(-50deg, 0deg);',
            'transform: skew(-50deg, 50deg);',
            'transform: translateX(20px);',
            'transform: scale(0.75);',
            'transform: scaleX(1.2);',
            'transform: scaleY(1.8);',
            'transform: rotate(45deg);',
            'transform: rotate(-45deg);',
            'transform: rotate3d(1, 1, 0, 60deg);',
            'transform: skewX(30deg);',
            'transform: skewY(-15deg);',
            'transform: rotate3d(0, 1, 0, 180deg);',
        ];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.showFull === 'true' ?
            html `
                    ${this.renderGallery()}
                    ${this.renderTransform()}

                ` :
            html `
                    ${this.renderGallery()}
                `}
        `;
    }
    renderTransform() {
        return html `
            <div class="group">
                <span>${this.msg.scaleX}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 prop="scaleX" value="0px" useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.scaleY}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 prop="scaleY" value="0px" useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.skewX}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 prop="skewX" value="0px" useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.skewY}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 prop="skewY" value="0px" useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.translateX}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 prop="translateX" value="0px" useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.translateY}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 prop="translateY" value="0px" useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.rotate}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 prop="rotate" value="0px" useSelect="false"></collab-ds-input-range-100554>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `<h5 style="${css}" .gallery=${css}>Item</h5>`;
        }))}
            </div>
        
        `;
    }
};
__decorate([
    property()
], PluginStyleTransform.prototype, "showFull", void 0);
PluginStyleTransform = __decorate([
    customElement('plugin-style-transform-100554')
], PluginStyleTransform);
export { PluginStyleTransform };
