/// <mls shortName="wcdToolboxItemActionPadding" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, render } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
/// **collab_i18n_start**
const message_pt = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const message_en = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WCDToolboxItemActionPadding = class WCDToolboxItemActionPadding extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.startX = 0;
        this.startY = 0;
        this.startTop = 0;
        this.startBottom = 0;
        this.startLeft = 0;
        this.startRight = 0;
        this.timeonChangeProp = -1;
        //---------DRAG------------------
        this.timeRemoveResize = 0;
    }
    //-------COMPONENT---------------------
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.elMain || !this.myParent)
            return;
        if (this.args && ['top', 'bottom', 'left', 'right'].includes(this.args)) {
            this.onmousedown = (e) => this.initDragging(e);
            this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
            this.myParent.updateBackgroundAuxSize('show');
        }
    }
    render() {
        switch (this.args) {
            case 'top':
                return this.renderOne('top');
            case 'bottom':
                return this.renderOne('bottom');
            case 'left':
                return this.renderOne('left');
            case 'right':
                return this.renderOne('right');
            case 'all':
                return this.renderAll();
            default: return this.renderButton();
        }
    }
    renderButton() {
        this.onclick = (e) => this.clickButton(e);
        this.classList.add('f-button');
        return html `<svg xmlns="http://www.w3.org/2000/svg" height="15px" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M352 64c0-17.7-14.3-32-32-32H128c-17.7 0-32 14.3-32 32s14.3 32 32 32H320c17.7 0 32-14.3 32-32zm96 128c0-17.7-14.3-32-32-32H32c-17.7 0-32 14.3-32 32s14.3 32 32 32H416c17.7 0 32-14.3 32-32zM0 448c0 17.7 14.3 32 32 32H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32zM352 320c0-17.7-14.3-32-32-32H128c-17.7 0-32 14.3-32 32s14.3 32 32 32H320c17.7 0 32-14.3 32-32z"/></svg>`;
    }
    renderOne(pos) {
        this.classList.add('f-square');
        switch (pos) {
            case 'top':
                this.style.cursor = 'ns-resize';
                break;
            case 'bottom':
                this.style.cursor = 'ns-resize';
                break;
            case 'left':
                this.style.cursor = 'ew-resize';
                break;
            case 'right':
                this.style.cursor = 'ew-resize';
                break;
            default: '';
        }
        return html ``;
    }
    renderAll() {
        return html ``;
    }
    //------IMPLEMENTATION----------------
    clickButton(e) {
        e.stopPropagation();
        if (!this.myParent)
            return;
        this.myParent.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: 'padding',
                args: 'top',
                position: 'p-m1'
            },
            {
                name: 'padding',
                args: 'right',
                position: 'p-r2'
            },
            {
                name: 'padding',
                args: 'bottom',
                position: 'p-m3'
            },
            {
                name: 'padding',
                args: 'left',
                position: 'p-l2'
            }
        ], false, 'padding');
        const params = {
            level: 4,
            position: 'right',
            wdcPath: this.myParent.title,
            op: 'Styles',
        };
        mls.events.fire([4], 'WCDEvent', JSON.stringify(params));
    }
    //------EXTERAL SCENARY----------------
    async renderOutdoorScenary() {
        if (!this.myParent || this.myParent.level !== '4')
            return;
        this.elExternal = await this.myParent.getAndSetScenaryOutDoor('Styles');
        if (!this.elExternal)
            return;
        render(this.renderPadding(), this.elExternal);
    }
    renderPadding() {
        if (!this.elMain)
            return html ``;
        return html `
            <div style="display:flex; flex-direction:column; gap:.5rem ;padding:1rem" class="myAuxGroup">
                <p style=" margin-bottom: 5px;">A propriedade <b>padding</b> define uma a distância entre o conteúdo de um elemento e suas bordas</p>
                <h4 style="display:flex; gap:1.5rem;margin:0px" >${this.msg.padding}<input type="checkbox" prop="padding"></h4>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.msg.top}</div>
                    <input prop="paddingTop" type="text" .value="${this.elMain.style.paddingTop}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.msg.right}</div>
                    <input prop="paddingRight" type="text" .value="${this.elMain.style.paddingRight}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div> 
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.msg.bottom}</div>
                    <input prop="paddingBottom" type="text" .value="${this.elMain.style.paddingBottom}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.msg.left}</div>
                    <input prop="paddingLeft" type="text" .value="${this.elMain.style.paddingLeft}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                
            </div>
        `;
    }
    onChangeProp(e) {
        const el = e.currentTarget;
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.changeEl(el);
        }, 500);
    }
    changeEl(el) {
        const prop = el.getAttribute('prop');
        const group = el ? el.getAttribute('group') : '';
        const elGroup = el.closest('.myAuxGroup')?.querySelector(`input[prop="${group}"]`);
        let isGroup = false;
        if (elGroup)
            isGroup = elGroup.checked;
        if (!prop || !this.elMain || !this.myParent)
            return;
        if (isGroup) {
            this.elMain.style.padding = el.value;
            ['paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight'].forEach((pr) => {
                const field = el.closest('.myAuxGroup')?.querySelector(`input[prop="${pr}"]`);
                if (field)
                    field.value = el.value;
            });
            this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
            this.myParent.updateBackgroundAuxSize('show');
            this.fireEvent(`{"padding":"${this.elMain.style.padding}"}`);
            return;
        }
        this.elMain.style[prop] = el.value;
        this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
        this.myParent.updateBackgroundAuxSize('show');
        this.fireEvent();
    }
    initDragging(e) {
        if (!this.elMain || !document.defaultView)
            return;
        this.startX = e.clientX;
        this.startY = e.clientY;
        const st = document.defaultView.getComputedStyle(this.elMain);
        this.startTop = parseInt(st.paddingTop, 10);
        this.startBottom = parseInt(st.paddingBottom, 10);
        this.startLeft = parseInt(st.paddingLeft, 10);
        this.startRight = parseInt(st.paddingRight, 10);
        const doDragging = (e) => {
            if (!this.elMain || !this.myParent)
                return;
            this.myParent.style.background = '#f9cc9d80';
            const deltaX = (e.clientX - this.startX);
            const deltaY = (e.clientY - this.startY);
            if (!this.args || ['top'].includes(this.args)) {
                this.elMain.style.paddingTop = (this.startTop + deltaY) + 'px';
            }
            if (!this.args || ['bottom'].includes(this.args)) {
                this.elMain.style.paddingBottom = (this.startBottom + deltaY) + 'px';
            }
            if (!this.args || ['left'].includes(this.args)) {
                this.elMain.style.paddingLeft = (this.startLeft + deltaX) + 'px';
            }
            if (!this.args || ['right'].includes(this.args)) {
                this.elMain.style.paddingRight = (this.startRight + deltaX * -1) + 'px';
            }
            this.renderOutdoorScenary();
            this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
            this.myParent.updateBackgroundAuxSize('show');
        };
        const stopDragging = (e) => {
            if (!this.elMain || !this.myParent)
                return;
            this.myParent.style.background = '';
            document.body.removeEventListener('mousemove', doDragging, false);
            document.body.removeEventListener('mouseup', stopDragging, false);
            clearTimeout(this.timeRemoveResize);
            this.timeRemoveResize = setTimeout(() => {
                if (!this.elMain || !this.myParent)
                    return;
                this.myParent.setAttribute('needResize', '');
            }, 800);
            this.fireEvent();
        };
        if (!this.elMain || !this.myParent)
            return;
        this.myParent.setAttribute('needResize', 'false');
        document.body.addEventListener('mousemove', doDragging, false);
        document.body.addEventListener('mouseup', stopDragging, false);
    }
    //----------FIRE-----------------
    fireEvent(ret = '') {
        if (!this.elMain || !this.myParent)
            return;
        if (ret === '') {
            if (this.args === 'top')
                ret = `padding-top: ${this.elMain.style.paddingTop}; `;
            if (this.args === 'bottom')
                ret = `padding-bottom:${this.elMain.style.paddingBottom}; `;
            if (this.args === 'left')
                ret = `padding-left: ${this.elMain.style.paddingLeft}; `;
            if (this.args === 'right')
                ret = `padding-right: ${this.elMain.style.paddingRight}; `;
        }
        this.myParent.setStyle(ret);
    }
};
WCDToolboxItemActionPadding = __decorate([
    customElement('wcd-toolbox-item-action-padding-100554')
], WCDToolboxItemActionPadding);
export { WCDToolboxItemActionPadding };
