/// <mls shortName="wcdToolboxItemActionPadding" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, render } from 'lit';
import { customElement, property } from 'lit/decorators.js';
//version 4
let WCDToolboxItemActionPadding = class WCDToolboxItemActionPadding extends LitElement {
    constructor() {
        super(...arguments);
        this.startX = 0;
        this.startY = 0;
        this.startTop = 0;
        this.startBottom = 0;
        this.startLeft = 0;
        this.startRight = 0;
        this.timeonChangeProp = -1;
        //-------------------------------------------
        this.timeRemoveResize = 0;
        this.myMsg = {
            margin: 'Margin',
            padding: 'Padding',
            top: 'Top',
            left: 'Left',
            bottom: 'Bottom',
            right: 'Right',
        };
    }
    createRenderRoot() {
        return this;
    }
    render() {
        this.renderOutdoorScenary();
        return html ``;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.elMain || !this.myParent)
            return;
        this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
        this.myParent.updateBackgroundAuxSize('show');
        this.onmousedown = (e) => this.initDragging(e);
    }
    //-----------------
    async renderOutdoorScenary() {
        if (!this.myParent || this.myParent.level !== '4')
            return;
        this.elExternal = await this.myParent.getAndSetScenaryOutDoor('Styles');
        if (!this.elExternal)
            return;
        render(this.renderPadding(), this.elExternal);
    }
    renderPadding() {
        if (!this.elMain)
            return html ``;
        return html `
            <div style="display:flex; flex-direction:column; gap:.5rem ;padding:1rem" class="myAuxGroup">
                <p style=" margin-bottom: 5px;">A propriedade <b>padding</b> define uma a distância entre o conteúdo de um elemento e suas bordas</p>
                <h4 style="display:flex; gap:1.5rem;margin:0px" >${this.myMsg.padding}<input type="checkbox" prop="padding"></h4>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.top}</div>
                    <input prop="paddingTop" type="text" .value="${this.elMain.style.paddingTop}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.right}</div>
                    <input prop="paddingRight" type="text" .value="${this.elMain.style.paddingRight}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div> 
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.bottom}</div>
                    <input prop="paddingBottom" type="text" .value="${this.elMain.style.paddingBottom}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">${this.myMsg.left}</div>
                    <input prop="paddingLeft" type="text" .value="${this.elMain.style.paddingLeft}"  group="padding" @input="${(e) => this.onChangeProp(e)}" />
                </div>
                
            </div>
        `;
    }
    onChangeProp(e) {
        const el = e.currentTarget;
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.changeEl(el);
        }, 500);
    }
    changeEl(el) {
        const prop = el.getAttribute('prop');
        const group = el ? el.getAttribute('group') : '';
        const elGroup = el.closest('.myAuxGroup')?.querySelector(`input[prop="${group}"]`);
        let isGroup = false;
        if (elGroup)
            isGroup = elGroup.checked;
        if (!prop || !this.elMain || !this.myParent)
            return;
        if (isGroup) {
            this.elMain.style.padding = el.value;
            ['paddingTop', 'paddingBottom', 'paddingLeft', 'paddingRight'].forEach((pr) => {
                const field = el.closest('.myAuxGroup')?.querySelector(`input[prop="${pr}"]`);
                if (field)
                    field.value = el.value;
            });
            this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
            this.myParent.updateBackgroundAuxSize('show');
            this.fireEvent(`{"padding":"${this.elMain.style.padding}"}`);
            return;
        }
        this.elMain.style[prop] = el.value;
        this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
        this.myParent.updateBackgroundAuxSize('show');
        this.fireEvent();
    }
    initDragging(e) {
        if (!this.elMain || !document.defaultView)
            return;
        this.startX = e.clientX;
        this.startY = e.clientY;
        const st = document.defaultView.getComputedStyle(this.elMain);
        this.startTop = parseInt(st.paddingTop, 10);
        this.startBottom = parseInt(st.paddingBottom, 10);
        this.startLeft = parseInt(st.paddingLeft, 10);
        this.startRight = parseInt(st.paddingRight, 10);
        const doDragging = (e) => {
            if (!this.elMain || !this.myParent)
                return;
            this.myParent.style.background = '#f9cc9d80';
            const deltaX = (e.clientX - this.startX);
            const deltaY = (e.clientY - this.startY);
            if (!this.tpChange || ['top'].includes(this.tpChange)) {
                this.elMain.style.paddingTop = (this.startTop + deltaY) + 'px';
            }
            if (!this.tpChange || ['bottom'].includes(this.tpChange)) {
                this.elMain.style.paddingBottom = (this.startBottom + deltaY) + 'px';
            }
            if (!this.tpChange || ['left'].includes(this.tpChange)) {
                this.elMain.style.paddingLeft = (this.startLeft + deltaX) + 'px';
            }
            if (!this.tpChange || ['right'].includes(this.tpChange)) {
                this.elMain.style.paddingRight = (this.startRight + deltaX * -1) + 'px';
            }
            this.renderOutdoorScenary();
            this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
            this.myParent.updateBackgroundAuxSize('show');
        };
        const stopDragging = (e) => {
            if (!this.elMain || !this.myParent)
                return;
            this.myParent.style.background = '';
            document.body.removeEventListener('mousemove', doDragging, false);
            document.body.removeEventListener('mouseup', stopDragging, false);
            clearTimeout(this.timeRemoveResize);
            this.timeRemoveResize = setTimeout(() => {
                if (!this.elMain || !this.myParent)
                    return;
                this.myParent.setAttribute('needResize', '');
            }, 800);
            this.fireEvent();
        };
        if (!this.elMain || !this.myParent)
            return;
        this.myParent.setAttribute('needResize', 'false');
        document.body.addEventListener('mousemove', doDragging, false);
        document.body.addEventListener('mouseup', stopDragging, false);
    }
    fireEvent(ret = '') {
        if (!this.elMain || !this.myParent)
            return;
        if (ret === '') {
            if (this.tpChange === 'top')
                ret = `{"paddingTop":"${this.elMain.style.paddingTop}"}`;
            if (this.tpChange === 'bottom')
                ret = `{"paddingBottom":"${this.elMain.style.paddingBottom}"}`;
            if (this.tpChange === 'left')
                ret = `{"paddingLeft":"${this.elMain.style.paddingLeft}"}`;
            if (this.tpChange === 'right')
                ret = `{"paddingRight":"${this.elMain.style.paddingRight}"}`;
        }
        const evento = new CustomEvent('onChange', {
            detail: { valor: `{"tp":"style","style":${ret} }` },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(evento);
    }
};
__decorate([
    property({ type: String, reflect: true })
], WCDToolboxItemActionPadding.prototype, "tpChange", void 0);
WCDToolboxItemActionPadding = __decorate([
    customElement('wcd-toolbox-item-action-padding-100554')
], WCDToolboxItemActionPadding);
export { WCDToolboxItemActionPadding };
export const getTemplate = (mode = '', position = '') => {
    let ret = templateActionPadding.buttonPadding;
    if (mode === 'paddingTop')
        ret = templateActionPadding.paddingTop;
    if (mode === 'paddingRight')
        ret = templateActionPadding.paddingRight;
    if (mode === 'paddingBottom')
        ret = templateActionPadding.paddingBottom;
    if (mode === 'paddingLeft')
        ret = templateActionPadding.paddingLeft;
    if (position !== '')
        ret.position = position;
    return ret;
};
const templateActionPadding = {
    backButton: {
        position: '',
        tp: 'back-button',
        format: '',
        title: 'Back',
        iconSvg: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM175 175c-9.4 9.4-9.4 24.6 0 33.9l47 47-47 47c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-47-47 47-47c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-47 47-47-47c-9.4-9.4-24.6-9.4-33.9 0z"/></svg>',
        onclick: (e, wc) => {
            wc.setIconsWcdToolbox([], true, 'size');
            wc.backNavigationScenaryOutdoor();
        },
        menuItens: [],
        menuSubItens: [],
        widget: '',
        cursor: 'pointer',
        attrs: undefined,
        isDblClick: false,
    },
    //padding
    buttonPadding: {
        position: 'p-l4',
        tp: 'button',
        format: '',
        title: 'padding',
        iconSvg: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M352 64c0-17.7-14.3-32-32-32H128c-17.7 0-32 14.3-32 32s14.3 32 32 32H320c17.7 0 32-14.3 32-32zm96 128c0-17.7-14.3-32-32-32H32c-17.7 0-32 14.3-32 32s14.3 32 32 32H416c17.7 0 32-14.3 32-32zM0 448c0 17.7 14.3 32 32 32H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H32c-17.7 0-32 14.3-32 32zM352 320c0-17.7-14.3-32-32-32H128c-17.7 0-32 14.3-32 32s14.3 32 32 32H320c17.7 0 32-14.3 32-32z"/></svg>',
        onclick: (e, wc) => {
            wc.setIconsWcdToolbox([
                templateActionPadding.backButton,
                templateActionPadding.paddingTop,
                templateActionPadding.paddingRight,
                templateActionPadding.paddingBottom,
                templateActionPadding.paddingLeft
            ], false, 'padding');
        },
        menuItens: [],
        menuSubItens: [],
        widget: '',
        cursor: 'pointer',
        attrs: undefined,
        isDblClick: false,
    },
    paddingTop: {
        position: 'p-m1',
        tp: 'action',
        format: 'square',
        title: '',
        iconSvg: '',
        onclick: undefined,
        menuItens: [],
        menuSubItens: [],
        widget: 'wcd-toolbox-item-action-padding-100554',
        cursor: 'ns-resize',
        attrs: [{ attr: 'tpchange', value: 'top' }],
        isDblClick: false,
    },
    paddingRight: {
        position: 'p-r2',
        tp: 'action',
        format: 'square',
        title: '',
        iconSvg: '',
        onclick: undefined,
        menuItens: [],
        menuSubItens: [],
        widget: 'wcd-toolbox-item-action-padding-100554',
        cursor: 'ew-resize',
        attrs: [{ attr: 'tpchange', value: 'right' }],
        isDblClick: false,
    },
    paddingBottom: {
        position: 'p-m3',
        tp: 'action',
        format: 'square',
        title: '',
        iconSvg: '',
        onclick: undefined,
        menuItens: [],
        menuSubItens: [],
        widget: 'wcd-toolbox-item-action-padding-100554',
        cursor: 'ns-resize',
        attrs: [{ attr: 'tpchange', value: 'bottom' }],
        isDblClick: false,
    },
    paddingLeft: {
        position: 'p-l2',
        tp: 'action',
        format: 'square',
        title: '',
        iconSvg: '',
        onclick: undefined,
        menuItens: [],
        menuSubItens: [],
        widget: 'wcd-toolbox-item-action-padding-100554',
        cursor: 'ew-resize',
        attrs: [{ attr: 'tpchange', value: 'left' }],
        isDblClick: false,
    },
};
