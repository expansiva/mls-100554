/// <mls shortName="collabMessagesAdd" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { addThread, updateThread } from './_100554_msgDBController';
import { notifyThreadChange, notifyThreadCreate, getTemporaryContext } from './_100554_aiAgentHelper';
import { getUserId, getDmThreadByUsers, addMessage, createThreadDM } from './_100554_collabMessageHelper';
import './_100554_collabInputTag';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    threadType: 'Tipo de thread',
    threadName: 'Nome da thread',
    dmUser: 'Usuário (DM)',
    channelTemplate: 'Template do canal',
    visibility: 'Visibilidade',
    visibilityPublic: 'Pública',
    visibilityPrivate: 'Privada',
    visibilityCompany: 'Empresa',
    visibilityTeam: 'Time',
    group: 'Grupo',
    languages: 'Tradução automática nos idiomas',
    languagesHint: 'A cada mensagem será verificado o idioma da mensagem e feito a tradução para os idiomas acima, deixe em branco para não gastar créditos.',
    validateFormError: 'Preencha todos os campos obrigatórios.',
    userError: 'ID de usuário inválido.',
    btnAdd: 'Adicionar thread',
    advanced: 'Configurações avançadas',
    successSaving: 'Alterações salvas com sucesso!',
    dmValidationError: "Usuário inválido",
    channelValidationError: "O nome do canal deve começar com '#'.",
    selectAgent: 'Escolha um AgentBot (opcional)',
    noneAgent: 'Nenhum – Sem agente automático',
    initialMessage: 'Mensagem inicial (opcional)',
    placeholderMessage: 'Escreva aqui uma mensagem de abertura...',
    suggestions: ['Mensagem de boas-vindas', 'Regras do canal', 'Links de ajuda'],
    topics: 'Tópicos iniciais',
    agentConfig: 'Configuração do agente',
    placeholderConfig: 'Explique como o agente deve funcionar...',
    back: 'Voltar',
    save: 'Salvar Detalhes',
    threadDmAlreadyExist: 'Já existe uma conversa direta com este usuário.',
    placeholderMessageAvatar: 'Digite aqui sua descrição..',
    avatarUrl: 'Gerar avatar com IA (opcional)',
    detailsBot: 'Instalar bot ',
    detailsInitialMessage: 'Configurar mensagem inicial',
    detailsIcon: 'Configurar ícone',
    threadNameInvalid: 'O nome deve começar com #',
    selectUser: 'Selecione um usuário',
};
const message_en = {
    loading: 'Loading...',
    threadType: 'Thread type',
    threadName: 'Thread name',
    dmUser: 'User (DM)',
    channelTemplate: 'Channel template',
    visibility: 'Visibility',
    visibilityPublic: 'Public',
    visibilityPrivate: 'Private',
    visibilityCompany: 'Company',
    visibilityTeam: 'Team',
    group: 'Group',
    languages: 'Automatic translation in multiple languages',
    languagesHint: 'For each message, the language will be detected and translated into the languages above. Leave blank to avoid spending credits.',
    validateFormError: 'Please fill in all required fields.',
    userError: 'Invalid user ID.',
    advanced: 'Advanced settings',
    btnAdd: 'Add thread',
    successSaving: 'Saved successfully!',
    dmValidationError: "Invalid user",
    channelValidationError: "Channel name must start with '#'.",
    selectAgent: 'Select an AgentBot (opcional)',
    noneAgent: 'None – No automatic agent',
    initialMessage: 'Initial message (optional)',
    placeholderMessage: 'Write an opening message here...',
    suggestions: ['Welcome message', 'Rules', 'Help links'],
    topics: 'Initial topics',
    agentConfig: 'Agent configuration',
    placeholderConfig: 'Explain how the agent should work...',
    back: 'Back',
    save: 'Save Details',
    threadDmAlreadyExist: 'A direct message thread with this user already exists.',
    placeholderMessageAvatar: "Type your description here...",
    avatarUrl: 'Generate avatar with AI (opcional)',
    detailsBot: 'Install bot',
    detailsInitialMessage: 'Set up initial message',
    detailsIcon: 'Set up icon',
    threadNameInvalid: 'The name must start with #',
    selectUser: 'Select a user',
};
const messages = { en: message_en, pt: message_pt };
/// **collab_i18n_end**
let CollabMessagesAdd100554 = class CollabMessagesAdd100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-add-100554{display:block}collab-messages-add-100554 small{font-size:var(--font-size-12)}collab-messages-add-100554 label{display:block;margin-bottom:.4rem}collab-messages-add-100554 input,collab-messages-add-100554 select{height:33px}collab-messages-add-100554 input,collab-messages-add-100554 select,collab-messages-add-100554 textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-messages-add-100554 input:invalid{border-color:var(--error-color)}collab-messages-add-100554 input:invalid+.field-thread-name-error{display:block;color:var(--error-color);font-size:.9em}collab-messages-add-100554 .field-thread-name-error{display:none}collab-messages-add-100554 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}collab-messages-add-100554 button:hover{background-color:var(--info-color-hover)}collab-messages-add-100554 .section-add-thread{padding:1rem}collab-messages-add-100554 .section-add-thread .section-thread-details{margin-top:1rem;display:flex;flex-direction:column;gap:1rem}collab-messages-add-100554 .section-add-thread details>summary{cursor:pointer}collab-messages-add-100554 .section-add-thread details>div{padding:.5rem;margin-left:1rem}collab-messages-add-100554 .actions{margin-top:1rem;display:flex;gap:1rem}collab-messages-add-100554 .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}collab-messages-add-100554 .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-add-100554 .saving-error{color:var(--error-color);font-size:var(--font-size-12)}`);
        this.msg = messages['en'];
        this.threadType = 'dm';
        this.threadName = '';
        this.visibility = 'private';
        this.group = 'CRM';
        this.languages = [];
        this.isLoading = false;
        this.dmUser = '';
        this.users = [];
        this.agentsBots = [];
        this._selectedAgent = 'none';
        this._initialMessage = '';
        this._topics = [];
        this._agentConfig = '';
        this._promptToAvatar = '';
        this.labelOk = '';
        this.labelError = '';
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        await this.loadUsersAvaliables();
        await this.loadAgentsBotsAvaliables();
    }
    render() {
        return this._renderAdd();
    }
    async loadUsersAvaliables() {
        const userId = getUserId();
        if (!userId)
            return;
        const res = await mls.api.msgGetUsers({ status: "active", prefixName: "", userId });
        if (res.statusCode !== 200)
            return;
        this.users = res.users;
    }
    async loadAgentsBotsAvaliables() {
        const agentsFiles = await this.getAgentsFiles();
        const agents = agentsFiles.map((data) => {
            const { visibility, agentName, avatar_url, agentDescription, scope } = data.agent;
            const { project, folder, shortName } = data.storFile;
            if (agentName.startsWith('agentBot') && agentName !== 'agentBotInstall' && visibility === 'public') {
                return {
                    id: agentName, name: agentName, description: agentDescription, avatar_url: avatar_url, info: { project, folder, shortName }
                };
            }
        }).filter((item) => item !== undefined);
        this.agentsBots = [{ id: 'none', name: '', description: '', avatar_url: '' }].concat(agents);
    }
    async getAgentsFiles() {
        const keys = Object.keys(mls.stor.files);
        const ret = [];
        for await (const k of keys) {
            if (k.indexOf('agent') < 0)
                continue;
            const storFile = mls.stor.files[k];
            const path = storFile.folder ? `./_${storFile.project}_${storFile.folder}/${storFile.shortName}` : `./_${storFile.project}_${storFile.shortName}`;
            if (storFile.extension !== '.ts' || !storFile.shortName.startsWith('agent'))
                continue;
            try {
                const mdl = await import(path);
                if (!mdl.createAgent)
                    continue;
                const agent = mdl.createAgent();
                ret.push({ agent, storFile });
            }
            catch (err) {
                continue;
            }
        }
        return ret;
    }
    _renderAdd() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="section-add-thread">

            <label>${this.msg.threadType}
                <select 
                    .value=${this.threadType}
                    @change=${(e) => this.threadType = e.target.value}>
                    <option value="dm">DM</option>
                    <option value="channel">Channel</option>
                </select>
            </label>


            ${this.threadType === 'dm' ? html `
                <label>
                    ${this.msg.dmUser}
                    <select
                        .value=${this.dmUser}
                        @change=${(e) => this.dmUser = e.target.value}>
                        <option value="" disabled selected>${this.msg.selectUser}</option>
                        ${this.users.map(user => html `
                            <option value="${user.userId}">@${user.name}</option>
                        `)}
                    </select>
                </label>
            ` : ''}

            ${this.threadType === 'channel' ? html `
                <label>${this.msg.threadName}
                    <input type="text" placeholder="#nome-do-canal"
                        .value=${this.threadName}
                         pattern="^#.*"
                        @input=${(e) => this.threadName = e.target.value}
                    >
                    <span class="field-thread-name-error">${this.msg.threadNameInvalid}</span>
                </label>
            ` : ''}

            ${this.threadType === 'channel' ? html `
                <label> ${this.msg.visibility}
                <select name="visibility" required
                    .value=${this.visibility}
                    @change=${(e) => this.visibility = e.target.value}>
                      <option value="public">${this.msg.visibilityPublic}</option>
                    <option value="private">${this.msg.visibilityPrivate}</option>
                    <option value="company">${this.msg.visibilityCompany}</option>
                    <option value="team">${this.msg.visibilityTeam}</option>
                </select>
                </label>            
            ` : ''}
            
            <label> ${this.msg.group}
                <select name="group" required
                    .value=${this.group}
                    @change=${(e) => this.group = e.target.value}>
                    <option value="CRM">CRM</option>
                    <option value="TASK">TASK</option>
                    <option value="DOCS">DOCS</option>
                    <option value="CONNECT">CONNECT</option>
                    <option value="APPS">APPS</option>
                </select>
            </label>

            <label> ${this.msg.languages}
                <collab-input-tag-100554 
                    pattern="^[a-z]{2}$|^[a-z]{2}-[A-Z]{2}$"
                    .value=${this.languages.join(',')}
                    .onValueChanged=${(value) => this.languages = value.split(',')}
                    id="languageInput"
                ></collab-input-tag-100554>
                <small> ${this.msg.languagesHint}</small>
            </label>

        
            ${this.threadType === 'channel' ? html `
                <div class="section-thread-details">
                    ${this.renderBotsConfig()}
                    ${this.renderInitialMessageConfig()}
                    ${this.renderIconConfig()}

                </div>
                <br>
                <br>
            ` : ''}

            <button
                @click=${this.addNewThread}
                ?disabled=${this.isLoading}
                >
                ${this.isLoading ? html `<span class="loader"></span>` : this.msg.btnAdd}
            </button>

            ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}<small>` : ''}
            ${this.labelError ? html `<small class="saving-error">${this.labelError}<small>` : ''}   
        </div>`;
    }
    renderBotsConfig() {
        return html `
            <details>
                <summary>${this.msg.detailsBot}</summary>
                <div>
                    <label>${this.msg.selectAgent}</label>
                    <select @change=${(e) => this._selectedAgent = e.target.value}>
                        ${this.agentsBots.map(agent => html `
                            <option 
                                value=${agent.id} 
                                ?selected=${this._selectedAgent === agent.id}>
                                ${agent.name}${agent.description ? ` - ${agent.description}` : ''}
                            </option>
                        `)}
                    </select>
                    ${this._selectedAgent && this._selectedAgent !== 'none' ? html `
                        <label>${this.msg.agentConfig}</label>
                        <textarea 
                            rows="5" 
                            .value=${this._agentConfig}
                            placeholder=${this.msg.placeholderConfig}
                            @input=${(e) => this._agentConfig = e.target.value}
                        ></textarea>
                ` : ''}
                </div>
            </details>
        `;
    }
    renderInitialMessageConfig() {
        return html `
            <details>
                <summary>${this.msg.detailsInitialMessage}</summary>
                <div>
                    <label>${this.msg.initialMessage}</label>
                    <textarea 
                        rows="5" 
                        .value=${this._initialMessage}
                        placeholder=${this.msg.placeholderMessage}
                        @input=${(e) => this._initialMessage = e.target.value}
                    ></textarea>
                </div>
            </details>            
        `;
    }
    renderIconConfig() {
        return html `
            <details>
                <summary>${this.msg.detailsIcon}</summary>
                <div>
                    <label>${this.msg.avatarUrl}</label>
                    <textarea 
                        rows="5" 
                        .value=${this._promptToAvatar}
                        placeholder=${this.msg.placeholderMessageAvatar}
                        @input=${(e) => this._promptToAvatar = e.target.value}
                    ></textarea>
                </div>
            </details>            
        `;
    }
    validateForm() {
        if (this.threadType === 'dm') {
            if (!this.dmUser.trim())
                return false;
            const userValid = this.users.find((user) => user.userId === this.dmUser);
            if (!userValid) {
                this.labelError = this.msg.dmValidationError;
                return false;
            }
        }
        if (this.threadType === 'channel') {
            if (!this.threadName.trim())
                return false;
            if (!this.threadName.startsWith('#')) {
                this.labelError = this.msg.channelValidationError;
                return false;
            }
        }
        if (!this.group)
            return false;
        if (!this.visibility)
            return false;
        return true;
    }
    async addNewThread() {
        if (!this.validateForm() || this.languageInput?.hasError) {
            this.labelError = this.msg.validateFormError;
            this.isLoading = false;
            return;
        }
        if (!this.userId) {
            this.labelError = this.msg.userError;
            this.isLoading = false;
            return;
        }
        let avatar_url = '';
        if (this.threadType === 'channel' && this._selectedAgent !== 'none') {
            const botSelected = this.agentsBots.find((item) => item.id === this._selectedAgent);
            avatar_url = botSelected?.avatar_url || '';
        }
        else {
            this._topics = [];
            this._initialMessage = '';
            this._selectedAgent = '';
        }
        this.isLoading = true;
        if (this.threadType === 'dm') {
            const alreadyExistThread = await getDmThreadByUsers(this.userId, this.dmUser);
            if (alreadyExistThread) {
                this.labelError = this.msg.threadDmAlreadyExist;
                this.isLoading = false;
                return;
            }
        }
        const threadName = this.threadType === 'dm' ? `@${this.users.find((user) => user.userId === this.dmUser)?.name}` : this.threadName;
        if (this.threadType === 'dm') {
            try {
                const thread = await createThreadDM(threadName, this.dmUser, this.group);
                if (this.onAddSuccess)
                    this.onAddSuccess();
            }
            catch (err) {
                console.error(err);
                this.labelError = err.message;
            }
            finally {
                this.isLoading = false;
            }
        }
        if (this.threadType === 'channel') {
            const params = {
                action: 'addThread',
                name: threadName,
                group: this.group,
                languages: this.languages,
                userId: this.userId,
                visibility: this.visibility,
                status: 'active',
                avatar_url,
                welcomeMessage: this._initialMessage,
                defaultTopics: this._topics || [],
            };
            try {
                const response = await mls.api.msgAddThread(params);
                if (response.thread) {
                    const thr = await addThread(response.thread);
                    notifyThreadCreate(thr);
                    if (this._selectedAgent && this._selectedAgent !== 'none') {
                        await this.addBot(response.thread.threadId, this.userId);
                    }
                    if (this._promptToAvatar) {
                        await this.generateAvatar(response.thread.threadId, this.userId);
                    }
                    if (this.onAddSuccess)
                        this.onAddSuccess();
                }
            }
            catch (err) {
                console.error(err);
                this.labelError = err.message;
            }
            finally {
                this.isLoading = false;
            }
        }
    }
    async addBot(threadId, userId) {
        const botSelected = this.agentsBots.find((item) => item.id === this._selectedAgent);
        if (!botSelected || !botSelected.info)
            return;
        await addMessage(threadId, `@@BotInstall {"projectId":${botSelected.info.project}, "shortName":"${botSelected.info.shortName}", "folder":${botSelected.info.folder || '""'}}`);
        if (this._agentConfig) {
            const threadWithBot = await mls.api.msgGetThreadUpdate({
                threadId,
                userId
            });
            if (threadWithBot && threadWithBot.thread.bots) {
                const botInfo = threadWithBot.thread.bots.find((bot) => bot.botId === botSelected.id);
                if (botInfo) {
                    const res = await mls.api.msgAddOrUpdateThreadBot({
                        botId: botSelected.id,
                        config: { 'agentConfiguration': this._agentConfig },
                        llmPrompt: botInfo.llmPrompt,
                        status: 'active',
                        threadId,
                        userId
                    });
                    notifyThreadChange(res.thread);
                    if (this.onAddSuccess)
                        this.onAddSuccess();
                }
            }
            else {
                notifyThreadChange(threadWithBot.thread);
                if (this.onAddSuccess)
                    this.onAddSuccess();
            }
        }
    }
    async generateAvatar(threadId, userId) {
        try {
            const agentName = '_100554_agentGenerateAvatarSvg';
            const moduleAgent = await import(`/${agentName}`);
            if (!moduleAgent?.createAgent || typeof moduleAgent.createAgent !== 'function') {
                throw new Error('Invalid agent');
            }
            const agent = moduleAgent.createAgent();
            const context = getTemporaryContext(threadId, userId, this._promptToAvatar);
            await agent.beforePrompt(context);
            if (context.task &&
                context.task.iaCompressed &&
                context.task.iaCompressed.nextSteps &&
                context.task.iaCompressed.nextSteps[0] &&
                context.task.iaCompressed.nextSteps[0].interaction &&
                context.task.iaCompressed.nextSteps[0].interaction.payload &&
                context.task.iaCompressed.nextSteps[0].interaction.payload[0]) {
                const svg = (context.task.iaCompressed?.nextSteps[0]?.interaction?.payload[0]).result;
                if (svg && typeof svg === 'string') {
                    const args = {
                        action: 'updateThread',
                        threadId,
                        userId,
                        avatar_url: svg
                    };
                    const response = await mls.api.msgUpdateThread(args);
                    if (response.statusCode !== 200) {
                        this.labelError = `${response.msg}`;
                    }
                    else {
                        const threadCache = await updateThread(threadId, response.thread);
                        notifyThreadChange(threadCache);
                    }
                }
            }
        }
        catch (err) {
            console.error("Erro ao gerar avatar via IA", err);
        }
    }
};
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "threadType", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "threadName", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "visibility", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "group", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "languages", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "isLoading", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "dmUser", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "users", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "agentsBots", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "_selectedAgent", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "_initialMessage", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "_topics", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "_agentConfig", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "_promptToAvatar", void 0);
__decorate([
    property()
], CollabMessagesAdd100554.prototype, "labelOk", void 0);
__decorate([
    property()
], CollabMessagesAdd100554.prototype, "labelError", void 0);
__decorate([
    property()
], CollabMessagesAdd100554.prototype, "userId", void 0);
__decorate([
    query('#languageInput')
], CollabMessagesAdd100554.prototype, "languageInput", void 0);
CollabMessagesAdd100554 = __decorate([
    customElement('collab-messages-add-100554')
], CollabMessagesAdd100554);
export { CollabMessagesAdd100554 };
