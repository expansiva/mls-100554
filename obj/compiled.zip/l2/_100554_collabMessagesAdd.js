/// <mls shortName="collabMessagesAdd" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import './_100554_collabInputTag';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    threadName: 'Nome da thread',
    visibility: 'Visibilidade',
    group: 'Grupo',
    languages: 'Idiomas',
    languagesHint: 'Detectado e atualizado com base nos idiomas dos usuários participantes.',
    addLoading: 'Adicionando thread...',
    validateFormError: 'Preencha todos os campos obrigatórios.',
    userError: 'ID de usuário inválido.',
    btnAdd: 'Adicionar thread'
};
const message_en = {
    loading: 'Loading...',
    threadName: 'Thread name',
    visibility: 'Visibility',
    group: 'Group',
    languages: 'Languages',
    languagesHint: 'Detected and updated based on the languages of participating users.',
    addLoading: 'Adding thread...',
    validateFormError: 'Please fill in all required fields.',
    userError: 'Invalid user ID.',
    btnAdd: 'Add thread'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesAdd100554 = class CollabMessagesAdd100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-add-100554 small{font-size:var(--font-size-12)}collab-messages-add-100554 label{display:block;margin-bottom:.4rem}collab-messages-add-100554 input,collab-messages-add-100554 select,collab-messages-add-100554 textarea{width:100%;display:block;font-size:1rem;line-height:1.5;height:33px;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-messages-add-100554 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}collab-messages-add-100554 button:hover{background-color:var(--info-color-hover)}`);
        this.msg = messages['en'];
        this.threadName = '';
        this.visibility = 'private';
        this.group = 'CRM';
        this.languages = [];
        this.isLoading = false; // NOVO
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="section-add">
            <label>${this.msg.threadName}
                <input type="text" name="name" required
                    .value=${this.threadName}
                    @input=${(e) => this.threadName = e.target.value}>
            </label>

            <label> ${this.msg.visibility}
                <select name="visibility" required
                    .value=${this.visibility}
                    @change=${(e) => this.visibility = e.target.value}>
                    <option value="public">Pública</option>
                    <option value="private">Privada</option>
                    <option value="company">Empresa</option>
                    <option value="team">Equipe</option>
                </select>
            </label>

            <label> ${this.msg.group}
                <select name="group" required
                    .value=${this.group}
                    @change=${(e) => this.group = e.target.value}>
                    <option value="CRM">CRM</option>
                    <option value="TASK">TASK</option>
                    <option value="DOCS">DOCS</option>
                    <option value="CONNECT">CONNECT</option>
                    <option value="APPS">APPS</option>
                </select>
            </label>

            <label> ${this.msg.languages}
                <collab-input-tag-100554 
                    .value=${this.languages.join(',')}
                    .onValueChanged=${(value) => this.languages = value.split(',')}
                    id="languageInput"
                ></collab-input-tag-100554>
                <small> ${this.msg.languagesHint}</small>
            </label>

            ${this.isLoading
            ? html `<p>${this.msg.addLoading}</p>`
            : html `<button @click=${this.addNewThread} style="margin-top: 20px;">${this.msg.btnAdd}</button>`}
        </div>`;
    }
    validateForm() {
        if (!this.threadName.trim())
            return false;
        if (!this.group)
            return false;
        if (!this.visibility)
            return false;
        return true;
    }
    async addNewThread() {
        if (!this.validateForm()) {
            const res = { ok: false, msg: this.msg.validateFormError };
            if (this.afterAdd)
                this.afterAdd(res);
            this.isLoading = false;
            return;
        }
        if (!this.userId) {
            const res = { ok: false, msg: this.msg.userError };
            if (this.afterAdd)
                this.afterAdd(res);
            this.isLoading = false;
            return;
        }
        const params = {
            action: 'addThread',
            name: this.threadName,
            group: this.group,
            languages: this.languages,
            userId: this.userId,
            visibility: this.visibility,
            status: 'active'
        };
        this.isLoading = true;
        try {
            const response = await mls.api.msgAddThread(params);
            const res = { ok: true, data: response.thread };
            if (this.afterAdd)
                this.afterAdd(res);
        }
        catch (err) {
            const res = { ok: false, msg: err.message };
            if (this.afterAdd)
                this.afterAdd(res);
            throw new Error(err.message);
        }
        finally {
            this.isLoading = false;
        }
    }
};
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "threadName", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "visibility", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "group", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "languages", void 0);
__decorate([
    state()
], CollabMessagesAdd100554.prototype, "isLoading", void 0);
__decorate([
    property()
], CollabMessagesAdd100554.prototype, "userId", void 0);
CollabMessagesAdd100554 = __decorate([
    customElement('collab-messages-add-100554')
], CollabMessagesAdd100554);
export { CollabMessagesAdd100554 };
