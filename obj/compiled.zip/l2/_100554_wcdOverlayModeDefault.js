/// <mls shortName="wcdOverlayModeDefault" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdOverlayLitBase } from './_100554_wcdOverlayLitBase';
import { execute as excCommandEnter } from './_100554_wcdCommandEnter';
import { execute as excCommandDel } from './_100554_wcdCommandDel';
import { execute as excCommandCopy } from './_100554_wcdCommandCopy';
import { execute as excCommandNext } from './_100554_wcdCommandSelectNext';
import { execute as excCommandUndo } from './_100554_wcdCommandUndo';
import './_100554_wcdOverlayModeDefaultItem';
let WcdOverlayModeDefault = class WcdOverlayModeDefault extends WcdOverlayLitBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wcd-overlay-mode-default-100554 wcd-toolbox-100554{box-shadow:0 0 2px 2px var(--bg-primary-color-darker-disabled)}`);
        this.overlayItemTagName = 'wcd-overlay-mode-default-item-100554';
        this.listWidgetsBase = [
            { name: '_100554_wcImage' },
            { name: '_100554_wcText' },
            { name: '_100554_wcCode' },
            { name: '_100554_wcVideo' },
            { name: '_100554_wcSection' },
            { name: '_100554_wcDividerLine' }
        ];
        this.keys = {
            'ArrowDown': 'down',
            'ArrowLeft': 'left',
            'ArrowUp': 'up',
            'ArrowRight': 'right'
        };
        this.myKeyEvents = {
            'Enter': excCommandEnter,
            'Backspace': excCommandDel,
            'Delete': excCommandDel,
            'c': excCommandCopy,
            'v': excCommandCopy,
            'z': excCommandUndo,
            'ArrowDown': this.onkeydownArrow.bind(this),
            'ArrowLeft': this.onkeydownArrow.bind(this),
            'ArrowUp': this.onkeydownArrow.bind(this),
            'ArrowRight': this.onkeydownArrow.bind(this)
        };
    }
    onkeydownArrow(e) {
        const param = {
            args: {},
            overlay: e.overlay,
            selectedIca: e.selectedIca
        };
        const event = e.args;
        event.preventDefault();
        if (!this.keys[event.key])
            return;
        const info = { position: '', positionMode: '' };
        info.position = this.keys[event.key];
        info.positionMode = event.altKey ? 'tree' : 'visual';
        param.args = info;
        excCommandNext(param);
    }
    refreshOverlay() {
        const page = this.parentElement;
        if (page) {
            page.overlay?.remove();
            page.overlay = undefined;
            page.refreshOverlay();
        }
    }
    selectItem(ica) {
        if (!ica || !ica.overlayRef)
            return;
        ica.overlayRef.click();
        ica.overlayRef.scrollIntoView({ block: 'center' });
    }
    getActionsTagsDefault() {
        return {
            'backButton': {
                name: 'button',
                position: 'p-r0',
                args: '',
                level: [1, 2, 3, 4, 5, 6]
            },
            'menu': {
                name: '_100554_wcdToolboxItemActionMenu',
                position: 'p-m0',
                args: '{}',
                level: [2, 3]
            },
            'events': {
                name: '_100554_wcdToolboxItemActionEvents',
                position: 'p-r1',
                args: '',
                level: [2]
            },
            'add': {
                name: "_100554_wcdAdd",
                level: [2, 3],
                position: 'p-l2',
                args: '{ "buttons" : "image,unsplash,video,embed,code,part,add" }',
                toolboxOptions: { background: 'none', border: 'none' }
            },
            'edit': {
                name: "_100554_wcdToolboxItemActionEditText",
                level: [2, 3],
                position: 'p-l0',
                args: ''
            },
            'title': {
                name: "_100554_wcdToolboxItemActionTitle",
                level: [1, 2, 3, 4, 5, 6],
                position: 'p-title-top',
                args: ''
            },
            'edit-code': {
                name: "_100554_wcdToolboxItemActionEditCode",
                level: [2, 3],
                position: 'p-l0',
                args: ''
            },
            'code-language': {
                name: "_100554_wcdToolboxItemActionCodeLanguage",
                level: [2, 3],
                position: 'p-l0',
                args: ''
            },
            'margin': {
                name: "_100554_wcdToolboxItemActionMargin",
                level: [3],
                position: 'p-l4',
                args: ''
            },
            'padding': {
                name: "_100554_wcdToolboxItemActionPadding",
                level: [3],
                position: 'p-m4',
                args: ''
            },
            'size': {
                name: "_100554_wcdToolboxItemActionSize",
                level: [3],
                position: 'p-r4',
                args: ''
            },
            'attr': {
                name: "_100554_wcdToolboxItemActionEditAttr",
                level: [2, 3],
                position: 'p-r0',
                args: ''
            },
        };
    }
    //---------COMPONENT----------------
    render() {
        this.style.display = 'block';
        this.style.position = 'absolute';
        this.style.width = '100%';
        this.style.height = 'calc(100% + 55px)'; //'calc(100vh - 50px)';//'100%';
        this.style.zIndex = '9000';
        this.style.top = '0';
        return html ``;
    }
};
WcdOverlayModeDefault = __decorate([
    customElement('wcd-overlay-mode-default-100554')
], WcdOverlayModeDefault);
export { WcdOverlayModeDefault };
