/// <mls shortName="aimChatRooms" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaLitElement, propertyDataSource } from './_100554_icaLitElement';
import * as chatHelper from './_100554_aimChatHelper';
import { currentUser, getRooms } from './_100554_aimChatMock';
let AimChatRooms100554 = class AimChatRooms100554 extends IcaLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`aim-chat-rooms-100554 .chat-list{list-style:none;margin:0;padding:0}aim-chat-rooms-100554 .chat-item:hover{background-color:#e6e6e6}aim-chat-rooms-100554 .chat-item{cursor:pointer;transition:background-color .5s;display:flex;align-items:center;padding:.1rem;position:relative}aim-chat-rooms-100554 .chat-item .back-button{cursor:pointer}aim-chat-rooms-100554 .chat-item .avatar{flex:0 0 auto;width:48px;height:48px;border-radius:50%;margin-right:1rem}aim-chat-rooms-100554 .chat-item .chat-content{flex:1;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;border-bottom:1px solid #E6E6E6;padding:.9rem}aim-chat-rooms-100554 .chat-item .chat-header{display:flex;justify-content:space-between;margin-bottom:.5rem}aim-chat-rooms-100554 .chat-item .chat-header .room-name{font-size:1rem;font-weight:bold;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}aim-chat-rooms-100554 .chat-item .chat-header .last-update{font-size:.875rem;color:#D3D3D3;white-space:nowrap}aim-chat-rooms-100554 .chat-item .chat-summary{display:flex;justify-content:space-between;align-items:center}aim-chat-rooms-100554 .chat-item .chat-summary .last-message{font-size:.875rem;color:#403f3f;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}aim-chat-rooms-100554 .chat-item .chat-summary .unread-count{background-color:#52C41A;color:#fff;font-size:.75rem;font-weight:bold;padding:.25rem .5rem;border-radius:12px;margin-left:1rem;white-space:nowrap}`);
    }
    render() {
        return this.renderRooms("chats");
    }
    renderRooms(group) {
        const roomsrecords = getRooms();
        const rooms = chatHelper.getChatRoomSummaries(currentUser, roomsrecords, group);
        console.log(rooms);
        return html ` 
        <ul class="chat-list">
        ${rooms.map((room) => html `
            <li class="chat-item"  @click=${() => this.handleRoomClick(room.id)}>
              <img class="avatar" src=${room.avatarUrl} alt="user avatar" />
              <div class="chat-content">
                <div class="chat-header">
                  <span class="room-name">${room.roomName}</span>
                  <span class="last-update">${chatHelper.formatChatDate(room.lastUpdate)}</span>
                </div>
                <div class="chat-summary">
                  <span class="last-message">${room.lastMessageSummary}</span>
                  ${room.unreadCount > 0 ? html `<span class="unread-count">${room.unreadCount}</span>` : ''}
                </div>
              </div>
            </li>
          `)}
      </ul>        
        `;
    }
    handleRoomClick(id) {
        this.activeRoom = id;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], AimChatRooms100554.prototype, "activeRoom", void 0);
__decorate([
    propertyDataSource({ type: Number })
], AimChatRooms100554.prototype, "activeMessage", void 0);
__decorate([
    propertyDataSource({ type: String })
], AimChatRooms100554.prototype, "activeFilterRooms", void 0);
AimChatRooms100554 = __decorate([
    customElement('aim-chat-rooms-100554')
], AimChatRooms100554);
export { AimChatRooms100554 };
