/// <mls shortName="wcdCommandSelectNext" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var keys = {
    'ArrowDown': 'botton',
    'ArrowLeft': 'left',
    'ArrowUp': 'top',
    'ArrowRight': 'right'
};
export function execute(param) {
    const e = param.args;
    const info = {};
    if (!keys[e.key])
        return;
    info.position = keys[e.key];
    info.positionMode = e.shiftKey ? 'visual' : 'tree';
    console.info(info);
}
