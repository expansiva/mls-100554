/// <mls shortName="wcdCommandSelectNext" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export async function execute(param) {
    if (!param?.selectedIca)
        throw new Error('invalid param.selectedIca');
    if (!param.overlay || typeof param.overlay.selectItem !== 'function')
        throw new Error('invalid param.overlay');
    const args = param.args;
    if (!args?.position ||
        !['left', 'right', 'up', 'down'].includes(args.position))
        throw new Error('invalid param.args.position');
    if (!args.positionMode ||
        !['visual', 'tree'].includes(args.positionMode))
        throw new Error('invalid param.args.positionMode');
    if (args.positionMode === 'tree') {
        navigateTree(param.selectedIca, args.position, param.overlay.selectItem);
    }
    else {
        navigateVisual(param.selectedIca, args.position, param.overlay.selectItem);
    }
}
function navigateVisual(el, position, selectItem) {
    const allElements = getAllIcaElements(document, 9999);
    let target = findVisual(el, position, allElements);
    if (!target) {
        // try again with childs
        switch (position) {
            case 'left':
                target = findVisual(el, 'leftchild', getAllIcaElements(el, 1));
                break;
            case 'right':
                target = findVisual(el, 'rightchild', getAllIcaElements(el, 1));
                break;
        }
    }
    if (target) {
        selectItem(target);
    }
}
function navigateTree(el, position, selectItem) {
    let target = null;
    switch (position) {
        case 'left':
            target = findSibling(el, -1);
            break;
        case 'right':
            target = findSibling(el, 1);
            break;
        case 'up':
            target = findParent(el);
            break;
        case 'down':
            target = findFirstChild(el);
            break;
    }
    if (target) {
        selectItem(target);
    }
}
function findSibling(el, direction) {
    let sibling = direction === -1 ? el.previousElementSibling : el.nextElementSibling;
    while (sibling) {
        if (isValidComponent(sibling)) {
            return sibling;
        }
        sibling = direction === -1 ? sibling.previousElementSibling : sibling.nextElementSibling;
    }
    return null;
}
function findParent(el) {
    let parent = el.parentElement;
    if (!parent && el.getRootNode() instanceof ShadowRoot) {
        parent = el.getRootNode().host;
    }
    while (parent) {
        if (isValidComponent(parent)) {
            return parent;
        }
        if (!parent.parentElement && parent.getRootNode() instanceof ShadowRoot) {
            parent = parent.getRootNode().host;
        }
        else {
            parent = parent.parentElement;
        }
    }
    return null;
}
function findFirstChild(el) {
    const allChilds = getAllIcaElements(el, 1);
    return allChilds.length > 0 ? allChilds[0] : null;
}
function isValidComponent(el) {
    return el.tagName.startsWith('ICA-');
}
function getAllIcaElements(root, deep) {
    let rc = [];
    const els = Array.from(root
        .querySelectorAll('*'));
    rc = rc.concat(els.filter(element => element.tagName.toLowerCase().startsWith('ica-')));
    els.forEach(el => {
        if (el.shadowRoot && deep > 0) {
            rc = rc.concat(getAllIcaElements(el.shadowRoot, deep - 1)); // reentrance
        }
    });
    return rc;
}
function calculateDistance(target, centerX, centerY) {
    const dx = centerX - (target.left + target.right) / 2;
    const dy = centerY - (target.top + target.bottom) / 2;
    return Math.sqrt(dx * dx + dy * dy);
}
function findVisual(el, direction, allElements) {
    const rect = el.getBoundingClientRect();
    const centerX = (rect.left + rect.right) / 2;
    const centerY = (rect.top + rect.bottom) / 2;
    let bestMatch = null;
    let bestMatchDistance = Infinity;
    allElements.forEach(element => {
        if (element === el)
            return;
        const elementRect = element.getBoundingClientRect();
        let validTarget = false;
        switch (direction) {
            case 'left':
                validTarget = elementRect.right <= rect.left;
                break;
            case 'leftchild':
                validTarget = elementRect.right >= rect.right;
                break;
            case 'right':
                validTarget = elementRect.left >= rect.right;
                break;
            case 'rightchild':
                validTarget = elementRect.left <= rect.left;
                break;
            case 'up':
                validTarget = elementRect.bottom <= rect.top;
                break;
            case 'down':
                validTarget = elementRect.top >= rect.bottom;
                break;
        }
        if (validTarget) {
            const distance = calculateDistance(elementRect, centerX, centerY);
            if (distance < bestMatchDistance) {
                bestMatchDistance = distance;
                bestMatch = element;
            }
        }
    });
    return bestMatch;
}
