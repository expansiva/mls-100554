/// <mls shortName="wcdCommandSelectNext" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export function execute(param) {
    console.info(param.args);
}
