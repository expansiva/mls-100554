/// <mls shortName="wcdOverlayModeStoryHelp" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState } from './_100554_collabState';
let WcdOverlayModeStoryHelp100554 = class WcdOverlayModeStoryHelp100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        globalState._ica = {};
    }
};
WcdOverlayModeStoryHelp100554 = __decorate([
    customElement('wcd-overlay-mode-story-help-100554')
], WcdOverlayModeStoryHelp100554);
export { WcdOverlayModeStoryHelp100554 };
