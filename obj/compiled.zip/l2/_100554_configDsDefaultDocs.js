/// <mls shortName="configDsDefaultDocs" project="100554" enhancement="_blank" groupName="other" />
import { Common } from './_100554_configDsDefaultCommon';
export class Doc {
    constructor(dsIO, ds) {
        this.add = (parentId, title, content) => this._addDoc(parentId, title, content);
        this.update = (id, parentId, title, content) => this._updateDoc(id, parentId, title, content);
        this.remove = (id) => this._removeDoc(id);
        this.find = (id) => this._find(id);
        this.list = {};
        this.ds = ds;
        this._ds = dsIO;
        this.methods = new Common(ds, dsIO);
        this.prepareDocs();
    }
    prepareDocs() {
        this.list = {};
        this.ds.docs.items.forEach((doc) => {
            this._addDoc2(doc);
        });
    }
    _find(id) {
        return this.list[id];
    }
    getLastDocIndex() {
        let lastID = 1;
        for (let i = 0; i < this.ds.docs.items.length; i++) {
            if (this.ds.docs.items[i].id > lastID) {
                lastID = this.ds.docs.items[i].id;
            }
        }
        return lastID;
    }
    async _addDoc(parentID, title, content = 'new document') {
        const fullpath = this.methods.getDocsMlsFilePath();
        const index = this.getLastDocIndex() + 1;
        const doc = {
            id: index,
            parentID,
            title,
            getContent: () => { return Promise.resolve(''); },
            setContent: () => { return Promise.resolve(true); }
        };
        try {
            await this.methods.createNewFile(index.toString(), fullpath, 'txt', content);
            this._addDoc2(doc);
            await this.methods.setContentFileDsMain();
            return Promise.resolve(index);
        }
        catch (err) {
            return Promise.reject(new Error('Error on create new document:' + err.message));
        }
    }
    _addDoc2(doc) {
        doc.getContent = () => this.getDocContent(doc);
        doc.setContent = (newcontent) => this.setDocContent(doc, newcontent);
        this.list[doc.id] = doc;
    }
    async _removeDoc(id) {
        const doc = this.find(id);
        if (!doc)
            throw new Error(`document: ${id} dont exists`);
        const fullpath = this.methods.getDocsMlsFilePath();
        try {
            await this.methods.setContentFile(id.toString(), 'txt', fullpath, null);
            delete this.list[id];
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove document:' + err.message));
        }
    }
    async _updateDoc(id, parentId, title, content) {
        const doc = this.find(id);
        if (!doc)
            throw new Error(`document: ${id} dont exists`);
        const fullpath = this.methods.getDocsMlsFilePath();
        try {
            if (content)
                await this.methods.setContentFile(id.toString(), 'txt', fullpath, content);
            doc.title = title;
            doc.parentID = parentId;
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on update document:' + err.message));
        }
    }
    async getDocContent(doc) {
        const fullpath = this.methods.getDocsMlsFilePath();
        const content = await this.methods.getContentFile(doc.id.toString(), 'txt', fullpath);
        return content;
    }
    async setDocContent(doc, content) {
        const fullpath = this.methods.getDocsMlsFilePath();
        if (content === null) {
            await this._removeDoc(doc.id);
            return true;
        }
        await this.methods.setContentFile(doc.id.toString(), 'txt', fullpath, content);
        return true;
    }
}
