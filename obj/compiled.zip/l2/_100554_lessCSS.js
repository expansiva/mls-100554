/// <mls shortName="lessCSS" project="100554" enhancement="_blank" />
import { LessAst } from "./_100554_lessAST";
import { setState, getState, initState } from './_100554_collabState';
/**
 * A unique symbol used as a key for properties that should be ignored during JSON serialization.
 *
 * Properties defined with this symbol as a key will not appear in the output of `JSON.stringify`,
 * ensuring that the property is excluded from serialization while avoiding key collisions.
 *
 * @const {symbol} ignoredProperty - A unique symbol for marking non-serializable properties.
 */
const _editor = Symbol("ignoredProperty");
export class LessCSS {
    constructor(url, editor, position = "left") {
        this.position = "left";
        this._url = '';
        this.lessAST = new LessAst(url, editor);
        this[_editor] = editor;
        this.selector = '';
        this.position = position;
        this._url = url;
        this.initStateIfNeeded();
        // Initialize CSSStyleDeclaration to provide autocomplete for CSS properties
        const cssDeclaration = document.createElement("div").style;
        // Create a proxy to intercept get/set on `styles`
        this.styles = new Proxy(cssDeclaration, {
            get: (target, property) => {
                // Retrieve the property value from LessCSS's `getProperty` function
                return this.getProperty(property) ?? target[property];
            },
            set: (target, property, value) => {
                // Use `setProperty` to update both AST and Monaco
                this.setProperty(property, value);
                target[property] = value;
                return true;
            }
        });
    }
    setEditor(editor) {
    }
    /**
     * Sets the current selector for which properties will be applied.
     */
    setSelector(selector) {
        this.selector = selector;
    }
    /**
     * Retrieves a specific CSS property value for the current selector from the AST.
     * @param property The CSS property to retrieve
     */
    getProperty(property) {
        return this.lessAST.getProperty(this.selector, property);
    }
    /**
     * Sets or updates a CSS property in the AST and source model.
     * @param property The CSS property to set
     * @param value The new value for the property
     */
    setProperty(property, value) {
        // Update the AST and LESS source model
        this.lessAST.saveProperty(this.selector, property, value);
        // Optional: Fire an event to update the UI if necessary
        // this.fireChangeEvent();
        this.updateState();
    }
    refresh() {
        if (this[_editor]) {
            this.lessAST = new LessAst(this._url, this[_editor]);
        }
        this.setSelector(this.selector);
    }
    setStateByLine(lineNumber, lineContent, emitter) {
        this.refresh();
        const state = getState(`less.${this.position}`);
        if (!state)
            return;
        const selector = this.lessAST.findSelectorByLine(lineNumber);
        if (!selector) {
            this.clearState();
            setState(`less.${this.position}.lineContent`, lineContent);
            return;
        }
        this.setSelector(selector);
        const info = this.lessAST.findInfoByLine(selector, lineNumber);
        setState(`less.${this.position}`, {
            selector: selector,
            lineContent: lineContent,
            key: info?.key,
            value: info?.value,
            emitter: emitter,
            lineNumber: lineNumber,
            lessCSS: this,
        });
    }
    clearState() {
        const state = getState(`less.${this.position}`);
        if (!state)
            return;
        setState(`less.${this.position}.lessCSS`, undefined);
        setState(`less.${this.position}.key`, undefined);
        setState(`less.${this.position}.value`, undefined);
        setState(`less.${this.position}.selector`, undefined);
    }
    updateState() {
        const state = getState(`less.${this.position}`);
        if (!state)
            return;
        setState(`less.${this.position}.lessCSS`, this);
        setState(`less.${this.position}.lessCSS.styles`, this.styles);
    }
    initStateIfNeeded() {
        initState('less', {
            left: {},
            right: {}
        });
        setState(`less.${this.position}`, {
            lessCSS: this,
            emitter: 'editor',
            key: undefined,
            value: undefined,
            lineNumber: undefined,
            selector: undefined,
            uri: this._url,
        });
        //setState(`less.${this.position}`, { ...getState(`less[${this.position}]`) });
    }
}
