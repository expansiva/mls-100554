/// <mls shortName="collabShowCodeDiff" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var CollabShowCodeDiff_1;
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { collab_check, collab_copy, collab_repeat, collab_thumbs_down, collab_thumbs_up, } from './_100554_collabIcons';
import { CollabLitElement } from './_100554_collabLitElement';
export function initCollabShowCodeDiff100554() {
    return true;
}
/// **collab_i18n_start**
const message_pt = {
    diff: 'Com Diferen�a',
    reject: 'Rejeitar',
    tryAgain: 'Tentar Novamente',
    accept: 'Aceitar',
    copy: 'Copiar',
    copied: 'Copiado'
};
const message_en = {
    diff: 'With Diff',
    reject: 'Reject',
    tryAgain: 'Try Again',
    accept: 'Accept',
    copy: 'Copy',
    copied: 'Copied'
};
const messages = {
    'en-us': message_en,
    'pt-br': message_pt
};
/// **collab_i18n_end**
let CollabShowCodeDiff = CollabShowCodeDiff_1 = class CollabShowCodeDiff extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en-us'];
        this.msize = '400.00,420.00,106.00,0';
        this.language = 'typescript';
        this.withCopy = true;
        this.withAccept = false;
        this.withReject = false;
        this.withTryAgain = false;
        this.withDiff = false;
        this.coping = false;
        this.onAccept = () => { console.info('not implement'); };
        this.onReject = () => { console.info('not implement'); };
        this.onTryAgain = () => { console.info('not implement'); };
        this.actualEditor = 'result';
        this.actualTextDiffOriginal = '';
        this.actualTextDiffModified = '';
        this.actualTextResult = '';
    }
    init() {
        if (this.actualEditor === 'diff')
            this.setDiffValue(this.actualTextDiffOriginal, this.actualTextDiffModified);
        else
            this.setResultValue(this.actualTextResult);
    }
    createEditorDiff() {
        if (!this.c1 || this._ed1Diff)
            return;
        if (this._ed1Result) {
            this._ed1Result.dispose();
            this.modelResult?.dispose();
            this._ed1Result = undefined;
            this.modelResult = undefined;
        }
        const opt = {
            automaticLayout: true,
            renderSideBySide: false,
            readOnly: true
        };
        this._ed1Diff = monaco.editor.createDiffEditor(this.c1, opt);
        this.c1['mlsEditor'] = this._ed1Diff;
    }
    createEditorResult() {
        if (!this.c1 || this._ed1Result)
            return;
        if (this._ed1Diff) {
            this._ed1Diff.dispose();
            this.modelDiffModified?.dispose();
            this.modelDiffOriginal?.dispose();
            this._ed1Diff = undefined;
            this.modelDiffModified = undefined;
            this.modelDiffOriginal = undefined;
        }
        const opt = {
            automaticLayout: true,
            readOnly: true
        };
        this._ed1Result = monaco.editor.create(this.c1, opt);
        this.c1['mlsEditor'] = this._ed1Result;
    }
    createModelDiff(editorType, srcOriginal, srcModified) {
        if (!this.modelDiffModified)
            this.modelDiffModified = monaco.editor.createModel(srcModified, editorType);
        else
            this.modelDiffModified.setValue(srcModified);
        if (!this.modelDiffOriginal)
            this.modelDiffOriginal = monaco.editor.createModel(srcOriginal, editorType);
        else
            this.modelDiffOriginal.setValue(srcOriginal);
    }
    createModelResult(editorType, src) {
        if (!this.modelResult)
            this.modelResult = monaco.editor.createModel(src, editorType);
        else
            this.modelResult.setValue(src);
    }
    setDiffValue(srcOriginal, srcModified) {
        this.createEditorDiff();
        this.createModelDiff(this.language, srcOriginal, srcModified);
        if (!this._ed1Diff || !this.modelDiffOriginal || !this.modelDiffModified)
            return;
        this._ed1Diff.setModel({
            original: this.modelDiffOriginal,
            modified: this.modelDiffModified,
        });
        this.actualTextDiffModified = srcModified;
        this.actualTextDiffOriginal = srcOriginal;
    }
    setResultValue(src) {
        this.createEditorResult();
        this.createModelResult(this.language, src);
        if (!this._ed1Result || !this.modelResult)
            return;
        this._ed1Result.setModel(this.modelResult);
        this.actualTextResult = src;
    }
    setMsizeEditor() {
        this.c1?.setAttribute('msize', this.msize);
    }
    onCopyClick() {
        this.coping = true;
        const value = this.actualEditor && this.actualEditor === 'result' ? this.modelResult?.getValue() : this.modelDiffModified?.getValue();
        navigator.clipboard.writeText(value || '');
        setTimeout(() => {
            this.coping = false;
        }, 3000);
    }
    onAcceptClick() {
        if (this.onAccept && typeof this.onAccept === 'function') {
            this.onAccept();
        }
    }
    onRejectClick() {
        if (this.onReject && typeof this.onReject === 'function') {
            this.onReject();
        }
    }
    onTryAgainClick() {
        if (this.onTryAgain && typeof this.onTryAgain === 'function') {
            this.onTryAgain();
        }
    }
    async getCssMonaco() {
        const cssPath = `../../../monaco/${window.latest?.monaco}/monaco.css`;
        const response = await fetch(cssPath);
        const cssText = await response.text();
        return cssText;
    }
    async loadCSS() {
        if (this.styleElement)
            return;
        let cssText = '';
        if (CollabShowCodeDiff_1.monaco_css)
            cssText = CollabShowCodeDiff_1.monaco_css;
        else if (CollabShowCodeDiff_1.inLoadingCss) {
            cssText = await CollabShowCodeDiff_1.loadingPromise;
        }
        else {
            CollabShowCodeDiff_1.inLoadingCss = true;
            CollabShowCodeDiff_1.loadingPromise = this.getCssMonaco();
            cssText = await CollabShowCodeDiff_1.loadingPromise;
            CollabShowCodeDiff_1.monaco_css = cssText;
            CollabShowCodeDiff_1.inLoadingCss = false;
        }
        if (!cssText)
            return;
        this.styleElement = document.createElement('style');
        this.styleElement.innerHTML = CollabShowCodeDiff_1.monaco_css;
        this.shadowRoot?.appendChild(this.styleElement);
    }
    renderWithCopy() {
        return html `
            <div @click=${this.onCopyClick} class="action-item" style="display:${this.coping ? 'none' : 'flex'}">
                ${collab_copy}
                <span>${this.msg.copy}</span>
            </div>
            <div class="action-item copied" style="display:${this.coping ? 'flex' : 'none'}">
                ${collab_check}
                <span>${this.msg.copied}</span>
            </div>
            `;
    }
    renderWithAccept() {
        return html `
            <div @click=${this.onAcceptClick} class="action-item ${!this.withAccept ? 'disabled' : ''}">
                ${collab_thumbs_up}
                <span>${this.msg.accept}</span>
            </div>
        `;
    }
    renderTryAgain() {
        return html `
            <div @click=${this.onTryAgainClick} class="action-item ${!this.withTryAgain ? 'disabled' : ''}">
                ${collab_repeat}
                <span>${this.msg.tryAgain}</span>
            </div>
        `;
    }
    renderReject() {
        return html `
            <div @click=${this.onRejectClick} class="action-item ${!this.withReject ? 'disabled' : ''}">
                ${collab_thumbs_down}
                <span>${this.msg.reject}</span>
            </div>
        `;
    }
    handleChangeDiff() {
        if (!this.inputDiff)
            return;
        if (this.inputDiff.checked) {
            this.actualEditor = 'diff';
            this.createEditorDiff();
            this.setDiffValue(this.actualTextDiffOriginal, this.actualTextDiffModified);
        }
        else {
            this.actualEditor = 'result';
            this.createEditorResult();
            this.setResultValue(this.actualTextResult);
        }
    }
    renderShowDiff() {
        return html `
            <div class="${!this.withDiff ? 'disabled' : ''}">
                <input @change=${this.handleChangeDiff} id="diff_check" type="checkbox"></input>
                <label for="diff_check">${this.msg.diff}<label>
            </div>
        `;
    }
    firstUpdated() {
        this.loadCSS();
        this.dispatchEvent(new CustomEvent('show-diff-ready'));
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="actions">
                    <span class="language">${this.language}</span>
                
                    <div class="actions-list">
                        ${this.renderShowDiff()}
                        ${this.renderWithAccept()}
                        ${this.renderReject()}
                        ${this.renderTryAgain()}
                        ${this.withCopy ? this.renderWithCopy() : ''}
                    </div>
            </div>

            <mls-editor-100529 style="display: block;height:600px;" ismls2="true"></mls-editor-100529>
    `;
    }
};
CollabShowCodeDiff.monaco_css = '';
CollabShowCodeDiff.inLoadingCss = false;
CollabShowCodeDiff.styles = css `
      :host{
        display:block;
      }
      .actions{
        height:30px; 
        background: #b4b4b4; 
        display:flex; 
        align-items:center;
        padding:0 1rem; 
        color:#fff;
        .actions-list{
          display:flex;
          gap:1rem;
        }
      }
      .language {
        flex:1;
      }
      
      .action-item{

        user-select: none;
        display:flex; 
        align-items:center;
        justify-content: center;
        cursor:pointer;
        min-width: 50px;
      }
      .disabled {
        cursor:default;
        text-decoration: line-through;
        pointer-events: none;
      }
      .copied{
        cursor:default;
        pointer-events: none;
      }
    `;
__decorate([
    property({ type: String })
], CollabShowCodeDiff.prototype, "msize", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabShowCodeDiff.prototype, "language", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabShowCodeDiff.prototype, "withCopy", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabShowCodeDiff.prototype, "withAccept", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabShowCodeDiff.prototype, "withReject", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabShowCodeDiff.prototype, "withTryAgain", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabShowCodeDiff.prototype, "withDiff", void 0);
__decorate([
    property({ type: Boolean })
], CollabShowCodeDiff.prototype, "coping", void 0);
__decorate([
    query('mls-editor-100529')
], CollabShowCodeDiff.prototype, "c1", void 0);
__decorate([
    query('#diff_check')
], CollabShowCodeDiff.prototype, "inputDiff", void 0);
CollabShowCodeDiff = CollabShowCodeDiff_1 = __decorate([
    customElement('collab-show-code-diff-100554')
], CollabShowCodeDiff);
export { CollabShowCodeDiff };
