/// <mls shortName="pluginStyleColumn" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, queryAll } from 'lit/decorators.js';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
import { IcaLitElement, propertyDataSource } from './_100554_icaLitElement';
import { getMessageKey } from './_100554_collabLitElement';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
import { convertColorToHex } from './_100554_libCommom';
/// **collab_i18n_start**
const message_pt = {
    columnsCount: 'Contagem de coluna',
    columnsWidth: 'Largura das colunas',
    columnsGap: 'Lacuna de colunas',
    columnsRule: 'Regra de Coluna',
    columnSpan: 'Espanço da coluna',
    breakInside: 'Quebre por dentro',
    description: 'Este plugin permite criar e ajustar colunas de texto de forma prática e eficiente. Com ele, é possível definir o número de colunas, o espaçamento entre elas e outros detalhes de formatação, proporcionando um layout organizado e facilitando a leitura.'
};
const message_en = {
    columnsCount: 'Columns Count',
    columnsWidth: 'Columns Width',
    columnsGap: 'Columns Gap',
    columnsRule: 'Columns Rule',
    columnSpan: 'Column Span',
    breakInside: 'Break Inside',
    description: 'This plugin allows for easy and efficient creation and adjustment of text columns. It lets you set the number of columns, spacing between them, and other formatting details, providing an organized layout and enhancing readability.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['column*', 'break-inside'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleColumn = class PluginStyleColumn extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-column-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-column-100554 .helper-group-title{margin:0;margin-top:var(--space-16);margin-bottom:var(--space-8);display:flex;gap:1.5rem}plugin-style-column-100554 details summary{cursor:pointer}plugin-style-column-100554 details>div{margin-left:var(--space-16)}plugin-style-column-100554 .group{margin-bottom:var(--space-8);display:flex;flex-direction:column;font-size:var(--font-size-12)}plugin-style-column-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-column-100554 .group .group-edit .group-select{display:block;font-size:1rem;background-color:#fff;background-clip:padding-box;border:1px solid #b5b4b4;border-radius:.25rem;transition:border-color .15s ease-in-out 0s,box-shadow .15s ease-in-out 0s;outline:none}plugin-style-column-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-column-100554 .gallery{margin-bottom:var(--space-16);display:flex;justify-content:start;align-items:center;gap:1rem;padding-top:1rem;flex-wrap:wrap;cursor:pointer}plugin-style-column-100554 .gallery .gallery-item{width:150px;height:120px;font-size:60%;border:1px solid #c3c3c3;padding:1rem;zoom:.5}`);
        this.showFull = 'true';
        this.position = 'left';
        this.msg = messages['en'];
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.tpBorder = ['none', 'solid', 'dotted', 'dashed', 'double', 'groove', 'ridge', 'inset', 'outset', 'hidden', 'inherit', 'initial', 'unset'];
        this.timeonChange = -1;
        this.gallery = [
            {
                style: 'column-count: 2;',
                state: {
                    breakInside: '',
                    columnCount: '2',
                    columnGap: '',
                    columnRuleColor: '',
                    columnRuleStyle: '',
                    columnRuleWidth: '',
                    columnSpan: '',
                    columnWidth: '',
                }
            },
            {
                style: 'column-count: 3;',
                state: {
                    breakInside: '',
                    columnCount: '3',
                    columnGap: '',
                    columnRuleColor: '',
                    columnRuleStyle: '',
                    columnRuleWidth: '',
                    columnSpan: '',
                    columnWidth: '',
                }
            },
            {
                style: 'column-count: 2; column-gap: 20px; column-rule-width: 1px; column-rule-style: dashed;',
                state: {
                    breakInside: '',
                    columnCount: '2',
                    columnGap: '20px',
                    columnRuleColor: '',
                    columnRuleStyle: 'dashed',
                    columnRuleWidth: '1px',
                    columnSpan: '',
                    columnWidth: '',
                }
            }, {
                style: 'column-count: 2; column-rule-width: 1px; column-rule-style: solid;',
                state: {
                    breakInside: '',
                    columnCount: '2',
                    columnGap: '',
                    columnRuleColor: '',
                    columnRuleStyle: 'solid',
                    columnRuleWidth: '1px',
                    columnSpan: '',
                    columnWidth: '',
                }
            }
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        this._onIcaStateChange();
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    setValues(rule) {
        const props = ['column-count', 'column-width', 'column-gap', 'column-span', 'column-rule-color', 'column-rule-style', 'column-rule-width', 'break-inside'];
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (props.includes(propertyName)) {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                }
            }
        }
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    setColumnRuleValues() {
        const aux = {
            'column-rule': (value) => { this.columnRule = value; },
        };
        this.columnRuleInputs?.forEach((bdInp) => {
            const prop = bdInp.getAttribute('prop');
            if (!prop)
                return;
            aux[prop](bdInp.value);
        });
    }
    setState() {
        this.setColumnRuleValues();
        window.globalState.less[this.position].emitter = 'helper';
        const styles = window.globalState.less[this.position].lessCSS.styles;
        styles.columnCount = this.columnCount || '';
        styles.columnGap = this.columnGap || '';
        styles.columnSpan = this.columnSpan || '';
        styles.columnWidth = this.columnWidth || '';
        styles.columnRuleColor = this.columnRuleColor || '';
        styles.columnRuleStyle = this.columnRuleStyle || '';
        styles.columnRuleWidth = this.columnRuleWidth || '';
        styles.breakInside = this.breakInside || '';
    }
    handleChange(e) {
        console.info('handleChange');
        clearTimeout(this.timeonChange);
        const el = e.detail ? e.detail.target : e.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(prop);
        if (!convertedProp)
            return;
        this.timeonChange = setTimeout(() => {
            if (convertedProp === 'columnRule') {
                this.columnRuleWidth = el.valueInput;
                this.columnRuleColor = el.valueColor;
                this.columnRuleStyle = el.valueSelect;
            }
            else
                this[convertedProp] = el.value;
            this.setState();
        }, 100);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
             ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderColumn()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderColumn() {
        return html `
            <div>
                <div class="group">
                    <span>${this.msg.columnsCount}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554 
                        prop="column-count" 
                        value=${this.columnCount}
                        useSelect="false" 
                        @onchange=${(e) => this.handleChange(e)}
                        ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.columnsWidth}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554
                        prop="column-width"
                        value=${this.columnWidth}
                        .arraySelect=${this.tpMeasures}  
                        @onchange=${(e) => this.handleChange(e)}
                        ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.columnsGap}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554
                        prop="column-gap" 
                        value=${this.columnGap}
                        .arraySelect=${this.tpMeasures} 
                        @onchange=${(e) => this.handleChange(e)}
                        ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.columnsRule}</span>
                    <div class="group-edit">
                        <collab-ds-input-select-color-100554
                        prop="column-rule" 
                        _valueInput=${this.columnRuleWidth}
                        _valueSelect=${this.columnRuleStyle}
                        _valueColor=${convertColorToHex(this.columnRuleColor || '')}
                        .arrayInputSelect=${this.tpMeasures} 
                        .arraySelect=${this.tpBorder} 
                        @onchange=${(e) => this.handleChange(e)}
                        ></collab-ds-input-select-color-100554>
                    </div>

                    <span>${this.msg.columnSpan}</span>
                    <div class="group-edit">
                        <select 
                            class="group-select"  
                            prop="column-span"
                            .value=${this.columnSpan}
                            @change=${(e) => this.handleChange(e)}
                        >
                                <option value=""></option>
                                <option value="none" ?selected=${this.columnSpan === 'none'}>none </option>
                                <option value="all" ?selected=${this.columnSpan === 'all'} >all</option>
                                <option value="inherit" ?selected=${this.columnSpan === 'inherit'}inherit</option>
                                <option value="initial" ?selected=${this.columnSpan === 'initial'}>initial</option>
                                <option value="unset" ?selected=${this.columnSpan === 'unset'}>unset</option>
                        </select>   
                    </div>
                    
                    <span>${this.msg.breakInside}</span>
                    <div class="group-edit">
                        <select 
                            class="group-select"  
                            prop="break-inside"      
                            .value=${this.breakInside}
                            @change=${(e) => this.handleChange(e)}
                        >
                            <option value=""></option>
                            <option value="none" ?selected=${this.breakInside === 'none'}>none</option>
                            <option value="auto" ?selected=${this.breakInside === 'auto'}>auto</option>
                            <option value="avoid" ?selected=${this.breakInside === 'avoid'}>avoid</option>
                            <option value="avoid-page" ?selected=${this.breakInside === 'avoid-page'}>avoid-page</option>
                            <option value="avoid-column" ?selected=${this.breakInside === 'avoid-column'}>avoid-column</option>
                            <option value="avoid-region" ?selected=${this.breakInside === 'avoid-region'}>avoid-region</option>
                            <option value="inherit" ?selected=${this.breakInside === 'inherit'}>inherit</option>
                            <option value="initial" ?selected=${this.breakInside === 'initial'}>initial</option>
                            <option value="unset" ?selected=${this.breakInside === 'unset'}>unset</option>
                        </select>   
                    </div>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
             ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `
                        <h5 class="gallery-item" style="${galleryItem.style}" @click=${() => { this.onGalleryClick(galleryItem); }} >Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor incididunt ut labore et dolore.</h5>
                        `;
        }))}
            </div>
        
        `;
    }
    async onGalleryClick(item) {
        this.breakInside = item.state.breakInside;
        this.columnCount = item.state.columnCount;
        this.columnGap = item.state.columnGap;
        this.columnRuleColor = item.state.columnRuleColor;
        this.columnRuleStyle = item.state.columnRuleStyle;
        this.columnRuleWidth = item.state.columnRuleWidth;
        this.columnSpan = item.state.columnSpan;
        this.columnWidth = item.state.columnWidth;
        await this.updateComplete;
        this.setState();
    }
};
__decorate([
    property()
], PluginStyleColumn.prototype, "showFull", void 0);
__decorate([
    propertyDataSource()
], PluginStyleColumn.prototype, "state", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "position", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnCount", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnWidth", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnGap", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnSpan", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnRule", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnRuleColor", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnRuleStyle", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "columnRuleWidth", void 0);
__decorate([
    property()
], PluginStyleColumn.prototype, "breakInside", void 0);
__decorate([
    queryAll('collab-ds-input-select-color-100554')
], PluginStyleColumn.prototype, "columnRuleInputs", void 0);
PluginStyleColumn = __decorate([
    customElement('plugin-style-column-100554')
], PluginStyleColumn);
export { PluginStyleColumn };
