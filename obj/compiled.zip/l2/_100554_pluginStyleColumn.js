/// <mls shortName="pluginStyleColumn" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement, getMessageKey } from './_100554_collabLitElement';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    columnsCount: 'Contagem de coluna',
    columnsWidth: 'Largura das colunas',
    columnsGap: 'Lacuna de colunas',
    columnsRule: 'Regra de Coluna',
    columnSpan: 'Espanço da coluna',
    breakInside: 'Quebre por dentro',
    description: 'Este plugin permite criar e ajustar colunas de texto de forma prática e eficiente. Com ele, é possível definir o número de colunas, o espaçamento entre elas e outros detalhes de formatação, proporcionando um layout organizado e facilitando a leitura.'
};
const message_en = {
    columnsCount: 'Columns Count',
    columnsWidth: 'Columns Width',
    columnsGap: 'Columns Gap',
    columnsRule: 'Columns Rule',
    columnSpan: 'Column Span',
    breakInside: 'Break Inside',
    description: 'This plugin allows for easy and efficient creation and adjustment of text columns. It lets you set the number of columns, spacing between them, and other formatting details, providing an organized layout and enhancing readability.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['column*'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleColumn = class PluginStyleColumn extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-column-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-column-100554 .helper-group-title{margin:0;margin-top:var(--space-16);margin-bottom:var(--space-8);display:flex;gap:1.5rem}plugin-style-column-100554 details summary{cursor:pointer}plugin-style-column-100554 details>div{margin-left:var(--space-16)}plugin-style-column-100554 .group{margin-bottom:var(--space-8);display:flex;flex-direction:column;font-size:var(--font-size-12)}plugin-style-column-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-column-100554 .group .group-edit .group-select{display:block;font-size:1rem;background-color:#fff;background-clip:padding-box;border:1px solid #b5b4b4;border-radius:.25rem;transition:border-color .15s ease-in-out 0s,box-shadow .15s ease-in-out 0s;outline:none}plugin-style-column-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-column-100554 .gallery{margin-bottom:var(--space-16);display:flex;justify-content:start;align-items:center;gap:1rem;padding-top:1rem;flex-wrap:wrap;cursor:pointer}plugin-style-column-100554 .gallery .gallery-item{width:150px;height:120px;font-size:60%;border:1px solid #c3c3c3;padding:1rem;zoom:.5}`);
        this.showFull = 'true';
        this.msg = messages['en'];
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.tpBorder = ['none', 'solid', 'dotted', 'dashed', 'double', 'groove', 'ridge', 'inset', 'outset', 'hidden', 'inherit', 'initial', 'unset'];
        this.arrayGallery = [
            '',
            'column-count: 2;',
            'column-count: 2; column-gap: 20px; column-rule-width: 1px; column-rule-style: dashed;',
            'column-count: 3;',
            'column-count: 2; column-rule-width: 1px; column-rule-style: solid;'
        ];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
             ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderColumn()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderColumn() {
        return html `
            <div>
                <div class="group">
                    <span>${this.msg.columnsCount}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554 prop="column-count" value="0px" useSelect="false" ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.columnsWidth}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554 prop="column-width" value="0px" .arraySelect=${this.tpMeasures}  ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.columnsGap}</span>
                    <div class="group-edit">
                        <collab-ds-input-range-100554 prop="column-gap" value="0px" .arraySelect=${this.tpMeasures}  ></collab-ds-input-range-100554>
                    </div>

                    <span>${this.msg.columnsRule}</span>
                    <div class="group-edit">
                        <collab-ds-input-select-color-100554 prop="column-rule" valueInput="0px" .arrayInputSelect=${this.tpMeasures} .arraySelect=${this.tpBorder} valueSelect="none" group="border" ></collab-ds-input-select-color-100554>
                    </div>

                    <span>${this.msg.columnSpan}</span>
                    <div class="group-edit">
                        <select class="group-select"  prop="column-span">
                            <option value=""></option>
                            <option value="row">Row</option>
                            <option value="row-reverse">Row Reverse</option>
                            <option value="column">Column</option>
                            <option value="column-reverse">Column Reverse</option>
                        </select>   
                    </div>
                    
                    <span>${this.msg.breakInside}</span>
                    <div class="group-edit">
                        <select class="group-select"  prop="break-inside">
                            <option value=""></option>
                            <option value="none">none</option>
                            <option value="auto">auto</option>
                            <option value="avoid">avoid</option>
                            <option value="avoid-page">avoid-page</option>
                            <option value="avoid-column">avoid-column</option>
                            <option value="avoid-region">avoid-region</option>
                            <option value="inherit">inherit</option>
                            <option value="initial">initial</option>
                            <option value="unset">unset</option>
                        </select>   
                    </div>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
             ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `
                        <h5 class="gallery-item" style="${css}" .gallery=${css}>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor incididunt ut labore et dolore.</h5>
                        `;
        }))}
            </div>
        
        `;
    }
};
__decorate([
    property()
], PluginStyleColumn.prototype, "showFull", void 0);
PluginStyleColumn = __decorate([
    customElement('plugin-style-column-100554')
], PluginStyleColumn);
export { PluginStyleColumn };
