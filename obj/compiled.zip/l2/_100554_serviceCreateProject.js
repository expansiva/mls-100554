/// <mls shortName="serviceCreateProject" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, queryAll } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { collab_check, collab_xmark, collab_lock } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    createProjectTitle: 'Criar projeto',
    createProjectHelper: 'Por favor escolha o tipo de projeto abaixo e pressione continuar.',
    labelName: 'Nome do projeto',
    labelDescription: 'Descrição',
    alertNoSelect: 'Por favor selecione um tipo de projeto',
    btnContinuar: 'Continuar',
    btnCreate: 'Criar projeto(Em desenvolvimento)',
    errorContinue: 'Selecione o tipo de site antes',
    detailsSystem: 'Sistema',
    detailsPluginsStorage: 'Plugins de armazenamento',
    detailsPluginsPublish: 'Plugins de publicação',
    alert: 'Em desenvolvimento',
};
const message_en = {
    createProjectTitle: 'Create project',
    createProjectHelper: 'Please choose your project type below and press continue.',
    labelName: 'Project name',
    labelDescription: 'Description',
    alertNoSelect: 'Please select project type',
    btnContinuar: 'Continue',
    btnCreate: 'Create Project (In develpoment)',
    errorContinue: 'Select the site type first',
    detailsSystem: 'System',
    detailsPluginsStorage: 'Storage plugins',
    detailsPluginsPublish: 'Publish plugins',
    alert: 'In develpoment'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceCreateProject100554 = class ServiceCreateProject100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.currentScenario = 'select';
        this.details = {
            icon: '&#xf15b',
            state: 'background',
            position: 'left',
            tooltip: 'Create project',
            visible: true,
            widget: '_100554_serviceCreateProject',
            level: [6]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: this.msg.createProjectTitle,
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickTitle: this.onClickTitle.bind(this),
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.data = [
            {
                title: "Blog / Institucional",
                mode: "site",
                description: "Ex: sites pessoais / comerciais com dados estáticos",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: false,
                appMobileAndroid: false,
                backend: false,
                multilanguage: true
            },
            {
                title: "Plataforma de publicação conteúdo(em desenvolvimento)",
                mode: "site",
                description: "Ex: Medium, Youtube, Vimeo",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: false,
                appMobileAndroid: false,
                backend: false,
                multilanguage: true
            },
            {
                title: "Portfólio / CMS(em desenvolvimento)",
                mode: "site",
                description: "sites pessoais ou comerciais com apresentação serviços produtos",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "Landing Page(em desenvolvimento)",
                mode: "site",
                description: "Captura de usuários e vendas produtos/serviços ",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "Educacional(em desenvolvimento)",
                mode: "site",
                description: "distribuição cursos e gestão alunos",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "E-Commerce(em desenvolvimento)",
                mode: "site",
                description: "Loja online de vendas",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "Educacional(em desenvolvimento)",
                mode: "site",
                description: "Ex: sites pessoais / comerciais com dados estáticos",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "B2B , B2C (Vendas)(em desenvolvimento)",
                mode: "site",
                description: "Ex: Amazon, Alibaba",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "ERP ( BackOffice)(em desenvolvimento)",
                mode: "site",
                description: "Ex: SAP, Oracle ERP",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "Plugins(em desenvolvimento)",
                mode: "system",
                description: "Pacote de plugins para o sistema",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            },
            {
                title: "Pacote de Componentes(em desenvolvimento)",
                mode: "system",
                description: "Pacote de componentes para o sistema",
                more: "Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.Lorem ipsum dolor sit amet. Quo vitae omnis qui sunt officiis qui dolor assumenda a officia quia. Ab nihil inventore sed accusamus quaerat At velit quidem qui molestias quidem est rerum labore aut officiis ratione! Rem assumenda quod ut consequatur voluptatem qui aliquam suscipit. Qui quia eveniet et atque animi id voluptatem natus et enim laudantium aut laboriosam ratione.Sit tenetur pariatur sit iure accusantium et accusamus tenetur ut fugit consequatur eum eligendi velit sed sunt nobis et perspiciatis incidunt. Aut explicabo maxime non animi autem rem repudiandae labore eum aliquam quis.",
                web: true,
                mobile: true,
                appMobileIOS: true,
                appMobileAndroid: true,
                backend: true,
                multilanguage: true
            }
        ];
        this.pluginsPublish = [
            {
                type: 'free',
                title: 'Download site',
                description: 'Permite baixar o site na máquina local e instalar em um provedor, requer conhecimentos técnicos',
                enabled: true,
                details: [
                    {
                        enabled: true,
                        item: 'Alto controle'
                    },
                    {
                        enabled: true,
                        item: 'Integrar com sites existentes'
                    }
                ]
            },
            {
                type: 'pro',
                title: 'GitHub',
                description: 'Permite publicar e usar sites no github.io , exemplo: meusite.github.io',
                enabled: false,
                details: [
                    {
                        enabled: true,
                        item: 'Free'
                    },
                    {
                        enabled: true,
                        item: 'DNS'
                    }
                ]
            },
            {
                type: 'pro',
                title: 'S3 - site estático',
                description: 'Permite usar um serviço que cobra pelo que utiliza, econômico, muito escalável, e com o DNS personalizado, ex: meusite.com',
                enabled: false,
                details: [
                    {
                        enabled: true,
                        item: 'Econômico'
                    },
                    {
                        enabled: true,
                        item: 'Escalável'
                    }
                ]
            }
        ];
        this.pluginsStorage = [
            {
                type: 'free',
                title: 'Armazenamento Local',
                description: 'Permite baixar o site na máquina local e instalar em um provedor, requer conhecimentos técnicos',
                enabled: true,
                details: [
                    {
                        enabled: false,
                        item: 'Backup'
                    },
                    {
                        enabled: false,
                        item: 'Histórico'
                    }
                ]
            },
            {
                type: 'pro',
                title: 'GitHub',
                description: 'Permite controle de versão robusto, integração contínua, revisões de código,  acessível de qualquer lugar, aumentando a produtividade e a segurança do código',
                enabled: false,
                details: [
                    {
                        enabled: true,
                        item: 'Backup'
                    },
                    {
                        enabled: true,
                        item: 'Histórico'
                    }
                ]
            },
            {
                type: 'pro',
                title: 'GitLab',
                description: 'Semelhante ao GitHub, permite também a instalação em servidores próprios, útil para empresas com muitos desenvolvedores simultâneos e que querem um serviço dedicado',
                enabled: false,
                details: [
                    {
                        enabled: true,
                        item: 'Backup'
                    },
                    {
                        enabled: true,
                        item: 'Histórico'
                    }
                ]
            },
        ];
        this.setEvents();
    }
    onClickTitle() {
        this.changeScenario('select');
        this.actualSiteSelected = undefined;
        this.menu.title = {
            icon: '',
            text: this.msg.createProjectTitle,
        };
        if (this.menu.updateTitle)
            this.menu.updateTitle();
    }
    onServiceClick(visible, reinit, el) {
        if (visible === true)
            this.setFullScreen(6, 'left');
        else
            this.setFullScreen(6, 'default');
    }
    changeScenario(scenario) {
        this.currentScenario = scenario;
    }
    onBtnContinueClick() {
        if (!this.actualSiteSelected) {
            this.setError(this.msg.errorContinue);
            return;
        }
        this.menu.title = {
            icon: '&#xf053',
            text: this.msg.createProjectTitle
        };
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        this.scrollTop = 0;
        this.changeScenario('customize');
    }
    onBtnCreateClick() {
        alert(this.msg.alert);
    }
    onTypeSiteClick(item, el) {
        if (this.sitesItems)
            this.sitesItems.forEach((item) => item.classList.remove('selected'));
        if (el) {
            const tr = el.closest('.tr-item');
            tr?.classList.toggle('selected');
        }
        this.actualSiteSelected = item;
    }
    onPluginPublishClick(item, el) {
        const card = el.closest('.card-item');
        if (!item.enabled) {
            card?.classList.add('shake');
            setTimeout(() => card?.classList.remove('shake'), 1000);
            return;
        }
        if (this.publishItems)
            this.publishItems.forEach((item) => item.classList.remove('selected'));
        if (card)
            card.classList.toggle('selected');
    }
    onPluginStorageClick(item, el) {
        const card = el.closest('.card-item');
        if (!item.enabled) {
            card?.classList.add('shake');
            setTimeout(() => card?.classList.remove('shake'), 1000);
            return;
        }
        if (this.storageItems)
            this.storageItems.forEach((item) => item.classList.remove('selected'));
        if (card)
            card.classList.toggle('selected');
    }
    setEvents() {
        mls.events.addEventListener([6], ['ProjectCreate'], (details) => {
            this.openService('_100554_serviceCreateProject', 'left', 6);
        });
    }
    renderSelect() {
        return html `
            <div class="select-type-project">
                <span>${this.msg.createProjectHelper}</span>
                <div class="buttons-container left">
                    <button @click=${this.onBtnContinueClick}>${this.msg.btnContinuar}</button>
                </div>

                <hr>
                <div class="cols">
                    <div class="col-left">
                        <details open>
                            <summary>Sites</summary>
                            <div>
                                <table>
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th>Web</th>
                                            <th>Mobile Responsive</th>
                                            <th>App IOS</th>
                                            <th>App Android</th>
                                            <th>App Backend</th>
                                            <th>Multi Language</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${this.data.map((item) => {
            return item.mode === 'system' ? '' : html `
                                                <tr class="tr-item" @click=${(e) => { this.onTypeSiteClick(item, e.target); }}>
                                                    <td><span>${item.title}</span> <br><small> ${item.description} </small></td>
                                                    <td>${item.web === true ? collab_check : collab_xmark} </td>
                                                    <td>${item.mobile === true ? collab_check : collab_xmark} </td>
                                                    <td>${item.appMobileIOS === true ? collab_check : collab_xmark} </td>
                                                    <td>${item.appMobileAndroid === true ? collab_check : collab_xmark} </td>
                                                    <td>${item.backend === true ? collab_check : collab_xmark} </td>
                                                    <td>${item.multilanguage === true ? collab_check : collab_xmark} </td>                                
                                                </tr>
                                                `;
        })}
                                    </tbody>
                                </table>
                            </div>
                        </details>

                        <details open>
                            <summary>${this.msg.detailsSystem}</summary>
                            <div>
                                <ul>
                                    ${this.data.map((item) => {
            return item.mode === 'site' ? '' : html `
                                                <li class="tr-item" @click=${(e) => { this.onTypeSiteClick(item, e.target); }}>
                                                    <span>${item.title}</span> 
                                                    <br>
                                                    <small> ${item.description} </small>                            
                                                </li>
                                                `;
        })}
                                </ul>
                            </div>
                        </details>
                    </div>

                    <div class="col-right">
                        <div class="details-selected-item">
                            <div>
                                <span class="details-title">${this.actualSiteSelected?.title}</span>
                                <span class="details-more">${this.actualSiteSelected?.more}</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="buttons-container">
                    <button @click=${this.onBtnContinueClick}>${this.msg.btnContinuar}</button>
                </div>

            </div>

        `;
    }
    renderCustomize() {
        return html `
            <div class="details-new-project">
                <details open>
                    <summary>Resume</summary>
                    <div>
                        <ul>
                            <li>
                                <div class="container-input">
                                    <span>Id:</span>
                                    <input value="101001" readonly></input>
                                </div>
                            </li>
                            <li></li>
                                <div class="container-input">
                                    <span>${this.msg.labelName}:</span>
                                    <input value="Test"></input>
                                </div>

                            <li>
                                <div class="container-input">
                                    <span>${this.msg.labelDescription}:</span>
                                    <textarea rows=6></textarea>
                                </div>
                            </li>
                        </ul>
                    </div>
                </details>
                
                <details open>
                    <summary>${this.msg.detailsPluginsPublish}</summary>
                    <div>
                        <div class="card-list">
                            ${this.pluginsPublish.map((item, index) => {
            return html `
                                <div
                                    class="card-item publish-item  ${!item.enabled ? 'disabled' : ''}  ${index === 0 ? 'selected' : ''}"
                                    @click=${(e) => { this.onPluginPublishClick(item, e.target); }}
                                >
                                    ${!item.enabled ? html `<span class="card-lock">${collab_lock}</span>` : ''}
                                    <span class="card-type ${item.type}">${item.type}</span>
                                    <span class="card-title">${item.title}</span>
                                    <span class="card-desc">${item.description}</span>
                                    <div class="card-details" >
                                        <ul>   
                                            ${item.details.map((details) => {
                return html `
                                                    <li>
                                                        <span>${details.enabled === true ? collab_check : collab_xmark} </span>                                
                                                        <span>${details.item}</span>
                                                        
                                                    </li>
                                                
                                                `;
            })}
                                        </ul>
                                    </div>
                                </div>
                                `;
        })}
                        </div>
                    </div>
                </details>
                <details open>
                    <summary>${this.msg.detailsPluginsStorage}</summary>
                    <div>
                        <div class="card-list" >
                            ${this.pluginsStorage.map((item, index) => {
            return html `
                                <div class="card-item storage-item ${!item.enabled ? 'disabled' : ''} ${index === 0 ? 'selected' : ''}"
                                 @click=${(e) => { this.onPluginStorageClick(item, e.target); }}>

                                    ${!item.enabled ? html `<span class="card-lock">${collab_lock}</span>` : ''}
                                    <span class="card-type ${item.type}">${item.type}</span>
                                    <span class="card-title">${item.title}</span>
                                    <span class="card-desc">${item.description}</span>
                                    <div class="card-details">
                                        <ul>   
                                            ${item.details.map((details) => {
                return html `
                                                    <li>
                                                        <span>${details.enabled === true ? collab_check : collab_xmark} </span>                                
                                                        <span>${details.item}</span>
                                                        
                                                    </li>
                                                
                                                `;
            })}
                                        </ul>
                                    </div>
                                </div>
                                `;
        })}
                        </div>
                    </div>
                </details>
            </div>

            <div class="buttons-container">
                <button @click=${this.onBtnCreateClick}>${this.msg.btnCreate}</button>
            </div>
        `;
    }
    renderScenario() {
        switch (this.currentScenario) {
            case 'select':
                return html `
                    ${this.renderSelect()}
                `;
            case 'customize':
                return html `
                    ${this.renderCustomize()}
                `;
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <section>
                ${this.renderScenario()}
            </section>
        `;
    }
};
ServiceCreateProject100554.styles = css `html{font-family:var(--font-family-primary);line-height:1.15}body{margin:0 !important;font-size:20px;font-weight:400;line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);font-family:'Cambria',serif}h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:.5rem}hr{box-sizing:content-box;height:0;overflow:visible;margin-top:1rem;border-width:1px 0px 0px;border-right-style:initial;border-bottom-style:initial;border-left-style:initial;border-right-color:initial;border-bottom-color:initial;border-left-color:initial;border-image:initial;border-top-style:solid;border-top-color:rgba(0,0,0,0.1);margin-bottom:1rem}button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}button:hover{background-color:var(--grey-color-light)}summary{cursor:pointer}input,select,textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}table{width:100%;margin-bottom:1rem;color:#212529}table th,table td{padding:.75rem;vertical-align:top;border-top:1px solid #dee2e6}table thead th{vertical-align:bottom;border-bottom:2px solid #dee2e6}table tbody+tbody{border-top:2px solid #dee2e6}.fa{display:inline-block}.fa.fa-file{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' height='1em' viewBox='0 0 384 512'><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M0 64C0 28.7 28.7 0 64 0H224V128c0 17.7 14.3 32 32 32H384V448c0 35.:host(.7) 64-64 64H64c-35.3 0-64-28.7-64-64V64zm384 64H256V0L384 128z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-location-dot{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z' fill='rgb(135,206,250,1)'/></svg>");background-repeat:no-repeat;width:16px;height:16px;background-position-y:center;background-position-x:50%}.fa.fa-rotate-left{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M48.5 224H40c-13.3 0-24-10.7-24-24V72c0-9.7 5.8-18.5 14.8-22.2s19.3-1.7 26.2 5.2L98.6 96.6c87.6-86.5 228.7-86.2 315.8 1c87.5 87.5 87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3c-62.2-62.2-162.7-62.5-225.3-1L185 183c6.9 6.9 8.9 17.2 5.2 26.2s-12.5 14.8-22.2 14.8H48.5z'/></svg>");background-repeat:no-repeat;width:16px;height:16px;background-position-y:center}.fa.fa-bug{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M256 0c53 0 96 43 96 96v3.6c0 15.7-12.7 28.4-28.4 28.4H188.4c-15.7 0-28.4-12.7-28.4-28.4V96c0-53 43-96 96-96zM41.4 105.4c12.5-12.5 32.8-12.5 45.3 0l64 64c.7 .7 1.3 1.4 1.9 2.1c14.2-7.3 30.4-11.4 47.5-11.4H312c17.1 0 33.2 4.1 47.5 11.4c.6-.7 1.2-1.4 1.9-2.1l64-64c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3l-64 64c-.7 .7-1.4 1.3-2.1 1.9c6.2 12 10.1 25.3 11.1 39.5H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H416c0 24.6-5.5 47.8-15.4 68.6c2.2 1.3 4.2 2.9 6 4.8l64 64c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0l-63.1-63.1c-24.5 21.8-55.8 36.2-90.3 39.6V240c0-8.8-7.2-16-16-16s-16 7.2-16 16V479.2c-34.5-3.4-65.8-17.8-90.3-39.6L86.6 502.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l64-64c1.9-1.9 3.9-3.4 6-4.8C101.5 367.8 96 344.6 96 320H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H96.3c1.1-14.1 5-27.5 11.1-39.5c-.7-.6-1.4-1.2-2.1-1.9l-64-64c-12.5-12.5-12.5-32.8 0-45.3z' fill='rgb(169,3,3,1)'/></svg>");background-repeat:no-repeat;width:10px;background-position-y:center}.fa.fa-unbalanced{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' height='1em' viewBox='0 0 512 512'><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480H40c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24V296c0 13.3 10.7 24 24 24s24-10.7 24-24V184c0-13.3-10.7-24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z' fill='rgb(249 139 5)'/></svg>");background-repeat:no-repeat;width:16px;height:16px;background-position-y:center}.fa.fa-chevron-right{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:12px;height:12px;background-position-y:center}.fa.fa-undo{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M125.7 160H176c17.7 0 32 14.3 32 32s-14.3 32-32 32H48c-17.7 0-32-14.3-32-32V64c0-17.7 14.3-32 32-32s32 14.3 32 32v51.2L97.6 97.6c87.5-87.5 229.3-87.5 316.8 0s87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3s-163.8-62.5-226.3 0L125.7 160z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-clone{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M272 0H396.1c12.7 0 24.9 5.1 33.9 14.1l67.9 67.9c9 9 14.1 21.2 14.1 33.9V336c0 26.5-21.5 48-48 48H272c-26.5 0-48-21.5-48-48V48c0-26.5 21.5-48 48-48zM48 128H192v64H64V448H256V416h64v48c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V176c0-26.5 21.5-48 48-48z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-file-pen{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M0 64C0 28.7 28.7 0 64 0H224V128c0 17.7 14.3 32 32 32H384V285.7l-86.8 86.8c-10.3 10.3-17.5 23.1-21 37.2l-18.7 74.9c-2.3 9.2-1.8 18.8 1.3 27.5H64c-35.3 0-64-28.7-64-64V64zm384 64H256V0L384 128zM549.8 235.7l14.4 14.4c15.6 15.6 15.6 40.9 0 56.6l-29.4 29.4-71-71 29.4-29.4c15.6-15.6 40.9-15.6 56.6 0zM311.9 417L441.1 287.8l71 71L382.9 487.9c-4.1 4.1-9.2 7-14.9 8.4l-60.1 15c-5.5 1.4-11.2-.2-15.2-4.2s-5.6-9.7-4.2-15.2l15-60.1c1.4-5.6 4.3-10.8 8.4-14.9z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-trash{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:11px !important;height:17px;background-position-y:center}.fa.fa-ellipsis-vertical{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;background-position-y:center}.fa.fa-ban{background-image:url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M367.2 412.5L99.5 144.8C77.1 176.1 64 214.5 64 256c0 106 86 192 192 192c41.5 0 79.9-13.1 111.2-35.5zm45.3-45.3C434.9 335.9 448 297.5 448 256c0-106-86-192-192-192c-41.5 0-79.9 13.1-111.2 35.5L412.5 367.2zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256z " fill="rgb(66,65,65,1)"/></svg>');background-repeat:no-repeat;width:17px !important;height:17px;background-position-y:center}.fa.fa-file-signature{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 0C28.7 0 0 28.7 0 64V448c0 35.3 28.7 64 64 64H320c35.3 0 64-28.7 64-64V428.7c-2.7 1.1-5.4 2-8.2 2.7l-60.1 15c-3 .7-6 1.2-9 1.4c-.9 .1-1.8 .2-2.7 .2H240c-6.1 0-11.6-3.4-14.3-8.8l-8.8-17.7c-1.7-3.4-5.1-5.5-8.8-5.5s-7.2 2.1-8.8 5.5l-8.8 17.7c-2.9 5.9-9.2 9.4-15.7 8.8s-12.1-5.1-13.9-11.3L144 381l-9.8 32.8c-6.1 20.3-24.8 34.2-46 34.2H80c-8.8 0-16-7.2-16-16s7.2-16 16-16h8.2c7.1 0 13.3-4.6 15.3-11.4l14.9-49.5c3.4-11.3 13.8-19.1 25.6-19.1s22.2 7.8 25.6 19.1l11.6 38.6c7.4-6.2 16.8-9.7 26.8-9.7c15.9 0 30.4 9 37.5 23.2l4.4 8.8h8.9c-3.1-8.8-3.7-18.4-1.4-27.8l15-60.1c2.8-11.3 8.6-21.5 16.8-29.7L384 203.6V160H256c-17.7 0-32-14.3-32-32V0H64zM256 0V128H384L256 0zM549.8 139.7c-15.6-15.6-40.9-15.6-56.6 0l-29.4 29.4 71 71 29.4-29.4c15.6-15.6 15.6-40.9 0-56.6l-14.4-14.4zM311.9 321c-4.1 4.1-7 9.2-8.4 14.9l-15 60.1c-1.4 5.5 .2 11.2 4.2 15.2s9.7 5.6 15.2 4.2l60.1-15c5.6-1.4 10.8-4.3 14.9-8.4L512.1 262.7l-71-71L311.9 321z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-user{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-calendar-days{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M128 0c17.7 0 32 14.3 32 32V64H288V32c0-17.7 14.3-32 32-32s32 14.3 32 32V64h48c26.5 0 48 21.5 48 48v48H0V112C0 85.5 21.5 64 48 64H96V32c0-17.7 14.3-32 32-32zM0 192H448V464c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V192zm64 80v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V272c0-8.8-7.2-16-16-16H80c-8.8 0-16 7.2-16 16zm128 0v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V272c0-8.8-7.2-16-16-16H208c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V272c0-8.8-7.2-16-16-16H336zM64 400v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V400c0-8.8-7.2-16-16-16H80c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V400c0-8.8-7.2-16-16-16H208zm112 16v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V400c0-8.8-7.2-16-16-16H336c-8.8 0-16 7.2-16 16z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-book{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M96 0C43 0 0 43 0 96V416c0 53 43 96 96 96H384h32c17.7 0 32-14.3 32-32s-14.3-32-32-32V384c17.7 0 32-14.3 32-32V32c0-17.7-14.3-32-32-32H384 96zm0 384H352v64H96c-17.7 0-32-14.3-32-32s14.3-32 32-32zm32-240c0-8.8 7.2-16 16-16H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16zm16 48H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16s7.2-16 16-16z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-list-check{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M152.1 38.2c9.9 8.9 10.7 24 1.8 33.9l-72 80c-4.4 4.9-10.6 7.8-17.2 7.9s-12.9-2.4-17.6-7L7 113C-2.3 103.6-2.3 88.4 7 79s24.6-9.4 33.9 0l22.1 22.1 55.1-61.2c8.9-9.9 24-10.7 33.9-1.8zm0 160c9.9 8.9 10.7 24 1.8 33.9l-72 80c-4.4 4.9-10.6 7.8-17.2 7.9s-12.9-2.4-17.6-7L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l22.1 22.1 55.1-61.2c8.9-9.9 24-10.7 33.9-1.8zM224 96c0-17.7 14.3-32 32-32H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H256c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H256c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H192c-17.7 0-32-14.3-32-32zM48 368a48 48 0 1 1 0 96 48 48 0 1 1 0-96z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-folder-tree{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 32C64 14.3 49.7 0 32 0S0 14.3 0 32v96V384c0 35.3 28.7 64 64 64H256V384H64V160H256V96H64V32zM288 192c0 17.7 14.3 32 32 32H544c17.7 0 32-14.3 32-32V64c0-17.7-14.3-32-32-32H445.3c-8.5 0-16.6-3.4-22.6-9.4L409.4 9.4c-6-6-14.1-9.4-22.6-9.4H320c-17.7 0-32 14.3-32 32V192zm0 288c0 17.7 14.3 32 32 32H544c17.7 0 32-14.3 32-32V352c0-17.7-14.3-32-32-32H445.3c-8.5 0-16.6-3.4-22.6-9.4l-13.3-13.3c-6-6-14.1-9.4-22.6-9.4H320c-17.7 0-32 14.3-32 32V480z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-cube{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M234.5 5.7c13.9-5 29.1-5 43.1 0l192 68.6C495 83.4 512 107.5 512 134.6V377.4c0 27-17 51.2-42.5 60.3l-192 68.6c-13.9 5-29.1 5-43.1 0l-192-68.6C17 428.6 0 404.5 0 377.4V134.6c0-27 17-51.2 42.5-60.3l192-68.6zM256 66L82.3 128 256 190l173.7-62L256 66zm32 368.6l160-57.1v-188L288 246.6v188z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-pen-nib{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M368.4 18.3L312.7 74.1 437.9 199.3l55.7-55.7c21.9-21.9 21.9-57.3 0-79.2L447.6 18.3c-21.9-21.9-57.3-21.9-79.2 0zM288 94.6l-9.2 2.8L134.7 140.6c-19.9 6-35.7 21.2-42.3 41L3.8 445.8c-3.8 11.3-1 23.9 7.3 32.4L164.7 324.7c-3-6.3-4.7-13.3-4.7-20.7c0-26.5 21.5-48 48-48s48 21.5 48 48s-21.5 48-48 48c-7.4 0-14.4-1.7-20.7-4.7L33.7 500.9c8.6 8.3 21.1 11.2 32.4 7.3l264.3-88.6c19.7-6.6 35-22.4 41-42.3l43.2-144.1 2.8-9.2L288 94.6z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-chevron-right{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-plus{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-check{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-pencil{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-cubes{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M290.8 48.6l78.4 29.7L288 109.5 206.8 78.3l78.4-29.7c1.8-.7 3.8-.7 5.7 0zM136 92.5V204.7c-1.3 .4-2.6 .8-3.9 1.3l-96 36.4C14.4 250.6 0 271.5 0 294.7V413.9c0 22.2 13.1 42.3 33.5 51.3l96 42.2c14.4 6.3 30.7 6.3 45.1 0L288 457.5l113.5 49.9c14.4 6.3 30.7 6.3 45.1 0l96-42.2c20.3-8.9 33.5-29.1 33.5-51.3V294.7c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-1.3-.5-2.6-.9-3.9-1.3V92.5c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-12.8-4.8-26.9-4.8-39.7 0l-96 36.4C150.4 48.4 136 69.3 136 92.5zM392 210.6l-82.4 31.2V152.6L392 121v89.6zM154.8 250.9l78.4 29.7L152 311.7 70.8 280.6l78.4-29.7c1.8-.7 3.8-.7 5.7 0zm18.8 204.4V354.8L256 323.2v95.9l-82.4 36.2zM421.2 250.9c1.8-.7 3.8-.7 5.7 0l78.4 29.7L424 311.7l-81.2-31.1 78.4-29.7zM523.2 421.2l-77.6 34.1V354.8L528 323.2v90.7c0 3.2-1.9 6-4.8 7.3z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-floppy-disk{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V173.3c0-17-6.7-33.3-18.7-45.3L352 50.7C340 38.7 323.7 32 306.7 32H64zm0 96c0-17.7 14.3-32 32-32H288c17.7 0 32 14.3 32 32v64c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V128zM224 288a64 64 0 1 1 0 128 64 64 0 1 1 0-128z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-xmark{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-arrow-up-long{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M214.6 9.4c-12.5-12.5-32.8-12.5-45.3 0l-128 128c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 109.3V480c0 17.7 14.3 32 32 32s32-14.3 32-32V109.3l73.4 73.4c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-128-128z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-arrow-down-long{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M169.4 502.6c12.5 12.5 32.8 12.5 45.3 0l128-128c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 402.7 224 32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 370.7L86.6 329.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l128 128z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-ellipsis-vertical{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center} :host{overflow-y:auto;overflow-x:hidden;display:block} details>div{padding-left:var(--space-32)} .container-input{max-width:600px} textarea, input{width:100%;max-width:100%;min-width:200px} input:read-only{background-color:var(--grey-color-light)} ul{padding-inline-start:0} .buttons-container{margin-top:var(--space-32);margin-bottom:var(--space-32);display:flex;justify-content:center} .buttons-container button{color:#ffffff;background-color:var(--active-color);min-width:200px} .buttons-container.left{margin-top:var(--space-16);justify-content:start} .select-type-project{padding:var(--space-16)} .select-type-project .cols{display:flex;gap:3rem;flex-wrap:wrap} .select-type-project .cols .col-left{flex:1} .select-type-project .cols .col-left ul{list-style:none;padding-inline-start:0} .select-type-project .cols .col-left ul li:hover{background-color:var(--grey-color-light)} .select-type-project .cols .col-left ul li.selected{background-color:var(--active-color);color:#ffffff} .select-type-project .cols .col-left ul li.selected small{color:#ffffff} .select-type-project .cols .col-left ul li{padding:1rem .3rem;font-size:var(--font-size-16);margin-bottom:var(--space-8);cursor:pointer;border-bottom:1px solid var(--grey-color)} .select-type-project .cols .col-left ul li span{font-weight:var(--font-weight-bold)} .select-type-project .cols .col-left ul li small{font-weight:var(--font-weight-lighter);color:var(--text-primary-color-lighter)} .select-type-project .cols .col-right{min-width:400px;flex:1} .select-type-project .cols .col-right .details-selected-item{margin-top:2rem} .select-type-project .cols .col-right .details-selected-item .details-title{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);display:block} .select-type-project .cols .col-right .details-selected-item .details-more{font-size:var(--font-size-16)} .select-type-project .cols .col-right .details-select-type{display:block} .select-type-project .cols .col-right .details-select-type span{display:flex;justify-content:center} .select-type-project table{font-size:var(--font-size-16);border-spacing:0;table-layout:fixed;width:100%} .select-type-project table thead th{border:none;background-color:var(--grey-color-light)} .select-type-project table thead th:nth-child(1){width:200px} .select-type-project table thead th:not(:nth-child(1)){width:80px} .select-type-project table tbody tr>td:not(:nth-child(1)){width:80px} .select-type-project table tbody tr{cursor:pointer} .select-type-project table tbody tr:hover{background-color:var(--grey-color-light)} .select-type-project table tbody tr.selected{background-color:var(--active-color);color:#ffffff} .select-type-project table tbody tr.selected small{color:#ffffff} .select-type-project table tbody tr.selected svg{fill:#ffffff} .select-type-project table tbody td{text-align:center;vertical-align:middle} .select-type-project table tbody td span{font-weight:var(--font-weight-bold)} .select-type-project table tbody td small{font-weight:var(--font-weight-lighter);color:var(--text-primary-color-lighter)} .details-new-project{padding:var(--space-16)} .details-new-project ul{list-style:none} .details-new-project .card-list{display:flex;gap:2rem;margin-top:2rem;margin-bottom:2rem;flex-wrap:wrap} .details-new-project .card-lock{z-index:1001;opacity:1;position:absolute;border-radius:50%;width:30px;height:30px;display:flex;justify-content:center;align-items:center;color:var(--error-color);border:1px solid var(--grey-color);background-color:var(--bg-primary-color);top:-15px;right:-15px} .details-new-project .card-lock svg{fill:var(--error-color)} .details-new-project .card-item.disabled{cursor:not-allowed;opacity:.6;user-select:none} .details-new-project .card-item{z-index:1000;position:relative;display:flex;flex-direction:column;width:300px;border:1px solid var(--grey-color-light);padding:var(--space-16);gap:.4rem;cursor:pointer;transition:transform .1s ease-in-out} .details-new-project .card-item:hover:not(.disabled), .details-new-project .card-item.selected{background-color:var(--grey-color-light)} .details-new-project .card-item.shake{animation:shake 1s cubic-bezier(.7, 0, .3, 1)} .details-new-project .card-item .card-type{width:30px;display:block;margin-left:auto;padding:.25em .4em;font-size:75%;font-weight:700;line-height:1;text-align:center;white-space:nowrap;padding-right:.6em;padding-left:.6em;border-radius:10rem;background-color:var(--bg-secondary-color)} .details-new-project .card-item .card-type.free{background-color:var(--success-color);color:var(--grey-color-lighter)} .details-new-project .card-item .card-type.pro{background-color:var(--active-color);color:var(--grey-color-lighter)} .details-new-project .card-item .card-desc{font-size:var(--font-size-16)} .details-new-project .card-item .card-details{font-size:var(--font-size-16)} .details-new-project .card-item .card-details ul li{display:flex;align-items:center}@keyframes shake{0%{transform:translateX(0)}10%{transform:translateX(-10px)}20%{transform:translateX(8px)}30%{transform:translateX(-6px)}40%{transform:translateX(4px)}50%{transform:translateX(-2px)}60%{transform:translateX(1px)}70%{transform:translateX(-0.5px)}80%{transform:translateX(.25px)}90%{transform:translateX(-0.1px)}100%{transform:translateX(0)}}`;
__decorate([
    property({ type: String })
], ServiceCreateProject100554.prototype, "currentScenario", void 0);
__decorate([
    property()
], ServiceCreateProject100554.prototype, "actualSiteSelected", void 0);
__decorate([
    queryAll('.tr-item')
], ServiceCreateProject100554.prototype, "sitesItems", void 0);
__decorate([
    queryAll('.publish-item')
], ServiceCreateProject100554.prototype, "publishItems", void 0);
__decorate([
    queryAll('.storage-item')
], ServiceCreateProject100554.prototype, "storageItems", void 0);
ServiceCreateProject100554 = __decorate([
    customElement('service-create-project-100554')
], ServiceCreateProject100554);
export { ServiceCreateProject100554 };
