/// <mls shortName="configDsDefaultTokens2" project="100554" enhancement="_blank" groupName="other" />
import { Common, initialTokensColor, initialTokensGlobal, initialtokensTypography } from './_100554_configDsDefaultCommon';
import { PreCompileLess } from './_100554_configDsDefaultPreCompileLess';
export class Token {
    constructor(dsIO, ds) {
        this.add = (key, value, theme, category) => this._addToken(key, value, theme, category);
        this.update = (key, newValue, theme) => this._updateToken(key, newValue, theme);
        this.remove = (key, theme) => this._removeToken(key, theme);
        this.find = (key, theme) => this._find(key, theme);
        this.addTheme = (theme, description) => this._addTheme(theme, description);
        this.removeTheme = (theme) => this._removeTheme(theme);
        this.list = {};
        this.getTokensLess = (theme) => this._getTokensLess(theme);
        this.getTokensCss = (theme) => this._getTokensCss(theme);
        this.setTokens = (theme, tokensColor, tokensTypography, tokensGlobal) => this._setTokens(theme, tokensColor, tokensTypography, tokensGlobal);
        this._ds = dsIO;
        this.ds = ds;
        this.methods = new Common(ds, dsIO);
        this.prepareTokens();
    }
    prepareTokens() {
        this.list = {};
        this.ds.tokens.items.forEach((token) => {
            if (!this.list[token.themeName]) {
                this.list[token.themeName] = {
                    description: '',
                    color: {},
                    global: {},
                    typography: {},
                };
            }
            this.list[token.themeName].description = token.description;
            Object.keys(token.global).forEach((key) => {
                this.list[token.themeName]['global'][key] = token.global[key];
            });
            Object.keys(token.color).forEach((key) => {
                this.list[token.themeName]['color'][key] = token.color[key];
            });
            Object.keys(token.typography).forEach((key) => {
                this.list[token.themeName]['typography'][key] = token.typography[key];
            });
        });
    }
    _find(key, theme) {
        const cats = Object.keys(this.list[theme]);
        let tokenInfo = null;
        for (let cat of cats) {
            const value = this.list[theme][cat][key];
            if (!value)
                continue;
            tokenInfo = {
                categorie: cat,
                value
            };
        }
        return tokenInfo;
    }
    _getTokensLess(theme) {
        const tokenByTheme = this.list[theme];
        if (!tokenByTheme)
            throw new Error(`no find theme: ${theme}`);
        let tokensLess = '';
        tokensLess += Object.keys(tokenByTheme.color).map((key) => {
            let token = '';
            if (!key.startsWith('_dark-'))
                token = `@${key}: ${tokenByTheme.color[key]};`;
            return token;
        }).filter((item) => !!item).join('\n');
        tokensLess += '\n' + Object.keys(tokenByTheme.typography).map((key) => `@${key}: ${tokenByTheme.typography[key]};`).join('\n');
        tokensLess += '\n' + Object.keys(tokenByTheme.global).map((key) => `@${key}: ${tokenByTheme.global[key]};`).join('\n');
        return Promise.resolve(tokensLess);
    }
    async _getTokensCss(theme) {
        const tokensLess = await this._getTokensLess(theme);
        try {
            const preCompileLess = new PreCompileLess();
            const tokensCss = await preCompileLess.execute('', tokensLess, theme, this.ds.tokens.items, ':root');
            return tokensCss;
        }
        catch (err) {
            throw new Error(`Error on compile tokens Less: ${err.message}`);
        }
    }
    async _addToken(key, value, theme, category) {
        if (!this.list[theme])
            throw new Error(`theme: ${theme} dont exists`);
        const tokenByKey = this.find(key, theme);
        if (tokenByKey)
            throw new Error(`token: ${key} already exists in theme: ${theme}`);
        this.list[theme][category][key] = value;
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on add new token:' + err.message));
        }
    }
    async _updateToken(key, value, theme) {
        if (!this.list[theme])
            throw new Error(`theme: ${theme} dont exists`);
        const tokenByKey = this.find(key, theme);
        if (!tokenByKey)
            throw new Error(`token: ${key} dont exists in theme: ${theme}`);
        try {
            this.list[theme][tokenByKey.categorie][key] = value;
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on update token:' + err.message));
        }
    }
    async _removeToken(key, theme) {
        const tokenByKey = this.find(key, theme);
        if (!tokenByKey)
            throw new Error(`token: ${key} dont exists in theme: ${theme}`);
        delete this.list[theme][tokenByKey.categorie][key];
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove token:' + err.message));
        }
    }
    async _addTheme(theme, description) {
        if (this.list[theme])
            throw new Error(`theme: ${theme} already exists`);
        this.list[theme] = {
            description,
            color: initialTokensColor,
            global: initialTokensGlobal,
            typography: initialtokensTypography,
        };
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove token:' + err.message));
        }
    }
    async _removeTheme(theme) {
        if (!this.list[theme])
            throw new Error(`theme: ${theme} dont exists`);
        delete this.list[theme];
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove token:' + err.message));
        }
    }
    async _setTokens(theme, tokensColor, tokensTypography, tokensGlobal) {
        if (!this.list[theme])
            throw new Error(`theme: ${theme} dont exists`);
        this.list[theme].color = tokensColor;
        this.list[theme].typography = tokensTypography;
        this.list[theme].global = tokensGlobal;
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on set tokens:' + err.message));
        }
    }
}
