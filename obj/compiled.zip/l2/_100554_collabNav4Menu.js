/// <mls shortName="collabNav4Menu" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { collab_bars, collab_bell } from './_100554_collabIcons';
let CollabNav4Menu = class CollabNav4Menu extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav4-menu-100554{font-family:Cambria, serif;font-size:14px;display:block;font-weight:400;background:#f6f6f6;border-radius:6px;height:40px;box-shadow:1px 1px 4px 0 rgba(0,0,0,0.1)}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav{display:flex;height:40px}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab{box-shadow:1px 1px 4px 0 rgba(0,0,0,0.1);display:flex;align-items:center;gap:var(--space-8);cursor:pointer;padding:6px 12px;background:var(--bg-secondary-color-lighter);color:var(--text-primary-color);transition:all var(--transition-slow);border:none;border-bottom:1px solid var(--bg-secondary-color);position:relative;z-index:0}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab svg{fill:currentColor}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab:hover{background:var(--bg-secondary-color-hover)}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab.active{border:1px solid var(--grey-color);border-bottom:none;background:var(--bg-primary-color);color:var(--active-color);font-weight:var(--font-weight-bold)}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .icon{display:flex;align-items:center;font-size:var(--font-size-16)}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .text{font-size:14px}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .close-btn{margin-left:4px;background:transparent;border:none;color:var(--text-primary-color-lighter);cursor:pointer;font-size:var(--font-size-16);transition:color var(--transition-slow)}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .close-btn:hover{color:var(--error-color)}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav.onlyicon .collab-nav4-menu-100554-tab .text{display:none}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav.onlyicon .collab-nav4-menu-100554-tab.active .text{display:inline}collab-nav4-menu-100554 .collab-nav4-menu-100554-nav.fixed .collab-nav4-menu-100554-tab .close-btn{display:none}`);
        this.selectedIndex = 0;
        this.mode = 'full';
        this.options = [
            { text: 'Home', icon: collab_bars.strings[0].toString(), allowClose: true },
            { text: 'Config', icon: collab_bell.strings[0].toString(), allowClose: true },
            { text: 'Sair', icon: collab_bars.strings[0].toString(), allowClose: true },
        ];
    }
    handleSelect(index) {
        this.selectedIndex = index;
        this.dispatchEvent(new CustomEvent('tab-selected', {
            detail: { index },
            bubbles: true,
            composed: true,
        }));
    }
    handleClose(e, index) {
        e.stopPropagation();
        if (!this.options)
            return;
        const closed = this.options.splice(index, 1);
        this.requestUpdate();
        this.dispatchEvent(new CustomEvent('tab-closed', {
            detail: { index, tab: closed[0] },
            bubbles: true,
            composed: true,
        }));
    }
    render() {
        return html `
			${this.renderNav()}
		`;
    }
    renderNav() {
        if (this.options) {
            return html `
				<nav class="collab-nav4-menu-100554-nav ${this.mode}">
					${this.options.map((tab, i) => {
                const isActive = i === this.selectedIndex;
                return html `
							<div
								class="collab-nav4-menu-100554-tab ${isActive ? 'active' : ''}"
								@click=${() => this.handleSelect(i)}
							>
								${tab.icon ? html `<span class="icon" .innerHTML=${tab.icon}></span>` : ''}
								${this.mode === 'full' || isActive
                    ? html `<span class="text">${tab.text}</span>`
                    : ''}
								${this.mode !== 'fixed' && tab.allowClose
                    ? html `
											<button class="close-btn" @click=${(e) => this.handleClose(e, i)}>
												×
											</button>
									  `
                    : ''}
							</div>
						`;
            })}
				</nav>
			`;
        }
    }
};
__decorate([
    property({ type: Number, reflect: true })
], CollabNav4Menu.prototype, "selectedIndex", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabNav4Menu.prototype, "mode", void 0);
__decorate([
    property()
], CollabNav4Menu.prototype, "options", void 0);
CollabNav4Menu = __decorate([
    customElement('collab-nav4-menu-100554')
], CollabNav4Menu);
export { CollabNav4Menu };
