/// <mls shortName="aimPromptExample" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let AimPromptExample = class AimPromptExample extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aim-prompt-example-100554 .prompt-suggestion{display:inline-block;padding:10px;margin:10px;border:1px solid #ccc;border-radius:8px;background-color:#f0f0f0;cursor:pointer;font-family:Arial,sans-serif;transition:background-color .3s;color:black}aim-prompt-example-100554 .prompt-suggestion:hover{background-color:#e0e0e0}aim-prompt-example-100554 aim-prompt-100554{display:block;margin:20px 0;font-weight:bold}`);
        this.text = "example";
        this.for = "";
    }
    handleClick() {
        const aimPromptElement = document.querySelector(this.for);
        if (aimPromptElement) {
            aimPromptElement.setAttribute('text', this.text);
        }
    }
    render() {
        return html `
            <div class="prompt-suggestion" @click=${this.handleClick}>
                ${this.text}
            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], AimPromptExample.prototype, "text", void 0);
__decorate([
    property({ type: String })
], AimPromptExample.prototype, "for", void 0);
AimPromptExample = __decorate([
    customElement('aim-prompt-example-100554')
], AimPromptExample);
export { AimPromptExample };
