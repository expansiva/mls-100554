/// <mls shortName="pluginTestDashboard1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let PluginTestDashboard1100554 = class PluginTestDashboard1100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.dashboardindex = '';
        this.scope = 'dashboard';
        this.chartData = {};
    }
    createRenderRoot() {
        return this;
    }
    async prepare() {
        await this.delay(5000);
        await import('./_100554_wcChart');
        this.chartData = {
            legend: {},
            tooltip: {},
            dataset: {
                source: [
                    ['Sun', 43.3, 85.8, 93.7],
                    ['Mon', 83.1, 73.4, 55.1],
                    ['Tue', 86.4, 65.2, 82.5],
                    ['Wed', 72.4, 53.9, 39.1],
                    ['Thu', 43.3, 85.8, 93.7],
                    ['Fri', 83.1, 73.4, 55.1],
                    ['Sat', 43.3, 85.8, 93.7],
                ]
            },
            xAxis: { type: 'category' },
            yAxis: {},
            series: [{
                    type: 'bar',
                    itemStyle: {
                        color: (p) => {
                            const colorList = ["#f68a55", "#f68a55", "#f68a55", "#f68a55", "#f68a55", "#f68a55", "#f68a55"];
                            return colorList[p.dataIndex];
                        }
                    }
                }, {
                    type: 'bar',
                    itemStyle: {
                        color: (p) => {
                            const colorList = ["#f4b491", "#f4b491", "#f4b491", "#f4b491", "#f4b491", "#f4b491", "#f4b491"];
                            return colorList[p.dataIndex];
                        }
                    }
                }, {
                    type: 'bar',
                    itemStyle: {
                        color: (p) => {
                            const colorList = ["#f8c9bc", "#f8c9bc", "#f8c9bc", "#f8c9bc", "#f8c9bc", "#f8c9bc", "#f8c9bc"];
                            return colorList[p.dataIndex];
                        }
                    }
                }]
        };
        this.innerHTML = `<wc-chart-100554 renderer="svg" datasource=${JSON.stringify(this.chartData)}></wc-chart-100554>`;
    }
    async delay(timeout) {
        await new Promise((resolve) => setTimeout(resolve, timeout));
    }
    render() {
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        return html ``;
    }
};
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "dashboardindex", void 0);
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "scope", void 0);
__decorate([
    property()
], PluginTestDashboard1100554.prototype, "chartData", void 0);
PluginTestDashboard1100554 = __decorate([
    customElement('plugin-test-dashboard1-100554')
], PluginTestDashboard1100554);
export { PluginTestDashboard1100554 };
