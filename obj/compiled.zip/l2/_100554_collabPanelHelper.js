/// <mls shortName="collabPanelHelper" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { collab_chevron_right, collab_chevron_left } from './_100554_collabIcons';
import { globalState } from './_100554_collabState';
let CollabPanelHelper100554 = class CollabPanelHelper100554 extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-panel-helper-100554 .container-open-helper{height:100%;position:absolute;top:0;background:#f6f6f6;right:0;width:0;z-index:9999;transition:width .5s ease}collab-panel-helper-100554 .container-open-helper.open{width:40%}collab-panel-helper-100554 .container-open-helper.open .helper{opacity:1;width:100%;height:100%}collab-panel-helper-100554 .container-open-helper .helper{z-index:0;opacity:0;overflow:auto;font-size:14px;width:0;height:0}collab-panel-helper-100554 .container-open-helper .helper details[open]{margin-bottom:1rem}collab-panel-helper-100554 .container-open-helper .helper details summary{font-weight:bold;padding-left:.5rem}collab-panel-helper-100554 .container-open-helper .helper details>div{margin-left:1rem;margin-top:1rem;border-bottom:1px solid #cecece}collab-panel-helper-100554 .container-open-helper .toogle{position:absolute;width:30px;height:80px;background:#f6f6f6;top:50%;left:-30px;z-index:9999;transform:translate(0%, -50%);border-top-left-radius:5px;cursor:pointer;border-bottom-left-radius:5px;display:flex;justify-content:center;align-items:center}`);
        this.plugin = '';
        this.isHelperContainerOpen = false;
    }
    async handleOpenHelperClick() {
        if (!this.containerHelpers)
            return;
        if (this.isHelperContainerOpen) {
            this.containerHelpers.classList.remove('open');
            this.isHelperContainerOpen = false;
        }
        else {
            this.containerHelpers.classList.add('open');
            this.isHelperContainerOpen = true;
        }
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('plugin')) {
            const plg = changedProperties.get('plugin');
            if (plg === this.plugin)
                return;
            console.info(`Renderizar plugin: ${this.plugin}`);
            console.info({ tokensInfo: globalState._ica?.cssTokens });
        }
    }
    render() {
        return html `<div class="container-open-helper">
                <div class="toogle" @click=${this.handleOpenHelperClick}> 
                    <i>${this.isHelperContainerOpen ? collab_chevron_right : collab_chevron_left}</i>
                </div>
                <div class="helper">
                    
                </div>
            </div>`;
    }
};
CollabPanelHelper100554.styles = css `
        .container-open-helper {
            height: 100%;
            position: absolute;
            top: 0;
            background: #f6f6f6;
            right: 0;
            width: 0;
            z-index: 9999;
            transition: width 0.5s ease;
        }
        .container-open-helper.open {
            width: 40%;
        }
        .container-open-helper.open .helper {
            opacity: 1;
            width: 100%;
            height: 100%;
        }
        .container-open-helper .helper {
            z-index: 0;
            opacity: 0;
            overflow: auto;
            font-size: 14px;
            width: 0;
            height: 0;
        }
        .container-open-helper .helper details[open] {
            margin-bottom: 1rem;
        }
        .container-open-helper .helper details summary {
            font-weight: bold;
            padding-left: 0.5rem;
        }
        .container-open-helper .helper details > div {
            margin-left: 1rem;
            margin-top: 1rem;
            border-bottom: 1px solid #cecece;
        }
        .container-open-helper .toogle {
            position: absolute;
            width: 30px;
            height: 80px;
            background: #f6f6f6;
            top: 50%;
            left: -30px;
            z-index: 9999;
            transform: translate(0%, -50%);
            border-top-left-radius: 5px;
            cursor: pointer;
            border-bottom-left-radius: 5px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
`;
__decorate([
    property()
], CollabPanelHelper100554.prototype, "plugin", void 0);
__decorate([
    property()
], CollabPanelHelper100554.prototype, "isHelperContainerOpen", void 0);
__decorate([
    query('.container-open-helper')
], CollabPanelHelper100554.prototype, "containerHelpers", void 0);
CollabPanelHelper100554 = __decorate([
    customElement('collab-panel-helper-100554')
], CollabPanelHelper100554);
export { CollabPanelHelper100554 };
