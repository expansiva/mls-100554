/// <mls shortName="wcdToolboxItemActionCodeLanguage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
import { IcaApresentationTextCodeBase } from './_100554_icaApresentationTextCodeBase';
import { dispatchEventConciliate } from './_100554_wcdCommandBase';
let WcdToolboxItemActionCodeLanguage = class WcdToolboxItemActionCodeLanguage extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        this.languages = [];
        this.actualLanguage = '';
    }
    async getLanguagesAvaliables() {
        if (!this.elICA)
            return;
        const wc = this.elICA.children[0];
        if (!wc || !(wc instanceof IcaApresentationTextCodeBase))
            throw new Error('Invalid wc rendering in ica');
        if (!wc.languages)
            throw new Error('Invalid wc languages in component');
        this.languages = wc.languages || [];
        await this.updateComplete;
        this.actualLanguage = wc.language || '';
    }
    handleChange(e) {
        if (!this.elICA)
            return;
        const target = e.target;
        const val = target.value;
        this.elICA.setAttribute('language', val);
        dispatchEventConciliate();
    }
    handleClick(e) {
        e.stopPropagation();
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        this.getLanguagesAvaliables();
    }
    render() {
        return html `<select style="border: none;outline:none;" .value=${this.actualLanguage} @click=${this.handleClick} @change=${this.handleChange}>${this.languages.map((item) => html `<option value=${item}>${item}</option>`)}</select>`;
    }
};
__decorate([
    property()
], WcdToolboxItemActionCodeLanguage.prototype, "languages", void 0);
__decorate([
    property()
], WcdToolboxItemActionCodeLanguage.prototype, "actualLanguage", void 0);
WcdToolboxItemActionCodeLanguage = __decorate([
    customElement('wcd-toolbox-item-action-code-language-100554')
], WcdToolboxItemActionCodeLanguage);
export { WcdToolboxItemActionCodeLanguage };
