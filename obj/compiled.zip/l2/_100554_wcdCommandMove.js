/// <mls shortName="wcdCommandMove" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { dispatchEventConciliate } from './_100554_wcdCommandBase';
import { canMoveElement } from './_100554_icaBaseDescription';
export function move(el, target, pos, update = true) {
    const page = el.closest('*[modeoverlay]');
    if (!page)
        throw new Error('Not found overlay');
    const father = target.parentElement;
    const child = el.querySelector('#' + target.id);
    const parentICA = target.getIcaParent(target);
    if (el === target || child) {
        throw new Error('Not possible move');
    }
    switch (pos) {
        case 'above':
            insertAbove(father, el, target, parentICA);
            break;
        case 'below':
            insertBelow(father, el, target, parentICA);
            break;
        case 'inside':
            insertInside(el, target);
            break;
        default:
            '';
    }
    if (update) {
        dispatchEventConciliate();
        page.recreateOverlay();
    }
}
export function updateOverlay(el) {
    const page = el.closest('*[modeoverlay]');
    if (!page)
        throw new Error('Not found overlay');
    dispatchEventConciliate();
    page.recreateOverlay();
}
function insertAbove(father, el, target, parentICA) {
    if (!parentICA)
        return false;
    const canMove = canMoveElement(el, parentICA);
    if (!canMove)
        return false;
    father.insertBefore(el, target);
    return true;
}
function insertBelow(father, el, target, parentICA) {
    if (!parentICA)
        return false;
    const canMove = canMoveElement(el, parentICA);
    if (!canMove)
        return false;
    father.insertBefore(el, target.nextSibling);
    return true;
}
function insertInside(el, target) {
    const canMove = canMoveElement(el, target);
    if (!canMove)
        return false;
    const elIn = target.querySelector(target.widget || '');
    if (elIn)
        elIn.appendChild(el);
    return true;
}
