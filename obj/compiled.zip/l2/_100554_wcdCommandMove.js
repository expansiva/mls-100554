/// <mls shortName="wcdCommandMove" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { dispatchEventConciliate } from './_100554_wcdCommandBase';
import { canMoveElement } from './_100554_icaBaseDescription2';
export function move(el, target, pos) {
    const page = el.closest('*[modeoverlay]');
    if (!page)
        throw new Error('Not found overlay');
    const father = target.parentElement;
    const child = el.querySelector('#' + target.id);
    const parentICA = target.getIcaParent(target);
    if (el === target || child) {
        throw new Error('Not possible move');
    }
    switch (pos) {
        case 'above':
            insertAbove(father, el, target, parentICA);
            break;
        case 'below':
            insertBelow(father, el, target, parentICA);
            break;
        case 'inside':
            insertInside(el, target);
            break;
        default:
            '';
    }
    dispatchEventConciliate();
    page.recreateOverlay();
}
function insertAbove(father, el, target, parentICA) {
    if (!parentICA)
        return;
    const canMove = canMoveElement(el, parentICA);
    if (!canMove)
        throw new Error('Movement not permitted');
    father.insertBefore(el, target);
}
function insertBelow(father, el, target, parentICA) {
    if (!parentICA)
        return;
    const canMove = canMoveElement(el, parentICA);
    if (!canMove)
        throw new Error('Movement not permitted');
    father.insertBefore(el, target.nextSibling);
}
function insertInside(el, target) {
    const canMove = canMoveElement(el, target);
    if (!canMove)
        throw new Error('Movement not permitted');
    const elIn = target.querySelector(target.widget || '');
    if (elIn)
        elIn.appendChild(el);
}
