/// <mls shortName="beStatesBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { getCollabStateInstance } from "./_100554_collabState";
export class EntityWithReadAction {
    constructor(entityKey, readDriver) {
        this.state = getCollabStateInstance(); // use singleton
        this.onAction = async () => {
            const action = this.state.getState(this.actionKey);
            console.log('on Action', this.actionKey, action);
            if (!action || action.command !== "read")
                return;
            const result = await this.readDriver.read(action);
            this.state.setState(this.dataKey, result);
        };
        this.entityKey = entityKey;
        this.readDriver = readDriver;
        this.state.subscribe(this.actionKey, this.onAction);
    }
    get actionKey() {
        return `db.${this.entityKey}.action`;
    }
    get dataKey() {
        return `db.${this.entityKey}`;
    }
}
