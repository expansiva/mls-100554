/// <mls shortName="agentNewModule2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import './_100554_widgetQuestionsForClarification';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, updateStepStatus, getStepById, getInteractionStepId, getNextStepIdAvaliable, notifyTaskChange } from "./_100554_aiAgentHelper";
import { startNewInteractionInAiTask, executeNextStep, addNewStep, toLLMClarification, startClarification } from "./_100554_aiAgentOrchestration";
const agentName = "agentNewModule2";
const project = 100554;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent for create a new Module - 2",
        visibility: "private",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async replayForSupport(context, payload) {
            return _replayForSupport(context, payload);
        },
        async beforeClarification(context, stepId) {
            return _beforeClarification(context, stepId);
        },
        async afterClarification(context, stepId, clarification) {
            return _afterClarification(context, stepId, clarification);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning 2...";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        throw new Error(`[${agentName}] [beforePrompt]: no context task.`);
    }
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step) {
        throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
    }
    context.task = await updateStepStatus(context.task, step.stepId, "in_progress");
    if (!step.prompt)
        throw new Error(`[${agentName}] beforePrompt: No prompt found in step for this agent.`);
    try {
        const prompt = JSON.parse(step.prompt);
        console.log(`[${agentName}] [beforePrompt]:`, prompt);
        const inputs = await getPrompts(prompt);
        await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
    }
    catch (e) {
        throw new Error(`[${agentName}] [beforePrompt]: Invalid prompt: ` + e.message || '?');
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
    notifyTaskChange(context);
    await executeNextStep(context);
};
const _replayForSupport = async (context, payload) => {
    const step = payload[0];
    if (!step || step.type !== 'flexible')
        throw new Error('Invalid step for replay');
    if (!step.result || !step.result.meta)
        throw new Error('Invalid step result for replay');
    // TODO: implemntar o que vai ser preciso fazer
};
const _beforeClarification = async (context, stepId) => {
    return startClarification(context, stepId);
};
const _afterClarification = async (context, stepId, clarification) => {
    if (!context || !context.message || !context.task)
        throw new Error("[${agentName}] [afterClarification] Invalid context");
    if (!clarification)
        throw new Error("[${agentName}] [afterClarification] Invalid json after clarification");
    const step = getStepById(context.task, stepId);
    if (!step || step.type !== "clarification") {
        throw new Error(`[${agentName}] [afterClarification] No found step: ${stepId} for this agent.`);
    }
    // add step for agentNewModule2
    const interactionId = getInteractionStepId(context.task, step.stepId);
    if (!interactionId)
        throw new Error("[${agentName}] [afterClarification] Not found interactionId in pending step");
    const payload = getStepById(context.task, interactionId);
    if (!payload || payload.type !== "agent")
        throw new Error("[${agentName}] [afterClarification] Clarification or tool step not bellow a agent");
    const promptUser = payload.interaction?.input.find((input) => input.type === 'human')?.content || '';
    const dataForNextAgent = {
        prompt: promptUser,
    };
    const newStep = {
        type: 'agent',
        agentName: 'agentNewModule3',
        prompt: JSON.stringify(dataForNextAgent),
        status: 'pending',
        stepId: getNextStepIdAvaliable(context.task),
        interaction: null,
        nextSteps: null,
        rags: null
    };
    // complete this step (payload) and push another step
    await addNewStep(context, step.stepId, [newStep]);
};
async function getPrompts(prompt) {
    if (!prompt || !prompt.clarification || !prompt.userPrompt)
        throw new Error(`Erro [${agentName}] getPrompts: invalid userPrompt`);
    prompt.ResumeClarification = toLLMClarification(prompt.clarification);
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: prompt });
    return prompts;
}
