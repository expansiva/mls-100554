/// <mls shortName="configDsDefaultPreCompileLess" project="100554" enhancement="_blank" groupName="other" />
export class PreCompileLess {
    execute(less, tokensLess, theme, tokens, prefix, includeTokens = true) {
        try {
            const fullLess = `${tokensLess}\n${less}`;
            this.compileLess(fullLess);
            return this.preCompileLess(less, tokens, theme, prefix, includeTokens);
        }
        catch (err) {
            throw new Error(err.message);
        }
    }
    async compileLess(str) {
        return new Promise((resolve, reject) => {
            if (!str || str.trim().length < 1)
                resolve('');
            const options = {
                compress: true,
                errorReporting: 'function'
            };
            window['less'].render(str, options)
                .then((output) => {
                resolve(output.css);
            }, (error) => {
                reject(new Error('Error LESS: ' + error));
            });
        });
    }
    async preCompileLess(less, tokens, theme, prefix, includeTokens) {
        let newLess = '';
        for (let tokenInfo of tokens) {
            if (tokenInfo.themeName !== theme)
                continue;
            const allTokens = { ...tokenInfo.color, ...tokenInfo.typography, ...tokenInfo.global };
            const darkAndLight = this.getDarkAndLight(allTokens);
            const cssVars = this.getCssVars(darkAndLight, prefix);
            newLess = this.replaceTokens(less, darkAndLight, cssVars, includeTokens);
        }
        return newLess;
    }
    getDarkAndLight(allTokens) {
        const themes = {};
        Object.entries(allTokens).forEach((entry) => {
            const [key, value] = entry;
            const [theme] = key.split('-');
            let themeName = 'root';
            if (theme === '_dark')
                themeName = 'dark';
            if (!themes[themeName])
                themes[themeName] = {};
            themes[themeName][key] = value;
        });
        return themes;
    }
    getCssVars(themes, prefix) {
        const cssArr = [];
        Object.entries(themes).forEach((entry) => {
            const [key, value] = entry;
            if (key === 'root') {
                const cssVars = [];
                Object.entries(value).forEach((entryTokens) => {
                    const [keyToken, valueToken] = entryTokens;
                    const cssVar = `--${keyToken}: ${valueToken};`;
                    cssVars.push(cssVar);
                });
                const cssFinal = `${prefix}{\n\t${cssVars.join('\n\t')}\n}`;
                cssArr.push(cssFinal);
            }
            else {
                const cssVars = [];
                Object.entries(value).forEach((entryTokensDark) => {
                    const [keyToken, valueToken] = entryTokensDark;
                    const tokenKey = keyToken.substring(1 + key.length + 1, keyToken.length);
                    const cssVar = `--${tokenKey}: ${valueToken};`;
                    cssVars.push(cssVar);
                });
                // const cssFinal = `@media (prefers-color-scheme: dark) {\n\t${prefix}{\n\t${cssVars.join('\n\t')}\n}`;
                const cssFinal = `[data-theme="dark"] {\n\t${cssVars.join('\n\t')}\n}`;
                cssArr.push(cssFinal);
            }
        });
        return cssArr.join('\n');
    }
    replaceTokens(less, themes, cssVars, includeTokens) {
        const { root } = themes;
        if (!root)
            return less;
        let newLess;
        if (includeTokens)
            newLess = cssVars + '\n' + less;
        else
            newLess = less;
        Object.keys(root).forEach((key) => {
            const variableName = `@${key};`;
            const escapedVariableName = this.getEscapedVariable(variableName);
            const pattern = new RegExp(escapedVariableName, 'g');
            const replacement = `var(--${key});`;
            newLess = newLess.replace(pattern, replacement);
            const variableName2 = `@${key},`;
            const escapedVariableName2 = this.getEscapedVariable(variableName2);
            const pattern2 = new RegExp(escapedVariableName2, 'g');
            const replacement2 = `var(--${key}),`;
            newLess = newLess.replace(pattern2, replacement2);
            const variableName3 = `(@${key}`;
            const escapedVariableName3 = this.getEscapedVariable(variableName3);
            const pattern3 = new RegExp(escapedVariableName3, 'g');
            const replacement3 = `(var(--${key})`;
            newLess = newLess.replace(pattern3, replacement3);
            const variableName4 = `@${key} `;
            const escapedVariableName4 = this.getEscapedVariable(variableName4);
            const pattern4 = new RegExp(escapedVariableName4, 'g');
            const replacement4 = `var(--${key}) `;
            newLess = newLess.replace(pattern4, replacement4);
        });
        return newLess;
    }
    getEscapedVariable(variableName) {
        return variableName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
}
