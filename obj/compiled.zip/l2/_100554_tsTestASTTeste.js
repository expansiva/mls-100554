/// <mls shortName="tsTestASTTeste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';
import { TsTestAst } from "./_100554_tsTestAST";
let LessASTTest100554 = class LessASTTest100554 extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.fileName = '_100554_tsTestASTTeste';
        this.model1 = mls.editor.models[this.fileName].test;
        this.fileToTest = '_100554_tsTestAST.test.ts';
        this.exeTest = () => {
            if (!this.model1)
                return "undefined;";
            const editor = mls.services['100554_serviceSource_left']._ed1;
            if (!editor)
                return `No find editor`;
            const testAST = new TsTestAst(this.model1, editor);
            const testAst = this.test1(testAST);
            const testGetIntegrations = this.test2(testAST);
            const testGetTests = this.test3(testAST);
            const testAddTest = this.test4(testAST, 'new Test');
            const testAddTestSameTitle = this.test4(testAST, 'Test add 2');
            const testAddIntegration = this.test5(testAST, 'adicionar usuario com todos os parametros');
            const testDeleteTest = this.test6(testAST, 'Test add');
            return `result test1: ${testAst} \n\n
${'*'.repeat(100)}\n
result test - get integrations: ${testGetIntegrations}  \n\n\n
${'*'.repeat(100)}\n
result test - get tests: ${testGetTests}  \n\n\n
${'*'.repeat(100)}\n
result test - add test: ${testAddTest}  \n\n\n
${'*'.repeat(100)}\n
result test - add test already existing: ${testAddTestSameTitle}  \n\n\n
${'*'.repeat(100)}\n
result test - add integration: ${testAddIntegration}  \n\n\n
${'*'.repeat(100)}\n
result test - delete test: ${testDeleteTest}  \n\n\n
${'*'.repeat(100)}\n


        `;
        };
        this.test1 = (testAST) => {
            const rc = testAST.parse();
            console.info(rc);
            return JSON.stringify(rc, null, 2);
        };
        this.test2 = (testAST) => {
            const rc = testAST.getIntegrations();
            console.info(rc);
            return JSON.stringify(rc, null, 2);
        };
        this.test3 = (testAST) => {
            const rc = testAST.getTests();
            console.info(rc);
            return JSON.stringify(rc, null, 2);
        };
        this.test4 = (testAST, title) => {
            const testNew = {
                functionName: 'fcTestNew',
                title,
                params: {
                    user: { type: 'String', value: 'Guilherme' },
                }
            };
            const fc = function fcTestNew() {
                console.info('Implements here');
            };
            try {
                const rc = testAST.addTest(testNew, fc);
                console.info(rc);
                return `${rc}`;
            }
            catch (err) {
                return `${err.message}`;
            }
        };
        this.test5 = (testAST, description) => {
            const integrationNew = {
                functionName: 'fcIntegrationNew',
                description,
                enabled: true,
                page: 'tsTestASTTeste',
                params: {
                    user: { type: 'String', description: 'The user name' },
                    phone: { type: 'String', description: 'The user phone number' },
                    cep: { type: 'Number', description: 'The user cep', optional: true },
                }
            };
            const fc = function fcIntegrationNew() {
                console.info('Implements here');
            };
            try {
                const rc = testAST.addIntegration(integrationNew, fc);
                console.info(rc);
                return `${rc}`;
            }
            catch (err) {
                return `${err.message}`;
            }
        };
        this.test6 = (testAST, name) => {
            try {
                const rc = testAST.deleteTest(name);
                return `${rc}`;
            }
            catch (err) {
                return `${err.message}`;
            }
        };
    }
    render() {
        return html `<p>testing file: ${this.fileToTest}</p>
         <pre style="position: relative;white-space: pre-wrap;">test: <br>${this.exeTest()}</pre>
         `;
    }
};
LessASTTest100554 = __decorate([
    customElement('ts-test-a-s-t-teste-100554')
], LessASTTest100554);
export { LessASTTest100554 };
