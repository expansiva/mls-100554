/// <mls shortName="lessMonaco" project="100554" enhancement="_blank" />
const _editor = Symbol("ignoredProperty");
/**
 * class to interface with monaco models
 */
export class MonacoDriver {
    constructor(editor) {
        this.getLines = (url) => {
            const model = monaco.editor.getModel(monaco.Uri.parse(url));
            if (!model || model.isDisposed())
                throw new Error(`invalid model ${url}`);
            const lines = model.getLinesContent();
            return lines;
        };
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        this.insertLine = (url, lineNr, line) => {
            const model = monaco.editor.getModel(monaco.Uri.parse(url));
            if (!model || model.isDisposed())
                throw new Error(`Invalid model ${url}`);
            const position = new monaco.Position(lineNr, 1);
            model.pushEditOperations([], // Undo stack will automatically handle this.
            [{ range: new monaco.Range(lineNr, 1, lineNr, 1), text: line + '\n', forceMoveMarkers: true }], () => null);
            if (this[_editor]) {
                this[_editor].setSelection(new monaco.Selection(lineNr, 1, lineNr, line.length + 1));
            }
            return true;
        };
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        this.deleteLine = (url, lineNr) => {
            return this.deleteLines(url, lineNr, 1);
        };
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        this.deleteLines = (url, startLine, countLines) => {
            const model = monaco.editor.getModel(monaco.Uri.parse(url));
            if (!model || model.isDisposed())
                throw new Error(`Invalid model ${url}`);
            model.pushEditOperations([], [{ range: new monaco.Range(startLine, 1, startLine + countLines, 1), text: '', forceMoveMarkers: true }], () => null);
            return true;
        };
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        this.updateLine = (url, lineNr, columnNr, newText) => {
            const model = monaco.editor.getModel(monaco.Uri.parse(url));
            if (!model || model.isDisposed())
                throw new Error(`Invalid model ${url}`);
            const lineContent = model.getLineContent(lineNr);
            const startColumn = columnNr;
            const endColumn = lineContent.length + 1;
            ;
            model.pushEditOperations([], [{
                    range: new monaco.Range(lineNr, startColumn, lineNr, endColumn),
                    text: newText,
                    forceMoveMarkers: true
                }], () => null);
            return true;
        };
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        this.finishEdit = (url) => {
            const model = monaco.editor.getModel(monaco.Uri.parse(url));
            if (!model || model.isDisposed())
                throw new Error(`Invalid model ${url}`);
            model.pushStackElement(); // Marks the end of a grouped edit
        };
        this[_editor] = editor;
    }
}
