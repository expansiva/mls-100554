/// <mls shortName="pluginSystemPrivacyPolicy" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Privacy Policy",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12,22A17.5,17.5,0,0,0,21,6.7V6L12,2,3,6v.7A17.5,17.5,0,0,0,12,22ZM11,6h2V8H11Zm0,4h2v8H11Z"/></svg>
    `;
    }
};
let PluginSystemPrivacyPolicy100554 = class PluginSystemPrivacyPolicy100554 extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.autoPrepare = false;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    async prepare() {
        await this.init();
    }
    async init() {
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="plugin-container">
                Privacy Policy
            </div>
        `;
    }
};
__decorate([
    property({ type: Boolean })
], PluginSystemPrivacyPolicy100554.prototype, "autoPrepare", void 0);
PluginSystemPrivacyPolicy100554 = __decorate([
    customElement('plugin-system-privacy-policy-100554')
], PluginSystemPrivacyPolicy100554);
export { PluginSystemPrivacyPolicy100554 };
