/// <mls shortName="agentCreateNewPrototypePage4" project="100554" enhancement="_blank" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import { createModel } from './_100554_collabLibModel';
import { startNewInteractionInAiTask, startNewAiTask, addNewStep } from "./_100554_aiAgentOrchestration";
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, updateStepStatus, updateTaskTitle, getNextPendentStep, appendLongTermMemory } from "./_100554_aiAgentHelper";
const agentName = "agentCreateNewPrototypePage4";
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Responsavel por fazer identificar os organismos que precisam ser alterados",
        visibility: "public",
        scope: ['l2_preview'],
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async replayForSupport(context, payload) {
            return _replayForSupport(context, payload);
        }
    };
}
;
const _beforePrompt = async (context) => {
    const taskTitle = "Planning";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        let pp = context.message.content
            .replace(`@@ ${agentName}`, '')
            .replace(`@@${agentName}`, '').trim();
        let data = JSON.parse(pp);
        const inputs = await getPrompts(data);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt, { project: data.project.toString(), shortName: data.shortName, folder: data.folder, link: data.link });
        return;
    }
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
    context = await updateStepStatus(context, step.stepId, "in_progress");
    if (!step.prompt)
        throw new Error(`[${agentName}] beforePrompt: No prompt found in step for this agent.`);
    const data = JSON.parse(step.prompt);
    await appendLongTermMemory(context, { project: data.project.toString(), shortName: data.shortName, folder: data.folder, link: data.link });
    const inputs = await getPrompts(data);
    await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    if (!context.task)
        throw new Error("Invalid context 2");
    const payload = getNextPendentStep(context.task);
    await updateFiles(context, payload);
    if (!context.task)
        throw new Error("Invalid context task");
    context.task = await updateTaskTitle(context.task, "Defs completed");
    //await verifyNeedNewStep(context, payload);
    //await executeNextStep(context);
};
const _replayForSupport = async (context, payload) => {
    const step = payload[0];
    if (!step || step.type !== 'flexible')
        throw new Error('Invalid step for replay');
    await updateFiles(context, step);
};
async function getPrompts(info) {
    if (!info || !info.project || !info.shortName || !info.folder)
        throw new Error(`Erro [${agentName}] getPrompts: invalid info`);
    const { project, folder, link, shortName } = info;
    /*const obj = typeof organism === 'string' ? JSON.parse(organism) : JSON.parse(JSON.stringify(organism));
    
    let shortName = obj.shift();*/
    const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, '.ts');
    if (!mls.stor.files[key])
        throw new Error(`Erro [${agentName}] getPrompts: not found stor`);
    const ts = await mls.stor.files[key].getContent();
    const data = {
        link,
        ts
    };
    const prompts = await getPromptByHtml({ project: 100554, shortName: agentName, folder: '', data });
    return prompts;
}
async function updateFiles(context, step) {
    if (!step || step.type !== 'flexible' || !step.result)
        throw new Error('Invalid step in update defs, type: "' + step?.type + '"');
    if (typeof step.result === 'string')
        return;
    const pageMemory = context.task?.iaCompressed?.longMemory;
    if (!pageMemory.project || !pageMemory.shortName || !pageMemory.folder || !step.result)
        throw new Error(`[${agentName}]Invalid step in update defs, type: ${step?.type} `);
    const { project, folder, shortName } = pageMemory;
    const result = step.result;
    /*const obj = typeof organism === 'string' ? JSON.parse(organism) : JSON.parse(JSON.stringify(organism));
    const shortName = obj.shift();*/
    const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, '.ts');
    if (!mls.stor.files[key])
        throw new Error(`Erro [${agentName}] updateFiles: not found stor `);
    if (!result.ts)
        throw new Error(`Erro [${agentName}] updateFiles: not found ts`);
    let models = mls.editor.getModels(project, shortName, folder);
    if (!models || !models.ts) {
        await createModel(mls.stor.files[key], true, false);
        models = mls.editor.getModels(project, shortName, folder);
    }
    if (!models || !models.ts)
        throw new Error(`Erro [${agentName}] updateFiles: not found models`);
    models.ts.model.setValue(result.ts);
}
async function verifyNeedNewStep(context, step) {
    if (!step || step.type !== 'flexible' || !step.result)
        throw new Error('Invalid step in update defs, type: "' + step?.type + '"');
    const pageMemory = context.task?.iaCompressed?.longMemory;
    if (!pageMemory.project || !pageMemory.shortName || !pageMemory.folder)
        throw new Error(`[${agentName}]Invalid step in update defs, type `);
    const { project, folder, organism } = pageMemory;
    const obj = typeof organism === 'string' ? JSON.parse(organism) : JSON.parse(JSON.stringify(organism));
    obj.shift();
    if (obj.length > 0) {
        const newStep = {
            agentName: 'agentCreateNewPrototypePage4',
            prompt: JSON.stringify({ project, shortName: pageMemory.shortName, folder, organism: obj, link: pageMemory.link }),
            status: 'pending',
            stepId: step.stepId + 1,
            interaction: null,
            nextSteps: null,
            rags: null,
            type: 'agent'
        };
        context = await addNewStep(context, step.stepId, [newStep]);
    }
}
