/// <mls shortName="icaApresentationSoundBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from '/_100554_/l2/icaLitElementBase.js';
export class IcaApresentationSoundBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaApresentationSoundBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
}
