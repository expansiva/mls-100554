/// <mls shortName="collabDsInputRange" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
export function initCollabDSInputRange() { }
;
let CollabDSInputRange = class CollabDSInputRange extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-ds-input-range-100554{display:grid;grid-template-columns:auto 1fr auto auto;gap:8px;align-items:center}collab-ds-input-range-100554 input[type="number"]{background-color:#f8f9fa;width:100%;min-width:80px;border-width:0px;border:none;border-radius:2px 0 0 2px;height:100%;color:black;font-size:11.5px;padding:0}collab-ds-input-range-100554>div{display:flex;border:1px solid #b5b4b4;border-radius:5px}collab-ds-input-range-100554>div input[type="number"]{border:none;padding:.1rem .1rem;outline:none;flex:1;width:100%;max-width:100px;min-width:50px;height:25px}collab-ds-input-range-100554>div select{display:block;border:0px;border-top-left-radius:0px;border-bottom-left-radius:0px;min-width:30px;padding:.1rem .1rem;outline:none;-webkit-appearance:none;font-size:13px;text-align-last:center;transition:all .3s;user-select:none;background-color:#fff;background-clip:padding-box;border-radius:.25rem;height:25px}collab-ds-input-range-100554>div select:hover{background-color:#40404054;color:white;transition:all .3s}collab-ds-input-range-100554 input[type="range"]::-webkit-input-placeholder{font-size:6px}`);
        this.arraySelect = [];
        this.useSelect = 'true';
        this.value = '';
        this.prop = '';
        this.min = 0;
        this.max = 100;
    }
    render() {
        //${this.renderInput()}
        return html `
            ${this.renderSelect()}
            
        `;
    }
    renderSelect() {
        return html `
            <div>
                <input type="number" .value="${this.onlyNumber(this.value)}" @input="${this.changeInput}"> </input>
                <select @change="${this.changeSelect}" style="${this.useSelect === 'false' ? 'display:none' : ''}">
                    ${repeat(this.arraySelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
                </select>
            </div>
        `;
    }
    updated() {
        const sel = this.querySelector('select');
        if (!sel)
            return;
        sel.value = this.onlyTxt(this.value);
    }
    //---------IMPLEMENTS-------------
    onlyNumber(str) {
        const regexNum = /(\d+(?:\.\d+)?)/;
        const res = str.match(regexNum);
        return res && res[0] ? res[0] : '';
    }
    onlyTxt(str) {
        const regexStr = /[a-zA-Z]+/;
        const res = str.match(regexStr);
        return res && res[0] ? res[0].replace('.', '') : 'px';
    }
    changeInput(e) {
        this.allChange(e, 'input');
    }
    changeSelect(e) {
        this.allChange(e, 'sel');
    }
    allChange(e, mode) {
        e.stopPropagation();
        let input = this.querySelector('input[type="number"]');
        let sel = this.querySelector('select');
        if (!input || !sel)
            return;
        this.value = input.value + sel.value;
        this.fireEvents({
            key: this.prop,
            value: input.value + sel.value
        });
    }
    fireEvents(obj) {
        obj.target = this;
        const onChangePropEvento = new CustomEvent('onchange', {
            bubbles: true,
            detail: obj
        });
        this.dispatchEvent(onChangePropEvento);
    }
};
__decorate([
    property()
], CollabDSInputRange.prototype, "useSelect", void 0);
__decorate([
    property()
], CollabDSInputRange.prototype, "value", void 0);
__decorate([
    property()
], CollabDSInputRange.prototype, "prop", void 0);
CollabDSInputRange = __decorate([
    customElement('collab-ds-input-range-100554')
], CollabDSInputRange);
export { CollabDSInputRange };
