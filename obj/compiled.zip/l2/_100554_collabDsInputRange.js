/// <mls shortName="collabDsInputRange" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
export function initCollabDSInputRange() { }
;
let CollabDSInputRange = class CollabDSInputRange extends LitElement {
    constructor() {
        super(...arguments);
        this.arraySelect = [];
        this.useSelect = 'true';
        this.value = '';
        this.prop = '';
        this.min = 0;
        this.max = 100;
    }
    render() {
        return html `
            ${this.renderInput()}
            ${this.renderSelect()}
            
        `;
    }
    renderInput() {
        return html `
            <input type="range" .value="${this.onlyNumber(this.value)}" min="${this.min}" max="${this.max}"   @input="${(e) => this.changeRange(e)}"></input>
        `;
    }
    renderSelect() {
        return html `
            <div>
                <input type="search" .value="${this.onlyNumber(this.value)}" @input="${this.changeInput}"> </input>
                <select @change="${this.changeSelect}" style="${this.useSelect === 'false' ? 'display:none' : ''}">
                    ${repeat(this.arraySelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
                </select>
            </div>
        `;
    }
    updated() {
        if (!this.shadowRoot)
            return;
        const sel = this.shadowRoot.querySelector('select');
        if (!sel)
            return;
        sel.value = this.onlyTxt(this.value);
    }
    //---------IMPLEMENTS-------------
    onlyNumber(str) {
        const regexNum = /(\d+(?:\.\d+)?)/;
        const res = str.match(regexNum);
        return res && res[0] ? res[0] : '';
    }
    onlyTxt(str) {
        const regexStr = /[a-zA-Z]+/;
        const res = str.match(regexStr);
        return res && res[0] ? res[0].replace('.', '') : '';
    }
    changeRange(e) {
        this.allChange(e, 'range');
    }
    changeInput(e) {
        this.allChange(e, 'input');
    }
    changeSelect(e) {
        this.allChange(e, 'sel');
    }
    allChange(e, mode) {
        e.stopPropagation();
        if (!this.shadowRoot)
            return;
        const parent = this.shadowRoot;
        let input = parent.querySelector('input[type="search"]');
        let range = parent.querySelector('input[type="range"]');
        let sel = parent.querySelector('select');
        if (!input || !sel || !range)
            return;
        if (mode === 'range') {
            input.value = range.value;
        }
        else if (mode === 'input') {
            const tot = this.onlyNumber(input.value);
            const max = range.max;
            if (!max || max < tot)
                range.max = tot;
            range.value = tot;
        }
        this.value = input.value + sel.value;
        this.fireEvents({
            key: this.prop,
            value: input.value + sel.value
        });
    }
    fireEvents(obj) {
        obj.target = this;
        const onChangePropEvento = new CustomEvent('onchange', {
            bubbles: true,
            detail: obj
        });
        this.dispatchEvent(onChangePropEvento);
    }
};
CollabDSInputRange.styles = css ` :host{display:flex;align-items:center;gap:1rem} :host input[type="range"]{background-color:#f8f9fa;width:120px;min-width:50px;border-width:0px;border:none;border-radius:2px 0 0 2px;height:100%;color:black;font-size:11.5px;padding:0} :host>div{display:flex;border:1px solid #b5b4b4;border-radius:5px} :host>div input[type="search"]{border:none;padding:.1rem .1rem;outline:none;width:60px} :host>div select{border:0px;border-top-left-radius:0px;border-bottom-left-radius:0px;min-width:45px;padding:.1rem .1rem;outline:none;-webkit-appearance:none;font-size:13px;text-align-last:center;transition:all .3s;user-select:none} :host>div select:hover{background-color:#40404054;color:white;transition:all .3s} :host input[type="range"]::-webkit-input-placeholder{font-size:11px}`;
__decorate([
    property()
], CollabDSInputRange.prototype, "useSelect", void 0);
__decorate([
    property()
], CollabDSInputRange.prototype, "value", void 0);
__decorate([
    property()
], CollabDSInputRange.prototype, "prop", void 0);
CollabDSInputRange = __decorate([
    customElement('collab-ds-input-range-100554')
], CollabDSInputRange);
export { CollabDSInputRange };
