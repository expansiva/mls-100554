/// <mls shortName="servicePrompt" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
let ServicePrompt100554 = class ServicePrompt100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-prompt-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);display:flex;flex-direction:column;padding:var(--space-16);background-color:var(--bg-primary-color-lighter)}service-prompt-100554 button{margin-top:var(--space-8);padding:var(--space-8) var(--space-16);background-color:var(--text-secondary-color);color:var(--bg-primary-color);border:none;border-radius:var(--space-base-unit);font-size:var(--font-size-16);cursor:pointer;transition:background-color var(--transition-normal)}service-prompt-100554 button svg{fill:currentColor}service-prompt-100554 button:hover{background-color:var(--text-secondary-color-hover)}service-prompt-100554 button[disabled]{pointer-events:none;opacity:.5}service-prompt-100554 .filter-container{display:flex;justify-content:start;align-items:center;gap:.5rem;padding:1rem}service-prompt-100554 .prompt-container{display:flex;flex-direction:column;align-items:flex-start;width:100%;scrollbar-width:thin;padding:1rem;background-color:var(--grey-color-light);border-radius:15px;margin:1rem 0}service-prompt-100554 .prompt-container textarea{width:98%;padding:var(--space-8);margin-right:var(--space-8);border:1px solid var(--grey-color-dark);border-radius:var(--space-base-unit);font-size:var(--font-size-16);color:var(--text-primary-color);transition:border-color var(--transition-normal)}service-prompt-100554 .prompt-container textarea:focus{border-color:var(--active-color);outline:none}service-prompt-100554 .prompt-container .prompt-action{display:flex;gap:1rem}service-prompt-100554 .prompt-container button{margin-top:var(--space-8);padding:var(--space-8) var(--space-16);background-color:var(--text-secondary-color);color:var(--bg-primary-color);border:none;border-radius:var(--space-base-unit);font-size:var(--font-size-16);cursor:pointer;transition:background-color var(--transition-normal)}service-prompt-100554 .prompt-container button svg{fill:currentColor}service-prompt-100554 .prompt-container button:hover{background-color:var(--text-secondary-color-hover)}service-prompt-100554 .prompts-results-container{display:flex;gap:1rem;flex-wrap:wrap}service-prompt-100554 .prompts-results-container svg{min-width:30px}service-prompt-100554 .prompts-results-container .card{position:relative;min-width:500px;max-width:500px;max-height:100px;flex:1;display:flex;align-items:center;gap:1rem;justify-content:space-between;background-color:var(--bg-secondary-color-lighter);border:1px solid var(--grey-color-darker);border-radius:var(--space-base-unit);padding:var(--space-16);margin-bottom:var(--space-16);cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.06);transition:box-shadow var(--transition-slow),transform var(--transition-normal)}service-prompt-100554 .prompts-results-container .card:hover{box-shadow:0 6px 12px rgba(0,0,0,0.12);transform:translateY(-2px)}service-prompt-100554 .prompts-results-container .card span{display:block;font-size:var(--font-size-12);margin-bottom:var(--space-8);width:400px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:justify}service-prompt-100554 .prompts-results-container .card .status{display:flex-inline;font-size:10px;color:#fff;padding:0 5px;border-radius:var(--space-base-unit);text-transform:uppercase;font-weight:bold;letter-spacing:.5px;width:100px;text-align:center}service-prompt-100554 .prompts-results-container .card .status.finalized{background-color:var(--success-color)}service-prompt-100554 .prompts-results-container .card .status.in-process{background-color:var(--active-color)}service-prompt-100554 .prompts-results-container .card .status.waiting{background-color:var(--warning-color)}service-prompt-100554 .prompts-results-container .card .status.canceled{background-color:var(--error-color)}service-prompt-100554 .prompts-results-container .card p{margin-top:var(--space-8);font-size:var(--font-size-12);color:var(--text-secondary-color);line-height:1.5}service-prompt-100554 .card-details{padding:var(--space-16);border-radius:5px;box-shadow:0 2px 8px rgba(0,0,0,0.1);display:flex;flex-direction:column;align-items:flex-start;gap:1rem}service-prompt-100554 .card-details pre{white-space:break-spaces}service-prompt-100554 .card-details .card-details-item{flex:1;width:calc(100% - var(--space-16)*2);padding:var(--space-16);border-radius:10px;background:var(--bg-secondary-color-lighter)}service-prompt-100554 .card-details .status{display:flex-inline;font-size:10px;color:#fff;padding:0 5px;border-radius:var(--space-base-unit);text-transform:uppercase;font-weight:bold;letter-spacing:.5px;width:100px;text-align:center}service-prompt-100554 .card-details .status.finalized{background-color:var(--success-color)}service-prompt-100554 .card-details .status.in-process{background-color:var(--active-color)}service-prompt-100554 .card-details .status.waiting{background-color:var(--warning-color)}service-prompt-100554 .card-details .status.canceled{background-color:var(--error-color)}service-prompt-100554 .card-details button{background:transparent;border:none;color:var(--active-color);cursor:pointer;margin-bottom:var(--space-16);font-size:var(--font-size-12)}@media (max-width:768px){service-prompt-100554 input[type="text"]{width:70%}}@media (max-width:544px){service-prompt-100554 input[type="text"],service-prompt-100554 button{width:100%;margin-bottom:var(--space-8)}service-prompt-100554 div{text-align:center}}`);
        this.details = {
            icon: '&#xf15b',
            state: 'foreground',
            position: 'right',
            tooltip: 'Service Example',
            visible: true,
            widget: '_100554_servicePrompt',
            level: [5]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: '',
            main: {},
            tabs: undefined,
            tools: {},
            onClickMain: undefined
        };
        this.uploadSvg = svg `<svg width=20 height=20 xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M288 109.3L288 352c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-242.7-73.4 73.4c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l128-128c12.5-12.5 32.8-12.5 45.3 0l128 128c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L288 109.3zM64 352l128 0c0 35.3 28.7 64 64 64s64-28.7 64-64l128 0c35.3 0 64 28.7 64 64l0 32c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64l0-32c0-35.3 28.7-64 64-64zM432 456a24 24 0 1 0 0-48 24 24 0 1 0 0 48z"/></svg>`;
        this.chat = svg `<svg xmlns="http://www.w3.org/2000/svg" width=20 height=20 viewBox="0 0 512 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M64 0C28.7 0 0 28.7 0 64L0 352c0 35.3 28.7 64 64 64l96 0 0 80c0 6.1 3.4 11.6 8.8 14.3s11.9 2.1 16.8-1.5L309.3 416 448 416c35.3 0 64-28.7 64-64l0-288c0-35.3-28.7-64-64-64L64 0z"/></svg>`;
        this.data = [
            {
                prompt: 'Resuma o artigo sobre mudanças climáticas.',
                status: 'finalized',
                result: [
                    {
                        type: 'result',
                        status: 'finalized',
                        price: 0.00001,
                        result: 'O artigo descreve os principais efeitos das mudanças climáticas e propõe soluções baseadas em energia renovável.'
                    }
                ]
            },
            {
                prompt: 'Gerar uma imagem de um castelo medieval à noite.',
                status: 'in-process',
                result: [{
                        type: 'tool',
                        toolName: 'ImageGenerator',
                        status: 'in-process',
                        args: JSON.stringify({ prompt: 'Castelo medieval à noite com céu estrelado', resolution: '800x600' })
                    }]
            },
            {
                prompt: 'Crie uma introdução para meu artigo sobre IA.',
                status: 'canceled',
                result: [{
                        type: 'agent',
                        agentName: 'TextWizard',
                        taskTitle: 'Criar introdução',
                        prompt: 'Crie uma introdução para um artigo acadêmico sobre os impactos positivos da IA na educação.',
                        status: 'canceled',
                        price: 0.00,
                        rags: null
                    }]
            },
            {
                prompt: 'Quais são os próximos passos do projeto?',
                status: 'waiting',
                result: [{
                        type: 'clarification',
                        status: 'waiting',
                        clarificationMessage: 'Você gostaria de ver os passos técnicos ou os de planejamento?',
                        htmlForm: '<form><select name="tipo"><option value="tecnico">Técnico</option><option value="planejamento">Planejamento</option></select></form>'
                    }]
            },
            {
                prompt: 'me ajude a criar um jogo de xadrez para web que permita dois jogadores',
                status: 'waiting',
                result: [{
                        type: "clarification",
                        status: 'finalized',
                        clarificationMessage: "Vamos precisar de mais detalhes para planejar seu jogo de xadrez. Por favor, especifique:",
                        htmlForm: `
                <form id='chessGameDetails'>
                    <div style='display: grid; gap: 1rem; padding: 1rem; background: #f5f5f5; border-radius: 8px;'>
                        <div>
                            <label>Recursos necessários:</label>
                            <div style='display: grid; gap: 0.5rem; margin-top: 0.5rem;' >
                                <label> <input type='checkbox' name = 'features' value='movement'> Validação de movimentos básicos</label >
                                <label> <input type='checkbox' name = 'features' value = 'check'> Detecção de xeque / xeque - mate </label>
                                <label> <input type='checkbox' name = 'features' value = 'history'> Histórico de jogadas </label>
                                <label> <input type='checkbox' name = 'features' value = 'timer' > Temporizador de partida </label>
                                <label> <input type='checkbox' name = 'features' value = 'multiplayer' > Multiplayer online </label>
                            </div>
                        </div>
                    <div >
                    <label>Tecnologias preferidas: </label>
                    <select name = 'tech' style = 'margin-top: 0.5rem; width: 100%; padding: 0.5rem;'>
                        <option value='any' > Qualquer tecnologia </option>
                        <option value = 'react' > React + Node.js </option>
                        <option value = 'vue' > Vue.js + Firebase </option>
                        <option value = 'vanilla' > JavaScript Vanilla </option>
                    </select>
                    </div>
                    <div>
                        <label>Deseja sistema de autenticação de usuários ? </label>
                        <select name = 'auth' style = 'margin-top: 0.5rem; width: 100%; padding: 0.5rem;'>
                            <option value='no' > Não necessário </option>
                            <option value = 'yes' > Sim, com login básico </option>
                            <option value = 'social' > Sim, com login social(Google / Facebook) </option>
                        </select>
                    </div>
                </div>
            </form>`
                    },
                    {
                        type: "agent",
                        status: 'waiting',
                        agentName: "agentPlannerNewProject",
                        taskTitle: "Planejamento de Jogo de Xadrez Online",
                        prompt: "Requisitos do sistema:\n\n1. **Regras do Jogo**\n- Validação de movimentos básicos para todas as peças\n- Detecção de xeque e xeque-mate\n- Histórico de jogadas em notação algébrica\n\n2. **Multiplayer Online**\n- Sistema de salas para partidas PvP\n- Comunicação em tempo real (WebSocket)\n- Identificação anônima sem login\n\n3. **Interface Web**\n- Tabuleiro interativo com arrastar-e-soltar\n- Painel lateral com histórico de jogadas\n- Indicadores de status do jogo (vez atual, xeque)\n\n4. **Requisitos Técnicos**\n- Tecnologia frontend (HTML5/CSS3/JavaScript)\n- Backend para gestão de partidas (Node.js/Python)\n- Banco de dados para persistência de partidas em andamento",
                        "rags": ["rag1"]
                    }
                ]
            }
        ];
        this.promptValue = '';
        this.selectedPromptIndex = null;
        this.filterStatus = 'all';
        this.currentPage = 0;
        this.itemsPerPage = 5;
    }
    onServiceClick(visible, reinit, el) {
    }
    handleInputChange(e) {
        const target = e.target;
        this.promptValue = target.value;
    }
    handleCardClick(index) {
        this.selectedPromptIndex = index;
    }
    goBackToList() {
        this.selectedPromptIndex = null;
    }
    handleFilterChange(e) {
        const target = e.target;
        this.filterStatus = target.value;
        this.currentPage = 0;
    }
    handlePageChange(direction) {
        if (direction === 'next' && (this.currentPage + 1) * this.itemsPerPage < this.data.length) {
            this.currentPage++;
        }
        else if (direction === 'prev' && this.currentPage > 0) {
            this.currentPage--;
        }
    }
    render() {
        if (this.selectedPromptIndex !== null) {
            const card = this.data[this.selectedPromptIndex];
            return html `
      <div class="card-details">
        <button @click=${this.goBackToList}>← Voltar</button>
        <h2>${card.prompt}</h2>
        <div class="status ${card.status}">${card.status}</div>

        ${card.result.map((result, index) => html `
                <details class="card-details-item">
                    <summary>${result.type}</summary>
                    ${this.renderDetails(result)}
                </details>
            `)}
      </div>
    `;
        }
        const filteredData = this.filterStatus === 'all' ? this.data : this.data.filter(card => card.status === this.filterStatus);
        const paginatedData = filteredData.slice(this.currentPage * this.itemsPerPage, (this.currentPage + 1) * this.itemsPerPage);
        const totalPages = Math.ceil(filteredData.length / this.itemsPerPage);
        return html `
    <div class="prompt-container">
      <textarea
        type="text"
        .value=${this.promptValue}
        @input=${this.handleInputChange}
        placeholder="Pergunte alguma coisa..."
        >
      </textarea>
      <div class="prompt-action">
        <button>${this.uploadSvg}</button>
        <button>Enviar</button>
      </div>
    </div>

    <div class="filter-container">
      <label for="statusFilter">Filtrar por status:</label>
      <select id="statusFilter" @change=${this.handleFilterChange}>
        <option value="all">Todos</option>
        <option value="in-process">Em processo</option>
        <option value="canceled">Cancelado</option>
        <option value="finalized">Finalizado</option>
        <option value="waiting">Aguardando</option>
      </select>
    </div>

    <div class="prompts-results-container">
        ${paginatedData.map((card, index) => html `
        <div class="card" @click=${() => this.handleCardClick(index + this.currentPage * this.itemsPerPage)}>
          ${this.chat}
          <span>${card.prompt}</span>
          <div class="status ${card.status}">${card.status}</div>
        </div>
      `)}
    </div>

    <div class="pagination-controls">
      <button @click=${() => this.handlePageChange('prev')} ?disabled=${this.currentPage === 0}>Anterior</button>
      <span>${this.currentPage + 1}/${totalPages}</span>
      <button @click=${() => this.handlePageChange('next')} ?disabled=${(this.currentPage + 1) * this.itemsPerPage >= filteredData.length}>Próximo</button>
    </div>
  `;
    }
    renderDetails(result) {
        switch (result.type) {
            case 'agent':
                return html `
        <p><strong>Agente:</strong> ${result.agentName}</p>
        <p><strong>Tarefa:</strong> ${result.taskTitle}</p>
        <p><strong>Prompt:</strong> ${result.prompt}</p>
        <p><strong>RAGs:</strong> ${result.rags?.join(', ') || 'Nenhum'}</p>
      `;
            case 'tool':
                return html `
        <p><strong>Ferramenta:</strong> ${result.toolName}</p>
        <p><strong>Argumentos:</strong> <pre>${result.args}</pre></p>
      `;
            case 'clarification':
                return html `
        <p><strong>Esclarecimento:</strong> ${result.clarificationMessage}</p>
        ${result.htmlForm ? html `<div .innerHTML=${result.htmlForm}></div> <button>Enviar<button>` : ''}
      `;
            case 'result':
                return html `
        <p><strong>Resultado:</strong> ${result.result}</p>
      `;
            default:
                return html `<p>Tipo de resultado desconhecido.</p>`;
        }
    }
};
__decorate([
    state()
], ServicePrompt100554.prototype, "data", void 0);
__decorate([
    state()
], ServicePrompt100554.prototype, "promptValue", void 0);
__decorate([
    state()
], ServicePrompt100554.prototype, "selectedPromptIndex", void 0);
__decorate([
    state()
], ServicePrompt100554.prototype, "filterStatus", void 0);
__decorate([
    state()
], ServicePrompt100554.prototype, "currentPage", void 0);
ServicePrompt100554 = __decorate([
    customElement('service-prompt-100554')
], ServicePrompt100554);
export { ServicePrompt100554 };
