/// <mls shortName="serviceSave" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { collab_branch } from './_100554_collabIcons';
import { initServiceSaveaddBranch } from './_100554_saveAddBranch';
import { getMyKeysBranch } from './_100554_libCommom';
import { getConfigProject, updateConfigProject } from './_100554_libProjectConfig';
initServiceSaveaddBranch();
/// **collab_i18n_start**
const message_pt = {
    openPullrequest: 'Pull request Abertos',
    needComment: 'Precisa de um comentario para o pullrequest',
    updateChanges: 'Atualizar alterações',
    comments: 'Comentários',
    update: 'Atualizar',
    fileChanges: 'Alterações de arquivos',
    noItemsToSave: 'Sem itens para salvar.',
    msgPullRequest: 'Este projeto utiliza pull requests, todas as alterações serão salvas no branch do seu usuário, para criar um pull request clique no botão',
    createPullRequest: "Criar pull request",
    create: 'Criar',
    cancel: 'Cancelar',
    title: 'Titulo',
    errorCreatePull: 'Erro ao tentar criar pull request',
    msgBlockAll: 'Você não tem acesso a este repositorio, por fvor entre em contato com o admin do projeto',
    msgBlock: 'Você não tem acesso de escrita neste repositorio, caso deseje criar um fork clique no botão abaixo',
    pullrequestOk: 'Pull request realizado com sucesso',
};
const message_en = {
    openPullrequest: 'Open pull requests',
    needComment: 'Need a comment for the pullrequest',
    updateChanges: 'Update Changes',
    comments: 'Comments',
    update: 'Update',
    fileChanges: 'File Changes',
    noItemsToSave: 'No items to save',
    msgPullRequest: 'This project uses pull requests, all changes will be saved in your user\'s branch, to create a pull request click the button',
    createPullRequest: "Create pull request",
    create: 'Create',
    cancel: 'Cancel',
    title: 'Title',
    errorCreatePull: 'Error when trying to create pull request',
    msgBlockAll: 'You do not have access to this repository, please contact the project admin',
    msgBlock: 'You do not have write access to this repository, if you wish to create a fork click the button below',
    pullrequestOk: 'Pull request completed successfully'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceSave = class ServiceSave extends ServiceBase {
    createRenderRoot() {
        return this;
    }
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-save-100554{font-family:var(--font-family-primary);font-size:var(--font-size-20);display:block;padding:1rem;overflow-y:auto;height:calc(100vh - 108px)}service-save-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}service-save-100554 button:hover{background-color:var(--grey-color-light)}service-save-100554 sectionsave{margin-top:1rem;display:block}service-save-100554 sectionsave .btnSave:hover{color:#fff;background-color:#007bff;border-color:#007bff}service-save-100554 sectionsave .btnSave{display:inline-block;color:#212529;text-align:center;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;background-color:transparent;border:1px solid transparent;padding:.375rem .75rem;font-size:1rem;line-height:1.5;border-radius:.25rem;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out}service-save-100554 sectionsave .mt-3,service-save-100554 sectionsave .my-3{margin-top:1rem !important}service-save-100554 sectionsave .form-control{display:block;width:98%;height:calc(1.5em + .75rem + 2px);padding:.375rem .75rem;font-size:1rem;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}service-save-100554 sectionsave .btnSave-primary{color:#fff;background-color:#007bff;border-color:#007bff}service-save-100554 sectionsave button,service-save-100554 sectionsave input,service-save-100554 sectionsave optgroup,service-save-100554 sectionsave select,service-save-100554 sectionsave textarea{margin:0;font-family:inherit;font-size:inherit;line-height:inherit}service-save-100554 sectionsave h4{margin-bottom:0rem}service-save-100554 sectionsaveheader{margin-top:.5rem;display:flex;justify-content:center;align-items:center;height:40px;border-bottom:1px solid #dee2e6 !important;font-weight:bold;font-size:1rem}service-save-100554 sectionnosave{margin-top:5px;display:flex;justify-content:center;align-items:center}service-save-100554 sectionsave{display:block}service-save-100554 sectionsave>ul{margin-top:.5rem;margin-left:0;padding-left:0px !important;list-style:none}service-save-100554 sectionsave li ul{list-style:none;padding-left:1rem !important}service-save-100554 sectionsave li ul{display:none}service-save-100554 sectionsave li.open>ul{display:block}service-save-100554 sectionsave li>div{display:flex;flex-direction:row;gap:.5rem}service-save-100554 sectionsave li>div input,service-save-100554 sectionsave li>div label{cursor:pointer;display:flex;justify-content:center;align-items:center;gap:.5rem}service-save-100554 sectionsave .fatv.fa-caret-righttv{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' height='1em' viewBox='0 0 256 512'><path d='M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z'/><path d='M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z'/></svg>");background-repeat:no-repeat;width:10px;background-position-y:center;padding:0;cursor:pointer}service-save-100554 sectionsave .fatv.fa-caret-righttv.rotate{transform:rotate(90deg)}service-save-100554 .fa-undo:hover,service-save-100554 .fa-clone:hover,service-save-100554 .fa-file-pen:hover,service-save-100554 .fa-trash:hover{filter:invert(39%) sepia(22%) saturate(4456%) hue-rotate(194deg) brightness(103%) contrast(101%)}`);
        this.myMessage = messages['en'];
        this.mainowner = '';
        this.mainrepo = '';
        this.mainbranch = '';
        this.owner = '';
        this.repo = '';
        this.branch = '';
        this.scenery = 'save';
        this.itens = undefined;
        this.otherProjects = [];
        this.error = '';
        this.details = {
            icon: '&#xf0c7',
            state: 'background',
            position: 'left',
            tooltip: 'Save',
            visible: true,
            widget: '_100554_serviceSave',
            level: [5]
        };
        this.onClickLink = (op) => {
            if (op === 'opSave')
                return this.showInitial();
            if (op === 'opBranch')
                return this.showBranche();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Save',
            actions: {
                opBranch: ''
            },
            icons: {},
            actionDefault: 'opSave', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
        };
        this.onMLSEvents = async (ev) => {
            if (ev.type !== 'FileAction')
                return;
            const fileAction = JSON.parse(ev.desc);
            if (!['changed', 'delete', 'new', 'rename'].includes(fileAction.action))
                return;
            this.scenery = 'save';
            if (this.isServiceVisible()) {
                this.init();
            }
            this.toogleBadge(true, '_100554_serviceSave');
        };
        this.oIcon = {
            nochange: { icon: 'fa-file-pen', title: 'Edited' },
            changed: { icon: 'fa-file-pen', title: 'Edited' },
            renamed: { icon: 'fa-clone', title: 'Renamed' },
            deleted: { icon: 'fa-xmark', title: 'Deleted' },
            //deleted: { icon: '&#xf1f8', title: 'Deleted' },f068
            //new: { icon: '&#xf006', title: 'New' }2b
            new: { icon: 'fa-plus', title: 'New' }
        };
        this.forceSaveL5ProjectFile = false;
        this.setEvents();
    }
    showInitial() {
        return true;
    }
    onServiceClick(visible, reinit) {
        if (visible && reinit) {
            this.updateList();
        }
        else if (visible && !reinit) {
            this.updateList();
        }
    }
    // -------------- EVENTS -------------------
    async setEvents() {
        mls.events.addListener(2, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(3, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(5, 'ProjectSelected', (ev) => { this.init(); });
        this.verifyExitFileChanged();
        await mls.stor.localDB.getAllProjects();
    }
    isServiceVisible() {
        return this.visible === 'true';
    }
    verifyExitFileChanged() {
        if (!mls.stor.files)
            return;
        const array = Object.keys(mls.stor.files);
        let exist = false;
        array.forEach((i) => {
            const f = mls.stor.files[i];
            if (!f)
                return;
            if (f.project === mls.actual[5].project && f.status !== 'nochange')
                exist = true;
        });
        if (!exist)
            return;
        this.toogleBadge(true, '_100554_serviceSave');
    }
    // -------------  WEBCOMPONENT -------------
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.myMessage = messages[lang];
        if (this.error !== '') {
            setTimeout(() => this.error = '', 3000);
            return html `${unsafeHTML(this.error)}`;
        }
        if (this.scenery !== 'save') {
            return this.renderBlockScenery();
        }
        if (this.itens) {
            return html `
                ${this.renderHeader()}
                ${this.renderItens()}
                ${this.renderOthersProjects()}
            `;
        }
        else if (this.otherProjects.length > 0) {
            return html `
                ${this.renderHeader()}
                ${this.renderOthersProjects()}
            `;
        }
        else {
            return html `
                ${this.renderHeader()}
                ${this.renderNoItens()}
            `;
        }
    }
    renderBlockScenery() {
        if (this.scenery === 'blockAll') {
            return html `
            <h4 style="margin-top:1rem; text-align:center">${this.myMessage.msgBlockAll}</h4>
            
        `;
        }
        return html `
            <h4 style="margin-top:1rem; text-align:center">${this.myMessage.msgBlock}</h4>
            <div style=" display: flex; justify-content: center; align-items: center; margin-top:1rem">
                <button @click="${this.createFork}" style=" display: flex; justify-content: center; align-items: center; margin: 0px; padding: 10px; height: 30px; background: #007bff; color: #fff;">
                    <svg width="16" height="16" fill="#fff" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path></svg>
                    Fork
                </button>
            </div>
        `;
    }
    renderHeader() {
        return html `
            <div style="display:flex; gap:1rem; font-size:.95rem; border-bottom: 1px solid #e2e1e1; padding-bottom: .5rem; position: relative">

                <div>
                    <span style="font-weight:600">Owner:</span>
                    <span>${this.owner}</span> 
                </div>
                <div>
                    <span style="font-weight:600">Repo:</span>
                    <span>${this.repo}</span> 
                </div>
                <div>
                    <span style="font-weight:600">Branch:</span>
                    <span>${this.branch}</span> 
                </div>

                <button style=" display: none; justify-content: center; align-items: center; margin: 0px; padding: 5px; height: 23px; " @click="${() => { if (this.menu.setMenuActive)
            this.menu.setMenuActive('opBranch'); }}">
                    ${collab_branch} Change
                </button>

            </div>
        `;
    }
    renderNoItens() {
        return html `
            <sectionnosave style="padding:1rem">
                <span>${unsafeHTML(this.myMessage.noItemsToSave)}</span> 
            </sectionnosave>  
        
        `;
    }
    renderOthersProjects() {
        this.filterOtherProject();
        return html `
        <sectionsave>
            <ul>
                ${repeat(this.otherProjects, ((key) => key), ((k, index) => {
            return html `
                            <li style="cursor: not-allowed;opacity: .5;">
                                <div style="cursor: not-allowed;">
                                    <span class="fatv fa-caret-righttv" style="cursor: not-allowed;"></span>
                                    <input type="checkbox" disabled style="cursor: not-allowed;">
                                    <label style="cursor: not-allowed;">${k}</label>
                                </div>
                            </li> `;
        }))}
            </ul>
        </sectionsave>
        `;
    }
    renderItens() {
        const keys = Object.keys(this.itens);
        return html `
            <sectionsave>
                <div id="Save_menu_action" style="display:flex;">
                    <div style="width:100%;" >
                        <h4 class="mt-3">${this.myMessage.comments}:</h4>
                        <textarea id="commitMessage" class="form-control" style="width:95%;" rows="2" maxlength="50"></textarea>
                    </div>
                    <div id="div_btn_save" class="text-right" style="width:79px; display: flex; align-items: self-end;">
                        <button id="btn_save" class="btnSave btn-sm btnSave-primary" @click="${this.onSave}">${this.myMessage.update}</button>
                    </div>
                </div>
                <h4 class="mt-3" data-mlsline="23">${this.myMessage.fileChanges}</h4>
                <ul>
                    ${repeat(keys, ((key) => key), ((k, index) => { return this.renderProject(k, index); }))}
                </ul>
            </sectionsave>  
        
        `;
    }
    renderProject(project, index) {
        const keys = Object.keys(this.itens[project]);
        return html `
        <li class="open">
            <div>
                <span class="fatv fa-caret-righttv" @click="${this.openMeList}"></span>
                <input type="checkbox" id="l0-${index}" @click="${this.clickSetValueAllChilds}">
                <label for="l0-${index}">${project}</label>
            </div>
            <ul>
                ${repeat(keys, ((key) => key), ((k, indexl) => { return this.renderLevels(k, project, index, indexl); }))}
            </ul>
        </li>
        `;
    }
    renderLevels(level, project, indexP, index) {
        if (level === '3') {
            return this.renderLevel3(level, project, indexP, index);
        }
        else {
            return this.renderLevelsDefault(level, project, indexP, index);
        }
    }
    renderLevel3(level, project, indexP, index) {
        const objP = this.itens[project];
        const keys = Object.keys(objP[level]);
        return html `
        <li class="open">
            <div>
                <span class="fatv fa-caret-righttv" @click="${this.openMeList}"></span>
                <input type="checkbox" id="l0-${project}-${index}" @click="${this.clickSetValueAllChilds}">
                <label for="l0-${project}-${index}">l${level}</label>
            </div>
            <ul>
                ${repeat(keys, ((key) => key), ((k, index3) => {
            const objL = objP[level];
            const objDS = objL[k];
            const itens = objDS ? objDS : [];
            return this.renderLevel4(itens, project, indexP, index, index3, k);
        }))}
            </ul>
        </li>
        `;
    }
    renderLevel4(itens, project, indexP, index, index3, k) {
        return html `
            <li>
                <div>
                    <span class="fatv fa-caret-righttv" @click="${this.openMeList}"></span>
                    <input type="checkbox" id="l0-${project}-${index}-${index3}" @click="${this.clickSetValueAllChilds}">
                    <label for="l0-${project}-${index}-${index3}">${k}</label>
                </div>
                <ul>                        
                    ${repeat(itens, ((item) => item), ((i, indexI) => { return this.renderItem(i, indexP, index, indexI); }))}
                </ul>
            </li>
        `;
    }
    renderLevelsDefault(level, project, indexP, index) {
        const objP = this.itens[project];
        let itens = objP[+level];
        itens = itens.sort((a, b) => a.text.localeCompare(b.text));
        return html `
        <li class="open">
            <div>
                <span class="fatv fa-caret-righttv" @click="${this.openMeList}" > </span>
                <input type = "checkbox" id = "l0-${project}-${index}" @click="${this.clickSetValueAllChilds}"/>
                <label for= "l0-${project}-${index}" > l${level} </label>
            </div>
                <ul> ${repeat(itens, ((item) => item), ((i, indexI) => { return this.renderItem(i, indexP, index, indexI); }))}
                </ul>
        </li>
        `;
    }
    renderItem(item, indexP, indexL, index) {
        return html `
        <li style="padding-left: 1.1rem;">
            <div>
                ${item.disabled || item.onlyFather
            ? html `<input type="checkbox" id="l0-${indexP}-${indexL}-${index}" disabled onlyStatusFather="${item.onlyFather}" @click="${this.clickVerifyStatusFather}" .instance=${item.file}>`
            : html `<input type="checkbox" id="l0-${indexP}-${indexL}-${index}" onlyStatusFather="${item.onlyFather}" @click="${this.clickVerifyStatusFather}" .instance=${item.file}>`}
                <label for= "l0-${indexP}-${indexL}-${index}" >

                    ${item.text}
                    ${unsafeHTML(item.span)}

                </label>
            </div>
        </li>
        `;
    }
    //-------- IMPLEMENTATION --------
    filterOtherProject() {
        const find = (f) => {
            let i = -1;
            this.otherProjects.forEach((prj, idx) => {
                if (prj === f)
                    i = idx;
            });
            return i;
        };
        let f = find(mls.actual[5].project);
        if (f >= 0)
            this.otherProjects.splice(f, 1);
        f = find(0);
        if (f >= 0)
            this.otherProjects.splice(f, 1);
    }
    async init(isSetInfoProject = true) {
        this.showLoader(true);
        this.scenery = 'save';
        if (isSetInfoProject)
            await this.initInfoProject();
        await this.setInfos();
        this.showLoader(false);
    }
    async initInfoProject() {
        const prj = mls.actual[5].project;
        if (!prj)
            return;
        const info = getMyKeysBranch(prj);
        if (!info)
            return;
        this.branch = info.branch;
        this.owner = info.owner;
        this.repo = info.repo;
        this.mainbranch = info.branch;
        this.mainowner = info.owner;
        this.mainrepo = info.repo;
    }
    showLoader(loader) {
        this.loading = loader;
    }
    showBranche() {
        this.menu.title = 'Branchs';
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        const div = document.createElement('div');
        const el = document.createElement('save-add-branch-100554');
        el.callBack = (obj) => {
            if (obj.nameWithOwner) {
                const ret = obj.nameWithOwner.split('/');
                this.owner = ret[0];
                this.repo = ret[1];
                this.branch = obj.defaultBranchRef.name;
            }
            else {
                this.branch = obj.name;
            }
            if (this.menu.setMenuActive)
                this.menu.setMenuActive('initial');
            this.requestUpdate();
        };
        div.appendChild(el);
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    async setInfos() {
        try {
            const objProjects = {};
            const filesKeys = Object.keys(mls.stor.files);
            this.otherProjects = await mls.stor.localDB.getAllProjects();
            for (const fKey of filesKeys) {
                const file = mls.stor.files[fKey];
                if (
                /*(!file.inLocalStorage && file.status === 'nochange') ||
                file.status === 'nochange' ||*/
                (!file.inLocalStorage && file.status !== 'deleted') ||
                    file.project === 0 || file.project !== mls.actual[5].project)
                    continue;
                const pj = file.project;
                const level = file.level;
                if (!objProjects[pj])
                    objProjects[pj] = {};
                const obj = objProjects[pj];
                if (!obj[level] && level === 3) {
                    const nNivel = file.folder.split('/');
                    if (nNivel.length >= 2) {
                        obj[level] = { [nNivel[1]]: [await this.configItem(file)] };
                    }
                }
                else if (!obj[level]) {
                    obj[level] = [await this.configItem(file)];
                }
                else if (obj[level] && level === 3) {
                    const nNivel = file.folder.split('/');
                    const obj3 = obj[level];
                    if (nNivel.length >= 2 && obj3[nNivel[1]]) {
                        obj3[nNivel[1]].push(await this.configItem(file));
                    }
                }
                else {
                    obj[level].push(await this.configItem(file));
                }
            }
            if (Object.keys(objProjects).length > 0) {
                this.itens = objProjects;
            }
            else {
                this.itens = undefined;
                this.toogleBadge(false, '_100554_serviceSave');
            }
        }
        catch (e) {
            this.itens = undefined;
            this.error = e.message;
            this.setError(e.message);
        }
    }
    async configItem(item) {
        let mountText = item.shortName + item.extension;
        let disabled = false;
        let span = `<span style = "font-size: 12px; color: #7678a6; margin-left: 5px;" class="fa ${this.oIcon[item.status].icon}" title = "${this.oIcon[item.status].title}" > </span>`;
        if (item.hasError && item.status !== 'deleted') {
            span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px; height: 16px;" class="fa fa-bug" title="Error"></span>';
            disabled = true;
        }
        if (item.isLocalVersionOutdated) {
            span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px;" class="fa fa-unbalanced" title="Version block"></span>';
            disabled = true;
        }
        if (item.status === 'renamed' && item.getValueInfo) {
            const itemNew = await item.getValueInfo();
            mountText = `${itemNew.originalShortName + item.extension} to ${mountText} `;
        }
        return {
            file: item,
            text: mountText,
            span: span,
            onlyFather: item.level === 3,
            disabled: disabled,
        };
    }
    openMeList(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const li = el.closest('li');
        if (!li)
            return;
        li.classList.toggle('open');
    }
    clickSetValueAllChilds(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.setValueAllChilds(el);
    }
    setValueAllChilds(el) {
        const father = el.closest('li');
        if (!father)
            return;
        const subList = father.querySelector('ul');
        if (!subList)
            return;
        const all = subList.querySelectorAll('input');
        all.forEach((i) => {
            const onlyStatusFather = i.getAttribute('onlyStatusFather') === 'true';
            if (i.disabled && !onlyStatusFather)
                return;
            i.checked = el.checked;
        });
        if (all.length === 1 && all[0].disabled)
            el.checked = false;
    }
    clickVerifyStatusFather(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.verifyStatusFather(el);
    }
    verifyStatusFather(el) {
        const father = el.closest('ul');
        if (!father)
            return;
        const grandfather = father.closest('li');
        if (!grandfather)
            return;
        const inpMain = grandfather.querySelector('input');
        if (!inpMain)
            return;
        if (el.checked) {
            inpMain.checked = true;
            return;
        }
        let needDisable = true;
        const all = father.querySelectorAll('input');
        all.forEach((i) => {
            if (i.checked)
                needDisable = false;
        });
        if (needDisable)
            inpMain.checked = false;
    }
    async updateList() {
        try {
            this.showLoader(true);
            this.fireEventsDetails();
            await this.setInfos();
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
        }
    }
    async fireOnPullrequest(e) {
        try {
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            this.showLoader(true);
            const driver = mls.stor.others.getDefaultDriver(prj);
            const opt = {
                owner: this.owner,
                repo: this.repo,
                branch: this.branch,
                title: 'Pull request',
                description: 'Pull request'
            };
            const ret = await driver.createPullRequest(opt);
            if (!ret)
                throw new Error('Error Pull request');
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error fireOnPullrequest');
        }
    }
    async createFork(e) {
        try {
            e.stopPropagation();
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            this.showLoader(true);
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            if (!info || !info.login) {
                const user = await driver.getUserInfo();
                info.login = user.login;
                this.setLocalHIstoryCurrentInfoDriver(user.login);
            }
            const ret = await driver.createFork(info.login, info.repo, info.owner, info.login);
            if (!ret)
                throw new Error('Error create fork');
            this.owner = info.login;
            this.repo = info.repo;
            this.branch = 'main';
            this.setLocalHIstoryCurrentInfoDriver();
            this.init(false);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error onCreateFork');
        }
    }
    //Sempre que salvar vai gerar um novo branch no usuario e solicitar um pullrequest.
    async onSave(e) {
        try {
            e.stopPropagation();
            const el = e.target;
            if (!el)
                return;
            const father = el.closest('sectionsave');
            if (!father)
                return;
            const txt = father.querySelector('textarea');
            if (!txt.value) {
                throw new Error(this.myMessage.needComment);
            }
            this.showLoader(true);
            if (!mls.l5.actualOrg)
                throw new Error('No organization selected');
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const actualOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
            const config = await getConfigProject(prj, true);
            if (!config)
                throw new Error('Not found config file in this project');
            const configOrg = config.orgName;
            if (actualOrg !== configOrg) {
                config.orgName = actualOrg;
                await updateConfigProject(prj, config);
                this.forceSaveL5ProjectFile = true;
            }
            const msg = txt.value;
            const array = this.getAllFileToSave(father);
            const oldOwner = this.owner;
            const oldRepo = this.repo;
            const oldBranch = this.branch;
            await this.fireCreateForkOrUpdate();
            console.info('gerou o fork');
            await this.fireCreateNewBranch();
            console.info('gerou o branche');
            await this.onSavenewPullrequest(array, msg);
            console.info('gerou o push');
            await this.firePullrequest(msg);
            console.info('gerou o pullrequest');
            txt.value = '';
            this.clearLocalHIstoryCurrentInfoDriver();
            this.owner = oldOwner;
            this.repo = oldRepo;
            this.branch = oldBranch;
            await this.setInfos();
            this.fireEvents();
            window.collabMessages.add(this.myMessage.pullrequestOk, 'information', { timeToClose: 5000, autoClose: true });
            this.showLoader(false);
        }
        catch (err) {
            this.error = err.message;
            this.setError(err.message);
            this.showLoader(false);
            console.info('Error onSave:', err);
        }
    }
    async onSavenewPullrequest(ar, msg) {
        if (ar.length <= 0)
            return;
        try {
            const arrSet = [];
            ar.forEach((i) => {
                i.inLocalStorage = false;
                if (!i.onAction)
                    i.onAction = (action) => this.afterUpdate(i);
                arrSet.push(i);
            });
            if (arrSet.length > 0) {
                await mls.stor.setContents(arrSet, msg);
            }
            return;
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
        }
    }
    async fireCreateForkOrUpdate() {
        try {
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            const user = await driver.getUserInfo();
            info.login = user.login;
            const isForkExist = await driver.checkForkIO(this.owner, this.repo, info.login);
            if (!isForkExist) {
                console.info('criou um novo fork');
                const ret = await driver.createFork(info.login, this.repo, this.owner, info.login);
                if (!ret)
                    throw new Error('Error create fork');
                this.owner = info.login;
                this.branch = 'main';
            }
            else {
                console.info('atualizou fork');
                const opt = {
                    repoOrigin: this.repo,
                    ownerOrigin: this.owner,
                    branchOrigin: 'main',
                    repoDest: this.repo,
                    ownerDest: info.login,
                    branchDest: 'main',
                };
                const ret = await driver.syncFork(opt);
                if (!ret)
                    throw new Error('Error sync fork');
                this.owner = info.login;
            }
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error fireCreateForkOrUpdate: ' + e.message);
            throw new Error(e.message + ' in: fireCreateForkOrUpdate');
        }
    }
    async fireCreateNewBranch() {
        try {
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const driver = mls.stor.others.getDefaultDriver(prj);
            const user = await driver.getUserInfo();
            const login = user.login;
            const newBranch = login + '_' + Date.now().toString();
            const ret = await driver.createNewBranch({ owner: this.owner, repo: this.repo, branch: this.branch, newBranch: newBranch });
            if (!ret)
                throw new Error('Error create Branch');
            this.branch = newBranch;
            this.setLocalHIstoryCurrentInfoDriver();
        }
        catch (err) {
            throw new Error(err.message + ' in: fireCreateNewBranch');
        }
    }
    async firePullrequest(msg) {
        try {
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const driver = mls.stor.others.getDefaultDriver(prj);
            const opt = {
                owner: this.owner,
                repo: this.repo,
                branch: this.branch,
                title: msg,
                description: msg
            };
            const ret = await driver.createPullRequest(opt);
            if (!ret)
                throw new Error('Error Pull request');
        }
        catch (err) {
            throw new Error(err.message + ' in: firePullrequest');
        }
    }
    //Manter para no futuro implementarmos o modo de salvar direto no repo.
    async onSave_withOutPullRequest(e) {
        try {
            e.stopPropagation();
            const el = e.target;
            if (!el)
                return;
            const father = el.closest('sectionsave');
            if (!father)
                return;
            this.showLoader(true);
            if (!mls.l5.actualOrg)
                throw new Error('No organization selected');
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const actualOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
            const config = await getConfigProject(prj, true);
            if (!config)
                throw new Error('Not found config file in this project');
            const configOrg = config.orgName;
            if (actualOrg !== configOrg) {
                config.orgName = actualOrg;
                await updateConfigProject(prj, config);
                this.forceSaveL5ProjectFile = true;
            }
            const txt = father.querySelector('textarea');
            const array = this.getAllFileToSave(father);
            const msg = txt ? txt.value : '';
            setTimeout(async () => {
                try {
                    this.setLocalHIstoryCurrentInfoDriver();
                    const p = await this.veriFyPermission();
                    if (p.read && !p.write) {
                        this.scenery = 'block';
                        this.showLoader(false);
                        this.requestUpdate();
                        return;
                    }
                    else if (!p.read && !p.write) {
                        this.scenery = 'blockAll';
                        this.showLoader(false);
                        this.requestUpdate();
                        return;
                    }
                    //await this.verifyVersionBlock(array);
                    await this.onSavenew(array, msg);
                    await this.setInfos();
                    this.fireEvents();
                    this.showLoader(false);
                }
                catch (e) {
                    this.error = e.message;
                    this.setError(e.message);
                    this.showLoader(false);
                }
            }, 500);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error onSave');
        }
    }
    async veriFyPermission() {
        try {
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            if (!info || !info.login) {
                const user = await driver.getUserInfo();
                info.login = user.login;
                this.setLocalHIstoryCurrentInfoDriver(user.login);
            }
            const p = driver.verifyPermission(info.owner, info.repo, info.login);
            return p;
        }
        catch (e) {
            throw new Error(e.message);
        }
    }
    clearLocalHIstoryCurrentInfoDriver() {
        const prj = mls.actual[5].project;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        if (info[prj])
            delete info[prj];
        localStorage.setItem('InfoCurrentDriver', JSON.stringify(info));
    }
    setLocalHIstoryCurrentInfoDriver(user = undefined) {
        const prj = mls.actual[5].project;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        info[prj] = {
            owner: this.owner,
            repo: this.repo,
            branch: this.branch,
            login: user ? user : info.login
        };
        localStorage.setItem('InfoCurrentDriver', JSON.stringify(info));
    }
    getLocalHIstoryCurrentInfoDriver() {
        const prj = mls.actual[5].project;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        if (info[prj])
            return info[prj];
        return {};
    }
    getAllFileToSave(father) {
        const ar = [];
        if (this.forceSaveL5ProjectFile) {
            const allChecks = father.querySelectorAll('input[type="checkbox"][onlyStatusFather]');
            allChecks.forEach((item) => {
                if (item.instance
                    && item.instance.level === 5
                    && item.instance.shortName === 'project'
                    && item.instance.extension === '.json') {
                    item.checked = true;
                }
            });
            this.forceSaveL5ProjectFile = false;
        }
        const els = father.querySelectorAll('input[type="checkbox"][onlyStatusFather]:checked');
        els.forEach((el) => {
            if (el.instance) {
                ar.push(el.instance);
                const info = el.instance;
                if (info.extension === '.ts' && info.status === 'deleted') {
                    const key = mls.stor.getKeyToFiles(info.project, info.level, info.shortName, info.folder, '.html');
                    const fl = mls.stor.files[key];
                    if (!fl || fl.status === 'new')
                        return;
                    fl.status = 'deleted';
                    ar.push(fl);
                }
            }
        });
        return ar;
    }
    async onSavenew(ar, msg) {
        if (ar.length <= 0)
            return;
        try {
            let versionBLock = 0;
            const arrSet = [];
            ar.forEach((i) => {
                if (i.isLocalVersionOutdated && !['new', 'deleted'].includes(i.status)) {
                    versionBLock++;
                    return;
                }
                i.inLocalStorage = false;
                if (!i.onAction)
                    i.onAction = (action) => this.afterUpdate(i);
                arrSet.push(i);
            });
            if (arrSet.length > 0) {
                await mls.stor.setContents(arrSet, msg);
                await this.uppVersionAfterSave(arrSet);
                this.fireEvents(800);
            }
            if (versionBLock > 0) {
                window.collabMessages.add(`File ${versionBLock} was changed in server, file was not save`, 'information');
            }
            return;
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
        }
    }
    async afterUpdate(storFile) {
        const mmodel = mls.editor.getModels(storFile.project, storFile.shortName);
        if (storFile.status === 'deleted') {
            this.deleteFile(storFile);
            return;
        }
        if (storFile.status === 'renamed' && mmodel && mmodel.ts) {
            mmodel.ts.originalProject = undefined;
            mmodel.ts.originalShortName = undefined;
            mmodel.ts.originalCRC = mls.common.crc.crc32(mmodel.ts.model.getValue()).toString(16);
        }
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        storFile.status = 'nochange';
    }
    async uppVersionAfterSave(array) {
        try {
            const driver = mls.stor.others.getDefaultDriver(mls.actual[5].project);
            if (!driver || !driver.getVersionFromFiles)
                return;
            const info = await driver.getVersionFromFiles(this.owner, this.repo, this.branch, array);
            if (!info)
                return;
            for await (const a of array) {
                const key = mls.stor.getKeyToFiles(a.project, a.level, a.shortName, a.folder, a.extension);
                if (!mls.stor.files[key] || !info[key])
                    continue;
                mls.stor.files[key].versionRef = info[key];
                mls.stor.files[key].isLocalVersionOutdated = false;
                mls.stor.files[key].newVersionRefIfOutdated = undefined;
                await mls.stor.localStor.setContent(mls.stor.files[key], { contentType: 'string', content: null });
            }
        }
        catch (e) {
            console.info(e);
            return;
        }
    }
    /*private async uppVersionAfterSave(array: mls.stor.IFileInfo[]) {

        const driver = mls.stor.others.getDefaultDriver(mls.actual[5].project as number);
        const retArray = await driver.loadFilesInfo(mls.actual[5].project as number);

        const arrayVersion = this.createArrayInfoVersion(array);

        retArray.forEach(async (i) => {

            const file = arrayVersion.filter((f) => f.name === i.ShortPath);
            if (!file || file.length <= 0 || (file && file.length >= 1 && file[0].version === i.versionRef)) return;

            if (file[0].version !== i.versionRef) {
                file[0].file.versionRef = i.versionRef;
                file[0].file.isLocalVersionOutdated = false;
                file[0].file.newVersionRefIfOutdated = undefined;
                await mls.stor.localStor.setContent(file[0].file, { contentType: 'string', content: null });

            }

        });

    }

    private async verifyVersionBlock(array: mls.stor.IFileInfo[]) {

        try {

            if (array.length <= 0) return;
            const ret = await mls.stor.server.loadProjectInfoIfNeeded(mls.actual[5].project as number, true);

        } catch (e: any) {
            console.info('Error save verifyVersionBlock:' + e.message);
        }

    }

    private createArrayInfoVersion(array: mls.stor.IFileInfo[]): { name: string, version: string, file: mls.stor.IFileInfo }[] {

        const ret: any = [];
        array.forEach((i) => {

            ret.push({
                name: `l${i.level}/${i.folder ? i.folder + '/' : ''}${i.shortName}${i.extension}`,
                version: i.versionRef,
                file: i
            })

        })
        return ret;
    }*/
    async deleteFile(storFile) {
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        mls.editor.deleteModels(storFile.project, storFile.shortName, true);
        const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
        delete mls.stor.files[keyFiles];
    }
    fireEvents(time = 0) {
        const params = {};
        params.action = 'projectListChanged';
        params.level = 5;
        params.project = mls.actual[5].project;
        params.position = this.position;
        mls.events.fire([5], ['FileAction'], JSON.stringify(params), time);
        this.fireEventsDetails();
    }
    fireEventsDetails() {
        const options = {
            shortName: undefined,
            project: undefined,
            htmlText: '<plugin-verify-error-100554 autoPrepare="true"></plugin-verify-error-100554><plugin-pullrequest-100554 autoPrepare="true"></plugin-pullrequest-100554>'
        };
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
};
__decorate([
    property()
], ServiceSave.prototype, "itens", void 0);
__decorate([
    property()
], ServiceSave.prototype, "otherProjects", void 0);
__decorate([
    property()
], ServiceSave.prototype, "error", void 0);
ServiceSave = __decorate([
    customElement('service-save-100554')
], ServiceSave);
export { ServiceSave };
