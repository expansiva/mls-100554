/// <mls shortName="serviceSave" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, unsafeHTML, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { collab_branch } from './_100554_collabIcons';
import { initServiceSaveaddBranch } from './_100554_saveAddBranch';
import { getMyKeysBranch } from './_100554_libCommom';
initServiceSaveaddBranch();
/// **collab_i18n_start**
const message_pt = {
    updateChanges: 'Atualizar alterações',
    comments: 'Comentários',
    update: 'Atualizar',
    fileChanges: 'Alterações de arquivos',
    noItemsToSave: 'Nenhum item para salvar',
    msgPullRequest: 'Este projeto utiliza pull requests, todas as alterações serão salvas no branch do seu usuário, para criar um pull request clique no botão',
    createPullRequest: "Criar pull request",
    create: 'Criar',
    cancel: 'Cancelar',
    title: 'Titulo',
    errorCreatePull: 'Erro ao tentar criar pull request',
    msgBlockAll: 'Você não tem acesso a este repositorio, por fvor entre em contato com o admin do projeto',
    msgBlock: 'Você não tem acesso de escrita neste repositorio, caso deseje criar um fork clique no botão abaixo',
};
const message_en = {
    updateChanges: 'Update Changes',
    comments: 'Comments',
    update: 'Update',
    fileChanges: 'File Changes',
    noItemsToSave: 'No items to save',
    msgPullRequest: 'This project uses pull requests, all changes will be saved in your user\'s branch, to create a pull request click the button',
    createPullRequest: "Create pull request",
    create: 'Create',
    cancel: 'Cancel',
    title: 'Title',
    errorCreatePull: 'Error when trying to create pull request',
    msgBlockAll: 'You do not have access to this repository, please contact the project admin',
    msgBlock: 'You do not have write access to this repository, if you wish to create a fork click the button below',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceSave = class ServiceSave extends ServiceBase {
    constructor() {
        super();
        this.myMessage = messages['en'];
        this.owner = '';
        this.repo = '';
        this.branch = '';
        this.scenery = 'save';
        this.itens = undefined;
        this.error = '';
        this.details = {
            icon: '&#xf0c7',
            state: 'background',
            position: 'left',
            tooltip: 'Save',
            visible: true,
            widget: '_100554_serviceSave',
            level: [5]
        };
        this.onClickLink = (op) => {
            if (op === 'opSave')
                return this.showInitial();
            if (op === 'opBranch')
                return this.showBranche();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Save',
            actions: {
                opBranch: ''
            },
            icons: {},
            actionDefault: 'opSave', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
        };
        this.onMLSEvents = async (ev) => {
            if (ev.type !== 'FileAction')
                return;
            const fileAction = JSON.parse(ev.desc);
            if (!['changed', 'delete', 'new', 'rename'].includes(fileAction.action))
                return;
            this.scenery = 'save';
            if (this.isServiceVisible()) {
                this.init();
            }
            this.toogleBadge(true, '_100554_serviceSave');
        };
        this.oIcon = {
            nochange: { icon: 'fa-file-pen', title: 'Edited' },
            changed: { icon: 'fa-file-pen', title: 'Edited' },
            renamed: { icon: 'fa-clone', title: 'Renamed' },
            deleted: { icon: 'fa-xmark', title: 'Deleted' },
            //deleted: { icon: '&#xf1f8', title: 'Deleted' },f068
            //new: { icon: '&#xf006', title: 'New' }2b
            new: { icon: 'fa-plus', title: 'New' }
        };
        this.setEvents();
    }
    showInitial() {
        return true;
    }
    showBranche() {
        this.menu.title = 'Branchs';
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        const div = document.createElement('div');
        const el = document.createElement('save-add-branch-100554');
        el.callBack = (obj) => {
            if (obj.nameWithOwner) {
                const ret = obj.nameWithOwner.split('/');
                this.owner = ret[0];
                this.repo = ret[1];
                this.branch = obj.defaultBranchRef.name;
            }
            else {
                this.branch = obj.name;
            }
            if (this.menu.setMenuActive)
                this.menu.setMenuActive('initial');
            this.requestUpdate();
        };
        div.appendChild(el);
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    onServiceClick(visible, reinit) {
        if (visible && reinit) {
            this.updateList();
        }
        else if (visible && !reinit) {
            this.updateList();
        }
    }
    // -------------- EVENTS -------------------
    setEvents() {
        mls.events.addListener(2, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(3, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(5, 'ProjectSelected', (ev) => { this.init(); });
        this.verifyExitFileChanged();
    }
    isServiceVisible() {
        return this.visible === 'true';
    }
    verifyExitFileChanged() {
        if (!mls.stor.files)
            return;
        const array = Object.keys(mls.stor.files);
        let exist = false;
        array.forEach((i) => {
            const f = mls.stor.files[i];
            if (!f)
                return;
            if (f.project === mls.actual[5].project && f.status !== 'nochange')
                exist = true;
        });
        if (!exist)
            return;
        this.toogleBadge(true, '_100554_serviceSave');
    }
    // -------------  WEBCOMPONENT -------------
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.myMessage = messages[lang];
        if (this.error !== '') {
            setTimeout(() => this.error = '', 3000);
            return html `${this.error}`;
        }
        if (this.scenery !== 'save') {
            return this.renderBlockScenery();
        }
        if (this.itens) {
            return html `
                ${this.renderHeader()}
                ${this.renderItens()}
            `;
        }
        else {
            return html `
                ${this.renderNoItens()}
            `;
        }
    }
    renderBlockScenery() {
        if (this.scenery === 'blockAll') {
            return html `
            <h4 style="margin-top:1rem; text-align:center">${this.myMessage.msgBlockAll}</h4>
            
        `;
        }
        return html `
            <h4 style="margin-top:1rem; text-align:center">${this.myMessage.msgBlock}</h4>
            <div style=" display: flex; justify-content: center; align-items: center; margin-top:1rem">
                <button @click="${this.createFork}" style=" display: flex; justify-content: center; align-items: center; margin: 0px; padding: 10px; height: 30px; background: #007bff; color: #fff;">
                    <svg width="16" height="16" fill="#fff" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path></svg>
                    Fork
                </button>
            </div>
        `;
    }
    renderHeader() {
        return html `
            <div style="display:flex; gap:1rem; font-size:.95rem; border-bottom: 1px solid #e2e1e1; padding-bottom: .5rem; position: relative">

                <div>
                    <span style="font-weight:600">Owner:</span>
                    <span>${this.owner}</span> 
                </div>
                <div>
                    <span style="font-weight:600">Repo:</span>
                    <span>${this.repo}</span> 
                </div>
                <div>
                    <span style="font-weight:600">Branch:</span>
                    <span>${this.branch}</span> 
                </div>

                <button style=" display: flex; justify-content: center; align-items: center; margin: 0px; padding: 5px; height: 23px; " @click="${() => { if (this.menu.setMenuActive)
            this.menu.setMenuActive('opBranch'); }}">
                    ${collab_branch} Change
                </button>

                <button style=" display: flex; justify-content: center; align-items: center; margin: 0px; padding: 5px; height: 23px; background: #007bff; color: #fff; position: absolute; right: 0px;">
                    <svg width="16" height="16" fill="#fff" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path></svg>
                    Pull request
                </button>

            </div>
        `;
    }
    renderNoItens() {
        return html `
            <sectionnosave>
                <span>${this.myMessage.noItemsToSave}</span> 
            </sectionnosave>  
        
        `;
    }
    renderItens() {
        const keys = Object.keys(this.itens);
        return html `
            <sectionsave>
                <div id="Save_menu_action" style="display:flex;">
                    <div style="width:100%;" >
                        <h4 class="mt-3">${this.myMessage.comments}:</h4>
                        <textarea id="commitMessage" class="form-control" style="width:95%;" rows="2" maxlength="50"></textarea>
                    </div>
                    <div id="div_btn_save" class="text-right" style="width:79px; display: flex; align-items: self-end;">
                        <button id="btn_save" class="btnSave btn-sm btnSave-primary" @click="${this.onSave}">${this.myMessage.update}</button>
                    </div>
                </div>
                <h4 class="mt-3" data-mlsline="23">${this.myMessage.fileChanges}</h4>
                <ul>
                    ${repeat(keys, ((key) => key), ((k, index) => {
            return this.renderProject(k, index);
        }))}
                </ul>
            </sectionsave>  
        
        `;
    }
    renderProject(project, index) {
        const keys = Object.keys(this.itens[project]);
        return html `
        <li>
            <div>
                <span class="fatv fa-caret-righttv" @click="${this.openMeList}"></span>
                <input type="checkbox" id="l0-${index}" @click="${this.clickSetValueAllChilds}">
                <label for="l0-${index}">${project}</label>
            </div>
            <ul>
                ${repeat(keys, ((key) => key), ((k, indexl) => {
            return this.renderLevels(k, project, index, indexl);
        }))}
            </ul>
        </li>
        `;
    }
    renderLevels(level, project, indexP, index) {
        if (level === '3') {
            return this.renderLevel3(level, project, indexP, index);
        }
        else {
            return this.renderLevelsDefault(level, project, indexP, index);
        }
    }
    renderLevel3(level, project, indexP, index) {
        const objP = this.itens[project];
        const keys = Object.keys(objP[level]);
        return html `
        <li>
            <div>
                <span class="fatv fa-caret-righttv" @click="${this.openMeList}"></span>
                <input type="checkbox" id="l0-${project}-${index}" @click="${this.clickSetValueAllChilds}">
                <label for="l0-${project}-${index}">l${level}</label>
            </div>
            <ul>
                ${repeat(keys, ((key) => key), ((k, index3) => {
            const objL = objP[level];
            const objDS = objL[k];
            const itens = objDS ? objDS : [];
            return html `
                                <li>
                                    <div>
                                        <span class="fatv fa-caret-righttv" @click="${this.openMeList}"></span>
                                        <input type="checkbox" id="l0-${project}-${index}-${index3}" @click="${this.clickSetValueAllChilds}">
                                        <label for="l0-${project}-${index}-${index3}">${k}</label>
                                    </div>
                                    <ul>                        
                                        ${repeat(itens, ((item) => item), ((i, indexI) => {
                return this.renderItem(i, indexP, index, indexI);
            }))}
                                    </ul>
                                </li>
                            `;
        }))}
            </ul>
        </li>
        `;
    }
    renderLevelsDefault(level, project, indexP, index) {
        const objP = this.itens[project];
        const itens = objP[+level];
        return html `
        <li>
            <div>
                <span class="fatv fa-caret-righttv" @click="${this.openMeList}"></span>
                <input type="checkbox" id="l0-${project}-${index}" @click="${this.clickSetValueAllChilds}">
                <label for="l0-${project}-${index}">l${level}</label>
            </div>
            <ul>
                ${repeat(itens, ((item) => item), ((i, indexI) => {
            return this.renderItem(i, indexP, index, indexI);
        }))}
            </ul>
        </li>
        `;
    }
    renderItem(item, indexP, indexL, index) {
        return html `
        <li style="padding-left: 1.1rem;" > 
            <div>
                ${item.disabled || item.onlyFather
            ? html `<input type="checkbox" id="l0-${indexP}-${indexL}-${index}" disabled onlyStatusFather="${item.onlyFather}" @click="${this.clickVerifyStatusFather}" .instance=${item.file}>`
            : html `<input type="checkbox" id="l0-${indexP}-${indexL}-${index}" onlyStatusFather="${item.onlyFather}" @click="${this.clickVerifyStatusFather}" .instance=${item.file}>`}
                
                <label for="l0-${indexP}-${indexL}-${index}">
                
                    ${item.text}
                    ${unsafeHTML(item.span)}
                
                </label>
            </div>
        </li>
        `;
    }
    //-------- IMPLEMENTATION --------
    async init(isSetInfoProject = true) {
        this.showLoader(true);
        this.scenery = 'save';
        if (isSetInfoProject)
            await this.initInfoProject();
        await this.setInfos();
        this.showLoader(false);
    }
    async initInfoProject() {
        const prj = mls.actual[5].project;
        if (!prj)
            return;
        const info = getMyKeysBranch(prj);
        if (!info)
            return;
        this.branch = info.branch;
        this.owner = info.owner;
        this.repo = info.repo;
    }
    showLoader(loader) {
        this.loading = loader;
    }
    async setInfos() {
        try {
            const objProjects = {};
            const filesKeys = Object.keys(mls.stor.files);
            for (const fKey of filesKeys) {
                const file = mls.stor.files[fKey];
                if (
                /*(!file.inLocalStorage && file.status === 'nochange') ||
                file.status === 'nochange' ||*/
                (!file.inLocalStorage && file.status !== 'deleted') ||
                    file.project === 0 ||
                    file.project !== mls.actual[5].project)
                    continue;
                const pj = file.project;
                const level = file.level;
                if (!objProjects[pj])
                    objProjects[pj] = {};
                const obj = objProjects[pj];
                if (!obj[level] && level === 3) {
                    const nNivel = file.folder.split('/');
                    if (nNivel.length >= 2) {
                        obj[level] = { [nNivel[1]]: [await this.configItem(file)] };
                    }
                }
                else if (!obj[level]) {
                    obj[level] = [await this.configItem(file)];
                }
                else if (obj[level] && level === 3) {
                    const nNivel = file.folder.split('/');
                    const obj3 = obj[level];
                    if (nNivel.length >= 2 && obj3[nNivel[1]]) {
                        obj3[nNivel[1]].push(await this.configItem(file));
                    }
                }
                else {
                    obj[level].push(await this.configItem(file));
                }
            }
            if (Object.keys(objProjects).length > 0) {
                this.itens = objProjects;
            }
            else {
                this.itens = undefined;
                this.toogleBadge(false, '_100554_serviceSave');
            }
        }
        catch {
            this.itens = undefined;
            // setar error;
        }
    }
    async configItem(item) {
        let mountText = item.shortName + item.extension;
        let disabled = false;
        let span = `<span style="font-size: 12px; color: #7678a6; margin-left: 5px;" class="fa ${this.oIcon[item.status].icon}" title="${this.oIcon[item.status].title}"></span>`;
        if (item.hasError && item.status !== 'deleted') {
            span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px; height: 16px;" class="fa fa-bug" title="Error"></span>';
            disabled = true;
        }
        if (item.isLocalVersionOutdated) {
            span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px;" class="fa fa-unbalanced" title="Version block"></span>';
            disabled = true;
        }
        if (item.status === 'renamed' && item.getValueInfo) {
            const itemNew = await item.getValueInfo();
            mountText = `${itemNew.originalShortName + item.extension} to ${mountText} `;
        }
        return {
            file: item,
            text: mountText,
            span: span,
            onlyFather: item.level === 3,
            disabled: disabled,
        };
    }
    openMeList(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const li = el.closest('li');
        if (!li)
            return;
        li.classList.toggle('open');
    }
    clickSetValueAllChilds(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.setValueAllChilds(el);
    }
    setValueAllChilds(el) {
        const father = el.closest('li');
        if (!father)
            return;
        const subList = father.querySelector('ul');
        if (!subList)
            return;
        const all = subList.querySelectorAll('input');
        all.forEach((i) => {
            const onlyStatusFather = i.getAttribute('onlyStatusFather') === 'true';
            if (i.disabled && !onlyStatusFather)
                return;
            i.checked = el.checked;
        });
        if (all.length === 1 && all[0].disabled)
            el.checked = false;
    }
    clickVerifyStatusFather(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.verifyStatusFather(el);
    }
    verifyStatusFather(el) {
        const father = el.closest('ul');
        if (!father)
            return;
        const grandfather = father.closest('li');
        if (!grandfather)
            return;
        const inpMain = grandfather.querySelector('input');
        if (!inpMain)
            return;
        if (el.checked) {
            inpMain.checked = true;
            return;
        }
        let needDisable = true;
        const all = father.querySelectorAll('input');
        all.forEach((i) => {
            if (i.checked)
                needDisable = false;
        });
        if (needDisable)
            inpMain.checked = false;
    }
    async updateList() {
        try {
            this.showLoader(true);
            await this.setInfos();
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
            this.showLoader(false);
        }
    }
    /*private async sleep(ms: number) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }*/
    createArrayInfoVersion(array) {
        const ret = [];
        array.forEach((i) => {
            ret.push({
                name: `l${i.level}/${i.folder ? i.folder + '/' : ''}${i.shortName}${i.extension}`,
                version: i.versionRef,
                file: i
            });
        });
        return ret;
    }
    async uppVersionAfterSave(array) {
        const driver = mls.stor.others.getDefaultDriver(mls.actual[5].project);
        const retArray = await driver.loadFilesInfo(mls.actual[5].project);
        const arrayVersion = this.createArrayInfoVersion(array);
        retArray.forEach(async (i) => {
            const file = arrayVersion.filter((f) => f.name === i.ShortPath);
            if (!file || file.length <= 0 || (file && file.length >= 1 && file[0].version === i.versionRef))
                return;
            if (file[0].version !== i.versionRef) {
                //file[0].file.isLocalVersionOutdated = true;
                //file[0].file.newVersionRefIfOutdated = i.versionRef;
                file[0].file.versionRef = i.versionRef;
                file[0].file.isLocalVersionOutdated = false;
                file[0].file.newVersionRefIfOutdated = undefined;
                await mls.stor.localStor.setContent(file[0].file, { contentType: 'string', content: null });
            }
        });
        mls.stor.localDB.savePrjInfo(mls.actual[5].project, retArray); // save cache, dont await
    }
    async verifyVersionBlock(array) {
        try {
            if (array.length <= 0)
                return;
            const ret = await mls.stor.server.loadProjectInfoIfNeeded(mls.actual[5].project, true);
        }
        catch (e) {
            console.info('Error save verifyVersionBlock:' + e.message);
        }
    }
    async createFork(e) {
        try {
            e.stopPropagation();
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            this.showLoader(true);
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            if (!info || !info.login) {
                const user = await driver.getUserInfo();
                info.login = user.login;
                this.setLocalHIstoryCurrentInfoDriver(user.login);
            }
            const ret = await driver.createFork(info.login, info.repo, info.owner, info.login);
            if (!ret)
                throw new Error('Error create fork');
            this.owner = info.login;
            this.repo = info.repo;
            this.branch = 'main';
            this.setLocalHIstoryCurrentInfoDriver();
            this.init(false);
        }
        catch (e) {
            this.error = e.message;
            this.showLoader(false);
            console.info('Error onCreateFork');
        }
    }
    async onSave(e) {
        try {
            e.stopPropagation();
            const el = e.target;
            if (!el)
                return;
            const father = el.closest('sectionsave');
            if (!father)
                return;
            this.showLoader(true);
            const txt = father.querySelector('textarea');
            const array = this.getAllFileToSave(father);
            const msg = txt ? txt.value : '';
            setTimeout(async () => {
                try {
                    this.setLocalHIstoryCurrentInfoDriver();
                    const p = await this.veriFyPermission();
                    if (p.read && !p.write) {
                        this.scenery = 'block';
                        this.showLoader(false);
                        this.requestUpdate();
                        return;
                    }
                    else if (!p.read && !p.write) {
                        this.scenery = 'blockAll';
                        this.showLoader(false);
                        this.requestUpdate();
                        return;
                    }
                    await this.verifyVersionBlock(array);
                    await this.onSavenew(array, msg);
                    await this.setInfos();
                    this.fireEvents();
                    this.showLoader(false);
                }
                catch (e) {
                    this.error = e.message;
                    this.showLoader(false);
                }
            }, 500);
        }
        catch (e) {
            this.error = e.message;
            this.showLoader(false);
            console.info('Error onSave');
        }
    }
    async veriFyPermission() {
        try {
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            if (!info || !info.login) {
                const user = await driver.getUserInfo();
                info.login = user.login;
                this.setLocalHIstoryCurrentInfoDriver(user.login);
            }
            const p = driver.verifyPermission(info.owner, info.repo, info.login);
            return p;
        }
        catch (e) {
            throw new Error(e.message);
        }
    }
    setLocalHIstoryCurrentInfoDriver(user = undefined) {
        const prj = mls.actual[5].project;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        info[prj] = {
            owner: this.owner,
            repo: this.repo,
            branch: this.branch,
            login: user ? user : info.login
        };
        localStorage.setItem('InfoCurrentDriver', JSON.stringify(info));
    }
    getLocalHIstoryCurrentInfoDriver() {
        const prj = mls.actual[5].project;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        if (info[prj])
            return info[prj];
        return {};
    }
    getAllFileToSave(father) {
        const ar = [];
        const els = father.querySelectorAll('input[type="checkbox"][onlyStatusFather]:checked');
        els.forEach((el) => {
            if (el.instance) {
                ar.push(el.instance);
                const info = el.instance;
                if (info.extension === '.ts' && info.status === 'deleted') {
                    const key = mls.stor.getKeyToFiles(info.project, info.level, info.shortName, info.folder, '.html');
                    const fl = mls.stor.files[key];
                    if (!fl || fl.status === 'new')
                        return;
                    fl.status = 'deleted';
                    ar.push(fl);
                }
            }
        });
        return ar;
    }
    async onSavenew(ar, msg) {
        if (ar.length <= 0)
            return;
        try {
            let versionBLock = 0;
            const arrSet = [];
            ar.forEach((i) => {
                if (i.isLocalVersionOutdated && !['new', 'deleted'].includes(i.status)) {
                    versionBLock++;
                    return;
                }
                i.inLocalStorage = false;
                if (!i.onAction)
                    i.onAction = (action) => this.afterUpdate(i);
                arrSet.push(i);
            });
            if (arrSet.length > 0) {
                await mls.stor.setContents(arrSet, msg);
                await this.uppVersionAfterSave(arrSet);
                this.fireEvents(800);
            }
            if (versionBLock > 0) {
                window.collabMessages.add(`File ${versionBLock} was changed in server, file was not save`, 'information');
            }
            return;
        }
        catch (e) {
            this.error = e.message;
        }
    }
    async afterUpdate(storFile) {
        const mmodel = mls.l2.editor.get(storFile);
        if (storFile.status === 'deleted') {
            this.deleteFile(storFile);
            return;
        }
        if (storFile.status === 'renamed' && mmodel) {
            mmodel.originalProject = undefined;
            mmodel.originalShortName = undefined;
            mmodel.originalCRC = mls.common.crc.crc32(mmodel.model.getValue()).toString(16);
        }
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        storFile.status = 'nochange';
    }
    async deleteFile(storFile) {
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        mls.l2.editor.remove(storFile);
        const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
        delete mls.stor.files[keyFiles];
    }
    fireEvents(time = 0) {
        const params = {};
        params.action = 'projectListChanged';
        params.level = 5;
        params.project = mls.actual[5].project;
        params.position = this.position;
        mls.events.fire([5], ['FileAction'], JSON.stringify(params), time);
    }
};
ServiceSave.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceSave.prototype, "itens", void 0);
__decorate([
    property()
], ServiceSave.prototype, "error", void 0);
ServiceSave = __decorate([
    customElement('service-save-100554')
], ServiceSave);
export { ServiceSave };
