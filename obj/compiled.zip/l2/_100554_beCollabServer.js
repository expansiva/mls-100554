/// <mls shortName="beCollabServer" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export class BECollabServer {
    constructor() {
        this.routes = {
            'GET': {},
            'POST': {},
            'PATCH': {},
            'PUT': {},
            'DELETE': {},
        };
    }
    //--------METHODS----------------- 
    on(path, methods, handler) {
        this.routes[methods][path] = handler;
    }
    start(msg) {
        try {
            window.addEventListener("message", (event) => { this.handleRequest(event); });
            return msg || 'Collab server start';
        }
        catch (e) {
            return e.message;
        }
    }
    //--------IMPLEMENTATION----------
    async handleRequest(event) {
        const { id, path, method, body } = event.data;
        const r = this.routes[method];
        if (!r || !r[path]) {
            return event.source.postMessage({ id, error: "Route not found: " + path }, "*");
        }
        try {
            const response = await r[path](body);
            event.source.postMessage({ id, response }, "*");
        }
        catch (error) {
            event.source.postMessage({ id, error: error.message }, "*");
        }
    }
}
