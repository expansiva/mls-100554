/// <mls shortName="beTableBase" project="100554" enhancement="_blank" groupName="other" />
import { getCollabStateInstance } from "./_100554_collabState";
export class TableDriverBase {
    constructor(provider) {
        this.state = getCollabStateInstance();
        this.tableInitialized = false;
        this.onAction = async (key, action) => {
            //const action = this.state.getState(this.actionKey) as TAction & { command: string };
            if ((key !== this.actionKey) ||
                (!action || !action.command)) {
                this.setError(`invalidAction key:${key}, action:${action}`);
                return;
            }
            this.setError("");
            if (!await this.ensureTable())
                return;
            switch (action.command) {
                case "read": return this.onRead(action);
                case "add": return this.onAdd(action);
                case "update": return this.onUpdate(action);
                case "delete": return this.onDelete(action);
                case "undo": return this.onUndo(action);
                case "redo": return this.onRedo(action);
                default: this.setError('invalidAction: "' + action.command + '"');
            }
        };
        this.provider = provider;
    }
    async onRead(action) {
        try {
            const rows = await this.provider.read(action.filter, action.range, action.sort);
            const map = rows.reduce((acc, r) => {
                acc[r.id] = { ...r, _status: "ready", _sync: "synced" };
                return acc;
            }, {});
            const current = this.state.getState(this.dataKey) || {};
            this.state.setState(this.dataKey, { ...current, ...map });
            this.setError("");
            this.setHistory(`read: filter=${JSON.stringify(action.filter)}`);
        }
        catch (e) {
            this.setError(e.message || "read error");
        }
    }
    async onAdd(action) {
        try {
            const newRow = this.state.getState(this.dataKey + ".newRow");
            if (!newRow) {
                this.setError("No data in newRow");
                return;
            }
            const { id, ...itemToAdd } = newRow;
            const added = await this.provider.add(itemToAdd);
            const current = this.state.getState(this.dataKey) || {};
            const newState = { ...added, _status: "ready", _sync: "synced" };
            current[added.id] = newState;
            this.state.setState(this.dataKey, current);
            this.state.setState(this.dataKey + ".newRow", undefined);
            this.setError("");
            this.setHistory(`add: ${JSON.stringify(added)}`);
        }
        catch (e) {
            this.setError(e.message || "add error");
        }
    }
    async onUpdate(action) {
        const item = this.findId(action.id);
        if (!item) {
            this.setError(`error on update ${this.entityKey}: id not found: ${action.id}`);
            return;
        }
        try {
            await this.provider.update(action.id, item);
            item._sync = "synced";
            item._status = "ready";
            this.setError("");
            this.setHistory(`update id ${action.id}, item: ${JSON.stringify(item)}`);
            const current = this.state.getState(this.dataKey) || {};
            current[action.id] = item;
            this.state.setState(this.dataKey, current);
        }
        catch (error) {
            this.setError(`error on update ${this.entityKey}: ` + error.message || "?");
            item._sync = "error";
        }
    }
    async onDelete(action) {
        const item = this.findId(action.id);
        if (!item) {
            this.setError(`error on delete ${this.entityKey}: id not found: ${action.id}`);
            return;
        }
        try {
            await this.provider.delete(action.id);
            const current = this.state.getState(this.dataKey) || {};
            delete current[action.id];
            this.state.setState(this.dataKey, current);
            this.setError("");
            this.setHistory(`delete id ${action.id}`);
        }
        catch (error) {
            this.setError(`error on delete ${this.entityKey}: ` + error.message || "?");
        }
    }
    async onUndo(action) {
        const item = this.findId(action.id);
        if (!item || !item._original) {
            this.setError(`undo failed: original not found for id ${action.id}`);
            return;
        }
        const restored = { ...item, ...item._original, _status: "ready", _sync: "pending" };
        restored._redo = { ...item };
        delete restored._original;
        const current = this.state.getState(this.dataKey) || {};
        current[action.id] = restored;
        this.state.setState(this.dataKey, current);
        this.setError("");
        this.setHistory(`undo id ${action.id}`);
    }
    async onRedo(action) {
        const item = this.findId(action.id);
        if (!item || !item._redo) {
            this.setError(`redo failed: redo not found for id ${action.id}`);
            return;
        }
        const redone = { ...item, ...item._redo, _status: "ready", _sync: "pending" };
        redone._original = { ...item };
        delete redone._redo;
        const current = this.state.getState(this.dataKey) || {};
        current[action.id] = redone;
        this.state.setState(this.dataKey, current);
        this.setError("");
        this.setHistory(`redo id ${action.id}`);
    }
    findId(id) {
        const all = this.state.getState(this.dataKey) || {};
        return all[id];
    }
    setHistory(msg) {
        let his = this.state.getState(this.historyKey);
        if (!his)
            his = [];
        his.push(new Date().toISOString() + " " + msg);
        if (his.length > 10)
            his.splice(0, 2);
        this.state.setState(this.historyKey, his);
    }
    setError(msg) {
        this.state.setState(this.errorKey, msg);
    }
    get historyKey() {
        return `db.${this.entityKey}.history`;
    }
    get errorKey() {
        return `db.${this.entityKey}.error`;
    }
    get actionKey() {
        return `db.${this.entityKey}.action`;
    }
    get dataKey() {
        return `db.${this.entityKey}`;
    }
    async ensureTable() {
        if (this.tableInitialized)
            return true;
        this.tableInitialized = true;
        await this.provider.ensureTable(this.dbName, this.tableName, this.modelPrisma)
            .catch((reason) => {
            this.setError("error on init table: " + reason.message || "?");
            return false;
        });
        return true;
    }
    subscribe() {
        const key = this.dataKey + "._unsubscribe";
        const old = this.state.getState(key);
        if (old && typeof old === "string") {
            this.unsubscribeAll(old);
        }
        this.state.subscribe(this.actionKey, this.onAction);
        this.state.setState(key, this.actionKey);
    }
    unsubscribeAll(actionKey) {
        this.state.unsubscribe(actionKey, "*");
    }
}
