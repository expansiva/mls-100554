/// <mls shortName="ateste2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
const message_pt = {
    hello: 'Hello world!'
};
let SimpleGreeting = class SimpleGreeting extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.name = new Date(Date.now()).toString();
    }
    handleConfirm(e) {
        console.info(e.detail);
    }
    showGreetingAlert() {
        alert(`Hello world Lucas 10`);
    }
    render() {
        return html `<div class="cls1">
            Meu nome é: ${this.name}
        </div>`;
    }
};
__decorate([
    property()
], SimpleGreeting.prototype, "name", void 0);
SimpleGreeting = __decorate([
    customElement('ateste2-100554')
], SimpleGreeting);
export { SimpleGreeting };
