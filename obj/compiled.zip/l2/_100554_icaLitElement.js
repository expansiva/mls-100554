/// <mls shortName="icaLitElement" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { state1 } from './_100554_icaDecorators';
import { CollabLitElement } from './_100554_collabLitElement';
export * from './_100554_icaDecorators';
const isTrace = false;
/**
 * Base class for all components that need to interact with the shared state.
 */
export class IcaLitElement extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.stateKeys = new Set();
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        if (isTrace)
            console.info(`connectedCallback, subscribe fields: ${Array.from(this.stateKeys)}`);
        state1.subscribe(Array.from(this.stateKeys), this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        state1.unsubscribe(Array.from(this.stateKeys), this);
    }
    /**
     * Handle state changes from IcaState.
     * @param key - The state key that changed.
     * @param value - The new value of the state.
     */
    handleIcaStateChange(key, value) {
        function isEqual(newValue, oldValue) {
            return JSON.stringify(newValue) === JSON.stringify(oldValue);
        }
        const ob1 = this;
        Array.from(this.stateKeys).forEach((stateKey) => {
            const [propName, path] = stateKey.split(';');
            if (path !== key || !ob1.hasAttribute(propName))
                return;
            const propValue = ob1[`_${propName}`];
            if (!isEqual(value, propValue)) {
                ob1[`_${propName}`] = value; // Ensure this triggers the setter with potential side effects
                this.requestUpdate();
            }
        });
    }
    loadStyle(css) {
        const tagName = this.tagName.toLowerCase();
        const alreadyAdded = document.body.querySelector(`style#${tagName}`);
        if (alreadyAdded)
            return;
        const style = document.createElement('style');
        style.id = tagName;
        style.textContent = css;
        document.body.appendChild(style);
    }
}
