/// <mls shortName="collabNewProject" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { collab_pull_request, collab_commit, collab_arrows_rotate } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    btnCreateProject: 'Criar projeto',
    btnRefreshOrg: 'Atualizar',
    push: 'Permite que os desenvolvedores façam push diretamente para a branch principal.',
    pullRequest: 'Exige que todas as mudanças sejam feitas através de Pull Requests, permitindo revisões de código e aprovação antes da integração na branch principal.',
    projectNameLabel: 'Nome do projeto',
    errorProjectName: 'Por favor, entre com um nome de projeto valido',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organização',
    visibilityLabel: 'Visibilidade do projeto',
    visibilityPublicOption: 'Público - Qualquer pessoa pode ver este repositório.',
    visibilityPrivateOption: 'Privado - Você escolhe quem pode ver.',
    teamLabel: 'Time',
    loadingAddText1: 'Buscando informações do usuário',
    loadingAddText2: 'Buscando organizações do usuário',
    step1Title: 'Passo 1',
    step2Title: 'Passo 2',
    step3Title: 'Passo 3',
    step1Msg: 'Escolha o driver para carregar suas organizações existentes.',
    step2Msg: 'Agora selecione a organização e o modo de atualização.',
    step3Msg: 'Finalmente, selecione a equipe e a visibilidade do projeto.',
    log_init: "Processando",
    log_error: "Erro",
    log_ok: "Concluido",
    log_0: "Verificando repositório",
    log_1: "Criando repositório",
    log_2: "Criando arquivo de validação",
    log_3: "Criando projeto no collab.codes",
    log_4: "Configurando visibilidade do projeto",
    log_5: "Renomeando projeto",
    log_6: "Criando arquivo de configuração",
    log_7: "Projeto criado com sucesso!",
    log_error_03: "Por favor espere, outro usuário esta utilizando o repositório.",
    log_error_04: "Existe um repositório, mas não foi possível validar o usuário",
};
const message_en = {
    btnCreateProject: 'Create project',
    btnRefreshOrg: 'Refresh',
    push: 'Allows developers to push directly to the main branch.',
    pullRequest: 'Requires all changes to be made through Pull Requests, allowing code reviews and approval before integration into the main branch.',
    projectNameLabel: 'Project name',
    errorProjectName: 'Please, enter with a valid project name',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organization',
    visibilityLabel: 'Project visibility',
    visibilityPublicOption: 'Public - Anyone can see this repository.',
    visibilityPrivateOption: 'Private - You choose who can see.',
    teamLabel: 'Team',
    loadingAddText1: 'Loading user informations',
    loadingAddText2: 'Loading user organizations',
    step1Title: 'Step 1',
    step2Title: 'Step 2',
    step3Title: 'Step 3',
    step1Msg: 'Choose the driver to load your existing organizations.',
    step2Msg: 'Now select the organization and the update mode.',
    step3Msg: 'Finally select the team and the visibility of the project.',
    log_init: "Processing",
    log_error: "Error",
    log_ok: "Completed",
    log_0: "Verify repository",
    log_1: "Creating repository",
    log_2: "Creating validation file",
    log_3: "Creating project on collab.codes",
    log_4: "Setting project visibility",
    log_5: "Renaming project",
    log_6: "Creating configuration file",
    log_7: "Project created successfully!",
    log_error_03: "Please wait, another user is creating; ",
    log_error_04: " There is a repository, but I was unable to validate the user",
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabNewProject = class CollabNewProject extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.NEWREPONAME = 'mls-new';
        this.VALIDADEFILE = 'validate.json';
        this.driverSelected = false;
        this.orgSelected = false;
        this.loadingAdd1Msg = '';
        this.orgsLoaded = false;
        this.actualOrgs = [];
        this.actualTeams = [];
        this.isValidProjectName = true;
        this.errorDriver = '';
        this.logs = [];
        this.newProjectName = '';
        this.newProjectNumber = 0;
        this.newProjectTeam = 'admin';
        this.newProjectVisibility = 'public';
        this.newProjectUpdateMode = 'pullRequest';
        this.driverName = '';
        this.orgName = '';
        this.login = '';
        this.drivers = {
            'github': 'GitHub',
            'gitlab': 'GitLab',
        };
        this.urls = {
            'github': 'https://github.com/',
            'gitlab': 'https://gitlab.com/',
        };
        this.PROJECTFIXED = 100570;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="add-container">
                <form>
                    <div class="step step1">
                        <h5>${this.msg.step1Title}</h5>
                        <small>${this.msg.step1Msg}</small>
                        <hr>
                    </div>
                    <div>
                        <label>${this.msg.projectNameLabel}</label>
                        <input id="input_project_name" type="text" @input=${(e) => { this.newProjectName = e.target.value; }}>
                        ${!this.isValidProjectName ? html `<small class="error"> ${this.msg.errorProjectName}</small>` : ''}
                    </div>

                    <div>
                        <label>${this.msg.driverNameLabel}</label>
                        <select @change=${this.onSelectDriverChange}>
                            <option value=""></option>
                            <option value="github">gitHub</option>
                            <option value="gitlab">gitLab</option>
                        </select>
                        ${!!this.errorDriver ? html `<small class="error"> ${this.errorDriver}</small>` : ''}

                    </div>
                    ${this.driverSelected ? html `

                            ${!this.orgsLoaded ?
            html `<div class="msg-loading">
                                ${this.loadingAdd1Msg}
                                <div>
                                    <span class="dot"></span>
                                    <span class="dot"></span>
                                    <span class="dot"></span>
                                </div>
                            </div>` :
            html `
                                <div class="step step2">
                                        <h5>${this.msg.step2Title}</h5>
                                        <small>${this.msg.step2Msg}</small>
                                    <hr>
                                </div>
                                <div class="cards-update-mode">
                                    <div style="display:none" class="card-update-mode" @click=${(ev) => this.onCardClick('push', ev)}>
                                        <input name="update_mode" type="radio" ></input>
                                        <div>
                                            <div class="card-update-mode-title">
                                                <span>${collab_commit}</span>
                                                <span >Push</span>
                                            </div>
                                            <span>${this.msg.push}</span>
                                        </div>
                                    </div>
                                    <div class="card-update-mode" @click=${(ev) => this.onCardClick('pullRequest', ev)}>
                                        <input name="update_mode" type="radio" checked></input>
                                        <div>
                                            <div class="card-update-mode-title">
                                                <span>${collab_pull_request}</span>
                                                <span>Pull Request</span>
                                            </div>
                                            <span> ${this.msg.pullRequest}</span>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <label>${this.msg.organizationLabel}</label>
                                    <div class="orgs-select">
                                        <select @change=${this.onOrgChanged}>
                                            <option></option>
                                            ${this.actualOrgs.map((org) => html `<option value="${org.id}">${org.name}</option>`)}
                                        </select>
                                        <button @click=${this.onRefreshOrgsClick}>${this.msg.btnRefreshOrg} ${collab_arrows_rotate}</button>
                                    </div>
                                    
                                </div>

                
                                ${this.orgSelected ? html `
                                    <div class="step step3">
                                        <h5>${this.msg.step3Title}</h5>
                                        <small>${this.msg.step3Msg}</small>
                                        <hr>
                                    </div>
                                    <div>
                                        <label>${this.msg.teamLabel}</label>
                                        <select @change=${(e) => { this.newProjectTeam = e.target.value; }}>
                                            ${this.actualTeams.map((team) => html `<option value="${team}">${team}</option>`)}
                                        </select>
                                    </div>
                                    <div>
                                        <label>${this.msg.visibilityLabel}</label>
                                        <select @change=${(e) => { this.newProjectVisibility = e.target.value; }}>
                                            <option value="public">${this.msg.visibilityPublicOption}</option>
                                            <option value="private">${this.msg.visibilityPrivateOption}</option>
                                        </select>
                                    </div>

                                    <div class="actions-btn">
                                        <button @click=${this.onCreateProjectClick}>
                                            ${this.msg.btnCreateProject}
                                        </button>
                                    </div>
                                
                                ` : html ``}
                                
                            `}
                    ` : html ``}
            
                </form>

                ${this.logs.length > 0 ? html `
            
                    <div class="logs-container">
                        <div class="progress">
                            <div class="progress-line"></div>
                        </div>
                        ${this.logs.map((log) => html `<collab-log-line-100554 status=${log.status} text=${log.pre}:${log.log}></collab-log-line-100554>`)}
                    </div>` : ''}
            </div>
        `;
    }
    toogleForm(disabled) {
        if (this.form) {
            this.form.classList.toggle('form-disabled', disabled);
        }
    }
    onSelectDriverChange(e) {
        this.errorDriver = '';
        const value = e.target.value;
        this.driverSelected = !!value;
        this.orgsLoaded = false;
        this.driverName = value;
        if (value) {
            this.loadOrgsByDriver(value);
        }
        else {
            this.orgSelected = false;
        }
    }
    onOrgChanged(e) {
        const value = e.target.value;
        this.orgSelected = !!value;
        this.orgName = value;
        if (value) {
            this.loadTeamByOrg(value);
            setTimeout(() => this.step3?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
        }
    }
    async loadOrgsByDriver(driver) {
        try {
            this.instanceDriver = mls.stor.others.getDriver(100529, driver);
            if (!this.instanceDriver)
                throw new Error('Invalid driver instance');
            this.loadingAdd1Msg = this.msg.loadingAddText1;
            const userInfo = await this.instanceDriver.getUserInfo();
            this.loadingAdd1Msg = this.msg.loadingAddText2;
            if (!userInfo.login)
                throw new Error('Invalid user login');
            this.login = userInfo.login;
            this.actualOrgs = await this.getOrgsByUser(this.login);
            this.orgsLoaded = true;
            setTimeout(() => this.step2?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
        }
        catch (err) {
            this.driverSelected = false;
            this.errorDriver = err.message;
            console.error(err.message);
        }
    }
    async getOrgsByUser(user) {
        if (!this.instanceDriver)
            throw new Error('Invalid driver instance');
        const orgs = await this.instanceDriver.getOrganizations(user);
        orgs.unshift({ id: user, name: user, avatarUrl: '', visibility: 'public' });
        return orgs;
    }
    loadTeamByOrg(org) {
        this.actualTeams = ['admin'];
    }
    async delay(time) {
        await new Promise((resolve) => setTimeout(resolve, time));
    }
    async delay2() {
        return new Promise((resolve, reject) => {
            resolve('free');
        });
    }
    async delayOk() {
        return new Promise((resolve, reject) => {
            resolve('Simulate ok');
        });
    }
    async delayError() {
        return new Promise((resolve, reject) => {
            reject(new Error('Simulate error'));
        });
    }
    addLog(log) {
        this.logs.push(log);
        this.requestUpdate();
    }
    changeStatusLastLog(status, msg) {
        const lastLog = this.logs[this.logs.length - 1];
        if (lastLog) {
            lastLog.status = status;
            lastLog.pre = status === 'finish' ? this.msg.log_ok : this.msg.log_error;
            if (msg)
                lastLog.log = msg;
            this.requestUpdate();
        }
    }
    async tryItem(fc, log) {
        try {
            this.addLog({ pre: this.msg.log_init, log, status: "inprogress" });
            setTimeout(() => this.logsContainer?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
            const rc = await fc();
            this.changeStatusLastLog('finish');
            return rc;
        }
        catch (err) {
            const msg = log + ':' + err.message;
            this.changeStatusLastLog('error', msg);
            this.setProgressError(true);
            throw new Error(err.message);
        }
    }
    setProgress(nr) {
        if (!this.progress)
            return;
        this.progress.style.width = Math.ceil(nr) + '%';
    }
    setProgressError(enabled) {
        if (!this.progress)
            return;
        if (enabled)
            this.progress.classList.add('error');
        else
            this.progress.classList.remove('error');
    }
    setProgressFinished(finished) {
        if (!this.progress)
            return;
        if (finished)
            this.progress.classList.add('finished');
        else
            this.progress.classList.remove('finished');
    }
    checkIsValidProjectName(name) {
        if (!name || name.length <= 3)
            return false;
        const projectNameRegex = /^[a-zA-Z][a-zA-Z0-9_]*$/;
        return projectNameRegex.test(name);
    }
    async onCreateProjectClick(e) {
        e.preventDefault();
        this.logs = [];
        this.toogleForm(true);
        if (!this.checkIsValidProjectName(this.newProjectName)) {
            this.toogleForm(false);
            this.isValidProjectName = false;
            this.inputProjectName?.focus();
            this.inputProjectName?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            return;
        }
        this.isValidProjectName = true;
        const userNameCollab = this.getLoginUser();
        if (!userNameCollab)
            return;
        this.simulate();
        return;
        try {
            let percent = 16.6;
            let newPercent = 0;
            this.setProgressError(false);
            this.setProgressFinished(false);
            this.setProgress(newPercent);
            const rc = await this.tryItem(async () => await this.instanceDriver?.verifyRepositoryNew(this.login, this.NEWREPONAME, userNameCollab), `${this.msg.log_0} ${this.NEWREPONAME}`);
            if (rc === 'reuse')
                percent = 25;
            newPercent += percent;
            this.setProgress(newPercent);
            if (rc === 'error' || rc === 'wait') {
                const obj = {
                    'wait': this.msg.log_error_03,
                    'error': this.msg.log_error_04,
                };
                this.addLog({ pre: this.msg.log_error, log: obj[rc], status: "error" });
                this.toogleForm(false);
                return;
            }
            if (rc === 'free') {
                await this.tryItem(async () => await this.instanceDriver?.createRepository(this.login, this.NEWREPONAME, this.orgName, 'new project in collab.codes', 'PUBLIC'), `${this.msg.log_1} ${this.NEWREPONAME} `);
                newPercent += percent;
                this.setProgress(newPercent);
                await this.tryItem(async () => await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, this.VALIDADEFILE, `{ "users": [ "${userNameCollab}" ] }`), `${this.msg.log_2} ${this.VALIDADEFILE} `);
                newPercent += percent;
                this.setProgress(newPercent);
            }
            const newProjectId = await this.tryItem(async () => await mls.api.cbeSaveNewPrj({
                orgName: this.orgName,
                info: {
                    project: this.newProjectNumber,
                    projectDriver: this.drivers[this.driverName],
                    projectURL: `${this.urls[this.driverName]}main/${this.orgName}/mls-new/`,
                    projectDependencies: []
                },
                settings: {
                    id: 0,
                    name: this.newProjectName,
                    owner: userNameCollab,
                    userAuth: this.newProjectVisibility,
                    archived_at: '',
                    created_at: '',
                    prj_dependencies: [],
                    value: ''
                }
            }), `${this.msg.log_3}`);
            newPercent += percent;
            this.setProgress(newPercent);
            if (this.newProjectVisibility === 'private')
                await this.tryItem(async () => await this.instanceDriver?.changeVisibility(this.orgName, this.NEWREPONAME, 'PRIVATE'), `${this.msg.log_4}`);
            newPercent += percent;
            this.setProgress(newPercent);
            const newProjectName = `mls-${newProjectId}`;
            await this.tryItem(async () => await this.instanceDriver?.renameRepository(this.orgName, this.NEWREPONAME, newProjectName), `${this.msg.log_5}`);
            newPercent += percent;
            this.setProgress(newPercent);
            const newUrlProject = `${this.urls[this.driverName]}main/${this.orgName}/${newProjectName}/`;
            await this.tryItem(async () => { await this.createConfigFile(newProjectId); }, `${this.msg.log_6}`);
            newPercent += percent;
            this.setProgress(newPercent);
        }
        catch (err) {
            this.toogleForm(false);
        }
        this.addLog({ pre: this.msg.log_ok, log: this.msg.log_7, status: "finish" });
        this.setProgressFinished(true);
        this.dispatchEvent(new CustomEvent('collab-new-project', {
            detail: this.newProjectNumber, bubbles: true, composed: true
        }));
    }
    async simulate() {
        try {
            let percent = 16.6;
            let newPercent = 0;
            this.setProgressError(false);
            this.setProgressFinished(false);
            this.setProgress(newPercent);
            const rc = await this.tryItem(async () => await this.delay2(), this.msg.log_0);
            if (rc === 'reuse')
                percent = 25;
            newPercent += percent;
            this.setProgress(newPercent);
            if (rc === 'error' || rc === 'wait') {
                const obj = {
                    'wait': this.msg.log_error_03,
                    'error': this.msg.log_error_04,
                };
                this.addLog({ pre: this.msg.log_error, log: obj[rc], status: "error" });
                this.setProgressError(true);
                this.toogleForm(false);
                return;
            }
            if (rc === 'free') {
                await this.tryItem(async () => await this.delay(2000), `${this.msg.log_1} ${this.NEWREPONAME} `);
                newPercent += percent;
                this.setProgress(newPercent);
                await this.tryItem(async () => await this.delay(2000), `${this.msg.log_2} ${this.VALIDADEFILE} `);
                newPercent += percent;
                this.setProgress(newPercent);
            }
            await this.tryItem(async () => await this.delay(2000), `${this.msg.log_4}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.tryItem(async () => await this.delay(200), `${this.msg.log_5}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.tryItem(async () => await this.delay(2000), `${this.msg.log_6}`);
            newPercent += percent;
            this.setProgress(newPercent);
        }
        catch (err) {
            this.toogleForm(false);
            return;
        }
        this.addLog({ pre: this.msg.log_ok, log: this.msg.log_7, status: "finish" });
        this.setProgressFinished(true);
        this.dispatchEvent(new CustomEvent('collab-new-project', {
            detail: this.PROJECTFIXED, bubbles: true, composed: true
        }));
    }
    async createConfigFile(project) {
        const newConfig = {
            designSystems: [],
            languages: []
        };
        const content = JSON.stringify(newConfig);
        const params = {
            project,
            level: 5,
            shortName: 'project',
            extension: '.json',
            versionRef: '0',
            folder: ''
        };
        const file = await mls.stor.addOrUpdateFile(params);
        if (!file)
            return;
        file.status = 'new';
        const fileInfo = {
            content,
            contentType: 'string',
        };
        await mls.stor.localStor.setContent(file, fileInfo);
    }
    onCardClick(opt, ev) {
        const target = ev.target;
        const input = target.closest('.card-update-mode')?.querySelector('input');
        if (input)
            input.checked = true;
        this.newProjectUpdateMode = opt;
    }
    async onRefreshOrgsClick(ev) {
        ev.preventDefault();
        this.actualOrgs = await this.getOrgsByUser(this.login);
        this.requestUpdate();
    }
    getLoginUser() {
        const userNameCollab = localStorage.getItem('loginUser');
        return userNameCollab;
    }
};
CollabNewProject.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], CollabNewProject.prototype, "driverSelected", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "orgSelected", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "loadingAdd1Msg", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "orgsLoaded", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "actualOrgs", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "actualTeams", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "isValidProjectName", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "errorDriver", void 0);
__decorate([
    property()
], CollabNewProject.prototype, "logs", void 0);
__decorate([
    query('#input_project_name')
], CollabNewProject.prototype, "inputProjectName", void 0);
__decorate([
    query('form')
], CollabNewProject.prototype, "form", void 0);
__decorate([
    query('.logs-container')
], CollabNewProject.prototype, "logsContainer", void 0);
__decorate([
    query('.step1')
], CollabNewProject.prototype, "step1", void 0);
__decorate([
    query('.step2')
], CollabNewProject.prototype, "step2", void 0);
__decorate([
    query('.step3')
], CollabNewProject.prototype, "step3", void 0);
__decorate([
    query('.progress-line')
], CollabNewProject.prototype, "progress", void 0);
CollabNewProject = __decorate([
    customElement('collab-new-project-100554')
], CollabNewProject);
export { CollabNewProject };
