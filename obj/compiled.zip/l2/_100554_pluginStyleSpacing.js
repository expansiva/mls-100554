/// <mls shortName="pluginStyleSpacing" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, query, queryAll } from 'lit/decorators.js';
import { CollabLitElement, getMessageKey } from './_100554_collabLitElement';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
import { collab_lock, collab_lock_open, collab_margin_bottom, collab_margin_top, collab_margin_left, collab_margin_right, collab_padding_bottom, collab_padding_top, collab_padding_left, collab_padding_right, } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    all: 'Group',
    margin: 'Margin',
    padding: 'Padding',
    top: 'Superior',
    left: 'Esquerda',
    bottom: 'Inferior',
    right: 'Direita',
    description: 'Este plugin permite ajustar margens e preenchimentos (margin e padding) de maneira simples e intuitiva. Ideal para desenvolvedores que buscam precisão no espaçamento dos elementos, ele facilita a definição de distâncias internas e externas para garantir um layout consistente e bem estruturado.'
};
const message_en = {
    all: 'Group',
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
    description: 'This plugin enables easy and intuitive adjustments of margins and paddings. Ideal for developers seeking precise element spacing, it streamlines the setup of inner and outer distances to ensure a consistent and well-structured layout.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['margin*', 'padding*'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleSpacing = class PluginStyleSpacing extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-spacing-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-spacing-100554 .helper-group-title{margin:0;margin-top:var(--space-16);margin-bottom:var(--space-8);display:flex;gap:1.5rem}plugin-style-spacing-100554 .helper-group-lock{display:flex;justify-content:start;align-items:center}plugin-style-spacing-100554 .helper-group-lock label{cursor:pointer}plugin-style-spacing-100554 .helper-group-lock i{margin-left:var(--space-8)}plugin-style-spacing-100554 .group{margin-left:var(--space-16);margin-top:var(--space-8);font-size:var(--font-size-12);display:flex;flex-direction:column;gap:.7rem}plugin-style-spacing-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-spacing-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-spacing-100554 .gallery{display:flex;justify-content:start;align-items:center;gap:1rem;padding:1rem;flex-wrap:wrap;cursor:pointer}plugin-style-spacing-100554 .gallery .box{background-color:var(--bg-primary-color);border:1px solid var(--text-primary-color)}plugin-style-spacing-100554 .gallery .box>div{background-color:var(--text-primary-color);width:40px;height:40px}`);
        this.msg = messages['en'];
        this.showFull = 'true';
        this.marginLocked = false;
        this.paddingLocked = false;
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.timeonChangeMargin = -1;
        this.timeonChangePadding = -1;
        this.gallery = [
            'margin: 10px',
            'margin: 10px 0',
            'margin: 0 10px',
            'margin-left:10px',
            'margin-right:10px',
            'margin-top:10px',
            'margin-bottom:10px',
        ];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `

        ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderMargin()}
                ${this.renderPadding()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderMargin() {
        return html `
            <h5 class="helper-group-title" >${this.msg.margin}</h5>
            <div class="helper-group-lock">
                <input id="helper-border-lock" type="checkbox" @change=${this.handleChangeLockMargin}>
                <label for="helper-border-lock"> ${this.msg.all}</label>
                <i>${this.marginLocked ? collab_lock : collab_lock_open}</i>
            </div>

            <div class="group">

                <div class="group-edit">
                    <i data-tooltip="${this.msg.top}">${collab_margin_top}</i>
                    <collab-ds-input-range-100554
                        prop="margin-top"
                        value="0px"
                        .arraySelect=${this.tpMeasures} 
                        group="margin"
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.left}" >${collab_margin_left}</i>
                    <collab-ds-input-range-100554
                        prop="margin-left"
                        value="0px"
                        .arraySelect=${this.tpMeasures} 
                        group="margin" 
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>   
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.bottom}">${collab_margin_bottom}</i>
                    <collab-ds-input-range-100554
                        prop="margin-bottom"
                        value="0px"
                        .arraySelect=${this.tpMeasures} 
                        group="margin" 
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.right}">${collab_margin_right}</i>
                    <collab-ds-input-range-100554
                        prop="margin-right"
                        value="0px"
                        .arraySelect=${this.tpMeasures} 
                        group="margin" 
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>

                </div>
            </div>

        `;
    }
    renderPadding() {
        return html `
            <h5 class="helper-group-title" >${this.msg.padding}</h5>
                <div class="helper-group-lock">
                <input id="helper-border-radius-lock" type="checkbox" @change=${this.handleChangeLockPadding}>
                <label for="helper-border-radius-lock"> ${this.msg.all}</label>
                <i>${this.paddingLocked ? collab_lock : collab_lock_open}</i>
            </div>

            <div class="group">

                <div class="group-edit">
                    <i data-tooltip="${this.msg.top}">${collab_padding_top}</i>
                    <collab-ds-input-range-100554
                        prop="padding-top"
                        value="0px"
                        .arraySelect=${this.tpMeasures}  
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.left}">${collab_padding_left}</i>
                    <collab-ds-input-range-100554
                        prop="padding-left"
                        value="0px"
                        .arraySelect=${this.tpMeasures} 
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554>    

                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.bottom}">${collab_padding_bottom}</i>
                    <collab-ds-input-range-100554
                        prop="padding-bottom"
                        value="0px"
                        .arraySelect=${this.tpMeasures} 
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554> 

                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.right}">${collab_padding_right}</i>
                    <collab-ds-input-range-100554
                        prop="padding-right"
                        value="0px"
                        .arraySelect=${this.tpMeasures} 
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554> 
                </div>
            </div>

        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((css, index) => {
            return html `
                <div class="box">
                    <div style="${css}" .gallery=${css}></div>
                </div>`;
        }))}
            </div>
        
        `;
    }
    handleChangeMargin(e) {
        clearTimeout(this.timeonChangeMargin);
        this.timeonChangeMargin = setTimeout(() => {
            const el = e.detail.target;
            if (!this.marginLocked)
                return;
            this.marginInputs?.forEach((inp) => {
                if (inp === el)
                    return;
                inp.value = el.value;
            });
        }, 100);
    }
    handleChangePadding(e) {
        clearTimeout(this.timeonChangePadding);
        this.timeonChangePadding = setTimeout(() => {
            const el = e.detail.target;
            if (!this.paddingInputs)
                return;
            this.paddingInputs?.forEach((inp) => {
                if (inp === el)
                    return;
                inp.value = el.value;
            });
        }, 100);
    }
    handleChangeLockPadding() {
        if (!this.inputLockP)
            return;
        console.info(this.inputLockP.checked);
        this.paddingLocked = this.inputLockP.checked;
    }
    handleChangeLockMargin() {
        if (!this.inputLockM)
            return;
        this.marginLocked = this.inputLockM.checked;
    }
};
__decorate([
    property()
], PluginStyleSpacing.prototype, "showFull", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "marginLocked", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "paddingLocked", void 0);
__decorate([
    query('#helper-border-radius-lock')
], PluginStyleSpacing.prototype, "inputLockP", void 0);
__decorate([
    query('#helper-border-lock')
], PluginStyleSpacing.prototype, "inputLockM", void 0);
__decorate([
    queryAll('collab-ds-input-range-100554[group="margin"]')
], PluginStyleSpacing.prototype, "marginInputs", void 0);
__decorate([
    queryAll('collab-ds-input-range-100554[group="padding"]')
], PluginStyleSpacing.prototype, "paddingInputs", void 0);
PluginStyleSpacing = __decorate([
    customElement('plugin-style-spacing-100554')
], PluginStyleSpacing);
export { PluginStyleSpacing };
