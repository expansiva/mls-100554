/// <mls shortName="wcColumn" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
let WcColumn = class WcColumn extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`wc-column-100554{display:block;width:100%;flex:1}`);
    }
    createRenderRoot() {
        return this;
    }
    render() {
        return html `<slot></slot>`;
    }
};
WcColumn = __decorate([
    customElement('wc-column-100554')
], WcColumn);
export { WcColumn };
