/// <mls shortName="wcColumn" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaLayoutFlowColumnBase } from './_100554_icaLayoutFlowColumnBase';
let WcColumn = class WcColumn extends IcaLayoutFlowColumnBase {
    render() {
        return html `
        <slot></slot>
        `;
    }
};
WcColumn.styles = css `
    :host {
        display: block;
        width:100%;
        flex: 1;
    }`;
WcColumn = __decorate([
    customElement('wc-column-100554')
], WcColumn);
export { WcColumn };
