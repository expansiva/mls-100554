/// <mls shortName="collabConsole" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
let CollabConsole100554 = class CollabConsole100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-console-100554{font-family:monospace;background:var(--bg-primary-color-lighter-focus);color:var(--text-primary-color);padding:10px;max-height:300px;overflow-y:auto;display:flex;flex-direction:column;gap:1rem;font-size:var(--font-size-12);box-shadow:0 -1px 10px -4px}collab-console-100554 .log{margin:0;padding:5px 0}collab-console-100554 .warn{color:var(--warning-color-focus)}collab-console-100554 .error{color:var(--error-color)}collab-console-100554 .info{color:var(--info-color-hover)}`);
        this.logs = [];
        this.height = '200px';
        this.scope = window;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('logs')) {
            this.scrollTop = this.scrollHeight;
        }
        if (changedProperties.has('scope')) {
            this.logs = [];
            this.interceptConsole();
        }
    }
    interceptConsole() {
        if (!this.scope)
            return;
        const originalLog = this.scope.console.log;
        const originalWarn = this.scope.console.warn;
        const originalError = this.scope.console.error;
        const originalInfo = this.scope.console.info;
        this.scope.console.log = (...args) => {
            this.addLog('log', args);
            originalLog.apply(this.scope.console, args);
        };
        this.scope.console.warn = (...args) => {
            this.addLog('warn', args);
            originalWarn.apply(this.scope.console, args);
        };
        this.scope.console.error = (...args) => {
            this.addLog('error', args);
            originalError.apply(this.scope.console, args);
        };
        this.scope.console.info = (...args) => {
            this.addLog('info', args);
            originalInfo.apply(this.scope.console, args);
        };
    }
    addLog(type, args) {
        const message = args.map(arg => (typeof arg === 'object' ? JSON.stringify(arg) : String(arg))).join(' ');
        this.logs = [...this.logs, { type, message }];
    }
    render() {
        this.style.height = this.height;
        return html `
      <div class="log-container">
        ${this.logs.map(log => html `
            <div class="log ${log.type}">
              [${log.type.toUpperCase()}] ${log.message}
            </div>
          `)}
      </div>
    `;
    }
};
__decorate([
    state()
], CollabConsole100554.prototype, "logs", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "height", void 0);
__decorate([
    property()
], CollabConsole100554.prototype, "scope", void 0);
CollabConsole100554 = __decorate([
    customElement('collab-console-100554')
], CollabConsole100554);
export { CollabConsole100554 };
