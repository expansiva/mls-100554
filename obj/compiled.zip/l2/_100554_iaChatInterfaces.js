/// <mls shortName="iaChatInterfaces" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export const StatusCodeOk = 200;
export const StatusCodeNotModified = 304;
export const StatusCodeNotAuthenticated = 401;
export const StatusCodeBadRequest = 400;
export const StatusCodeUnauthorized = 401;
export const StatusCodeNotFound = 404;
export const StatusCodeForbidden = 403;
export const StatusCodeConflict = 409;
export const StatusCodeServerError = 500;
export const StatusCodeNotImplemented = 501;
