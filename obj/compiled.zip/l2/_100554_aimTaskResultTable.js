/// <mls shortName="aimTaskResultTable" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
let AimTaskResultTable = class AimTaskResultTable extends AimTaskBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    onInitializing() {
        this.notifyCompleteByStatus('ok', '');
    }
    renderBody(taskRoot, child) {
        const title = child.title;
        const body = child._tempResult || '';
        return html `
        <details open>
            <summary>${title}</summary>
            <div style='margin: 10px'>${this.renderTable2(this.parseTable2(body))}</div> 
        </details>
        `;
    }
    parseTable(body) {
        const i1 = body.indexOf('|');
        if (i1 < 0)
            return [];
        let lines = body.substring(i1).split('\n');
        let tab1 = [];
        for (const line of lines) {
            if (!line.startsWith('|'))
                continue;
            const cols = line.trim().split('|');
            tab1.push(cols);
        }
        return tab1;
    }
    parseTable2(body) {
        const regex = /\|/g;
        const lines = body.split('\n');
        const linesWithValues = lines.filter(line => line.trim() !== '');
        const table = linesWithValues.map(line => line.split(regex));
        const tableWithNoEspaces = table.map(line => line.map(cel => cel.trim()));
        return tableWithNoEspaces;
    }
    renderTable2(tab1) {
        if (tab1.length < 2)
            return html `invalid table`;
        return html `
        <table class="tb">
            <thead>
            <tr>${tab1[0].map(header => html `<th class="th">${header}</th>`)}</tr>
            </thead>
            <tbody>
            ${tab1.slice(1).map(row => html `
                <tr>${row.map(cell => html `<td class="td">${cell}</td>`)}</tr>
            `)}
            </tbody>
        </table>
        `;
    }
};
AimTaskResultTable = __decorate([
    customElement('aim-task-result-table-100554')
], AimTaskResultTable);
export { AimTaskResultTable };
