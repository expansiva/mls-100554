/// <mls shortName="icaLoadPage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { convertFileNameToTag } from './_100554_utilsLit';
import { getDependenciesByHtml } from './_100554_libCompile';
let IcaLoadPage100554 = class IcaLoadPage100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.src = '';
    }
    async loadPage() {
        if (!this.src)
            return;
        await import(`./${this.src}`);
        const html = await this.getHTML();
        const deps = await this.getDeps(html);
        for await (let importJs of deps.importsJs) {
            await import(`.${importJs}`);
        }
        const tag = convertFileNameToTag(this.src);
        if (!tag)
            return;
        this.innerHTML = html;
    }
    async getHTML() {
        const { project, shortName } = mls.l2.getPath(this.src);
        if (!project || !shortName)
            return '';
        const keyToFile = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
        const file = mls.stor.files[keyToFile];
        if (!file)
            return '';
        const content = await file.getContent();
        return content;
    }
    async getDeps(html) {
        const models = mls.editor.models[this.src];
        const deps = await getDependenciesByHtml(models, html, 'Default');
        return deps;
    }
    firstUpdated() {
        this.loadPage();
    }
    createRenderRoot() {
        return this; // dont use shadow root
    }
    render() {
        return html ``;
    }
};
__decorate([
    property({ type: String })
], IcaLoadPage100554.prototype, "src", void 0);
IcaLoadPage100554 = __decorate([
    customElement('ica-load-page-100554')
], IcaLoadPage100554);
export { IcaLoadPage100554 };
