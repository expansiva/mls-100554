/// <mls shortName="agentNewWidget" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { svg_agent } from './_100554_aiAgentBase';
import { getTokens } from './_100554_libCompile';
import { createNewFile } from "./_100554_pluginNewFileBase";
import { preferModelType } from './_100554_aiPrompts';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, updateStepStatus, getNextPendentStep, updateTaskTitle } from "./_100554_aiAgentHelper";
import { executeNextStep, startNewInteractionInAiTask } from "./_100554_aiAgentOrchestration";
const agentName = "agentNewWidget";
const actualtheme = "Default";
const project = 100554;
const enhancement = '_100554_enhancementLit';
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Responsável pela criação de um novo web componente (widget) para o sistema Collab Codes.",
        visibility: "private",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Creating.";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        throw new Error('[_beforePrompt]This agent cannot be started first: agentNewWidget');
    }
    else {
        const step = getNextPendingStepByAgentName(context.task, agentName);
        if (!step) {
            throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
        }
        context.task = await updateStepStatus(context.task, step.stepId, "in_progress");
        if (!step.prompt)
            throw new Error(`[${agentName}] beforePrompt: No prompt found in step for this agent.`);
        const data = JSON.parse(step.prompt);
        if (!('json' in data) || !('prompt' in data))
            throw new Error(`[${agentName}] beforePrompt: Invalid prompt structure missing json and prompt`);
        const inputs = await getPrompts(data.json, data.prompt, step.rags);
        await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
    await addFile(context);
    context.task = await updateStepStatus(context.task, step.stepId, "completed");
    await executeNextStep(context);
};
async function addFile(context) {
    if (!context || !context.task)
        throw new Error('Not found context to create files');
    const step = getNextPendentStep(context.task);
    if (!step || step.type !== 'flexible')
        throw new Error('Invalid step in create files');
    if (!step.content || !step.content.html || !step.content.ts || !step.content.less)
        throw new Error('Not found "html" or "ts" or "less" in addFile files');
    const pageName = step.content.shortName;
    const fileHTML = step.content.html;
    const fileTS = step.content.ts;
    const fileLess = step.content.less;
    await createNewFile({ project, position: 'right', shortName: pageName, enhancement, sourceTS: fileTS, sourceHTML: fileHTML, sourceLess: fileLess, openPreview: false });
    let aux = '';
    const m = mls.editor.getModels(project, pageName);
    if (m && m.ts && m.ts.compilerResults && m.ts.compilerResults.errors.length > 0) {
        aux = ', com ' + m.ts.compilerResults.errors.length + ' erros, favor verificar';
    }
    context.task = await updateTaskTitle(context.task, "Widget created" + aux);
}
export async function getPrompts(json, prompt, rags) {
    if (!prompt || prompt.length < 3)
        throw new Error("Invalid Prompt");
    const prompts = [];
    prompts.push(systemMainInstruction());
    prompts.push(systemRulesInstruction());
    prompts.push(systemDefinitionsInstruction());
    prompts.push(systemProcessInstruction());
    prompts.push(systemOutInstruction());
    prompts.push(systemModelInstruction());
    prompts.push(systemRequirementsUserInstruction(json));
    prompts.push(await systemDefinitionsBaseInstruction(json));
    prompts.push(await systemTokensLessInstruction());
    prompts.push({
        type: 'human',
        content: prompt
    });
    return prompts;
}
function systemMainInstruction() {
    //executor or translate
    return {
        type: 'system',
        content: `${preferModelType("executor")}
Você é um programador responsável pela criação de um novo web componente (widget) para o sistema Collab Codes.

Se não for possível cumprir esta tarefa (por falta de dados ou conflito de requisitos), **retorne um objeto JSON** do tipo "result", com uma descrição do problema.

Se for possível cumprir esta tarefa, **retorne um objeto JSON** do tipo "flexible", contendo o typescript gerado, o html gerado e o less gerado.
`
    };
}
function systemRulesInstruction() {
    return {
        type: 'system',
        content: `## Requirements do Collab Codes:
1. Para o retorno do .ts 
  1.1. Utilize **TypeScript fortemente tipado**.
  1.2 Não use comentários dentro do render, isto dá problemas de compilação.
  1.3. Utilize **Lit 3**, siga o modelo para análise dos imports.
  1.4. **Não estenda diretamente** "LitElement"; existem classes especializadas já definidas para cada tipo de widget.
  1.5. **Padrões de nomeação**:
   - "camelCase" para propriedades.
   - "PascalCase" para nomes de componentes/classes.
  1.6. Use os atributos padrões da classe base.
  1.7. Deixe a linha 1 , tripleSlash, igual no modelo, isto irá ser importante para saber o nome do arquivo e outros detalhes.

2. Para o retorno do .less
  2.1 Inclua o código LESS, onde o primeiro nível é a tag HTML do componente.

3. Para o retorno do .html
  3.1 use o html para demonstrar o componente criado, procure demonstrar pontos fortes e restrições, inicie o html com a tag div, não inclua javascript, inclua estilos para uma apresentação melhor.

4. Para todos os retornos(.ts, .less e .html)
  4.1 Retorne os conteúdos sem qualquer indentação (sem espaços ou tabulações no início das linhas), mantendo apenas as quebras de linha.

5. Analise cuidadosamente as seções fornecidas abaixo:
   - "Modelo Widget"
   - "Requirements editáveis pelo usuário"
   - "Definições dos Atributos"
   - "Definições da Classe Base"
   - "Formato de saida"
   - "LESS TOKENS - DESIGN SYSTEM"
`
    };
}
function systemDefinitionsInstruction() {
    return {
        type: 'system',
        content: `## Definições de Propriedades (Collab Codes):
A classe base utilizada no sistema Collab Codes define três tipos principais de propriedades:

- @property: Padrão do Lit para propriedades estáticas.
- @propertyDataSource: Propriedade ligada a um único state dinâmico. Exemplo de binding: "{{page1.name}}".
- @propertyCompositeDataSource: Propriedade composta por múltiplos states dinâmicos. Exemplo: "Olá {{page1.userId}} - {{page1.userName}}".

- a propriedade autofocus deve ser definida conforme lit "@property({{ type: Boolean }}) autofocus: boolean = false;"
- a propriedade name deve ser definida conforme lit "@property({{ type: String }}) name: string | undefined;"

**Importante**: Use corretamente a anotação conforme o tipo da propriedade analisada.
Para cada propriedade criada, use um JSDoc com exemplo.
Para a classe , use um JSDoc incluindo também o esqueleto gerado no render, que será utilizado para fazer o css/less futuramente.

**Sobre o gerenciamento de propriedades e states no Collab Codes:**

- Quando uma propriedade é decorada com @propertyDataSource ou @propertyCompositeDataSource, ela é automaticamente associada a um ou mais states dinâmicos do sistema, como por exemplo: "{{page1.dataRange}}".
- O gerenciador de states do Collab Codes é responsável por:
  - Registrar automaticamente a dependência entre a propriedade e o(s) state(s) referenciado(s).
  - Detectar alterações no(s) state(s) de forma automática e eficiente.
  - Atualizar o valor da propriedade no componente sem necessidade de eventos manuais (dispatchEvent, CustomEvent, etc.).
- **Importante:**
  Não é necessário implementar listeners, eventos personalizados, nem funções de observação manual para essas propriedades.
  **Toda a comunicação e atualização é gerenciada automaticamente pelo sistema de states.**
`
    };
}
function systemProcessInstruction() {
    return {
        type: 'system',
        content: `## Processo de Execução (Modelo Agentic)

Você opera em um ciclo de agente iterativo (agent loop) focado na conclusão da tarefa:

1. **Analisar o Contexto:** Revise todas as informações fornecidas, principalmente o "Modelo Widget", os "Requirements editáveis pelo usuário" e as "Definições da Classe Base".
2. **Planejar a Geração:** Decida a estrutura geral do widget com base no contexto atual, incluindo ".ts", ".html" e ".less".
3. **Gerar o Código:** Produza o código:
   - ".ts": conforme todos os requisitos TypeScript e padrões do Collab Codes.
   - ".html": representando visualmente o widget de forma clara, usando apenas marcação e estilo.
   - ".less": usando a tag do componente como seletor de nível superior e tokens do design system.
4. **Validar o Código:** Verifique se:
   - Todos os requisitos foram seguidos.
   - A tipagem está correta.
   - A estrutura está coerente com o sistema Collab Codes.
   - A saída está no formato esperado com os três arquivos gerados.
5. **Finalizar a Tarefa:** Retorne um objeto JSON do tipo:
   - "flexible" com os três campos: "ts", "html", "less", se tudo estiver correto.
   - "result" com descrição do erro, caso algo esteja inválido ou impossível de gerar.

**Importante:**
- Execute **apenas uma etapa por vez** com atenção.
- **Valide completamente** antes de retornar a saída.
- Seja **preciso, padronizado e consistente**, 
Só finalize a tarefa quando estiver completamente de acordo com os requisitos.`
    };
}
function systemOutInstruction() {
    return {
        type: 'system',
        content: `## Formato de saida
Você deve retornar um array de objetos no formato JSON. Cada objeto representa uma subtarefa, com **apenas um dos seguintes formatos**:
\`\`\` json
[{{
    "type": "flexible",
    "content": { html: string, ts: string, less: string, shortName:string }
  },
  {
    "type": "result",
    "result": string
  }}]
\`\`\`
`
    };
}
function systemModelInstruction() {
    return {
        type: 'system',
        content: `## Modelo Widget

/// <mls shortName="widgetInputNumber" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, LitElement, ifDefined, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaFormsInputNumberBase } from './_100554_icaFormsInputNumberBase';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_collabDecorators';

@customElement('widget-input-number-100554')
export class WidgetInputNumber extends IcaFormsInputNumberBase {

    @propertyDataSource({ type: String }) value: number | undefined;

    @propertyCompositeDataSource({ type: String }) hint: string = '';

    error: string = '';

    render() {
        return html\`
        <label class="form-control-label" for="input">
          \${this.label}
        </label>

        <input
            id="input"
            class="input_control"
            type="number"
            name=\${ifDefined(this.name)}
            ?disabled=\${this.disabled}
            ?readonly=\${this.readonly}
            ?required=\${this.required}
            min=\${ifDefined(this.minvalue)}
            max=\${ifDefined(this.maxvalue)}
            step=\${ifDefined(this.step as number)}
            .value=\${this.value}
            ?autofocus=\${this.autofocus}
            pattern=\${ifDefined(this.pattern)}
            inputmode=\${ifDefined(this.inputmode)}
            @input=\${this.handleChange}
        />

        <div class="form_error_message">\${this.error}</div>
        \`;
    }

    private handleChange() {
        if (!this.input) return;
        let newval = +this.input.value;
        if (!isNaN(newval)
            && (this.minvalue === undefined || (newval >= this.minvalue))
            && (this.maxvalue === undefined || (newval <= this.maxvalue))
        ) {
            this.value = newval;
            this.error = '';
            this.requestUpdate();
        } else {
            this.error = this.errormessage || '';
            this.requestUpdate();
        }
    }
}
`
    };
}
function systemRequirementsUserInstruction(req) {
    return {
        type: 'system',
        content: `## Requirements editável pelo usuário
\`\`\`json
${JSON.stringify(req, null, 2)}
\`\`\`
`
    };
}
//Tem q ser dinamico
async function systemDefinitionsBaseInstruction(json) {
    const step = json.find((i) => i.sectionName === 'parentClass');
    if (!step)
        throw new Error("[systemDefinitionsBaseInstruction]Not found section : parentClass");
    if (!step.widgetName)
        throw new Error("[systemDefinitionsBaseInstruction]Not found widgetName in parentClass");
    const shortName = step.widgetName;
    const key = mls.stor.getKeyToFiles(project, 2, shortName, "", ".ts");
    if (!mls.stor.files[key])
        throw new Error("[systemDefinitionsBaseInstruction]Not found class base:" + project + "_" + shortName);
    let contet = await mls.stor.files[key].getContent();
    if (!contet)
        throw new Error("[systemDefinitionsBaseInstruction]Not found content:" + project + "_" + shortName);
    return {
        type: 'system',
        content: `## Definições da Classe Base \n\n ${contet}`
    };
}
//Tem q ser dinamico
async function systemTokensLessInstruction() {
    return {
        type: 'system',
        content: '## LESS TOKENS - DESIGN SYSTEM \n\n' + (await getTokens({ project, shortName: '' }, actualtheme)) || ""
    };
}
