/// <mls shortName="aimChatMessage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import * as chatHelper from './_100554_aimChatHelper';
let AimChatMessage100554 = class AimChatMessage100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aim-chat-message-100554{display:flex;flex-direction:column;align-items:flex-start;width:100%;margin-bottom:10px}aim-chat-message-100554.user{align-items:flex-end}aim-chat-message-100554 .message-row{max-width:80%;margin-bottom:3px;margin-right:50px;margin-left:50px}aim-chat-message-100554 .message-card{display:flex;flex-direction:column;background-color:#f9f9f9;border:1px solid #ddd;border-radius:8px;padding:6px;position:relative}aim-chat-message-100554 .message-card.user{background-color:#daf8cb;align-self:flex-end}aim-chat-message-100554 .message-card.other{background-color:#f1f1f1;align-self:flex-start}aim-chat-message-100554 .message-title{color:#be069c}aim-chat-message-100554 .message-content{padding-right:4em}aim-chat-message-100554 .message-footer{font-size:.75rem;color:gray;position:absolute;bottom:5px;right:10px;text-align:right}`);
        this.messages = [];
    }
    render() {
        const isUser = this.isUser || false;
        if (!this.messages || this.messages.length < 1) {
            return html `<p>No messages found</p>`;
        }
        return html `
        <div class="message-group">
        ${this.messages.map((message, index) => html `
        <div class="message-row">
          <div class="message-card ${isUser ? 'user' : ''}">
            ${index === 0
            ? html `<div class="message-title">${message.sender}</div>`
            : ''}
            <div class="message-content">${message.content}</div>
            <div class="message-footer">
                ${chatHelper.formatMessageTimeCompact(message.timestamp)}
            </div>
          </div>
        </div>
        </div>
        `)}
    `;
    }
};
__decorate([
    property({ type: Array })
], AimChatMessage100554.prototype, "messages", void 0);
__decorate([
    property({ type: Boolean })
], AimChatMessage100554.prototype, "isUser", void 0);
AimChatMessage100554 = __decorate([
    customElement('aim-chat-message-100554')
], AimChatMessage100554);
export { AimChatMessage100554 };
