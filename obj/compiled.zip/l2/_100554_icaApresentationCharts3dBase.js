/// <mls shortName="icaApresentationCharts3dBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { StateLitElement } from './_100554_stateLitElement';
export class IcaApresentationCharts3dBase extends StateLitElement {
}
