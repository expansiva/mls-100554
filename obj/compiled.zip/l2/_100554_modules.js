/// <mls shortName="modules" project="100554" enhancement="_100554_enhancementLit" groupName="other" folder="" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
let Modules100554 = class Modules100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`modules-100554{display:block;padding:2rem;color:#fff;font-family:sans-serif}modules-100554 .header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:2rem;color:var(--text-primary-color)}modules-100554 .modules-list{display:grid;grid-template-columns:repeat(auto-fill, minmax(250px, 1fr));gap:1rem}modules-100554 .module-card{background:#1e1e1e;border-radius:12px;padding:1rem;box-shadow:0 4px 10px rgba(0,0,0,0.3);transition:transform .2s}modules-100554 .module-card:hover{transform:scale(1.02)}modules-100554 .card-content{display:flex;flex-direction:column;gap:.5rem}modules-100554 .module-title{font-size:1.2rem;color:#fff}modules-100554 .module-category,modules-100554 .module-uses{font-size:.9rem;color:#ccc}modules-100554 .actions{display:flex;justify-content:space-between;gap:.5rem;margin-top:1rem}modules-100554 .actions a{flex:1;text-align:center;text-decoration:none;background:#2a2a2a;color:white;padding:.5rem;border-radius:6px;transition:background .2s}modules-100554 .actions a:hover{background:#444}modules-100554 .module-details{padding:2rem;margin:2rem auto;color:#000;background:#fff;border-radius:12px;box-shadow:0 0 15px rgba(0,0,0,0.5)}modules-100554 .back-button{background:none;border:none;font-size:1rem;cursor:pointer;margin-bottom:1rem;color:#007bff}modules-100554 .back-button:hover{text-decoration:underline}modules-100554 input{width:100%;padding:.5rem;border:1px solid #ccc;border-radius:4px}modules-100554 button:not(.back-button){background:#007bff;color:#fff;border:none;padding:.5rem 1rem;margin-top:.5rem;cursor:pointer;border-radius:4px}modules-100554 button:not(.back-button):hover{background:#0056b3}`);
        this.currentView = 'list';
        this.archiveConfirmationText = '';
        this.selectedModule = null;
        this.mockModules = [
            { name: 'Authentication', category: 'Core', uses: 312 },
            { name: 'Payments', category: 'Integration', uses: 159 },
            { name: 'Dashboard', category: 'UI', uses: 512 },
            { name: 'Notifications', category: 'Service', uses: 98 },
        ];
    }
    render() {
        return html `
      ${this.currentView === 'list' ? this.renderModuleList() : this.renderModuleDetails()}
    `;
    }
    renderModuleList() {
        return html `
      <div class="header">
        <h2>Select a Module</h2>
      </div>

      <div class="modules-list">
        ${this.mockModules.map(module => html `
          <div class="module-card">
            <div class="card-content">
              <div class="module-title">${module.name}</div>
              <div class="module-category">Category: ${module.category}</div>
              <div class="module-uses">Used in ${module.uses} projects</div>
              <div class="actions">
                <a href="#">Select</a>
                <a href="#" @click=${(e) => this.openDetails(e, module)}>⋯</a>
              </div>
            </div>
          </div>
        `)}
      </div>
    `;
    }
    renderModuleDetails() {
        return html `
        <div class="module-details">
        <button class="back-button" @click=${this.goBack}>← Back</button>
        <div>In development</div>
      </div>
    `;
    }
    openDetails(ev, module) {
        ev.preventDefault();
        this.selectedModule = module;
        this.currentView = 'details';
        this.archiveConfirmationText = '';
    }
    goBack() {
        this.currentView = 'list';
        this.selectedModule = null;
        this.archiveConfirmationText = '';
    }
    confirmArchive() {
        const expected = `archive module ${this.selectedModule.name}`;
        if (this.archiveConfirmationText.trim().toLowerCase() === expected) {
            alert('Module archived!');
            this.goBack();
        }
        else {
            alert('Confirmation text does not match.');
        }
    }
};
__decorate([
    state()
], Modules100554.prototype, "currentView", void 0);
__decorate([
    state()
], Modules100554.prototype, "archiveConfirmationText", void 0);
__decorate([
    state()
], Modules100554.prototype, "selectedModule", void 0);
Modules100554 = __decorate([
    customElement('modules-100554')
], Modules100554);
export { Modules100554 };
