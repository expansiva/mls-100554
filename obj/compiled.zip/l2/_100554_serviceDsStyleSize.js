/// <mls shortName="serviceDsStyleSize" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabDSInputRange } from './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    width: 'Largura',
    maxWidth: 'Largura máxima',
    minWidth: 'Largura mínima',
    height: 'Altura',
    maxHeight: 'Altura máxima',
    minHeight: 'Altura mínima',
    overflow: 'Overflow',
    overflowX: 'Overflow-x',
    overflowY: 'Overflow-y'
};
const message_en = {
    width: 'Width',
    maxWidth: 'Max Width',
    minWidth: 'Min Width',
    height: 'Height',
    maxHeight: 'Max Height',
    minHeight: 'Min Height',
    overflow: 'Overflow',
    overflowX: 'Overflow-x',
    overflowY: 'Overflow-y'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleSize = class ServiceDsStyleSize extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.myUpp = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleSize';
        this.details = {
            icon: '&#xf07e',
            state: 'foreground',
            position: 'right',
            tooltip: 'Size',
            visible: false,
            widget: '_100554_serviceDsStyleSize',
            tags: ['ds_styles'],
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Size',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //------------IMPLEMENTS-----------
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        initCollabDSInputRange();
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    setValues(ar) {
        this.myUpp = true;
        ar.forEach((i) => {
            if (!this.shadowRoot || !i.key)
                return;
            const value = i.value;
            const prop = i.key;
            if (prop === 'overflow') {
                const elGroup = this.shadowRoot.querySelector('*[prop="overflow"]');
                const el = this.shadowRoot.querySelector('*[prop="overflow-x"]');
                const el2 = this.shadowRoot.querySelector('*[prop="overflow-y"]');
                if (elGroup)
                    elGroup.checked = true;
                if (el)
                    el.value = value;
                if (el2)
                    el2.value = value;
            }
            else {
                const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
                if (el)
                    el.value = value;
            }
        });
        this.myUpp = false;
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error)
            return html `<h3 style="color:red">${this.error}</h3>`;
        return this.renderBody();
    }
    renderBody() {
        return html `
            ${this.renderWidth()}
            ${this.renderHeight()}
            ${this.renderOverflow()}
        `;
    }
    renderWidth() {
        return html `
            <div>
                <h5>${this.msg.width}</h5>
                <div class="groupEdit">
                    <span>${this.msg.width}</span>
                    <collab-ds-input-range-100554 prop="width" value="0px" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.maxWidth}</span>
                    <collab-ds-input-range-100554 prop="max-width" value="0px" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>    
                </div>
                <div class="groupEdit">
                    <span>${this.msg.minWidth}</span>
                    <collab-ds-input-range-100554 prop="min-width" value="0px" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
            </div>
        `;
    }
    renderHeight() {
        return html `
            <div>
                <h5>${this.msg.height}</h5>
                <div class="groupEdit">
                    <span>${this.msg.height}</span>
                    <collab-ds-input-range-100554 prop="height" value="0px" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.maxHeight}</span>
                    <collab-ds-input-range-100554 prop="max-height" value="0px" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.minHeight}</span>
                    <collab-ds-input-range-100554 prop="min-height" value="0px" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
            </div>
        `;
    }
    renderOverflow() {
        return html `
            <div>
                <h5>${this.msg.overflow}</h5>
                <div class="groupEdit">
                    <span>${this.msg.overflow}</span>
                    <input type="checkbox" prop="overflow"></input>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.overflowX}</span>
                    <select @change="${(e) => this.onChangeProp2('overflow-x')}" prop="overflow-x" group="overflow">
                        <option value="none">none</option>
                        <option value="auto">auto</option>
                        <option value="hidden">hidden</option>
                        <option value="inherit">inherit</option>
                        <option value="initial">initial</option>
                        <option value="overlay">overlay</option>
                        <option value="revert">revert</option>
                        <option value="scroll">scroll</option>
                        <option value="unset">unset</option>
                        <option value="visible">visible</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.overflowY}</span>
                    <select @change="${this.onChangeProp2}" prop="overflow-y" group="overflow">
                        <option value="none">none</option>
                        <option value="auto">auto</option>
                        <option value="hidden">hidden</option>
                        <option value="inherit">inherit</option>
                        <option value="initial">initial</option>
                        <option value="overlay">overlay</option>
                        <option value="revert">revert</option>
                        <option value="scroll">scroll</option>
                        <option value="unset">unset</option>
                        <option value="visible">visible</option>
                    </select>
                </div>
            </div>
        `;
    }
    onChangeProp2(prop) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            if (!this.shadowRoot)
                return;
            const elGroup = this.shadowRoot.querySelector('*[prop="overflow"]');
            const isGroup = elGroup && elGroup.checked;
            if (isGroup) {
                const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
                const el2 = this.shadowRoot.querySelector('*[prop="' + (prop === 'overflow-x' ? 'overflow-y' : 'overflow-x') + '"]');
                if (el2)
                    el2.value = el.value;
                this.emitEvent({ key: 'overflow', value: el.value });
            }
            else {
                const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
                this.emitEvent({ key: prop, value: el.value });
            }
        }, 500);
    }
    onChangeProp(obj) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.emitEvent(obj);
        }, 500);
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        if (obj.target)
            delete obj.target;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
};
ServiceDsStyleSize.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsStyleSize.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleSize.prototype, "helper", void 0);
ServiceDsStyleSize = __decorate([
    customElement('service-ds-style-size-100554')
], ServiceDsStyleSize);
export { ServiceDsStyleSize };
