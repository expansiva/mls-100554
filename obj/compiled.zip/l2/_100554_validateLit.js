/// <mls shortName="validateLit" project="100554" enhancement="_blank" />
import { convertFileNameToTag } from './_100554_utilsLit';
export function validateTagName(modelTS) {
    if (!modelTS || !modelTS.storFile)
        return false;
    const { storFile, model } = modelTS;
    const { project, shortName } = storFile;
    storFile.hasError = false;
    clearErrorsOnModel(model);
    if (!modelTS.compilerResults)
        return false;
    if (shortName === 'enhancementLit' && project === 100554)
        return false;
    const decorators = JSON.parse(modelTS.compilerResults.decorators);
    if (!decorators)
        return false;
    const decoratorToCheck = 'customElement';
    let rc = false;
    Object.entries(decorators).forEach((entrie) => {
        const decoratorInfo = entrie[1];
        if (!decoratorInfo || decoratorInfo.type !== 'ClassDeclaration')
            return;
        decoratorInfo.decorators.forEach((_decorator) => {
            const decoratorInfo = getDecoratorClassInfo(_decorator.text);
            if (!decoratorInfo || decoratorInfo.decoratorName !== decoratorToCheck)
                return;
            let correctTagName = convertFileNameToTag(`_${project}_${shortName}`);
            if (correctTagName !== decoratorInfo.tagName) {
                rc = true;
                setErrorOnModel(model, _decorator.line + 1, decoratorToCheck.length + 3, _decorator.text.length + 1, `Invalid web component tag name, the correct definition is: ${correctTagName}`, monaco.MarkerSeverity.Error);
                storFile.hasError = true;
            }
        });
    });
    return rc;
}
export function validateRender(modelTS) {
    if (!modelTS || !modelTS.storFile)
        return false;
    const { storFile, model, compilerResults } = modelTS;
    const { project, shortName } = storFile;
    storFile.hasError = false;
    clearErrorsOnModel(model);
    if (!compilerResults)
        return false;
    if (shortName === 'enhancementLit' && project === 100554)
        return false;
    const shortName2 = `_${project}_${shortName}`;
    return verify(model, shortName2);
}
function getDecoratorClassInfo(decoratorString) {
    const regex = /(\w+)\(['"](.+?)['"]\)/;
    const match = decoratorString.match(regex);
    let result = undefined;
    if (match && match.length > 2) {
        const decoratorName = match[1];
        const tagName = match[2];
        result = {
            decoratorName,
            tagName,
        };
    }
    return result;
}
function getLineIndent(model, lineNumber) {
    if (model) {
        var lineContent = model.getLineContent(lineNumber);
        var match = lineContent.match(/^\s*/);
        return match ? match[0].length : 0;
    }
    return 0;
}
export function setErrorOnModel(model, line, startColumn, endColumn, message, severity) {
    const lineIndent = getLineIndent(model, line);
    const markerOptions = {
        severity,
        message,
        startLineNumber: line,
        startColumn: startColumn + lineIndent,
        endLineNumber: line,
        endColumn: endColumn + lineIndent,
    };
    monaco.editor.setModelMarkers(model, 'markerSource', [markerOptions]);
}
function clearErrorsOnModel(model) {
    monaco.editor.setModelMarkers(model, 'markerSource', []);
}
function verify(model, shortName) {
    const lines = model.getLinesContent();
    const tag = convertFileNameToTag(shortName);
    const msgError = `Do not use the same component tag (${tag}) inside the rendering, possible looping`;
    let htmlCount = 0;
    let rc = false;
    for (let i = 0; i < lines.length; i++) {
        let line = lines[i];
        line = line.replace(/\/\/.*/, ''); // remove inline comment 
        const lineInCommentBlock = isInCommentBlock(lines, i + 1);
        line = line.replace(/\s+/g, ''); // remove blank spaces
        if (line.indexOf(`document.createElement('${tag}')`) >= 0 ||
            line.indexOf(`document.createElement("${tag}")`) >= 0) {
            // mfile.storFile.hasError = true;
            setErrorOnModel(model, i + 1, 0, line.length, msgError, monaco.MarkerSeverity.Warning);
            rc = true;
            break;
        }
        if (line.indexOf('html`') >= 0 && !lineInCommentBlock)
            htmlCount += 1;
        if (line.indexOf('`') >= 0 && line.indexOf('html`') === -1 && !lineInCommentBlock)
            htmlCount -= 1;
        if (htmlCount != 0) {
            if (line.indexOf('<' + tag) >= 0) {
                // mfile.storFile.hasError = true;
                const column = model.getLineFirstNonWhitespaceColumn(i + 1);
                const length = model.getLineLength(i + 1);
                setErrorOnModel(model, i + 1, column, length, msgError, monaco.MarkerSeverity.Warning);
                rc = true;
                break;
            }
        }
    }
    return rc;
}
function isInCommentBlock(lines, lineNumber) {
    let countStartBlockComment = 0;
    let countEndBlockComment = 0;
    for (let i = 0; i <= lineNumber - 1; i++) {
        const line = lines[i];
        if (line.indexOf('/*') >= 0)
            countStartBlockComment += 1;
        if (line.indexOf('*/') >= 0 && i !== lineNumber - 1)
            countEndBlockComment += 1;
    }
    const isInBlockComment = countStartBlockComment > countEndBlockComment;
    return isInBlockComment;
}
;
