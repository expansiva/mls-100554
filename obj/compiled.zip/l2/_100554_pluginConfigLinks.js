/// <mls shortName="pluginConfigLinks" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg, repeat } from 'lit';
import { property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { getConfigProject, updateConfigProject } from './_100554_libProjectConfig';
export class PluginConfigLinks extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-config-links-100554{display:block;padding:1rem}plugin-config-links-100554 button{display:flex;flex-direction:column;border:1px solid #aeaeae;background:none;justify-content:center;align-items:center;width:60px;padding:.3rem;border-radius:5px;cursor:pointer}plugin-config-links-100554 button svg{width:20px}plugin-config-links-100554 .plugin-links{display:flex;gap:.5rem;flex-wrap:wrap}plugin-config-links-100554 .plugin-links link-item{position:relative;min-width:150px;padding:.5rem;background-color:#FCFCFD;border-radius:4px;box-shadow:rgba(45,35,66,0.4) 0 2px 4px,rgba(45,35,66,0.3) 0 7px 13px -3px,#D6D6E7 0 -3px 0 inset;box-sizing:border-box;cursor:pointer;font-family:"JetBrains Mono",monospace;transition:box-shadow .15s,transform .15s;user-select:none;-webkit-user-select:none;white-space:nowrap;will-change:box-shadow,transform}plugin-config-links-100554 .plugin-links link-item:focus{box-shadow:#D6D6E7 0 0 0 1.5px inset,rgba(45,35,66,0.4) 0 2px 4px,rgba(45,35,66,0.3) 0 7px 13px -3px,#D6D6E7 0 -3px 0 inset}plugin-config-links-100554 .plugin-links link-item:hover{box-shadow:rgba(45,35,66,0.4) 0 4px 8px,rgba(45,35,66,0.3) 0 7px 13px -3px,#D6D6E7 0 -3px 0 inset;transform:translateY(-2px);opacity:.8}plugin-config-links-100554 .plugin-links a{display:flex;flex-direction:column;justify-content:center;align-items:center;gap:.3rem;text-decoration:none;z-index:98}plugin-config-links-100554 .plugin-links .del-link{position:absolute;width:11px;top:2px;left:3px;z-index:99;display:none}plugin-config-links-100554 .content-edit{display:none;width:100%;border-bottom:1px solid #9c9b9b;padding:.3rem;margin-bottom:1rem;justify-content:end}plugin-config-links-100554 .content-edit content-edit{display:flex;gap:.5rem;justify-content:center;width:100%}plugin-config-links-100554 .content-edit content-edit .body-edit{display:flex;gap:.5rem;justify-content:center;align-items:center;width:99%}plugin-config-links-100554 .content-edit content-edit .body-edit div{display:flex;justify-content:center;align-items:center;gap:.3rem}plugin-config-links-100554 .content-edit content-edit .body-edit div input{height:30px;border-radius:5px;border:1px solid #bdbdbd}plugin-config-links-100554 .content-edit content-edit .body-edit div textarea{height:30px;border-radius:5px;border:1px solid #a9a5a5}plugin-config-links-100554.mode-edit .content-edit{display:flex}plugin-config-links-100554.mode-edit .del-link{display:block}plugin-config-links-100554.mode-edit .btn-edit{display:none}`);
        this.myLinks = [];
        this.autoPrepare = false;
        this.test = [
            {
                url: 'https://chatgpt.com/',
                title: 'ChatGPT',
                color: '#007bff',
            },
            {
                url: 'https://github.com/expansiva/',
                title: 'gitHub',
                color: '#000000',
            }, {
                url: 'https://www.techdrop.news/',
                title: 'TechDrop',
                color: '#4e00ff',
            },
            {
                url: 'https://www.youtube.com/@multilevelstudio7354',
                title: 'youtube',
                color: '#ff0303',
            }
        ];
    }
    async prepare() {
        this.init();
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        return html `
            ${this.renderEdit()}
            <div class="plugin-links">
                ${repeat(this.myLinks, ((lk) => lk.url), ((l, index) => {
            return this.renderLink(l, index);
        }))}
                <button style="float:right" class="btn-edit" @click="${this.setModeEdit}">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg>
                    
                    New
                </button>
            </div>
        `;
    }
    renderLink(l, idx) {
        return html `
            <link-item style="border:1px solid ${l.color}">
                
                <svg class="del-link" @click="${this.clickDel}" index="${idx}"  xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/></svg>
                <a target="_blank" href="${l.url}" >
                    
                    <label style="color:${l.color}; cursor:pointer;">${l.title}</label>
                </a>
            </link-item>
        
        `;
    }
    renderEdit() {
        return html `
            <div class="content-edit">
                <content-edit>
                    <div class="body-edit">
                        
                        <div style="width:30%">
                            <label>title</label>
                            <input style="width:100%" ref="title"/>
                        </div> 
                        <div style="width:50%">
                            <label>url</label>
                            <input style="width:100%" ref="url"/>
                        </div> 
                        <div style="width:20%">
                            <label>color</label>
                            <input style="width:100%" ref="color" type="color"/>
                        </div>

                    </div>
                    <button style="margin-left:2rem" @click="${this.addLink}">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg>
                        add
                    </button> 
                    <button @click="${this.removeModeEdit}"> 
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M48.5 224L40 224c-13.3 0-24-10.7-24-24L16 72c0-9.7 5.8-18.5 14.8-22.2s19.3-1.7 26.2 5.2L98.6 96.6c87.6-86.5 228.7-86.2 315.8 1c87.5 87.5 87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3c-62.2-62.2-162.7-62.5-225.3-1L185 183c6.9 6.9 8.9 17.2 5.2 26.2s-12.5 14.8-22.2 14.8L48.5 224z"/></svg>
                        cancel
                    </button>
                </content-edit>
                
            </div>
        
        `;
    }
    //------IMPLEMENTS---------
    async init() {
        const prj = mls.actual[5].project;
        if (!prj)
            return;
        this.myConfig = await getConfigProject(prj);
        if (this.myConfig && this.myConfig['links']) {
            this.myLinks = this.myConfig['links'];
        }
        this.requestUpdate();
    }
    async addLink(e) {
        let el = e.target;
        if (!el)
            return;
        el = el.closest('content-edit');
        if (!el)
            return;
        const alIpt = el.querySelectorAll('*[ref]');
        const info = { color: '', title: '', url: '' };
        Array.from(alIpt).forEach((i) => {
            const key = i.getAttribute('ref');
            info[key] = i.value;
            i.value = '';
        });
        if (!info.url || !info.title) {
            alert('fill all the fields!');
            return;
        }
        if (!info.color)
            info.color = '#000000';
        this.myLinks.push(info);
        this.updateConfig();
        this.requestUpdate();
    }
    async updateConfig() {
        try {
            const prj = mls.actual[5].project;
            if (!prj || !this.myConfig)
                return;
            this.myConfig['links'] = this.myLinks;
            updateConfigProject(prj, this.myConfig);
        }
        catch (e) {
            console.info(e);
        }
    }
    clickDel(e) {
        e.stopPropagation();
        let el = e.target;
        if (!el)
            return;
        if (el.tagName.toLocaleLowerCase() !== 'svg') {
            el = el.closest('svg');
        }
        const index = el.getAttribute('index');
        if (index != '' && index != null)
            this.myLinks.splice(+index, 1);
        this.updateConfig();
        this.requestUpdate();
    }
    removeModeEdit() {
        this.classList.remove('mode-edit');
    }
    setModeEdit() {
        this.classList.add('mode-edit');
    }
}
__decorate([
    property()
], PluginConfigLinks.prototype, "myLinks", void 0);
__decorate([
    property({ type: Boolean })
], PluginConfigLinks.prototype, "autoPrepare", void 0);
if (!customElements.get('plugin-config-links-100554')) {
    customElements.define('plugin-config-links-100554', PluginConfigLinks);
}
export const pluginData = {
    title: "Config links",
    getSvg() {
        return svg `
     <svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M579.8 267.7c56.5-56.5 56.5-148 0-204.5c-50-50-128.8-56.5-186.3-15.4l-1.6 1.1c-14.4 10.3-17.7 30.3-7.4 44.6s30.3 17.7 44.6 7.4l1.6-1.1c32.1-22.9 76-19.3 103.8 8.6c31.5 31.5 31.5 82.5 0 114L422.3 334.8c-31.5 31.5-82.5 31.5-114 0c-27.9-27.9-31.5-71.8-8.6-103.8l1.1-1.6c10.3-14.4 6.9-34.4-7.4-44.6s-34.4-6.9-44.6 7.4l-1.1 1.6C206.5 251.2 213 330 263 380c56.5 56.5 148 56.5 204.5 0L579.8 267.7zM60.2 244.3c-56.5 56.5-56.5 148 0 204.5c50 50 128.8 56.5 186.3 15.4l1.6-1.1c14.4-10.3 17.7-30.3 7.4-44.6s-30.3-17.7-44.6-7.4l-1.6 1.1c-32.1 22.9-76 19.3-103.8-8.6C74 372 74 321 105.5 289.5L217.7 177.2c31.5-31.5 82.5-31.5 114 0c27.9 27.9 31.5 71.8 8.6 103.9l-1.1 1.6c-10.3 14.4-6.9 34.4 7.4 44.6s34.4 6.9 44.6-7.4l1.1-1.6C433.5 260.8 427 182 377 132c-56.5-56.5-148-56.5-204.5 0L60.2 244.3z"/></svg>
    `;
    }
};
