/// <mls shortName="collabMessagesAddParticipant" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { updateThread } from './_100554_msgDBController';
import { notifyThreadChange } from './_100554_aiAgentHelper';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    btnAddParticipant: 'Adicionar participante',
    labelUserId: 'Nome do usuario ou Id',
    labelPermission: 'Autoridade:',
    errorFieldsAddParticipant: 'Preencha todos os campos!',
    successAddParticipant: 'Usuário adicionado com sucesso',
    threadDetails: 'Detalhes da sala'
};
const message_en = {
    loading: 'Loading...',
    btnAddParticipant: 'Add Participant',
    labelUserId: 'User id or name',
    labelPermission: 'Auth:',
    errorFieldsAddParticipant: 'Fill in all fields!',
    successAddParticipant: 'User added sucessfully',
    threadDetails: 'Thread details'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesAddParticipant100554 = class CollabMessagesAddParticipant100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-add-participant-100554{display:block;overflow:auto;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}collab-messages-add-participant-100554 .add-participant{display:flex;flex-direction:column;gap:1rem;padding:1rem}collab-messages-add-participant-100554 .add-participant .add-participant-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-add-participant-100554 .add-participant .add-participant-error{color:var(--error-color);font-size:var(--font-size-12)}collab-messages-add-participant-100554 .add-participant input,collab-messages-add-participant-100554 .add-participant select{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;height:30px}collab-messages-add-participant-100554 .add-participant button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}collab-messages-add-participant-100554 .add-participant button:hover{background-color:var(--info-color-hover)}`);
        this.msg = messages['en'];
        this.labelOkAddParticipant = '';
        this.labelErrorAddParticipant = '';
        this.userIdOrName = '';
        this.auth = 'write';
        this.isAddParticipant = false;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="add-participant">
            <label>
                ${this.msg.labelUserId}
                <input 
                    type="text"
                    .value=${this.userIdOrName}
                    @input=${(e) => this.userIdOrName = e.target.value}
                />
            </label>

            <label>
                ${this.msg.labelPermission}
                <select
                    .value=${this.auth}
                    @change=${(e) => this.auth = e.target.value}
                >
                    <option value="admin">Admin</option>
                    <option value="moderator">Moderator</option>
                    <option value="none">None</option>
                    <option value="read">Read</option>
                    <option value="write">Write</option>
                </select>
            </label>

            <button
                @click=${this.onSubmitAddParticipant}
                ?disabled=${this.isAddParticipant}
            >
                ${this.isAddParticipant ? html `<span class="loader"></span>` : this.msg.btnAddParticipant}
            </button>
            
            ${this.labelOkAddParticipant ? html `<small class="add-participant-ok">${this.labelOkAddParticipant}<small>` : ''}
            ${this.labelErrorAddParticipant ? html `<small class="add-participant-error">${this.labelErrorAddParticipant}<small>` : ''}
        </div>
    `;
    }
    async onSubmitAddParticipant() {
        this.labelErrorAddParticipant = '';
        this.labelOkAddParticipant = '';
        if (!this.actualThread || !this.userId) {
            return;
        }
        if (!this.userIdOrName || !this.auth) {
            this.labelErrorAddParticipant = this.msg.errorFieldsAddParticipant;
            return;
        }
        this.isAddParticipant = true;
        try {
            const response = await mls.api.msgAddUserInThread({
                auth: this.auth,
                userIdOrName: this.userIdOrName,
                threadId: this.actualThread?.thread.threadId,
                userId: this.userId,
            });
            if (response.statusCode !== 200) {
                this.labelErrorAddParticipant = `${response.msg}`;
                this.isAddParticipant = false;
                return;
            }
            if (response.thread) {
                const thr = await updateThread(response.thread.threadId, response.thread);
                notifyThreadChange(thr);
            }
            this.labelOkAddParticipant = `${this.msg.successAddParticipant}`;
            this.userIdOrName = '';
            this.auth = 'write';
            this.isAddParticipant = false;
        }
        catch (error) {
            console.error('Error on add user:', error);
            this.labelErrorAddParticipant = error.message;
            this.isAddParticipant = false;
        }
    }
};
__decorate([
    property()
], CollabMessagesAddParticipant100554.prototype, "userId", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant100554.prototype, "labelOkAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant100554.prototype, "labelErrorAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant100554.prototype, "userIdOrName", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant100554.prototype, "auth", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant100554.prototype, "isAddParticipant", void 0);
__decorate([
    property()
], CollabMessagesAddParticipant100554.prototype, "actualThread", void 0);
CollabMessagesAddParticipant100554 = __decorate([
    customElement('collab-messages-add-participant-100554')
], CollabMessagesAddParticipant100554);
export { CollabMessagesAddParticipant100554 };
