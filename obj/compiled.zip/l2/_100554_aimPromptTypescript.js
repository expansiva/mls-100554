/// <mls shortName="aimPromptTypescript" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { collab_arrow_up_long } from './_100554_collabIcons';
import { readTasks } from "./_100554_aimHelper";
import './_100554_aimPromptExample';
import './_100554_aimActionUpdateLit';
import './_100554_aimList';
import { IcaLitElement } from './_100554_icaLitElement';
import { add as addActionUpdateLit } from './_100554_aimActionUpdateLit';
const dataForDetails = {
    project: 100554,
    shortName: 'aimPromptTypescript'
};
const modelType = 'ts';
const languageid = 'typescript';
/// **collab_i18n_start**
const message_pt = {
    btnSend: 'Enviar',
    placeHolder: 'Digite sua pergunta...'
};
const message_en = {
    btnSend: 'Send',
    placeHolder: 'Enter your question...'
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
let AimPromptTypeScript = class AimPromptTypeScript extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aim-prompt-typescript-100554 .aim-prompt-container{display:flex;flex-direction:column;gap:16px;width:100%}aim-prompt-typescript-100554 .model-key-container{display:flex;flex-direction:column;gap:8px}aim-prompt-typescript-100554 .model-key-container label{font-size:14px;font-weight:500;color:var(--text-color, #000)}aim-prompt-typescript-100554 .model-key-input{margin:.5em;padding:.5em;border:1px solid #d1d1d1;border-radius:8px;background-color:#fff;color:#000;font-size:14px;outline:none;transition:border-color .3s ease}aim-prompt-typescript-100554 .model-key-input::placeholder{color:#a9a9a9;font-style:italic}aim-prompt-typescript-100554 .model-key-input:focus{border-color:#0078d4}aim-prompt-typescript-100554 .model-key-input:disabled{opacity:.4;pointer-events:none}aim-prompt-typescript-100554 .error-message{font-size:12px;color:red;margin:0}aim-prompt-typescript-100554 .aim-prompt-search-container{display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-radius:12px}aim-prompt-typescript-100554 .aim-prompt-search-input{padding:10px 15px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none}aim-prompt-typescript-100554 .aim-prompt-search-input:focus{border-color:#0078d4}aim-prompt-typescript-100554 .search-button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease}aim-prompt-typescript-100554 .search-button:hover{background-color:#005bb5}aim-prompt-typescript-100554 .search-button:disabled{background-color:#e0e0e0;cursor:not-allowed}aim-prompt-typescript-100554 .search-button:disabled{background-color:#e0e0e0;cursor:not-allowed}`);
        this.msg = messages['en'];
        /**
         * This widget can be used in 4 contexts:
         * - in the editor -> renderMode = 'editor'
         * - in service detail -> renderMode = 'detail'
         * - in preview (default) -> renderMode = 'desenv'
         */
        this.renderMode = "desenv";
        /**
         * Model key used to find the file and model.
         * Example: _100111_file1 (without extension).
         * If modelKey === "", show input.
         */
        this.modelKey = "";
        /**
         * Text being edited.
         */
        this.text = "";
        this.isLoaded = false;
        this.isError = true;
        this.taskid = -1;
    }
    async connectedCallback() {
        super.connectedCallback();
        await readTasks();
        this.isLoaded = true;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isLoaded) {
            return html `<p>Loading...</p>`;
        }
        if (this.renderMode === "desenv") {
            return html `${this.renderChoiceModelKey()}
            <hr>
            ${this.renderTask()}`;
        }
        this.validateModelKey();
        console.log('isButtonDisabled', this.isError, this.text.trim().length);
        const isButtonDisabled = this.isError || this.text.trim() === '';
        return html `
            <div class="aim-prompt-search-container">
                <textarea
                    rows="1"
                    autocomplete="off"
                    .value="${this.text}"
                    placeholder=${this.msg.placeHolder}
                    class="aim-prompt-search-input"
                    id="searchInput"
                    @focus="${this.handleFocus}"
                    @input="${this.refreshHeight}"
                ></textarea>
                <button class="search-button"
                  @click="${this.handleClick}"
                  ?disabled="${isButtonDisabled}">
                ${collab_arrow_up_long}</button>
            </div>`;
    }
    renderChoiceModelKey() {
        // Only if in desenv
        // User inputs the modelKey.
        // After validation, show input in red if there is an error.
        if (this.renderMode !== "desenv")
            return html ``;
        this.validateModelKey();
        const borderColor = this.isError ? 'border-color: red;' : '';
        return html `
            <div class="model-key-container">
                <label for="modelKeyInput">File reference:</label>
                <input
                    id="modelKeyInput"
                    type="text"
                    readonly
                    disabled
                    class="model-key-input"
                    style="${borderColor}"
                    value="${this.getActualWidget()}"
                    @input="${(e) => this.modelKey = e.target.value}"
                />
                ${this.isError ? html `<p class="error-message">source not loaded in editor</p>` : ''}
            </div>
        `;
    }
    renderTask() {
        if (this.taskid <= 0)
            return html ``;
        return html `
        <br>
        <hr>
        <aim-list-100554>
            <aim-action-update-lit-100554 mode="processed" taskindex="${this.taskid}" title="Prompt for ${this.modelKey}">
            </aim-action-update-lit-100554>
        </aim-list-100554>
        <br>`;
    }
    getActualWidget() {
        const actualLeft = mls.actual[2]?.left;
        return `_${actualLeft?.project}_${actualLeft?.shortName}`;
    }
    validateModelKey() {
        this.isError = (!mls.editor.models[this.getActualWidget()]?.ts);
    }
    handleFocus(event) {
        if (this.isInIframe() || this.isInDetail())
            return;
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(dataForDetails));
    }
    refreshHeight() {
        const textarea = this.parentElement?.querySelector("#searchInput");
        if (!textarea)
            throw new Error('field searchInput not found');
        this.text = textarea.value;
        textarea.style.height = 'auto';
        textarea.style.height = `${textarea.scrollHeight}px`;
    }
    async handleClick() {
        const textarea = this.parentElement?.querySelector("#searchInput");
        if (!textarea)
            throw new Error('field searchInput not found');
        this.validateModelKey();
        if (this.isError && textarea.value.length < 5)
            return;
        const fileRef = this.modelKey;
        let error = "";
        let prompt = await this.getPrompt(textarea.value);
        try {
            prompt = await this.getPrompt(textarea.value);
        }
        catch (e) {
            error = e.message || "An unknown error occurred";
        }
        this.taskid = addActionUpdateLit({
            title: `${fileRef} ${modelType}`,
            prompt,
            error,
            modelType: modelType,
            fileRef
        });
        textarea.value = error;
        this.refreshHeight();
        this.requestUpdate();
    }
    isInIframe() {
        return window.self !== window.top;
    }
    isInDetail() {
        let element = this;
        while (element.parentElement) {
            element = element.parentElement;
            if (element.tagName.toLowerCase() === 'service-detail-100554') {
                return true;
            }
        }
        return false;
    }
    async getPrompt(userPrompt) {
        const model = mls.editor.models[this.modelKey]?.ts;
        if (!model || !model.model)
            throw new Error('invalid reference: ' + this.modelKey);
        const source = model.model.getValue();
        if (source.length < 10)
            throw new Error('invalid ${languageid} file');
        userPrompt = this.verifyPromptWithCmd(userPrompt);
        return `
        ${userPrompt}

        \`\`\` ${languageid}
        ${source}
        \`\`\`
        `;
    }
    verifyPromptWithCmd(userPrompt) {
        if (userPrompt.trim() === "/review") {
            return `
            Review the code below and add comments directly on the relevant lines of the code.
. Add comments immediately after the observed issue, starting with "// review: [moderate | critical]".
. Use Clean Code principles to analyze: clarity, meaningful names, simplicity, organization, maintainability, and best practices.
. Validate function and variable names, and check if the code adheres to the Single Responsibility Principle.
. Suggest improvements without altering the structure of the code.
. Provide suggestions only for issues classified as moderate or critical.
. Return comments in language: ${navigator.language}`;
        }
        return userPrompt;
    }
};
__decorate([
    property({ type: "string" })
], AimPromptTypeScript.prototype, "renderMode", void 0);
__decorate([
    property({ type: "string" })
], AimPromptTypeScript.prototype, "modelKey", void 0);
__decorate([
    property({ type: "string", reflect: true })
], AimPromptTypeScript.prototype, "text", void 0);
__decorate([
    property({ type: Boolean })
], AimPromptTypeScript.prototype, "isLoaded", void 0);
AimPromptTypeScript = __decorate([
    customElement('aim-prompt-typescript-100554')
], AimPromptTypeScript);
export { AimPromptTypeScript };
