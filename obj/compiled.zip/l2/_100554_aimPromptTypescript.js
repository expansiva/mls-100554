/// <mls shortName="aimPromptTypescript" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { collab_arrow_up_long } from './_100554_collabIcons';
import { readTasks } from "./_100554_aimHelper";
import './_100554_aimPromptExample';
import './_100554_aimActionUpdateLit';
import './_100554_aimActionList';
import './_100554_aimList';
import { IcaLitElement } from './_100554_icaLitElement';
import { add as addActionUpdateLit } from './_100554_aimActionUpdateLit';
const dataForDetails = {
    project: 100554,
    shortName: 'aimPromptTypescript'
};
const modelType = 'ts';
const languageid = 'typescript';
/// **collab_i18n_start**
const message_pt = {
    btnSend: 'Enviar',
    placeHolder: 'Digite sua pergunta...'
};
const message_en = {
    btnSend: 'Send',
    placeHolder: 'Enter your question...'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let aimPromptTypeScript = class aimPromptTypeScript extends IcaLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        /**
         * This widget can be used in 3 contexts:
         * - in the editor -> renderMode = 'editor'
         * - in service detail -> renderMode = 'detail'
         * - in preview (default) -> renderMode = 'desenv'
         */
        this.renderMode = "desenv";
        /**
         * Model key used to find the file and model.
         * Example: _100111_file1 (without extension).
         * If modelKey === "", show input.
         */
        this.modelKey = "";
        /**
         * Text being edited.
         */
        this.text = "";
        this.isLoaded = false;
        this.taskid = -1;
    }
    async connectedCallback() {
        super.connectedCallback();
        await readTasks();
        this.isLoaded = true;
    }
    render() {
        if (!this.isLoaded) {
            return html `<p>Loading...</p>`;
        }
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const isError = !this.validateModelKey();
        const isButtonDisabled = isError || this.text.trim() === '';
        return html `
            ${this.taskid >= 0 ? this.renderTask() : ''}
            ${this.renderChoiceModelKey(isError)}
            <div class="aim-prompt-search-container">
                <textarea
                    rows="1"
                    autocomplete="off"
                    .value="${this.text}"
                    placeholder=${this.msg.placeHolder}
                    class="aim-prompt-search-input"
                    id="searchInput"
                    @focus="${this.handleFocus}"
                    @input="${this.handleInput}"
                ></textarea>
                <button class="search-button"
                  @click="${this.handleClick}"
                  ?disabled="${isButtonDisabled}">
                ${collab_arrow_up_long}</button>
            </div>`;
    }
    renderChoiceModelKey(isError) {
        // Only if in desenv
        // User inputs the modelKey.
        // After validation, show input in red if there is an error.
        if (this.renderMode !== "desenv")
            return html ``;
        const borderColor = isError ? 'border-color: red;' : '';
        return html `
            <div class="model-key-container">
                <label for="modelKeyInput">File reference:</label>
                <input
                    id="modelKeyInput"
                    type="text"
                    class="model-key-input"
                    placeholder="example: _${dataForDetails.project}_${dataForDetails.shortName}"
                    style="${borderColor}"
                    @input="${(e) => this.modelKey = e.target.value}"
                />
                ${isError ? html `<p class="error-message">Invalid model key</p>` : ''}
            </div>
        `;
    }
    renderTask() {
        return html `
        <br>
        <hr>
        <aim-list-100554>
            <aim-action-update-lit-100554 mode="processed" taskindex="${this.taskid}" title="Prompt for ${this.modelKey}">
            </aim-action-update-lit-100554>
        </aim-list-100554>
        <br>`;
    }
    validateModelKey() {
        // return true if all ok
        const modelKey = this.querySelector("#modelKeyInput")?.value || '';
        return !(!modelKey || !mls.editor.models[modelKey]?.ts);
    }
    handleFocus(event) {
        if (this.isInIframe() || this.isInDetail())
            return;
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(dataForDetails));
    }
    handleInput(event) {
        const textarea = event.target;
        this.text = textarea.value;
        // 1 - Update height.
        textarea.style.height = 'auto';
        textarea.style.height = `${textarea.scrollHeight}px`;
        // 2 - Update all components with the same modelKey.
        // todo: Implement this logic
    }
    async handleClick() {
        const textarea = this.parentElement?.querySelector("#searchInput");
        if (!textarea)
            throw new Error('field searchInput not found');
        const isError = !this.validateModelKey();
        if (isError || textarea.value.length < 5)
            return;
        const fileRef = this.modelKey;
        let error = "";
        let prompt = await this.getPrompt(textarea.value);
        try {
            prompt = await this.getPrompt(textarea.value);
        }
        catch (e) {
            error = e.message || "An unknown error occurred";
        }
        this.taskid = addActionUpdateLit({
            title: `${fileRef} ${modelType}`,
            prompt,
            error,
            modelType: modelType,
            fileRef
        });
        this.requestUpdate();
    }
    isInIframe() {
        return window.self !== window.top;
    }
    isInDetail() {
        let element = this;
        while (element.parentElement) {
            element = element.parentElement;
            if (element.tagName.toLowerCase() === 'service-detail-100554') {
                return true;
            }
        }
        return false;
    }
    async getPrompt(userPrompt) {
        const model = mls.editor.models[this.modelKey]?.ts;
        if (!model || !model.model)
            throw new Error('invalid reference: ' + this.modelKey);
        const source = model.model.getValue();
        if (source.length < 10)
            throw new Error('invalid ${languageid} file');
        return `
        ${userPrompt}

        \`\`\` ${languageid}
        ${source}
        \`\`\`
        `;
    }
};
aimPromptTypeScript.style = css ` .aim-prompt-container{display:flex;flex-direction:column;gap:16px;width:100%} .model-key-container{display:flex;flex-direction:column;gap:8px} .model-key-container label{font-size:14px;font-weight:500;color:var(--text-color, #000)} .model-key-input{margin:.5em;padding:.5em;border:1px solid #d1d1d1;border-radius:8px;background-color:#fff;color:#000;font-size:14px;outline:none;transition:border-color .3s ease} .model-key-input::placeholder{color:#a9a9a9;font-style:italic} .model-key-input:focus{border-color:#0078d4} .error-message{font-size:12px;color:red;margin:0} .aim-prompt-search-container{display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-radius:12px} .aim-prompt-search-input{padding:10px 15px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none} .aim-prompt-search-input:focus{border-color:#0078d4} .search-button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease} .search-button:hover{background-color:#005bb5} .search-button:disabled{background-color:#e0e0e0;cursor:not-allowed} .search-button:disabled{background-color:#e0e0e0;cursor:not-allowed}`;
__decorate([
    property({ type: "string" })
], aimPromptTypeScript.prototype, "renderMode", void 0);
__decorate([
    property({ type: "string" })
], aimPromptTypeScript.prototype, "modelKey", void 0);
__decorate([
    property({ type: "string", reflect: true })
], aimPromptTypeScript.prototype, "text", void 0);
__decorate([
    property({ type: Boolean })
], aimPromptTypeScript.prototype, "isLoaded", void 0);
aimPromptTypeScript = __decorate([
    customElement('aim-prompt-typescript-100554')
], aimPromptTypeScript);
export { aimPromptTypeScript };
