/// <mls shortName="wcEmbedsSocialMedia" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaApresentationEmbedsSocialMediaBase100554 } from './_100554_icaApresentationEmbedsSocialMediaBase';
import { propertyDataSource } from './_100554_icaLitElement';
let WcEmbedsSocialMedia100554 = class WcEmbedsSocialMedia100554 extends IcaApresentationEmbedsSocialMediaBase100554 {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    render() {
        this.style.display = 'block';
        if (!this.url)
            return html `<h3>Not found url</h3>`;
        if (this.url.includes("youtube.com") || this.url.includes("youtu.be"))
            return this.generateYouTubeEmbed(this.url);
        if (this.url.includes("twitter.com") || this.url.includes("x.com"))
            return this.generateTwitterEmbed(this.url);
        return html `<h3> Not found url </h3>`;
    }
    generateYouTubeEmbed(url) {
        let videoId = '';
        if (url.includes("youtu.be")) {
            videoId = url.split('/').pop();
        }
        else {
            const urlParams = new URLSearchParams(new URL(url).search);
            videoId = urlParams.get('v');
        }
        return html `<iframe src="https://www.youtube.com/embed/${videoId}" allowfullscreen style="display: flex; justify-content: center; align-items: center; margin: 0 auto;"></iframe>`;
    }
    generateTwitterEmbed(url) {
        this.loadExternalScripts();
        return html `
            <iframe style='width:100%;border:none' onload="setTimeout(()=>{this.style.height = (this.contentWindow.document.body.scrollHeight + 50) +'px'},1500)" srcdoc=' <html> <head> <title></title> </head> <body style=" display: flex; align-items: center; justify-content: center;"> <blockquote class="twitter-tweet"> <a href="${url.replace('x.com', 'twitter.com')}"></a> </blockquote> <script src="https://platform.twitter.com/widgets.js" ></script> </body> </html>'> 
            </iframe>
        `;
    }
    loadExternalScripts() {
        // Carrega o script do Twitter
        const twitterScript = document.createElement('script');
        twitterScript.src = "https://platform.twitter.com/widgets.js";
        twitterScript.async = true;
        twitterScript.charset = "utf-8";
        document.body.appendChild(twitterScript);
    }
};
__decorate([
    propertyDataSource({ type: String })
], WcEmbedsSocialMedia100554.prototype, "datasource", void 0);
__decorate([
    property({ type: String })
], WcEmbedsSocialMedia100554.prototype, "description", void 0);
__decorate([
    property({ type: String })
], WcEmbedsSocialMedia100554.prototype, "url", void 0);
WcEmbedsSocialMedia100554 = __decorate([
    customElement('wc-embeds-social-media-100554')
], WcEmbedsSocialMedia100554);
export { WcEmbedsSocialMedia100554 };
