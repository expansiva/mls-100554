/// <mls shortName="serviceDetail" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { getAllWebComponentsInSource } from './_100554_libCompile';
import { convertTagToFileName } from './_100554_utilsLit';
let ServiceDetail100554 = class ServiceDetail100554 extends ServiceBase {
    constructor() {
        super();
        this.plugin = {};
        //-------SERVICE------------
        this.details = {
            icon: '&#xf059',
            state: 'background',
            position: 'right',
            tooltip: 'Plugin Detail',
            visible: true,
            widget: '_100554_serviceDetail',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.onClickLink = (op) => {
            if (op === 'opAboutThis')
                return this.showAboutThis();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Example',
            actions: {
                opAboutThis: 'About this content',
            },
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.name = 'Somebody';
        this.setEvents();
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: _${this.plugin.project}_${this.plugin.shortName}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
                <li><button>Open</button></li>
            </ul>
		

        `;
        div.onclick = (e) => {
            let el = e.target;
            if (el.tagName.toLocaleLowerCase() === 'button' || (el.parentElement && el.parentElement.tagName.toLocaleLowerCase() === 'button')) {
                const keyFile = mls.stor.getKeyToFiles(this.plugin.project, 2, this.plugin.shortName, '', '.ts');
                const storFile = mls.stor.files[keyFile];
                if (!storFile)
                    return;
                this.selectLevel(2);
                this.fireEvents('open', storFile, {});
            }
        };
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    //----------COMPONENT------------------
    onServiceClick(visible, reinit, el) {
    }
    render() {
        return html `<div style="overflow:auto;height:100%;" id="contentPlugin"></div>`;
    }
    //----------IMPLEMENTS-------------------
    setEvents() {
        mls.events.addEventListener([2, 3, 4, 5, 6, 7], ['PluginDetails'], (ev) => this.onPluginDetails(ev));
    }
    onPluginDetails(ev) {
        if (!ev.desc)
            return;
        this.openMe();
        const data = JSON.parse(ev.desc);
        if (data.shortName)
            this.openPlugin(data);
    }
    async openPlugin(info) {
        const keyFile = mls.stor.getKeyToFiles(info.project, 2, info.shortName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (!storFile && this.contentPlugin) {
            this.contentPlugin.innerHTML = 'Not found storFile:' + JSON.stringify(info);
            return;
        }
        else if (!storFile)
            return;
        this.plugin = info;
        const content = await storFile.getContent();
        if (this.contentPlugin && typeof content === 'string') {
            this.contentPlugin.innerHTML = '';
            const allWcs = getAllWebComponentsInSource(content);
            this.contentPlugin.innerHTML = content;
            allWcs.forEach((wc) => {
                const fileName = convertTagToFileName(wc);
                const script = document.createElement('script');
                script.type = 'module';
                script.id = fileName;
                script.src = (`/${fileName}`);
                this.contentPlugin?.appendChild(script);
            });
        }
    }
    fireEvents(action, file, info, timeout = 0) {
        const params = {};
        params.action = action;
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = '.ts';
        params.folder = file.folder;
        params.position = 'left';
        if (info && info.shortName) {
            params.newshortName = info.shortName;
            params.newProject = info.project;
            params.newfolder = file.folder;
        }
        if (['open'].includes(action)) {
            mls.actual[2].setFullName(`_${file.project}_${file.shortName}`);
            mls.actual[2]['left'] = {
                project: file.project,
                shortName: file.shortName,
                extension: '.ts',
                folder: file.folder,
            };
        }
        mls.events.fire([2], ['FileAction'], JSON.stringify(params), timeout);
    }
};
ServiceDetail100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    query('#contentPlugin')
], ServiceDetail100554.prototype, "contentPlugin", void 0);
__decorate([
    property()
], ServiceDetail100554.prototype, "name", void 0);
ServiceDetail100554 = __decorate([
    customElement('service-detail-100554')
], ServiceDetail100554);
export { ServiceDetail100554 };
