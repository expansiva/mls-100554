/// <mls shortName="serviceDetail" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { getAllWebComponentsInSource } from './_100554_libCompile';
import { convertTagToFileName } from './_100554_utilsLit';
let ServiceDetail100554 = class ServiceDetail100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-detail-100554{display:block}`);
        this.msize = '';
        this.widget = '';
        this.plugin = {};
        //-------SERVICE------------
        this.details = {
            icon: '&#xf059',
            state: 'background',
            position: 'right',
            tooltip: 'Detail',
            visible: true,
            widget: '_100554_serviceDetail',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.onClickLink = (op) => {
            if (op === 'opAboutThis')
                return this.showAboutThis();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: '',
            actions: {
                opAboutThis: 'About this content',
            },
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.setEvents();
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        const name = this.plugin.project ? `_${this.plugin.project}_${this.plugin.shortName}` : 'nothing selected';
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
                <li><button>Open</button></li>
            </ul>
		

        `;
        div.onclick = (e) => {
            let el = e.target;
            if (el.tagName.toLocaleLowerCase() === 'button' || (el.parentElement && el.parentElement.tagName.toLocaleLowerCase() === 'button')) {
                const keyFile = mls.stor.getKeyToFiles(this.plugin.project, 2, this.plugin.shortName, '', '.ts');
                const storFile = mls.stor.files[keyFile];
                if (!storFile)
                    return;
                this.selectLevel(2);
                this.fireEvents('open', storFile, {});
            }
        };
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    onServiceClick(visible, reinit, el) {
        if (!visible && this.contentPlugin) {
            this.contentPlugin.innerHTML = '';
        }
        if (!this.contentPlugin)
            return;
        Array.from(this.contentPlugin.children).forEach((child) => {
            if (child.tagName.startsWith('PLUGIN-')) {
                child.setAttribute('msize', this.msize);
            }
        });
    }
    //----------COMPONENT------------------
    firstUpdated() {
        if (this.widget) {
            const { project, shortName } = mls.l2.getPath(this.widget);
            const info = {
                project,
                shortName,
            };
            this.showPluginContent(info);
        }
    }
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible || !this.contentPlugin)
                return;
            Array.from(this.contentPlugin.children).forEach((child) => {
                if (child.tagName.startsWith('PLUGIN-')) {
                    child.setAttribute('msize', this.msize);
                }
            });
        }
    }
    render() {
        return html `<div style="overflow:auto;height:100%;padding:1rem" id="contentPlugin"></div>`;
    }
    //----------IMPLEMENTS-------------------
    setEvents() {
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['PluginDetails'], (ev) => this.onPluginDetails(ev));
        mls.events.addListener(2, 'MonacoAction', (ev) => this.onMonacoEvents(ev));
        mls.events.addListener(2, 'FileAction', (ev) => this.onFileActionReceived.bind(this)(ev));
    }
    onMonacoEvents(ev) {
        if (!ev.desc)
            return;
        const args = JSON.parse(ev.desc);
        if (!args)
            return;
        const { action, position } = args;
        if (position === this.position)
            return;
        if (action !== 'helpAssistant')
            return;
        if (!args.codeLenCommand?.refs)
            return;
        this.openMe();
        mls.actual[0].setFullName(args.codeLenCommand.refs);
        const { project, path } = mls.actual[0];
        if (!path || !project)
            return;
        const info = {
            project,
            shortName: path,
        };
        this.showPluginContent(info);
    }
    async onFileActionReceived(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.action !== 'fileReference')
            return;
        const info = {
            project: 100554,
            shortName: 'pluginCodelensFileReferences',
            htmlText: `<plugin-codelens-file-references-100554 project=${params.project} shortname=${params.shortName} position=${params.position}></plugin-codelens-file-references-100554>`
        };
        this.openMe();
        this.showPluginContent(info);
    }
    onPluginDetails(ev) {
        if (!ev.desc)
            throw new Error('Error on PluginDetails event, invalid desc');
        this.openMe();
        const data = JSON.parse(ev.desc);
        this.showPluginContent(data);
    }
    async showPluginContent(info) {
        // show htmlText or plugin html
        if (!info.project || !info.shortName) {
            if (!info.htmlText)
                throw new Error(`Error on PluginDetails events, invalid data: ${info.project} ${info.shortName}`);
        }
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        const content = info.htmlText ? info.htmlText : await this.getHtmlFromPlugin(info);
        this.updateContentPluginWithScripts(content);
    }
    async getHtmlFromPlugin(info) {
        const keyFile = mls.stor.getKeyToFiles(info.project, 2, info.shortName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (!storFile)
            return 'Not found storFile:' + JSON.stringify(info);
        this.plugin = info;
        const content = await storFile.getContent();
        if (typeof content !== 'string')
            return `Error on content of _${info.project}_${info.shortName}`;
        return content;
    }
    updateContentPluginWithScripts(content) {
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        this.contentPlugin.innerHTML = '';
        const allWcs = getAllWebComponentsInSource(content);
        this.contentPlugin.innerHTML = content;
        allWcs.forEach((wc) => {
            const fileName = convertTagToFileName(wc);
            const script = document.createElement('script');
            script.type = 'module';
            script.id = fileName;
            script.src = (`/${fileName}`);
            this.contentPlugin?.appendChild(script);
        });
        Array.from(this.contentPlugin.children).forEach((child) => {
            if (child.tagName.startsWith('PLUGIN-')) {
                child.setAttribute('msize', this.msize);
            }
        });
    }
    fireEvents(action, file, info, timeout = 0) {
        const params = {};
        params.action = action;
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = '.ts';
        params.folder = file.folder;
        params.position = 'left';
        if (info && info.shortName) {
            params.newshortName = info.shortName;
            params.newProject = info.project;
            params.newfolder = file.folder;
        }
        if (['open'].includes(action)) {
            mls.actual[2].setFullName(`_${file.project}_${file.shortName}`);
            mls.actual[2]['left'] = {
                project: file.project,
                shortName: file.shortName,
                extension: '.ts',
                folder: file.folder,
            };
        }
        mls.events.fire([2], ['FileAction'], JSON.stringify(params), timeout);
    }
};
__decorate([
    property({ type: String })
], ServiceDetail100554.prototype, "msize", void 0);
__decorate([
    property({ type: String })
], ServiceDetail100554.prototype, "widget", void 0);
__decorate([
    query('#contentPlugin')
], ServiceDetail100554.prototype, "contentPlugin", void 0);
ServiceDetail100554 = __decorate([
    customElement('service-detail-100554')
], ServiceDetail100554);
export { ServiceDetail100554 };
