/// <mls shortName="pluginPullrequest" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { getMyKeysBranch } from './_100554_libCommom';
/// **collab_i18n_start**
const message_pt = {
    openPullrequest: 'Pull request Abertos',
    noItens: "Nenhum pull request aberto",
};
const message_en = {
    openPullrequest: 'Open pull requests',
    noItens: 'No open pull requests',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export class PluginPullrequest extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.itens = [];
        this.owner = '';
        this.repo = '';
        this.branch = '';
        this.error = '';
        this.autoPrepare = false;
    }
    //-----COMPONENT---------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        this.initInfoProject();
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error !== '') {
            setTimeout(() => this.error = '', 9900);
            return html `<h3 style="color:red">${this.error}</h3>`;
        }
        if (this.itens.length <= 0)
            return this.renderNoIntes();
        return this.renderListPull();
    }
    renderNoIntes() {
        return html `
            <h3>${this.msg.noItens}</h3>
        `;
    }
    renderListPull() {
        return html `
            <h3>${this.msg.openPullrequest}</h3>
            <ul style="list-style: decimal;">
                ${repeat(this.itens, ((key) => key.id), ((k, index) => { return this.renderItemListPull(k, index); }))}
            </ul>
        `;
    }
    renderItemListPull(i, index) {
        return html `
        <li>
            <a href="${i.url}" style="text-decoration: underline; cursor: pointer;" target="_blank">${i.title} (${i.author.login})</a>
        </li>`;
    }
    //------IMPLEMENTS--------
    async prepare() {
        this.loadListPullRequest();
    }
    async loadListPullRequest() {
        try {
            const prj = mls.actual[5].project;
            if (!prj)
                throw new Error('Not found project actual');
            const driver = mls.stor.others.getDefaultDriver(prj);
            //this.showLoader(true);
            const ret = await driver.listPullRequests(this.owner, this.repo);
            this.itens = ret;
            this.requestUpdate();
            //this.showLoader(false);
        }
        catch (err) {
            this.error = err.message;
            this.requestUpdate();
            //this.showLoader(false);
        }
    }
    async initInfoProject() {
        const prj = mls.actual[5].project;
        if (!prj)
            return;
        const info = getMyKeysBranch(prj);
        if (!info)
            return;
        this.branch = info.branch;
        this.owner = info.owner;
        this.repo = info.repo;
    }
}
__decorate([
    property()
], PluginPullrequest.prototype, "error", void 0);
__decorate([
    property()
], PluginPullrequest.prototype, "autoPrepare", void 0);
if (!customElements.get('plugin-pullrequest-100554')) {
    customElements.define('plugin-pullrequest-100554', PluginPullrequest);
}
