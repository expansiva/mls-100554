/// <mls shortName="pluginProjectInfo" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg, repeat } from 'lit';
import { query, property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
/// **collab_i18n_start**
const message_pt = {
    detailsResume: 'Resumo',
    designSystems: 'Design systems',
    lastModified: 'Última modificação',
    fork: 'Galhos',
    files: 'Arquivos',
    detailsInfo: 'Info',
    name: 'Nome',
    projectDriver: 'Driver',
    projectOrg: 'Organização',
    projectOwner: 'Proprietário',
    projectCreatedAt: 'Criado em',
    projectURL: 'URL do Projeto',
};
const message_en = {
    designSystems: 'Design systems',
    lastModified: 'Last Modified',
    detailsResume: 'Resume',
    fork: 'Forks',
    files: 'Files',
    detailsInfo: 'Info',
    name: 'Name',
    projectDriver: 'Project Driver',
    projectOrg: 'Organization',
    projectOwner: 'Owner',
    projectCreatedAt: 'CreatedAt',
    projectURL: 'Project URL',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Info",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
export class PluginProjectInfo extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-project-info-100554{font-family:'Charlie Display',-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;display:block;overflow:auto;background:#ffffff;font-size:calc(.25rem * 4)}plugin-project-info-100554 .plugin-body{height:100%;width:-webkit-fill-available;padding:1rem;overflow:hidden}plugin-project-info-100554 .plugin-container{padding:10px 0;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);display:flex;flex-direction:column;align-items:flex-start;height:100%;width:100%}plugin-project-info-100554 header{margin-left:16px}plugin-project-info-100554 header>div{display:flex;gap:.5rem}plugin-project-info-100554 icon{margin-right:10px}plugin-project-info-100554 h2{font-size:18px;font-weight:bold;margin:0;color:#333}plugin-project-info-100554 small{color:#888;margin-left:auto;font-size:14px}plugin-project-info-100554 p{font-size:16px;color:#555}plugin-project-info-100554 .details-card{margin-top:1rem;border:1px solid var(--grey-color-light);padding:1rem;border-radius:10px}plugin-project-info-100554 .listInfo{list-style:none;margin:0px;padding:0px;padding-left:.5rem;margin-bottom:2rem}plugin-project-info-100554 .listInfo ul{list-style:none}plugin-project-info-100554 details{margin-bottom:1rem}plugin-project-info-100554 details>div{padding-left:2rem}`);
        this.msg = messages['en'];
        this.autoPrepare = false;
    }
    async prepare() {
        await this.init();
    }
    //------COMPONENT------
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.display = 'block';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html ``;
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
            </header>
        `;
    }
    renderBody() {
        //${this.renderInfoFork()}
        return html `<div class="plugin-body">
            ${this.renderInfo()}
            
            
        </div>`;
    }
    renderInfo() {
        return html `
            <div class="details-card">

                <details open>
                    <summary>${this.msg.detailsInfo}</summary>
                    <div>
                        <ul class="listInfo">
                            <li>
                                <b>${this.msg.name}:</b> 
                                ${this.projectName}
                            </li>
                            <li>
                                <b>${this.msg.projectOrg}:</b> 
                                ${this.projectOrg}
                            </li>
                                <li>
                                <b>${this.msg.projectOwner}:</b> 
                                ${this.projectOwner}
                            </li>
                                <li>
                                <b>${this.msg.projectCreatedAt}:</b> 
                                ${this.projectCreatedAt}
                            </li>
                            <li style="display:flex">
                                <b>${this.msg.projectDriver}:</b> 
                                ${this.projectDriver}
                            </li>
                            <li>
                                <b>${this.msg.projectURL}:</b>
                                ${this.projectURL}
                            </li>
                        </ul>
                    </div>
                </details>
            </div>
        `;
    }
    renderInfoFork() {
        return html `
        <div class="details-card">
            <details close>
                <summary>${this.msg.fork}</summary>
                <div>
                    ${this.renderForksItem()}
                </div>
            </details>
        </div>
        `;
    }
    renderForksItem() {
        if (!this.forks && !this.branches)
            return html `No fork of this project`;
        const forks = this.forks ? html `<ul>
            ${repeat(this.forks, ((fk) => fk.nameWithOwner), ((f, index) => {
            return html `<li>${f.nameWithOwner}</li>`;
        }))}</ul>` : html ``;
        const branches = this.branches ? html `<ul>
            ${repeat(this.branches, ((br) => br.name), ((b, index) => {
            return html `<li>${b.name}</li>`;
        }))}</ul>` : html ``;
        return html `${forks}${branches}`;
    }
    //-------IMPLEMENTS-----------
    async init() {
        try {
            const project = this.project ? +this.project : mls.actual[5].project;
            if (!project)
                return;
            this.setInfos(project);
            await this.getForks(project);
        }
        catch (err) {
            console.info(err);
        }
    }
    setInfos(project) {
        let settings = mls.l5.getProjectSettings(project);
        let details = mls.l5.getProjectDetails(project);
        if (!details || !settings)
            return;
        this.projectName = details.name;
        this.projectDriver = settings.projectDriver;
        this.projectCreatedAt = new Date(details.created_at).toLocaleString();
        this.projectOwner = details.owner;
        this.projectDriver = settings.projectDriver;
        this.projectURL = settings.projectURL;
        if (mls.l5.actualOrg) {
            this.projectOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
        }
    }
    async getForks(project) {
        const driver = mls.stor.others.getDefaultDriver(project);
        const dB = this.getMyKeysBranch(project);
        const forks = await driver.listForks(dB.owner, dB.repo);
        const branches = await driver.listBranches(dB.owner, dB.repo);
        this.forks = forks;
        this.branches = branches;
    }
    getMyKeysBranch(project) {
        try {
            const obj = mls.l5.getProjectDetails(project);
            if (!obj || !obj.value)
                throw new Error('Error getProjectDetails in:' + project);
            const json = JSON.parse(obj.value);
            if (!json)
                throw new Error('Error getProjectDetails .value json in:' + project);
            let info = '';
            if (!json.projectURL && json.l5_actionPrjSettings) {
                info = json.l5_actionPrjSettings.projectURL;
            }
            else if (json.projectURL) {
                info = json.projectURL;
            }
            else {
                throw new Error('Error project info:' + project);
            }
            if (info.endsWith('/')) {
                info = info.substring(0, info.length - 1);
            }
            const array = info.split('/');
            if (array.length < 3) {
                throw new Error('Insufficient information to progress');
            }
            return { branch: array[array.length - 3], owner: array[array.length - 2], repo: array[array.length - 1] };
        }
        catch (e) {
            throw new Error('Error get info branch: ' + e.message);
        }
    }
}
__decorate([
    property({ type: Boolean })
], PluginProjectInfo.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "project", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectName", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectDriver", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOrg", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOwner", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectCreatedAt", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectURL", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "forks", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "branches", void 0);
__decorate([
    query('.plugin-body')
], PluginProjectInfo.prototype, "body", void 0);
if (!customElements.get('plugin-project-info-100554')) {
    customElements.define('plugin-project-info-100554', PluginProjectInfo);
}
