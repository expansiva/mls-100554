/// <mls shortName="pluginProjectInfo" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg, repeat } from 'lit';
import { query, property, state } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { collab_trash, collab_lock, collab_lock_open } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    detailsResume: 'Resumo',
    designSystems: 'Design systems',
    lastModified: 'Última modificação',
    fork: 'Galhos',
    deps: 'Dependências',
    files: 'Arquivos',
    detailsInfo: 'Info',
    name: 'Nome',
    projectDriver: 'Driver',
    projectOrg: 'Organização',
    projectOwner: 'Proprietário',
    projectCreatedAt: 'Criado em',
    projectURL: 'URL do Projeto',
    save: 'Salvar',
    successSavingDeps: 'Dependências atualizadas'
};
const message_en = {
    designSystems: 'Design systems',
    lastModified: 'Last Modified',
    detailsResume: 'Resume',
    fork: 'Forks',
    deps: 'Dependencies',
    files: 'Files',
    detailsInfo: 'Info',
    name: 'Name',
    projectDriver: 'Project Driver',
    projectOrg: 'Organization',
    projectOwner: 'Owner',
    projectCreatedAt: 'CreatedAt',
    projectURL: 'Project URL',
    save: 'Save',
    successSavingDeps: 'Dependencies updated'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Info",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
export class PluginProjectInfo extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-project-info-100554{font-family:var(--font-family-primary);display:block;overflow:auto;background:var(--bg-primary-color);font-size:var(--font-size-16)}plugin-project-info-100554 .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}plugin-project-info-100554 .saving-error{color:var(--error-color);font-size:var(--font-size-12)}plugin-project-info-100554 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:inline-flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}plugin-project-info-100554 button:hover{background-color:var(--info-color-hover)}plugin-project-info-100554 button .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}plugin-project-info-100554 .plugin-body{height:100%;width:-webkit-fill-available;padding:1rem;overflow:hidden}plugin-project-info-100554 .plugin-container{padding:10px 0;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);display:flex;flex-direction:column;align-items:flex-start;height:100%;width:100%}plugin-project-info-100554 header{margin-left:16px}plugin-project-info-100554 header>div{display:flex;gap:.5rem}plugin-project-info-100554 icon{margin-right:10px}plugin-project-info-100554 h2{font-size:18px;font-weight:bold;margin:0;color:#333}plugin-project-info-100554 small{color:#888;margin-left:auto;font-size:14px}plugin-project-info-100554 p{font-size:16px;color:#555}plugin-project-info-100554 .details-card{margin-top:1rem;border:1px solid var(--grey-color-light);padding:1rem;border-radius:10px}plugin-project-info-100554 .listInfo{list-style:none;margin:0px;padding:0px;padding-left:.5rem;margin-bottom:2rem}plugin-project-info-100554 .listInfo ul{list-style:none}plugin-project-info-100554 .deps-action{display:flex;justify-content:end}plugin-project-info-100554 .deps-details-list{list-style:none;padding-inline-start:0}plugin-project-info-100554 .deps-details-list li{padding:.75rem 1.25rem;border:1px solid var(--grey-color-light);display:flex;justify-content:start;align-items:center;border-right-width:0;border-left-width:0;border-radius:0;gap:1rem}plugin-project-info-100554 .deps-details-list li:first-child{border-top-width:0}plugin-project-info-100554 .deps-details-list li .deps-details-tags span{display:inline-block;padding:.2em .3em;font-size:75%;text-align:center;white-space:nowrap;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;color:#fff;background-color:#2e6596;border-radius:.25rem}plugin-project-info-100554 .deps-details-list li .deps-details-tags span svg{height:8px;fill:currentColor}plugin-project-info-100554 .deps-details-list li .deps-details-actions{margin-left:auto;cursor:pointer}plugin-project-info-100554 details{margin-bottom:1rem}plugin-project-info-100554 details summary{cursor:pointer}plugin-project-info-100554 details>div{padding-left:2rem}`);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.deps = [];
        this.isSavingDeps = false;
        this.labelOk = '';
        this.labelError = '';
    }
    async prepare() {
        await this.init();
    }
    //------COMPONENT------
    firstUpdated() {
        console.log('11111');
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.display = 'block';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderBody()}
            </div>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body">
            ${this.renderInfo()}
            ${this.renderDependencies()}

        </div>`;
    }
    renderInfo() {
        return html `
            <div class="details-card">

                <details open>
                    <summary>${this.msg.detailsInfo}</summary>
                    <div>
                        <ul class="listInfo">
                            <li>
                                <b>${this.msg.name}:</b> 
                                ${this.projectName}
                            </li>
                            <li>
                                <b>${this.msg.projectOrg}:</b> 
                                ${this.projectOrg}
                            </li>
                                <li>
                                <b>${this.msg.projectOwner}:</b> 
                                ${this.projectOwner}
                            </li>
                                <li>
                                <b>${this.msg.projectCreatedAt}:</b> 
                                ${this.projectCreatedAt}
                            </li>
                            <li style="display:flex">
                                <b>${this.msg.projectDriver}:</b> 
                                ${this.projectDriver}
                            </li>
                            <li>
                                <b>${this.msg.projectURL}:</b>
                                ${this.projectURL}
                            </li>
                        </ul>
                    </div>
                </details>
            </div>
        `;
    }
    renderDependencies() {
        return html `

        <div class="details-card">
            <details open>
                <summary>${this.msg.deps}</summary>
                <div>
                    <ul class="deps-details-list">
                        ${this.deps.map((dep, index) => {
            return html `
                                <li>
                                    <span> ${dep.name}(${dep.id})</span>
                                    <div class="deps-details-tags">
                                        <span>
                                            <i>${dep.auth === 'public' ? collab_lock_open : collab_lock}</i>
                                            <span>${dep.auth}</span>
                                        </span>
                                    </div>
                                    <div class="deps-details-actions">
                                        <span @click=${() => { this.deps.splice(index, 1); this.requestUpdate(); }}>
                                            ${collab_trash}
                                        </span>
                                    </div>
                                </li>
                            `;
        })}
                    </ul>
                    <div class="deps-action">
                        <button
                            ?disabled=${this.isSavingDeps}
                        >
                            ${this.isSavingDeps ? html `<span class="loader"></span>` : this.msg.save}
                        </button>
                    </div>
                    ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}<small>` : ''}
                    ${this.labelError ? html `<small class="saving-error">${this.labelError}<small>` : ''}      
                </div>
            </details>
        </div>
    
        `;
    }
    renderInfoFork() {
        return html `
        <div class="details-card">
            <details close>
                <summary>${this.msg.fork}</summary>
                <div>
                    ${this.renderForksItem()}
                </div>
            </details>
        </div>
        `;
    }
    renderForksItem() {
        if (!this.forks && !this.branches)
            return html `No fork of this project`;
        const forks = this.forks ? html `<ul>
            ${repeat(this.forks, ((fk) => fk.nameWithOwner), ((f, index) => {
            return html `<li>${f.nameWithOwner}</li>`;
        }))}</ul>` : html ``;
        const branches = this.branches ? html `<ul>
            ${repeat(this.branches, ((br) => br.name), ((b, index) => {
            return html `<li>${b.name}</li>`;
        }))}</ul>` : html ``;
        return html `${forks}${branches}`;
    }
    //-------IMPLEMENTS-----------
    async handleSaveDeps() {
        this.labelError = '';
        this.labelOk = '';
        this.isSavingDeps = true;
        try {
            await this.saveDeps();
            this.isSavingDeps = false;
            this.labelOk = `${this.msg.successSavingDeps}`;
        }
        catch (error) {
            console.error('Error on update perfil:', error);
            this.labelError = error.message;
            this.isSavingDeps = false;
        }
    }
    async saveDeps() {
        if (!this.project)
            throw new Error(`Project not found`);
        if (!this.projectDetails)
            throw new Error(`Project details ${this.project} not found`);
        if ('created_at' in this.projectDetails)
            delete this.projectDetails.created_at;
        if ('archived_at' in this.projectDetails)
            delete this.projectDetails.archived_at;
        if ('repository_lastModified' in this.projectDetails)
            delete this.projectDetails.repository_lastModified;
        if ('files' in this.projectDetails)
            delete this.projectDetails.files;
        const orgIndex = mls.l5.getProjectOrgIndex(this.project);
        if (!orgIndex)
            throw new Error('Project not found in organizations');
        const orgName = Object.keys(mls.stor.orgs)[orgIndex];
        this.projectDetails.prj_dependencies = this.deps.map((item) => item.id);
        const args = {
            action: "savePrjSettings",
            project: this.project,
            orgIndex,
            orgName,
            projectDetails: this.projectDetails
        };
        await mls.api.base.cbePost(args);
    }
    async init() {
        try {
            const project = this.project ? +this.project : mls.actual[5].project;
            if (!project)
                return;
            this.setInfos(project);
            this.deps = this.getDependencies();
            await this.getForks(project);
        }
        catch (err) {
            console.info(err);
        }
    }
    getDependencies() {
        const project = this.project ? +this.project : mls.actual[5].project;
        let deps = [];
        if (project)
            deps = mls.l5.getProjectDependencies(project, false);
        const allDependencies = [];
        deps.forEach((id) => {
            const depPrjDetails = mls.l5.getProjectDetails(id);
            const objDep = {};
            if (depPrjDetails) {
                objDep.name = depPrjDetails.name;
                objDep.id = depPrjDetails.id;
                objDep.auth = depPrjDetails.userAuth;
            }
            else {
                objDep.name = `Unknown - Project don't exists or deleted`;
                objDep.id = id;
                objDep.auth = '';
                objDep.unknown = true;
            }
            allDependencies.push(objDep);
        });
        return allDependencies;
    }
    setInfos(project) {
        this.project = project;
        let settings = mls.l5.getProjectSettings(project);
        this.projectDetails = mls.l5.getProjectDetails(project);
        if (!this.projectDetails || !settings)
            return;
        this.projectName = this.projectDetails.name;
        this.projectDriver = settings.projectDriver;
        this.projectCreatedAt = new Date(this.projectDetails.created_at).toLocaleString();
        this.projectOwner = this.projectDetails.owner;
        this.projectDriver = settings.projectDriver;
        this.projectURL = settings.projectURL;
        if (mls.l5.actualOrg) {
            this.projectOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
        }
    }
    async getForks(project) {
        const driver = mls.stor.others.getDefaultDriver(project);
        const dB = this.getMyKeysBranch(project);
        const forks = await driver.listForks(dB.owner, dB.repo);
        const branches = await driver.listBranches(dB.owner, dB.repo);
        this.forks = forks;
        this.branches = branches;
    }
    getMyKeysBranch(project) {
        try {
            const obj = mls.l5.getProjectDetails(project);
            if (!obj || !obj.value)
                throw new Error('Error getProjectDetails in:' + project);
            const json = JSON.parse(obj.value);
            if (!json)
                throw new Error('Error getProjectDetails .value json in:' + project);
            let info = '';
            if (!json.projectURL && json.l5_actionPrjSettings) {
                info = json.l5_actionPrjSettings.projectURL;
            }
            else if (json.projectURL) {
                info = json.projectURL;
            }
            else {
                throw new Error('Error project info:' + project);
            }
            if (info.endsWith('/')) {
                info = info.substring(0, info.length - 1);
            }
            const array = info.split('/');
            if (array.length < 3) {
                throw new Error('Insufficient information to progress');
            }
            return { branch: array[array.length - 3], owner: array[array.length - 2], repo: array[array.length - 1] };
        }
        catch (e) {
            throw new Error('Error get info branch: ' + e.message);
        }
    }
}
__decorate([
    property({ type: Boolean })
], PluginProjectInfo.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "project", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectName", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectDriver", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOrg", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOwner", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectCreatedAt", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectURL", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "forks", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "branches", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "deps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "isSavingDeps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelOk", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelError", void 0);
__decorate([
    query('.plugin-body')
], PluginProjectInfo.prototype, "body", void 0);
if (!customElements.get('plugin-project-info-100554')) {
    customElements.define('plugin-project-info-100554', PluginProjectInfo);
}
