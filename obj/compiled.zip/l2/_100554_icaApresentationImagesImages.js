/// <mls shortName="icaApresentationImagesImages" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { IcaLitElementBase } from './_100554_icaLitElementBase';
let IcaApresentationImagesImages = class IcaApresentationImagesImages extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.mySymbol = 'fa-image';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu", args: '{"itens":[{"item":"_100554_wcdMenuItemImage", "args":"normal", "level": [2, 3]},{"item":"_100554_wcdMenuItemImage", "args":"center", "level": [2, 3]},{"item":"_100554_wcdMenuItemImage", "args":"big", "level": [2, 3]},{"item":"_100554_wcdMenuItemImage", "args":"change", "level": [2, 3]}]}' },
            { name: "size" },
            { name: "events" },
            { name: "title" },
        ];
    }
    setDefaultAttributes() {
        this.setAttribute('src', `data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==`);
    }
    changeStateHtml(html) {
    }
    allowCommand(cmd, scope, target) {
        if (cmd === 'move')
            return this.commandMove(scope, target);
        return { inside: false, before: false, after: false };
    }
    // ----------- IMPLEMENTATION ---------------
    commandMove(scope, target) {
        return { inside: false, before: false, after: false };
    }
};
IcaApresentationImagesImages = __decorate([
    customElement('ica-apresentation-images-images-100554')
], IcaApresentationImagesImages);
export { IcaApresentationImagesImages };
