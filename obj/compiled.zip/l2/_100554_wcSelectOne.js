/// <mls shortName="wcSelectOne" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaFormsInputSelectOneBase } from './_100554_icaFormsInputSelectOneBase';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_icaLitElement';
let WcSelectOne = class WcSelectOne extends IcaFormsInputSelectOneBase {
    constructor() {
        super(...arguments);
        this.required = false;
        this.disabled = false;
    }
    render() {
        return html `
        <label>${this.label}</label>
        <br>
        <select
            class="select_control" 
            ?disabled=${this.disabled} 
            ?required=${this.required}
            .value=${this.selectedvalue} 
            @change=${this.handleChange}
        >
            ${this.renderOpt()}
        </select>
        <small> ${this.hint || ''}</small>
    `;
    }
    renderOpt() {
        if (this.options) {
            return html `
                ${this.options.map((opt) => {
                return html `<option value=${opt.key}>${opt.value}</option>`;
            })}
        `;
        }
    }
    handleChange(event) {
        const selectElement = event.target;
        this.selectedvalue = selectElement.value;
    }
};
WcSelectOne.styles = css `
    :host {
        display: block;
    }

    .select_control {
        display: block;
        width:100%;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #212529;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 0.25rem;
        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        outline:none;
    }
    `;
__decorate([
    propertyDataSource({ type: String })
], WcSelectOne.prototype, "hint", void 0);
__decorate([
    property({ type: Boolean })
], WcSelectOne.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WcSelectOne.prototype, "disabled", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WcSelectOne.prototype, "label", void 0);
__decorate([
    propertyDataSource()
], WcSelectOne.prototype, "options", void 0);
__decorate([
    propertyDataSource()
], WcSelectOne.prototype, "selectedvalue", void 0);
WcSelectOne = __decorate([
    customElement('wc-select-one-100554')
], WcSelectOne);
export { WcSelectOne };
