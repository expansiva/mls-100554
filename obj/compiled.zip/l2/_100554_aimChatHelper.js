/// <mls shortName="aimChatHelper" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { globalState } from './_100554_icaState';
export function getMessages(user, chatRooms, roomId) {
    const room = chatRooms.find((room) => room.id === roomId);
    if (!room) {
        console.warn(`Room with ID ${roomId} not found`);
        return [];
    }
    return room.messages
        .slice()
        .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    // .slice(-100);
}
export function getMessagesGroup(chatRooms, roomId, messages) {
    const room = chatRooms.find((room) => room.id === roomId);
    if (!room) {
        console.warn(`Room with ID ${roomId} not found`);
        return [];
    }
    return room.messages
        .filter((message) => messages.includes(message.id))
        .sort((a, b) => messages.indexOf(a.id) - messages.indexOf(b.id));
}
export function getChatRoomSummaries(user, chatRooms, group) {
    return chatRooms
        .filter((room) => room.group === group)
        .map((room) => {
        const lastSeenId = user.lastSeenChats[room.id] || new Date(0);
        const unreadCount = room.messages.filter((msg) => msg.timestamp > lastSeenId).length;
        const lastUpdate = room.messages[room.messages.length - 1]?.timestamp || new Date(0);
        const lastMessage = room.messages[room.messages.length - 1];
        const lastMessageSummary = lastMessage
            ? `${lastMessage.sender}: ${lastMessage.content}`
            : 'no msg';
        return {
            roomName: room.roomName,
            id: room.id,
            avatarUrl: room.avatarUrl,
            lastUpdate,
            unreadCount,
            lastMessageSummary,
        };
    })
        .sort((a, b) => b.lastUpdate.getTime() - a.lastUpdate.getTime());
}
export function formatChatDate(date, language = navigator.language) {
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isThisWeek = date >= new Date(now.getFullYear(), now.getMonth(), now.getDate() - now.getDay());
    if (isToday) {
        return new Intl.DateTimeFormat(language, { hour: '2-digit', minute: '2-digit' }).format(date);
    }
    else if (isThisWeek) {
        return new Intl.DateTimeFormat(language, { weekday: 'long' }).format(date);
    }
    else {
        return new Intl.DateTimeFormat(language, { day: '2-digit', month: '2-digit', year: 'numeric' }).format(date);
    }
}
export function formatMessageTime(date) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const messageDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const diffDays = Math.floor((today.getTime() - messageDay.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays === 0) {
        return `Hoje, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
    if (diffDays === 1) {
        return `Ontem, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
    return date.toLocaleDateString();
}
export function formatMessageTimeCompact(date) {
    return `${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
}
export const pathActiveRoom = "{{globalState.chat.activeRoom}}";
export const pathActiveMessage = "{{globalState.chat.activeMessage}}";
export const pathActiveFilterRooms = "{{globalState.chat.activeFilterRooms}}";
function initDataSource() {
    if (globalState?._ica?.localState?.chat)
        return;
    globalState._ica = {
        globalState: {
            chat: {
                activeRoom: "",
                activeMessage: "",
                activeFilterRooms: ""
            }
        }
    };
}
initDataSource();
