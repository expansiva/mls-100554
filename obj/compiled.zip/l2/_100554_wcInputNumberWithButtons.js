/// <mls shortName="wcInputNumberWithButtons" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_icaLitElement';
import { IcaFormsInputNumberBase } from './_100554_icaFormsInputNumberBase';
let WCInputNumber = class WCInputNumber extends IcaFormsInputNumberBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-input-number-with-buttons-100554{display:block}wc-input-number-with-buttons-100554 div{display:flex;gap:.3rem}wc-input-number-with-buttons-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer;width:40px}wc-input-number-with-buttons-100554 button:hover{background-color:var(--grey-color-light)}wc-input-number-with-buttons-100554 .input_control{display:block;width:100%;padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;-webkit-appearance:none;-moz-appearance:none;appearance:none;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;text-align:center}wc-input-number-with-buttons-100554 input[type="number"]::-webkit-inner-spin-button,wc-input-number-with-buttons-100554 input[type="number"]::-webkit-outer-spin-button{-webkit-appearance:none;margin:0}wc-input-number-with-buttons-100554 input[type="number"]{-moz-appearance:textfield}wc-input-number-with-buttons-100554 .form_error_message{color:red}`);
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.hint = '';
        this.inputmode = 'none';
        this.error = '';
    }
    render() {
        return html `
        <label class="form-control-label" for="input">
          ${this.label}
        </label>

        <div>
            <button @click=${this.handleMinusClick}> - </button>
            <input
                id="input"
                class="input_control"
                type="number"
                name=${ifDefined(this.name)}
                ?disabled=${this.disabled}
                ?readonly=${this.readonly}
                ?required=${this.required}
                min=${ifDefined(this.minvalue)}    
                max=${ifDefined(this.maxvalue)}
                step=${ifDefined(this.step)}
                .value=${this.datasource}
                ?autofocus=${this.autofocus}
                pattern=${ifDefined(this.pattern)}
                inputmode=${ifDefined(this.inputmode)}
                @input=${this.handleChange}
            />
            <button @click=${this.handlePlusClick} > + </button>
        </div>


        <div class="form_error_message">${this.error}</div>
        `;
    }
    handleMinusClick() {
        if (!this.input)
            return;
        let newval = +this.input.value - 1;
        if (!isNaN(newval) && (this.minvalue === undefined || (newval >= this.minvalue))) {
            this.datasource = newval;
        }
    }
    handlePlusClick() {
        if (!this.input)
            return;
        let newval = +this.input.value + 1;
        if (!isNaN(newval) && (this.maxvalue === undefined || (newval <= this.maxvalue))) {
            this.datasource = newval;
        }
    }
    handleChange() {
        if (!this.input)
            return;
        let newval = +this.input.value;
        this.checkNewVal(newval);
    }
    checkNewVal(value) {
        if (!isNaN(value)
            && (this.minvalue === undefined || (value >= this.minvalue))
            && (this.maxvalue === undefined || (value <= this.maxvalue))) {
            this.datasource = value;
            this.error = '';
            this.requestUpdate();
        }
        else {
            this.error = this.errormessage || '';
            this.requestUpdate();
        }
    }
};
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], WCInputNumber.prototype, "datasource", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "placeholder", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WCInputNumber.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "errormessage", void 0);
__decorate([
    property({ type: Number })
], WCInputNumber.prototype, "maxvalue", void 0);
__decorate([
    property({ type: Number })
], WCInputNumber.prototype, "minvalue", void 0);
__decorate([
    property({ type: Number })
], WCInputNumber.prototype, "step", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "autofocus", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WCInputNumber.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "inputmode", void 0);
__decorate([
    query('input[type="number"]')
], WCInputNumber.prototype, "input", void 0);
WCInputNumber = __decorate([
    customElement('wc-input-number-with-buttons-100554')
], WCInputNumber);
export { WCInputNumber };
