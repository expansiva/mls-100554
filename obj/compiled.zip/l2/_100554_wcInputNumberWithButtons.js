var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="wcInputNumberWithButtons" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_icaLitElement';
import { IcaFormsInputNumberBase } from './_100554_icaFormsInputNumberBase';
let WCInputNumber = class WCInputNumber extends IcaFormsInputNumberBase {
    constructor() {
        super(...arguments);
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.hint = '';
        this.inputmode = 'none';
        this.error = '';
    }
    render() {
        return html `
        <label class="form-control-label" for="input">
          ${this.label}
        </label>

        <div>
            <button @click=${this.handleMinusClick}> - </button>
            <input
                id="input"
                class="input_control"
                type="number"
                name=${ifDefined(this.name)}
                ?disabled=${this.disabled}
                ?readonly=${this.readonly}
                ?required=${this.required}
                min=${ifDefined(this.minvalue)}    
                max=${ifDefined(this.maxvalue)}
                step=${ifDefined(this.step)}
                .value=${this.datasource}
                ?autofocus=${this.autofocus}
                pattern=${ifDefined(this.pattern)}
                inputmode=${ifDefined(this.inputmode)}
                @input=${this.handleChange}
            />
            <button @click=${this.handlePlusClick} > + </button>
        </div>


        <div class="form_error_message">${this.error}</div>
        `;
    }
    handleMinusClick() {
        if (!this.input)
            return;
        let newval = +this.input.value - 1;
        if (!isNaN(newval) && (this.minvalue === undefined || (newval >= this.minvalue))) {
            this.datasource = newval;
        }
    }
    handlePlusClick() {
        if (!this.input)
            return;
        let newval = +this.input.value + 1;
        if (!isNaN(newval) && (this.maxvalue === undefined || (newval <= this.maxvalue))) {
            this.datasource = newval;
        }
    }
    handleChange() {
        if (!this.input)
            return;
        let newval = +this.input.value;
        this.checkNewVal(newval);
    }
    checkNewVal(value) {
        if (!isNaN(value)
            && (this.minvalue === undefined || (value >= this.minvalue))
            && (this.maxvalue === undefined || (value <= this.maxvalue))) {
            this.datasource = value;
            this.error = '';
            this.requestUpdate();
        }
        else {
            this.error = this.errormessage || '';
            this.requestUpdate();
        }
    }
};
__decorate([
    propertyDataSource({ type: String })
], WCInputNumber.prototype, "datasource", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "placeholder", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WCInputNumber.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "errormessage", void 0);
__decorate([
    property({ type: Number })
], WCInputNumber.prototype, "maxvalue", void 0);
__decorate([
    property({ type: Number })
], WCInputNumber.prototype, "minvalue", void 0);
__decorate([
    property({ type: Number })
], WCInputNumber.prototype, "step", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WCInputNumber.prototype, "autofocus", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WCInputNumber.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WCInputNumber.prototype, "inputmode", void 0);
__decorate([
    query('input[type="number"]')
], WCInputNumber.prototype, "input", void 0);
WCInputNumber = __decorate([
    customElement('wc-input-number-with-buttons-100554')
], WCInputNumber);
export { WCInputNumber };
