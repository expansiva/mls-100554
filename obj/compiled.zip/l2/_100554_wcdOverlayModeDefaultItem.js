/// <mls shortName="wcdOverlayModeDefaultItem" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { WcdOverlayItemLitBase } from './_100554_wcdOverlayItemLitBase';
import { getPosition } from './_100554_icaGlobal';
let WcdOverlayModeDefaultItem = class WcdOverlayModeDefaultItem extends WcdOverlayItemLitBase {
    constructor() {
        super(...arguments);
        this.fcCallBackClick = this.onCBClick;
        this.fcCallBackLeave = (e) => { };
        this.fcCallBackOver = (e) => { };
    }
    //---------COMPONENT--------------
    render() {
        this.overlay = this.parentElement;
        if (!this.info || !this.boundingPage)
            return html ``;
        const pos = getPosition(this.info, this.boundingPage);
        this.info.element.overlayRef = this;
        this.style.display = 'block';
        this.style.position = 'absolute';
        this.style.width = pos.width;
        this.style.height = pos.height;
        this.style.top = pos.top;
        this.style.left = pos.left;
        let aux = '';
        if (this.info.element.dataset.event && this.level === '2') {
            aux = `<span class="itemHasEvent" style="display: flex; justify-content: center; align-items: center; width: 15px; background: var(--grey-color-darker); border-radius: 10px; padding: 2px; position: absolute; right: -8px; bottom: -8px; box-shadow: 0px 2px 4px #35353500;"><svg style="fill:#ffffff; width:12px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M349.4 44.6c5.9-13.7 1.5-29.7-10.6-38.5s-28.6-8-39.9 1.8l-256 224c-10 8.8-13.6 22.9-8.9 35.3S50.7 288 64 288l111.5 0L98.6 467.4c-5.9 13.7-1.5 29.7 10.6 38.5s28.6 8 39.9-1.8l256-224c10-8.8 13.6-22.9 8.9-35.3s-16.6-20.7-30-20.7l-111.5 0L349.4 44.6z"/></svg></span>`;
        }
        return html `${unsafeHTML(aux)}`;
    }
    //---------IMPLEMENTS--------------
    onCBClick(e) {
        const wcd = this.querySelector('wcd-toolbox-100554');
        if (!wcd)
            return;
        const tag = wcd.elICA ? wcd.elICA.getActionsTags() : [];
        const test = tag.filter((i) => i.name === 'add').length <= 0;
        if (test)
            wcd.style.boxShadow = '0px 0px 2px 2px var(--bg-primary-color-darker-disabled)';
    }
};
__decorate([
    property()
], WcdOverlayModeDefaultItem.prototype, "info", void 0);
__decorate([
    property()
], WcdOverlayModeDefaultItem.prototype, "widget", void 0);
__decorate([
    property()
], WcdOverlayModeDefaultItem.prototype, "level", void 0);
WcdOverlayModeDefaultItem = __decorate([
    customElement('wcd-overlay-mode-default-item-100554')
], WcdOverlayModeDefaultItem);
export { WcdOverlayModeDefaultItem };
