/// <mls shortName="icaApresentationVideoEmbeddedVideoBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElement } from './_100554_icaLitElement';
export class IcaApresentationVideoEmbeddedVideoBase extends IcaLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.src && this.src.startsWith('/l3') && window['mls']) {
            const newSrc = await this.getUrlL3(this.src);
            if (newSrc)
                this.src = newSrc;
        }
    }
    async getUrlL3(src) {
        //Example Url => /100554/l3/assets/video1 => 100554_3_assets_video1
        const result = src.replace(/^\/(\d+)\/l(\d+)\//, '$1_$2_').replace(/\//g, '_');
        const storFile = mls.stor.files[result];
        if (!storFile)
            throw new Error('Invalid url');
        const urlCache = await storFile.saveContentInCacheIfNeed();
        return urlCache;
    }
}
