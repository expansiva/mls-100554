var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="icaFormsInputSelectOne" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { customElement } from 'lit/decorators.js';
import { IcaLitElementBase } from './_100554_icaLitElementBase';
let IcaFormsInputSelectOne = class IcaFormsInputSelectOne extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.mySymbol = 'fa-table-columns';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "events" },
            { name: "title" },
        ];
    }
    changeStateHtml(html) {
    }
    allowCommand(cmd, scope, target) {
        if (cmd === 'move')
            return this.commandMove(scope, target);
        return { inside: false, before: false, after: false };
    }
    commandMove(scope, target) {
        return { inside: false, before: false, after: false };
    }
};
IcaFormsInputSelectOne = __decorate([
    customElement('ica-forms-input-select-one-100554')
], IcaFormsInputSelectOne);
export { IcaFormsInputSelectOne };
