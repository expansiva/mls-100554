/// <mls shortName="pageTest3" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_icaState';
import { initTestState } from './_100554_testPagesState';
let PageTest3100554 = class PageTest3100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        initTestState();
        initState('projectTest.page3', {
            indexSel: -1,
            columns: ['id', 'solicitante', 'status'],
            error: '',
            action: '',
            justificativa: '',
            id: -1,
            solicitante: '',
        });
        globalState.globalStateManagment.subscribe([
            'data/0;projectTest.page3.indexSel',
            'data/0;projectTest.page3.action'
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'projectTest.page3.indexSel' && _value >= 0) {
            this.onSelectItem(_value);
            return;
        }
        if (_key === 'projectTest.page3.action' && _value === 'approve') {
            this.onApprove();
            return;
        }
        if (_key === 'projectTest.page3.action' && _value === 'reject') {
            this.onReject();
            return;
        }
    }
    onSelectItem(idx) {
        setState('projectTest.page3.id', globalState._ica.projectTest.tables.solicitacoes[idx].id, true);
        setState('projectTest.page3.solicitante', globalState._ica.projectTest.tables.solicitacoes[idx].solicitante, true);
        setState('projectTest.page3.justificativa', globalState._ica.projectTest.tables.solicitacoes[idx].justificativa, true);
    }
    onApprove() {
        setState(`projectTest.page3.action`, '', true);
        const idx = globalState._ica.projectTest.page3.indexSel;
        const dt = [...globalState._ica.projectTest.tables.solicitacoes];
        dt[idx].status = 'Aprovado';
        setState(`projectTest.tables.solicitacoes`, dt, true);
    }
    onReject() {
        setState(`projectTest.page3.action`, '', true);
        const idx = globalState._ica.projectTest.page3.indexSel;
        const jus = globalState._ica.projectTest.page3.justificativa;
        const dt = [...globalState._ica.projectTest.tables.solicitacoes];
        dt[idx].status = 'Rejeitado';
        dt[idx].justificativa = jus;
        setState(`projectTest.tables.solicitacoes`, dt, true);
    }
};
PageTest3100554 = __decorate([
    customElement('page-test3-100554')
], PageTest3100554);
export { PageTest3100554 };
