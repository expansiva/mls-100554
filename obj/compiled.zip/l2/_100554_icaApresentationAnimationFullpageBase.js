/// <mls shortName="icaApresentationAnimationFullpageBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from '/_100554_/l2/icaLitElementBase.js';
export class IcaApresentationAnimationFullpageBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaApresentationAnimationFullpageBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
}
