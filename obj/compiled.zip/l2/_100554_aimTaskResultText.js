/// <mls shortName="aimTaskResultText" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
let AimTaskResultText = class AimTaskResultText extends AimTaskBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    onInitializing() {
        this.notifyCompleteByStatus('ok', '');
    }
    renderBody(taskRoot, child) {
        const title = child.title;
        const body = child._tempResult || '';
        return html `
        <details open>
            <summary>${title}- Text</summary>
            <pre>
                <code>
                    ${body}
                </code>
            </pre>
        </details>
        `;
    }
};
AimTaskResultText = __decorate([
    customElement('aim-task-result-text-100554')
], AimTaskResultText);
export { AimTaskResultText };
