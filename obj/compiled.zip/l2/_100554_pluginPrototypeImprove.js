/// <mls shortName="pluginPrototypeImprove" project="100554" enhancement="_100554_enhancementLit" groupName="other" folder="" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { collab_file_pen, collab_magnifying_glass } from './_100554_collabIcons';
let PluginPrototypeImprove100554 = class PluginPrototypeImprove100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-prototype-improve-100554{padding:.4rem;display:block;max-width:375px;font-size:14px;font-family:var(--font-family-primary)}plugin-prototype-improve-100554 details{margin-top:.5rem}plugin-prototype-improve-100554 details>summary{cursor:pointer}plugin-prototype-improve-100554 details>div{margin-left:1rem;padding:1rem 1rem 0 1rem}plugin-prototype-improve-100554 .btn-group{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px;padding-top:10px}plugin-prototype-improve-100554 .btn-group .btn{padding:6px 12px;border-radius:16px;border:1.5px solid #ccc;background:transparent;color:#333;cursor:pointer;font-weight:400;user-select:none;transition:background-color .2s ease,border-color .2s ease,color .2s ease,font-weight .2s ease}plugin-prototype-improve-100554 .btn-group .btn:hover{border-color:#4A90E2;color:#004080}plugin-prototype-improve-100554 .btn-group .btn-selected{border-color:#4A90E2;background:#D6E9FF;color:#004080;font-weight:600}plugin-prototype-improve-100554 .btn-action{display:flex;gap:8px;align-items:center;justify-content:center;flex-wrap:wrap;margin-bottom:10px}plugin-prototype-improve-100554 .btn-action .btn{display:flex;justify-content:center;align-items:center;flex-direction:column;gap:.3rem;width:130px;height:80px;padding:6px 12px;border-radius:6px;border:1.5px solid #ccc;background:transparent;color:#333;cursor:pointer;font-weight:400;user-select:none;transition:background-color .2s ease,border-color .2s ease,color .2s ease,font-weight .2s ease}plugin-prototype-improve-100554 .btn-action .btn:hover{border-color:#4A90E2;color:#004080}plugin-prototype-improve-100554 .btn-action .btn-selected{border-color:#4A90E2;background:#D6E9FF;color:#004080;font-weight:600}plugin-prototype-improve-100554 .section{margin-bottom:24px}plugin-prototype-improve-100554 input{width:100%;font-family:inherit;font-size:1rem;padding:8px;box-sizing:border-box;border-radius:30px;border:1px solid #ccc;resize:vertical}`);
        this.improve = {
            scope: 'page',
            action: [],
            text: {},
            layout: {},
            visual: {},
            interaction: {},
            accessibility: {},
            responsiveness: {},
            notes: '',
        };
    }
    toggleAction(action) {
        const actions = this.improve.action ?? [];
        if (actions.includes(action)) {
            this.improve = {
                ...this.improve,
                action: actions.filter(a => a !== action),
            };
        }
        else {
            this.improve = {
                ...this.improve,
                action: [...actions, action],
            };
        }
    }
    updateTextOption(option, value) {
        this.improve = {
            ...this.improve,
            text: {
                ...this.improve.text,
                [option]: value,
            },
        };
    }
    updateLayoutOption(option, value) {
        this.improve = {
            ...this.improve,
            layout: {
                ...this.improve.layout,
                [option]: value,
            },
        };
    }
    updateVisualOption(option, value) {
        this.improve = {
            ...this.improve,
            visual: {
                ...this.improve.visual,
                [option]: value,
            },
        };
    }
    updateInteractionOption(option, value) {
        this.improve = {
            ...this.improve,
            interaction: {
                ...this.improve.interaction,
                [option]: value,
            },
        };
    }
    updateAccessibilityOption(option, value) {
        this.improve = {
            ...this.improve,
            accessibility: {
                ...this.improve.accessibility,
                [option]: value,
            },
        };
    }
    updateResponsivenessOption(option, value) {
        this.improve = {
            ...this.improve,
            responsiveness: {
                ...this.improve.responsiveness,
                [option]: value,
            },
        };
    }
    updateNotes(value) {
        this.improve = {
            ...this.improve,
            notes: value,
        };
    }
    renderContrastOptions() {
        const options = ['normal', 'high'];
        const selected = this.improve.visual?.contrast ?? '';
        return html `
      <div class="btn-group">
        ${options.map(opt => html `
          <button
            type="button"
            class="btn ${selected === opt ? 'btn-selected' : ''}"
            @click=${() => this.updateVisualOption('contrast', opt)}
            aria-pressed=${selected === opt}
          >
            ${opt.charAt(0).toUpperCase() + opt.slice(1)}
          </button>
        `)}
      </div>
    `;
    }
    renderTextOptions() {
        const toneOptions = ['friendly', 'professional', 'concise'];
        const toneSelected = this.improve.text?.tone ?? '';
        return html `
      <div>
        <strong>Tone</strong>
        <div class="btn-group">
          ${toneOptions.map(opt => html `
            <button
              type="button"
              class="btn ${toneSelected === opt ? 'btn-selected' : ''}"
              @click=${() => this.updateTextOption('tone', opt)}
              aria-pressed=${toneSelected === opt}
            >
              ${opt.charAt(0).toUpperCase() + opt.slice(1)}
            </button>
          `)}
        </div>

        <strong>Clarify wording</strong>
        <div class="btn-group">
            <button
            type="button"
            class="btn ${this.improve.text?.clarity ? 'btn-selected' : ''}"
            @click=${() => this.updateTextOption('clarity', !this.improve.text?.clarity)}
            aria-pressed=${this.improve.text?.clarity}
            >
            Clarify wording
            </button>
        </div>

        <strong>Shorter</strong>
        <div class="btn-group">
            <button
            type="button"
            class="btn ${this.improve.text?.shorter ? 'btn-selected' : ''}"
            @click=${() => this.updateTextOption('shorter', !this.improve.text?.shorter)}
            aria-pressed=${this.improve.text?.shorter}
            >
            Shorter
            </button>
        </div>
        
      </div>
    `;
    }
    renderLayoutOptions() {
        const gridOptions = ['auto', '1-col', '2-col', '3-col'];
        const spacingOptions = ['compact', 'comfortable', 'roomy'];
        const gridSelected = this.improve.layout?.grid ?? '';
        const spacingSelected = this.improve.layout?.spacing ?? '';
        return html `
      <div>
        <strong>Grid</strong>
        <div class="btn-group">
          ${gridOptions.map(opt => html `
            <button
              type="button"
              class="btn ${gridSelected === opt ? 'btn-selected' : ''}"
              @click=${() => this.updateLayoutOption('grid', opt)}
              aria-pressed=${gridSelected === opt}
            >
              ${opt.charAt(0).toUpperCase() + opt.slice(1)}
            </button>
          `)}
        </div>

        <strong>Spacing</strong>
        <div class="btn-group">
          ${spacingOptions.map(opt => html `
            <button
              type="button"
              class="btn ${spacingSelected === opt ? 'btn-selected' : ''}"
              @click=${() => this.updateLayoutOption('spacing', opt)}
              aria-pressed=${spacingSelected === opt}
            >
              ${opt.charAt(0).toUpperCase() + opt.slice(1)}
            </button>
          `)}
        </div>

        <strong>Align to Grid</strong>
        <div class="btn-group">
            <button
            type="button"
            class="btn ${this.improve.layout?.alignToGrid ? 'btn-selected' : ''}"
            @click=${() => this.updateLayoutOption('alignToGrid', !this.improve.layout?.alignToGrid)}
            aria-pressed=${this.improve.layout?.alignToGrid}
            >
            Align to Grid
            </button>
        </div>

        <strong>Reorder Sections</strong>
        <div class="btn-group">
            <button
            type="button"
            class="btn ${this.improve.layout?.reorderSections ? 'btn-selected' : ''}"
            @click=${() => this.updateLayoutOption('reorderSections', !this.improve.layout?.reorderSections)}
            aria-pressed=${this.improve.layout?.reorderSections}
            >
            Reorder Sections
            </button>
      </div>
        
      </div>
    `;
    }
    renderVisualOptions() {
        const imageryOptions = ['add', 'reduce', 'keep'];
        const imagerySelected = this.improve.visual?.imagery ?? '';
        return html `
      <div>
        <strong>Emphasize Headers</strong>
        <div class="btn-group">
            <button
                type="button"
                class="btn ${this.improve.visual?.emphasizeHeaders ? 'btn-selected' : ''}"
                @click=${() => this.updateVisualOption('emphasizeHeaders', !this.improve.visual?.emphasizeHeaders)}
                aria-pressed=${this.improve.visual?.emphasizeHeaders}
            >
                Emphasize Headers
            </button>
        </div>

        <strong>Imagery</strong>
        <div class="btn-group">
          ${imageryOptions.map(opt => html `
            <button
              type="button"
              class="btn ${imagerySelected === opt ? 'btn-selected' : ''}"
              @click=${() => this.updateVisualOption('imagery', opt)}
              aria-pressed=${imagerySelected === opt}
            >
              ${opt.charAt(0).toUpperCase() + opt.slice(1)}
            </button>
          `)}
        </div>
      </div>
    `;
    }
    renderInteractionOptions() {
        const ctaOptions = ['low', 'medium', 'high'];
        const ctaSelected = this.improve.interaction?.ctaProminence ?? '';
        return html `
      <div>
        <strong>CTA Prominence</strong>
        <div class="btn-group">
          ${ctaOptions.map(opt => html `
            <button
              type="button"
              class="btn ${ctaSelected === opt ? 'btn-selected' : ''}"
              @click=${() => this.updateInteractionOption('ctaProminence', opt)}
              aria-pressed=${ctaSelected === opt}
            >
              ${opt.charAt(0).toUpperCase() + opt.slice(1)}
            </button>
          `)}
        </div>

        <strong>Simplify Navigation</strong>
        <div class="btn-group">
            <button
            type="button"
            class="btn ${this.improve.interaction?.navigationSimplify ? 'btn-selected' : ''}"
            @click=${() => this.updateInteractionOption('navigationSimplify', !this.improve.interaction?.navigationSimplify)}
            aria-pressed=${this.improve.interaction?.navigationSimplify}
            >
          Simplify Navigation
        </button>
        </div>

        <strong>Add Feedback States</strong>
        <div class="btn-group">
            <button
            type="button"
            class="btn ${this.improve.interaction?.addFeedbackStates ? 'btn-selected' : ''}"
            @click=${() => this.updateInteractionOption('addFeedbackStates', !this.improve.interaction?.addFeedbackStates)}
            aria-pressed=${this.improve.interaction?.addFeedbackStates}
            >
            Add Feedback States (hover/active)
            </button>
        </div>
        
        </div>
    `;
    }
    renderAccessibilityOptions() {
        return html `
      <div>
        <strong>Accessibility</strong>
        <div class="btn-group">
            <button
            type="button"
            class="btn ${this.improve.accessibility?.largeTouchTargets ? 'btn-selected' : ''}"
            @click=${() => this.updateAccessibilityOption('largeTouchTargets', !this.improve.accessibility?.largeTouchTargets)}
            aria-pressed=${this.improve.accessibility?.largeTouchTargets}
            >
            Large Touch Targets
            </button>
         </div>

      </div>
    `;
    }
    renderResponsivenessOptions() {
        const optimizeOptions = ['mobile', 'desktop', 'both'];
        const optimizeSelected = this.improve.responsiveness?.optimizeFor ?? '';
        return html `
      <div>
        <strong>Optimize for</strong>
        <div class="btn-group">
          ${optimizeOptions.map(opt => html `
            <button
              type="button"
              class="btn ${optimizeSelected === opt ? 'btn-selected' : ''}"
              @click=${() => this.updateResponsivenessOption('optimizeFor', opt)}
              aria-pressed=${optimizeSelected === opt}
            >
              ${opt.charAt(0).toUpperCase() + opt.slice(1)}
            </button>
          `)}
        </div>

        <strong>Sticky Header</strong>
        <div class="btn-group">
            <button
                type="button"
                class="btn ${this.improve.responsiveness?.stickyHeader ? 'btn-selected' : ''}"
                @click=${() => this.updateResponsivenessOption('stickyHeader', !this.improve.responsiveness?.stickyHeader)}
                aria-pressed=${this.improve.responsiveness?.stickyHeader}
            >
            Sticky Header
            </button>
        </div>
      </div>
    `;
    }
    renderQuickActions() {
        return html `
            <div class="btn-action">
                <button
                    type="button"
                    class="btn"
                    @click=${() => this.toggleAction('review')}
                >
                    ${collab_magnifying_glass}
                    <span>Review</span>
                </button>
                <button
                    type="button"
                    class="btn"
                    @click=${() => this.toggleAction('rewrite')}
                >
                    ${collab_file_pen}
                    <span>Rewrite</span>
                </button>
                
            </div>
        
        `;
    }
    renderAdditionalNotes() {
        return html `
        <input
            placeholder="Escreva suas observações aqui..."
            .value=${this.improve.notes}
            @input=${(e) => this.updateNotes(e.target.value)}
        ></input>
                `;
    }
    render() {
        return html `

    <div class="section">${this.renderAdditionalNotes()}</div>
    <div class="section">${this.renderQuickActions()}</div>

    <details>
        <summary>Text</summary>
        <div>
            <div class="section">${this.renderTextOptions()}</div>
            <hr>
        </div>
    </details>
    <details>
        <summary>Layout</summary>
        <div>
             <div class="section">${this.renderLayoutOptions()}</div>
            <hr>

        </div>
    </details>
    <details>
        <summary>Visual</summary>
        <div>
             <div class="section">${this.renderVisualOptions()}</div>
            <hr>

        </div>
    </details>
    <details>
        <summary>Contrast</summary>
        <div>
            <div class="section">${this.renderContrastOptions()}</div>
            <hr>

        </div>
    </details>

    <details>
        <summary>Interaction</summary>
        <div>
            <div class="section">${this.renderInteractionOptions()}</div>
            <hr>
        </div>
    </details>

    <details>
        <summary>Accessibility</summary>
        <div>
            <div class="section">${this.renderAccessibilityOptions()}</div>
            <hr>
        </div>
    </details>

    <details>
        <summary>Responsiveness </summary>
        <div>
            <div class="section">${this.renderResponsivenessOptions()}</div>
            <hr>
        </div>
    </details>

<pre>${JSON.stringify(this.improve, null, 2)}</pre>

      
    `;
    }
};
__decorate([
    state()
], PluginPrototypeImprove100554.prototype, "improve", void 0);
PluginPrototypeImprove100554 = __decorate([
    customElement('plugin-prototype-improve-100554')
], PluginPrototypeImprove100554);
export { PluginPrototypeImprove100554 };
