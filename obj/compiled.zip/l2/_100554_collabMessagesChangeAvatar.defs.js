"use strict";
/// <mls shortName="collabMessagesChangeAvatar" project="100554" enhancement="_blank" folder="" />
