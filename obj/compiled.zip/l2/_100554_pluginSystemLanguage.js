/// <mls shortName="pluginSystemLanguage" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
/// **collab_i18n_start**
const message_pt = {
    languageLabel: 'Linguagens',
    alterarLabel: 'Alterar',
};
const message_en = {
    languageLabel: 'Languages',
    alterarLabel: 'Change',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Language",
    getSvg() {
        return svg `
        <svg width="22px" height="22px" viewBox="0 0 24 24" role="img" xmlns="http://www.w3.org/2000/svg" aria-labelledby="languageIconTitle" stroke="#000000" stroke-width="1" stroke-linecap="square" stroke-linejoin="miter" fill="none" color="#000000"> <title id="languageIconTitle">Language</title> <circle cx="12" cy="12" r="10"/> <path stroke-linecap="round" d="M12,22 C14.6666667,19.5757576 16,16.2424242 16,12 C16,7.75757576 14.6666667,4.42424242 12,2 C9.33333333,4.42424242 8,7.75757576 8,12 C8,16.2424242 9.33333333,19.5757576 12,22 Z"/> <path stroke-linecap="round" d="M2.5 9L21.5 9M2.5 15L21.5 15"/> </svg>
    `;
    }
};
let PluginSystemLanguage100554 = class PluginSystemLanguage100554 extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-system-language-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-system-language-100554 .plugin-container{padding:.5rem}plugin-system-language-100554 .plugin-container details>div{margin-left:1rem;margin-top:.3rem}plugin-system-language-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}plugin-system-language-100554 button:hover{background-color:var(--grey-color-light)}plugin-system-language-100554 input,plugin-system-language-100554 select,plugin-system-language-100554 textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}`);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.actualLanguage = 'pt-BR';
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    async prepare() {
        await this.init();
    }
    async init() {
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.getUserLanguage();
        return html `
            <div class="plugin-container">
                   <details open> 
                    <summary>${this.msg.languageLabel}</summary>
                    <div>
                        <select style="width:200px" .value=${this.actualLanguage} class="select-language">
                            <option value="default">Default</option>
                            <option value="pt-BR">pt-BR</option>
                            <option value="en-US">en-US</option>
                        </select>
                        <button style="margin-top:1rem" @click=${this.handleChangeLanguageClick}>${this.msg.alterarLabel}</button>
                    </div>
                </details>
            </div>
        `;
    }
    getUserLanguage() {
        const userSettings = localStorage.getItem('userSettings');
        if (!userSettings) {
            this.actualLanguage = 'default';
            return;
        }
        const data = JSON.parse(userSettings);
        if (!data || !data.language) {
            this.actualLanguage = 'default';
            return;
        }
        this.actualLanguage = data.language;
    }
    handleChangeLanguageClick() {
        if (!this.selectLanguage)
            return;
        const language = this.selectLanguage.value;
        this.setUserLanguage(language);
        location.reload();
    }
    setUserLanguage(language) {
        let data = { language: '' };
        const userSettings = localStorage.getItem('userSettings');
        if (userSettings)
            data = JSON.parse(userSettings);
        if (language === 'default')
            this.actualLanguage = this.getUserDefault();
        else
            this.actualLanguage = language;
        data.language = language;
        localStorage.setItem('userSettings', JSON.stringify(data));
    }
    getUserDefault() {
        const navigatorLanguage = this.getNavigatorLanguage();
        const acceptLanguages = ['en-US', 'pt-BR'];
        const defaultLang = acceptLanguages.includes(navigatorLanguage) ? navigatorLanguage : 'en-US';
        return defaultLang;
    }
    getNavigatorLanguage() {
        const lg = navigator.language ? navigator.language : '';
        return lg;
    }
    ;
};
__decorate([
    property({ type: Boolean })
], PluginSystemLanguage100554.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginSystemLanguage100554.prototype, "actualLanguage", void 0);
__decorate([
    query('.select-language')
], PluginSystemLanguage100554.prototype, "selectLanguage", void 0);
PluginSystemLanguage100554 = __decorate([
    customElement('plugin-system-language-100554')
], PluginSystemLanguage100554);
export { PluginSystemLanguage100554 };
