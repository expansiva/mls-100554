/// <mls shortName="iaAgentBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export class AgentBase {
    constructor(_threadId, _userId) {
        this.threadId = _threadId;
        this.userId = _userId;
    }
    async executeAgent(agentName, prompt, step) {
        if (!this.userId)
            throw new Error('Not found userId');
        if (!this.threadId)
            throw new Error('Not found threadId');
        const instanceModule = await import(`./_100554_${agentName}`);
        if (!instanceModule)
            throw new Error(`Invalid module for agent : ${agentName}, step: ${step} `);
        const instanceClass = instanceModule[agentName];
        if (!instanceClass)
            throw new Error(`Invalid class name for agent : ${agentName}, step: ${step} `);
        const instanceAgent = new instanceClass(this.threadId, this.userId);
        if (!instanceAgent)
            throw new Error(`Invalid instance for agent : ${agentName}, step: ${step} `);
        const inputs = instanceAgent.getPrompt(prompt);
        if (!inputs)
            throw new Error('Invalid inputs');
        const task = await this.executeInteraction(step, inputs);
        this.task = task;
        const payload = this.getPayloadByStep(task, step + 1);
        await instanceAgent.afterPrompt(payload);
    }
    getPayloadByStep(task, step) {
        let ret = undefined;
        const getPayload = (interaction) => {
            if (!interaction || ret !== undefined)
                return;
            if (interaction.payload && interaction.payload.length > 0) {
                interaction.payload.forEach((p) => {
                    if (ret === undefined && p.stepId === step)
                        ret = [p];
                    getPayload(p.interaction);
                });
            }
        };
        getPayload(task.iaCompressed?.interaction);
        return ret;
    }
    async executePrompt(prompt, inputs) {
        if (!this.userId)
            throw new Error('Not found userId');
        if (!this.threadId)
            throw new Error('Not found threadId');
        const args = {
            action: 'addMessageAI',
            userId: this.userId,
            threadId: this.threadId,
            message: prompt,
            inputAI: inputs,
        };
        const ret = await mls.api.msgAddMessageAI(args);
        this.task = ret.task;
        return ret.task;
    }
    async executeInteraction(parentStepId, inputs) {
        if (!this.userId)
            throw new Error('Not found userId');
        if (!this.threadId)
            throw new Error('Not found threadId');
        if (!this.task)
            throw new Error('Not found task');
        const args = {
            action: 'addTaskAIInteraction',
            userId: this.userId,
            messageId: this.task.messageid_created || '',
            taskId: this.task.PK,
            parentStepId,
            inputAI: inputs,
        };
        const ret = await mls.api.msgAddTaskAIInteraction(args);
        this.task = ret.task;
        return ret.task;
    }
    async executeUpdateStepStatus(status, stepId) {
        if (!this.userId)
            throw new Error('Not found userId');
        if (!this.threadId)
            throw new Error('Not found threadId');
        if (!this.task)
            throw new Error('Not found task');
        const args = {
            action: 'updateStepStatus',
            userId: this.userId,
            messageId: this.task.messageid_created || '',
            taskId: this.task.PK,
            stepId,
            status
        };
        const ret = await mls.api.msgUpdateStepStatus(args);
        return ret.task;
    }
    async executeGetTask(messageId, taskId) {
        if (!this.userId)
            throw new Error('Not found userId');
        if (!this.threadId)
            throw new Error('Not found threadId');
        const args = {
            action: 'getTaskUpdate',
            userId: this.userId,
            messageId,
            taskId
        };
        const ret = await mls.api.msgGetTaskUpdate(args);
        return ret.task;
    }
}
