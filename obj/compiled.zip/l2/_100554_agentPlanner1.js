/// <mls shortName="agentPlanner1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { svg_agent } from './_100554_aiAgentBase';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, calculateStepsStatistics, updateStepStatus, notifyTaskCompleted, getStepById, updateTaskTitle, notifyTaskChange } from "./_100554_aiAgentHelper";
import { systemAgentsAvailable, systemRagsAvailable, systemToolsAvailable, addRAGAdditionalInformation, preferModelType, getPromptByHtml } from "./_100554_aiPrompts";
import { startNewAiTask, executeNextStep, startNewInteractionInAiTask, } from "./_100554_aiAgentOrchestration";
const agentName = "agentPlanner1";
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "first agent for general prompts",
        visibility: "private",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async beforeClarification(context, stepId) {
            return _beforeClarification(context, stepId);
        }
    };
}
;
const _beforePrompt = async (context) => {
    const taskTitle = "Planning";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        // using temporary context, create a new task
        const inputs = await getPrompts(context.message.content, null);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
    }
    else {
        const step = getNextPendingStepByAgentName(context.task, agentName);
        if (!step) {
            throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
        }
        context.task = await updateStepStatus(context.task, step.stepId, "in_progress");
        const inputs = await getPrompts(step.prompt, step.rags);
        await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
    const { flexible, result } = calculateStepsStatistics([step], true);
    if (flexible > 0)
        throw new Error(`[${agentName}] afterPrompt: error, Flexible step found.`);
    context.task = await updateStepStatus(context.task, step.stepId, "completed");
    await executeNextStep(context);
    if (result > 0)
        await addMessageResponse(context, step);
};
const _beforeClarification = async (context, stepId) => {
    if (!context.task)
        throw new Error("[_beforeClarification] Invalid context.task");
    const step = getStepById(context.task, stepId);
    if (!step)
        throw new Error(`[_beforeClarification] Invalid step: ${stepId} on task: ${context.task.PK}`);
    const msg = `Invalid return from agent: ${agentName} not supported return of type clarification`;
    await updateStepStatus(context.task, stepId, 'failed', msg);
    const task = await updateTaskTitle(context.task, msg);
    context.task = task;
    notifyTaskChange(context);
    const element = prepareHtmlClarification();
    return element;
};
function prepareHtmlClarification() {
    const div = document.createElement('div');
    div.innerHTML = `Invalid return from LLM, ${agentName} don't use payload of type Clarification, please try again!`;
    return div;
}
async function addMessageResponse(context, step) {
    const payload = step?.interaction?.payload;
    if (!payload)
        return;
    const [pay1] = payload;
    if (!pay1 || pay1.type !== 'result')
        return;
    const value = typeof pay1.result === 'object' ? JSON.stringify(pay1.result) : pay1.result;
    if (!value || typeof value !== 'string')
        return;
    notifyTaskCompleted(context, value);
}
export async function getPrompts(prompt, rags) {
    if (!prompt || prompt.length < 3)
        throw new Error("Invalid Prompt");
    const agents = systemAgentsAvailable();
    const ragsA = systemRagsAvailable();
    const tools = await systemToolsAvailable();
    const data = {
        mode: preferModelType("cost"),
        agentsAvailable: agents.content,
        ragsAvailable: ragsA.content,
        toolsAvailable: tools.content,
        humanPrompt: prompt
    };
    const prompts = await getPromptByHtml({ project: 100554, shortName: 'agentPlanner1', folder: '', data });
    addRAGAdditionalInformation(rags, prompts);
    return prompts;
}
