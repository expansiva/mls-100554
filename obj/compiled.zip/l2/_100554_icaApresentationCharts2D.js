/// <mls shortName="icaApresentationCharts2D" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { IcaLitElementBase } from './_100554_icaLitElementBase';
let IcaApresentationCharts2D = class IcaApresentationCharts2D extends IcaLitElementBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    getActionsTags() {
        let rc = [
            { name: "title" },
        ];
        return rc;
    }
    changeStateHtml(html) {
    }
    allowCommand(cmd, scope, target) {
        return { inside: false, before: false, after: false };
    }
    commandMove(scope, target) {
        return { inside: false, before: false, after: false };
    }
};
IcaApresentationCharts2D = __decorate([
    customElement('ica-apresentation-charts2-d-100554')
], IcaApresentationCharts2D);
export { IcaApresentationCharts2D };
