/// <mls shortName="collabPromptPreview" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { loadChatPreferences } from './_100554_collabMessageHelper';
import { getUserIdLocalStorage, getTemporaryContext } from './_100554_aiAgentHelper';
import { createAgent } from './_100554_agentWebCare';
export const initCollabICATree = '';
const message_pt = {
    send: 'Enviar',
    overlay: 'Digite seu prompt'
};
const message_en = {
    send: 'Send',
    overlay: 'Edit your prompt'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let CollabFCATree = class CollabFCATree extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-prompt-preview-100554 .input-wrapper{display:flex;border:1px solid var(--grey-color-dark);border-radius:5px;overflow:hidden;font-family:var(--font-family-primary);background-color:var(--bg-primary-color)}collab-prompt-preview-100554 .input-wrapper input{flex:1;border:none;padding:var(--space-16) var(--space-24);font-size:var(--font-size-16);outline:none;color:var(--text-primary-color-lighter);background-color:var(--bg-primary-color-lighter)}collab-prompt-preview-100554 .input-wrapper button{background-color:var(--text-primary-color-disabled);color:var(--bg-primary-color);border:none;padding:var(--space-16) var(--space-24);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background-color var(--transition-normal) ease}collab-prompt-preview-100554 .input-wrapper button:hover{opacity:.8}collab-prompt-preview-100554 .loader{border:3px solid #f3f3f3;border-top:3px solid #555;border-radius:50%;width:16px;height:16px;animation:spin 1s linear infinite;display:inline-block}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}`);
        this.msg = messages['en'];
        this.page = '';
        this.loading = false;
    }
    render() {
        return html `
        <div class="input-wrapper">
            <input
                type="text"
                id="inputpromptpreview"
                placeholder="Digite sua mensagem..."
                ?disabled=${this.loading}
            />
            <button type="button" @click=${this.clickSend} ?disabled=${this.loading}>
                ${this.loading
            ? html `<span class="loader"></span>`
            : this.msg.send}
            </button>
        </div>
        `;
    }
    async clickSend() {
        if (!this.page) {
            this.sendError('Erro page not selected');
            return;
        }
        const v = this.inputpromptpreview?.value || '';
        if (!v) {
            this.sendError('Error: Invalid prompt');
            return;
        }
        this.loading = true;
        if (this.inputpromptpreview)
            this.inputpromptpreview.value = '';
        try {
            await this.fireCollab(JSON.stringify({ page: this.page, prompt: v }));
        }
        catch (err) {
            this.sendError('Error on send message:' + err.message);
        }
        finally {
            this.loading = false;
        }
    }
    sendError(erro) {
        const father = this.closest('service-preview-100554');
        if (!father)
            return;
        if (father.setError)
            father.setError(erro);
    }
    async fireCollab(prompt) {
        const pref = loadChatPreferences();
        if (!pref.threadMaintenance) {
            this.sendError('Please configure your maintenance thread at: CollabMessage > Settings > Chat Preferences');
            return;
        }
        const userId = getUserIdLocalStorage();
        const threadId = pref.threadMaintenance;
        if (!userId)
            return;
        const context = getTemporaryContext(threadId, userId, '@@ agentWebCare ' + prompt);
        const agent = createAgent();
        await agent.beforePrompt(context);
    }
};
__decorate([
    property()
], CollabFCATree.prototype, "page", void 0);
__decorate([
    query('#inputpromptpreview')
], CollabFCATree.prototype, "inputpromptpreview", void 0);
__decorate([
    state()
], CollabFCATree.prototype, "loading", void 0);
CollabFCATree = __decorate([
    customElement('collab-prompt-preview-100554')
], CollabFCATree);
export { CollabFCATree };
