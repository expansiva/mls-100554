/// <mls shortName="testPageInPage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let TestPageICAFull = class TestPageICAFull extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        window.globalState = {
            tables: {
                sex: [{ key: 'm', value: 'masculino' }, { key: 'f', value: 'feminino' }],
            },
            newUser: {
                name: '',
                age: 0,
                city: '',
                sex: ''
            },
            sum: 0,
        };
    }
    /// **collab_events_start**
    handleClickbtnSomarDesktop() {
        window.globalStateManagment.setState('sum', window.globalState.sum + 1);
    }
    handleClickbtnSubtrairDesktop() {
        window.globalStateManagment.setState('sum', window.globalState.sum - 1);
    }
};
TestPageICAFull = __decorate([
    customElement('test-page-in-page-100554')
], TestPageICAFull);
export { TestPageICAFull };
