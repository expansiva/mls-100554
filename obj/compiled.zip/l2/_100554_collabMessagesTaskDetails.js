/// <mls shortName="collabMessagesTaskDetails" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { getNextResultStep, getNextPendentStep, getNextClarificationStep, getInteractionStepId, getStepById, getTotalCost, getTemporaryContext } from './_100554_aiAgentHelper';
import { getClarification } from './_100554_aiAgentOrchestration';
import { collab_money } from './_100554_collabIcons';
let WidgetAiInteraction100554 = class WidgetAiInteraction100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-details-100554{display:block;overflow:auto;font-family:var(--font-family-primary);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);height:100%;padding:0 .5rem}collab-messages-task-details-100554 .task-short-info{font-size:var(--font-size-16);margin:1rem 0}collab-messages-task-details-100554 .task-short-info>div{display:flex;align-items:center;gap:.5rem}collab-messages-task-details-100554 details>div{font-size:var(--font-size-12);margin-left:1rem;padding:.5rem}collab-messages-task-details-100554 details summary{cursor:pointer}collab-messages-task-details-100554 .formated-details-json pre{background:#f8f8f8;padding:12px;border-radius:6px;overflow-x:auto;font-family:monospace;font-size:14px;white-space:pre-wrap;word-break:break-word;color:#000}collab-messages-task-details-100554 .formated-details-json .json-key{color:brown}collab-messages-task-details-100554 .formated-details-json .json-string{color:olive}collab-messages-task-details-100554 .formated-details-json .json-value{color:navy}collab-messages-task-details-100554 .prompts-content{display:flex;flex-direction:column;gap:1rem}collab-messages-task-details-100554 .prompts-content .prompts-input-item{display:flex;flex-direction:column;border:1px solid var(--grey-color-light);padding:var(--space-16);gap:1rem}collab-messages-task-details-100554 .prompts-content .prompts-input-item .prompts-input-type{text-transform:uppercase;font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}collab-messages-task-details-100554 .prompts-content .prompts-input-item .prompts-input-content pre{font-size:var(--font-size-12);white-space:break-spaces;overflow:hidden}collab-messages-task-details-100554 .interactions .cost{display:flex;align-items:center;margin-bottom:.4rem}collab-messages-task-details-100554 .interactions .cost svg{width:10px;height:10px}collab-messages-task-details-100554 .interactions .trace-content pre{font-size:var(--font-size-12);white-space:break-spaces}collab-messages-task-details-100554 .clarification-details pre{font-size:var(--font-size-12);white-space:break-spaces;max-height:200px;overflow-y:scroll}collab-messages-task-details-100554 .flexible-details pre{font-size:var(--font-size-12);white-space:break-spaces;max-height:200px;overflow:auto}collab-messages-task-details-100554 .result pre{font-size:var(--font-size-12);white-space:break-spaces}collab-messages-task-details-100554 .rotate{animation:spin 1s linear infinite}@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(-360deg)}}`);
        this.task = undefined;
        this.stepid = '';
        this.seen = new Set();
        this.PROJECTNUMBER = 100554;
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.interactionClarification) {
            this.setClarification();
        }
    }
    render() {
        if (!this.task)
            return html `No task.`;
        let isClarificationPending = false;
        if (this.task) {
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                isClarificationPending = true;
        }
        return html `

            <div class="task-short-info">
                <div>
                    <b>${this.task.PK}</b> 
                    <span>${this.task.status}</span> 
                    <span>${collab_money} ${getTotalCost(this.task)}</span>
                </div>

            </div>
            
            <details class="details-task">
                <summary>Details</summary>
                <div>
                    <details>
                        <summary>Raw</summary>
                        <div>
                            ${this.renderTaskModeJson()}
                        </div>
                    </details>
                    ${this.renderTaskModeDetails()}
                </div>
            </details>
            
            ${this.task?.status === "done"
            ? this.renderDirectResult()
            : html ``}

            ${isClarificationPending
            ? this.renderDirectClarification()
            : html ``}

            `;
    }
    renderTaskModeJson() {
        if (!this.task)
            return html ``;
        const formattedJson = this.syntaxHighlight(this.task);
        return html `<div class="formated-details-json"><pre .innerHTML=${formattedJson}></pre></div>`;
    }
    renderTaskModeDetails() {
        return html `
            ${this.renderTaskInfo()}
            ${this.renderlLongMemory()}
            ${this.task?.iaCompressed?.nextSteps ? this.renderTaskInteractions(this.task?.iaCompressed?.nextSteps) : ''}
        `;
    }
    renderDirectResult() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextResultStep(this.task);
        if (!payload)
            return html ``;
        return this.renderResult(payload);
    }
    renderDirectClarification() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextClarificationStep(this.task);
        if (!payload)
            return html ``;
        return html `<div class="direct-clarification">${this.renderClarification(payload)}</div>`;
    }
    renderlLongMemory() {
        if (!this.task || !this.task.iaCompressed?.longMemory)
            return html ``;
        return html `
            <h4>LongMemory</h4>
            <ul>
                ${Object.keys(this.task.iaCompressed?.longMemory).map((key) => {
            return html `<li>${key}:${this.task?.iaCompressed?.longMemory[key]}</li>`;
        })}
            </ul>
        `;
    }
    renderTaskInfo() {
        if (!this.task)
            return html ``;
        const cloneTask = Object.assign({}, this.task);
        delete cloneTask.iaCompressed;
        return html `
            <div class="task-info">
                <ul>
                    ${Object.keys(cloneTask).map((key) => {
            return html `
                            <li>${key}: 
                            ${cloneTask && typeof cloneTask[key] === 'string'
                ? cloneTask[key]
                : cloneTask[key].toString()} </li>`;
        })}
                </ul>             
            </div>
        `;
    }
    renderTaskInteractions(payloads) {
        return html `
            <div class="payload-content">
                ${payloads.map((payload) => {
            return html `
                <div>
                    ${this.renderPayload(payload)}
                </div>`;
        })}
            </div>
        `;
    }
    renderPayload(payload, isDirect = false) {
        switch (payload.type) {
            case 'agent':
                return this.renderPayloadAgent(payload, isDirect);
            case 'tool':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderTool(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
                    </details>
                `;
            case 'clarification':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderClarificationDetails(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}
                    </details>
                `;
            case 'result':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderResult(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
                    </details>
                `;
            case 'flexible':
                return html `
                    <details ?open=${isDirect} >
                        <summary>${payload.type}</summary>
                        ${this.renderFlexible(payload)}
                        ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
                        ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
                    </details>
                `;
            default:
                return html `<p>Tipo de resultado desconhecido.</p>`;
        }
    }
    renderPayloadAgent(payload, isDirect = false) {
        if (payload.type !== 'agent')
            return html ``;
        return html `
        <details ?open=${isDirect}>
            <summary>
                ${payload.type}(${payload.agentName})
                <icon class="fa-solid fa-reply-all" style="transform: rotateY(174deg); z-index:9999" @click=${(e) => { e.stopPropagation(); e.preventDefault(); this.replayForSupport(e.currentTarget, payload.agentName, payload.interaction, payload.stepId); }}></icon>
                <span class="result"></span>
            </summary>
            ${this.renderAgent(payload)}
            ${payload.interaction ? this.renderInteration(payload.interaction, payload.stepId) : html ``}
            ${payload.nextSteps && payload.nextSteps.length > 0 ? this.renderTaskInteractions(payload.nextSteps) : html ``}  
        </details>`;
    }
    renderInteration(interaction, stepId) {
        return html ` 
            <div class="interactions">
                <div class="cost">
                    ${collab_money} 
                    Cost: ${interaction.cost}
                </div>
                <details>
                    <summary>Inputs</summary>
                    <div>
                        <div class="prompts-content">
                            ${interaction.input.map((result, index) => html `
                                <div class="prompts-input-item">
                                    <span class="prompts-input-type">${result.type}</span>
                                    <span class="prompts-input-content"><pre>${result.content}</pre></span>
                                </details>
                            `)}
                        </div>
                    </div>
                </details>

                <details>
                    <summary>Trace</summary>
                    <div>
                        <div class="trace-content">
                            <pre>${interaction?.trace?.join('\n')}</pre>
                        </div>
                    </div>
                </details>

                ${interaction.payload && interaction.payload.length > 0
            ? html `
                        <details>
                            <summary>Payload</summary>
                            <div>
                                <div class="payload-content">
                                    ${interaction.payload?.map((payl) => { return this.renderPayload(payl); })}
                                </div>
                            </div>
                        </details>`
            : html ``}
                
            </div>`;
    }
    renderAgent(payload) {
        return html `
            <ul>
                <li>agentName: ${payload.agentName}</li>
                <li>stepId: ${payload.stepId}</li>
                <li>prompt: ${payload.prompt}</li>
                <li>status: ${payload.status}</li>
            </ul>
        `;
    }
    renderTool(payload) {
        return html `
            <ul>
                <li>toolName: ${payload.toolName}</li>
                <li>stepId: ${payload.stepId}</li>
                <li>status: ${payload.status}</li>
            </ul>
            <div class="clarification-details">
                <pre>${JSON.stringify(payload)}</pre>
            </div>`;
    }
    renderClarificationDetails(payload) {
        return html `
            <ul>
                <li>templateWidget: ${payload.templateWidget}</li>
                <li>json: ${payload.json}</li>
                <li>stepId: ${payload.stepId}</li>
                <li>status: ${payload.status}</li>
            </ul>
            ${payload.json ? html `<div class="clarification-details"><pre>${JSON.stringify(payload.json)}</pre></div>` : ''}
            `;
    }
    renderFlexible(payload) {
        return html `
            <ul>
                <li>stepId: ${payload.stepId}</li>
                <li>status: ${payload.status}</li>
            </ul>
            <div class="flexible-details">
                <pre>${JSON.stringify(payload)}</pre>
            </div>
            `;
    }
    renderClarification(payload) {
        if (!this.task)
            return html `Invalid task`;
        const parentInteraction = getInteractionStepId(this.task, payload.stepId);
        if (!parentInteraction)
            return html `No found parentInteraction ${payload.stepId} on task: ${this.task.PK} `;
        const interaction = getStepById(this.task, parentInteraction);
        this.interactionClarification = interaction;
        if (!interaction)
            return html `Invalid interaction id:${parentInteraction} on task: ${this.task.PK} `;
        if (!interaction.agentName)
            return html `Invalid agent name for step id:${interaction.stepId} on task: ${this.task.PK} `;
        return html `<div class="content"> Processing...</div>`;
    }
    renderResult(payload) {
        return html `
            <div class="result">
                <pre>${typeof payload.result === 'object' ? JSON.stringify(payload.result) : payload.result}</pre>
            </div>`;
    }
    async setClarification() {
        if (!this.directClarificationContent || !this.task)
            return;
        const clarification = await getClarification(this.task.PK);
        if (!clarification)
            return;
        this.directClarificationContent.innerHTML = '';
        this.directClarificationContent.appendChild(clarification);
        this.executeHTMLClarificationScript();
    }
    executeHTMLClarificationScript() {
        this.directClarification?.querySelectorAll('script').forEach(oldScript => {
            const newScript = document.createElement('script');
            newScript.type = oldScript.type || 'text/javascript';
            if (!newScript.type) {
                newScript.type = 'text/javascript';
            }
            if (oldScript.hasAttribute('type') && oldScript.getAttribute('type') === 'module') {
                newScript.type = 'module';
            }
            if (oldScript.src) {
                newScript.src = oldScript.src;
            }
            else {
                newScript.textContent = oldScript.textContent;
            }
            oldScript.replaceWith(newScript);
        });
    }
    syntaxHighlight(json) {
        if (typeof json !== 'string') {
            json = JSON.stringify(json, null, 2);
        }
        json = json
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        return json.replace(/("(\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*"(?:\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)/g, (match) => {
            let cls = 'json-value';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'json-key';
                }
                else {
                    cls = 'json-string';
                }
            }
            else if (/true|false/.test(match)) {
                cls = 'json-boolean';
            }
            else if (/null/.test(match)) {
                cls = 'json-null';
            }
            return `<span class="${cls}">${match}</span>`;
        });
    }
    async replayForSupport(el, agentName, interaction, stepId) {
        const sum = el?.closest('summary');
        let result;
        if (sum)
            result = sum.querySelector('.result');
        if (result)
            result.innerHTML = '';
        const load = (start) => {
            if (!el)
                return;
            if (start) {
                el.classList.remove('fa-reply-all');
                el.classList.add('rotate');
                el.classList.add('fa-rotate-left');
            }
            else {
                el.classList.remove('fa-rotate-left');
                el.classList.remove('rotate');
                el.classList.add('fa-reply-all');
            }
        };
        try {
            load(true);
            const moduleAgent = await import(`./_${this.PROJECTNUMBER}_${agentName}`);
            if (!moduleAgent || !this.task)
                throw new Error('Not found agent:' + agentName);
            if (!moduleAgent.createAgent)
                throw new Error('Not found createAgent:' + agentName);
            const agent = moduleAgent.createAgent();
            if (!agent.replayForSupport)
                throw new Error('Not found replayForSupport:' + agentName);
            const context = getTemporaryContext(this.task.PK, this.task.owner, 'context temporary');
            context.task = this.task;
            await agent.replayForSupport(context, interaction.payload);
            if (result)
                result.innerText = 'result: Ok';
            load(false);
        }
        catch (e) {
            console.info(e);
            if (result)
                result.innerText = e && e.message ? 'result: ' + e.message : 'result: Erro';
            load(false);
        }
    }
};
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "task", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], WidgetAiInteraction100554.prototype, "seen", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "interactionClarification", void 0);
__decorate([
    query('.direct-clarification')
], WidgetAiInteraction100554.prototype, "directClarification", void 0);
__decorate([
    query('.direct-clarification .content')
], WidgetAiInteraction100554.prototype, "directClarificationContent", void 0);
WidgetAiInteraction100554 = __decorate([
    customElement('collab-messages-task-details-100554')
], WidgetAiInteraction100554);
export { WidgetAiInteraction100554 };
