/// <mls shortName="serviceDsAssetsOverview" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabInputTag } from './_100554_collabInputTag';
/// **collab_i18n_start**
const message_pt = {
    folder: 'Pastas',
    inLocalStorage: 'Em local',
    description: 'Descri��o',
    tags: 'Tags',
    deleteFile: 'Deletar Arquivo',
};
const message_en = {
    folder: 'Folder',
    inLocalStorage: 'In local storage',
    description: 'Description',
    tags: 'Tags',
    deleteFile: 'Delete file',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsAssetsOverview100554 = class ServiceDsAssetsOverview100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.details = {
            icon: '&#xf229',
            state: 'foreground',
            tooltip: 'Assets Overview',
            visible: false,
            position: "right",
            tags: ['ds_assets'],
            widget: '_100554_serviceDsAssetsOverview',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (op === 'opHelper')
                return this.showInitial();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Assets Overview',
            actions: {
                opHelper: 'Assets Overview',
            },
            icons: {},
            actionDefault: 'opHelper', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.state = {
            multiple: false,
            text: '',
            folder: '',
            inLocalStorage: '',
            readOnly: true,
            description: '',
            tags: '',
            actualFileInfo: undefined,
            actualAssetsItem: null
        };
        this.setEvents();
        initCollabInputTag();
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible) {
            this.setData();
            if (el && typeof el.layout === 'function')
                el.layout();
        }
    }
    setEvents() {
        mls.events.addEventListener([this.level], ['DSAssetsUnSelected'], (ev) => {
            this.onDsAssetsUnSelected(ev);
        });
        mls.events.addEventListener([this.level], ['DSAssetsChanged'], (ev) => {
            this.onDsAssetsChanged(ev);
        });
    }
    onDsAssetsUnSelected(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.service.includes('_100554_serviceDsAssetsOverview'))
            return;
        this.showNav2Item(false);
    }
    onDsAssetsChanged(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.position === 'right')
            return;
        if (params.info.helper.includes('_100554_serviceDsAssetsOverview')) {
            this.data = params;
            this.showNav2Item(true);
            this.openMe();
            this.setData();
        }
        else
            this.showNav2Item(false);
    }
    showInitial() {
        this.menu.title = 'Assets Image';
        this.setData();
        return true;
    }
    async setData() {
        if (!this.data)
            return;
        if (!this.data.info.filesSelectedArr)
            return undefined;
        if (this.data.info.filesSelectedArr.length === 0) {
            this.state.text = `No file selected.`;
            this.state.multiple = true;
            this.state.folder = '';
            this.state.inLocalStorage = '';
        }
        else if (this.data.info.filesSelectedArr.length > 1) {
            this.state.multiple = true;
            this.state.inLocalStorage = '';
            this.state.text = `${this.data.info.filesSelectedArr.length} files selected.`;
        }
        else {
            const [file] = this.data.info.filesSelectedArr;
            this.state.actualFileInfo = file;
            this.state.multiple = this.data.info.readOnly;
            this.state.text = file.shortName + file.extension;
            this.state.folder = file.folder;
            this.state.inLocalStorage = file.inLocalStorage.toString();
            await this.prepareStateFile(file);
        }
        this.state.readOnly = this.data.info.readOnly;
        this.requestUpdate();
    }
    async initDs() {
        const { project } = mls.actual[5];
        const { mode } = mls.actual[3];
        if (project === undefined || mode === undefined)
            return;
        this.ds = mls.l3.getDSInstance(project, mode);
        await this.ds.init();
    }
    async prepareStateFile(file) {
        this.state.actualAssetsItem = null;
        this.state.tags = '';
        this.state.description = '';
        await this.initDs();
        if (!this.ds)
            return;
        const fullname = file.shortName + file.extension;
        const assetsItem = this.ds.assets.find(file.folder, fullname);
        if (!assetsItem)
            return;
        this.state.actualAssetsItem = assetsItem;
        this.state.tags = assetsItem.tags ? assetsItem.tags.join(',') : '';
        this.state.description = assetsItem.description;
    }
    handleKeyUp(e) {
        if (!this.ds)
            return;
        const value = e.target.value;
        if (this.state.actualAssetsItem) {
            this.ds.assets.update(this.state.folder, this.state.actualAssetsItem.shortname, this.state.actualAssetsItem.tags, value, this.state.actualAssetsItem.type);
        }
    }
    handleValueChanged(value) {
        if (!this.ds)
            return;
        if (this.state.actualAssetsItem) {
            this.ds.assets.update(this.state.folder, this.state.actualAssetsItem.shortname, value.split(','), this.state.actualAssetsItem.description, this.state.actualAssetsItem.type);
        }
    }
    async handleDelete() {
        if (!this.ds)
            return;
        if (this.state.actualAssetsItem && this.state.actualFileInfo) {
            const deletedFile = this.state.actualFileInfo;
            const params = {
                action: 'delete',
                info: this.data?.info,
                position: 'right'
            };
            await this.ds.assets.remove(this.state.folder, this.state.actualAssetsItem.shortname);
            mls.events.fire(3, 'DSAssetsChanged', JSON.stringify(params), 0);
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <div class="service_assets_overview" >
            <details open="open" >
                <summary>${this.state.text}</summary>
                <ul >
                    <li >
                        <i class="fa-solid fa-folder" ></i>
                        <span >${this.msg.folder}:</span>
                        <span>${this.state.folder}</span>
                    </li>
                    <li ">
                        <i class="fa-solid fa-database" "></i>
                        <span ">${this.msg.inLocalStorage}:</span>
                        <span>${this.state.inLocalStorage}</span>
                    </li>
                </ul>
                <div class="ds_assets_ds_container" style="display:${this.state.multiple ? "none;" : ""}" >
                    <label>${this.msg.description}:</label>
                    <textarea rows="5" @input=${(e) => { this.handleKeyUp(e); }} .value="${this.state.description}"></textarea>
                    <label>${this.msg.tags}:</label>
                    <collab-input-tag-100554 .value=${this.state.tags} .onValueChanged=${(value) => { this.handleValueChanged(value); }} ></collab-input-tag-100554>
                    <div class="actions">
                        <button @click=${() => { this.handleDelete(); }}>${this.msg.deleteFile}</button>
                    </div>
                </div>
            </details>
        </div>`;
    }
};
ServiceDsAssetsOverview100554.styles = css `[[mls_getDefaultDesignSystem]]`;
ServiceDsAssetsOverview100554 = __decorate([
    customElement('service-ds-assets-overview-100554')
], ServiceDsAssetsOverview100554);
export { ServiceDsAssetsOverview100554 };
