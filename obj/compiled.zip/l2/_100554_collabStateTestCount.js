/// <mls shortName="collabStateTestCount" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement, collabState } from './_100554_collabLitElement';
import * as states from './_100554_collabStore';
let MyComponent = class MyComponent extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.count = 0;
    }
    connectedCallback() {
        super.connectedCallback();
        setTimeout(() => {
            this.count += 10; // set count += 10 after 3 sec. 
            super.setCollabState(states.COUNTHITSPAGES, this.count);
        }, 3000);
    }
    render() {
        return html `
      <button @click=${this.increment}>Increment Lit default</button>
      <button @click=${() => super.setCollabState(states.COUNTHITSPAGES, this.count + 1)} style='margin: 2em'>
        Increment CollabState
      </button>
      <div>Count: ${this.count}</div>
    `;
    }
    increment() {
        this.count++;
        // call setCollabState to update state on others
        super.setCollabState(states.COUNTHITSPAGES, this.count);
    }
};
__decorate([
    property({ type: Number }),
    collabState(states.COUNTHITSPAGES)
], MyComponent.prototype, "count", void 0);
MyComponent = __decorate([
    customElement('collab-state-test-count-100554')
], MyComponent);
