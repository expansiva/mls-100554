var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="ateste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
// teste 5
const message_ru = { installPlugin: 'Установить плагин', createNewPlugin: 'Создать новый плагин', backList: 'Вернуться к списку', noPluginsInstalled: 'Плагины не установлены', desactivate: 'Деактивировать', activate: 'Активировать', delete: 'Удалить', reference: 'Справка', noPluginsAvaliables: 'Нет доступных плагинов', install: 'Установить', p1: 'Что такое плагины?', p2: 'Плагины - это фрагменты кода, которые добавляют дополнительные функции в ваш проект. Они разработаны для расширения и улучшения возможностей вашего проекта.', p3: 'Как работают плагины?', p4: 'Когда вы устанавливаете и активируете плагин, он добавляет новые функции или возможности в ваш проект. Плагины могут изменять способ работы вашего проекта, добавляя новые параметры конфигурации, искусственный интеллект, виджеты, короткие коды и другие функции.', p5: 'Где найти плагины?', p6: 'Вы можете найти плагины непосредственно в (L5) вашего проекта, в разделе Сервисы (Services), называемом "Плагины". Здесь вы можете управлять и добавлять новые плагины в свой проект.', p7: 'Как создать плагин?', p8: 'Для создания плагина...', };
let SimpleGreeting = class SimpleGreeting extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-100554 .cls1{font-size:14px;border:1px;clip-path:none;text-shadow:1px 1px;transform:scale(1, 3);column-count:auto;flex:1 1 auto;cursor:pointer;padding:0px;margin:0rem}ateste-100554 .cls1 h1{background-color:var(--bg-primary-color);color:red}ateste-100554.thema2 .cls1{background-color:var(--text-primary-color-lighter-disabled);color:var(--success-color-focus);font-size:12px;border-width:1px}ateste-100554.thema2 .cls1 h1{color:red}ateste-100554.thema2 .cls1 h1:hover{color:yellowgreen}`);
        this.name = new Date(Date.now()).toString();
    }
    createRenderRoot() {
        return this;
    }
    handleConfirm(e) {
        console.info(e.detail);
    }
    render() {
        return html `<div class="cls1"><h1>Hello world Lucas 10</h1></div>`;
    }
};
__decorate([
    property()
], SimpleGreeting.prototype, "name", void 0);
SimpleGreeting = __decorate([
    customElement('ateste-100554')
], SimpleGreeting);
export { SimpleGreeting };
