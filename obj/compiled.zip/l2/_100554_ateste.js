/// <mls shortName="ateste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, when, repeat, classMap, styleMap, ifDefined } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let SimpleGreeting = class SimpleGreeting extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-100554{display:block}ateste-100554 .cls1{font-size:14px;border:1px;clip-path:none;text-shadow:1px 1px;column-count:auto;flex:1 1 auto;cursor:pointer;padding:0px;margin:0rem}ateste-100554 .cls1 h1{background-color:var(--bg-primary-color);color:red}ateste-100554.thema2 .cls1{background-color:var(--text-primary-color-lighter-disabled);color:var(--success-color-focus);font-size:12px;border-width:1px}ateste-100554.thema2 .cls1 h1{color:red}ateste-100554.thema2 .cls1 h1:hover{color:yellowgreen}`);
        this.selectedId = 2;
        this.items = [
            { id: 1, name: 'Banana', color: 'green' },
            { id: 2, name: 'Maçã', color: 'red' },
            { id: 3, name: 'Uva', color: 'purple' },
        ];
    }
    render() {
        console.log('teste 2');
        return html `
    <div>
      <h3>Frutas:</h3>
      <ul>
        ${repeat(this.items, ((item) => item.id), ((item) => {
            const classes = {
                'highlight': item.color === 'green',
                'selected': item.id === this.selectedId,
            };
            const styles = {
                color: item.color,
                cursor: 'pointer',
            };
            return html `
              <li
                class=${classMap(classes)}
                style=${styleMap(styles)}
                title=${ifDefined(item.name)}
                @click=${() => (this.selectedId = item.id)}
              >
                ${item.name}
              </li>
            `;
        }))}
      </ul>

      ${when(this.selectedId !== null, () => html `<p>Selecionado: ${this.getSelectedName()}</p>`, () => html `<p>Nenhuma fruta selecionada.</p>`)}
    </div>
  `;
    }
    getSelectedName() {
        const found = this.items.find(i => i.id === this.selectedId);
        return found ? found.name : '';
    }
};
__decorate([
    property()
], SimpleGreeting.prototype, "selectedId", void 0);
__decorate([
    state()
], SimpleGreeting.prototype, "items", void 0);
SimpleGreeting = __decorate([
    customElement('ateste-100554')
], SimpleGreeting);
export { SimpleGreeting };
