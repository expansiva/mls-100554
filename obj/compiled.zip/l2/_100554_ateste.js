/// <mls shortName="ateste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let SimpleGreeting = class SimpleGreeting extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-100554 .cls1{font-size:14px;border:1px;clip-path:none;text-shadow:1px 1px;transform:scale(1, 3);column-count:auto;flex:1 1 auto;cursor:pointer;padding:0px;margin:0rem}ateste-100554 .cls1 h1{background-color:var(--bg-primary-color);color:red}ateste-100554.thema2 .cls1{background-color:var(--text-primary-color-lighter-disabled);color:var(--success-color-focus);font-size:12px;border-width:1px}ateste-100554.thema2 .cls1 h1{color:red}ateste-100554.thema2 .cls1 h1:hover{color:yellowgreen}`);
        this.tot = 10;
        this.list = [];
    }
    createRenderRoot() {
        return this;
    }
    handleConfirm(e) {
        console.info(e.detail);
    }
    connectedCallback() {
        super.connectedCallback();
        this.prepareList();
    }
    render() {
        return html `
        <ul>
            ${this.list.map((i) => html `<li>${i}</li>`)}
        </ul>
        `;
    }
    /*render() {

        return html`
        <ul>
            ${repeat(this.list, (
                (key: string) => key) as any,
                ((k: any, index: any) => { return html`<li>${k}</li>` }) as any)
            }
        </ul>
        `;
        
    }*/
    prepareList() {
        const newList = [];
        for (let i = 0; i < this.tot; i++) {
            newList.push(i.toString());
        }
        this.list = newList;
    }
};
__decorate([
    property()
], SimpleGreeting.prototype, "tot", void 0);
__decorate([
    property()
], SimpleGreeting.prototype, "list", void 0);
SimpleGreeting = __decorate([
    customElement('ateste-100554')
], SimpleGreeting);
export { SimpleGreeting };
