var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="ateste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import './_100554_ateste2';
/// **collab_i18n_start**
const message_pt = {
    hello2: 'Ola mundo!, teste',
    hello: 'Ola mundo novo!',
};
const messages = {
    'pt': message_pt
};
/// **collab_i18n_end**
let SimpleGreeting = class SimpleGreeting extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-100554{display:block}ateste-100554 .cls1{font-size:14px;border:1px;clip-path:none;text-shadow:1px 1px;column-count:auto;flex:1 1 auto;cursor:pointer;padding:0px;margin:0rem}ateste-100554 .cls1 h1{background-color:var(--bg-primary-color);color:red}ateste-100554.thema2 .cls1{background-color:var(--text-primary-color-lighter-disabled);color:var(--success-color-focus);font-size:12px;border-width:1px}ateste-100554.thema2 .cls1 h1{color:red}ateste-100554.thema2 .cls1 h1:hover{color:yellowgreen}`);
        this.name = new Date(Date.now()).toString();
    }
    handleConfirm(e) {
        console.info(e.detail);
    }
    showGreetingAlert() {
        alert(`Hello world Lucas 10`);
    }
    render() {
        return html `
      <div class="cls1" clb_id="1">
        <h1 clb_id="2">Hello world Lucas ${message_pt.hello} teste 23</h1>
        <button @click="${this.showGreetingAlert}" clb_id="3">Show Greeting</button>
        <ateste2-100554 clb_id="4" name="Guilherme"></ateste2-100554>
        <h1 clb_id="5">${message_pt.hello}</h1>
      </div>
    `;
    }
};
__decorate([
    property()
], SimpleGreeting.prototype, "name", void 0);
SimpleGreeting = __decorate([
    customElement('ateste-100554')
], SimpleGreeting);
export { SimpleGreeting };
