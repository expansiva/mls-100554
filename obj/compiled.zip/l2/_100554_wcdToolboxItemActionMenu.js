/// <mls shortName="wcdToolboxItemActionMenu" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat, unsafeHTML } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import * as icaGlobal from './_100554_icaGlobal';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
/// **collab_i18n_start**
const message_pt = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const message_en = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdToolboxItemActionMenu = class WcdToolboxItemActionMenu extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        this.myMsg = messages['en'];
        //--------CSS------------------------
        this.css = `

        wcd-toolbox-item-action-menu-100554{
            display:block;
            height:17px;
            border:1px solid #d3cece;
            padding:.2rem;
            border-radius:5px;
            position:relative;
            background:#fff;
        }

        wcd-toolbox-itemmenu{
            display:flex;
            height:20px;
            gap:.3rem;
            
        }

        wcd-toolbox-itemmenu a{
            display: flex!important;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size:12px;
            width:18px;
            height:18px;
            
        }

        wcd-toolbox-itemmenu a:hover{
            background:#e1e1e1;
        }

        wcd-toolbox-submenu{
            position:absolute;
            top:19px;
            left:80%;
            display:flex;
            flex-direction: column;
            gap:.3rem;
            min-width: 150px;
            min-height: 50px;
            padding:.5rem;
            border:1px solid var(--bg-secondary-color-darker);
            background:#fff;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            border-top-right-radius: 10px;
            
            background:var(--bg-primary-color-lighter)
        }

        wcd-toolbox-submenu a {
            font-size:13px;
            display:flex;
            gap:.3rem;
            align-items: center;
            padding:.1rem;
            color:var(--text-primary-color);
        }

        wcd-toolbox-submenu a:hover {
            background:var(--grey-color-light);
        }
    `;
        //---------PREDEFINITION--------------
        this.defaultItens = {
            itens: [
                {
                    title: 'To Parent',
                    value: 'goToParents',
                    icon: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M246.6 9.4c-12.5-12.5-32.8-12.5-45.3 0l-128 128c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 109.3V320c0 17.7 14.3 32 32 32s32-14.3 32-32V109.3l73.4 73.4c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-128-128zM64 352c0-17.7-14.3-32-32-32s-32 14.3-32 32v64c0 53 43 96 96 96H352c53 0 96-43 96-96V352c0-17.7-14.3-32-32-32s-32 14.3-32 32v64c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V352z"/></svg>'
                },
            ],
            subItens: [
                {
                    title: 'To Child',
                    value: 'goToFirstChild',
                    icon: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 384 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M350 334.5c3.8 8.8 2 19-4.6 26l-136 144c-4.5 4.8-10.8 7.5-17.4 7.5s-12.9-2.7-17.4-7.5l-136-144c-6.6-7-8.4-17.2-4.6-26s12.5-14.5 22-14.5h88l0-192c0-17.7-14.3-32-32-32H32C14.3 96 0 81.7 0 64V32C0 14.3 14.3 0 32 0l80 0c70.7 0 128 57.3 128 128l0 192h88c9.6 0 18.2 5.7 22 14.5z"/></svg>'
                },
                {
                    title: 'Delete',
                    value: 'removeMe',
                    icon: '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z"/></svg>'
                }
            ]
        };
    }
    //----------COMPONENT---------------
    createRenderRoot() {
        return this;
    }
    updated() {
        try {
            if (!this.args || this.args === '') {
                this.myItens = this.defaultItens;
            }
            else {
                this.myItens = JSON.parse(this.args);
            }
        }
        catch (e) {
            this.myItens = undefined;
        }
    }
    render() {
        if (!this.myItens)
            return html ``;
        return html `
        <style>${this.css}</style>
        <wcd-toolbox-itemmenu>
        ${repeat(this.myItens.itens, ((key, idx) => 'i' + idx), ((item, index) => {
            return this.renderItem(item, index);
        }))}
        ${this.renderSubMenu()}
        </wcd-toolbox-itemmenu>
        <wcd-toolbox-submenu style="display:none">
            ${repeat(this.myItens.subItens, ((key, idx) => 'i' + idx), ((item, index) => {
            return this.renderSubItem(item, index);
        }))}
        </wcd-toolbox-submenu>
            
        `;
    }
    renderItem(item, index) {
        return html `
            <a @click="${this.clickMenu}" .opt="${item.value}">
                <i title="${item.title}">${unsafeHTML(item.icon)}</i>
            </a>
        `;
    }
    renderSubMenu() {
        if (!this.myItens || !this.myItens.subItens || this.myItens.subItens.length === 0)
            return html ``;
        return html `
            <a @click="${this.toggleSubMenu}">
                <i title="SubMenu">
                    <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 128 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
                </i>
            </a>
        `;
    }
    renderSubItem(item, index) {
        return html `
            <a @click="${this.clickSubMenu}" .opt="${item.value}">
                <i title="${item.title}">${unsafeHTML(item.icon)}</i>
                <span>${item.title}</span>
            </a>
        `;
    }
    //-----------IMPLEMENTATION-----------
    clickMenu(e) {
        e.stopPropagation();
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'a')
            el = el.closest('a');
        if (!el)
            return;
        if (this.args === '' || !this.args) {
            this.goToDefaultActions(el.opt);
            return;
        }
        if (this.elICA && this.elICA.clickMenu)
            this.elICA.clickMenu(el.opt);
    }
    clickSubMenu(e) {
        e.stopPropagation();
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'a')
            el = el.closest('a');
        if (!el)
            return;
        if (!this.containerSubMenu)
            return;
        this.containerSubMenu.style.display = 'none';
        if (this.args === '' || !this.args) {
            this.goToDefaultActions(el.opt);
            return;
        }
        if (this.elICA && this.elICA.clickMenu)
            this.elICA.clickMenu(el.opt);
    }
    toggleSubMenu(e) {
        if (!this.containerSubMenu)
            return;
        this.containerSubMenu.style.display = this.containerSubMenu.style.display === '' ? 'none' : '';
    }
    goToDefaultActions(opt) {
        switch (opt) {
            case 'goToParents':
                this.goToParent();
                break;
            case 'goToFirstChild':
                this.goToFirstChild();
                break;
            case 'removeMe':
                this.removeMe();
                break;
            default: '';
        }
    }
    goToParent() {
        const toParent = (el) => {
            let parent = el.parentElement;
            if (!parent)
                parent = el.getRootNode() ? el.getRootNode().host : null;
            if (!parent)
                return;
            const tag = parent.tagName.toLowerCase();
            if (!tag.startsWith(`${icaGlobal.PREFIX}-`))
                toParent(parent);
            else if (tag.startsWith(`${icaGlobal.PREFIX}-`)) {
                const overlayItem = parent.overlayRef;
                if (!overlayItem)
                    return;
                overlayItem.click();
            }
        };
        if (!this.elICA)
            return;
        toParent(this.elICA);
    }
    goToFirstChild() {
        const toFirstChild = (el) => {
            if (el.children.length === 0)
                return;
            const findNextIca = (childrens) => {
                const child = childrens.find((item => item.tagName.toLowerCase().startsWith(`${icaGlobal.PREFIX}-`)));
                if (!child) {
                    for (let ch of childrens) {
                        const arrChildren = (Array.from(ch.shadowRoot ? ch.shadowRoot.children : ch.children));
                        let next = findNextIca(arrChildren);
                        if (!next)
                            continue;
                        return next;
                    }
                }
                return child;
            };
            const arrChildren = (Array.from(el.shadowRoot ? el.shadowRoot.children : el.children));
            const nextIca = findNextIca(arrChildren);
            if (!nextIca)
                return;
            const overlayItem = nextIca.overlayRef;
            if (!overlayItem)
                return;
            overlayItem.click();
        };
        if (!this.elICA)
            return;
        toFirstChild(this.elICA);
    }
    removeMe() {
        if (!this.elICA)
            return;
        this.elICA.overlayRef?.remove();
        this.elICA.remove();
    }
};
__decorate([
    property({ reflect: true })
], WcdToolboxItemActionMenu.prototype, "myItens", void 0);
__decorate([
    query('wcd-toolbox-submenu')
], WcdToolboxItemActionMenu.prototype, "containerSubMenu", void 0);
WcdToolboxItemActionMenu = __decorate([
    customElement('wcd-toolbox-item-action-menu-100554')
], WcdToolboxItemActionMenu);
export { WcdToolboxItemActionMenu };
