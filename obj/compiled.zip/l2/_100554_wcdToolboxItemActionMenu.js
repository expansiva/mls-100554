/// <mls shortName="wcdToolboxItemActionMenu" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
import { convertFileNameToTag } from './_100554_utilsLit';
let WcdToolboxItemActionMenu = class WcdToolboxItemActionMenu extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        this.isLoad = [];
        //--------CSS------------------------
        this.css = `

        wcd-toolbox-item-action-menu-100554{
            display:block;
            height:17px;
            border:1px solid #d3cece;
            padding:.2rem;
            border-radius:5px;
            background:#fff;
        }

        wcd-toolbox-itemmenu{
            display:flex;
            height:20px;
            gap:.3rem;
            
        }

        

        wcd-toolbox-itemmenu a:hover{
            background:#e1e1e1;
        }

        
    `;
    }
    //----------COMPONENT---------------
    createRenderRoot() {
        return this;
    }
    render() {
        this.setMyArgs();
        if (!this.myInfos || this.myInfos.itens === undefined)
            return html ``;
        this.style.zIndex = '9999';
        return html `
        <style>${this.css}</style>
        <wcd-toolbox-itemmenu>
            ${repeat(this.myInfos.itens, ((key, idx) => 'i' + idx), ((item, index) => {
            return this.renderItem(item, index);
        }))}
        </wcd-toolbox-itemmenu>
            
        `;
    }
    renderItem(item, index) {
        const tag = this.loadItemAndReturnTag(item.item);
        return html `
            <${tag} .args=${item.arg}>
            </${tag}>
        `;
    }
    //-----------IMPLEMENTATION-----------
    setMyArgs() {
        try {
            if (this.args && this.args !== '') {
                this.myInfos = JSON.parse(this.args);
            }
        }
        catch (e) {
            this.myInfos = undefined;
        }
    }
    async loadItemAndReturnTag(file) {
        try {
            if (this.isLoad.includes(file))
                return '';
            if (!file.startsWith('./'))
                file = './' + file;
            await import(file);
            return convertFileNameToTag(file.replace('./', ''));
        }
        catch (e) {
            return '';
        }
    }
};
WcdToolboxItemActionMenu = __decorate([
    customElement('wcd-toolbox-item-action-menu-100554')
], WcdToolboxItemActionMenu);
export { WcdToolboxItemActionMenu };
