/// <mls shortName="wcdToolboxItemActionMenu" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
import { convertFileNameToTag } from './_100554_utilsLit';
let WcdToolboxItemActionMenu = class WcdToolboxItemActionMenu extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.isLoad = [];
        //--------CSS------------------------
        this.css = `

        wcd-toolbox-item-action-menu-100554{
            display:block;
            border:1px solid #d3cece;
            padding:.3rem;
            border-radius:5px;
            background:#fff;
        }

        wcd-toolbox-items-menu{
            display:flex;
            height:18px;
            gap: .5rem;
            justify-content: center;
            align-items: center;
            
        }

        wcd-toolbox-item-menu{
            height: 18px;
            padding: .2rem;
            display: flex;
            justify-content: center;
            align-items: center;
            
        }

        wcd-toolbox-item-menu:hover{
            background:#e1e1e1;
        }

        
    `;
    }
    //----------COMPONENT---------------
    createRenderRoot() {
        return this;
    }
    render() {
        this.setMyArgs();
        if (!this.myInfos || this.myInfos.itens === undefined)
            return html ``;
        setTimeout(() => { this.loadItens(); }, 200);
        this.style.zIndex = '9999';
        return html `
        <style>${this.css}</style>
        <wcd-toolbox-items-menu>
        </wcd-toolbox-items-menu>
            
        `;
    }
    //-----------IMPLEMENTATION-----------
    setMyArgs() {
        try {
            if (this.args && this.args !== '') {
                this.myInfos = JSON.parse(this.args);
            }
        }
        catch (e) {
            this.myInfos = undefined;
        }
    }
    async loadItens() {
        if (!this.myInfos || this.myInfos.itens === undefined)
            return;
        for await (const item of this.myInfos.itens) {
            await this.loadItem(item);
        }
    }
    async loadItem(item) {
        try {
            if (!item.item.startsWith('_') || !item.level || (this.myParent && this.myParent.level && !item.level.includes(+this.myParent.level)))
                return;
            let file = item.item;
            if (!this.isLoad.includes(file)) {
                if (!file.startsWith('./'))
                    file = './' + file;
                await import(file);
            }
            const tag = convertFileNameToTag(item.item);
            const el = document.createElement(tag);
            el.args = item.args;
            el.style.cssText = `
                border:none!important;
                border-radius:0px!important; 
                background:transparent!important;
            `;
            const f = document.createElement('wcd-toolbox-item-menu');
            f.appendChild(el);
            if (this.elItens)
                this.elItens.appendChild(f);
        }
        catch (e) {
            return '';
        }
    }
};
__decorate([
    query('wcd-toolbox-items-menu')
], WcdToolboxItemActionMenu.prototype, "elItens", void 0);
WcdToolboxItemActionMenu = __decorate([
    customElement('wcd-toolbox-item-action-menu-100554')
], WcdToolboxItemActionMenu);
export { WcdToolboxItemActionMenu };
