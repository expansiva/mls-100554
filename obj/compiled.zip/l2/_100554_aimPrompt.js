/// <mls shortName="aimPrompt" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { collab_arrow_up_long } from './_100554_collabIcons';
import { StateLitElement } from './_100554_stateLitElement';
import './_100554_aimPromptExample';
const message_pt = {
    btnSend: 'Enviar',
    placeHolder: 'Digite sua pergunta...'
};
const message_en = {
    btnSend: 'Send',
    placeHolder: 'Enter your question...'
};
const message_fr = {
    btnSend: 'Envoyer',
    placeHolder: 'Entrez votre question...'
};
const messages = {
    'en': message_en,
    'pt': message_pt,
    'fr': message_fr
};
let AimPrompt = class AimPrompt extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aim-prompt-100554 .aim-prompt-search-container{display:flex;align-items:center;background-color:var(--grey-color-light);padding:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1);border-radius:12px}aim-prompt-100554 .aim-prompt-search-input{padding:10px 15px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;width:100%;border-radius:8px;outline:none}aim-prompt-100554 .aim-prompt-search-input:focus{border-color:#0078d4}aim-prompt-100554 .search-button{margin-left:8px;padding:10px 12px;border:none;border-radius:9999px;background-color:#ddd;color:#fff;font-size:16px;cursor:pointer;transition:background-color .3s ease}aim-prompt-100554 .search-button:hover{background-color:#005bb5}aim-prompt-100554 .search-button:disabled{background-color:#e0e0e0;cursor:not-allowed}`);
        this.msg = messages['en'];
        this.text = "";
        this.dataForDetails = {
            project: 100554,
            shortName: 'aimPrompt'
        };
        this.EVENTPROMPTNAME = "promptChange";
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="aim-prompt-search-container">
                <textarea
                    rows="1"
                    autocomplete="off"
                    .value="${this.text}"
                    placeholder="${this.msg.placeHolder}"
                    class="aim-prompt-search-input"
                    id="searchInput"
                    @focus="${this.handleFocus}"
                    @input="${this.handleInput}"
                ></textarea>
                <button class="search-button" @click="${this.handleClick}">
                ${collab_arrow_up_long}</button>
            </div>`;
    }
    handleClick() {
        const textarea = this.parentElement?.querySelector("#searchInput");
        if (!textarea)
            throw new Error('field searchInput not found');
        const url = this.getModelFromLastPromptDetails()?.uri.toString() || '';
        window.parent.postMessage(JSON.stringify({
            eventName: this.EVENTPROMPTNAME,
            url,
            text: textarea.value
        }), window.parent.location.origin);
    }
    firstUpdated() {
        this.listenPromptChange();
    }
    listenPromptChange() {
        window.addEventListener("message", (event) => {
            if ((event.origin !== window.location.origin) ||
                (typeof event.data !== 'string') ||
                (!event.data.includes(this.EVENTPROMPTNAME)))
                return;
            try {
                const receivedData = JSON.parse(event.data);
                event.preventDefault();
                this.exePrompt(receivedData.text || '', receivedData.url || '');
            }
            catch (e) {
                console.warn("invalid message:", event.data);
            }
        }, false);
    }
    exePrompt(prompt, url) {
        if (!url || !url.startsWith('file://server/'))
            throw new Error('invalid exec prompt url:' + url);
        if (!prompt || !prompt.trim())
            return;
        const uri = new monaco.Uri();
        const model = monaco.editor.getModel(monaco.Uri.parse(url));
        if (!model)
            throw new Error('model not found, url=' + url);
        const language = model.getLanguageId();
        const text = model.getValue();
        console.log('prompt2: ', prompt, ", url:", url, ", language:", language, ", text len:", text.length);
    }
    isInIframe() {
        return window.self !== window.top;
    }
    isInDetail() {
        let element = this;
        while (element.parentElement) {
            element = element.parentElement;
            if (element.tagName.toLowerCase() === 'service-detail-100554') {
                return true;
            }
        }
        return false;
    }
    handleFocus(event) {
        if (this.isInIframe() || this.isInDetail())
            return;
        this.setLastPromptDetails();
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(this.dataForDetails));
    }
    handleInput(event) {
        const textarea = event.target;
        this.text = textarea.value;
        textarea.style.height = 'auto';
        textarea.style.height = `${textarea.scrollHeight}px`;
    }
    handleCollabStateChange(changedKey, value) {
        if (changedKey === "aimPrompt_text") {
            console.log('handleCollabStateChange', value);
            this.text = value;
        }
    }
    setLastPromptDetails() {
        var _a;
        console.log('setLastPromptDetails');
        const globalState = (_a = window.parent).globalState || (_a.globalState = {});
        const service = globalState.service || (globalState.service = {});
        const aimPrompt = service.aimPrompt || (service.aimPrompt = {});
        const w = window.parent;
        const m = w.mls;
        aimPrompt.actualLevel = m.actualLevel;
        aimPrompt.actualPosition = m.actualPosition;
        aimPrompt.actualService = m.actualService;
        aimPrompt.actualNav3 = m.actualNav3;
        const a = m.actual[m.actualLevel];
        aimPrompt.fileRef = `_${a.project}_${a.path}`;
    }
    getModelFromLastPromptDetails() {
        const key = window.parent.globalState?.service?.aimPrompt?.fileRef;
        if (!key)
            throw new Error('invalid globalState last prompt details, fileRef');
        const nav3 = window.parent.globalState?.service?.aimPrompt?.actualNav3;
        if (!nav3)
            throw new Error('invalid globalState last prompt details, nav3');
        const m = window.parent.mls.editor.models[key];
        if (!m)
            throw new Error('invalid globalState, model doesn\'t exist');
        if (nav3 === "Typescript")
            return m.ts?.model;
        if (nav3 === "HTML")
            return m.html?.model;
        if (nav3 === "Style")
            return m.style?.model;
        return undefined;
    }
};
AimPrompt.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property({ type: "string", reflect: true })
], AimPrompt.prototype, "text", void 0);
AimPrompt = __decorate([
    customElement('aim-prompt-100554')
], AimPrompt);
export { AimPrompt };
