/// <mls shortName="aimPrompt" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { collab_arrow_up_long } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    btnSend: 'Enviar',
    placeHolder: 'Digite sua pergunta...'
};
const message_en = {
    btnSend: 'Send',
    placeHolder: 'Enter your question...'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabInputTag = class CollabInputTag extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<div class="aim-prompt-search-container">
                <input
                    type="text"
                    autocomplete="off"
                    placeholder=${this.msg.placeHolder}
                    class="aim-prompt-search-input"
                    id="searchInput"
                />
                <button class="search-button">${collab_arrow_up_long}</button>
            </div>`;
    }
};
CollabInputTag.styles = css `
        .aim-prompt-search-container {
            display: flex;
            align-items: center;
            background-color: var(--grey-color-light);
            padding: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .aim-prompt-search-input {
            padding: 10px 15px;
            border: none;
            background-color: var(--grey-color-light);
            font-size: 16px;
            outline: none;
            transition: background-color 0.3s ease;
            width:100%;
        }

        .search-button {
            margin-left: 10px;
            padding: 10px 12px;
            border: none;
            border-radius: 9999px;
            background-color: #000;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .search-button svg{
            fill: #fff;
        }

        .aim-prompt-search-input:not(:placeholder-shown) + .search-button:hover{
            opacity:.6;
        }

        .aim-prompt-search-input:placeholder-shown + .search-button {
            background-color: var(--grey-color-darker); 
            cursor: not-allowed;
        }
    
    `;
CollabInputTag = __decorate([
    customElement('aim-prompt-100554')
], CollabInputTag);
export { CollabInputTag };
