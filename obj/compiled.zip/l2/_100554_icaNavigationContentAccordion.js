/// <mls shortName="icaNavigationContentAccordion" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { IcaLitElementBase } from './_100554_icaLitElementBase';
let IcaNavigationContentAccordion = class IcaNavigationContentAccordion extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.mySymbol = 'fa-bars';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
    changeStateHtml(html) {
    }
    allowCommand(cmd, scope, target) {
        if (cmd === 'move')
            return this.commandMove(scope, target);
        return { inside: false, before: false, after: false };
    }
    commandMove(scope, target) {
        return { inside: false, before: false, after: false };
    }
};
IcaNavigationContentAccordion = __decorate([
    customElement('ica-navigation-content-accordion-100554')
], IcaNavigationContentAccordion);
export { IcaNavigationContentAccordion };
