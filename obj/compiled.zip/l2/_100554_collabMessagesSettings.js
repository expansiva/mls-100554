/// <mls shortName="collabMessagesSettings" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_user, collab_minus, collab_ban, collab_dot } from './_100554_collabIcons';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    save: 'Salvar',
    status: 'Status',
    userid: 'Id do usuário',
    username: 'Nome do usuário',
    errorUserName: 'Nome do usuário não pode ser vazio',
    successSaving: 'Perfil do usuário atualizado com sucesso'
};
const message_en = {
    loading: 'Loading...',
    save: 'Save',
    status: 'Status',
    userid: 'User Id',
    username: 'UserName',
    errorUserName: 'User name cannot be empty',
    successSaving: 'User perfil updated successfully'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesSettings100554 = class CollabMessagesSettings100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-100554{display:block;overflow:auto;font-family:'Charlie Display',-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;font-size:calc(.25rem * 4);font-weight:400;line-height:1.5;color:#403f3f;background-color:#ffffff;padding:1rem}collab-messages-settings-100554 .user{background-color:#ffffff;padding:2rem .75rem;border-radius:10px;box-shadow:rgba(0,0,0,0.16) 0 1px 4px}collab-messages-settings-100554 .user .saving-ok{color:#52C41A;font-size:calc(.25rem * 3)}collab-messages-settings-100554 .user .saving-error{color:#FF4D4F;font-size:calc(.25rem * 3)}collab-messages-settings-100554 .user .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-settings-100554 .user input,collab-messages-settings-100554 .user select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;height:25px}collab-messages-settings-100554 .user button{background-color:#0a6dc9;border-radius:8px;border:none;box-shadow:0 1px 3px 0 #E6E6E6;display:inline-flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}collab-messages-settings-100554 .user button:hover{background-color:#1b7edb}collab-messages-settings-100554 .user .user-info{width:100%}collab-messages-settings-100554 .user .user-details{display:flex;align-items:center;gap:1rem}collab-messages-settings-100554 .user .user-info-item{margin-bottom:.4rem;display:flex;align-items:center}collab-messages-settings-100554 .user .user-info-item label{display:inline;margin-right:.6rem;font-weight:700}collab-messages-settings-100554 .user .user-info-item.action{display:flex;justify-content:end}collab-messages-settings-100554 .user .user-info-item.status>span{display:flex;align-items:center;gap:.5rem}collab-messages-settings-100554 .user .user-info-item.status .blocked svg{color:#FF4D4F;fill:#FF4D4F}collab-messages-settings-100554 .user .user-info-item.status .active svg{color:#52C41A;fill:#52C41A}collab-messages-settings-100554 .user img{width:80px;height:80px;border-radius:50%;object-fit:cover}collab-messages-settings-100554 .user .avatar{display:flex;flex-direction:column;gap:.4rem;align-items:center;width:150px}collab-messages-settings-100554 .user .avatar .avatar-placeholder{width:80px;height:80px;border-radius:50%;background-color:#ccc;display:flex;align-items:center;justify-content:center;font-size:40px;color:white;cursor:pointer}collab-messages-settings-100554 .user .avatar .avatar-placeholder svg{width:30px;height:50px}`);
        this.msg = messages['en'];
        this.labelOk = '';
        this.labelError = '';
        this.isSaving = false;
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
        this.userPerfil = await this.getUserPerfil();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const avatarUrl = this.userPerfil?.avatar_url;
        const iconByStatus = {
            'active': collab_dot,
            'deleted': collab_minus,
            'blocked': collab_ban,
            '': html ``,
        };
        const icon = iconByStatus[this.userPerfil?.status || ''];
        return html `
      <div >
        <h4>User</h4>
        <div class="user">
          <div class="user-details">
            <div class="avatar">
                ${avatarUrl
            ? html `<img src="${avatarUrl}" alt="Avatar" />`
            : html `<div class="avatar-placeholder">${collab_user}</div>`}
                <a @click=${(e) => { e.preventDefault(); this.refreshAvatar(); }} href="#"> Atualizar</a>
            </div>
            <div  class="user-info">
                <div class="user-info-item">
                    <label>${this.msg.username}</label>
                    <input .value=${this.userPerfil?.name ?? ''} type="text" />
                </div>
                <div class="user-info-item">
                    <label>${this.msg.userid}</label>
                    <span> ${this.userPerfil?.userId ?? ''}  </span>
                </div>
                <div class="user-info-item status">
                    <label>${this.msg.status}</label>
                    <span class=${this.userPerfil?.status}> ${this.userPerfil?.status ?? 'N/A'} ${icon} </span>
                </div>
            
            </div>
        </div>
            <div class="user-info-item action">
                <button
                    @click=${this.handleSave}
                    ?disabled=${this.isSaving}
                >
                    ${this.isSaving ? html `<span class="loader"></span>` : this.msg.save}
                </button>
            </div>
            ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}<small>` : ''}
            ${this.labelError ? html `<small class="saving-error">${this.labelError}<small>` : ''}      
      </div>
    `;
    }
    refreshAvatar() {
        const collabInit = document.querySelector('collab-init-100554');
        if (!collabInit)
            return;
        const url = collabInit.getAttribute('avatarUrl');
        if (url && this.userPerfil) {
            this.userPerfil.avatar_url = url;
            this.requestUpdate();
        }
    }
    async getUserPerfil() {
        try {
            const response = await mls.api.msgGetUserUpdate({ userId: "" });
            console.info(response);
            return response.user;
        }
        catch (err) {
            this.serviceBase?.setError(err.message);
            throw new Error(err.message);
        }
    }
    async handleSave() {
        this.labelError = '';
        this.labelOk = '';
        if (!this.userPerfil || !this.userPerfil?.name) {
            this.labelError = this.msg.errorUserName;
            return;
        }
        this.isSaving = true;
        try {
            const response = await mls.api.msgUpdateUserDetails({
                userId: this.userPerfil.userId,
                avatar_url: this.userPerfil.avatar_url,
                name: this.userPerfil.name,
                status: this.userPerfil.status
            });
            if (response.statusCode !== 200) {
                this.labelError = `${response.msg}`;
                this.isSaving = false;
                return;
            }
            this.labelOk = `${this.msg.successSaving}`;
            this.isSaving = false;
        }
        catch (error) {
            console.error('Error on update perfil:', error);
            this.labelError = error.message;
            this.isSaving = false;
        }
    }
};
__decorate([
    state()
], CollabMessagesSettings100554.prototype, "userPerfil", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "labelOk", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "labelError", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "isSaving", void 0);
__decorate([
    query('.avatar img')
], CollabMessagesSettings100554.prototype, "userAvatarEl", void 0);
CollabMessagesSettings100554 = __decorate([
    customElement('collab-messages-settings-100554')
], CollabMessagesSettings100554);
export { CollabMessagesSettings100554 };
