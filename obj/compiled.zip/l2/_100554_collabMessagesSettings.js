/// <mls shortName="collabMessagesSettings" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { loadChatPreferences, saveChatPreferences } from './_100554_collabMessageHelper';
import { collab_user, collab_minus, collab_ban, collab_dot, collab_message } from './_100554_collabIcons';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    save: 'Salvar',
    status: 'Status',
    userid: 'Id do usuário',
    username: 'Nome do usuário',
    errorUserName: 'Nome do usuário não pode ser vazio',
    successSavingUser: 'Perfil do usuário atualizado com sucesso',
    successSavingChatPref: 'Preferências do chat atualizado com sucesso',
    chatPref: 'Preferências do chat',
    translate: 'Tradução',
    preferLanguage: 'Idioma preferido',
    userTitle: 'Usuário',
};
const message_en = {
    loading: 'Loading...',
    save: 'Save',
    status: 'Status',
    userid: 'User Id',
    username: 'UserName',
    errorUserName: 'User name cannot be empty',
    successSavingUser: 'User perfil updated successfully',
    successSavingChatPref: 'Chat preferences updated successfully',
    chatPref: 'Chat Preferences',
    translate: 'Translate',
    preferLanguage: 'Preferred language',
    userTitle: 'User',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabMessagesSettings100554 = class CollabMessagesSettings100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-settings-100554{display:block;overflow:auto;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding:1rem}collab-messages-settings-100554 .section{background-color:var(--bg-primary-color-lighter);padding:2rem .75rem;border-radius:10px;box-shadow:rgba(0,0,0,0.16) 0 1px 4px;margin-bottom:3rem}collab-messages-settings-100554 .section .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}collab-messages-settings-100554 .section .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}collab-messages-settings-100554 .section .saving-error{color:var(--error-color);font-size:var(--font-size-12)}collab-messages-settings-100554 .section input,collab-messages-settings-100554 .section select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;height:25px}collab-messages-settings-100554 .section button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:inline-flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}collab-messages-settings-100554 .section button:hover{background-color:var(--info-color-hover)}collab-messages-settings-100554 .user .user-info{width:100%}collab-messages-settings-100554 .user .user-details{display:flex;align-items:center;gap:1rem}collab-messages-settings-100554 .user .user-info-item{margin-bottom:.4rem;display:flex;align-items:center}collab-messages-settings-100554 .user .user-info-item label{display:inline;margin-right:.6rem;font-weight:var(--font-weight-bold)}collab-messages-settings-100554 .user .user-info-item.action{display:flex;justify-content:end}collab-messages-settings-100554 .user .user-info-item.status>span{display:flex;align-items:center;gap:.5rem}collab-messages-settings-100554 .user .user-info-item.status .blocked svg{color:var(--error-color);fill:var(--error-color)}collab-messages-settings-100554 .user .user-info-item.status .active svg{color:var(--success-color);fill:var(--success-color)}collab-messages-settings-100554 .user img{width:80px;height:80px;border-radius:50%;object-fit:cover}collab-messages-settings-100554 .user .avatar{display:flex;flex-direction:column;gap:.4rem;align-items:center;width:150px}collab-messages-settings-100554 .user .avatar .avatar-placeholder{width:80px;height:80px;border-radius:50%;background-color:#ccc;display:flex;align-items:center;justify-content:center;font-size:40px;color:white;cursor:pointer}collab-messages-settings-100554 .user .avatar .avatar-placeholder svg{width:30px;height:50px}collab-messages-settings-100554 .chat-preferences .chat-config-item{display:flex;flex-direction:column;gap:.3rem;margin-bottom:1rem}collab-messages-settings-100554 .chat-preferences .chat-config-item.action{display:flex;justify-content:end;align-items:end}collab-messages-settings-100554 .chat-preferences .chat-config-item label{display:inline-flex;margin-right:.6rem;font-weight:var(--font-weight-bold);align-items:center}`);
        this.msg = messages['en'];
        this.chatPreferences = {
            translationMode: 'icon',
            language: ''
        };
        this.labelOk = '';
        this.labelError = '';
        this.labelOkPref = '';
        this.labelErrorPref = '';
        this.isSavingUser = false;
        this.isSavingChat = false;
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
        this.userPerfil = await this.getUserPerfil();
        this.chatPreferences = loadChatPreferences();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderUser()}
            ${this.renderChatPreferences()}
        `;
    }
    renderUser() {
        const avatarUrl = this.userPerfil?.avatar_url;
        const iconByStatus = {
            'active': collab_dot,
            'deleted': collab_minus,
            'blocked': collab_ban,
            '': html ``,
        };
        const icon = iconByStatus[this.userPerfil?.status || ''];
        return html `
         <div >
        <h4>${collab_user} ${this.msg.userTitle}</h4>
        <div class="section user">
          <div class="user-details">
            <div class="avatar">
                ${avatarUrl
            ? html `<img src="${avatarUrl}" alt="Avatar" />`
            : html `<div class="avatar-placeholder">${collab_user}</div>`}
                <a @click=${(e) => { e.preventDefault(); this.refreshAvatar(); }} href="#"> Atualizar</a>
            </div>
            <div class="user-info">
                <div class="user-info-item">
                    <label>${this.msg.username}</label>
                    <input
                        .value=${this.userPerfil?.name ?? ''} 
                        type="text" 
                        @input=${this.handleNameInput}
                    />
                </div>
                <div class="user-info-item">
                    <label>${this.msg.userid}</label>
                    <span> ${this.userPerfil?.userId ?? ''}  </span>
                </div>
                <div class="user-info-item status">
                    <label>${this.msg.status}</label>
                    <span class=${this.userPerfil?.status}> ${this.userPerfil?.status ?? 'N/A'} ${icon} </span>
                </div>
            
            </div>
        </div>
            <div class="user-info-item action">
                <button
                    @click=${this.handleSave}
                    ?disabled=${this.isSavingUser}
                >
                    ${this.isSavingUser ? html `<span class="loader"></span>` : this.msg.save}
                </button>
            </div>
            ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}<small>` : ''}
            ${this.labelError ? html `<small class="saving-error">${this.labelError}<small>` : ''}      
      </div>
        
        `;
    }
    renderChatPreferences() {
        return html `
    <div>
        <h4>${collab_message} ${this.msg.chatPref}</h4>
        <div class="section chat-preferences">

            <div class="chat-config-item">
                <label for="translationMode">${this.msg.translate}:</label>
                <select
                    id="translationMode"
                    @change=${this.handleTranslationModeChange}
                    .value=${this.chatPreferences?.translationMode ?? 'icon'}
                >
                    <option value="none">none</option>
                    <option value="icon">icon</option>
                    <option value="text">text</option>
                    <option value="iconText">icon + text</option>
                </select>
            </div>
            <div class="chat-config-item">
                <label>${this.msg.preferLanguage}:</label>
                <input
                    @input=${this.handleLanguageInput}
                    .value=${this.chatPreferences?.language ?? ''}
                    type="text"
                />
            </div>
            <div class="chat-config-item action">
                <button
                    @click=${this.handleSaveChatPref}
                    ?disabled=${this.isSavingChat}
                >
                    ${this.isSavingChat ? html `<span class="loader"></span>` : this.msg.save}
                </button>
            </div>
            ${this.labelOkPref ? html `<small class="saving-ok">${this.labelOkPref}<small>` : ''}
            ${this.labelErrorPref ? html `<small class="saving-error">${this.labelErrorPref}<small>` : ''}    
        </div>
    </div>`;
    }
    refreshAvatar() {
        const collabInit = document.querySelector('collab-init-100554');
        if (!collabInit)
            return;
        const url = collabInit.getAttribute('avatarUrl');
        if (url && this.userPerfil) {
            this.userPerfil.avatar_url = url;
            this.requestUpdate();
        }
    }
    async getUserPerfil() {
        try {
            const response = await mls.api.msgGetUserUpdate({ userId: "" });
            console.info(response);
            return response.user;
        }
        catch (err) {
            this.serviceBase?.setError(err.message);
            throw new Error(err.message);
        }
    }
    async handleSave() {
        this.labelError = '';
        this.labelOk = '';
        if (!this.userPerfil || !this.userPerfil?.name) {
            this.labelError = this.msg.errorUserName;
            return;
        }
        this.isSavingUser = true;
        try {
            const response = await mls.api.msgUpdateUserDetails({
                userId: this.userPerfil.userId,
                avatar_url: this.userPerfil.avatar_url,
                name: this.userPerfil.name,
                status: this.userPerfil.status
            });
            if (response.statusCode !== 200) {
                this.labelError = `${response.msg}`;
                this.isSavingUser = false;
                return;
            }
            this.labelOk = `${this.msg.successSavingUser}`;
            this.isSavingUser = false;
        }
        catch (error) {
            console.error('Error on update perfil:', error);
            this.labelError = error.message;
            this.isSavingUser = false;
        }
    }
    async handleSaveChatPref() {
        this.labelErrorPref = '';
        this.labelOkPref = '';
        this.isSavingChat = true;
        try {
            saveChatPreferences(this.chatPreferences);
            this.labelOkPref = `${this.msg.successSavingChatPref}`;
            this.isSavingChat = false;
        }
        catch (error) {
            console.error('Error on update chat preferences:', error);
            this.labelErrorPref = error.message;
            this.isSavingChat = false;
        }
    }
    handleTranslationModeChange(e) {
        const select = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            translationMode: select.value
        };
    }
    handleLanguageInput(e) {
        const target = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            language: target.value
        };
    }
    handleNameInput(e) {
        if (!this.userPerfil)
            return;
        const target = e.target;
        this.userPerfil.name = target.value;
    }
};
__decorate([
    state()
], CollabMessagesSettings100554.prototype, "userPerfil", void 0);
__decorate([
    state()
], CollabMessagesSettings100554.prototype, "chatPreferences", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "labelOk", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "labelError", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "labelOkPref", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "labelErrorPref", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "isSavingUser", void 0);
__decorate([
    property()
], CollabMessagesSettings100554.prototype, "isSavingChat", void 0);
__decorate([
    query('.avatar img')
], CollabMessagesSettings100554.prototype, "userAvatarEl", void 0);
CollabMessagesSettings100554 = __decorate([
    customElement('collab-messages-settings-100554')
], CollabMessagesSettings100554);
export { CollabMessagesSettings100554 };
