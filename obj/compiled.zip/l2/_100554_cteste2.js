/// <mls shortName="cteste2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
let Cteste2100554 = class Cteste2100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
    }
    /// **collab_events_start**
    handleClickbuttonSum() {
        // here or code for event
    }
};
Cteste2100554 = __decorate([
    customElement('cteste2-100554')
], Cteste2100554);
export { Cteste2100554 };
