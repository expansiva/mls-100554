/// <mls shortName="aimTaskDsTokens" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { getInfoMyService } from "./_100554_aimHelper";
import { AimTaskBase } from "./_100554_aimTaskBase";
let AimTaskDsTokens = class AimTaskDsTokens extends AimTaskBase {
    onInitializing() {
        this.getSource();
    }
    getSource() {
        this.getTokens().then((ret) => {
            const result = ret;
            this.notifyCompleteByStatus('ok', result);
        }).catch((e) => {
            this.notifyCompleteByStatus('error', e);
        });
    }
    getTokens() {
        return new Promise(async (resolve, reject) => {
            try {
                const info = getInfoMyService(this);
                if (!info) {
                    reject('Not found info in getFileStyle');
                    return;
                }
                const activeServiceOp = info.actServiceOp;
                if (activeServiceOp.tagName !== 'SERVICE-DS-TOKENS-100554')
                    reject('100554_ServiceDsTokens is not active in level 3');
                const val = activeServiceOp.getEditorSource();
                this.taskChild.ref = activeServiceOp.getActualRef() || '';
                resolve(val);
            }
            catch (e) {
                reject(e);
            }
        });
    }
};
AimTaskDsTokens = __decorate([
    customElement('aim-task-ds-tokens-100554')
], AimTaskDsTokens);
