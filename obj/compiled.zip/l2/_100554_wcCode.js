/// <mls shortName="wcCode" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaApresentationTextCodeBase } from './_100554_icaApresentationTextCodeBase';
let WcCode100554 = class WcCode100554 extends IcaApresentationTextCodeBase {
    constructor() {
        super(...arguments);
        this.loadStyle(`wc-code-100554 pre{position:relative;white-space:pre-line}wc-code-100554 pre select{position:absolute;top:62px;left:5px;border:none;outline:none}wc-code-100554 pre code.hljs{display:block;overflow-x:auto;padding:1em}wc-code-100554 code.hljs{padding:3px 5px}wc-code-100554 .hljs{background:#fff;border:1px solid var(--grey-color);color:#000;outline:none}wc-code-100554 .hljs-keyword,wc-code-100554 .hljs-literal,wc-code-100554 .hljs-symbol,wc-code-100554 .hljs-name{color:#569CD6}wc-code-100554 .hljs-link{color:#569CD6;text-decoration:underline}wc-code-100554 .hljs-built_in,wc-code-100554 .hljs-type{color:#4EC9B0}wc-code-100554 .hljs-number,wc-code-100554 .hljs-class{color:#B8D7A3}wc-code-100554 .hljs-string,wc-code-100554 .hljs-meta .hljs-string{color:#D69D85}wc-code-100554 .hljs-regexp,wc-code-100554 .hljs-template-tag{color:#9A5334}wc-code-100554 .hljs-subst,wc-code-100554 .hljs-function,wc-code-100554 .hljs-title,wc-code-100554 .hljs-params,wc-code-100554 .hljs-formula{color:#DCDCDC}wc-code-100554 .hljs-comment,wc-code-100554 .hljs-quote{color:#57A64A;font-style:italic}wc-code-100554 .hljs-doctag{color:#608B4E}wc-code-100554 .hljs-meta,wc-code-100554 .hljs-meta .hljs-keyword,wc-code-100554 .hljs-tag{color:#9B9B9B}wc-code-100554 .hljs-variable,wc-code-100554 .hljs-template-variable{color:#BD63C5}wc-code-100554 .hljs-attr,wc-code-100554 .hljs-attribute{color:#9CDCFE}wc-code-100554 .hljs-section{color:gold}wc-code-100554 .hljs-emphasis{font-style:italic}wc-code-100554 .hljs-strong{font-weight:bold}wc-code-100554 .hljs-bullet,wc-code-100554 .hljs-selector-tag,wc-code-100554 .hljs-selector-id,wc-code-100554 .hljs-selector-class,wc-code-100554 .hljs-selector-attr,wc-code-100554 .hljs-selector-pseudo{color:#D7BA7D}wc-code-100554 .hljs-addition{background-color:#144212;display:inline-block;width:100%}wc-code-100554 .hljs-deletion{background-color:#600;display:inline-block;width:100%}wc-code-100554 pre{margin:0}`);
        this.language = 'typescript';
        this.languages = [];
        this.text = '';
    }
    updated(changedProperties) {
        if (changedProperties.has('language')) {
            if (!window.hljsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js';
                script.onload = () => {
                    window.hljsLoaded = true;
                    this.setCode();
                };
                document.head.appendChild(script);
            }
            else {
                this.setCode();
            }
        }
        if (changedProperties.has('text')) {
            if (!this.codeBlock)
                return;
            this.waitForLoadIfNeeded(() => {
                this.setCode();
            });
        }
        if (changedProperties.has('languages')) {
            if (this.select)
                this.select.value = this.language;
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.hljsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load highlight.js. please try again`);
            }
        };
        checkVariable();
    }
    setCode() {
        if (!this.codeBlock)
            return;
        this.codeBlock.innerHTML = '';
        this.codeBlock.removeAttribute('data-highlighted');
        this.codeBlock.classList.add('language-' + this.language);
        const that = this;
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            window.hljs.configure({ ignoreUnescapedHTML: true });
            if (!that.languages || that.languages.length === 0)
                that.languages = window.hljs.listLanguages();
            const res = window.hljs.highlight(this.text, { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
        });
    }
    firstUpdated() {
        this.setCode();
    }
    render() {
        return html `
       <pre>
            <code class="code" spellcheck="false"></code>
       </pre>
    `;
    }
    onChangeText(e) {
        const target = e.target;
        const val = target.textContent;
        const that = this;
        function setCursorToEnd(el) {
            const range = document.createRange();
            const selection = window.getSelection();
            range.selectNodeContents(el);
            range.collapse(false);
            if (!selection)
                return;
            selection.removeAllRanges();
            selection.addRange(range);
        }
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            const res = window.hljs.highlight(val, { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
            setCursorToEnd(that.codeBlock);
        });
    }
};
__decorate([
    property({ type: String, reflect: true, attribute: true })
], WcCode100554.prototype, "language", void 0);
__decorate([
    property({ type: Array })
], WcCode100554.prototype, "languages", void 0);
__decorate([
    property({ type: String, reflect: true })
], WcCode100554.prototype, "text", void 0);
__decorate([
    query('.code')
], WcCode100554.prototype, "codeBlock", void 0);
__decorate([
    query('select')
], WcCode100554.prototype, "select", void 0);
WcCode100554 = __decorate([
    customElement('wc-code-100554')
], WcCode100554);
export { WcCode100554 };
