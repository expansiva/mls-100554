/// <mls shortName="wcCode" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaApresentationTextCodeBase } from './_100554_icaApresentationTextCodeBase';
let WcCode100554 = class WcCode100554 extends IcaApresentationTextCodeBase {
    constructor() {
        super(...arguments);
        this.language = 'typescript';
        this.languages = [];
        this.text = '';
    }
    updated(changedProperties) {
        if (changedProperties.has('language')) {
            if (!window.hljsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js';
                script.onload = () => {
                    window.hljsLoaded = true;
                    this.setCode();
                };
                document.head.appendChild(script);
            }
            else {
                this.setCode();
            }
        }
        if (changedProperties.has('text')) {
            if (!this.codeBlock)
                return;
            this.waitForLoadIfNeeded(() => {
                this.setCode();
            });
        }
        if (changedProperties.has('languages')) {
            if (this.select)
                this.select.value = this.language;
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.hljsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load highlight.js. please try again`);
            }
        };
        checkVariable();
    }
    setCode() {
        if (!this.codeBlock)
            return;
        this.codeBlock.innerHTML = '';
        this.codeBlock.removeAttribute('data-highlighted');
        this.codeBlock.classList.add('language-' + this.language);
        const that = this;
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            window.hljs.configure({ ignoreUnescapedHTML: true });
            that.languages = window.hljs.listLanguages();
            const res = window.hljs.highlight(this.text, { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
        });
    }
    firstUpdated() {
        this.setCode();
    }
    render() {
        return html `
        
       <pre>
            <select .value=${this.language} @change=${(e) => { this.onChangeLanguage(e); }}>
                ${this.languages.map((lang) => {
            return html `<option value=${lang}>${lang}</option>`;
        })}
            </select>
            <code class="code" contenteditable="true" spellcheck="false" @input=${this.onChangeText}></code>
       </pre>
    `;
    }
    onChangeLanguage(e) {
        const target = e.target;
        const value = target.value;
        this.language = value;
    }
    onChangeText(e) {
        const target = e.target;
        const val = target.textContent;
        const that = this;
        function setCursorToEnd(el) {
            const range = document.createRange();
            const selection = window.getSelection();
            range.selectNodeContents(el);
            range.collapse(false);
            if (!selection)
                return;
            selection.removeAllRanges();
            selection.addRange(range);
        }
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            const res = window.hljs.highlight(val, { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
            setCursorToEnd(that.codeBlock);
        });
    }
};
WcCode100554.styles = css `

    pre{
        position:relative;
    }
    pre select {
        position:absolute;
        top:62px;
        left:5px;
        border: none;
        outline:none;
    }
    pre code.hljs {
        display: block;
        overflow-x: auto;
        padding: 1em
      }
      code.hljs {
        padding: 3px 5px
      }
      /*
      * Visual Studio 2015 dark style
      * Author: Nicolas LLOBERA <nllobera@gmail.com>
      */
      .hljs {
        background: #fff;
        border: 1px solid var(--grey-color);
        color: #000;
        outline:none;
      }
      .hljs-keyword,
      .hljs-literal,
      .hljs-symbol,
      .hljs-name {
        color: #569CD6
      }
      .hljs-link {
        color: #569CD6;
        text-decoration: underline
      }
      .hljs-built_in,
      .hljs-type {
        color: #4EC9B0
      }
      .hljs-number,
      .hljs-class {
        color: #B8D7A3
      }
      .hljs-string,
      .hljs-meta .hljs-string {
        color: #D69D85
      }
      .hljs-regexp,
      .hljs-template-tag {
        color: #9A5334
      }
      .hljs-subst,
      .hljs-function,
      .hljs-title,
      .hljs-params,
      .hljs-formula {
        color: #DCDCDC
      }
      .hljs-comment,
      .hljs-quote {
        color: #57A64A;
        font-style: italic
      }
      .hljs-doctag {
        color: #608B4E
      }
      .hljs-meta,
      .hljs-meta .hljs-keyword,
      .hljs-tag {
        color: #9B9B9B
      }
      .hljs-variable,
      .hljs-template-variable {
        color: #BD63C5
      }
      .hljs-attr,
      .hljs-attribute {
        color: #9CDCFE
      }
      .hljs-section {
        color: gold
      }
      .hljs-emphasis {
        font-style: italic
      }
      .hljs-strong {
        font-weight: bold
      }
      /*.hljs-code {
        font-family:'Monospace';
      }*/
      .hljs-bullet,
      .hljs-selector-tag,
      .hljs-selector-id,
      .hljs-selector-class,
      .hljs-selector-attr,
      .hljs-selector-pseudo {
        color: #D7BA7D
      }
      .hljs-addition {
        background-color: #144212;
        display: inline-block;
        width: 100%
      }
      .hljs-deletion {
        background-color: #600;
        display: inline-block;
        width: 100%
      }
      pre {
        margin: 0;
      }
      .actions{
        height:30px; 
        background: #b4b4b4; 
        display:flex; 
        align-items:center;
        padding:0 1rem; 
        color:#fff;
        .actions-list{
          display:flex;
          gap:1rem;
        }
      }
      .language {
        flex:1;
      }
      
      .action-item{
        display:flex; 
        align-items:center;
        justify-content: center;
        cursor:pointer;
        min-width: 70px;
      }
      .accepted{
        cursor:default;
      }
      .copied {
        cursor:default;
      }
    `;
__decorate([
    property({ type: String, reflect: true })
], WcCode100554.prototype, "language", void 0);
__decorate([
    property({ type: Array })
], WcCode100554.prototype, "languages", void 0);
__decorate([
    property({ type: String, reflect: true })
], WcCode100554.prototype, "text", void 0);
__decorate([
    query('.code')
], WcCode100554.prototype, "codeBlock", void 0);
__decorate([
    query('select')
], WcCode100554.prototype, "select", void 0);
WcCode100554 = __decorate([
    customElement('wc-code-100554')
], WcCode100554);
export { WcCode100554 };
