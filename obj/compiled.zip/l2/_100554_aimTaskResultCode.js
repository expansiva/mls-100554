/// <mls shortName="aimTaskResultCode" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeSnippet100554 } from './_100554_collabShowCodeSnippet';
import { initCollabShowCodeDiff100554 } from './_100554_collabShowCodeDiff';
import { getInfoMyService } from './_100554_aimHelper';
let AimTaskResultCode = class AimTaskResultCode extends AimTaskBase {
    constructor() {
        super();
        this.result = '';
        initCollabShowCodeSnippet100554();
        initCollabShowCodeDiff100554();
    }
    onInitializing() {
        this.notifyCompleteByStatus('ok', '');
    }
    renderBody(taskRoot, child) {
        const title = child.title;
        const body = child._tempResult || '';
        this.result = this.extractScript(body);
        return html `
        <details open>
            <summary>${title}- Code</summary>
            <div style='margin: 10px'>
                <collab-show-code-snippet-100554 withAccept="true" .onAccept=${this.onAccept.bind(this)}>
                </collab-show-code-snippet-100554>
            </div> 
        </details>
        `;
    }
    onAccept() {
        const info = getInfoMyService(this);
        if (!info || !info.actServiceOp)
            return;
        if (info.actServiceOp.tagName !== 'SERVICE-SOURCE-100554')
            return;
        info.actServiceOp.setEditorValue(this.result);
    }
    extractScript(src) {
        const regex = /```typescript([\s\S]+?)```/g;
        const matches = src.match(regex);
        const contents = [];
        let ret = src;
        if (matches) {
            for (const m of matches) {
                const conteudo = m.replace(/```typescript|```/g, '').trim();
                contents.push(conteudo);
            }
            ret = contents[0];
        }
        return ret;
    }
    firstUpdated(a) {
        super.firstUpdated(a);
        if (this.codeSnippet)
            this.codeSnippet.textIn = this.result;
    }
};
__decorate([
    query('collab-show-code-snippet-100554')
], AimTaskResultCode.prototype, "codeSnippet", void 0);
__decorate([
    query('collab-show-code-diff-100554')
], AimTaskResultCode.prototype, "codeDif", void 0);
AimTaskResultCode = __decorate([
    customElement('aim-task-result-code-100554')
], AimTaskResultCode);
export { AimTaskResultCode };
