/// <mls shortName="icaLayoutGroupTableBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { StateLitElement } from './_100554_stateLitElement';
export class IcaLayoutGroupTableBase extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
}
