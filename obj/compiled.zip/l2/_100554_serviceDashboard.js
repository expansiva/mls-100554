/// <mls shortName="serviceDashboard" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { getConfigProject } from './_100554_libProjectConfig';
import './_100554_collabTiles';
let ServiceDashboard100554 = class ServiceDashboard100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-dashboard-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);display:block;overflow:auto}`);
        this.msize = '';
        this.cssBreakPoint = '';
        this.activeTab = 'Icon1';
        //------SERVICE----------
        this.details = {
            icon: '&#xf201',
            state: 'foreground',
            position: 'left',
            tooltip: 'Dashboard',
            visible: true,
            widget: '_100554_serviceDashboard',
            level: [6]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            this.activeTab = op;
        };
        this.menu = {
            title: '',
            actions: {},
            icons: {
                Icon1: 'Example 1;f0e8',
                Icon2: 'Example 2;f0e8',
            },
            actionDefault: '', // call after close icon clicked
            iconDefault: 'Icon1',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.refreshTimeOut = 0;
        //------------IMPLEMENTATION---------------
        this.pluginsDash1 = [];
        this.pluginsDash2 = [];
    }
    onServiceClick(visible, reinit, el) {
        if (!visible) {
            const el = this.shadowRoot?.querySelector('collab-tiles-100554');
            if (!el)
                return;
            const config = el.getAttribute('config');
            if (config === 'close' || !el.onlyclose)
                return;
            el.onlyclose();
        }
    }
    //---------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        this.loadAndSetPlugins();
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            const [w, h] = this.msize.split(',');
            if (w && +w < 800)
                this.cssBreakPoint = 'break-800';
            else if (w && +w > 800)
                this.cssBreakPoint = '';
            clearTimeout(this.refreshTimeOut);
            this.refreshTimeOut = setTimeout(() => {
                this.shadowRoot?.querySelectorAll('collab-tiles-item-100554 collabtileitemcontent').forEach((item) => {
                    Array.from(item.children).forEach((plugin) => {
                        const root = plugin.shadowRoot || plugin;
                        root.querySelectorAll('wc-chart-100554').forEach((chart) => {
                            if (chart.myChart && chart.myChart.resize)
                                chart.myChart.resize();
                        });
                    });
                });
            }, 500);
        }
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'Icon1':
                return this.renderIcon1();
            case 'Icon2':
                return this.renderIcon2();
            default:
                return html ``;
        }
    }
    renderIcon1() {
        if (this.pluginsDash1.length <= 0)
            return html `<h3 style="padding:2rem">Not found plugins</h3>`;
        return html `<collab-tiles-100554 .tilesItens=${this.pluginsDash1} example="1" class="${this.cssBreakPoint}"></collab-tiles-100554>`;
    }
    renderIcon2() {
        if (this.pluginsDash2.length <= 0)
            return html `<h3 style="padding:2rem">Not found plugins</h3>`;
        return html `<collab-tiles-100554 .tilesItens=${this.pluginsDash2} example="2" class="${this.cssBreakPoint}"></collab-tiles-100554>`;
    }
    async loadAndSetPlugins() {
        const prj = mls.actual[5].project;
        if (!prj)
            return;
        await mls.plugin.loadAll(prj, true);
        const dash = "l6Dashboard";
        const arry = mls.plugin.getAllMenuActions(100554, { scope: dash });
        const config = await getConfigProject(prj);
        arry.forEach((i, index) => {
            const item = {
                title: 'Tile_' + index,
                plugin: i.widget,
                position: '2 2',
                index: '99',
                enabled: 'true',
                widgetConfig: ''
            };
            const infoPlugin = this.getInfoPlugin(config, i.widgetConfig, i.widget, i.category);
            item.position = infoPlugin.pos;
            item.index = infoPlugin.index;
            item.enabled = infoPlugin.enabled;
            item.widgetConfig = infoPlugin.widgetConfig;
            switch (i.category) {
                case 'Examples 1': {
                    this.pluginsDash1.push(item);
                    break;
                }
                case 'Examples 2': {
                    this.pluginsDash2.push(item);
                    break;
                }
                default: '';
            }
        });
        this.pluginsDash1.sort((a, b) => {
            return Number(a.index) - Number(b.index);
        });
        this.pluginsDash2.sort((a, b) => {
            return Number(a.index) - Number(b.index);
        });
        this.requestUpdate();
    }
    getInfoPlugin(config, widgetConfig, widget, cat) {
        const ret = { index: '99', enabled: 'true', pos: '2 2', widgetConfig: '' };
        if (!config || !widgetConfig || !cat)
            return ret;
        const plugin = config.plugins;
        widgetConfig = '_' + widgetConfig.replace('2_', '').replace('.ts', '');
        ret.widgetConfig = widgetConfig;
        if (!plugin[widgetConfig] || !plugin[widgetConfig][widget] || !plugin[widgetConfig][widget]["l6Dashboard"] || !plugin[widgetConfig][widget]["l6Dashboard"][cat])
            return ret;
        const pos = plugin[widgetConfig][widget]["l6Dashboard"][cat].replace('tile', '').trim();
        const a = pos.split(' ');
        if (a.length < 3)
            ret.pos = a.join(' ');
        else {
            ret.index = a.pop();
            ret.pos = a.join(' ');
        }
        ret.enabled = plugin[widgetConfig][widget].enabled;
        return ret;
    }
};
__decorate([
    property()
], ServiceDashboard100554.prototype, "msize", void 0);
__decorate([
    property()
], ServiceDashboard100554.prototype, "cssBreakPoint", void 0);
__decorate([
    property()
], ServiceDashboard100554.prototype, "activeTab", void 0);
ServiceDashboard100554 = __decorate([
    customElement('service-dashboard-100554')
], ServiceDashboard100554);
export { ServiceDashboard100554 };
