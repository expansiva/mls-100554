/// <mls shortName="serviceDashboard" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import './_100554_collabTiles';
let ServiceDashboard100554 = class ServiceDashboard100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.msize = '';
        this.cssBreakPoint = '';
        this.details = {
            icon: '&#xf201',
            state: 'foreground',
            position: 'left',
            tooltip: 'Dashboard',
            visible: true,
            widget: '_100554_serviceDashboard',
            level: [6]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Dashboard',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.refreshTimeOut = 0;
    }
    onServiceClick(visible, reinit, el) {
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            const all = this.shadowRoot?.querySelectorAll('wc-chart-100554');
            const [w, h] = this.msize.split(',');
            if (w && +w < 800)
                this.cssBreakPoint = 'break-800';
            else if (w && +w > 800)
                this.cssBreakPoint = '';
            clearTimeout(this.refreshTimeOut);
            this.refreshTimeOut = setTimeout(() => {
                all?.forEach((i) => {
                    if (i.myChart && i.myChart.resize)
                        i.myChart.resize();
                });
            }, 500);
        }
    }
    render() {
        return html `<collab-tiles-100554 class="${this.cssBreakPoint}"></collab-tiles-100554>`;
    }
};
ServiceDashboard100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDashboard100554.prototype, "msize", void 0);
__decorate([
    property()
], ServiceDashboard100554.prototype, "cssBreakPoint", void 0);
ServiceDashboard100554 = __decorate([
    customElement('service-dashboard-100554')
], ServiceDashboard100554);
export { ServiceDashboard100554 };
