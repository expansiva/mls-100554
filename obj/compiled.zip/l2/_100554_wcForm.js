/// <mls shortName="wcForm" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaFormsContentFormBase } from './_100554_icaFormsContentFormBase';
let WcForm100554 = class WcForm100554 extends IcaFormsContentFormBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.autocomplete = false;
        this.disabled = false;
        this.validateOnChange = false;
        this.autosave = false;
    }
    render() {
        return html `<form><slot></slot></form>`;
    }
};
__decorate([
    property({ type: String })
], WcForm100554.prototype, "action", void 0);
__decorate([
    property({ type: String })
], WcForm100554.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WcForm100554.prototype, "method", void 0);
__decorate([
    property({ type: String })
], WcForm100554.prototype, "novalidate", void 0);
__decorate([
    property({ type: Boolean })
], WcForm100554.prototype, "autocomplete", void 0);
__decorate([
    property({ type: Boolean })
], WcForm100554.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WcForm100554.prototype, "validateOnChange", void 0);
__decorate([
    property({ type: Boolean })
], WcForm100554.prototype, "autosave", void 0);
__decorate([
    property({ type: String })
], WcForm100554.prototype, "enctype", void 0);
__decorate([
    property({ type: String })
], WcForm100554.prototype, "target", void 0);
WcForm100554 = __decorate([
    customElement('wc-form-100554')
], WcForm100554);
export { WcForm100554 };
