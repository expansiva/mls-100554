/// <mls shortName="wcdToolboxItemActionEditAttrDialog" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { globalWcd } from './_100554_wcdState';
import './_100554_wcdToolboxItemActionEditAttrOut';
let WcdToolboxItemActionEditAttrDialog = class WcdToolboxItemActionEditAttrDialog extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    //-------COMPONENT----------
    disconnectedCallback() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (globalWcd.myParent) {
            globalWcd.myParent.removeAttribute('needresize');
            globalWcd.myParent.style.overflowY = '';
            globalWcd.myParent.style.height = this.lastHeightWcd || '';
        }
        if (globalWcd.elICA)
            globalWcd.elICA.style.height = this.lastHeight || '';
        else if (this.lastIca)
            this.lastIca.style.height = this.lastHeight || '';
        super.disconnectedCallback();
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        this.recalculeIcaHeight();
    }
    render() {
        this.style.cssText = `width: 100%`;
        return html `<wcd-toolbox-item-action-edit-attr-out-100554></wcd-toolbox-item-action-edit-attr-out-100554>`;
    }
    //------IMPLEMENTS----------
    recalculeIcaHeight() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        const height = globalWcd.elICA.getBoundingClientRect()?.height;
        if (this.lastHeight === undefined)
            this.lastHeight = globalWcd.elICA.style.height;
        if (this.lastHeightWcd === undefined)
            this.lastHeightWcd = globalWcd.myParent.style.height;
        globalWcd.myParent.setAttribute('needresize', 'false');
        globalWcd.myParent.style.overflowY = 'auto';
        globalWcd.myParent.style.height = '300px';
        globalWcd.elICA.style.height = (height + 300) + 'px';
        globalWcd.myParent.style.top = height + 'px';
    }
};
WcdToolboxItemActionEditAttrDialog = __decorate([
    customElement('wcd-toolbox-item-action-edit-attr-dialog-100554')
], WcdToolboxItemActionEditAttrDialog);
export { WcdToolboxItemActionEditAttrDialog };
