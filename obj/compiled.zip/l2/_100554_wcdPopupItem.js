/// <mls shortName="wcdPopupItem" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, css } from 'lit';
import { customElement } from 'lit/decorators.js';
let WCDPopupItem = class WCDPopupItem extends LitElement {
    constructor() {
        super();
        console.log('in WCDPopupItem');
    }
    // Default onClick handler, should be overridden by child classes
    handleClick() {
        console.log(`wcd popup click not implemented`);
    }
    render() {
        return html `
      <div @click=${this.handleClick}>
        ?
      </div>
    `;
    }
};
WCDPopupItem.styles = css `
    :host {
      display: inline-block;
      padding: 8px 12px;
      background-color: #333;
      color: white;
      border-radius: 4px;
      cursor: pointer;
      text-align: center;
      font-size: 14px;
      transition: background-color 0.2s ease;
    }

    :host(:hover) {
      background-color: #444;
    }
  `;
WCDPopupItem = __decorate([
    customElement('wcd-popup-item-100554')
], WCDPopupItem);
export { WCDPopupItem };
