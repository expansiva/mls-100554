/// <mls shortName="pluginStyleTokens" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getMessageKey } from './_100554_collabLitElement';
import { StateLitElement } from './_100554_stateLitElement';
import { propertyDataSource } from './_100554_collabDecorators';
import { getTokens } from './_100554_designSystemBase';
/// **collab_i18n_start**
const message_pt = {
    description: 'Um plugin especializado para gerenciar tokens de design de cores. Defina, organize e aplique facilmente paletas de cores para garantir consistência em seus designs, melhorando a acessibilidade e o apelo visual em seus projetos.'
};
const message_en = {
    description: 'A specialized plugin for managing color design tokens. Easily define, organize, and apply color palettes to ensure consistency across your designs, enhancing accessibility and visual appeal in your projects.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['color:@*', 'background-color:@*', 'background:@*'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginCssTokens = class PluginCssTokens extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-tokens-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-style-tokens-100554>div{padding:.5rem}plugin-style-tokens-100554 .tokens-container{text-transform:uppercase;font-size:var(--font-size-12);color:var(--text-primary-color-darker);margin-bottom:1rem}plugin-style-tokens-100554 .tokens-content{display:flex;flex-wrap:wrap;margin-top:.3rem}plugin-style-tokens-100554 .token{display:flex;flex-direction:row}plugin-style-tokens-100554 .token-item{height:45px;width:45px;cursor:pointer;border:1px solid}plugin-style-tokens-100554 .token-item.selected{box-shadow:0 4px 8px rgba(0,0,0,0.2),0 2px 4px rgba(0,0,0,0.15);border:1px solid #fff;transform:scale(1.1);transition:transform .2s ease,box-shadow .2s ease}plugin-style-tokens-100554 .token-item:hover{box-shadow:0 4px 8px rgba(0,0,0,0.2),0 2px 4px rgba(0,0,0,0.15)}`);
        this.msg = messages['en'];
        this.position = 'left';
        this.level = 0;
        this.prop = '';
        this.value = '';
        this.theme = 'Default';
        this.tokens = {};
        this.needOrder = true;
    }
    async getTokensColor() {
        const { project } = mls.actual[5];
        if (!project)
            throw new Error('Invalid project selected');
        const tokens = await getTokens(project);
        const resumeTokensByTheme = tokens.find((tk) => tk.themeName === this.theme);
        if (!resumeTokensByTheme)
            return undefined;
        const tokensColorKeys = Object.keys(resumeTokensByTheme.color);
        const filter = this.value.startsWith('@') ? this.value.substring(1, this.value.length) : this.value;
        const res = tokensColorKeys.filter((key) => !key.startsWith('_dark')).map((key2) => {
            return {
                key: key2,
                value: resumeTokensByTheme.color[key2]
            };
        });
        const grouping = this.groupColorsByState(res);
        if (!this.needOrder)
            return grouping;
        const sortedColors = Object.keys(grouping)
            .sort((a, b) => {
            if (filter.indexOf(a) > -1)
                return -1;
            if (filter.indexOf(b) > -1)
                return 1;
            return 0;
        })
            .reduce((result, key) => {
            result[key] = grouping[key];
            return result;
        }, {});
        this.needOrder = false;
        return sortedColors;
    }
    groupColorsByState(items) {
        const grouped = {};
        items.forEach(item => {
            const match = item.key.match(/^(.*?)(-(hover|focus|disabled))?$/);
            const baseKey = match ? match[1].replace(/-(lighter|darker|dark|light)/, '') : item.key;
            const state = match && match[3] ? match[3] : 'default';
            const variation = item.key.includes('lighter')
                ? 'lighter'
                : item.key.includes('darker')
                    ? 'darker'
                    : item.key.includes('dark')
                        ? 'dark'
                        : item.key.includes('light')
                            ? 'light'
                            : 'default';
            if (!grouped[baseKey]) {
                grouped[baseKey] = {};
            }
            if (!grouped[baseKey][state]) {
                grouped[baseKey][state] = { dark: "", light: "", lighter: "", darker: "", default: "" };
            }
            grouped[baseKey][state][variation] = item.value;
        });
        return grouped;
    }
    handleColorClick(key, value) {
        if (!this.state || !this.state.lessCSS || !this.state.selector || !this.prop)
            return;
        this.state.lessCSS.styles[this.prop] = `@${key}`;
    }
    setTooltip() {
        const doc = this.ownerDocument || document;
        const tooltipEl = doc.querySelector('collab-tooltip');
        this.querySelectorAll('.token-item').forEach((item) => {
            if (tooltipEl && tooltipEl.tooltip)
                tooltipEl.tooltip(item);
        });
    }
    async getTokens() {
        if (!this.needOrder && this.tokens)
            return;
        const tokens = await this.getTokensColor();
        if (tokens)
            this.tokens = tokens;
    }
    updated(changedProperties) {
        if (changedProperties.has('tokens')) {
            this.setTooltip();
        }
        if (changedProperties.has('value') && changedProperties.get('value')) {
            this.getTokens();
        }
    }
    async firstUpdated(a) {
        super.firstUpdated(a);
        this.getTokens();
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (!_value.value?.startsWith('@')) {
            this.needOrder = true;
            return;
        }
        const { key, value } = _value;
        this.prop = key || '';
        this.value = value || '';
    }
    render() {
        return html `
            <div>
                ${Object.keys(this.tokens).map((cat) => html `
                <div class="tokens-container">
                    ${cat}
                    <div class="tokens-content">
                    ${Object.keys(this.tokens[cat]).map((state) => html `
                        <div class="token">
                        ${Object.keys(this.tokens[cat][state]).map((variation) => {
            return this.tokens[cat][state][variation] ? html `
                            <div
                                @click=${() => { this.handleColorClick(`${cat}${variation !== 'default' ? '-' + variation : ''}${state !== 'default' ? '-' + state : ''}`, this.tokens[cat][state][variation]); }} 
                                class="token-item${this.value === `@${cat}${variation !== 'default' ? '-' + variation : ''}${state !== 'default' ? '-' + state : ''}` ? ' selected' : ''} "
                                data-tooltip="${cat}${variation !== 'default' ? '-' + variation : ''}${state !== 'default' ? '-' + state : ''}"
                                style="background-color: ${this.tokens[cat][state][variation]};border-color: ${this.tokens[cat][state][variation]}">
                            
                            </div>
                            ` : html ``;
        })}
                        </div>
                    `)}
                    </div>
                </div>
                `)}
            </div>
            `;
    }
};
__decorate([
    propertyDataSource()
], PluginCssTokens.prototype, "state", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "position", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "level", void 0);
__decorate([
    property({ reflect: true })
], PluginCssTokens.prototype, "prop", void 0);
__decorate([
    property({ reflect: true })
], PluginCssTokens.prototype, "value", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "theme", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "tokens", void 0);
PluginCssTokens = __decorate([
    customElement('plugin-style-tokens-100554')
], PluginCssTokens);
export { PluginCssTokens };
