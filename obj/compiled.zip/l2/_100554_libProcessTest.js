/// <mls shortName="libProcessTest" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export function getScriptTest(ica) {
    const array = ica.getHistory();
    if (array.length <= 0)
        return undefined;
    const params = {};
    array.forEach((h) => {
        if (h.system)
            return;
        const key = h.key.split('.').pop();
        const tp = typeof h.value;
        const vl = processValue(h.value);
        if (!key)
            return;
        params[key] = { vl, tp, ori: h.key };
    });
    const lines = [];
    let lastkey = '';
    let lastInteraction = '';
    let lastIndex = -1;
    array.forEach((h) => {
        const tipo = h.system ? "System" : "User";
        const vl = processValue(h.value);
        let row = '';
        if (!h.system) {
            const param = getParam(params, h.key);
            if (!param)
                return;
            row = `setState('${h.key}', args.${param}.value);`;
        }
        else {
            row = `verifyState('${h.key}', ${vl})`;
            if (typeof vl === "string")
                row = `verifyState('${h.key}', '${vl}')`;
        }
        if (lastInteraction === tipo && lastkey === h.key && lastIndex >= 0) {
            lines[lastIndex] = row;
        }
        else {
            lines.push(row);
            lastInteraction = tipo;
            lastkey = h.key;
            lastIndex = lines.length - 1;
        }
    });
    const exe = {
        functionName: '',
        title: '',
        params: {}
    };
    Object.keys(params).forEach((k) => {
        const p = params[k];
        if (!p)
            return;
        exe.params[k] = { type: p.tp, value: p.vl };
    });
    const func = `export function @funcname(args: Record<string, ICANParams>): string {\ntry{\n${lines.join('\n')}\nreturn 'ok';\n}catch(e:any){\nreturn e.message;\n}\n}`;
    return { func, exe };
}
function getParam(params, key) {
    const keys = Object.keys(params);
    let ret = '';
    keys.forEach((i) => {
        if (params[i].ori !== key)
            return;
        ret = i;
    });
    return ret;
}
function processValue(vl) {
    if (typeof vl === "string" || typeof vl === "number") {
        return vl;
    }
    return JSON.stringify(vl);
}
export function runTest(iframe, script) {
    return;
}
