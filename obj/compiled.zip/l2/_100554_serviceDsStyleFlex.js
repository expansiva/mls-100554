/// <mls shortName="serviceDsStyleFlex" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
/// **collab_i18n_start**
const message_pt = {
    display: 'Exibição',
    flexDirection: 'Direção flexível',
    flexWrap: 'Envoltório flexível',
    justifyContent: 'Justificar conteúdo',
    alignItems: 'Alinhar itens',
    alignContent: 'Alinhar conteúdo',
    alignSelf: 'Alinhar-se',
    order: 'Ordem'
};
const message_en = {
    display: 'Display',
    flexDirection: 'Flex direction',
    flexWrap: 'Flex wrap',
    justifyContent: 'Justify content',
    alignItems: 'Align items',
    alignContent: 'Align content',
    alignSelf: 'Align self',
    order: 'Order'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleFlex = class ServiceDsStyleFlex extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.myUpp = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleFlex';
        this.details = {
            icon: '&#xf009',
            state: 'foreground',
            position: 'right',
            tooltip: 'Flex',
            tags: ['ds_styles'],
            visible: false,
            widget: '_100554_serviceDsStyleFlex',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Flex',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //-------------IMPLEMENTS--------------
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        this.arrayGallery = [
            'display: flex;flex-direction: row; justify-content: flex-start;border: 1px solid #cccccc;margin-left: 10px; width:120px;padding: 5px; cursor: pointer;background:white',
            'display: flex; flex-direction: row; justify-content: flex-end; border: 1px solid rgb(204, 204, 204); margin-left: 10px; width: 120px; padding: 5px; cursor: pointer;background:white',
            'display: flex; flex-direction: row; justify-content: center; border: 1px solid rgb(204, 204, 204); margin-left: 10px; width: 120px; padding: 5px; cursor: pointer;background:white',
            'display: flex; flex-direction: row; justify-content: space-between; border: 1px solid rgb(204, 204, 204); margin-left: 10px; width: 120px; padding: 5px; cursor: pointer;background:white',
            'display: flex;flex-direction: column; justify-content: flex-start;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white',
            'display: flex;flex-direction: column; justify-content: flex-end;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white',
            'display: flex;flex-direction: column; justify-content: center;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white',
            'display: flex;flex-direction: column; justify-content: space-between;border: 1px solid #cccccc;margin-left: 10px; width:60px;height:200px; padding: 5px; cursor: pointer;background:white'
        ];
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    setValues(ar) {
        this.myUpp = true;
        ar.forEach((i) => {
            if (!this.shadowRoot || !i.key)
                return;
            const value = i.value;
            const prop = i.key;
            const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
            if (el)
                el.value = value;
        });
        this.myUpp = false;
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `${this.renderFlex()}${this.renderFlexItem()}${this.renderGallery()}`;
    }
    renderFlex() {
        return html `
            <div>
                <h5>Flex</h5>
                <div class="groupEdit">
                    <span>${this.msg.display}</span>
                    <select @change="${() => this.onChangeProp("display")}" style="width:150px" prop="display">
                        <option value=""></option>
                        <option value="flex">Flex</option>
                        <option value="inline-flex">Inline Flex</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.flexDirection}</span>
                    <select @change="${() => this.onChangeProp("flex-direction")}" style="width:150px" prop="flex-direction">
                        <option value=""></option>
                        <option value="row">Row</option>
                        <option value="row-reverse">Row Reverse</option>
                        <option value="column">Column</option>
                        <option value="column-reverse">Column Reverse</option>
                    </select>   
                </div>
                <div class="groupEdit">
                    <span>${this.msg.flexWrap}</span>
                    <select @change="${() => this.onChangeProp("flex-wrap")}" style="width:150px" prop="flex-wrap">
                        <option value=""></option>
                        <option value="nowrap">Nowrap</option>
                        <option value="wrap">Wrap</option>
                        <option value="wrap-reverse">Wrap Reverse</option>
                    </select>  
                </div>
                <div class="groupEdit">
                    <span>${this.msg.justifyContent}</span>
                    <select @change="${() => this.onChangeProp("justify-content")}" style="width:150px" prop="justify-content">
                        <option value=""></option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="space-between">Space between</option>
                        <option value="space-around">Space around</option>
                    </select>  
                </div>
                <div class="groupEdit">
                    <span>${this.msg.alignItems}</span>
                    <select @change="${() => this.onChangeProp("align-items")}" style="width:150px" prop="align-items">
                        <option value=""></option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="baseline">Baseline</option>
                        <option value="stretch">Stretch</option>
                    </select>  
                </div>
                <div class="groupEdit">
                    <span>${this.msg.alignContent}</span>
                    <select @change="${() => this.onChangeProp("align-content")}" style="width:150px" prop="align-content">
                        <option value=""></option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="space-between">Space between</option>
                        <option value="space-around">Space around</option>
                        <option value="stretch">Stretch</option>
                    </select>  
                </div>
            </div>
        
        `;
    }
    renderFlexItem() {
        return html `
            <div>
                <h5>Flex-Item</h5>
                <div class="groupEdit">
                    <span>${this.msg.alignSelf}</span>
                    <select @change="${() => this.onChangeProp("align-self")}" style="width:150px" prop="align-self">
                        <option value=""></option>
                        <option value="auto">auto</option>
                        <option value="flex-start">Flex start</option>
                        <option value="flex-end">Flex end</option>
                        <option value="center">Center</option>
                        <option value="baseline">Baseline</option>
                        <option value="stretch">Stretch</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.order}</span>
                    <select @change="${() => this.onChangeProp("order")}" style="width:150px" prop="order">
                        <option value=""></option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        
                    </select>   
                </div>
                
            </div>
        
        `;
    }
    renderGallery() {
        return html `
            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer;border:none">
                ${repeat(this.arrayGallery.slice(0, 4), ((key) => key), ((css, index) => {
            return html `<div style="${css}" @click="${this.clickGallery}" .gallery=${css}>
                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                            <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                        </div>`;
        }))}
            </div>
            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">
                ${repeat(this.arrayGallery.slice(4, 8), ((key) => key), ((css, index) => {
            return html `<div style="${css}" @click="${this.clickGallery}" .gallery=${css}>
                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                    <span style="background: #363636; padding: 0.5rem; margin: 0.25rem;" .gallery=${css}></span>
                </div>`;
        }))}
            </div>
        
        `;
    }
    onChangeProp(prop) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            if (!this.shadowRoot)
                return;
            const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
            this.emitEvent({ key: prop, value: el.value });
        }, 500);
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
    clickGallery(e) {
        const el = e.target;
        if (!el)
            return;
        const css = el.gallery;
        if (!css)
            return;
        const commands = css.split(';');
        const changes = [];
        commands.forEach((item) => {
            const [key, value] = item.split(':');
            if (!key)
                return;
            changes.push({
                key: key.trim(),
                value: value.trim()
            });
        });
        const rc = {
            emitter: 'right',
            value: changes,
            helper: this.helper
        };
        this.setValues(changes);
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
};
ServiceDsStyleFlex.styles = css ` :host{padding:1rem;display:block} :host>div{margin-bottom:1rem;border-bottom:1px solid #bcb9b9} .groupEdit{display:flex;flex-direction:row;margin-bottom:.5rem} .groupEdit span{width:150px;font-size:90%}`;
__decorate([
    property()
], ServiceDsStyleFlex.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleFlex.prototype, "helper", void 0);
ServiceDsStyleFlex = __decorate([
    customElement('service-ds-style-flex-100554')
], ServiceDsStyleFlex);
export { ServiceDsStyleFlex };
