/// <mls shortName="collabL3PreviewTextAttr" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { propertyDataSource } from './_100554_collabDecorators';
let CollabL3PreviewText = class CollabL3PreviewText extends StateLitElement {
    render() {
        this.onclick = this.handleClick.bind(this);
        this.onblur = this.handleChange.bind(this);
        this.setAttribute('contenteditable', 'true');
        return html `${this.value}`;
    }
    handleChange(event) {
        this.value = this.innerText;
        event.stopPropagation();
        event.preventDefault();
    }
    handleClick(event) {
        event.stopPropagation();
        event.preventDefault();
    }
};
__decorate([
    propertyDataSource({ type: String })
], CollabL3PreviewText.prototype, "value", void 0);
CollabL3PreviewText = __decorate([
    customElement('collab-l3-preview-text-attr-100554')
], CollabL3PreviewText);
export { CollabL3PreviewText };
