/// <mls shortName="bePageTest2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { BECollabServer } from './_100554_beCollabServer';
export class Test {
    constructor() {
        this.server = new BECollabServer();
        this.setRoutes();
    }
    startServer() {
        return this.server.start('Server no ar');
    }
    //-----IMPLEMENTS------------
    setRoutes() {
        this.server.on('/api/test', 'POST', async (body) => {
            console.log('POST');
            return { message: "Recebi os dados!", data: body };
        });
        this.server.on('/api/test', 'GET', async (body) => {
            console.log('GET');
            return { message: "AQUI O RETORNO" };
        });
    }
}
window.Test = Test;
