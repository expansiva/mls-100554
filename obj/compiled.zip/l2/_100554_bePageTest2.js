/// <mls shortName="bePageTest2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { BECollabServer } from './_100554_beCollabServer';
import { BEIndexedDBBase } from './_100554_beIndexedDBBase';
export class Test {
    constructor() {
        this.server = new BECollabServer();
        this.indexDb = new BEIndexedDBBase();
        this.setRoutes();
        this.initDB();
    }
    startServer() {
        return this.server.start('Server no ar');
    }
    //-----IMPLEMENTS------------
    setRoutes() {
        this.server.on('/api/user', 'POST', async (body) => {
            console.log('Caiu api add user');
            return await this.addUser(body);
        });
        this.server.on('/api/user', 'PUT', async (body) => {
            console.log('Caiu api upd user');
            return await this.updUser(body);
        });
        this.server.on('/api/user', 'DELETE', async (body) => {
            console.log('Caiu api del user');
            return await this.delUser(body);
        });
        this.server.on('/api/user', 'GET', async (body) => {
            console.log('Caiu api get user');
            return await this.getUser(body);
        });
    }
    initDB() {
        this.indexDb.dbName = 'dbTest';
        const tbUser = [
            {
                field: 'id',
                tp: 'NUMBER',
                primaryKey: true,
                autoIncrement: true,
            },
            {
                field: 'nome',
                tp: 'STRING',
                primaryKey: false,
                autoIncrement: false,
            },
            {
                field: 'senha',
                tp: 'STRING',
                primaryKey: false,
                autoIncrement: false,
            }
        ];
        this.indexDb.createTable('user', tbUser);
    }
    async addUser(info) {
        return await this.indexDb.post('user', info);
    }
    async updUser(info) {
        return await this.indexDb.put('user', info);
    }
    async getUser(nome) {
        let bd = [];
        if (nome)
            bd = [{ field: 'nome', value: nome }];
        return await this.indexDb.get('user', bd);
    }
    async delUser(id) {
        if (!id)
            throw new Error('not found id');
        let bd = [{ field: 'id', value: +id }];
        return await this.indexDb.delete('user', bd);
    }
}
window.Test = Test;
