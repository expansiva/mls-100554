/// <mls shortName="wcdToolboxItemActionEditVariation" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { dispatchEventConciliate } from './_100554_wcdCommandBase';
import { getConfigProject } from './_100554_libProjectConfig';
let WCDToolboxItemActionEditAttrOut = class WCDToolboxItemActionEditAttrOut extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`wcd-toolbox-item-action-edit-variation-100554{width:100%}wcd-toolbox-item-action-edit-variation-100554 addvariation{width:100%;display:flex;gap:1rem;align-items:center;margin-top:.5rem}wcd-toolbox-item-action-edit-variation-100554 addvariationitem{display:flex;gap:.5rem;align-items:center;height:19px;width:100%}wcd-toolbox-item-action-edit-variation-100554 addvariationitem select{width:calc(100% - 30px);border:1px solid #a6a4a4;border-radius:3px;height:19px;outline:none}wcd-toolbox-item-action-edit-variation-100554 addvariationitem button{padding:0 .3rem;background-color:#1890FF;color:white;border:none;border-radius:2px;cursor:pointer;width:25px}wcd-toolbox-item-action-edit-variation-100554 addvariationitem button:hover{opacity:.5}`);
        this.languages = {};
        this.timeKeydown = -1;
        this.init();
    }
    //-------COMPONENT---------------------
    render() {
        if (!this.info)
            return html ``;
        if (!this.info.hasVariation)
            return html `This attribute has no variation`;
        return html `
            ${repeat(this.info.variations, ((key) => key.attr), ((k, index) => { return this.renderVariantItem(k); }))}  
            ${this.renderAddVariation(this.info)}  
        `;
    }
    renderVariantItem(v) {
        return html `
            <attrvariations>
                <label for="${v.attr}">${v.attr}</label>
                <input type="text" .info=${v} id="${v.attr}" value="${v.vl}" @keydown="${this.onKeydown}">
            </attrvariations>
        `;
    }
    renderAddVariation(info) {
        const array = Object.keys(this.languages);
        if (array.length <= 1)
            return;
        return html ` 
            <addvariation .info=${info}>
                <addvariationitem>
                    <select>
                        ${repeat(array, ((key) => key), ((k, index) => { return this.renderOptVariant(k, index); }))}
                    </select>
                    <button @click="${this.clickAddVariation}">+</button>
                </addvariationitem>
            </addvariation>
        
        `;
    }
    renderOptVariant(v, index) {
        let stl = '';
        const i = this.languages[v];
        let item = i.name;
        if (index === 0) {
            stl = 'display:none';
            item = '';
        }
        return html `
            <option value="${v}" style="${stl}">${item}</option>
        
        `;
    }
    //---------IMPLEMENTATION-----------------
    async init() {
        this.setLanguages();
    }
    clickAddVariation(e) {
        e.preventDefault();
        e.stopPropagation();
        const elBtn = e.target;
        const father = elBtn.closest('addvariation');
        const sel = father?.querySelector('select');
        const info = father.info;
        const l = this.languages[sel.value];
        if (!elBtn || !father || !sel || !info || !this.elIca)
            return;
        const key = info.attr + '-' + l.acronym;
        const vl = this.elIca.getAttribute(key);
        if (vl) {
            return;
        }
        this.elIca.setAttribute(key, l.name);
        dispatchEventConciliate();
        const evento = new CustomEvent('setconfig', {
            detail: { vl: `fatherforceUpdate`, me: this },
            bubbles: true,
            composed: true,
        });
        this.dispatchEvent(evento);
    }
    onKeydown(e) {
        e.stopPropagation();
        clearTimeout(this.timeKeydown);
        const el = e.target;
        if (!el)
            return;
        this.timeKeydown = setTimeout(() => {
            if (!this.elIca)
                return;
            const info = el.info;
            this.elIca.setAttribute(info.attr, el.value);
            dispatchEventConciliate();
            this.elIca.requestUpdate();
        }, 500);
    }
    async setLanguages() {
        const { project } = mls.actual[5];
        if (!project) {
            this.languages = {
                'English': { acronym: 'en', name: 'English' }
            };
        }
        else {
            const config = await getConfigProject(project);
            if (!config || !config.languages || config.languages.length === 0) {
                this.languages = {
                    'English': { acronym: 'en', name: 'English' }
                };
            }
            else {
                config.languages.forEach((entry, index) => {
                    this.languages[`${entry.name}`] = {
                        acronym: entry.language,
                        name: entry.name,
                    };
                });
            }
        }
    }
};
__decorate([
    property()
], WCDToolboxItemActionEditAttrOut.prototype, "info", void 0);
WCDToolboxItemActionEditAttrOut = __decorate([
    customElement('wcd-toolbox-item-action-edit-variation-100554')
], WCDToolboxItemActionEditAttrOut);
export { WCDToolboxItemActionEditAttrOut };
