/// <mls shortName="aimChatMessages" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaLitElement, propertyDataSource } from './_100554_icaLitElement';
import * as chatHelper from './_100554_aimChatHelper';
import * as chatMock from './_100554_aimChatMock';
/// **collab_i18n_start** 
const message_pt = {
    lazyLoading: 'Carregar mais ...',
    unreadMessages: 'Mensagens não lidas',
};
const message_en = {
    lazyLoading: 'Load more ...',
    unreadMessages: 'Mensages not read',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let AimChatMessages100554 = class AimChatMessages100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aim-chat-messages-100554 .chat-container{display:flex;flex-direction:column;padding:10px;width:99%;height:99%;overflow-y:auto;max-height:100%;background:linear-gradient(to bottom, #111, #333)}aim-chat-messages-100554 .unread-label{text-align:center;font-size:.95rem;color:var(--error-color);margin:10px 0;font-weight:bold}aim-chat-messages-100554 .message-group{display:contents}aim-chat-messages-100554 .message-time{text-align:center;font-size:.85rem;color:gray;margin-bottom:5px}aim-chat-messages-100554 .message{padding:10px;border-radius:10px;background-color:#f1f1f1;max-width:90%;align-self:flex-start}aim-chat-messages-100554 .message.user{background-color:#daf8cb;align-self:flex-end;text-align:right;display:block;margin-right:20px}aim-chat-messages-100554 .lazyloading{text-align:center;padding:10px;background-color:var(--info-color);border:1px solid #ddd;cursor:pointer;border-radius:5px;font-size:14px;color:#333;max-width:20em}aim-chat-messages-100554 .lazyloading:hover{background-color:var(--info-color-hover)}`);
        this.offsetUnread = 3000;
        this.minVisibleGroups = 20000;
        this.lazyLoadingOffset = 0;
        this.scrollToUnreadMessages = true;
        this.msg = messages['en'];
    }
    firstUpdated() {
        this.scrollMessages();
    }
    updated() {
        this.scrollMessages();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const currentUser = chatMock.currentUser;
        const roomId = Number(this.activeRoom) || 0;
        const fm = this.groupMessagesByUserAndDate(currentUser, roomId);
        const rc = html `    
        <div class="chat-container">
        ${this.renderLazyLoadingIfNeed(fm.showLazyLoading)}
        ${fm.groups.map((group, index) => {
            const isUser = group.sender === currentUser.username;
            const showDateHeader = index === 0 ||
                (group.date && fm.groups[index - 1]?.date?.toDateString() !== group.date.toDateString());
            return html `
              ${showDateHeader
                ? html `<div class="message-time">${chatHelper.formatMessageTime(group.date)}</div>`
                : ''}
              ${group.showUnreadTitle
                ? html `<div class="unread-label" id="unread-${group.messagesId[0]}">${this.msg.unreadMessages}</div>`
                : ''}
              <aim-chat-message-100554
                class="${isUser ? 'user' : 'other'}" 
                .isUser="${isUser}"
                .messages="${group.messagesId.map((id) => fm.messages.find((msg) => msg.id === id))}"
              ></aim-chat-message-100554>
            `;
        })}
      </div>
      `;
        return rc;
    }
    renderLazyLoadingIfNeed(showLazyLoading) {
        if (!showLazyLoading)
            return html ``;
        return html `
        <div class="lazyloading"
        @click=${() => {
            this.lazyLoadingOffset = this.lazyLoadingOffset + 10;
            this.scrollToUnreadMessages = false;
            this.requestUpdate();
        }}>${this.msg.lazyLoading}</div>
    `;
    }
    readMessages(currentUser, roomId) {
        return chatHelper.getMessages(currentUser, chatMock.getRooms(), roomId);
    }
    getGroupsToRender(fm) {
        // this.offsetUnread = 5; -> min start on 5 groups before unread
        // this.minVisibleMessages = 200; -> min visible groups
        // lazyLoadingOffset = 0; -> start on 0, add after 'load More'
        if (fm.groups.length === 0)
            return fm;
        const unreadIndex = fm.groups.findIndex((group) => group.showUnreadTitle);
        const startGroupIndex = unreadIndex > -1
            ? Math.max(unreadIndex - this.offsetUnread - this.lazyLoadingOffset, 0)
            : Math.max(fm.groups.length - this.minVisibleGroups - this.lazyLoadingOffset, 0);
        const endGroupIndex = Math.min(startGroupIndex + this.minVisibleGroups, fm.groups.length);
        fm.groups = fm.groups.slice(startGroupIndex, endGroupIndex);
        if (startGroupIndex > 0)
            fm.showLazyLoading = true;
        return fm;
    }
    groupMessagesByUserAndDate(currentUser, roomId) {
        const fm = {
            lastSeen: currentUser.lastSeenChats[roomId] || new Date(0),
            showLazyLoading: false,
            messages: this.readMessages(currentUser, roomId),
            groups: []
        };
        if (fm.messages.length === 0)
            return fm;
        let currentGroup = null;
        let unreadTitleSet = false;
        for (let i = 0; i < fm.messages.length; i++) {
            const message = fm.messages[i];
            const messageDate = message.timestamp.toDateString();
            const isFirstUnread = !unreadTitleSet && message.timestamp > fm.lastSeen;
            if (isFirstUnread)
                unreadTitleSet = true;
            if (currentGroup &&
                currentGroup.sender === message.sender &&
                !isFirstUnread &&
                messageDate === fm.messages[i - 1].timestamp.toDateString()) {
                currentGroup.messagesId.push(message.id);
            }
            else {
                if (currentGroup)
                    fm.groups.push(currentGroup);
                currentGroup = {
                    showUnreadTitle: isFirstUnread,
                    date: new Date(message.timestamp),
                    messagesId: [message.id],
                    sender: message.sender,
                };
            }
        }
        if (currentGroup)
            fm.groups.push(currentGroup);
        return this.getGroupsToRender(fm);
    }
    shouldDisplayTime(prevMessage, currentMessage) {
        const dt1 = chatHelper.formatMessageTime(prevMessage.timestamp);
        const dt2 = chatHelper.formatMessageTime(currentMessage.timestamp);
        return dt1 !== dt2;
    }
    scrollMessages() {
        // scrool to unread messages ou start
        if (!this.scrollToUnreadMessages)
            return;
        const unreadLabel = this.renderRoot.querySelector('.unread-label');
        if (unreadLabel) {
            const el = unreadLabel.previousElementSibling || unreadLabel;
            el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
};
__decorate([
    propertyDataSource({ type: Number })
], AimChatMessages100554.prototype, "activeRoom", void 0);
__decorate([
    propertyDataSource({ type: Number })
], AimChatMessages100554.prototype, "activeMessage", void 0);
__decorate([
    propertyDataSource({ type: String, reflect: true })
], AimChatMessages100554.prototype, "activeFilterRooms", void 0);
AimChatMessages100554 = __decorate([
    customElement('aim-chat-messages-100554')
], AimChatMessages100554);
export { AimChatMessages100554 };
