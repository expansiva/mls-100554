/// <mls shortName="collabLogLine" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { collab_check, collab_circle_notch, collab_triangle_exclamation } from './_100554_collabIcons';
let CollabLogLine100554 = class CollabLogLine100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.text = '';
        this.status = 'inprogress';
        this.iconsByStatus = {
            inprogress: collab_circle_notch,
            error: collab_triangle_exclamation,
            finish: collab_check,
            waiting: collab_circle_notch
        };
    }
    render() {
        if (!this.text)
            return html ``;
        return html `
        <div status=${this.status}>
            <div>${this.iconsByStatus[this.status]}</div>
            <span>${this.text}</span>
        </div>`;
    }
};
CollabLogLine100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], CollabLogLine100554.prototype, "text", void 0);
__decorate([
    property()
], CollabLogLine100554.prototype, "status", void 0);
CollabLogLine100554 = __decorate([
    customElement('collab-log-line-100554')
], CollabLogLine100554);
export { CollabLogLine100554 };
