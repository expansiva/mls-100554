/// <mls shortName="litWhen" project="100554" enhancement="_blank" />
export function when(condition, trueCase, falseCase) {
    return condition ? trueCase() : falseCase?.();
}
