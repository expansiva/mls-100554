/// <mls shortName="libManagementCan" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export function addTest(path, fc) {
}
export function setState(path, value) {
}
export function verifyState(path, value) {
}
