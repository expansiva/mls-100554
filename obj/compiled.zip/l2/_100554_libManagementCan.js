/// <mls shortName="libManagementCan" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { globalState } from './_100554_collabState';
/** Guarda watchers ativos */
const activeWatchers = new Map();
/**
 * Inicializa ou atualiza o estado global em um caminho específico.
 */
export function initState(path, value) {
    let globalState = getState();
    const stateManager = getStateManager();
    if (!path)
        return;
    const keys = path.split('.');
    if (!globalState) {
        globalState = {};
    }
    keys.forEach((key, index) => {
        if (!globalState[key]) {
            globalState[key] = index === keys.length - 1 ? value : {};
        }
        else if (index === keys.length - 1 && typeof globalState[key] === 'object' && typeof value === 'object') {
            globalState[key] = { ...globalState[key], ...value };
        }
        globalState = globalState[key];
    });
    function setNestedState(currentPath, data) {
        if (typeof data !== 'object' || data === null) {
            stateManager.setState(currentPath, data);
            return;
        }
        if (Array.isArray(data)) {
            stateManager.setState(currentPath, data);
            return;
        }
        Object.entries(data).forEach(([key, val]) => {
            setNestedState(`${currentPath}.${key}`, val);
        });
    }
    setNestedState(path, value);
}
/**
 * Atualiza o estado em um caminho.
 */
export function setState(path, value) {
    const stateManager = getStateManager();
    stateManager.setState(path, value);
    return true;
}
/**
 * Espera até que o estado em `path` seja igual a `value`.
 * Se `timeout` for 0 ou undefined, espera indefinidamente.
 */
export async function waitingState(path, value, options) {
    const stateManager = getStateManager();
    const expected = normalizeValue(value);
    const timeout = options?.timeout ?? 0; // 0 = infinito
    const retryInterval = options?.retryInterval ?? 100;
    const startTime = Date.now();
    const initialValue = stateManager.getState(path);
    while (true) {
        const current = normalizeValue(stateManager.getState(path));
        if (current === expected) {
            return;
        }
        if (initialValue !== current) {
            throw new Error(`Value for state invalid: path "${path}", expected "${expected}", got "${current}"`);
        }
        if (timeout > 0 && Date.now() - startTime >= timeout) {
            throw new Error(`Timeout waiting for state: path "${path}", expected "${expected}", got "${current}"`);
        }
        await delay(retryInterval);
    }
}
/**
 * Vigia continuamente um estado. Se ele mudar de valor, lança erro.
 * Fica rodando até chamar `unwatchState` ou `clearWatchers`.
 */
export function watchState(path, expectedValue, options) {
    const stateManager = getStateManager();
    const expected = normalizeValue(expectedValue);
    const retryInterval = options?.retryInterval ?? 100;
    // Se já existe watcher para esse path, limpa
    if (activeWatchers.has(path)) {
        clearInterval(activeWatchers.get(path));
        activeWatchers.delete(path);
    }
    const interval = setInterval(() => {
        const current = normalizeValue(stateManager.getState(path));
        if (current !== expected) {
            clearInterval(interval);
            activeWatchers.delete(path);
            throw new Error(`Watch failed: path "${path}" changed. Expected "${expected}", got "${current}"`);
        }
    }, retryInterval);
    activeWatchers.set(path, interval);
}
/** Cancela observação de um path específico */
export function unwatchState(path) {
    if (activeWatchers.has(path)) {
        clearInterval(activeWatchers.get(path));
        activeWatchers.delete(path);
    }
}
/** Cancela todos os watchers ativos */
export function clearWatchers() {
    for (const interval of activeWatchers.values()) {
        clearInterval(interval);
    }
    activeWatchers.clear();
}
/**
 * Verifica estado com timeout opcional, retornando boolean em vez de erro.
 */
export async function verifyState(path, value, options) {
    try {
        await waitingState(path, value, options);
        return true;
    }
    catch {
        return false;
    }
}
/** Utils */
function normalizeValue(val) {
    return typeof val === "object" ? JSON.stringify(val) : String(val);
}
function delay(ms) {
    return new Promise(res => setTimeout(res, ms));
}
function getStateManager() {
    const stateManager = globalState.globalStateManagment;
    if (!stateManager)
        throw new Error('Invalid preview stateManagment');
    return stateManager;
}
function getState() {
    const state = globalState._ica;
    if (!state)
        throw new Error('Invalid preview stateManagment');
    return state;
}
