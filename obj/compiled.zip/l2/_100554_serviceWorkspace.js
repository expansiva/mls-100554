/// <mls shortName="serviceWorkspace" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import './_100554_pluginGithubL4Project';
import './_100554_pluginGithubL4Issues';
import './_100554_pluginConfigLinks';
let ServiceWorkspace100554 = class ServiceWorkspace100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-workspace-100554{display:block}`);
        this.msize = '';
        this.activeTab = 'ITasks';
        //----------SERVICE--------------------
        this.details = {
            icon: '&#xf4ce',
            state: 'foreground',
            position: 'left',
            tooltip: 'Workspace',
            visible: true,
            widget: '_100554_serviceWorkspace',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.menu = {
            title: '',
            main: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [
                    { text: 'Links', icon: 'f0c1' },
                    { text: 'Project', icon: 'f0ae' },
                    { text: 'Issues', icon: 'e5a0' },
                    { text: 'Requirements', icon: 'f0a6' },
                    { text: 'Chat', icon: 'f086' },
                ]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        //----------IMPLEMENTS------------------
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        this.activeTab = ISceneries[index];
    }
    onServiceClick(visible, reinit, el) {
    }
    //------------COMPONENT-----------------
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.visible)
            return;
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'msize') {
            const [width, height, top, left] = this.msize.split(',');
            if (height)
                this.style.height = height + 'px';
        }
        super.attributeChangedCallback(name, oldVal, newVal);
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'ILinks':
                return this.renderLinks();
            case 'ITasks':
                return this.renderTasks();
            case 'IBackLog':
                return this.renderBackLog();
            case 'IRequirements':
                return this.renderRequirements();
            case 'IChat':
                return this.renderChat();
            default:
                return html ``;
        }
    }
    createRenderRoot() {
        return this;
    }
    renderLinks() {
        return html `
        <plugin-config-links-100554 autoPrepare>
        </plugin-config-links-100554>`;
    }
    renderTasks() {
        return html `
        <plugin-github-l4-project-100554 autoclick="true">
        </plugin-github-l4-project-100554>`;
    }
    renderBackLog() {
        return html `
        <plugin-github-l4-issues-100554>
        </plugin-github-l4-issues-100554>`;
    }
    renderRequirements() {
        return html `
        <plugin-github-l4-issues-100554 labelfilter="feature request">
        </plugin-github-l4-issues-100554>`;
    }
    renderChat() {
        return html `
        <div style="padding:2rem">
            Here are the plugins that manage communication with the team, such as slack channels - under development
        </div>`;
    }
};
__decorate([
    property()
], ServiceWorkspace100554.prototype, "msize", void 0);
__decorate([
    property()
], ServiceWorkspace100554.prototype, "activeTab", void 0);
ServiceWorkspace100554 = __decorate([
    customElement('service-workspace-100554')
], ServiceWorkspace100554);
export { ServiceWorkspace100554 };
var ISceneries;
(function (ISceneries) {
    ISceneries[ISceneries["ILinks"] = 0] = "ILinks";
    ISceneries[ISceneries["ITasks"] = 1] = "ITasks";
    ISceneries[ISceneries["IBackLog"] = 2] = "IBackLog";
    ISceneries[ISceneries["IRequirements"] = 3] = "IRequirements";
    ISceneries[ISceneries["IChat"] = 4] = "IChat";
})(ISceneries || (ISceneries = {}));
