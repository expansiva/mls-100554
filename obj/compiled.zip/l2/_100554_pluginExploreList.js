/// <mls shortName="pluginExploreList" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, svg, repeat } from 'lit';
import { property, queryAll } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { selectLevel, forceServiceInstance } from './_100554_libCommom';
/// **collab_i18n_start**
const message_pt = {
    updateListVerify: "atualizar lista/verificar",
    update: "atualizar",
    addNewFile: "adicionar novo arquivo",
    filter: "Filtrar",
    localProject: "Projeto local",
    totalFiles: "arquivos totais",
    filesWithErrors: "arquivos com erros",
    filesInLocalStorage: "arquivos no armazenamento local",
    filesChangedOnTheServer: "arquivos alterados no servidor",
    history: "Histórico",
    undo: "desfazer",
    clone: "clonar",
    rename: "renomear",
    delete: "excluir"
};
const message_en = {
    updateListVerify: 'update list/ verify',
    update: 'update',
    addNewFile: 'add new file',
    filter: 'Filter',
    localProject: 'Local project',
    totalFiles: 'total files',
    filesWithErrors: 'files with errors',
    filesInLocalStorage: 'file in local storage',
    filesChangedOnTheServer: 'files changed on the server',
    history: 'History',
    undo: 'undo',
    clone: 'clone',
    rename: 'rename',
    delete: 'delete',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "List",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
export class PluginExploreList extends PluginBaseModule {
    constructor() {
        super();
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.mode = 'list';
        this.position = 'left';
        this.levelFiles = 2;
        this.project = 1;
        this.projectLabel = '1';
        this.errorAux = '';
        this.files = [];
        this.history = [];
        this.info = {
            tot: 0,
            version: 0,
            storage: 0,
            error: 0,
        };
        this.onMLSEvents = async (ev) => {
            if (![1, 2, 3, 4, 5].includes(ev.level) || (ev.type !== 'FileAction'))
                return;
            const fileAction = JSON.parse(ev.desc);
            if (fileAction.position !== this.position ||
                !['statusOrErrorChanged', 'projectListChanged'].includes(fileAction.action) ||
                fileAction.project === 0)
                return;
            this.init();
        };
        this.fireEventThisProject = 0;
        this.changeListTimeout = 0;
        //------------ IMPLEMENTS -----------------
        this.extensionLevel = {
            2: '.ts',
            4: '.html'
        };
        this.inFilter = false;
        this.timeFilterChange = 0;
        this.setEvents();
    }
    async prepare() {
        this.init();
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
        forceServiceInstance(2, '_100554_serviceSource');
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('mode') && this.mode === 'list') {
            this.init();
        }
    }
    async showAdd() {
        await import('./_100554_serviceListFilesAdd');
        this.inFilter = false;
        this.mode = 'add';
    }
    setEvents() {
        mls.events.addEventListener([2, 5], ['ProjectSelected'], (ev) => {
            if (this.project === mls.actual[5].project)
                return;
            this.init();
        });
        mls.events.addListener(5, 'FileAction', (ev) => {
            if ((ev.type !== 'FileAction'))
                return;
            // if (this.visible === undefined || this.visible === null || (this.visible && this.visible === 'false')) return;
            const fileAction = JSON.parse(ev.desc);
            if (!['projectListChanged'].includes(fileAction.action))
                return;
            this.init();
        });
        mls.events.addListener(2, 'FileAction', this.onMLSEvents.bind(this));
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.mode === 'list') {
            return html `
            <div class="contentServiceList scroll-custom">
                ${this.renderHeader()}
                <ul>
                    ${this.renderHistory()}
                    ${this.renderList()}
                </ul>
                ${this.renderAuxEdit()}
            </div>
        `;
        }
        else {
            return html `${this.renderAdd()}`;
        }
    }
    renderHeader() {
        let auxV = '';
        let auxE = '';
        let auxS = '';
        if (this.info.version > 0) {
            auxV = `<b>[${this.info.version}]</b> <span class="fa fa-unbalanced"></span> <b>${this.msg.filesChangedOnTheServer}, </b>`;
        }
        if (this.info.error > 0) {
            auxE = `<b>[${this.info.error}]</b> <span class="fa fa-bug"></span><b>${this.msg.filesWithErrors},</b>`;
        }
        if (this.info.storage > 0) {
            auxS = `<b>[${this.info.storage}]</b> <span class="fa fa-location-dot"></span> <b>${this.msg.filesInLocalStorage}.</b>`;
        }
        //verifyChangeInList
        return html `
        <div class="groupHeader">
            <div class="groupAction"> 
                <a @click="${this.verifyChangeInList}" id="listUpdateFiles">${this.msg.updateListVerify}</a>
                <a @click="${this.showAdd}">${this.msg.addNewFile}</a>

            </div>
            <div class="groupFilter">
                
                    <form>
                        <div class="groupFilterRadio">
                            <input id="radioProjectActual" name="projectFind" type="radio" checked="checked" value="${this.projectLabel}" @click="${this.clickRadioProjectActual}">
                            <label for="radioProjectActual">${this.projectLabel}</label>
                            <input id="radioProjectZero" name="projectFind" type="radio" value="0" @click="${this.clickRadioProject0}">
                            <label for="radioProjectZero">${this.msg.localProject}</label>
                        </div>
                    </form>
                <input name="projectFilter" type="text" placeholder="Filter" @input="${this.filterLiChange}">
            </div>
            <div class="groupInfo">
                <span style="margin-right:10px">
                    [${this.info.tot}]
				    <span class="fa fa-file"></span> 
                    ${this.msg.totalFiles}
                </span>
                ${auxV ? html `<span .innerHTML="${auxV}" style="margin-right:10px"></span>` : ''}
                ${auxE ? html `<span .innerHTML="${auxE}" style="margin-right:10px"></span>` : ''}
                ${auxS ? html `<span .innerHTML="${auxS}" style="margin-right:10px"></span>` : ''}
            </div>
        </div>
        `;
    }
    renderHistory() {
        return html `
            ${this.history.length <= 0 ? '' :
            html `
                    <li class="headerTitle">
                        ${+this.project === 0 ? `${this.msg.history} (All Projects)` : `${this.msg.history}`}
                    </li>
                    ${repeat(this.history, ((item) => item.shortName), ((file, index) => this.renderLiItem(file, index, true)))}
                `}
        `;
    }
    renderList() {
        let letterInit = '';
        return html `
            ${this.files.length <= 0 ? '' :
            html `
                    ${repeat(this.files, ((item) => item.shortName), ((file, index) => {
                if (letterInit !== file.shortName.charAt(0).toUpperCase()) {
                    letterInit = file.shortName.charAt(0).toUpperCase();
                    return html `
                                    <li class="headerTitle">${letterInit} </li>
                                    ${this.renderLiItem(file, index, false)}
                                `;
                }
                return this.renderLiItem(file, index, false);
            }))}
                `}
        `;
    }
    renderAuxEdit() {
        return html `
            <div class="elContentAux" style="display:none" @click="${this.clickOptStop}">
                <div class="elContentAux2">
                    <form>
                        <span class="spanPrj">
                            <input name="projectEdit1" style="width: 80px;" .value="${this.project}" @click="${this.clickOptStop}">
                        </span>
                        <span class="spanName">
                            <input name="projectEdit2" @click="${this.clickOptStop}">
                        </span>
                    </form>
                    <button class="btnActCloneRename fa fa-file-pen" style="margin: 4px 0px;"></button>
                    <button class="fa fa-ban" title="cancel" @click="${this.clickHiddenAux}" style="margin: 4px 0px;"></button>
                </div>
                <div class="showError"style="color: red; font-size: 10px;">${this.errorAux}</div>
            </div>
        `;
    }
    renderLiItem(file, index, inHistory) {
        const name = this.project === 0 && inHistory ? '_' + file.project + '_' + file.shortName : file.shortName;
        const nameFilter = inHistory ? '*******' : name.toLocaleLowerCase();
        let auxVersion = '';
        let auxStorage = '';
        let auxBug = '';
        let auxHtml = '';
        const keyHtml = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, '.html');
        const keyStyle = mls.stor.getKeyToFiles(file.project, file.level, file.shortName, file.folder, '.less');
        const styleFile = mls.stor.files[keyStyle];
        const htmlFile = mls.stor.files[keyHtml];
        const htmlLocal = htmlFile && mls.stor.files[keyHtml].inLocalStorage;
        const styleLocal = styleFile && mls.stor.files[keyStyle].inLocalStorage;
        const htmlError = htmlFile && htmlFile.hasError;
        const styleError = styleFile && styleFile.hasError;
        if (file.inLocalStorage) {
            const titleLocalStorage = `.ts${htmlLocal ? ', .html' : ''} ${styleLocal ? ', .less' : ''} `;
            auxStorage = `<span title=" ${titleLocalStorage} in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        else if (htmlLocal) {
            auxStorage = `<span title=".html in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        else if (styleLocal) {
            auxStorage = `<span title=".less in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.hasError || styleError || htmlError) {
            auxBug = `<span title="bug" class="fa fa-bug" style="color:rgb(169, 3, 3); height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.isLocalVersionOutdated) {
            auxVersion = `<span title="need conciliation" class="fa fa-unbalanced" style="color:orange; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        const style = this.inFilter && inHistory ? 'display:none' : '';
        const actualL2 = mls.actual[2][this.position]?.shortName;
        return html `
            <li @click="${this.clickOptOpen}" class="${file.shortName === actualL2 ? 'selected' : ''}" style="${style}" .myFile=${file} .nameFilter="${nameFilter}">
                <div class="elContent">
                    <div class="groupHiddenList" @click="${this.clickGroupHidden}">
                        <span class="mls-gpbtnslider-item fa fa-undo" title="${this.msg.undo}" @click="${this.clickOptUndo}"></span>
                        <span class="mls-gpbtnslider-item fa fa-clone" title="${this.msg.clone}" @click="${this.clickOptClone}"></span>
                        <span class="mls-gpbtnslider-item fa fa-file-pen" title="${this.msg.rename}" @click="${this.clickOptRename}"></span>
                        <span class="mls-gpbtnslider-item fa fa-trash" title="${this.msg.delete}" @click="${this.clickOptDel}"></span>
                    </div>
                    <span class="${file.status === 'deleted' ? 'fileDeleted' : ''}">${name}</span>
                    <div style="display:flex; gap:.5rem" .innerHTML="${auxStorage + auxBug + auxVersion + auxHtml}"></div>
                </div>
            </li>
        `;
    }
    renderAdd() {
        return html `<service-list-files-add-100554 level="${this.levelFiles}" position="${this.position}" .father="${this}"></service-list-files-add-100554>`;
    }
    //------------ EVENTOS -----------------
    clickOptUndo(e) {
        e.stopPropagation();
        const mfile = this.getMyFileInElement(e.target);
        if (!mfile)
            return;
        this.fireEvents('undo', mfile, {});
    }
    clickOptDel(e) {
        e.stopPropagation();
        const mfile = this.getMyFileInElement(e.target);
        if (!mfile)
            return;
        this.fireEvents('delete', mfile, {});
    }
    async clickOptOpen(e) {
        e.stopPropagation();
        const target = e.target;
        const li = target.closest('li');
        this.lis?.forEach((l) => l.classList.remove('selected'));
        if (li)
            li.classList.add('selected');
        const mfile = this.getMyFileInElement(e.target);
        if (!mfile)
            return;
        this.setHistory(mfile);
        selectLevel(2);
        this.fireEvents('open', mfile, {});
    }
    clickOptRename(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.clickOptRenameClone(el, 'rename');
    }
    clickOptClone(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.clickOptRenameClone(el, 'clone');
    }
    clickOptRenameClone(el, mode) {
        if (!el)
            return;
        const myfile = this.getMyFileInElement(el);
        if (!myfile)
            return;
        const father = el.closest('.contentServiceList');
        const li = el.closest('li');
        if (!father || !li)
            return;
        const elContentAux = father.querySelector('.elContentAux');
        const btnActCloneRename = father.querySelector('.btnActCloneRename');
        const iptProj = elContentAux.querySelector('.spanPrj input');
        const iptName = elContentAux.querySelector('.spanName input');
        if (!father || !li)
            return;
        li.appendChild(elContentAux);
        elContentAux.style.display = '';
        iptProj.value = mls.actual[5].project;
        iptName.value = '';
        btnActCloneRename.onclick = async (e2) => {
            try {
                e2.stopPropagation();
                this.validInputsAux(myfile, { mode: mode, project: iptProj.value, name: iptName.value });
                this.fireEvents(mode, myfile, { project: +iptProj.value, shortName: iptName.value });
                elContentAux.style.display = 'none';
                const all = this.shadowRoot?.querySelectorAll('.activegpbtnslider');
                Array.from(all).forEach((i) => i.classList.remove('activegpbtnslider'));
            }
            catch (er) {
                this.errorAux = er.message;
                setTimeout(() => { this.errorAux = ''; }, 2000);
            }
        };
    }
    fireEvents(action, file, info, timeout = 0) {
        const params = {};
        params.action = action;
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = file.extension;
        params.folder = file.folder;
        params.position = this.position;
        if (info && info.shortName) {
            params.newshortName = info.shortName;
            params.newProject = info.project;
            params.newfolder = file.folder;
        }
        if (['open'].includes(action)) {
            mls.actual[this.levelFiles].setFullName(`_${file.project}_${file.shortName}`);
            mls.actual[this.levelFiles][this.position] = {
                project: file.project,
                shortName: file.shortName,
                extension: file.extension,
                folder: file.folder,
            };
        }
        mls.events.fire([+this.levelFiles], ['FileAction'], JSON.stringify(params), timeout);
        if (['open'].includes(action))
            return;
        this.changeList(100);
    }
    fireEventLoadProject() {
        if (this.fireEventThisProject === mls.actual[5].project)
            return;
        this.fireEventThisProject = mls.actual[5].project;
        const info = {};
        info.project = mls.actual[5].project;
        info.level = 2;
        info.needCompile = true;
        mls.events.fire([+this.levelFiles], ['ProjectLoaded'], JSON.stringify(info), 0);
    }
    changeList(time = 500) {
        clearTimeout(this.changeListTimeout);
        this.changeListTimeout = setTimeout(async () => {
            await this.init();
        }, time);
    }
    async init() {
        this.info.tot = 0;
        this.info.version = 0;
        this.info.storage = 0;
        this.info.error = 0;
        this.project = mls.actual[5].project;
        this.projectLabel = this.project.toString();
        this.fireEventLoadProject();
        await this.getFiles();
    }
    getMyFileInElement(el) {
        el = el.closest('li');
        if (!el || !el['myFile'])
            return;
        const mfile = el['myFile'];
        return mfile;
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        if (el.classList.contains('activegpbtnslider')) {
            const li = el.closest('li');
            const elContentAux = li.querySelector('.elContentAux');
            if (elContentAux)
                elContentAux.style.display = 'none';
        }
        el.classList.toggle('activegpbtnslider');
    }
    clickHiddenAux(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const elContentAux = el.closest('.elContentAux');
        if (!elContentAux)
            return;
        const iptProj = elContentAux.querySelector('.spanPrj input');
        const iptName = elContentAux.querySelector('.spanName input');
        if (iptName)
            iptName.value = '';
        if (iptProj)
            iptProj.value = this.project.toString();
        elContentAux.style.display = 'none';
    }
    clickOptStop(e) {
        e.stopPropagation();
    }
    async clickRadioProject0(e) {
        this.info.tot = 0;
        this.info.version = 0;
        this.info.storage = 0;
        this.info.error = 0;
        this.project = 0;
        await this.getFiles();
    }
    clickRadioProjectActual(e) {
        this.info.tot = 0;
        this.info.version = 0;
        this.info.storage = 0;
        this.info.error = 0;
        this.project = mls.actual[5].project;
        this.getFiles();
    }
    filterLiChange(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        clearTimeout(this.timeFilterChange);
        this.timeFilterChange = setTimeout(() => {
            this.inFilter = el.value.length > 0;
            const contentServiceList = el.closest('.contentServiceList');
            if (!contentServiceList)
                return;
            const all = contentServiceList.querySelectorAll('li');
            all.forEach((li) => {
                const name = li.nameFilter ? li.nameFilter : '******';
                const inp = el.value.toLocaleLowerCase();
                if (name.indexOf(inp) >= 0) {
                    li.style.display = '';
                }
                else {
                    li.style.display = 'none';
                }
            });
        }, 500);
    }
    async verifyChangeInList(e) {
        try {
            await this.verifyChangeInList2(e);
        }
        catch (e) {
        }
    }
    async verifyChangeInList2(e) {
        try {
            e.stopPropagation();
            const el = e.target;
            if (!el)
                return;
            const isClick = el.innerText === 'updated';
            if (isClick)
                return;
            el.innerText = 'updated';
            await mls.stor.server.loadProjectInfoIfNeeded(mls.actual[5].project, true);
            const key = Object.keys(mls.stor.files)?.filter((item) => item.indexOf(mls.actual[5].project.toString()) >= 0);
            if (key.length > 0) {
                this.fireEvents('projectListChanged', mls.stor.files[key[0]], {}, 500);
                mls.events.fireFileAction('updatedOnServer', mls.stor.files[key[0]], 'left', undefined, undefined, undefined, undefined, 600);
            }
            this.changeList(500);
            setTimeout(() => {
                if (!this)
                    return;
                el.innerText = 'update list/ verify';
            }, 50000);
        }
        catch (e) {
            console.info('Error verifyChangeInList2:' + e.message);
        }
    }
    async getFiles() {
        try {
            const arraySf = this.getFilesProject();
            const arraySfHistory = await this.getFileHistory();
            this.files = [...arraySf];
            this.history = [...arraySfHistory];
        }
        catch (e) {
            console.info(e);
        }
    }
    getFilesProject() {
        if (!window['mls'])
            return [];
        const arraySf = [];
        const ext = this.extensionLevel[this.levelFiles];
        for (const i of Object.keys(mls.stor.files).sort()) {
            const sf = mls.stor.files[i];
            if (sf.project !== this.project ||
                sf.level !== +this.levelFiles ||
                sf.extension !== ext)
                continue;
            this.info.tot++;
            if (sf.isLocalVersionOutdated)
                this.info.version++;
            if (sf.inLocalStorage)
                this.info.storage++;
            if (sf.hasError)
                this.info.error++;
            arraySf.push(sf);
        }
        return arraySf;
    }
    async getFileHistory() {
        if (!window['mls'])
            return [];
        const arraySfHistory = [];
        const lh = this.getHistory();
        if (lh.length <= 0 || !window['mls'])
            return [];
        for await (const i of lh) {
            let key = mls.stor.getKeyToFiles(i.project, this.levelFiles, i.shortName, i.folder, i.extension);
            if (!mls.stor.files[key] && +this.project === 0) {
                await mls.stor.server.loadProjectInfoIfNeeded(i.project);
                key = mls.stor.getKeyToFiles(i.project, this.levelFiles, i.shortName, i.folder, i.extension);
            }
            if (!mls.stor.files[key] || (i.project !== +this.project && +this.project !== 0))
                continue;
            arraySfHistory.push(mls.stor.files[key]);
        }
        return arraySfHistory;
    }
    getHistory() {
        const info = localStorage.getItem('mlsInfoHistoryL' + this.levelFiles);
        return info ? JSON.parse(info) : [];
    }
    setHistory(file) {
        const info = localStorage.getItem('mlsInfoHistoryL' + this.levelFiles);
        const res = info ? JSON.parse(info) : [];
        let idx = -1;
        res.forEach((i, index) => {
            if (i.project !== file.project || i.shortName !== file.shortName)
                return;
            idx = index;
        });
        if (idx >= 0) {
            res.splice(idx, 1);
        }
        res.unshift({ project: file.project, shortName: file.shortName, extension: file.extension, folder: file.folder });
        if (res.length > 10) {
            for (let i = res.length - 1; i >= 0; i--) {
                if (res.length <= 10)
                    break;
                const key = mls.stor.getKeyToFiles(res[i].project, this.levelFiles, res[i].shortName, res[i].folder, res[i].extension);
                if (!mls.stor.files[key]) {
                    res.splice(i, 1);
                }
                else if (mls.stor.files[key] && mls.stor.files[key].status === 'nochange' && mls.stor.files[key].shortName !== file.shortName) {
                    res.splice(i, 1);
                }
            }
        }
        localStorage.setItem('mlsInfoHistoryL' + this.levelFiles, JSON.stringify(res));
    }
    validInputsAux(file, action) {
        if (file.hasError && ['clone', 'rename'].includes(action.mode))
            throw new Error('It is not possible to perform this action on files with an error.');
        if (!this.isValidNewName(file, action))
            throw new Error('Invalid name');
    }
    isValidNewName(file, action) {
        if (action.project === '' || action.name === '')
            return false;
        if (action.name.length === 0 || action.name.length > 255)
            return false;
        const invalidCharacters = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        if (invalidCharacters.test(action.name))
            return false;
        const key = mls.stor.getKeyToFiles(+action.project, this.levelFiles, action.name, file.folder, file.extension);
        return !mls.stor.files[key];
    }
}
PluginExploreList.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property({ type: Boolean })
], PluginExploreList.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "mode", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "position", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "levelFiles", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "project", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "projectLabel", void 0);
__decorate([
    property()
], PluginExploreList.prototype, "errorAux", void 0);
__decorate([
    property({ type: Array })
], PluginExploreList.prototype, "files", void 0);
__decorate([
    property({ type: Array })
], PluginExploreList.prototype, "history", void 0);
__decorate([
    queryAll('li')
], PluginExploreList.prototype, "lis", void 0);
if (!customElements.get('plugin-explore-list-100554')) {
    customElements.define('plugin-explore-list-100554', PluginExploreList);
}
