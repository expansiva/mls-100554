/// <mls shortName="wcdOverlayLitBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
export class WcdOverlayLitBase extends CollabLitElement {
    constructor() {
        super();
        this.level = mls.actualLevel.toString() || '7';
        this.myItens = [];
        document.onkeydown = (e) => { this.onkeyDown(e); };
    }
    //------------COMPONENT---------------
    createRenderRoot() {
        return this; // dont use shadow root
    }
    onkeyDown(e) {
        e.stopPropagation();
        let el = this.querySelector('wcd-toolbox-100554');
        const param = {
            args: e,
            overlay: this,
            selectedIca: undefined
        };
        if (!el) {
            if (this.myKeyEvents[e.key])
                this.myKeyEvents[e.key](param);
            return;
        }
        el = el.parentElement;
        if (!el.info) {
            if (this.myKeyEvents[e.key])
                this.myKeyEvents[e.key](param);
            return;
        }
        el = el.info?.element;
        if (this.myKeyEvents[e.key]) {
            param.selectedIca = el;
            this.myKeyEvents[e.key](param);
        }
    }
}
__decorate([
    property({ type: String, reflect: true })
], WcdOverlayLitBase.prototype, "level", void 0);
export function getPosition(icaInfo, boundingPage) {
    const elBase = icaInfo.element;
    let { width, height } = icaInfo;
    const ad3 = (n1, s1, s2) => n1 + parseInt(s1, 10) + parseInt(s2, 10);
    const { marginTop, marginBottom, marginLeft, marginRight, paddingTop, paddingBottom, paddingLeft, paddingRight } = window.getComputedStyle(elBase);
    let left = icaInfo.x;
    let top = icaInfo.y;
    left -= parseInt(marginLeft, 10);
    top -= parseInt(marginTop, 10);
    width = Math.max(ad3(width, marginLeft, marginRight), ad3(0, paddingLeft, paddingRight));
    if (width > elBase.ownerDocument.body.clientWidth)
        width -= 3;
    height = Math.max(ad3(height, marginTop, marginBottom), ad3(0, paddingTop, paddingBottom));
    return {
        left: `${left - boundingPage.left}px`,
        top: `${top - boundingPage.top}px`,
        width: `${width}px`,
        height: `${height}px`
    };
}
