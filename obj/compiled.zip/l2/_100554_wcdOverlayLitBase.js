/// <mls shortName="wcdOverlayLitBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { getPosition } from './_100554_icaGlobal';
export class WcdOverlayLitBase extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.level = mls.actualLevel.toString() || '7';
        this.myItens = [];
        document.onkeydown = (e) => { this.onkeyDown(e); };
    }
    refreshOverlay() {
        throw new Error('Method not implemented.');
    }
    //------------COMPONENT---------------
    createRenderRoot() {
        return this; // dont use shadow root
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (typeof ResizeObserver !== 'undefined') {
            if (this.resizeObserver)
                this.resizeObserver.disconnect();
            this.resizeObserver = new ResizeObserver(entries => {
                if (this.timeoutResize)
                    clearTimeout(this.timeoutResize);
                this.timeoutResize = setTimeout(() => {
                    this.updateSizeOverlayItems();
                });
            });
            this.resizeObserver.observe(this);
        }
        this.updateSizeOverlayItems();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        const hasMsize = changedProperties.has('msize');
        if (changedProperties.has('globalVariation') && changedProperties.get('globalVariation') !== undefined) {
            setTimeout(() => this.updateSizeOverlayItems(), 500);
        }
        if (hasMsize) {
            if (this.timeoutResize)
                clearTimeout(this.timeoutResize);
            this.timeoutResize = setTimeout(() => {
                this.updateSizeOverlayItems();
            }, 50);
        }
    }
    onkeyDown(e) {
        e.stopPropagation();
        let el = this.querySelector('wcd-toolbox-100554');
        const param = {
            args: e,
            overlay: this,
            selectedIca: undefined
        };
        if (!el) {
            if (this.myKeyEvents[e.key])
                this.myKeyEvents[e.key](param);
            return;
        }
        if (this.myKeyEvents[e.key]) {
            param.selectedIca = el.elICA;
            this.myKeyEvents[e.key](param);
        }
    }
    createOverlayItems() {
        const boundingPage = this.getBoundingClientRect();
        this.innerHTML = '';
        this.myItens.forEach((item) => {
            item.element.setAttribute('level', this.level);
            this.createOverlayItem(item, this, boundingPage);
        });
        setTimeout(() => this.updateSizeOverlayItems(), 100);
    }
    changeOverlayItemsLevel() {
        if (!this)
            return;
        Array.from(this.children).forEach((item) => {
            item.setAttribute('level', this.level);
        });
    }
    createOverlayItem(icaInfo, content, boundingPage) {
        const icaOverlayItem = document.createElement(this.overlayItemTagName);
        icaOverlayItem.setAttribute('widget', icaInfo.element.tagName.toLowerCase());
        icaOverlayItem.setAttribute('level', this.level);
        icaOverlayItem.info = icaInfo;
        icaOverlayItem.boundingPage = boundingPage;
        content.appendChild(icaOverlayItem);
    }
    updateSizeOverlayItems() {
        requestAnimationFrame(() => {
            const items = Array.from(this.children);
            const boundingPage = this.getBoundingClientRect();
            items.forEach((item) => {
                if (!item.info)
                    return;
                const { x, y, height, width } = item.info.element.getBoundingClientRect();
                item.info.x = x;
                item.info.y = y;
                item.info.height = height;
                item.info.width = width;
                const pos = getPosition(item.info, boundingPage);
                item.style.width = pos.width;
                item.style.height = pos.height;
                item.style.top = pos.top;
                item.style.left = pos.left;
            });
        });
    }
}
__decorate([
    property({ type: String, reflect: true })
], WcdOverlayLitBase.prototype, "level", void 0);
__decorate([
    property({ type: String, reflect: true })
], WcdOverlayLitBase.prototype, "msize", void 0);
