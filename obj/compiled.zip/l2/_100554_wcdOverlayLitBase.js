/// <mls shortName="wcdOverlayLitBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
export class WcdOverlayLitBase extends CollabLitElement {
    constructor() {
        super();
        this.level = mls.actualLevel.toString() || '7';
        this.myItens = [];
        document.onkeydown = (e) => { this.onkeyDown(e); };
    }
    //------------COMPONENT---------------
    createRenderRoot() {
        return this; // dont use shadow root
    }
    onkeyDown(e) {
        e.stopPropagation();
        let el = this.querySelector('wcd-toolbox-100554');
        const param = {
            args: e,
            overlay: this,
            selectedIca: undefined
        };
        if (!el) {
            if (this.myKeyEvents[e.key])
                this.myKeyEvents[e.key](param);
            return;
        }
        el = el.parentElement;
        if (!el.info) {
            if (this.myKeyEvents[e.key])
                this.myKeyEvents[e.key](param);
            return;
        }
        el = el.info?.element;
        if (this.myKeyEvents[e.key]) {
            param.selectedIca = el; //as IcaLitElementBase;
            this.myKeyEvents[e.key](param);
        }
    }
}
__decorate([
    property({ type: String, reflect: true })
], WcdOverlayLitBase.prototype, "level", void 0);
