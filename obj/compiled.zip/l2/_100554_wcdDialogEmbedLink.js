/// <mls shortName="wcdDialogEmbedLink" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { execute } from './_100554_wcdCommandAddEmbedLink';
import { CollabLitElement } from './_100554_collabLitElement';
import { globalWcd } from './_100554_wcdState';
/// **collab_i18n_start**
const message_pt = {
    placeholder: 'cole um link para incorporar conteúdo de outro site e pressione Enter'
};
const message_en = {
    placeholder: 'paste a link to embed content from another site and press Enter'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdDialogEmbedLink100554 = class WcdDialogEmbedLink100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.link = '';
        this.msg = messages['en'];
    }
    async handleKeyDown(event) {
        event.stopPropagation();
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.myParent)
            throw new Error('Invalid window.wcdState.myParent');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        if (event.key === 'Enter') {
            await execute({
                args: { url: this.link },
                overlay: globalWcd.myParent?.parentElement?.parentElement,
                selectedIca: globalWcd.elICA,
            });
        }
    }
    handleInput(event) {
        event.stopPropagation();
        this.link = event.target?.value || '';
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.prompt)
            this.prompt.focus();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `

            <div class="container">
                <div class="prompt-content">
                    <input
                    @input=${this.handleInput.bind(this)} 
                    @keydown=${this.handleKeyDown.bind(this)} 
                    type="text" 
                    id="prompt-input"
                    placeholder=${this.msg.placeholder}
                    />
                </div>
        `;
    }
};
WcdDialogEmbedLink100554.styles = css `
        :host{
            display:block;
            width:100%;
        }
        .container{
            padding:1rem;
        }

        .prompt-content{
            padding: 10px;
            display:flex;
            margin-bottom:1rem;
        }

        .prompt-content input {
            border:none;
            border-bottom: 1px solid var(--grey-color);
            outline:none;
            width: 100%;
            display: block;
            font-size: 1rem;
            line-height: 1.5;
            color: #000000;
            background-color: #fff;
            background-clip: padding-box;
            border-radius: 0.25rem;
            transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        }
    `;
__decorate([
    query('#prompt-input')
], WcdDialogEmbedLink100554.prototype, "prompt", void 0);
WcdDialogEmbedLink100554 = __decorate([
    customElement('wcd-dialog-embed-link-100554')
], WcdDialogEmbedLink100554);
export { WcdDialogEmbedLink100554 };
