/// <mls shortName="icaGlobal" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export const PREFIX = 'ica';
export const PREFIXWCD = 'wcd';
export const ATTRGROUP = 'isicagroup';
export const ICAPAGE = 'ica-page-100554';
