/// <mls shortName="icaLayoutFlowColumn" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { IcaLitElementBase } from './_100554_icaLitElementBase';
let IcaLayoutFlowColumn = class IcaLayoutFlowColumn extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.mySymbol = 'fa-table-columns';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
    changeStateHtml(html) {
    }
    allowCommand(cmd, scope, target) {
        if (cmd === 'move')
            return this.commandMove(scope, target);
        return { inside: false, before: false, after: false };
    }
    commandMove(scope, target) {
        const activeInMe = this.querySelector('*[renderType="editactive"]');
        if (activeInMe && this.children.length <= 1)
            return { inside: false, before: false, after: false };
        const myScope = this.getMyScope();
        if (myScope !== scope)
            return { inside: false, before: false, after: false };
        const tag = target.tagName.toLocaleLowerCase();
        let inside = tag !== 'ica-row-100554' && tag !== 'ica-column-100554';
        if (activeInMe && this.children.length <= 1)
            inside = false;
        const parent = this.getIcaParent(this);
        const insideFather = parent && parent.tagName.startsWith('ICA-') ? parent.allowCommand('move', scope, target) : { inside: true };
        const before = insideFather.inside;
        const after = insideFather.inside;
        return { inside, before, after };
    }
};
IcaLayoutFlowColumn = __decorate([
    customElement('ica-layout-flow-column-100554')
], IcaLayoutFlowColumn);
export { IcaLayoutFlowColumn };
