/// <mls shortName="codeLensLit" project="100554" enhancement="_blank" />
// File: CodeLens
export function setCodeLens(mfile) {
    clearCodeLens(mfile);
    const { model, compilerResults } = mfile;
    const { decorators } = compilerResults;
    if (mfile.shortName === 'enhancementLit' && mfile.project === 100554)
        return;
    setCodeLensDecoratorClass(model, decorators);
    setCodeLensServiceDetails(model, mfile);
}
function clearCodeLens(mfile) {
    for (let slineNr in mfile.codeLens) {
        const codeLen = mfile.codeLens[slineNr];
        if (codeLen[0].id === 'helpAssistant') {
            mls.l2.codeLens.removeCodeLen(mfile.model, Number.parseInt(slineNr));
        }
    }
}
function setCodeLensDecoratorClass(model, decorators) {
    const objDecorators = JSON.parse(decorators);
    Object.entries(objDecorators).forEach((entrie) => {
        const decoratorInfo = entrie[1];
        if (!decoratorInfo || decoratorInfo.type !== 'ClassDeclaration')
            return;
        decoratorInfo.decorators.forEach((_decorator) => {
            if (_decorator.text.startsWith('customElement(')) {
                mls.l2.codeLens.addCodeLen(model, _decorator.line + 1, { id: 'helpAssistant', title: `customElement`, jsComm: '', refs: '_100554_pluginCodelensCustomElement' });
            }
        });
    });
}
async function setCodeLensServiceDetails(model, mfile) {
    const lines = findLinesByText(model, 'public details: IService');
    lines.forEach((line) => {
        mls.l2.codeLens.addCodeLen(model, line, { id: 'helpAssistant', title: `serviceDetails`, jsComm: '', refs: '_100554_pluginCodelensServiceDetails' });
    });
}
function findLinesByText(model, textToFind) {
    const lines = [];
    if (!model)
        return lines;
    const lineCount = model.getLineCount();
    for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
        const lineText = model.getLineContent(lineNumber);
        if (lineText.includes(textToFind)) {
            lines.push(lineNumber);
        }
    }
    return lines;
}
