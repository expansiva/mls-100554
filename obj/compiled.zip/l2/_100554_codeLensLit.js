/// <mls shortName="codeLensLit" project="100554" enhancement="_blank" />
// File: CodeLens
export function setCodeLens(model1) {
    clearCodeLens(model1);
    const { model, compilerResults, storFile } = model1;
    if (!storFile || !model || !compilerResults)
        return;
    const { decorators } = compilerResults;
    if (storFile.shortName === 'enhancementLit' && storFile.project === 100554)
        return;
    setCodeLensDecoratorClass(model, decorators);
    setCodeLensServiceDetails(model);
}
function clearCodeLens(model1) {
    for (let slineNr in model1.codeLens) {
        const codeLen = model1.codeLens[slineNr];
        if (codeLen[0].id === 'helpAssistant') {
            mls.l2.codeLens.removeCodeLen(model1.model, Number.parseInt(slineNr));
        }
    }
}
function setCodeLensDecoratorClass(model, decorators) {
    const objDecorators = JSON.parse(decorators);
    Object.entries(objDecorators).forEach((entrie) => {
        const decoratorInfo = entrie[1];
        if (!decoratorInfo || decoratorInfo.type !== 'ClassDeclaration')
            return;
        decoratorInfo.decorators.forEach((_decorator) => {
            if (_decorator.text.startsWith('customElement(')) {
                mls.l2.codeLens.addCodeLen(model, _decorator.line + 1, { id: 'helpAssistant', title: `customElement`, jsComm: '', refs: '_100554_pluginCodelensCustomElement' });
            }
        });
    });
}
async function setCodeLensServiceDetails(model) {
    const lines = findLinesByText(model, 'public details: IService');
    lines.forEach((line) => {
        mls.l2.codeLens.addCodeLen(model, line, { id: 'helpAssistant', title: `serviceDetails`, jsComm: '', refs: '_100554_pluginCodelensServiceDetails' });
    });
}
function findLinesByText(model, textToFind) {
    const lines = [];
    if (!model)
        return lines;
    const lineCount = model.getLineCount();
    for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
        const lineText = model.getLineContent(lineNumber);
        if (lineText.includes(textToFind)) {
            lines.push(lineNumber);
        }
    }
    return lines;
}
