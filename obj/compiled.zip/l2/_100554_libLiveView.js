/// <mls shortName="libLiveView" project="100554" enhancement="_blank" />
import { createAllModels } from './_100554_collabLibModel';
import { createStorFile } from './_100554_collabLibStor';
import { getGlobalCss, getTokensCss } from './_100554_designSystemBase';
import { getDependenciesByHtmlFile } from './_100554_libCompile';
import { getProjectConfig, getProjectModuleConfig } from './_100554_libCommom';
import { convertTagToFileName } from './_100554_utilsLit';
let esBuild;
export const DISTFOLDER = 'wwwroot';
export async function buildModule(project, moduleName) {
    await loadEsBuild();
    const moduleConfig = await getProjectModule(project, moduleName);
    const allPages = await getAllPages(project, moduleConfig.path) || [];
    let buildRequired = false;
    await prepareStyleFile(project, moduleConfig.theme);
    await prepareRunTimeFile(project);
    for (let storFiles of allPages) {
        let needBuild = false;
        const storFilesDist = getDistStorFile(storFiles.ts);
        if (!storFilesDist.storFileDistJs || !storFilesDist.storFileDistHtml)
            needBuild = true;
        else {
            const dtJsDist = new Date(storFilesDist.storFileDistJs.updatedAt || '');
            const dtHtmlDist = new Date(storFilesDist.storFileDistHtml.updatedAt || '');
            if (storFiles.ts.updatedAt &&
                storFiles.html.updatedAt) {
                const dtJs = new Date(storFiles.ts.updatedAt);
                const dtHtml = new Date(storFiles.html.updatedAt);
                if (dtJsDist < dtJs || dtHtmlDist < dtHtml)
                    needBuild = true;
                else
                    needBuild = false;
                if (storFilesDist.storFileDistJs.inLocalStorage &&
                    storFilesDist.storFileDistHtml.inLocalStorage &&
                    !storFiles.ts.inLocalStorage &&
                    !storFiles.html.inLocalStorage &&
                    dtJsDist > dtJs &&
                    dtHtml > dtHtml) {
                    mls.stor.localStor.setContent(storFilesDist.storFileDistHtml, { content: null });
                    mls.stor.localStor.setContent(storFilesDist.storFileDistJs, { content: null });
                    needBuild = true;
                }
                else if (!needBuild && !storFiles.html.inLocalStorage && !storFiles.ts.inLocalStorage) {
                    mls.stor.localStor.setContent(storFilesDist.storFileDistHtml, { content: null });
                    mls.stor.localStor.setContent(storFilesDist.storFileDistJs, { content: null });
                    needBuild = false;
                }
            }
            if (!needBuild) {
                needBuild = await checkOrganismInPageIsOutdated(storFiles.defs.references?.widgets || [], dtHtmlDist, dtJsDist, storFiles.html.inLocalStorage, storFiles.ts.inLocalStorage);
            }
        }
        if (needBuild) {
            buildRequired = true;
            await buildPage(storFiles.ts, storFiles.html, moduleConfig.theme);
        }
    }
    return buildRequired;
}
async function checkOrganismInPageIsOutdated(widgets, outdatedHtml, outdatedTs, outdatedHTMLLocal, outdatedTsLocal) {
    let needBuild = false;
    for (let widget of widgets) {
        if (!widget.used)
            continue;
        const fileInfo = convertTagToFileName(widget.tag);
        if (!fileInfo)
            continue;
        const { folder, project, shortName } = fileInfo;
        const storFiles = await mls.stor.getFiles({
            folder,
            project,
            shortName,
            level: 2,
            loadContent: false
        });
        if (storFiles.ts?.updatedAt) {
            const dtJs = new Date(storFiles.ts.updatedAt);
            if (outdatedTs < dtJs || (outdatedTs > dtJs && !outdatedTsLocal && storFiles.ts.inLocalStorage)) {
                needBuild = true;
                break;
            }
        }
        if (storFiles.html?.updatedAt) {
            const dtHtml = new Date(storFiles.html.updatedAt);
            if (outdatedHtml < dtHtml || (outdatedHtml > dtHtml && !outdatedHTMLLocal && storFiles.html.inLocalStorage))
                needBuild = true;
            break;
        }
    }
    return needBuild;
}
async function buildPage(storFileTs, storFileHtml, theme) {
    const { folder, project, shortName, level } = storFileTs;
    let models = mls.editor.getModels(project, shortName, folder, level);
    if (!models) {
        models = await createAllModels(storFileTs, true, true);
    }
    const html = await storFileHtml.getContent();
    if (!html || typeof html !== 'string')
        return;
    let data = await getDependenciesByHtmlFile(storFileHtml, html, theme, true);
    const importsMap = parseImportsMap(data.importsMap);
    const webcomponets = findWidgets(html);
    const valids = [...new Set([...Object.keys(importsMap), ...data.importsJs, ...webcomponets])];
    const result = await executeEsBuild(importsMap, valids, webcomponets, data.importsJs);
    generateOutput(storFileTs, html, result.outputFiles[0].text);
}
async function buildRunTimeFile(storFile) {
    const { folder, project, shortName, level } = storFile;
    let models = mls.editor.getModels(project, shortName, folder, level);
    if (!models) {
        models = await createAllModels(storFile, true, true);
    }
    let data = await getDependenciesByHtmlFile(storFile, '', '', true);
    const ts = await storFile.getContent();
    if (!ts || typeof ts !== 'string')
        return;
    const importsMap = parseImportsMap(data.importsMap);
    const valids = [...new Set([...Object.keys(importsMap), ...data.importsJs])];
    const result = await executeEsBuild(importsMap, valids, [], data.importsJs);
    generateOutputRunTime(project, result.outputFiles[0].text);
}
async function executeEsBuild(importsMap, valids, webcomponets, importsJs) {
    const virtualFsPlugin = {
        name: 'virtual-fs',
        setup(build) {
            build.onResolve({ filter: /.*/ }, (args) => {
                const transforPathInitId = (input) => {
                    let [idPart, ...restParts] = input.split('/');
                    if (input.startsWith('./')) {
                        idPart = restParts[0];
                        restParts.shift();
                    }
                    const rest = restParts.join('/');
                    const lastSlashIndex = rest.lastIndexOf('/');
                    const path = rest.substring(0, lastSlashIndex);
                    const file = rest.substring(lastSlashIndex + 1);
                    return `/${path}/${idPart}${file}`;
                };
                const isValidStart = (path) => {
                    return !path.startsWith("./l2/") && !path.startsWith("_") && !(path.startsWith("./_") && path.indexOf("/l2/") >= 0);
                };
                if (valids.includes(args.path)) {
                    return {
                        path: args.path,
                        namespace: 'virtual',
                    };
                }
                if (args.path.startsWith("./") &&
                    !args.importer.startsWith("https://") && isValidStart(args.path)) {
                    return {
                        path: args.path.replace('./', '/'),
                        namespace: 'virtual',
                    };
                }
                if ((args.path.startsWith("./") ||
                    args.path.startsWith("../") ||
                    args.path.startsWith("/")) &&
                    importsMap[args.importer] && isValidStart(args.path)) {
                    const url = new URL(args.path, importsMap[args.importer]);
                    return { path: url.href, namespace: 'virtual' };
                }
                if ((args.path.startsWith("./") ||
                    args.path.startsWith("../") ||
                    args.path.startsWith("/")) &&
                    args.importer.startsWith("https://") && isValidStart(args.path)) {
                    const url = new URL(args.path, args.importer);
                    return { path: url.href, namespace: 'virtual' };
                }
                if (args.path.startsWith("http")) {
                    return { path: args.path, namespace: 'virtual' };
                }
                if ((args.path.startsWith("_") || args.path.startsWith("./_")) &&
                    !args.importer.startsWith("https://") && !args.path.startsWith("./l2/")) {
                    return {
                        path: transforPathInitId(args.path),
                        namespace: 'virtual',
                    };
                }
                if (args.path.indexOf("/l2/") &&
                    !args.importer.startsWith("https://")) {
                    return {
                        path: args.path.replace('./l2/', `/_${mls.actualProject}_`),
                        namespace: 'virtual',
                    };
                }
                return null;
            });
            build.onLoad({ filter: /.*/, namespace: 'virtual' }, async (args) => {
                try {
                    let path = importsMap[args.path] ? importsMap[args.path] : args.path;
                    if (path.startsWith('_'))
                        return;
                    const res = await fetch(path);
                    if (!res.ok)
                        throw new Error(`Error get ${args.path}`);
                    const text = await res.text();
                    return { contents: text, loader: 'js' };
                }
                catch (e) {
                    console.info('erro:' + args.path);
                    return { contents: '', loader: 'js' };
                }
            });
        },
    };
    let allImports = [...importsJs, ...webcomponets];
    allImports = [...new Set(allImports)];
    const virtualEntryPath = "virtual-entry.js";
    const virtualEntryContent = allImports.map(path => `import "${path}";`).join("\n");
    const result = await esBuild.build({
        stdin: {
            contents: virtualEntryContent,
            resolveDir: "/",
            sourcefile: virtualEntryPath,
            loader: "js"
        },
        bundle: true,
        minify: false,
        format: "esm",
        sourcemap: false,
        write: false,
        plugins: [virtualFsPlugin]
    });
    return result;
}
async function generateOutput(storFile, htmlString, jsString) {
    const { project, shortName, folder } = storFile;
    const newDistFolder = folder ? `${DISTFOLDER}/${folder}` : DISTFOLDER;
    const storFilesDist = getDistStorFile(storFile);
    let storFileJs = storFilesDist.storFileDistJs;
    let storFileHtml = storFilesDist.storFileDistHtml;
    if (!storFileJs)
        storFileJs = await createStorFileOutput({ project, shortName, folder: newDistFolder, ext: '.js' }, jsString);
    else
        await mls.stor.localStor.setContent(storFileJs, { contentType: 'string', content: jsString });
    if (!storFileHtml)
        storFileHtml = await createStorFileOutput({ project, shortName, folder: newDistFolder, ext: '.html' }, htmlString);
    else
        await mls.stor.localStor.setContent(storFileHtml, { contentType: 'string', content: htmlString });
    storFileHtml.updatedAt = new Date().toISOString();
    storFileJs.updatedAt = new Date().toISOString();
    await mls.stor.cache.addIfNeed({
        project,
        folder: newDistFolder,
        content: htmlString,
        extension: '.html',
        shortName,
        version: storFileHtml.versionRef,
    });
    await mls.stor.cache.addIfNeed({
        project,
        folder: newDistFolder,
        content: jsString,
        extension: '.js',
        shortName,
        version: storFileJs.versionRef,
    });
}
async function prepareStyleFile(project, theme) {
    const shortName = 'globalStyle';
    const keyStorFileCssGlobal = mls.stor.getKeyToFiles(project, 2, 'project', '', '.less');
    const storFile = mls.stor.files[keyStorFileCssGlobal];
    if (!storFile)
        return false;
    const keyStorFileCssGlobalDist = mls.stor.getKeyToFiles(project, 2, shortName, DISTFOLDER, '.css');
    const storFileDist = mls.stor.files[keyStorFileCssGlobalDist];
    if (!storFileDist || storFile.inLocalStorage) {
        const globalCss = await getGlobalCss(project, theme);
        const tokens = await getTokensCss(project, theme);
        await generateOutputCssGlobal(project, `${globalCss}\n\n${tokens || ''}`);
        return true;
    }
    const versionStyle = storFileDist?.versionRef || '0';
    const cacheStyle = await mls.stor.cache.getFileFromCache(project, DISTFOLDER, shortName, '.css', versionStyle);
    if (!cacheStyle) {
        const contentStyle = await storFileDist.getContent();
        if (contentStyle && typeof contentStyle === 'string') {
            await mls.stor.cache.addIfNeed({
                project: project,
                folder: DISTFOLDER,
                content: contentStyle,
                extension: '.css',
                shortName,
                version: versionStyle,
                contentType: 'text/plain'
            });
        }
    }
    return false;
}
async function prepareRunTimeFile(project) {
    const shortName = 'collabRunTime';
    const runTimeStorTime = mls.stor.getKeyToFiles(project, 2, shortName, '', '.ts');
    const storFile = mls.stor.files[runTimeStorTime];
    if (!storFile)
        return;
    const keyDist = mls.stor.getKeyToFiles(project, 2, shortName, DISTFOLDER, '.js');
    const storFileDist = mls.stor.files[keyDist];
    if (!storFileDist || storFile.inLocalStorage) {
        await buildRunTimeFile(storFile);
    }
    const version = storFileDist?.versionRef || '0';
    const cacheRunTime = await mls.stor.cache.getFileFromCache(project, DISTFOLDER, shortName, '.js', version);
    if (!cacheRunTime) {
        const contentRunTime = await storFileDist.getContent();
        if (contentRunTime && typeof contentRunTime === 'string') {
            await mls.stor.cache.addIfNeed({
                project: project,
                folder: DISTFOLDER,
                content: contentRunTime,
                extension: '.js',
                shortName,
                version,
            });
        }
    }
}
async function generateOutputRunTime(project, content) {
    const shortName = 'collabRunTime';
    const keyToDistRunTime = mls.stor.getKeyToFiles(project, 2, shortName, DISTFOLDER, '.js');
    let storFileDistRunTime = mls.stor.files[keyToDistRunTime];
    if (!storFileDistRunTime)
        storFileDistRunTime = await createStorFileOutput({ project, shortName, folder: DISTFOLDER, ext: '.js' }, content);
    else
        await mls.stor.localStor.setContent(storFileDistRunTime, { contentType: 'string', content: content });
    await mls.stor.cache.addIfNeed({
        project,
        folder: DISTFOLDER,
        content: content,
        extension: '.js',
        shortName,
        version: storFileDistRunTime.versionRef,
    });
}
async function generateOutputCssGlobal(project, cssString) {
    const shortName = 'globalStyle';
    const keyToDistCssGlobal = mls.stor.getKeyToFiles(project, 2, shortName, DISTFOLDER, '.css');
    let storFileDistCssGlobal = mls.stor.files[keyToDistCssGlobal];
    if (!storFileDistCssGlobal)
        storFileDistCssGlobal = await createStorFileOutput({ project, shortName, folder: DISTFOLDER, ext: '.css' }, cssString);
    else
        await mls.stor.localStor.setContent(storFileDistCssGlobal, { contentType: 'string', content: cssString });
    await mls.stor.cache.addIfNeed({
        project,
        folder: DISTFOLDER,
        content: cssString,
        extension: '.css',
        shortName,
        version: storFileDistCssGlobal.versionRef,
    });
}
function getDistStorFile(storFile) {
    const { project, shortName, folder, level } = storFile;
    const newDistFolder = folder ? `${DISTFOLDER}/${folder}` : DISTFOLDER;
    const keyToDistJs = mls.stor.getKeyToFiles(project, level, shortName, newDistFolder, '.js');
    const keyToDistHtml = mls.stor.getKeyToFiles(project, level, shortName, newDistFolder, '.html');
    let storFileDistJs = mls.stor.files[keyToDistJs];
    let storFileDistHtml = mls.stor.files[keyToDistHtml];
    return {
        storFileDistJs,
        storFileDistHtml,
    };
}
async function createStorFileOutput(data, source) {
    const param = {
        project: data.project,
        shortName: data.shortName,
        folder: data.folder,
        level: 2,
        extension: data.ext,
        source,
        status: 'new'
    };
    const storFile = await createStorFile(param, false, false, false);
    return storFile;
}
async function getAllPages(project, modulePath) {
    const allPages = [];
    for (let key of Object.keys(mls.stor.files)) {
        const storFile = mls.stor.files[key];
        if (storFile.extension !== '.defs.ts' || storFile.project !== project || storFile.folder !== modulePath)
            continue;
        const keyToImport = storFile.folder ? `_${storFile.project}_${storFile.folder}_${storFile.shortName}` : `./_${storFile.project}_${storFile.shortName}`;
        try {
            const module = await import(`./${keyToImport}.defs.js`);
            if (!module)
                continue;
            const defs = module?.defs;
            if (!defs || defs.meta.type !== 'page')
                continue;
            const keyHTML = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, '.html');
            const keyTs = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, '.ts');
            const sfTs = mls.stor.files[keyTs];
            const sfHtml = mls.stor.files[keyHTML];
            if (!sfTs || !sfHtml)
                continue;
            allPages.push({
                ts: sfTs,
                html: sfHtml,
                defs
            });
        }
        catch (err) {
            console.error('Error on get defs from page:' + keyToImport);
            continue;
        }
    }
    return allPages;
}
async function getProjectModule(project, moduleName) {
    const moduleProject = await getProjectConfig(project);
    if (!moduleProject)
        throw new Error(`_${project}_project not found`);
    if (!moduleProject.modules)
        throw new Error(`No modules configured`);
    const moduleConfig = moduleProject.modules.find((item) => item.name === moduleName);
    if (!moduleConfig)
        throw new Error(`Not found module in project: ${moduleName}`);
    const moduleInfo = await getProjectModuleConfig(moduleConfig.path, project);
    if (!moduleInfo)
        throw new Error(`Not found module config : ${moduleName}`);
    const rc = {
        name: moduleName,
        path: moduleConfig.path,
        theme: moduleInfo.theme
    };
    return rc;
}
function parseImportsMap(importsArray) {
    return Object.fromEntries(importsArray.map(str => {
        const match = str.match(/^"(.+?)":\s*"(.+?)"$/);
        if (!match)
            throw new Error("Formato inválido: " + str);
        const [, key, value] = match;
        return [key, value];
    }));
}
function findWidgets(html) {
    if (!html)
        return [];
    const tempEl = document.createElement('div');
    tempEl.innerHTML = html;
    const els = tempEl.querySelectorAll('*');
    const array = Array.from(els)
        .map((el) => {
        const info = convertTagToFileName(el.tagName.toLowerCase() || '');
        if (!info)
            return '';
        if (info.folder) {
            return '/' + `_${info.project}_${info.folder}/${info.shortName}`;
        }
        return '/' + `_${info.project}_${info.shortName}`;
    }).filter(Boolean);
    const ret = [...new Set(array)];
    return ret;
}
async function loadEsBuild() {
    if (mls.esbuild) {
        esBuild = mls.esbuild;
    }
    else if (!mls.esbuildInLoad)
        await initializeEsBuild();
}
async function initializeEsBuild() {
    mls.esbuildInLoad = true;
    const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
    if (!esBuild) {
        esBuild = await import(url);
        await esBuild.initialize({
            wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
        });
        mls.esbuild = esBuild;
        mls.esbuildInLoad = false;
    }
}
