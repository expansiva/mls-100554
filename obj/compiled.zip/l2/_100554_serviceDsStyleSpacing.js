/// <mls shortName="serviceDsStyleSpacing" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/**
 * @mlsComponentDetails {
 *  "webComponentDependencies": ["collab-ds-input-range-100554"]
 * }
 */
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabDSInputRange } from './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    margin: 'Margem',
    padding: 'Preenchimento',
    top: 'Topo',
    left: 'Esquerda',
    bottom: 'Inferior',
    right: 'Direita',
};
const message_en = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleSpacing = class ServiceDsStyleSpacing extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.myUpp = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleSpacing';
        this.details = {
            icon: '&#xe4ba',
            state: 'foreground',
            position: 'right',
            tooltip: 'Spacing',
            tags: ['ds_styles'],
            visible: false,
            widget: '_100554_serviceDsStyleSpacing',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Spacing',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //-------------IMPLEMENTS--------------
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        initCollabDSInputRange();
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    setValues(ar) {
        this.myUpp = true;
        ar.forEach((i) => {
            if (!this.shadowRoot || !i.key)
                return;
            const value = i.value;
            const prop = i.key;
            if (['margin', 'padding'].includes(prop)) {
                this.uppProp(value, prop);
            }
            else {
                const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
                if (el)
                    el.value = value;
            }
        });
        this.myUpp = false;
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `${this.renderMargin()}${this.renderPadding()}`;
    }
    renderMargin() {
        return html `
            <div>
                <h5 style="display:flex; gap:1.5rem" >${this.msg.margin}<input type="checkbox" prop="margin"></h5>
                <div class="groupEdit">
                    <span>${this.msg.top}</span>
                    <collab-ds-input-range-100554 prop="margin-top" value="0px" .arraySelect=${this.tpMeasures} group="margin" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.left}</span>
                    <collab-ds-input-range-100554 prop="margin-left" value="0px" .arraySelect=${this.tpMeasures} group="margin" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>    
                </div>
                <div class="groupEdit">
                    <span>${this.msg.bottom}</span>
                    <collab-ds-input-range-100554 prop="margin-bottom" value="0px" .arraySelect=${this.tpMeasures} group="margin" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554> 
                </div>
                <div class="groupEdit">
                    <span>${this.msg.right}</span>
                    <collab-ds-input-range-100554 prop="margin-right" value="0px" .arraySelect=${this.tpMeasures} group="margin" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554> 
                </div>
            </div>
        `;
    }
    renderPadding() {
        return html `
            <div>
                <h5 style="display:flex; gap:1.5rem" >${this.msg.padding}<input type="checkbox" prop="padding"></h5>
                <div class="groupEdit">
                    <span>${this.msg.top}</span>
                    <collab-ds-input-range-100554 prop="padding-top" value="0px" .arraySelect=${this.tpMeasures} group="padding" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.left}</span>
                    <collab-ds-input-range-100554 prop="padding-left" value="0px" .arraySelect=${this.tpMeasures} group="padding" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>    
                </div>
                <div class="groupEdit">
                    <span>${this.msg.bottom}</span>
                    <collab-ds-input-range-100554 prop="padding-bottom" value="0px" .arraySelect=${this.tpMeasures} group="padding" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554> 
                </div>
                <div class="groupEdit">
                    <span>${this.msg.right}</span>
                    <collab-ds-input-range-100554 prop="padding-right" value="0px" .arraySelect=${this.tpMeasures} group="padding" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554> 
                </div>
            </div>
        `;
    }
    onChangeProp(e) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            const el = e.detail.target;
            this.beforeEmitEvent(el, e.detail);
        }, 500);
    }
    beforeEmitEvent(el, obj) {
        if (!this.shadowRoot)
            return;
        const group = el ? el.getAttribute('group') : '';
        const elGroup = this.shadowRoot.querySelector(`input[prop="${group}"]`);
        let isGroup = false;
        if (elGroup)
            isGroup = elGroup.checked;
        if (isGroup) {
            this.uppProp(el.value, group);
            return;
        }
        this.emitEvent({
            key: el.getAttribute('prop'),
            value: el.value,
        });
    }
    uppProp(value, group) {
        if (!this.shadowRoot)
            return;
        const info = {
            margin: {
                p1: 'margin-top',
                p2: 'margin-left',
                p3: 'margin-right',
                p4: 'margin-bottom',
            },
            padding: {
                p1: 'padding-top',
                p2: 'padding-left',
                p3: 'padding-bottom',
                p4: 'padding-right',
            },
        };
        const prop = group;
        const elP1 = this.shadowRoot.querySelector(`*[prop="${info[group].p1}"]`);
        const elP2 = this.shadowRoot.querySelector(`*[prop="${info[group].p2}"]`);
        const elP3 = this.shadowRoot.querySelector(`*[prop="${info[group].p3}"]`);
        const elP4 = this.shadowRoot.querySelector(`*[prop="${info[group].p4}"]`);
        const ar = [];
        if (elP1)
            ar.push(elP1);
        if (elP2)
            ar.push(elP2);
        if (elP3)
            ar.push(elP3);
        if (elP4)
            ar.push(elP4);
        ar.forEach((i) => {
            i.value = value;
        });
        this.emitEvent({
            key: prop,
            value: value,
        });
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
};
ServiceDsStyleSpacing.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsStyleSpacing.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleSpacing.prototype, "helper", void 0);
ServiceDsStyleSpacing = __decorate([
    customElement('service-ds-style-spacing-100554')
], ServiceDsStyleSpacing);
export { ServiceDsStyleSpacing };
