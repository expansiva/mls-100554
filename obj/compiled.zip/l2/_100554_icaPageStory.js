/// <mls shortName="icaPageStory" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState } from './_100554_icaState';
let IcaPageMedium100554 = class IcaPageMedium100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`ica-page-story-100554{font-family:'Charlie Display',-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;font-size:calc(.25rem * 4);font-weight:400;line-height:1.5;color:#403f3f;background-color:#ffffff;display:block}`);
    }
    initPage() {
        globalState._ica = {};
    }
    /// **collab_events_start**
    handleClickbuttonSum() {
        // here or code for event
    }
};
IcaPageMedium100554 = __decorate([
    customElement('ica-page-story-100554')
], IcaPageMedium100554);
export { IcaPageMedium100554 };
