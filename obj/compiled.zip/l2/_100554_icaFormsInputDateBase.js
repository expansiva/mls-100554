/// <mls shortName="icaFormsInputDateBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from '/_100554_/l2/icaLitElementBase.js';
export class IcaFormsInputDateBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaFormsInputDateBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "events" },
        ];
    }
}
