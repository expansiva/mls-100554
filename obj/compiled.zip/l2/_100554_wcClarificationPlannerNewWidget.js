/// <mls shortName="wcClarificationPlannerNewWidget" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { postBackClarification } from "./_100554_aiAgentOrchestration";
import { convertFileNameToTag, convertTagToFileName } from './_100554_utilsLit';
let WcClarificationPlannerNewWidget100554 = class WcClarificationPlannerNewWidget100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-clarification-planner-new-widget-100554{font-family:Arial,sans-serif;padding:20px;font-size:var(--font-size-12)}wc-clarification-planner-new-widget-100554 input,wc-clarification-planner-new-widget-100554 select,wc-clarification-planner-new-widget-100554 textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}wc-clarification-planner-new-widget-100554 button{background-color:#0a6dc9;border-radius:8px;border:none;box-shadow:0 1px 3px 0 #E6E6E6;display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}wc-clarification-planner-new-widget-100554 .section{margin-bottom:20px;padding:15px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}wc-clarification-planner-new-widget-100554 .section h2{margin-top:0;text-transform:capitalize}wc-clarification-planner-new-widget-100554 .property,wc-clarification-planner-new-widget-100554 .requirement{margin-left:20px;margin-top:5px;width:calc(100% - 20px)}wc-clarification-planner-new-widget-100554 .buttons{margin-top:30px;display:flex;gap:1rem}wc-clarification-planner-new-widget-100554 .cancel{background-color:#FAAD14;color:white}wc-clarification-planner-new-widget-100554 .cancel:hover{background-color:#fbbd34}wc-clarification-planner-new-widget-100554 .continue{background-color:#52C41A;color:white}wc-clarification-planner-new-widget-100554 .continue:hover{background-color:#66d93f}`);
        this.ICABASEPROJECT = 100554;
        this.develpoment = false;
    }
    render() {
        if (this.develpoment)
            this.setDevelpoment();
        return html `
        
        <div>
            ${this.data?.json.map((item) => {
            switch (item.sectionName) {
                case 'resume':
                    return this.renderResume(item);
                case 'parentClass':
                    return this.renderParentClass(item);
                case 'widgetName':
                    return this.renderWidgetName(item);
                case 'properties':
                    return this.renderProperties(item);
                case 'requirements':
                    return this.renderRequirements(item);
            }
        })}
            <div class="buttons">
                <button class="cancel" @click=${this.handleCancel}>Cancelar</button>
                <button class="continue" @click=${this.handleOk}>Continuar</button>
            </div>

        </div>`;
    }
    renderResume(item) {
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
            </div>
        `;
    }
    renderParentClass(item) {
        item.widgetName = this.createParentName(item.widgetName);
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                <div>
                    <label>Parent Class:</label>
                    <input
                        @input= ${(e) => this.handleParentInput(e, item)} 
                        type="text"
                        .value=${item.widgetName}
                    ></input>
                </div>
            </div>
        `;
    }
    renderWidgetName(item) {
        item.tagName = this.createTagName(item.tagName);
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                <div>
                    <label>Widget:</label>
                    <input
                        type="text"
                        .value=${item.widgetName}
                        @input= ${(e) => this.handleWidgetNameInput(e, item)} 
                    ></input>
                </div>
                <div>
                    <label>Tagname:</label>
                    <input
                        id="input_tagName"
                        type="text"
                        readonly
                        @change=${(e) => this.handleTagNameChange(e, item)}
                        .value=${item.tagName}
                    ></input>
                </div>
            </div>
        `;
    }
    renderProperties(item) {
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                <ul>
                    ${item.properties.map((prop) => html `<li><b>${prop.propertyName}:</b> ${prop.description} (Essencial: ${prop.isEssencial}</li>`)}
                </ul>
            </div>
        `;
    }
    renderRequirements(item) {
        return html `
            <div class="section">
                <h2 class="title">${item.sectionName}</h2>
                <p class="desc">${item.description}</p>
                
                <h3>Functional Requirements:</h3>
                ${item.functionalRequirements
            ? html `
                        <textarea
                            rows=${item.functionalRequirements.length}
                            .value = "- ${item.functionalRequirements.join('\n -')}"
                            @input=${(e) => this.handleRqFunctionalInput(e, item)}
                        >
                        </textarea>
                    `
            : ''}

                <h3>Visual Requirements</h3>
                ${item.visualRequirements
            ? html `
                        <textarea
                            rows=${item.visualRequirements.length}
                            .value = "- ${item.visualRequirements.join('\n -')}"
                            @input=${(e) => this.handleRqVisualInput(e, item)}
                        >
                        </textarea>
                    `
            : ''}

            </div>
        `;
    }
    createTagName(value) {
        const actual = mls.actual[5];
        const project = actual.project;
        if (!project)
            return value;
        return convertFileNameToTag(`_${project}_${value}`);
    }
    createParentName(value) {
        return convertTagToFileName(`${value}-${this.ICABASEPROJECT}`).replace(`_${this.ICABASEPROJECT}_`, '') + 'Base';
    }
    handleWidgetNameInput(e, item) {
        const target = e.target;
        item.widgetName = target.value;
        if (this.inputTag) {
            this.inputTag.value = this.createTagName(target.value);
            const event = new Event('change', { bubbles: true });
            this.inputTag.dispatchEvent(event);
        }
    }
    handleTagNameChange(e, item) {
        const target = e.target;
        item.tagName = target.value;
    }
    handleParentInput(e, item) {
        const target = e.target;
        item.widgetName = target.value;
    }
    handleRqVisualInput(e, item) {
        const target = e.target;
        item.visualRequirements = target.value.split('\n');
    }
    handleRqFunctionalInput(e, item) {
        const target = e.target;
        item.functionalRequirements = target.value.split('\n');
    }
    handleCancel() {
        this.handleAction('cancel');
    }
    handleOk() {
        this.handleAction('continue');
    }
    async handleAction(action) {
        if (!this.data)
            return;
        console.info(this.data);
        await postBackClarification(action, this.data);
    }
    setDevelpoment() {
        this.data = {
            clarificationMessage: '',
            stepId: 123,
            taskId: '123',
            json: [
                {
                    "sectionName": "resume",
                    "description": "Widget para seleção de intervalo de datas, com suporte a limites mínimos e máximos e bloqueio de datas específicas, ideal para reservas e agendamentos."
                },
                {
                    "sectionName": "parentClass",
                    "description": "Component for selecting date ranges, useful for period filters.",
                    "widgetName": "ica-forms-input-date-range"
                },
                {
                    "sectionName": "widgetName",
                    "description": "Nome do Widget",
                    "widgetName": "wcDataPickerRange",
                    "tagName": "wc-data-picker-range",
                },
                {
                    "sectionName": "properties",
                    "description": "Propriedades do widget",
                    "properties": [
                        { "propertyName": "startValue", "description": "Data inicial do intervalo selecionado", "isEssencial": "true" },
                        { "propertyName": "endValue", "description": "Data final do intervalo selecionado", "isEssencial": "true" },
                        { "propertyName": "minvalue", "description": "Data mínima permitida para seleção", "isEssencial": "false" },
                        { "propertyName": "maxvalue", "description": "Data máxima permitida para seleção", "isEssencial": "false" },
                        { "propertyName": "blockedDates", "description": "Lista de datas específicas bloqueadas para seleção (essencial)", "isEssencial": "true" },
                        { "propertyName": "label", "description": "Rótulo para o campo de seleção", "isEssencial": "false" },
                        { "propertyName": "hint", "description": "Dica para o usuário sobre o uso do widget", "isEssencial": "false" },
                        { "propertyName": "required", "description": "Define se o campo é obrigatório", "isEssencial": "false" },
                        { "propertyName": "disabled", "description": "Define se o widget está desabilitado", "isEssencial": "false" },
                        { "propertyName": "readonly", "description": "Define se o widget é somente leitura", "isEssencial": "false" },
                        { "propertyName": "autofocus", "description": "Define se o widget recebe foco automaticamente", "isEssencial": "false" },
                        { "propertyName": "pattern", "description": "Padrão para validação da data", "isEssencial": "false" },
                        { "propertyName": "errormessage", "description": "Mensagem exibida em caso de erro de validação", "isEssencial": "false" },
                        { "propertyName": "eventBinding", "description": "Eventos para interação com o widget", "isEssencial": "false" }
                    ]
                },
                {
                    "sectionName": "requirements",
                    "description": "Requisitos para este widget, altere se necessário",
                    "functionalRequirements": [
                        "Must support selection of a date range with start and end dates",
                        "Must allow setting minimum and maximum selectable dates",
                        "Must allow blocking specific dates from selection",
                        "Must provide clear validation and error messages",
                        "Must support keyboard navigation and accessibility standards",
                        "Must allow disabling and readonly modes",
                        "Must support localization (language, month and weekday labels)",
                        "Must allow navigation between months",
                        "Must highlight the current date",
                        "Must display selected date(s) with visual feedback",
                        "Must support both single and range date selection modes",
                        "Must allow customization of first day of the week"
                    ],
                    "visualRequirements": [
                        "Must render two consecutive months side by side",
                        "Must clearly differentiate between selected, hovered, and disabled dates",
                        "Must display weekdays headers aligned with their respective columns",
                        "Must use subtle color variation for past/future dates outside the current month",
                        "Must include controls for next/previous month navigation",
                        "Must include a clear call-to-action to close or confirm the selection"
                    ]
                }
            ]
        };
    }
};
__decorate([
    property()
], WcClarificationPlannerNewWidget100554.prototype, "data", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], WcClarificationPlannerNewWidget100554.prototype, "develpoment", void 0);
__decorate([
    query('#input_tagName')
], WcClarificationPlannerNewWidget100554.prototype, "inputTag", void 0);
WcClarificationPlannerNewWidget100554 = __decorate([
    customElement('wc-clarification-planner-new-widget-100554')
], WcClarificationPlannerNewWidget100554);
export { WcClarificationPlannerNewWidget100554 };
