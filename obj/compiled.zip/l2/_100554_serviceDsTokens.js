/// <mls shortName="serviceDsTokens" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ServiceDsTokens100554_1;
import { html, css } from 'lit';
import { customElement, query, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { getDSInstance, list as listDs } from './_100554_libDesignSystem';
/// **collab_i18n_start**
const message_pt = {
    theme: "Tema",
    addNewTheme: 'Adicionar novo tema',
    back: 'Voltar',
};
const message_en = {
    theme: "Theme",
    addNewTheme: 'Add new theme',
    back: 'Back',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsTokens100554 = ServiceDsTokens100554_1 = class ServiceDsTokens100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.msize = '';
        this.actualTheme = 'Default';
        this.currentScenario = 'editor';
        this.themes = [];
        this.details = {
            icon: '&#xf0ae',
            state: 'foreground',
            tooltip: 'Tokens',
            visible: true,
            position: "left",
            tags: [],
            widget: '_100554_serviceDsTokens',
            level: [3]
        };
        this.onClickIcon = (op) => {
            if (op === 'icTypography')
                this.showTypography();
            if (op === 'icGlobal')
                this.showGlobal();
            if (op === 'icColor')
                this.showColors();
        };
        this.onClickTitle = () => {
            this._onClickTitle();
        };
        this.menu = {
            title: {
                icon: '&#xf053',
                text: 'Theme'
            },
            actions: {},
            icons: {
                icColor: 'Colors;f53f',
                icTypography: 'Typography;f031',
                icGlobal: 'Global;f065'
            },
            actionDefault: '',
            iconDefault: 'icColor',
            setMode: undefined,
            onClickLink: undefined,
            onClickIcon: this.onClickIcon,
            onClickTitle: this.onClickTitle,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.timeoutChangesEditorColor = 0;
        this.timeoutChangesEditorTypography = 0;
        this.timeoutChangesEditorGlobal = 0;
        this.models = {
            resume: {},
            color: {},
            global: {},
            typography: {},
        };
        this.tokensColors = {};
        this.tokensTypo = {};
        this.tokensGlobal = {};
        this.actualTypeTokens = 'color';
        this.styles = `
        .select-theme {
            padding: 1rem;
        }
        .select-theme .select-theme-action {
            display:flex;
            justify-content:center;
        }
        .select-theme .theme-item {
            border-bottom: 1px solid #cecece;
        }
        .select-theme .theme-item .desc {
            font-size: var(--font-size-16);
            display:block;
        }
        .select-theme .theme-item .pallete {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
            padding-bottom: 1rem;
        }
        .select-theme .theme-item .pallete .pallete-item {
            cursor:pointer;
            background-color: #535353;
            width: 40px;
            height: 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            font-weight: bold;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }

        .select-theme .theme-item .pallete:hover {
            opacity: .7
        }
    `;
    }
    createRenderRoot() {
        return this;
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible) {
            const params = { isComponent: false, service: [] };
            mls.events.fire([3], ['DSTokenSelected'], JSON.stringify(params), 1000);
            if (el && typeof el.layout === 'function')
                el.layout();
        }
        else {
            const params = { isComponent: false, service: [] };
            mls.events.fire([3], ['DSTokenUnSelected'], JSON.stringify(params), 0);
        }
    }
    getActualRef() {
        return `_100554_serviceDsTokens_${this.actualTypeTokens}`;
    }
    async setEditorSource(tokens, tokensType) {
        if (!this.models[tokensType])
            return;
        const model = this.models[tokensType];
        const fullRange = model.getFullModelRange();
        const lines = tokens.trim().split('\n');
        const operations = [{
                range: fullRange,
                text: '',
                forceMoveMarkers: true
            }, {
                range: { startLineNumber: 1, startColumn: 1 },
                text: lines.join('\n'),
                forceMoveMarkers: true
            }];
        model.pushEditOperations([], operations, () => []);
        return;
    }
    getEditorSource() {
        const model = this._ed1?.getModel();
        const val = model?.getValue() || '';
        return val;
    }
    async setTokens(theme) {
        const { tokensColors, tokensGlobal, tokensTypo } = await this.getTokens(theme);
        this.setInitialModels(tokensColors, 'color');
        this.setInitialModels(tokensGlobal, 'global');
        this.setInitialModels(tokensTypo, 'typography');
    }
    async getTokens(theme) {
        const { project } = mls.actual[5];
        const { mode } = mls.actual[3];
        if (project === undefined || mode === undefined)
            throw new Error('No project or design system selected');
        const dss = await listDs(project);
        const dsInfo = dss[mode];
        if (!dsInfo)
            return { tokensColors: '', tokensTypo: '', tokensGlobal: '', resumeTokens: '' };
        this.dsInstance = await getDSInstance(project, mode);
        await this.dsInstance.init();
        if (!this.dsInstance.tokens)
            throw new Error('No tokens finded');
        const list = this.dsInstance.tokens.list;
        const tokens = list[theme];
        this.tokensColors = tokens.color;
        this.tokensTypo = tokens.typography;
        this.tokensGlobal = tokens.global;
        const strColors = Object.entries(this.tokensColors).map((entry) => {
            const [key, value] = entry;
            return `@${key}: ${value};`;
        }).join('\n');
        const strTypo = Object.entries(this.tokensTypo).map((entry) => {
            const [key, value] = entry;
            return `@${key}: ${value};`;
        }).join('\n');
        const strGlobal = Object.entries(this.tokensGlobal).map((entry) => {
            const [key, value] = entry;
            return `@${key}: ${value};`;
        }).join('\n');
        return {
            tokensColors: strColors,
            tokensTypo: strTypo,
            tokensGlobal: strGlobal,
        };
    }
    createEditor() {
        if (this.c2)
            this._ed1 = monaco.editor.create(this.c2, mls.editor.conf['tokens']);
        this.c2['mlsEditor'] = this._ed1;
        if (this.serviceContent) {
            this.serviceContent.layout();
            this.setMsizeEditor();
        }
    }
    getUri(shortFN) {
        ServiceDsTokens100554_1.modelCount = ServiceDsTokens100554_1.modelCount + 1 || 1;
        return monaco.Uri.parse(`file://server/${shortFN}_${ServiceDsTokens100554_1.modelCount}.ts`);
    }
    setInitialModels(src, model) {
        const uri = this.getUri('l3_tokens');
        this.models[model] = monaco.editor.getModel(uri);
        if (this.models[model])
            this.models[model].setValue(src);
        else
            this.models[model] = monaco.editor.createModel(src, 'less', uri);
    }
    showGlobal() {
        this.actualTypeTokens = 'global';
        if (!this._ed1)
            return;
        this._ed1.setModel(this.models['global']);
        this._ed1.updateOptions({ readOnly: false });
        this._ed1.getModel()?.onDidChangeContent((event) => {
            this.timeoutChangesEditorGlobal = setTimeout(() => {
                if (this.timeoutChangesEditorGlobal)
                    clearTimeout(this.timeoutChangesEditorGlobal);
                this.onEditorGlobalChange(event.changes);
            }, 1000);
        });
    }
    showTypography() {
        this.actualTypeTokens = 'typography';
        if (!this._ed1)
            return;
        this._ed1.setModel(this.models['typography']);
        this._ed1.updateOptions({ readOnly: false });
        this._ed1.getModel()?.onDidChangeContent((event) => {
            this.timeoutChangesEditorTypography = setTimeout(() => {
                if (this.timeoutChangesEditorTypography)
                    clearTimeout(this.timeoutChangesEditorTypography);
                this.onEditorTypoChange(event.changes);
            }, 1000);
        });
    }
    async showColors() {
        this.actualTypeTokens = 'color';
        if (Object.keys(this.tokensColors).length === 0) {
            await this.setTokens(this.actualTheme);
        }
        if (!this._ed1)
            return;
        this._ed1.setModel(this.models['color']);
        this._ed1.updateOptions({ readOnly: false });
        this._ed1.getModel()?.onDidChangeContent((event) => {
            this.timeoutChangesEditorColor = setTimeout(() => {
                if (this.timeoutChangesEditorColor)
                    clearTimeout(this.timeoutChangesEditorColor);
                this.onEditorColorChange(event.changes);
            }, 500);
        });
    }
    onEditorColorChange(changes) {
        const [change] = changes;
        if (!change)
            return;
        if (!this._ed1)
            return;
        const model = this._ed1.getModel();
        if (!model)
            return;
        const tokens = this.getEditorsTokens();
        if (!this.dsInstance || !this.dsInstance.tokens)
            return;
        this.dsInstance.tokens.setTokens(this.actualTheme, tokens.color, tokens.typography, tokens.global);
    }
    onEditorTypoChange(changes) {
        const [change] = changes;
        if (!change)
            return;
        const tokens = this.getEditorsTokens();
        if (!this.dsInstance || !this.dsInstance.tokens)
            return;
        this.dsInstance.tokens.setTokens(this.actualTheme, tokens.color, tokens.typography, tokens.global);
    }
    onEditorGlobalChange(changes) {
        const [change] = changes;
        if (!change)
            return;
        const tokens = this.getEditorsTokens();
        if (!this.dsInstance || !this.dsInstance.tokens)
            return;
        this.dsInstance.tokens.setTokens(this.actualTheme, tokens.color, tokens.typography, tokens.global);
    }
    getEditorsTokens() {
        const typography = this.getEditorJsonKeyValue('typography');
        const color = this.getEditorJsonKeyValue('color');
        const global = this.getEditorJsonKeyValue('global');
        return {
            color,
            global,
            typography,
        };
    }
    getEditorJsonKeyValue(model) {
        const editorValue = this.models[model].getValue().trim().split('\n');
        const tokens = {};
        editorValue.forEach((line) => {
            const { key, value } = this.convertTokenLineEditorToKeyValue(line);
            if (!key)
                return;
            tokens[key] = value;
        });
        return tokens;
    }
    convertTokenLineEditorToKeyValue(content) {
        //@mls-bg-primary: #383838;
        const rc = {};
        if (!content.startsWith('@') || !content.endsWith(';'))
            return rc;
        const [key, value] = (content.substring(1, content.length - 1)).split(':');
        rc.key = key.trim();
        rc.value = value.trim();
        return rc;
    }
    setMsizeEditor() {
        if (!this.visible)
            return;
        this.c2?.setAttribute('msize', this.msize);
    }
    _onClickTitle() {
        this.currentScenario = 'select';
    }
    getThemes() {
        if (!this.dsInstance || !this.dsInstance.tokens)
            return [];
        const list = this.dsInstance.tokens.list;
        const themes = [];
        Object.keys(list).forEach((theme) => {
            const themeItem = {
                themeName: theme,
                description: list[theme].description,
                pallete: []
            };
            Object.keys(list[theme].color).forEach((token) => {
                themeItem.pallete.push(list[theme].color[token]);
            });
            themes.push(themeItem);
        });
        return themes;
    }
    async onSelectTheme(theme) {
        this.tokensColors = {};
        this.tokensGlobal = {};
        this.tokensTypo = {};
        this.actualTheme = theme;
        this.currentScenario = 'editor';
        this.menu.title.text = `${this.msg.theme}:${this.actualTheme}`;
        if (this.menu.updateTitle)
            this.menu.updateTitle();
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            this.setMsizeEditor();
        }
        if (changedProperties.has('currentScenario') && this.currentScenario === 'editor') {
            this.createEditor();
            this.showColors();
        }
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.menu.title.text = `${this.msg.theme}:${this.actualTheme}`;
        if (this.menu.updateTitle)
            this.menu.updateTitle();
    }
    renderEditor() {
        return html `<mls-editor-100529 ismls2="true"></mls-editor-100529>`;
    }
    renderSelect() {
        this.themes = this.getThemes();
        return html `<div class="select-theme">
            <div>
                ${this.themes.map((theme) => {
            return html `
                    <div class="theme-item" @click=${() => { this.onSelectTheme(theme.themeName); }}>
                        <span>${theme.themeName}</span>
                        <span class="desc">${theme.description}</span>

                        <div class="pallete">
                            ${theme.pallete.map((color) => {
                return html `<div class="pallete-item" style="background-color:${color};"></div>`;
            })}
                        </div>
                    </div>`;
        })}
            </div>
            <div class="select-theme-action">
                <a href="#">${this.msg.addNewTheme}</a>
            </div>
        </div>`;
    }
    renderScenario() {
        switch (this.currentScenario) {
            case 'editor':
                return html `${this.renderEditor()}`;
            case 'add':
                return html `
                `;
            case 'select':
                return html `
                    ${this.renderSelect()}
                `;
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <section>
                ${this.renderScenario()}
            </section>
            <style>${this.styles}</style>
        `;
    }
};
ServiceDsTokens100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property({ type: String })
], ServiceDsTokens100554.prototype, "msize", void 0);
__decorate([
    property({ type: String })
], ServiceDsTokens100554.prototype, "actualTheme", void 0);
__decorate([
    property({ type: String })
], ServiceDsTokens100554.prototype, "currentScenario", void 0);
__decorate([
    property({ type: String })
], ServiceDsTokens100554.prototype, "themes", void 0);
__decorate([
    query('mls-editor-100529')
], ServiceDsTokens100554.prototype, "c2", void 0);
ServiceDsTokens100554 = ServiceDsTokens100554_1 = __decorate([
    customElement('service-ds-tokens-100554')
], ServiceDsTokens100554);
export { ServiceDsTokens100554 };
