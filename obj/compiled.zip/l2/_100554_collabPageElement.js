var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="collabPageElement" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { convertTagToFileName } from './_100554_utilsLit';
export const PREFIX_ICA_ID = 'ica_';
export class CollabPageElement extends CollabLitElement {
    constructor() {
        super();
        this.modeoverlay = '';
        this.level = mls.actualLevel.toString() || '7';
        this.isPage = true;
        this.hasImport = [];
    }
    //--------COMPONENT------------
    createRenderRoot() {
        return this; // dont use shadow root
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        setTimeout(() => {
            this.checkToAddOverlay();
        }, 500);
        this.setupIds();
        this.setupEvents();
        this.initPage();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level') && changedProperties.get('level') !== undefined) {
            this.checkToAddOverlay();
        }
    }
    render() {
        this.style.position = 'relative';
        return html ``;
    }
    //--------IMPLEMENTS------------
    getVariationDevice() {
        const device = (document.documentElement.getAttribute('data-device') || 'desktop').toLowerCase();
        return device;
    }
    setupIds() {
        const icas = this.findAllElementsIca(this);
        let device = this.getVariationDevice();
        if (device.length > 0)
            device = device.charAt(0).toUpperCase() + device.slice(1);
        icas.forEach((item) => {
            const oldId = item.element.id;
            const icaId = `${PREFIX_ICA_ID}${item.element.id}`;
            item.element.setAttribute('id', icaId);
            item.element.setAttribute('idel', oldId);
        });
    }
    setupEvents() {
        const allWebComponentsInPage = this.getAllWebComponents(this);
        let device = this.getVariationDevice();
        if (device.length > 0)
            device = device.charAt(0).toUpperCase() + device.slice(1);
        allWebComponentsInPage.forEach((el) => {
            const widget = el.tagName.toLowerCase();
            customElements.whenDefined(widget).then(() => {
                const events = el.getAttribute('data-event')?.split(' ') || [];
                if (!events || events.length === 0)
                    return;
                const elementId = el.getAttribute('idel') || el.getAttribute('id');
                if (!elementId)
                    return;
                const that = this;
                events.forEach(event => {
                    // search por functions name, from specific to generic,
                    // ex: handleClick1Desktop, handleClick1, handleClick
                    const handlerGeneric = `handle${event.charAt(0).toUpperCase() + event.slice(1)}`;
                    const handlerSpecificID = `${handlerGeneric}${elementId}`;
                    const handlerSpecificDevice = `${handlerSpecificID}${device}`;
                    if (that[handlerSpecificDevice]) {
                        el.addEventListener(event, that[handlerSpecificDevice].bind(this));
                    }
                    else if (that[handlerSpecificID]) {
                        el.addEventListener(event, that[handlerSpecificID].bind(this));
                    }
                    else if (that[handlerGeneric]) {
                        el.addEventListener(event, that[handlerGeneric].bind(this));
                    }
                });
            });
        });
    }
    checkToAddOverlay() {
        if (this.level === '7') {
            this.overlay?.remove();
            this.overlay = undefined;
            return;
        }
        if (this.overlay) {
            this.overlay.setAttribute('level', this.level);
            this.overlay.changeOverlayItemsLevel();
            return;
        }
        this.createOverlay();
    }
    async createOverlay() {
        if (!this.modeoverlay)
            return;
        const ok = await this.importWCDOverlay(this.modeoverlay);
        if (!ok)
            return;
        this.overlay = document.createElement(this.modeoverlay);
        this.overlay.myItens = this.findAllElementsIca(this);
        this.overlay.createOverlayItems();
        this.appendChild(this.overlay);
    }
    async importWCDOverlay(imports) {
        try {
            if (this.hasImport.includes(imports))
                return true;
            imports = convertTagToFileName(imports);
            if (!imports.startsWith('./'))
                imports = './' + imports;
            await import(imports);
            this.hasImport.push(imports);
            return true;
        }
        catch (e) {
            console.info(e);
            return false;
        }
    }
    findAllElementsIca(el) {
        let elements = [];
        let elToSearch = el;
        function traverseShadowRoot(element, depth) {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                const { x, y, height, width } = element.getBoundingClientRect();
                elements.push({ element: element, depth, x, y, height, width, opacity: element.style.opacity });
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item, depth + 1);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child, depth + 1));
                }
            }
        }
        if (el.shadowRoot)
            elToSearch = el.shadowRoot;
        elToSearch.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item, 0); // Inicializar com profundidade 0
        });
        return elements;
    }
    getAllWebComponents(root) {
        const webComponents = [];
        function findWebComponents(node) {
            if (node instanceof HTMLElement) {
                const tagName = node.tagName.toLowerCase();
                if (tagName.split('-').length > 0) {
                    webComponents.push(node);
                }
                // Check if the element has a shadow root
                if (node.shadowRoot) {
                    node.shadowRoot.childNodes.forEach(childNode => findWebComponents(childNode));
                }
            }
            node.childNodes.forEach(childNode => findWebComponents(childNode));
        }
        findWebComponents(root);
        return webComponents;
    }
}
__decorate([
    property({ type: String, reflect: true })
], CollabPageElement.prototype, "modeoverlay", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabPageElement.prototype, "level", void 0);
export function getEventName(eventName, elementId, device) {
    const handlerGeneric = `handle${eventName.charAt(0).toUpperCase() + eventName.slice(1)} `;
    if (!elementId)
        return handlerGeneric;
    const handlerSpecificID = `${handlerGeneric}${elementId} `;
    if (!device)
        return handlerSpecificID;
    if (device.length > 0)
        device = device.charAt(0).toUpperCase() + device.slice(1);
    const handlerSpecificDevice = `${handlerSpecificID}${device} `;
    return handlerSpecificDevice;
}
