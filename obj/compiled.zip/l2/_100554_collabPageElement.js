/// <mls shortName="collabPageElement" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { convertTagToFileName } from './_100554_utilsLit';
export const PREFIX_ICA_ID = 'ica_';
export function toPascalCase(str) {
    return str.replace(/(^\w|-\w)/g, match => match.replace('-', '').toUpperCase());
}
export class CollabPageElement extends StateLitElement {
    recreateOverlay() {
        this.overlay?.remove();
        this.overlay = undefined;
        this.createOverlay();
    }
    refreshOverlay() {
        this.checkToAddOverlay();
    }
    constructor() {
        super();
        this.modeoverlay = '';
        this.initPageComplete = false;
        this.level = window.mls && mls.actualLevel ? mls.actualLevel.toString() : '7';
        this.isPage = true;
        this.hasImport = [];
    }
    //--------COMPONENT------------
    createRenderRoot() {
        return this; // dont use shadow root
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        setTimeout(() => {
            this.checkToAddOverlay();
        }, 500);
        this.setupIds();
        // this.setupEvents();
        await this.initPage();
        this.initPageComplete = true;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level') && changedProperties.get('level') !== undefined) {
            this.checkToAddOverlay();
        }
    }
    render() {
        this.style.position = 'relative';
        return html ``;
    }
    //--------IMPLEMENTS------------
    setupIds() {
        const icas = this.findAllElementsIca(this);
        icas.forEach((item) => {
            const oldId = item.element.id;
            const icaId = `${PREFIX_ICA_ID}${item.element.id}`;
            item.element.setAttribute('id', icaId);
            item.element.setAttribute('idel', oldId);
        });
    }
    checkToAddOverlay() {
        if (this.level === '7') {
            this.overlay?.remove();
            this.overlay = undefined;
            return;
        }
        if (this.overlay) {
            this.overlay.setAttribute('level', this.level);
            this.overlay.changeOverlayItemsLevel();
            return;
        }
        this.createOverlay();
    }
    async createOverlay() {
        if (!this.modeoverlay)
            return;
        const ok = await this.importWCDOverlay(this.modeoverlay);
        if (!ok)
            return;
        this.overlay = document.createElement(this.modeoverlay);
        this.overlay.myItens = this.findAllElementsIca(this);
        this.overlay.createOverlayItems();
        this.appendChild(this.overlay);
        mls.events.fire(3, 'WCDEventChange', JSON.stringify({ op: 'recreateOverlay' }));
    }
    async importWCDOverlay(imports) {
        try {
            if (this.hasImport.includes(imports))
                return true;
            imports = convertTagToFileName(imports);
            if (!imports.startsWith('./')) {
                if (mls && mls.modePreview && mls.modePreview === 'singlePage')
                    imports = '/' + imports;
                else
                    imports = './' + imports;
            }
            await import(imports);
            this.hasImport.push(imports);
            return true;
        }
        catch (e) {
            console.info(e);
            return false;
        }
    }
    findAllElementsIca(el) {
        let elements = [];
        let elToSearch = el;
        const arrayEls = [];
        function traverseShadowRoot(element, depth) {
            if (element.tagName.toLowerCase().startsWith('ica') && !arrayEls.includes(element)) {
                const { x, y, height, width } = element.getBoundingClientRect();
                elements.push({ element: element, depth, x, y, height, width, opacity: element.style.opacity });
                arrayEls.push(element);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item, depth + 1);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child, depth + 1));
                }
            }
        }
        if (el.shadowRoot)
            elToSearch = el.shadowRoot;
        elToSearch.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item, 0); // Inicializar com profundidade 0
        });
        return elements;
    }
}
__decorate([
    property({ type: String, reflect: true })
], CollabPageElement.prototype, "modeoverlay", void 0);
__decorate([
    property()
], CollabPageElement.prototype, "initPageComplete", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabPageElement.prototype, "level", void 0);
