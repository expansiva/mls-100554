/// <mls shortName="collabJsonType" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
let CollabFCATree = class CollabFCATree extends LitElement {
    constructor() {
        super(...arguments);
        this.exemploUsuario = {
            nome: "Marcos",
            idade: 55,
            filhos: [{ nome: "João" }],
            animals: ["gato"],
            parentes: [1]
        };
    }
    //-------- COMPONENT --------------
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    createRenderRoot() {
        return this;
    }
    render() {
        if (!this.jsonInfo) {
            return html `Not json`;
        }
        else {
            return html `${this.renderJson()}`;
        }
    }
    renderJson() {
        return html `
        <ul>
        ${repeat(this.jsonInfo, ((key, idx) => key.field + idx), ((item, index) => {
            return this.renderItem(item, index);
        }))}</ul>`;
    }
    renderItem(item, idx) {
        return html `<li>
            field:${item.field}, type:${item.type}
            <ul>
                ${repeat(item.children, ((key, idx2) => key.field + idx2), ((item2, index) => {
            return this.renderItem(item2, index);
        }))}
            </ul>
        </li>`;
    }
    //-------- IMPLEMENTATION --------------
    init() {
        this.json = this.exemploUsuario;
        this.jsonInfo = this.generateJsonFromInterface(this.json);
        console.info(this.jsonInfo);
    }
    generateJsonFromInterface(obj) {
        const result = [];
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                const value = obj[key];
                const field = { field: key };
                if (Array.isArray(value)) {
                    field.type = 'array';
                    if (value.length > 0 && typeof value[0] === 'object') {
                        field.children = this.generateJsonFromInterface(value[0]);
                    }
                    else {
                        field.children = [{ field: "arrayItem", type: typeof value[0], children: [] }];
                    }
                }
                else if (typeof value === 'object') {
                    field.type = 'object';
                    field.children = this.generateJsonFromInterface(value);
                }
                else {
                    field.type = typeof value;
                    field.children = [];
                }
                result.push(field);
            }
        }
        return result;
    }
};
__decorate([
    property()
], CollabFCATree.prototype, "json", void 0);
__decorate([
    property()
], CollabFCATree.prototype, "jsonInfo", void 0);
CollabFCATree = __decorate([
    customElement('collab-json-type-100554')
], CollabFCATree);
export { CollabFCATree };
