/// <mls shortName="lessASTTest" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';
import { LessCSS } from "./_100554_lessCSS";
let LessASTTest100554 = class LessASTTest100554 extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`less-a-s-t-test-100554{color:blue;margin:2px}less-a-s-t-test-100554 .cl1{margin-bottom:2px;margin-top:2px;margin-right:2px;margin-left:2px;background-color:red;margin:2px}less-a-s-t-test-100554.theme2{display:inherit}less-a-s-t-test-100554.theme2 .cl1{margin:2px}less-a-s-t-test-100554.theme3{display:inherit}`);
        this.rootSelector = 'less-a-s-t-test-100554';
        this.fileToTest = '_100554_lessASTTest.less';
        this.url1 = monaco.editor.getModel(monaco.Uri.parse(`//server/${this.fileToTest}`));
        this.exeTest = () => {
            if (!this.url1)
                return "undefined;";
            const url = this.url1.uri.toString();
            const lessCSS = new LessCSS(url);
            const selector = lessCSS.lessAST.findSelectorByLine(18);
            lessCSS.setSelector(this.rootSelector);
            return `selector: ${this.rootSelector}\n${this.test2(lessCSS, this.rootSelector)}`;
        };
        this.test1 = (lessCSS, rootSelector) => {
            let result = "test change property update value\n";
            result += "before:\n" + JSON.stringify(lessCSS.lessAST.ast[rootSelector], null, 2) + "\n\n";
            lessCSS.styles.color = "blue;";
            result += "after:\n" + JSON.stringify(lessCSS.lessAST.ast[rootSelector], null, 2) + "\n\n";
            return result;
        };
        this.test2 = (lessCSS, rootSelector) => {
            let selector = `${rootSelector} .cl1`;
            lessCSS.setSelector(selector);
            let result = `Adding selector ${selector} and property. If it already exists, please delete it manually before testing.\n`;
            result += "before:\n" + JSON.stringify(lessCSS.lessAST.ast[selector], null, 2) + "\n\n";
            lessCSS.styles.margin = "2px";
            result += "after:\n" + JSON.stringify(lessCSS.lessAST.ast[selector], null, 2) + "\n\n";
            result += "full:\n" + JSON.stringify(lessCSS.lessAST.ast, null, 2) + "\n\n";
            return result;
        };
        this.test3 = (lessCSS, rootSelector) => {
            let selector = `${rootSelector}`;
            lessCSS.setSelector(selector);
            let result = `delete property backgroundColor, currentValue='${lessCSS.styles.backgroundColor}'\n`;
            if (lessCSS.styles.backgroundColor === "")
                return result + `property dont exists\n`;
            result += "before:\n" + JSON.stringify(lessCSS.lessAST.ast[selector], null, 2) + "\n\n";
            lessCSS.styles.backgroundColor = "";
            result += "after:\n" + JSON.stringify(lessCSS.lessAST.ast[selector], null, 2) + "\n\n";
            result += "full:\n" + JSON.stringify(lessCSS.lessAST.ast, null, 2) + "\n\n";
            return result;
        };
        this.testt1 = (lessCSS, rootSelector) => {
            let result = `list themes:\n`;
            result += JSON.stringify(lessCSS.lessAST.listThemes(), null, 2) + "\n\n";
            const themeName = "theme3";
            result += `adding theme: ${themeName}, return=${lessCSS.lessAST.addTheme(themeName)}\n`;
            result += `theme description:\n\n${lessCSS.lessAST.getThemeDescription(themeName).join("\n")}\n\n`;
            return result;
        };
        this.testt2 = (lessCSS, rootSelector) => {
            let result = `list themes:\n`;
            result += JSON.stringify(lessCSS.lessAST.listThemes(), null, 2) + "\n\n";
            const themeName = "theme3";
            result += `deleting theme: ${themeName}, return=${lessCSS.lessAST.deleteTheme(themeName)}`;
            return result;
        };
    }
    render() {
        return html `<p>testing file: ${this.fileToTest}</p>
         <p>model: ${this.url1?.uri.toString()} </p>
         <pre>test: <br>${this.exeTest()}</pre>
         `;
    }
};
LessASTTest100554 = __decorate([
    customElement('less-a-s-t-test-100554')
], LessASTTest100554);
export { LessASTTest100554 };
