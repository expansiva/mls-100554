/// <mls shortName="serviceDsDocList" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { collab_plus, collab_chevron_right } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    add: 'Adicionar'
};
const message_en = {
    loading: 'Loading...',
    add: 'Add'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsDocList100554 = class ServiceDsDocList100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.list = [];
        this.docIdSelected = 0;
        this.loading = true;
        this.details = {
            icon: '&#xf02d',
            state: 'foreground',
            tooltip: 'Documentation List',
            visible: true,
            position: "left",
            tags: ['ds_docs'],
            widget: '_100554_serviceDsDocList',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (op === 'opList')
                return true;
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'List',
            actions: {},
            icons: {},
            actionDefault: 'opList', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible)
            mls.events.fire([3], ['DSDocSelected'], 'Doc Selected', 1000);
        else
            mls.events.fire([3], ['DSDocUnSelected'], 'Doc UnSelected', 0);
        if (reinit) {
            const { project } = mls.actual[5];
            const { mode } = mls.actual[3];
            if (this.lastProject !== project || this.lastDsIndex !== mode) {
                this.getState();
            }
        }
    }
    async connectedCallback() {
        super.connectedCallback();
        await this.getState();
        this.loading = false;
        const firstItem = this.list[0].item?.id;
        if (firstItem)
            this.selectDoc(firstItem);
    }
    setEvents() {
        mls.events.addEventListener([3], ['DSDocPageChanged'], (ev) => {
            this.onDocPageChanged(ev);
        });
    }
    async getState() {
        const allDocs = await this.getListDocs();
        this.list = this.createFolderStructure(allDocs);
    }
    async getListDocs() {
        const { project } = mls.actual[5];
        const { mode } = mls.actual[3];
        if (project === undefined || mode === undefined)
            return [];
        const dss = mls.l5.ds.list(project);
        this.lastDsIndex = mode;
        this.lastProject = project;
        const dsInfo = dss[mode];
        if (!dsInfo)
            return [];
        this.dsInstance = mls.l3.getDSInstance(project, mode);
        await this.dsInstance.init();
        this.list = [];
        const allItems = [];
        Object.keys(this.dsInstance.docs.list).forEach((doc) => {
            if (!this.dsInstance)
                return;
            allItems.push(this.dsInstance.docs.list[doc]);
        });
        return allItems;
    }
    createFolderStructure(arr) {
        const map = new Map();
        const root = {
            id: 0,
            item: undefined,
            children: []
        };
        map.set(0, root);
        for (const obj of arr) {
            const { id, parentID } = obj;
            const folder = {
                id,
                item: obj,
                children: []
            };
            if (map.has(parentID)) {
                const parentFolder = map.get(parentID);
                parentFolder.children.push(folder);
                map.set(id, folder);
            }
        }
        return root.children;
    }
    onDocPageChanged(ev) {
        if (!ev.desc)
            return;
        const st = JSON.parse(ev.desc);
        if (st.op === 'Add')
            this.addDoc(st.id);
        if (st.op === 'Change')
            this.changedMe(st.id, st.content);
        if (st.op === 'Update')
            this.updateDoc(st.id, st.parentID, st.title);
        else if (st.op === 'Delete')
            this.removeDoc(st.id);
    }
    async addDoc(parentID) {
        if (!this.dsInstance)
            return;
        const idx = await this.dsInstance.docs.add(parentID, 'NewDocument', 'Describe your new documentation here');
        await this.getState();
        this.selectDoc(idx);
    }
    async changedMe(id, content) {
        if (!this.dsInstance)
            return;
        const doc = this.dsInstance.docs.list[id];
        if (!doc)
            return;
        doc.setContent(content);
    }
    async updateDoc(id, parentID, title) {
        if (!this.dsInstance)
            return;
        await this.dsInstance.docs.update(id, parentID, title, '');
        this.getState();
    }
    async removeDoc(id) {
        if (!this.dsInstance)
            return;
        if (!this.containerMain)
            return;
        const el = this.containerMain.querySelector(`details[docId = "${id}"]`);
        if (!el)
            return;
        const doc = this.dsInstance.docs.list[id];
        let nextEl = el.nextElementSibling || el.closest(`details[docId = "${doc.parentID}"]`);
        nextEl = nextEl || el.previousElementSibling;
        const nextElId = nextEl?.getAttribute('docId');
        await this.dsInstance.docs.remove(id);
        await this.getState();
        if (nextElId)
            this.selectDoc(+nextElId);
    }
    async addNewDoc() {
        let selectedParentIndex = 0;
        this.addDoc(selectedParentIndex);
    }
    selectDoc(id) {
        setTimeout(() => {
            let docToSelect;
            if (!this.containerMain)
                return;
            docToSelect = this.containerMain.querySelector(`details[docId = "${id}"]`);
            if (docToSelect)
                docToSelect.click();
        }, 100);
    }
    onDetailsClick(doc, e) {
        this.docIdSelected = doc.id;
        const target = e.target;
        const details = target.closest('details');
        const summary = details.querySelector('summary');
        const isSelected = summary.classList.contains('selected');
        e.stopPropagation();
        if (details.open && !isSelected)
            e.preventDefault();
        if (isSelected) {
            return;
        }
        this.seeDocumentation(doc.item, doc.item?.title, doc.children.length > 0);
    }
    async seeDocumentation(item, title, hasChildren) {
        if (!item || !title)
            return;
        const text = await item.getContent();
        const obj = {
            op: 'Open',
            title,
            content: text,
            id: item.id,
            parentID: item.parentID,
            hasChildren
        };
        mls.events.fire([3], ['DSDocPageClicked'], JSON.stringify(obj));
    }
    renderList(items) {
        return items.map((doc) => html `
            <details
                class="${doc.children.length > 0 ? '' : 'nochildren'}"
                docId="${doc.id.toString()}"
                parentId="${doc.item?.parentID.toString()}"
                @click=${(e) => { this.onDetailsClick(doc, e); }}
            >
                <summary class= "${doc.id === this.docIdSelected ? 'selected' : ''}" >
                    <div>
                        <p>${doc.item?.title}</p>
                        <span></span>
                        ${collab_chevron_right}
                    </div>
                </summary>
                ${doc.children.length > 0 ? html `<div style="padding-left:1rem">${this.renderList(doc.children)}<div>` : ''}
            </details>
            `);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div>
                ${this.loading
            ? html `<p>${this.msg.loading}</p>`
            : html `
                <div>
                    <div class="list-docs-container">
                        ${this.renderList(this.list)}
                    </div>
                    <div class="list-docs-actions">
                        <button @click=${() => { this.addNewDoc(); }}>
                            <span>${this.msg.add}</span>
                            ${collab_plus}
                        </button>
                    </div>
                    

                </div>`}`;
    }
};
ServiceDsDocList100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsDocList100554.prototype, "list", void 0);
__decorate([
    property()
], ServiceDsDocList100554.prototype, "docIdSelected", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceDsDocList100554.prototype, "loading", void 0);
__decorate([
    query('.list-docs-container')
], ServiceDsDocList100554.prototype, "containerMain", void 0);
ServiceDsDocList100554 = __decorate([
    customElement('service-ds-doc-list-100554')
], ServiceDsDocList100554);
export { ServiceDsDocList100554 };
