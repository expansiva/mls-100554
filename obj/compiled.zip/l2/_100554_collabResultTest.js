/// <mls shortName="collabResultTest" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_spinner_clock, collab_check, collab_xmark } from './_100554_collabIcons';
let CollabConsole100554 = class CollabConsole100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-result-test-100554 .test-container{display:flex;align-items:center;gap:10px;font-family:Arial,sans-serif}collab-result-test-100554 .test-container details>summary{cursor:pointer;margin-left:.2rem}collab-result-test-100554 .test-container details>div{margin-top:1rem;margin-left:1.5rem}collab-result-test-100554 .loading{font-size:24px;animation:spin 5s linear infinite}collab-result-test-100554 .result{font-size:16px}collab-result-test-100554 .result.pass{color:var(--success-color)}collab-result-test-100554 .result.failed{color:var(--error-color);fill:var(--error-color)}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}`);
        this.testName = '';
        this.status = 'pending';
        this.resultStatus = 'pass';
        this.result = '';
    }
    updated(changedProperties) {
        super.updated(changedProperties);
    }
    renderRunning() {
        return html `
                <span class="loading">${collab_spinner_clock}</span>
                <span>${this.testName}</span>
        `;
    }
    renderFinished() {
        return html `
                <details open class="result">
                    <summary>${this.testName}</summary>
                    <div>
                        <div>
                            <i class="result ${this.resultStatus}">${this.resultStatus === 'pass' ? collab_check : collab_xmark}</i>
                            <span>Result: ${this.result}</span>
                        </div>                    
                    </div>
                </details>
        `;
    }
    render() {
        return html `
            <div class="test-container">
                ${this.status === 'running'
            ? this.renderRunning()
            : this.renderFinished()}
            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "testName", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "resultStatus", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "result", void 0);
CollabConsole100554 = __decorate([
    customElement('collab-result-test-100554')
], CollabConsole100554);
export { CollabConsole100554 };
