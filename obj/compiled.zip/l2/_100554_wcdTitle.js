/// <mls shortName="wcdTitle" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
let WcdAdd100554 = class WcdAdd100554 extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        this.styles = `
        wcd-title-100554 div {
            display:block;
            background: #4c4c4c;
            color: #fff;
            font-size: 11px;
            text-transform: lowercase;
            padding: 0 .5rem;
            height: 14px;
            border-radius: 5px;
            font-weight: normal;
            letter-spacing: -.5px;
            font-family: monospace;
            width: max-content;
        }

    `;
    }
    createRenderRoot() {
        return this;
    }
    render() {
        return html `
            <div>${this.myParent?.widget || ''}</div>
            <style>${this.styles}</style>
        `;
    }
};
WcdAdd100554 = __decorate([
    customElement('wcd-title-100554')
], WcdAdd100554);
export { WcdAdd100554 };
