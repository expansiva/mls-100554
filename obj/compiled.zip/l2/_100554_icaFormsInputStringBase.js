/// <mls shortName="icaFormsInputStringBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from './_100554_icaLitElementBase';
export class IcaFormsInputStringBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.mySymbol = 'fa-font';
        this.baseName = 'IcaFormsInputStringBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
}
