/// <mls shortName="icaFormsInputStringBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { StateLitElement } from './_100554_stateLitElement';
export class IcaFormsInputStringBase extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
}
