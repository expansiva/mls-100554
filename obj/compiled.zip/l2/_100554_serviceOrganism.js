/// <mls shortName="serviceOrganism" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { convertFileNameToTag } from './_100554_utilsLit';
import "./_100554_wcdToolboxItemActionEditAttrOut";
/// **collab_i18n_start**
const message_pt = {
    detailsHint: 'Detalhes do objeto selecionado na página, - help , - ajustes widget como mutations (ica), - ajustes dinâmicos (wcd) , por favor selecione um item na página',
    selectPlugin: 'Por favor selecione um plugin IA',
    loading: 'Carregando...'
};
const message_en = {
    detailsHint: 'Details of the selected object on the page, - help , - widget settings like mutations (ica), - dynamic settings (wcd), please select an item on the page',
    selectPlugin: 'Please select a plugin IA',
    loading: 'Loading...'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceOrganism100554 = class ServiceOrganism100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-organism-100554{display:block;overflow-y:auto}`);
        this.msg = messages['en'];
        this.msize = '';
        this.activeTab = 'icDetails';
        this.pluginNav = '';
        this.pluginProp = '';
        this.pluginStyle = '';
        //-------SERVICE---------------
        this.details = {
            icon: '&#xf471',
            state: 'foreground',
            position: 'right',
            tooltip: 'Organism',
            visible: true,
            widget: '_100554_serviceOrganism',
            level: [5]
        };
        this.menu = {
            title: '',
            main: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [
                    { text: 'Navigation', icon: 'f041' },
                    { text: 'Properties', icon: 'f0ce' },
                    { text: 'Style', icon: 'f53f' },
                    { text: 'Details', icon: '3f' }
                ]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.setEvents();
    }
    setEvents() {
        mls.events.addListener(3, 'WCDEvent', (ev) => this.onWCDEvent(ev));
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        this.activeTab = ESceneries[index];
    }
    onServiceClick(visible, reinit, el) {
    }
    //-------COMPONENT--------------
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(ESceneries[this.activeTab]);
        await this.loadPlugins();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'icNavigation':
                return this.renderNavigation();
            case 'icProperties':
                return this.renderProperties();
            case 'icDetails':
                return this.renderDetails();
            case 'icStyle':
                return this.renderStyle();
            default:
                return html ``;
        }
    }
    renderNavigation() {
        // this.openService('_100554_servicePreview', 'right', 3);
        return html ` ${this.pluginNav ? unsafeHTML(`<${this.pluginNav} .service=${this}></${this.pluginNav}>`) : `<div>${this.msg.loading}</div>`}`;
    }
    renderProperties() {
        // this.openService('_100554_servicePreview', 'right', 3);
        return html `<wcd-toolbox-item-action-edit-attr-out-100554></wcd-toolbox-item-action-edit-attr-out-100554>`;
    }
    renderDetails() {
        return html `<div>${this.msg.detailsHint}</div>`;
    }
    renderStyle() {
        return html `<plugin-edit-style-l3-100554 .service=${this} msize="${this.msize}"></plugin-edit-style-l3-100554>`;
    }
    //---------IMPLEMENTATION------------
    async loadPlugins() {
        const project = mls.actualProject;
        if (!project)
            return;
        await mls.plugin.loadAll(project, true);
        const plgNav = mls.plugin.getAllMenuActions(project, { scope: 'l3PageNavigation' });
        const plgProp = mls.plugin.getAllMenuActions(project, { scope: 'l3PageProperties' });
        const plgStyle = mls.plugin.getAllMenuActions(project, { scope: 'l3PageStyle' });
        const plgNavName = plgNav[0] ? plgNav[0].widget : '';
        const plgPropName = plgProp[0] ? plgProp[0].widget : '';
        const plgStlpName = plgStyle[0] ? plgStyle[0].widget : '';
        if (plgNavName) {
            const { folder, project, shortName } = mls.l2.getPath(plgNavName);
            await import(`./_${project}_${shortName}`);
            this.pluginNav = convertFileNameToTag({ project, shortName, folder });
        }
        if (plgPropName) {
            const { folder, project, shortName } = mls.l2.getPath(plgPropName);
            await import(`./_${project}_${shortName}`);
            this.pluginProp = convertFileNameToTag({ project, shortName, folder });
        }
        if (plgStlpName) {
            const { folder, project, shortName } = mls.l2.getPath(plgStlpName);
            await import(`./_${project}_${shortName}`);
            this.pluginStyle = convertFileNameToTag({ project, shortName, folder });
        }
    }
    onWCDEvent(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (this.menu.setTabActive) {
            this.openMe();
            this.menu.setTabActive(ESceneries[data.op]);
        }
    }
};
__decorate([
    property({ type: String })
], ServiceOrganism100554.prototype, "msize", void 0);
__decorate([
    property()
], ServiceOrganism100554.prototype, "activeTab", void 0);
__decorate([
    property()
], ServiceOrganism100554.prototype, "pluginNav", void 0);
__decorate([
    property()
], ServiceOrganism100554.prototype, "pluginProp", void 0);
__decorate([
    property()
], ServiceOrganism100554.prototype, "pluginStyle", void 0);
ServiceOrganism100554 = __decorate([
    customElement('service-organism-100554')
], ServiceOrganism100554);
export { ServiceOrganism100554 };
var ESceneries;
(function (ESceneries) {
    ESceneries[ESceneries["icNavigation"] = 0] = "icNavigation";
    ESceneries[ESceneries["icProperties"] = 1] = "icProperties";
    ESceneries[ESceneries["icStyle"] = 2] = "icStyle";
    ESceneries[ESceneries["icDetails"] = 3] = "icDetails";
})(ESceneries || (ESceneries = {}));
