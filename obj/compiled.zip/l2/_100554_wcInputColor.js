/// <mls shortName="wcInputColor" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
let WcInputColor = class WcInputColor extends LitElement {
    constructor() {
        super(...arguments);
        this.value = '';
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.error = '';
    }
    render() {
        return html `
        <label class="form-control-label">
          ${this.label}
        </label>

        <input
            class="input_control"
            type="color"
            name=${ifDefined(this.name)}
            ?disabled=${this.disabled}
            ?readonly=${this.readonly}
            ?required=${this.required}
            .value=${this.value}
            ?autofocus=${this.autofocus}
            pattern=${ifDefined(this.pattern)}  
        />
        <small class="form_hint">${this.hint}</small>
        <div class="form_error_message">${this.error}</div>
        `;
    }
};
__decorate([
    property({ type: String })
], WcInputColor.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WcInputColor.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WcInputColor.prototype, "widget", void 0);
__decorate([
    property({ type: String })
], WcInputColor.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WcInputColor.prototype, "errormessage", void 0);
__decorate([
    property({ type: String })
], WcInputColor.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], WcInputColor.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WcInputColor.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WcInputColor.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WcInputColor.prototype, "autofocus", void 0);
__decorate([
    property({ type: String })
], WcInputColor.prototype, "hint", void 0);
__decorate([
    query('.input_control')
], WcInputColor.prototype, "input", void 0);
WcInputColor = __decorate([
    customElement('wc-input-color-100554')
], WcInputColor);
export { WcInputColor };
