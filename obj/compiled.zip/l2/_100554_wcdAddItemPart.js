/// <mls shortName="wcdAddItemPart" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { collab_ellipsis } from './_100554_collabIcons';
import { CollabLitElement } from "./_100554_collabLitElement";
import * as commandDivider from './_100554_wcdCommandAddDivider';
/// **collab_i18n_start**
const message_pt = {
    newPart: 'Adicionar uma nova parte',
};
const message_en = {
    newPart: 'Add a new part',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdAddItemPart100554 = class WcdAddItemPart100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <button @keydown=${this.handleKeyDown} @click=${this.handleClick} data-tooltip=${this.msg.newPart} ><span>${collab_ellipsis}</span></button>

    `;
    }
    async handleClick(e) {
        e.stopPropagation();
        this.handleNewPartClick();
    }
    async handleNewPartClick() {
        if (!window.wcdState.myParent)
            throw new Error('Invalid window.wcdState.myParent');
        if (!window.wcdState.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        await commandDivider.execute({
            args: {},
            overlay: window.wcdState.myParent.parentElement?.parentElement,
            selectedIca: window.wcdState.elICA,
        });
    }
    async handleKeyDown(e) {
        e.stopPropagation();
        if (e.key === 'Enter') {
            this.handleClick(new MouseEvent('click'));
        }
    }
};
WcdAddItemPart100554.styles = css ``;
WcdAddItemPart100554 = __decorate([
    customElement('wcd-add-item-part-100554')
], WcdAddItemPart100554);
export { WcdAddItemPart100554 };
