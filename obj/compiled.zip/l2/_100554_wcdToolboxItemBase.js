/// <mls shortName="wcdToolboxItemBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { CollabLitElement } from './_100554_collabLitElement';
export class WcdToolboxItemBase extends CollabLitElement {
    createRenderRoot() {
        return this;
    }
}
