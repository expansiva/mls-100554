/// <mls shortName="wcdToolboxItemBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { CollabLitElement } from './_100554_collabLitElement';
import { globalWcd } from './_100554_wcdState';
export class WcdToolboxItemBase extends CollabLitElement {
    constructor() {
        super();
        this.myParent = globalWcd.myParent;
        this.elMain = globalWcd.elMain;
        this.elICA = globalWcd.elICA;
    }
    createRenderRoot() {
        return this;
    }
}
