/// <mls shortName="wcdToolboxItemBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { LitElement } from 'lit';
export class WcdToolboxItemBase extends LitElement {
}
