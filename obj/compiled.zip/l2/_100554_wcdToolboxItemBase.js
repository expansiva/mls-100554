/// <mls shortName="wcdToolboxItemBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { CollabLitElement } from './_100554_collabLitElement';
export class WcdToolboxItemBase extends CollabLitElement {
    constructor() {
        super();
        this.myParent = window.wcdState.myParent;
        this.elMain = window.wcdState.elMain;
        this.elICA = window.wcdState.elICA;
    }
    createRenderRoot() {
        return this;
    }
}
