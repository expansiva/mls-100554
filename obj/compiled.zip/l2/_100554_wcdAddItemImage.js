/// <mls shortName="wcdAddItemImage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { collab_image } from './_100554_collabIcons';
import { CollabLitElement } from "./_100554_collabLitElement";
import { globalWcd } from './_100554_wcdState';
/// **collab_i18n_start**
const message_pt = {
    image: 'Adicionar uma imagem',
};
const message_en = {
    image: 'Add an image',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdAddItemImage100554 = class WcdAddItemImage100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <wcd-add-button @keydown=${(e) => this.handleKeyDown(e)} @click=${this.handleImageClick} data-tooltip=${this.msg.image} ><span>${collab_image}</span></wcd-add-button>

    `;
    }
    async handleImageClick(e) {
        e.stopPropagation();
        this.showHelper();
    }
    async handleKeyDown(e) {
        e.stopPropagation();
        if (e.key === 'Enter') {
            this.handleImageClick(new MouseEvent('click'));
        }
    }
    showHelper() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.myParent)
            throw new Error('Invalid window.wcdState.myParent');
        globalWcd.myParent.onclick = null;
        globalWcd.myParent?.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: '_100554_wcdDialogImage',
                args: '',
                position: 'p-l1',
                level: [2],
                toolboxOptions: { background: '#fff', border: 'none' }
            },
        ], false, 'size');
    }
};
WcdAddItemImage100554.styles = css ``;
WcdAddItemImage100554 = __decorate([
    customElement('wcd-add-item-image-100554')
], WcdAddItemImage100554);
export { WcdAddItemImage100554 };
