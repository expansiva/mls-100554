/// <mls shortName="collabInputTag" project="100554" enhancement="_100554_enhancementLit" groupName="internal" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
export function initCollabInputTag() {
    return true;
}
let CollabInputTag = class CollabInputTag extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-input-tag-100554{font-family:var(--font-family-primary)}collab-input-tag-100554 .collab-tag-input{max-width:100%;display:flex;align-content:flex-start;flex-wrap:wrap;background-color:#FFF;border:solid 1px #CCC;border-radius:2px;min-height:33px;padding:0 5px}collab-input-tag-100554 .collab-tag-input input{flex-grow:1;display:inline-block;order:200;border:none;height:33px;line-height:33px;font-size:14px;margin:0;width:auto}collab-input-tag-100554 .collab-tag-input input:focus{outline:none}collab-input-tag-100554 .collab-tag-input div.tag{display:inline-block;flex-grow:0;margin:5px 5px 5px 0;padding:0 20px 0 10px;height:25px;line-height:25px;background-color:#E1E1E1;color:#333;font-size:14px;order:100;border-radius:2px;position:relative;overflow:hidden}collab-input-tag-100554 .collab-tag-input div.tag.duplicate{background-color:rgba(255,64,27,0.71);transition:all .3s linear}collab-input-tag-100554 .collab-tag-input div.tag:last-child{margin-right:5px}collab-input-tag-100554 .collab-tag-input div.tag .remove{display:inline-block;color:#000000;padding-left:.45rem;position:absolute;text-align:center;border-top-right-radius:2px;border-bottom-right-radius:2px;transition:all .3s ease;cursor:pointer;top:0;right:5px}`);
        this.tags = [];
        this.allowDelete = false;
    }
    get value() {
        return this.tags.join(',');
    }
    set value(val) {
        if (!val) {
            this.empty();
            return;
        }
        const arrTags = val.split(',');
        this.tags = arrTags;
    }
    addTag(tag) { return this._addTag(tag); }
    deleteTag(index) { return this._deleteTag(index); }
    empty() { return this._empty(); }
    _addTag(tag) {
        if (!tag)
            return;
        tag = tag.toLowerCase();
        if (this.tags.indexOf(tag) === -1) {
            this.tags.push(tag);
            if (this.input)
                this.input.value = '';
            this.requestUpdate();
        }
        else {
            const element = this.querySelector('[data-index="' + this.tags.indexOf(tag) + '"]');
            element.classList.add('duplicate');
            setTimeout(() => {
                element.classList.remove('duplicate');
            }, 500);
        }
    }
    _deleteTag(index) {
        const newTags = [];
        this.tags.forEach((tag, idx) => {
            if (idx !== index) {
                newTags.push(tag);
            }
        });
        this.tags = newTags;
        this.requestUpdate();
    }
    _empty() {
        this.tags = [];
        this.requestUpdate();
    }
    onInputKeyDown(event) {
        event.stopImmediatePropagation();
        if (!this.input)
            return;
        const { value } = this.input;
        if (event.keyCode === 13) {
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 188) {
            event.preventDefault();
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 8 && value.length === 0) {
            if (this.allowDelete) {
                this._deleteTag(this.tags.length - 1);
                if (this.onValueChanged)
                    this.onValueChanged(this.value);
                this.allowDelete = false;
            }
            else {
                this.allowDelete = true;
            }
        }
    }
    render() {
        return html `<div class="collab-tag-input">
                <input id="tag-input" @keydown=${(ev) => { this.onInputKeyDown(ev); }}></input>
                ${this.tags.map((tag, index) => {
            return html `
                        <div data-index=${index} class="tag">

                            ${tag}
                        </div>
                    `;
        })}
        </div>`;
    }
};
__decorate([
    property()
], CollabInputTag.prototype, "tags", void 0);
__decorate([
    query('#tag-input')
], CollabInputTag.prototype, "input", void 0);
CollabInputTag = __decorate([
    customElement('collab-input-tag-100554')
], CollabInputTag);
export { CollabInputTag };
