/// <mls shortName="collabInputTag" project="100554" enhancement="_100554_enhancementLit" groupName="internal" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
export function initCollabInputTag() {
    return true;
}
let CollabInputTag = class CollabInputTag extends LitElement {
    constructor() {
        super(...arguments);
        this.tags = [];
        this.allowDelete = false;
    }
    get value() {
        return this.tags.join(',');
    }
    set value(val) {
        if (!val) {
            this.empty();
            return;
        }
        const arrTags = val.split(',');
        this.tags = arrTags;
    }
    addTag(tag) { return this._addTag(tag); }
    deleteTag(index) { return this._deleteTag(index); }
    empty() { return this._empty(); }
    _addTag(tag) {
        if (!tag)
            return;
        tag = tag.toLowerCase();
        if (this.tags.indexOf(tag) === -1) {
            this.tags.push(tag);
            if (this.input)
                this.input.value = '';
            this.requestUpdate();
        }
        else {
            const element = this.shadowRoot?.querySelector('[data-index="' + this.tags.indexOf(tag) + '"]');
            element.classList.add('duplicate');
            setTimeout(() => {
                element.classList.remove('duplicate');
            }, 500);
        }
    }
    _deleteTag(index) {
        const newTags = [];
        this.tags.forEach((tag, idx) => {
            if (idx !== index) {
                newTags.push(tag);
            }
        });
        this.tags = newTags;
        this.requestUpdate();
    }
    _empty() {
        this.tags = [];
        this.requestUpdate();
    }
    onInputKeyDown(event) {
        if (!this.input)
            return;
        const { value } = this.input;
        if (event.keyCode === 13) {
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 188) {
            event.preventDefault();
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 8 && value.length === 0) {
            if (this.allowDelete) {
                this._deleteTag(this.tags.length - 1);
                if (this.onValueChanged)
                    this.onValueChanged(this.value);
                this.allowDelete = false;
            }
            else {
                this.allowDelete = true;
            }
        }
    }
    render() {
        return html `<div class="collab-tag-input">
                <input id="tag-input" @keydown=${(ev) => { this.onInputKeyDown(ev); }}></input>
                ${this.tags.map((tag, index) => {
            return html `
                        <div data-index=${index} class="tag">
                            <div class="remove">x</div>
                            ${tag}
                        </div>
                    `;
        })}
        </div>`;
    }
};
CollabInputTag.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], CollabInputTag.prototype, "tags", void 0);
__decorate([
    query('#tag-input')
], CollabInputTag.prototype, "input", void 0);
CollabInputTag = __decorate([
    customElement('collab-input-tag-100554')
], CollabInputTag);
export { CollabInputTag };
