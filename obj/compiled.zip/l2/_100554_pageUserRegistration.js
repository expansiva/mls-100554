/// <mls shortName="pageUserRegistration" project="100554" enhancement="_100554_enhancementLit" groupName="other" /> 
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { BECollabClient } from './_100554_beCollabClient';
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement, query } from 'lit/decorators.js';
import { globalState, initState, setState } from './_100554_collabState';
import { initTestState } from './_100554_testPagesState';
let PageUserRegistration100554 = class PageUserRegistration100554 extends CollabPageElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.client = new BECollabClient();
        this.time = -1;
    }
    initPage() {
        initTestState();
        initState('projectTest.pageUserRegistration', {
            indexSel: -1,
            columns: ['id', 'user', 'status'],
            mode: 'list',
            msg: '',
            action: '',
            users: [],
            selected: {
                id: '',
                user: '',
                status: ''
            },
        });
        globalState.globalStateManagment.subscribe([
            'data/0;projectTest.pageUserRegistration.indexSel',
            'data/0;projectTest.pageUserRegistration.action',
            'data/0;projectTest.pageUserRegistration.mode'
        ], this);
        this.onGetForm();
    }
    handleIcaStateChange(_key, _value) {
        if (_key === 'projectTest.pageUserRegistration.indexSel' && _value >= 0) {
            this.onSelectItem(_value);
            return;
        }
        if (_key === 'projectTest.pageUserRegistration.action' && _value === 'add') {
            this.onNew();
            return;
        }
        if (_key === 'projectTest.pageUserRegistration.action' && _value != '') {
            this.onSubmitForm();
            return;
        }
        if (_key === 'projectTest.pageUserRegistration.mode' && _value != '') {
            this.onMode();
            return;
        }
    }
    onSelectItem(idx) {
        setState('projectTest.pageUserRegistration.selected.id', globalState._ica.projectTest.pageUserRegistration.users[idx].id, true);
        setState('projectTest.pageUserRegistration.selected.user', globalState._ica.projectTest.pageUserRegistration.users[idx].user, true);
        setState('projectTest.pageUserRegistration.selected.status', globalState._ica.projectTest.pageUserRegistration.users[idx].status, true);
        setState('projectTest.pageUserRegistration.mode', 'edit', true);
    }
    onNew() {
        setState('projectTest.pageUserRegistration.selected.id', '', true);
        setState('projectTest.pageUserRegistration.selected.user', '', true);
        setState('projectTest.pageUserRegistration.selected.status', '', true);
        setState('projectTest.pageUserRegistration.mode', 'edit', true);
    }
    async onSubmitForm() {
        let action = globalState._ica.projectTest.pageUserRegistration.action;
        const st = { ...globalState._ica.projectTest.pageUserRegistration };
        if (action === 'cancel') {
            setState('projectTest.pageUserRegistration.indexSel', -1, true);
            this.onGetForm();
            return;
        }
        if (action === 'save' && !st.selected.id)
            st.action = 'new';
        if (st.selected.id !== '')
            st.selected.id = +st.selected.id;
        const ret = await this.client.request("beUserRegistration", "POST", st);
        setState('projectTest.pageUserRegistration.msg', ret, true);
        this.onGetForm();
    }
    async onGetForm() {
        const ret = await this.client.request("beUserRegistration", "GET", {});
        setState('projectTest.pageUserRegistration.users', ret, true);
        setState('projectTest.pageUserRegistration.mode', 'list', true);
        setTimeout(() => setState('projectTest.pageUserRegistration.msg', '', true), 3000);
    }
    onMode() {
        clearTimeout(this.time);
        this.time = setTimeout(() => this.configureMode(), 500);
    }
    configureMode() {
        if (!this.contentForm || !this.list)
            return;
        const st = { ...globalState._ica.projectTest.pageUserRegistration };
        if (st.mode === 'list') {
            this.list.style.display = '';
            this.contentForm.style.display = 'none';
            return;
        }
        this.list.style.display = 'none';
        this.contentForm.style.display = '';
        const f = this.contentForm.querySelector('form');
        if (f)
            f.onsubmit = (e) => e.preventDefault();
    }
};
__decorate([
    query('#widget44')
], PageUserRegistration100554.prototype, "list", void 0);
__decorate([
    query('#contentForm')
], PageUserRegistration100554.prototype, "contentForm", void 0);
PageUserRegistration100554 = __decorate([
    customElement('page-user-registration-100554')
], PageUserRegistration100554);
export { PageUserRegistration100554 };
