/// <mls shortName="cssTokens" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { getDSInstance } from './_100554_libDesignSystem';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginCssTokens = class PluginCssTokens extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`css-tokens-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}css-tokens-100554>div{padding:.5rem}css-tokens-100554 .tokens-container{text-transform:uppercase;font-size:var(--font-size-12);color:var(--text-primary-color-darker);margin-bottom:1rem}css-tokens-100554 .tokens-content{display:flex;flex-wrap:wrap}css-tokens-100554 .token{display:flex;flex-direction:row}css-tokens-100554 .token-item{height:45px;width:45px;cursor:pointer}`);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.position = 'left';
        this.level = 0;
        this.filter = '';
        this.theme = 'Default';
        this.tokens = {};
    }
    async initDsInstance() {
        const { project } = mls.actual[5];
        if (project === undefined)
            throw new Error('No project selected!');
        this.dsInstance = await getDSInstance(project, 0);
        if (!this.dsInstance)
            return;
        await this.dsInstance.init();
    }
    async getTokensColor() {
        await this.initDsInstance();
        if (!this.dsInstance || !this.dsInstance.tokens)
            return '';
        if (!this.dsInstance)
            return '';
        const resumeTokensByTheme = this.dsInstance.tokens.list[this.theme];
        if (!resumeTokensByTheme)
            return undefined;
        const tokensColorKeys = Object.keys(resumeTokensByTheme.color);
        const res = tokensColorKeys.filter((key) => !key.startsWith('_dark') && key.startsWith(this.filter)).map((key2) => {
            return {
                key: key2,
                value: resumeTokensByTheme.color[key2]
            };
        });
        return this.groupColorsByState(res);
    }
    groupColorsByState(items) {
        const grouped = {};
        items.forEach(item => {
            const match = item.key.match(/^(.*?)(-(hover|focus|disabled))?$/);
            const baseKey = match ? match[1].replace(/-(lighter|darker|dark|light)/, '') : item.key;
            const state = match && match[3] ? match[3] : 'default';
            const variation = item.key.includes('lighter')
                ? 'lighter'
                : item.key.includes('darker')
                    ? 'darker'
                    : item.key.includes('dark')
                        ? 'dark'
                        : item.key.includes('light')
                            ? 'light'
                            : 'default';
            if (!grouped[baseKey]) {
                grouped[baseKey] = {};
            }
            if (!grouped[baseKey][state]) {
                grouped[baseKey][state] = { dark: "", light: "", lighter: "", darker: "", default: "" };
            }
            grouped[baseKey][state][variation] = item.value;
        });
        return grouped;
    }
    handleColorClick(key, value) {
        console.info({ key, value });
    }
    setTooltip() {
        const doc = this.ownerDocument || document;
        const tooltipEl = doc.querySelector('collab-tooltip');
        this.querySelectorAll('.token-item').forEach((item) => {
            if (tooltipEl && tooltipEl.tooltip)
                tooltipEl.tooltip(item);
        });
    }
    async getTokens() {
        const tokens = await this.getTokensColor();
        if (tokens)
            this.tokens = tokens;
    }
    updated(changedProperties) {
        if (changedProperties.has('tokens')) {
            this.setTooltip();
        }
        if (changedProperties.has('filter')) {
            this.getTokens();
        }
    }
    async firstUpdated() {
        this.getTokens();
    }
    render() {
        return html `
            <div>
                ${Object.keys(this.tokens).map((cat) => html `
                <div class="tokens-container">
                    ${cat}
                    <div class="tokens-content">
                    ${Object.keys(this.tokens[cat]).map((state) => html `
                        <div class="token">
                        ${Object.keys(this.tokens[cat][state]).map((variation) => {
            return this.tokens[cat][state][variation] ? html `
                            <div
                                @click=${() => { this.handleColorClick(`${cat}${variation !== 'default' ? '-' + variation : ''}${state !== 'default' ? '-' + state : ''}`, this.tokens[cat][state][variation]); }} 
                                class="token-item"
                                data-tooltip="${cat}${variation !== 'default' ? '-' + variation : ''}${state !== 'default' ? '-' + state : ''}"
                                style="background-color: ${this.tokens[cat][state][variation]}">
                            
                            </div>
                            ` : html ``;
        })}
                        </div>
                    `)}
                    </div>
                </div>
                `)}
            </div>
            `;
    }
};
__decorate([
    property({ type: Boolean })
], PluginCssTokens.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "position", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "level", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "filter", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "theme", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "tokens", void 0);
PluginCssTokens = __decorate([
    customElement('css-tokens-100554')
], PluginCssTokens);
export { PluginCssTokens };
