/// <mls shortName="cssTokens" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, svg } from 'lit';
import { property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Tokens",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
export class PluginCssTokens extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.position = 'left';
        this.level = 0;
        this.key = '';
        this.prop = '';
    }
    async prepare() {
    }
    render() {
        return html `<div>Pallete</div>`;
    }
}
PluginCssTokens.styles = css ``;
__decorate([
    property({ type: Boolean })
], PluginCssTokens.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "position", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "level", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "key", void 0);
__decorate([
    property()
], PluginCssTokens.prototype, "prop", void 0);
