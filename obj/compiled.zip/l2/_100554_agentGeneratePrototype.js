/// <mls shortName="agentGeneratePrototype" project="100554" enhancement="_blank" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import './_100554_widgetQuestionsForClarification';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, getAgentStepByAgentName, getNextStepIdAvaliable, notifyTaskChange, updateStepStatus } from "./_100554_aiAgentHelper";
import { startNewInteractionInAiTask, startNewAiTask, executeNextStep, addNewStep, startClarification } from "./_100554_aiAgentOrchestration";
const agentName = "agentGeneratePrototype";
const project = 100554;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent for create a new Module",
        visibility: "public",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async beforeClarification(context, stepId, readOnly) {
            return _beforeClarification(context, stepId, readOnly);
        },
        async afterClarification(context, stepId, clarification) {
            return _afterClarification(context, stepId, clarification);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning...";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        // const inputs: any = await getPrompts(context.message.content || getPromptMock());
        const inputs = await getPrompts(getPromptMock());
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
        return;
    }
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
    if (!step.prompt)
        throw new Error(`[${agentName}] beforePrompt: No prompt found in step for this agent.`);
    const inputs = await getPrompts(step.prompt);
    await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    notifyTaskChange(context);
    await executeNextStep(context);
};
const _beforeClarification = async (context, stepId, readOnly) => {
    return startClarification(context, stepId, readOnly);
};
const _afterClarification = async (context, stepId, clarification) => {
    // only execute after button 'continue'
    if (!context || !context.message || !context.task)
        throw new Error(`[${agentName}] [afterClarification] Invalid context`);
    if (!clarification)
        throw new Error(`[${agentName}] [afterClarification] Invalid json after clarification`);
    const newStep = {
        type: 'agent',
        agentName: `${agentName}2`,
        prompt: '...',
        status: 'pending',
        stepId: getNextStepIdAvaliable(context.task),
        interaction: null,
        nextSteps: null,
        rags: null
    };
    // complete this step (payload) and push another step
    await addNewStep(context, stepId, [newStep], "Waiting ...");
};
async function getPrompts(userPrompt) {
    if (!userPrompt)
        throw new Error(`Erro [${agentName}] getPrompts: invalid userPrompt`);
    const dataForReplace = {
        userPrompt
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
function getPromptMock() {
    return "criar site petshop";
}
export function getPayload1(context) {
    if (!context || !context.task)
        throw new Error(`[${agentName}] [getPayload] Invalid context`);
    const agentStep = getAgentStepByAgentName(context.task, agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agentName}] [getPayload] no agent found`);
    // get result
    const resultStep = agentStep.interaction?.payload?.[0];
    if (!resultStep || resultStep.type !== "clarification" || !resultStep.json)
        throw new Error(`[${agentName}] [getPayload] No step clarification found for this agent.`);
    let payload1 = resultStep.json;
    if (typeof payload1 === "string")
        payload1 = JSON.parse(payload1);
    // get userPrompt
    payload1.userPrompt = agentStep?.interaction?.input.find((input) => input.type === 'human')?.content || '';
    return payload1;
}
