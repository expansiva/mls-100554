/// <mls shortName="serviceDsStyleTypography" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/**
 * @mlsComponentDetails {
 *  "webComponentDependencies": ["collab-ds-input-range-100554"]
 * }
 */
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabDSInputRange } from './_100554_collabDsInputRange';
import { initCollabDsInputSelectColor } from './_100554_collabDsInputSelectColor';
/// **collab_i18n_start**
const message_pt = {
    color: 'Cor',
    fontFamily: 'Fam�lia de fontes',
    fontWeight: 'Peso da fonte',
    fontStyle: 'Estilo da fonte',
    fontSize: 'Tamanho da fonte',
    letterSpacing: 'Espa�amento entre letras',
    wordSpacing: 'Espa�amento entre palavras',
    lineHeight: 'Altura da linha',
    textAlign: 'Alinhar texto',
    variant: 'Variante',
    transform: 'Transformar',
    decoration: 'Decora��o',
    textOverflow: 'Text-overflow',
};
const message_en = {
    color: 'Color',
    fontFamily: 'Font Family',
    fontWeight: 'Font Weight',
    fontStyle: 'Font Style',
    fontSize: 'Font Size',
    letterSpacing: 'Letter Spacing',
    wordSpacing: 'Word Spacing',
    lineHeight: 'Line Height',
    textAlign: 'Text align',
    variant: 'Variant',
    transform: 'Transform',
    decoration: 'Decoration',
    textOverflow: 'Text-overflow',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleTypography = class ServiceDsStyleTypography extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.myUpp = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleTypography';
        this.details = {
            icon: '&#xf031',
            state: 'foreground',
            position: 'right',
            tooltip: 'Typography',
            visible: false,
            tags: ['ds_styles'],
            widget: '_100554_serviceDsStyleTypography',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Typography',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //-------------IMPLEMENTS--------------
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        initCollabDSInputRange();
        initCollabDsInputSelectColor();
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    setValues(ar) {
        this.myUpp = true;
        ar.forEach((i) => {
            if (!this.shadowRoot || !i.key)
                return;
            const value = i.value;
            const prop = i.key;
            const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
            if (el)
                el.value = value;
        });
        this.myUpp = false;
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div>
                <div class="groupEdit">
                    <span>${this.msg.color}</span>
                    <input type="color" prop="color" @change="${(e) => this.onChangeProp2('color')}"></input>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.fontFamily}</span>
                    <select style="width:160px" prop="font-family" @change="${(e) => this.onChangeProp2('font-family')}">
                        <option value=""></option>
                        <option value="COURIER">Courier</option>
                        <option value="VERDANA">Verdana</option>
                        <option value="ARIAL">Arial</option>
                        <option value="TIMES NEW ROMAN">Times new Roman</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.fontWeight}</span>
                    <select style="width:160px" prop="font-weight" @change="${(e) => this.onChangeProp2('font-weight')}">
                        <option value=""></option>
                        <option value="100">100</option>
                        <option value="200">200</option>
                        <option value="300">300</option>
                        <option value="400">400</option>
                        <option value="500">500</option>
                        <option value="600">600</option>
                        <option value="700">700</option>
                        <option value="800">800</option>
                        <option value="900">900</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.fontStyle}</span>
                    <select style="width:160px" prop="font-style" @change="${(e) => this.onChangeProp2('font-style')}">
                        <option value=""></option>
                        <option value="NULL">null</option>
                        <option value="NORMAL">normal</option>
                        <option value="ITALIC">italic</option>
                    </select>
                </div> 
                <div class="groupEdit">
                    <span>${this.msg.fontSize}</span>
                    <collab-ds-input-range-100554 prop="font-size" value="0px" .arraySelect=${this.tpMeasures}  group="radius" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit"> 
                    <span>${this.msg.letterSpacing}</span>
                    <collab-ds-input-range-100554 prop="letter-spacing" value="0px" .arraySelect=${this.tpMeasures}  group="radius" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit"> 
                    <span>${this.msg.wordSpacing}</span>
                    <collab-ds-input-range-100554 prop="word-spacing" value="0px" .arraySelect=${this.tpMeasures}  group="radius" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit"> 
                    <span>${this.msg.lineHeight}</span>
                    <collab-ds-input-range-100554 prop="line-height" value="0px" .arraySelect=${this.tpMeasures}  group="radius" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.textAlign}</span>
                    <select style="width:160px" prop="text-align" @change="${(e) => this.onChangeProp2('text-align')}">
                        <option value=""></option>
                        <option value="CENTER">center</option>
                        <option value="END">end</option>
                        <option value="INHERIT">inherit</option>
                        <option value="INITIAL">initial</option>
                        <option value="JUSTIFY">justify</option>
                        <option value="LEFT">left</option>
                        <option value="REVERT">revert</option>
                        <option value="RIGHT">right</option>
                        <option value="START">start</option>
                        <option value="UNSET">unset</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.variant}</span>
                    <select style="width:160px" prop="variant" @change="${(e) => this.onChangeProp2('variant')}">
                        <option value=""></option>
                        <option value="NORMAL">normal</option>
                        <option value="SMALL-CAPS">small-caps</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.transform}</span>
                    <select style="width:160px" prop="transform" @change="${(e) => this.onChangeProp2('transform')}">
                        <option value=""></option>
                        <option value="UPPERCASE">uppercase</option>
                        <option value="LOWERCASE">lowercase</option>
                        <option value="CAPITALIZE">capitalize</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.decoration}</span>
                    <select style="width:160px" prop="decoration" @change="${(e) => this.onChangeProp2('decoration')}">
                        <option value=""></option>
                        <option value="NORMAL">normal</option>
                        <option value="UNDERLINE">underline</option>
                        <option value="OVERLINE">overline</option>
                        <option value="LINE-THROUGH">line-through</option>
                    </select>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.textOverflow}</span>
                    <select style="width:160px" prop="text-overflow" @change="${(e) => this.onChangeProp2('text-overflow')}">
                        <option value=""></option>
                        <option value="ELLIPSIS">ellipsis</option>
                        <option value="CLIP">clip</option>
                        <option value="INITIAL">initial</option>
                    </select>
                </div>
            </div>
        `;
    }
    onChangeProp(obj) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.emitEvent(obj.detail);
        }, 500);
    }
    onChangeProp2(prop) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            if (!this.shadowRoot)
                return;
            const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
            this.emitEvent({ key: prop, value: el.value });
        }, 500);
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        if (obj.target)
            delete obj.target;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
};
ServiceDsStyleTypography.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsStyleTypography.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleTypography.prototype, "helper", void 0);
ServiceDsStyleTypography = __decorate([
    customElement('service-ds-style-typography-100554')
], ServiceDsStyleTypography);
export { ServiceDsStyleTypography };
