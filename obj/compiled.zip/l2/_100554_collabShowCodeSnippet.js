/// <mls shortName="collabShowCodeSnippet" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { collab_check, collab_copy, collab_double_check } from './_100554_collabIcons';
import { CollabLitElement } from './_100554_collabLitElement';
export function initCollabShowCodeSnippet100554() {
    return true;
}
/// **collab_i18n_start**
const message_pt = {
    copy: 'Copiar',
    copied: 'Copiado',
    accept: 'Aceitar',
    accepted: 'Aceito'
};
const message_en = {
    copy: 'Copy',
    copied: 'Copied',
    accept: 'Accept',
    accepted: 'Accepted'
};
const messages = {
    'en-us': message_en,
    'pt-br': message_pt
};
/// **collab_i18n_end**
let CollabShowCodeSnippet100554 = class CollabShowCodeSnippet100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en-us'];
        this.language = 'typescript';
        this.withCopy = true;
        this.withAccept = false;
        this.coping = false;
        this.accepting = false;
        this.text = ``;
        this.onAccept = () => { console.info('not implement'); };
    }
    set textIn(text) {
        this.text = text;
        if (!this.codeBlock)
            return;
        this.waitForLoadIfNeeded(() => {
            this.setCode();
        });
    }
    updated(changedProperties) {
        if (changedProperties.has('language')) {
            if (!window.hljsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js';
                script.onload = () => {
                    window.hljsLoaded = true;
                    this.setCode();
                };
                document.head.appendChild(script);
            }
            else {
                this.setCode();
            }
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.hljsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load highlight.js. please try again`);
            }
        };
        checkVariable();
    }
    setCode() {
        // const supportedLanguages = (window as any).hljs.listLanguages();
        if (!this.codeBlock)
            return;
        this.codeBlock.innerHTML = '';
        this.codeBlock.removeAttribute('data-highlighted');
        this.codeBlock.classList.add('language-' + this.language);
        const val = this.innerHTML;
        this.text = val;
        const that = this;
        this.waitForLoadIfNeeded(() => {
            const res = window.hljs.highlight(val, { language: that.language });
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            if (!that.codeBlock)
                return;
            that.codeBlock.innerHTML = res.value;
        });
    }
    onCopyClick() {
        this.coping = true;
        navigator.clipboard.writeText(this.text);
        setTimeout(() => {
            this.coping = false;
        }, 3000);
    }
    onAcceptClick() {
        if (this.onAccept && typeof this.onAccept === 'function') {
            this.accepting = true;
            this.onAccept();
            setTimeout(() => {
                this.accepting = false;
            }, 3000);
        }
    }
    firstUpdated() {
        this.setCode();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
       <div class="actions">
            <span class="language">${this.language}</span>
            <div class="actions-list">
             ${this.withAccept ?
            this.renderWithAccept() : ''}
             ${this.withCopy ?
            this.renderWithCopy() : ''}
            </div>
       </div>

       <pre><code class="code"></code></pre>
    `;
    }
    renderWithCopy() {
        return html `
      <div @click=${this.onCopyClick} class="action-item" style="display:${this.coping ? 'none' : 'flex'}">
        <div>
          ${collab_copy}
        </div>
        <span>${this.msg.copy}</span>
    </div>
    <div class="action-item copied" style="display:${this.coping ? 'flex' : 'none'}">
      ${collab_check}
      <span>${this.msg.copied}</span>
    </div>
    `;
    }
    renderWithAccept() {
        return html `
      <div @click=${this.onAcceptClick} class="action-item" style="display:${this.accepting ? 'none' : 'flex'}">
        <div>
          ${collab_check}
        </div>
        <span>${this.msg.accept}</span>
    </div>
    <div class="action-item accepted" style="display:${this.accepting ? 'flex' : 'none'}">
      ${collab_double_check}
      <span>${this.msg.accepted}Accepted</span>
    </div>
    `;
    }
};
CollabShowCodeSnippet100554.styles = css `
    pre code.hljs {
        display: block;
        overflow-x: auto;
        padding: 1em
      }
      code.hljs {
        padding: 3px 5px
      }
      /*
      * Visual Studio 2015 dark style
      * Author: Nicolas LLOBERA <nllobera@gmail.com>
      */
      .hljs {
        background: #1E1E1E;
        color: #DCDCDC
      }
      .hljs-keyword,
      .hljs-literal,
      .hljs-symbol,
      .hljs-name {
        color: #569CD6
      }
      .hljs-link {
        color: #569CD6;
        text-decoration: underline
      }
      .hljs-built_in,
      .hljs-type {
        color: #4EC9B0
      }
      .hljs-number,
      .hljs-class {
        color: #B8D7A3
      }
      .hljs-string,
      .hljs-meta .hljs-string {
        color: #D69D85
      }
      .hljs-regexp,
      .hljs-template-tag {
        color: #9A5334
      }
      .hljs-subst,
      .hljs-function,
      .hljs-title,
      .hljs-params,
      .hljs-formula {
        color: #DCDCDC
      }
      .hljs-comment,
      .hljs-quote {
        color: #57A64A;
        font-style: italic
      }
      .hljs-doctag {
        color: #608B4E
      }
      .hljs-meta,
      .hljs-meta .hljs-keyword,
      .hljs-tag {
        color: #9B9B9B
      }
      .hljs-variable,
      .hljs-template-variable {
        color: #BD63C5
      }
      .hljs-attr,
      .hljs-attribute {
        color: #9CDCFE
      }
      .hljs-section {
        color: gold
      }
      .hljs-emphasis {
        font-style: italic
      }
      .hljs-strong {
        font-weight: bold
      }
      /*.hljs-code {
        font-family:'Monospace';
      }*/
      .hljs-bullet,
      .hljs-selector-tag,
      .hljs-selector-id,
      .hljs-selector-class,
      .hljs-selector-attr,
      .hljs-selector-pseudo {
        color: #D7BA7D
      }
      .hljs-addition {
        background-color: #144212;
        display: inline-block;
        width: 100%
      }
      .hljs-deletion {
        background-color: #600;
        display: inline-block;
        width: 100%
      }
      pre {
        margin: 0;
      }

      .actions{
        height:30px; 
        background: #b4b4b4; 
        display:flex; 
        align-items:center;
        padding:0 1rem; 
        color:#fff;
        .actions-list{
          display:flex;
          gap:1rem;
        }
      }
      .language {
        flex:1;
      }
      
      .action-item{
        display:flex; 
        align-items:center;
        justify-content: center;
        cursor:pointer;
        min-width: 70px;
      }
      .accepted{
        cursor:default;

      }
      .copied {
        cursor:default;
      }
    `;
__decorate([
    property({ type: String, reflect: true })
], CollabShowCodeSnippet100554.prototype, "language", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabShowCodeSnippet100554.prototype, "withCopy", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabShowCodeSnippet100554.prototype, "withAccept", void 0);
__decorate([
    property({ type: Boolean })
], CollabShowCodeSnippet100554.prototype, "coping", void 0);
__decorate([
    property({ type: Boolean })
], CollabShowCodeSnippet100554.prototype, "accepting", void 0);
__decorate([
    query('.code')
], CollabShowCodeSnippet100554.prototype, "codeBlock", void 0);
CollabShowCodeSnippet100554 = __decorate([
    customElement('collab-show-code-snippet-100554')
], CollabShowCodeSnippet100554);
export { CollabShowCodeSnippet100554 };
