/// <mls shortName="wcdDialogImageUnsplash" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { execute, executechange } from './_100554_wcdCommandAddImage';
import { CollabLitElement } from './_100554_collabLitElement';
import { globalWcd } from './_100554_wcdState';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    results: 'resultados',
    next: 'Próximo',
    placeholder: 'digite palavras chaves para buscar no Unsplash, e pressione Enter'
};
const message_en = {
    loading: 'Loading...',
    results: 'results',
    next: 'Next',
    placeholder: 'type keywords to search Unsplash, and press Enter'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdDialogImageUnsplash100554 = class WcdDialogImageUnsplash100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wcd-dialog-image-unsplash-100554{display:block;width:100%}wcd-dialog-image-unsplash-100554 .container{padding:1rem}wcd-dialog-image-unsplash-100554 .prompt-content{padding:10px;display:flex;margin-bottom:1rem}wcd-dialog-image-unsplash-100554 .prompt-content input{border:none;border-bottom:1px solid var(--grey-color);outline:none;width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}wcd-dialog-image-unsplash-100554 .result-info{display:flex;justify-content:center;width:100%}wcd-dialog-image-unsplash-100554 .result-info small{margin-left:auto;font-weight:200;font-size:var(--font-size-16);color:var(--grey-color-darker)}wcd-dialog-image-unsplash-100554 .result-info button{margin-left:auto;border:none;background:none;color:var(--text-color-primary);cursor:pointer}wcd-dialog-image-unsplash-100554 .gallery{display:grid;grid-template-columns:repeat(auto-fill, minmax(200px, 1fr));grid-auto-rows:200px;gap:10px;padding:10px}wcd-dialog-image-unsplash-100554 .gallery .gallery-item{box-shadow:0 4px 8px rgba(0,0,0,0.1);transition:transform .3s ease,filter .3s ease;cursor:pointer;border-radius:8px;position:relative}wcd-dialog-image-unsplash-100554 .gallery .gallery-item p{position:absolute;bottom:5px;left:5px;font-size:var(--font-size-12);color:#ffffff;display:none}wcd-dialog-image-unsplash-100554 .gallery img{width:100%;height:100%;display:block;border-radius:8px}wcd-dialog-image-unsplash-100554 .gallery .gallery-item:hover{transform:scale(1.05)}wcd-dialog-image-unsplash-100554 .gallery .gallery-item:hover p{display:block}wcd-dialog-image-unsplash-100554 .gallery .gallery-item img:hover{filter:brightness(.4)}@media (max-width:768px){wcd-dialog-image-unsplash-100554 .gallery{grid-template-columns:repeat(auto-fill, minmax(150px, 1fr))}}`);
        this.msg = messages['en'];
        this.images = [];
        this.totalResults = 0;
        this.totalPages = 0;
        this.actualPage = 1;
        this.query = '';
        this.lastQuery = '';
        this.perPage = 12;
        this.clientId = 'UEmilNZzuDCesxf1L__2J4T18vdlj6jHMsdeFet3WTQ';
    }
    async getImages() {
        const encodedQuery = encodeURIComponent(this.query);
        fetch(`https://api.unsplash.com/search/photos?query=${encodedQuery}&page=${this.actualPage}&per_page=${this.perPage}&client_id=${this.clientId}`)
            .then(response => response.json())
            .then(data => {
            this.totalPages = data.total_pages;
            this.totalResults = data.total;
            this.images = data.results;
        })
            .catch(error => console.error('Error:', error));
        return [];
    }
    async handleKeyDown(event) {
        event.stopPropagation();
        if (event.key === 'Enter') {
            if (this.lastQuery !== this.query) {
                this.actualPage = 1;
            }
            if (!this.query) {
                this.images = [];
                this.totalResults = 0;
                this.actualPage = 1;
                return;
            }
            await this.getImages();
        }
    }
    async handleNext() {
        this.actualPage += 1;
        if (this.actualPage > this.totalPages)
            return;
        await this.getImages();
    }
    handleInput(event) {
        event.stopPropagation();
        this.query = event.target?.value || '';
    }
    async handleGalleryClick(item) {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.myParent)
            throw new Error('Invalid window.wcdState.myParent');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        const args = this.args;
        if (args && args === 'change') {
            await executechange({
                args: { src: item.urls.full },
                overlay: globalWcd.myParent?.parentElement?.parentElement,
                selectedIca: globalWcd.elICA,
            });
            return;
        }
        await execute({
            args: { src: item.urls.full },
            overlay: globalWcd.myParent?.parentElement?.parentElement,
            selectedIca: globalWcd.elICA,
        });
    }
    recalculeIcaHeight() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        const height = this.getBoundingClientRect()?.height;
        if (this.lastHeight === undefined)
            this.lastHeight = globalWcd.elICA.style.height;
        globalWcd.elICA.style.height = height + 'px';
    }
    disconnectedCallback() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (globalWcd.elICA)
            globalWcd.elICA.style.height = this.lastHeight || '';
        else if (this.lastIca)
            this.lastIca.style.height = this.lastHeight || '';
        super.disconnectedCallback();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('images')) {
            this.recalculeIcaHeight();
        }
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.prompt)
            this.prompt.focus();
    }
    render() {
        this.lastIca = globalWcd.elICA;
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `

            <div class="container">

                <div class="prompt-content">
                    <input
                    @input=${this.handleInput.bind(this)} 
                    @keydown=${this.handleKeyDown.bind(this)} 
                    type="text" 
                    id="prompt-input"
                    placeholder=${this.msg.placeholder}
                    />
                </div>

                <div class="result-info" style=${this.query === '' ? 'display:none;' : 'display:flex;'}>
                    <small>
                        ${this.totalResults} ${this.msg.results}</small>
                    <button @click=${this.handleNext.bind(this)}>${this.msg.next}</button>

                </div>

                <div class="gallery">
                    ${this.images.map((image) => {
            return html `
                        <div @click=${() => { this.handleGalleryClick(image); }} class="gallery-item">
                            <img src=${image.urls.small}></img>
                            <p>${image.user.first_name}</p>
                        </div>`;
        })}
                </div>

            </div>

        `;
    }
};
__decorate([
    query('#prompt-input')
], WcdDialogImageUnsplash100554.prototype, "prompt", void 0);
__decorate([
    property()
], WcdDialogImageUnsplash100554.prototype, "images", void 0);
__decorate([
    property()
], WcdDialogImageUnsplash100554.prototype, "totalResults", void 0);
WcdDialogImageUnsplash100554 = __decorate([
    customElement('wcd-dialog-image-unsplash-100554')
], WcdDialogImageUnsplash100554);
export { WcdDialogImageUnsplash100554 };
