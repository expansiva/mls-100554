/// <mls shortName="collabConfigService" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
/// **collab_i18n_start**
const message_pt = {
    addService: 'Adicionar Serviço',
    back: 'Voltar',
    hidden: 'Oculto',
    style: 'Estilo'
};
const message_en = {
    addService: 'Add Service',
    back: 'Back',
    hidden: 'Hidden',
    style: 'Style'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabConfig100554 = class CollabConfig100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.currentScenario = 'list';
        this.error = '';
        this.positionToolbar = 'left';
        this.actualLevel = -1;
        this.userServices = [];
        this.avaliableServices = [];
        this.infos = {};
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.height = '100%';
        return html `
        <div class="bodyServiceConfig">
            ${this.currentScenario === 'list' ?
            html `
                    ${this.renderHeader()}
                    ${this.renderListServices()}
                `
            : html `
                    ${this.renderHeader()}
                    ${this.renderListAddServices()} 
                `}
        </div> `;
    }
    async connectedCallback() {
        super.connectedCallback();
        this.setInfos();
        await this.getServices();
    }
    renderHeader() {
        return html `
        
        <div class="header">
            
            ${this.currentScenario === 'list' ?
            html `
                    <button @click="${this.goToScenaryAdd}">${this.msg.addService}</button>
                `
            : html `
                    <button @click="${this.goToScenaryList}">${this.msg.back}</button>
                `}
            ${this.error ?
            html `
                    <div style="color:red">${this.error}</div>
                `
            : html ``}
            <div style="font-size:90%; display: flex; justify-content: center; align-items: center; padding-right: 0.5rem;">
                <span style="margin-right:5px">Position:</span>
                ${this.positionToolbar === 'left' ?
            html `<input type="radio" value="left" id="leftradioopt" name="radioOpt" checked 
                @click="${this.onclickPositionLeft}" />
                <label for="leftradioopt" style="margin-right:5px">left</label>
                <input type="radio" value="right" id="rightradioopt" name="radioOpt" @click="${this.onclickPositionRight}"/>
                <label for="rightradioopt">right</label>` :
            html `<input type="radio" value="left" id="leftradioopt" name="radioOpt"  
                @click="${this.onclickPositionLeft}" />
                <label for="leftradioopt" style="margin-right:5px">left</label>
                <input type="radio" value="right" id="rightradioopt" name="radioOpt" @click="${this.onclickPositionRight}" checked/>
                <label for="rightradioopt">right</label>`}
                
            </div>
        </div>
        `;
    }
    onclickPositionLeft() {
        this.positionToolbar = 'left';
        this.getServices();
    }
    onclickPositionRight() {
        this.positionToolbar = 'right';
        this.getServices();
    }
    renderListAddServices() {
        return html `
        <ul class="listView">
            ${repeat(this.avaliableServices, ((item) => item.icon), ((service, index) => {
            return html `
                        <li>
                            <div class="groupInfos" style="justify-content:start;">
                                <div>#${index + 1}</div>
                                <div>
                                    ${service.tooltip}
                                </div>
                            </div>
                            <div class="groupInfos" style="justify-content:end;">
                                <div>
                                    <a myIndex="${index}" @click="${this.activeService}">Active</a>
                                </div>
                            </div>
                        </li>
                    `;
        }))}    
        </ul>
        `;
    }
    renderListServices() {
        return html `
        <ul class="listView">
            ${repeat(this.userServices, ((item) => item.widget), ((service, index) => {
            return html `
                    <li>
                        <div class="groupInfos" style="justify-content:start;">
                            <div>#${index + 1}</div>
                            <div>
                                ${service.tooltip}
                                <span class="badge" style="display:${service.visible ? 'none' : 'inline-block'}">${this.msg.hidden}<span>
                            </div>
                        </div>
                        <div class="groupInfos" style="justify-content:end;display:flex; gap:1rem;">
                            <div style="display: flex; justify-content: center; align-items: center;">
                                <span class="fa fa-ellipsis-vertical" style="cursor:pointer" @click="${this.openHiddenConfigs}"></span>
                                <span class="groupHidden" style="display:none">
                                    <a myIndex="${index}" @click="${this.desactiveService}">Desactivate</a>
                                    <span style="margin: 0px 1rem">|</span>
                                    <label>${this.msg.style}</label>
                                    <select  myIndex="${index}" @change="${this.changeClassName}"> 
                                        <option value="" ?selected="${service && !['separator-left', 'separator-right'].includes(service.classname)}"></option>
                                        <option value="separator-left" ?selected="${service.classname === 'separator-left'}">separator-left</option>
                                        <option value="separator-right" ?selected="${service.classname === 'separator-right'}">separator-right</option>
                                    </select>
                                    
                                </span>
                            </div>
                            <div>
                                <span class="fa fa-arrow-up-long" style="cursor:pointer" move="up" myIndex="${index}" @click="${this.moveElement}"></span>
                                <span class="fa fa-arrow-down-long" style="cursor:pointer" move="down" myIndex="${index}" @click="${this.moveElement}"></span>
                            </div>
                        </div>
                    </li>
                    `;
        }))}
        </ul>
        `;
    }
    setInfos() {
        this.infos.nav = this.closest('collab-nav-3')?.previousElementSibling;
        if (!this.infos.nav)
            return;
        const level = this.infos.nav.getAttribute('level');
        this.actualLevel = level ? +level : -1;
    }
    goToScenaryAdd() {
        this.currentScenario = 'add';
    }
    goToScenaryList() {
        this.currentScenario = 'list';
    }
    openHiddenConfigs(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const elHidden = el.parentElement?.querySelector('.groupHidden');
        if (!elHidden)
            return;
        const state = elHidden.style.display === '' ? 'none' : '';
        elHidden.style.display = state;
    }
    changeClassName(e) {
        const el = e.target;
        if (!el)
            return;
        const indexs = el.getAttribute('myIndex');
        let indexOri = indexs ? +indexs : -1;
        if (!this.userServices[indexOri])
            return;
        this.userServices = [...this.userServices];
        this.fireChangeClassName(indexOri, el.value);
    }
    desactiveService(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const indexs = el.getAttribute('myIndex');
        let indexOri = indexs ? +indexs : -1;
        const userArray = [...this.userServices];
        const avaliableArray = [...this.avaliableServices];
        const obj = userArray[indexOri];
        if (!obj || obj.isStatic) {
            this.error = 'This service cannot be deactivated!';
            setTimeout(() => { this.error = ''; }, 3000);
            return;
        }
        ;
        avaliableArray.push(obj);
        userArray.splice(indexOri, 1);
        this.userServices = userArray;
        this.avaliableServices = avaliableArray;
        this.fireRemoveService(indexOri);
    }
    activeService(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const indexs = el.getAttribute('myIndex');
        let indexOri = indexs ? +indexs : -1;
        const userArray = [...this.userServices];
        const avaliableArray = [...this.avaliableServices];
        const obj = avaliableArray[indexOri];
        if (!obj)
            return;
        userArray.push(obj);
        avaliableArray.splice(indexOri, 1);
        this.userServices = userArray;
        this.avaliableServices = avaliableArray;
        this.fireAddService(obj);
    }
    moveElement(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const move = el.getAttribute('move');
        const indexs = el.getAttribute('myIndex');
        let indexOri = indexs ? +indexs : -1;
        let indexDest = -1;
        if (indexOri < 0 || (move === 'up' && indexOri === 0) || (move === 'down' && indexOri === this.userServices.length - 1))
            return;
        indexDest = move === 'up' ? indexOri - 1 : indexDest = indexOri + 1;
        if (indexDest === indexOri)
            return;
        const objTo = this.userServices[indexDest];
        const objFrom = this.userServices[indexOri];
        if (objTo.isStatic) {
            this.error = 'This service cannot be moved to this position!';
            setTimeout(() => { this.error = ''; }, 3000);
            return;
        }
        if (!objFrom)
            return;
        if (objFrom.isStatic) {
            this.error = 'This service is static, cannot be moved';
            setTimeout(() => { this.error = ''; }, 3000);
            return;
        }
        if (indexOri < indexDest) {
            this.userServices.splice((indexDest + 1), 0, objFrom);
            this.userServices.splice(indexOri, 1);
        }
        else {
            this.userServices.splice(indexDest, 0, objFrom);
            this.userServices.splice((indexOri + 1), 1);
        }
        this.userServices = [...this.userServices];
        this.fireMoveService(indexOri, indexDest);
    }
    async getServices() {
        const arrayUserServices = await this.getUserServices();
        const arrayAvaliableServices = await this.getAvaliableServices();
        this.userServices = arrayUserServices[this.actualLevel][this.positionToolbar];
        this.avaliableServices = arrayAvaliableServices[this.actualLevel][this.positionToolbar];
    }
    async getAvaliableServices() {
        if (!this.infos.nav)
            return [];
        const avaliableServices = await this.infos.nav.getAvaliableServices();
        return avaliableServices;
    }
    async getUserServices() {
        if (!this.infos.nav)
            return [];
        const avaliableServices = this.infos.nav.getUserServices();
        return avaliableServices;
    }
    async fireChangeClassName(index, cls) {
        if (!this.infos.nav)
            return;
        await this.infos.nav.updateClassName(index, cls, this.actualLevel, this.positionToolbar);
    }
    async fireAddService(service) {
        if (!this.infos.nav)
            return;
        await this.infos.nav.addService(service, this.actualLevel, this.positionToolbar);
    }
    async fireRemoveService(index) {
        if (!this.infos.nav)
            return;
        await this.infos.nav.removeService(index, this.actualLevel, this.positionToolbar);
    }
    async fireMoveService(indexOri, indexDest) {
        if (!this.infos.nav)
            return;
        await this.infos.nav.moveService(indexOri, indexDest, this.actualLevel, this.positionToolbar);
    }
};
CollabConfig100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property({ type: String })
], CollabConfig100554.prototype, "currentScenario", void 0);
__decorate([
    property({ type: String })
], CollabConfig100554.prototype, "error", void 0);
__decorate([
    property({ type: String })
], CollabConfig100554.prototype, "positionToolbar", void 0);
__decorate([
    property({ type: Number })
], CollabConfig100554.prototype, "actualLevel", void 0);
__decorate([
    property({ type: Array })
], CollabConfig100554.prototype, "userServices", void 0);
__decorate([
    property({ type: Array })
], CollabConfig100554.prototype, "avaliableServices", void 0);
CollabConfig100554 = __decorate([
    customElement('collab-config-service-100554')
], CollabConfig100554);
export { CollabConfig100554 };
