/// <mls shortName="beTableProduto" project="100554" enhancement="_blank" groupName="other" />
import { TableDriverBase } from "./_100554_beTableBase";
export const modelPrisma = `
  model Produto {
    id Int @id @default(autoincrement())
    nome String
    descricao String
    preco Float
    imagem String
    categoria String
  }
`;
class ProdutoDriver extends TableDriverBase {
    constructor() {
        super(...arguments);
        this.entityKey = "produtos";
        this.dbName = "collab";
        this.tableName = "produtos";
        this.modelPrisma = modelPrisma;
    }
}
export const factoryProdutoDriver = (provider) => {
    const instance = new ProdutoDriver(provider);
    instance.subscribe();
};
