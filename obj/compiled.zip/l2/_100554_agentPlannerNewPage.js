/// <mls shortName="agentPlannerNewPage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { svg_agent } from './_100554_aiAgentBase';
import './_100554_wcClarification';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, calculateStepsStatistics, updateStepStatus, getInteractionStepId, getStepById } from "./_100554_aiAgentHelper";
import { startNewAiTask, executeNextStep, startNewInteractionInAiTask, addNewStep } from "./_100554_aiAgentOrchestration";
const agentName = "agentPlannerNewPage";
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Responsável por definir os detalhes de criação de uma nova página no sistema",
        visibility: "private",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async beforeClarification(context, stepId) {
            return _beforeClarification(context, stepId);
        },
        async afterClarification(context, stepId, data) {
            return _afterClarification(context, stepId, data);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (!context.task) {
        // using temporary context, create a new task
        const inputs = await getPrompts(context.message.content, null);
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
    }
    else {
        const step = getNextPendingStepByAgentName(context.task, agentName);
        if (!step) {
            throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
        }
        context.task = await updateStepStatus(context.task, step.stepId, "in_progress");
        const inputs = await getPrompts(step.prompt, step.rags);
        await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
    }
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
    const { flexible } = calculateStepsStatistics([step], true);
    if (flexible > 0)
        throw new Error(`[${agentName}] afterPrompt: error, Flexible step found.`);
    context.task = await updateStepStatus(context.task, step.stepId, "completed");
    await executeNextStep(context);
};
const _beforeClarification = async (context, stepId) => {
    if (!context.task)
        throw new Error("[_beforeClarification] Invalid context.task");
    const step = getStepById(context.task, stepId);
    if (!step)
        throw new Error(`[_beforeClarification] Invalid step: ${stepId} on task: ${context.task.PK}`);
    if (!step.json)
        throw new Error(`[_beforeClarification] Invalid step json on task: ${context.task.PK} step ${stepId}`);
    const element = prepareHtmlClarification(step.json, context.task.PK, stepId, step.clarificationMessage);
    return element;
};
const _afterClarification = async (context, stepId, data) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    if (!data.json)
        throw new Error("Invalid json after clarification");
    const step = getStepById(context.task, stepId);
    if (!step) {
        throw new Error(`[${agentName}] _afterClarification: No found step: ${stepId} for this agent.`);
    }
    const interactionId = getInteractionStepId(context.task, step.stepId);
    if (!interactionId)
        throw new Error("[_afterClarification] Not found interactionId in pending step");
    const payload = getStepById(context.task, interactionId);
    if (!payload || payload.type !== "agent")
        throw new Error("[_afterClarification] Clarification or tool step not bellow a agent");
    const promptUser = payload.interaction?.input.find((input) => input.type === 'human')?.content || '';
    let newPrompt = '';
    data.json.forEach((cl) => {
        const text = Array.isArray(cl.value) ? '-' + cl.value.join('\n -') : cl.value;
        newPrompt = newPrompt + ` ** ${cl.description}\n ${text} `;
    });
    const newStep = {
        agentName,
        prompt: promptUser + '\n' + newPrompt,
        status: 'pending',
        stepId: step.stepId + 1,
        interaction: null,
        nextSteps: null,
        rags: null,
        type: 'agent'
    };
    await addNewStep(context, step.stepId, [newStep]);
};
function prepareHtmlClarification(json, taskId, stepId, clarificationMessage) {
    const div = document.createElement('div');
    const wc = document.createElement('wc-clarification-100554');
    const data = {
        type: "clarification",
        taskId: taskId,
        stepId: stepId.toString(),
        clarificationMessage: clarificationMessage,
        json
    };
    div.appendChild(wc);
    wc.clarificationData = data;
    return div;
}
export async function getPrompts(prompt, rags) {
    if (!prompt || prompt.length < 3)
        throw new Error("Invalid Prompt");
    const prompts = [];
    prompts.push(systemMainInstruction());
    prompts.push(systemRulesInstruction());
    prompts.push(systemOutInstruction());
    prompts.push({
        type: 'human',
        content: prompt
    });
    return prompts;
}
function systemMainInstruction() {
    return {
        type: 'system',
        content: `
Você é um planejador responsável por definir os detalhes de criação de uma nova página no sistema.

Com base no prompt original do usuário, sua tarefa é:
1. Entender o propósito da página.
2. Escolher o nome da página.
3. Determinar o tipo da página, usando o enum \`PageType\`.
4. Verificar se há APIs, states ou dados existentes que podem ser usados. Caso não existam, deve sugerir o que precisa ser criado e aguardar uma confirmação ou complementação do usuário.
5. Especificar cada campo necessário (widgets), se o usuario não passar os campos, coloque os campos que você achar necessario para o funcionamento da pagina.
6. Definir restrições e requerimentos técnicos ou funcionais.
7. Se os dados forem suficientes, preparar a chamada para o agente \`agenteCreateHtml1\`.
8. Se necessário, peça mais informações ao usuário usando o tipo \`clarification\`. Sempre que possível, inclua um \`htmlForm\` com campos e respostas prontas (como botões, selects ou inputs) para facilitar a interação. O formulário será exibido ao usuário e os dados enviados serão incluídos automaticamente no próximo prompt.  Se for necessária uma \`clarification\`, retorne **apenas essa subtarefa**. Não crie outros agentes ou ferramentas até que a resposta do usuário seja recebida.
`
    };
}
function systemRulesInstruction() {
    return {
        type: 'system',
        content: `## Regras adicionais:
  •	O campo widgets é obrigatório se for criar a página.
  •	O Nome da página que você criar deve ser no formato pageXxx , onde ‘page’ é o sufixo obrigatório.
  •	Cada widget deve conter:
  •	name: identificador curto
  •	binding: no formato "{{[pageName].[name]}}" (não confundir com bindings reais dos states)
  •	description: funcionalidade do componente
  •	Se o tipo da página estiver ambíguo, retorne uma clarificationMessage solicitando mais detalhes ao usuário.`
    };
}
function systemOutInstruction() {
    return {
        type: 'system',
        content: `## Formato de saída 
Você deve retornar **apenas um dos seguintes formatos** no array JSON:

\`\`\`json
[
  {
    "type": "agent",
    "agentName": "agenteCreateHtml1",
    "taskTitle": string,
    "promptUser": string, // original do usuario,
    "rags": null,
    "prompt":{
      "pageName": string,
      "pageType": "crud" | "report" | "dashboard" | "form" | "search" | "workflow" | "config" | "association",
      "loadContext": false,
      "requirements": string,
      "widgets": [
        {
          "name": string,
          "binding": string,
          "description": string
        }
      ]
    }  
  }
]
ou
[
  {
    "type": "clarification",
    "clarificationMessage": string,
    "json": TClarification
  }
]
\`\`\`
 
definição de TClarification
\`\`\`json
[
    
  {
    "sectionName": "pageName",
    "description": "Nome da pagina",
    "value": "nomedapagina"
  },
  {
    "sectionName": "requirements",
    "description": "requisitos para esta pagina, altere se necessário",
    "value": [
      "exemplo 1 - Suporte para autenticação de usuário",
      "exemplo 2 - Validação de campos de entrada"
    ]
  }
]
\`\`\`

`
    };
}
