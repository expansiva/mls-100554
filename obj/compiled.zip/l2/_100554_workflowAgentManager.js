/// <mls shortName="workflowAgentManager" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import * as plannermain from './_100554_agentPlanner1';
export let url = 'https://collab.codes/msg';
export let userId = '20250306212720.1000';
export let threadId = '20250304200000.1000';
export async function getTask(messageId, taskId) {
    return execGetTaskUpdate(messageId, taskId);
}
export async function execNewPrompt(prompt) {
    return _execNewPrompt(prompt);
}
//--------IMPLEMENTS---------
async function _execNewPrompt(prompt) {
    const inputs = plannermain.startPrompt(prompt);
    const tagInitial = await execAddTask(inputs, prompt);
    if (!tagInitial)
        throw new Error('Error create tag');
    const after = await plannermain.afterPrompt(tagInitial, tagInitial.iaCompressed?.interaction?.payload);
    console.info({ executou: 'agentPlanner1', resultado: tagInitial.iaCompressed?.interaction?.payload });
    return await _execNextPass(tagInitial, after);
}
async function _execNextPass(task, steps) {
    for await (let step of steps) {
        try {
            const instanceAgent = await import(`./_100554_${step.agent}`);
            if (!instanceAgent) {
                console.info(`Invalid instance for agent : ${step.agent}, step: ${step.stepFather} `);
                continue;
            }
            if (!instanceAgent.beforePrompt) {
                console.info('Invalid function beforePrompt');
                continue;
            }
            const inputs = instanceAgent.beforePrompt(task, step.nextprompt);
            if (!inputs || !task.messageid_created) {
                console.info('Invalid inputs or task messageid');
                continue;
            }
            const taskUpdt = await execAddTaskAIInteraction(inputs, task.messageid_created, task.PK, step.stepFather);
            const payload = getPayloadByStep(taskUpdt, step.stepFather + 1);
            console.info({ executou: step.agent, resultado: payload });
            if (payload && payload.type && ['clarification', 'result', 'tool'].includes(payload.type)) {
                if (payload.type === 'clarification') {
                    await execUpdateStepStatus(task.messageid_created || '', task.PK, step.stepFather, 'waiting_for_user');
                }
                continue;
            }
            else {
                const after = await instanceAgent.afterPrompt(task, payload);
                await _execNextPass(task, after);
            }
        }
        catch (e) {
            console.info(e.message);
            await execUpdateStepStatus(task.messageid_created || '', task.PK, step.stepFather, 'failed');
        }
    }
    return await execGetTaskUpdate(task.messageid_created || '', task.PK);
}
function getPayloadByStep(task, step) {
    let ret = undefined;
    const getPayload = (interaction) => {
        if (!interaction || ret !== undefined)
            return;
        if (interaction.payload && interaction.payload.length > 0) {
            interaction.payload.forEach((p) => {
                if (ret === undefined && p.stepId === step)
                    ret = p;
                getPayload(p.interaction);
            });
        }
    };
    getPayload(task.iaCompressed?.interaction);
    return ret;
}
//--------CALL IO------------
async function execUpdateStepStatus(messageId, taskId, stepId, status) {
    const result = await callAPI(url, {
        action: "updateStepStatus",
        userId,
        messageId,
        taskId,
        stepId,
        status
    });
    return result;
}
async function execGetTaskUpdate(messageId, taskId) {
    const result = await callAPI(url, {
        action: "getTaskUpdate",
        userId,
        messageId,
        taskId,
    });
    return result.task;
}
async function execAddTask(inputAI, message) {
    const result = await callAPI(url, {
        action: 'addMessageAI',
        userId,
        threadId,
        message,
        inputAI,
    });
    return result.task;
}
async function execAddTaskAIInteraction(inputAI, messageId, taskId, parentStepId) {
    const result = await callAPI(url, {
        action: "addTaskAIInteraction",
        userId,
        messageId,
        taskId,
        parentStepId,
        inputAI,
    });
    return result.task;
}
async function callAPI(url, body, method = 'POST') {
    const response = await fetch(url, {
        method,
        credentials: 'omit',
        headers: {
            'Content-Type': 'application/json',
        },
        body: method === 'POST' ? JSON.stringify(body) : undefined,
    });
    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Erro na requisição: ${response.status} - ${errorText}`);
    }
    return await response.json();
}
