/// <mls shortName="workflowAgentManager" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export let url = 'https://collab.codes/msg';
export let userId = '20250417120844.1000';
export let threadId = '20250417133813.1000';
export async function getTask(messageId, taskId) {
    return execGetTaskUpdate(messageId, taskId);
}
/*export async function execNewPrompt(prompt: string): Promise<iaChat.TaskData> {
    return _execNewPrompt(prompt);
}*/
export async function execPromptByTaskStep(msgId, taskPK, agenteName, step, prompt) {
    return _execPromptByTaskStep(msgId, taskPK, agenteName, step, prompt);
}
//--------IMPLEMENTS---------
/*async function _execNewPrompt(prompt: string): Promise<iaChat.TaskData> {
    const inputs = plannermain.startPrompt(prompt);
    const tagInitial = await execAddTask(inputs, prompt);
    if (!tagInitial) throw new Error('Error create tag');
    const after = await plannermain.afterPrompt(tagInitial, tagInitial.iaCompressed?.interaction?.payload)
    console.info({ executou: 'agentPlanner1', resultado: tagInitial.iaCompressed?.interaction?.payload });
    return await _execNextPass(tagInitial, after);

}*/
async function _execPromptByTaskStep(msgId, taskPK, agenteName, step, prompt) {
    const task = await execGetTaskUpdate(msgId, taskPK);
    const after = [{
            agent: agenteName,
            nextprompt: prompt,
            stepFather: step
        }];
    return await _execNextPass(task, after);
}
async function _execNextPass(task, steps) {
    for await (let step of steps) {
        try {
            const instanceAgent = await import(`./_100554_${step.agent}`);
            if (!instanceAgent) {
                console.info(`Invalid instance for agent : ${step.agent}, step: ${step.stepFather} `);
                continue;
            }
            if (!instanceAgent.beforePrompt) {
                console.info('Invalid function beforePrompt');
                continue;
            }
            const inputs = instanceAgent.beforePrompt(task, step.nextprompt);
            if (!inputs || !task.messageid_created) {
                console.info('Invalid inputs or task messageid');
                continue;
            }
            const taskUpdt = await execAddTaskAIInteraction(inputs, task.messageid_created, task.PK, step.stepFather);
            const payload = getPayloadByStep(taskUpdt, step.stepFather + 1);
            console.info({ executou: step.agent, resultado: payload });
            if (payload && payload.type && ['clarification', 'result', 'tool'].includes(payload.type)) {
                if (payload.type === 'clarification') {
                    await execUpdateStepStatus(task.messageid_created || '', task.PK, step.stepFather, 'waiting_for_user');
                }
                continue;
            }
            else {
                const after = await instanceAgent.afterPrompt(task, payload);
                await _execNextPass(task, after);
            }
        }
        catch (e) {
            console.info(e.message);
            await execUpdateStepStatus(task.messageid_created || '', task.PK, step.stepFather, 'failed');
        }
    }
    return await execGetTaskUpdate(task.messageid_created || '', task.PK);
}
function getPayloadByStep(task, step) {
    let ret = undefined;
    const getPayload = (interaction) => {
        if (!interaction || ret !== undefined)
            return;
        if (interaction.payload && interaction.payload.length > 0) {
            interaction.payload.forEach((p) => {
                if (ret === undefined && p.stepId === step)
                    ret = p;
                getPayload(p.interaction);
            });
        }
    };
    getPayload(task.iaCompressed?.interaction);
    return ret;
}
//--------CALL IO------------
async function execUpdateStepStatus(messageId, taskId, stepId, status) {
    const result = await mls.api.msgUpdateStepStatus({
        action: "updateStepStatus",
        userId,
        messageId,
        taskId,
        stepId,
        status
    });
    return result;
}
async function execGetTaskUpdate(messageId, taskId) {
    const result = await mls.api.msgGetTaskUpdate({
        action: "getTaskUpdate",
        userId,
        messageId,
        taskId,
    });
    return result.task;
}
async function execAddTask(inputAI, message) {
    const result = await mls.api.msgAddMessageAI({
        action: 'addMessageAI',
        userId,
        threadId,
        message,
        inputAI,
    });
    return result.task;
}
async function execAddTaskAIInteraction(inputAI, messageId, taskId, parentStepId) {
    const result = await mls.api.msgAddTaskAIInteraction({
        action: "addTaskAIInteraction",
        userId,
        messageId,
        taskId,
        parentStepId,
        inputAI,
    });
    return result.task;
}
