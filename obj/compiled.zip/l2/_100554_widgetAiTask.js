/// <mls shortName="widgetAiTask" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_money, collab_pause, collab_stop, collab_play, collab_clock, collab_triangle_exclamation, collab_check, collab_bug } from './_100554_collabIcons';
import { getInternalStatus } from './_100554_iaChatBase';
let WidgetAiTask100554 = class WidgetAiTask100554 extends IcaLitElement {
    constructor() {
        // @property() status: 'todo' | 'in progress' | 'done' | 'paused' | 'waitingforuser' = 'in progress';
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ai-task-100554{box-shadow:rgba(50,50,93,0.25) 0 2px 5px -1px,rgba(0,0,0,0.3) 0 1px 3px -1px;overflow:hidden;cursor:pointer;margin-right:50px;margin-left:50px;background-color:#fff;color:#000000;min-height:60px;display:flex;align-items:center}widget-ai-task-100554 .card{display:block;padding:var(--space-16);width:100%;position:relative}widget-ai-task-100554 .card .task-icon.failed{fill:var(--error-color)}widget-ai-task-100554 .card .task-icon.completed{fill:var(--success-color)}widget-ai-task-100554 .card .task-icon.waiting_for_user{fill:var(--warning-color)}widget-ai-task-100554 .card .card-header{display:flex;justify-content:space-between;gap:1rem;align-items:center}widget-ai-task-100554 .card .card-header .card-user{color:#be069c}widget-ai-task-100554 .card .card-header .card-time{font-size:.75rem;color:gray;position:absolute;bottom:0px;right:10px;text-align:right}widget-ai-task-100554 .card .card-header .card-title{font-size:var(--font-size-12);font-weight:bold}widget-ai-task-100554 .card .card-header .card-price{display:flex;align-items:center;gap:.2rem;font-size:var(--font-size-12)}widget-ai-task-100554 .card .card-header .card-price svg{width:12px;height:12px}widget-ai-task-100554 .card .card-header .card-actions{display:flex;gap:.4rem;align-items:center}widget-ai-task-100554 .card .card-header .card-actions i{cursor:pointer}widget-ai-task-100554 .card .card-header .card-actions i:hover{transform:scale(1.1)}widget-ai-task-100554 .card .card-header .card-actions svg{width:12px;height:12px}widget-ai-task-100554 .card .card-header .card-status{text-transform:uppercase;font-size:var(--font-size-12);border:1px solid;padding:0 .3rem;border-radius:4px;white-space:nowrap}widget-ai-task-100554 .card .card-header .card-status.todo{color:var(--grey-color-darker)}widget-ai-task-100554 .card .card-header .card-status.done{color:var(--success-color)}widget-ai-task-100554 .card .card-header .card-status.in-progress{color:var(--active-color)}widget-ai-task-100554 .card .card-header .card-status.waitingforuser{color:var(--warning-color)}widget-ai-task-100554 .card .card-header .card-status.paused{color:var(--info-color-disabled)}widget-ai-task-100554 .card .card-body{margin-top:var(--space-16)}widget-ai-task-100554 .card .card-body .card-message{font-size:var(--font-size-16)}`);
        this.taskid = '';
        this.taskTitle = '';
        this.taskUserName = '';
        this.taskTime = '';
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('taskid') && changedProperties.get('taskid') !== '') {
            this.getTask(this.taskid);
        }
    }
    render() {
        const statusFake = 'in progress';
        const priceFake = '0.0001'; ///<span class="card-price"> ${collab_money}${getTotalCost(this.task)}</span>
        return html `<div @click=${this.onCardClick} class="card"> 
            <div class="card-header">
                ${this.renderIconTask()}
                <span class="card-user">@${this.taskUserName}</span>
                <span class="card-title">${this.taskTitle}</span>
                <span class="card-status ${statusFake.split(' ').join('-')}">${statusFake}</span>
                <span class="card-price"> ${collab_money}${priceFake}</span>
                <span class="card-time"> ${this.taskTime}</span>

                <div class="card-actions">
                    ${['in progress', 'waitingforuser', 'todo'].includes(statusFake)
            ? html `
                    <i>${collab_pause}</i>
                    <i>${collab_stop}</i>`
            : ['paused'].includes(statusFake)
                ? html `
                        <i>${collab_play}</i>
                        <i>${collab_stop}</i>`
                : html ``}
                    
                </div>

            </div>
         </div>`;
    }
    renderIconTask() {
        const taskObj = {
            'pending': collab_clock,
            'in_progress': collab_clock,
            'completed': collab_check,
            'failed': collab_bug,
            'waiting_for_user': collab_triangle_exclamation
        };
        if (!this.task)
            return;
        const internalStatus = getInternalStatus(this.task);
        if (!internalStatus)
            return '';
        return html `<span @click= ${(e) => { e.stopPropagation(); this.onStatusClick(e, internalStatus); }} class="task-icon ${internalStatus.status}">${taskObj[internalStatus.status]}</span>`;
    }
    getTask(taskId) {
    }
    onStatusClick(ev, data) {
        const event = new CustomEvent('taskclick', {
            detail: { stepId: data.stepId },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }
    onCardClick() {
        const event = new CustomEvent('taskclick', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }
};
__decorate([
    property()
], WidgetAiTask100554.prototype, "taskid", void 0);
__decorate([
    property()
], WidgetAiTask100554.prototype, "taskTitle", void 0);
__decorate([
    property()
], WidgetAiTask100554.prototype, "taskUserName", void 0);
__decorate([
    property()
], WidgetAiTask100554.prototype, "taskTime", void 0);
__decorate([
    state()
], WidgetAiTask100554.prototype, "task", void 0);
WidgetAiTask100554 = __decorate([
    customElement('widget-ai-task-100554')
], WidgetAiTask100554);
export { WidgetAiTask100554 };
