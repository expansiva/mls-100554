/// <mls shortName="widgetAiTask" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { getTask } from './_100554_msgDBController';
import { getNextPendentStep, getTotalCost } from './_100554_aiAgentHelper';
import { collab_money, collab_pause, collab_bell, collab_chevron_right, collab_clock, collab_check, collab_bug } from './_100554_collabIcons';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
};
const message_en = {
    loading: 'Loading...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WidgetAiTask100554 = class WidgetAiTask100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ai-task-100554{box-shadow:rgba(50,50,93,0.25) 0 2px 5px -1px,rgba(0,0,0,0.3) 0 1px 3px -1px;overflow:hidden;cursor:pointer;background-color:#fff;color:#000000;height:40px;display:flex;align-items:center;border-radius:10px}widget-ai-task-100554 .card.no-details{display:block}widget-ai-task-100554 .card{display:block;padding:var(--space-16);width:100%;position:relative}widget-ai-task-100554 .card .task-icon .icon-wrapper{position:relative;display:inline-block;font-size:20px}widget-ai-task-100554 .card .task-icon .notification-badge{position:absolute;top:-1px;right:-3px;background:red;color:white;border-radius:50%;padding:.1em .1em;font-size:.49em;font-weight:bold;line-height:1;min-width:1em;text-align:center}widget-ai-task-100554 .card .task-icon.failed{fill:var(--error-color);color:var(--error-color)}widget-ai-task-100554 .card .task-icon.done{fill:var(--success-color);color:var(--success-color)}widget-ai-task-100554 .card .task-icon.waitingforuser{fill:var(--warning-color);color:var(--warning-color)}widget-ai-task-100554 .card .card-header{display:flex;justify-content:space-between;gap:1rem;align-items:center}widget-ai-task-100554 .card .card-header .card-user{color:#be069c}widget-ai-task-100554 .card .card-header .card-time{font-size:.75rem;color:gray;position:absolute;bottom:0px;right:10px;text-align:right}widget-ai-task-100554 .card .card-header .card-title{font-size:var(--font-size-12);font-weight:bold}widget-ai-task-100554 .card .card-header .card-price{display:flex;align-items:center;gap:.2rem;font-size:var(--font-size-12)}widget-ai-task-100554 .card .card-header .card-price svg{width:12px;height:12px}widget-ai-task-100554 .card .card-header .card-actions{display:flex;gap:.4rem;align-items:center}widget-ai-task-100554 .card .card-header .card-actions i{cursor:pointer}widget-ai-task-100554 .card .card-header .card-actions i:hover{transform:scale(1.1)}widget-ai-task-100554 .card .card-header .card-actions svg{width:12px;height:12px}widget-ai-task-100554 .card .card-header .card-status{text-transform:uppercase;font-size:var(--font-size-12);border:1px solid;padding:0 .3rem;border-radius:4px;white-space:nowrap}widget-ai-task-100554 .card .card-header .card-status.todo{color:var(--grey-color-darker)}widget-ai-task-100554 .card .card-header .card-status.done{color:var(--success-color)}widget-ai-task-100554 .card .card-header .card-status.in-progress{color:var(--active-color)}widget-ai-task-100554 .card .card-header .card-status.waitingforuser{color:var(--warning-color)}widget-ai-task-100554 .card .card-header .card-status.paused{color:var(--info-color-disabled)}widget-ai-task-100554 .card .card-body{margin-top:var(--space-16)}widget-ai-task-100554 .card .card-body .card-message{font-size:var(--font-size-16)}`);
        this.msg = messages['en'];
        this.taskid = '';
        this.messageid = '';
        this.lastChanged = '';
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('lastChanged')) {
            if (this.context && this.context.task) {
                this.task = this.context.task;
            }
        }
        if (changedProperties.has('taskid') && changedProperties.get('taskid') !== '') {
            this.getTaskLocal(this.taskid);
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.task) {
            return html `<div @click=${this.onCardClick} class="card no-details"> 
            <div class="card-header">
                <span class="card-title">Task</span>
                ${collab_chevron_right}
            </div>
         </div>`;
        }
        const price = getTotalCost(this.task) || '0.00';
        const title = this.task.title || '...';
        return html `<div @click=${this.onCardClick} class="card"> 
            <div class="card-header">
                ${this.renderIconTask()}
                    <span class="card-title"> ${title}</span>
                    <span class="card-price"> ${collab_money}${price}</span>
            </div>
         </div>`;
    }
    renderIconTask() {
        const taskObj = {
            '': html ``,
            'pending': collab_clock,
            'paused': collab_pause,
            'todo': collab_clock,
            'in progress': collab_clock,
            'done': collab_check,
            'failed': collab_bug,
            'waitingforuser': html `
                    <span class="icon-wrapper">
                        ${collab_bell}
                        <span class="notification-badge">1</span>
                    </span>`,
        };
        let status = '';
        if (this.task) {
            status = this.task.status;
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                status = 'waitingforuser';
        }
        if (!this.task)
            return html `<spanclass="task-icon in progress ">${collab_clock}</span>`;
        return html `<span class="task-icon ${status.split(' ').join('-')} ">${taskObj[status]}</span>`;
    }
    async getTaskLocal(taskId) {
        const task = await getTask(taskId);
        if (task)
            this.task = task;
    }
    onCardClick() {
        const event = new CustomEvent('taskclick', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }
};
__decorate([
    property()
], WidgetAiTask100554.prototype, "taskid", void 0);
__decorate([
    property()
], WidgetAiTask100554.prototype, "messageid", void 0);
__decorate([
    property()
], WidgetAiTask100554.prototype, "lastChanged", void 0);
__decorate([
    state()
], WidgetAiTask100554.prototype, "task", void 0);
__decorate([
    state()
], WidgetAiTask100554.prototype, "context", void 0);
WidgetAiTask100554 = __decorate([
    customElement('widget-ai-task-100554')
], WidgetAiTask100554);
export { WidgetAiTask100554 };
