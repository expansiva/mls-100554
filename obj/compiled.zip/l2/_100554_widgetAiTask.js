/// <mls shortName="widgetAiTask" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_money, collab_pause, collab_stop, collab_play, collab_clock, collab_triangle_exclamation, collab_check, collab_bug } from './_100554_collabIcons';
import { getTotalCost, getInternalStatus } from './_100554_iaChatBase';
let WidgetAiTask100554 = class WidgetAiTask100554 extends IcaLitElement {
    constructor() {
        // @property() status: 'todo' | 'in progress' | 'done' | 'paused' | 'waitingforuser' = 'in progress';
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-ai-task-100554{display:block;box-shadow:rgba(50,50,93,0.25) 0 2px 5px -1px,rgba(0,0,0,0.3) 0 1px 3px -1px;overflow:hidden;cursor:pointer;margin-right:50px;margin-left:50px;background-color:#fff;color:#000000}widget-ai-task-100554 .card{display:block;padding:var(--space-16)}widget-ai-task-100554 .card .task-icon.failed{fill:var(--error-color)}widget-ai-task-100554 .card .task-icon.completed{fill:var(--success-color)}widget-ai-task-100554 .card .task-icon.waiting_for_user{fill:var(--warning-color)}widget-ai-task-100554 .card .card-header{display:flex;justify-content:space-between;gap:1rem;align-items:center}widget-ai-task-100554 .card .card-header .card-title{font-size:var(--font-size-12);font-weight:bold}widget-ai-task-100554 .card .card-header .card-price{display:flex;align-items:center;gap:.2rem;font-size:var(--font-size-12)}widget-ai-task-100554 .card .card-header .card-price svg{width:12px;height:12px}widget-ai-task-100554 .card .card-header .card-actions{display:flex;gap:.4rem;align-items:center}widget-ai-task-100554 .card .card-header .card-actions i{cursor:pointer}widget-ai-task-100554 .card .card-header .card-actions i:hover{transform:scale(1.1)}widget-ai-task-100554 .card .card-header .card-actions svg{width:12px;height:12px}widget-ai-task-100554 .card .card-header .card-status{text-transform:uppercase;font-size:var(--font-size-12);border:1px solid;padding:0 .3rem;border-radius:4px}widget-ai-task-100554 .card .card-header .card-status.todo{color:var(--grey-color-darker)}widget-ai-task-100554 .card .card-header .card-status.done{color:var(--success-color)}widget-ai-task-100554 .card .card-header .card-status.in-progress{color:var(--active-color)}widget-ai-task-100554 .card .card-header .card-status.waitingforuser{color:var(--warning-color)}widget-ai-task-100554 .card .card-header .card-status.paused{color:var(--info-color-disabled)}widget-ai-task-100554 .card .card-body{margin-top:var(--space-16)}widget-ai-task-100554 .card .card-body .card-message{font-size:var(--font-size-16)}`);
        this.task = {
            PK: "task#1744287679401",
            SK: "metadata",
            title: "@@ criar widget de data , com inicio e final, sem horas",
            owner: "20250306212720.1000",
            team: "unassigned",
            status: "done",
            last_updated: 1744287681703,
            last_update_log: "Task started by  at 2025-04-10T12:21:20.244Z",
            source: "",
            iaCompressed: {
                interaction: {
                    input: [
                        {
                            type: "system",
                            content: "Você é um planejador que irá coordenar agentes e ferramentas para executar tarefas complexas com base no prompt do usuário.\n\nSeu objetivo é analisar o prompt do usuário e decidir o próximo passo.\n\n1. Se faltar informações importantes para continuar, retorne apenas uma subtarefa do tipo `clarification`. Sempre que possível, inclua um `htmlForm` com campos e opções para facilitar a resposta do usuário.\n2. Se a tarefa puder ser resolvida diretamente com uma resposta, retorne uma subtarefa do tipo `result`.\n3. Decida qual agente, ferramenta ou base de conhecimento (RAG) será executado no próximo passo.\n4. Nunca retorne múltiplas subtarefas. Retorne **apenas uma subtarefa por vez** neste passo inicial."
                        },
                        {
                            type: "system",
                            content: "Agentes disponíveis:\n\t•\tagentPlannerNewPage: planejamento para a criação de novas páginas no sistema, será pedido mais informações ao usuário se necessário.\n\t•\tagentPlannerNewWidget: planejamento para a criação de componentes/widgets, será pedido mais informações ao usuário se necessário.\n\t•\tagentPlannerNewAPI: criação de endpoints ou APIs, será pedido mais informações ao usuário se necessário.\n\t•\tagentSupportExternal: suporte para usuários externos. Executar rag1 antes de enviar o prompt.\n\t•\tagentSupportInternal: suporte para usuários internos. Executar os RAGs rag1 e rag2 antes de enviar o prompt."
                        },
                        {
                            type: "human",
                            content: "criar widget de data , com inicio e final, sem horas"
                        }
                    ],
                    cost: 0.0011,
                    trace: [
                        "provider: openai model:gpt-4o inputTokens:317 outputTokens:29 inputCost:2.50/1M outputCost:10.00/1M total:$0.0011 llmTime: 1242ms"
                    ],
                    payload: [
                        {
                            type: "clarification",
                            clarificationMessage: "Preciso de mais informações, é um web component ?",
                            status: "completed",
                            stepId: 1,
                            interaction: null,
                            nextSteps: null,
                            title: "Error, step type not recognized"
                        },
                        {
                            type: "clarification",
                            clarificationMessage: "Preciso de mais informações, é um web component ?",
                            status: "completed",
                            stepId: 2,
                            interaction: {
                                input: [],
                                cost: 0.001,
                                payload: [
                                    {
                                        type: "clarification",
                                        clarificationMessage: "Preciso de mais informações, é um web component 2 ?",
                                        status: "waiting_for_user",
                                        stepId: 3,
                                        interaction: null,
                                        nextSteps: null,
                                        title: ""
                                    },
                                ],
                                trace: []
                            },
                            nextSteps: null,
                            title: ''
                        }
                    ]
                }
            }
        };
    }
    renderIconTask() {
        const taskObj = {
            'pending': collab_clock,
            'in_progress': collab_clock,
            'completed': collab_check,
            'failed': collab_bug,
            'waiting_for_user': collab_triangle_exclamation
        };
        const internalStatus = getInternalStatus(this.task);
        console.info(internalStatus);
        if (!internalStatus)
            return '';
        return html `<span @click= ${(e) => { e.stopPropagation(); this.onStatusClick(e, internalStatus); }} class="task-icon ${internalStatus.status}">${taskObj[internalStatus.status]}</span>`;
    }
    render() {
        return html `<div @click=${this.onCardClick} class="card"> 
            <div class="card-header">
                ${this.renderIconTask()}
                <span class="card-title">${this.task.PK}</span>
                <span class="card-status ${this.task.status.split(' ').join('-')}">${this.task.status}</span>
                <span class="card-price"> ${collab_money}${getTotalCost(this.task)}</span>
                <div class="card-actions">
                    ${['in progress', 'waitingforuser', 'todo'].includes(this.task.status)
            ? html `
                    <i>${collab_pause}</i>
                    <i>${collab_stop}</i>`
            : ['paused'].includes(this.task.status)
                ? html `
                        <i>${collab_play}</i>
                        <i>${collab_stop}</i>`
                : html ``}
                    
                </div>

            </div>
         </div>`;
    }
    onStatusClick(ev, data) {
        const event = new CustomEvent('taskclick', {
            detail: { stepId: data.stepId },
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }
    onCardClick() {
        const event = new CustomEvent('taskclick', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }
};
__decorate([
    state()
], WidgetAiTask100554.prototype, "task", void 0);
WidgetAiTask100554 = __decorate([
    customElement('widget-ai-task-100554')
], WidgetAiTask100554);
export { WidgetAiTask100554 };
