/// <mls shortName="collabPreviewL4" project="100554" enhancement="_100554_enhancementLit" groupName="other" folder="" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import './_100554_collabL3EditText';
let CollabPreviewL4 = class CollabPreviewL4 extends CollabLitElement {
    //-----COMPONENT----------
    render() {
        return html ``;
    }
};
CollabPreviewL4 = __decorate([
    customElement('collab-preview-l4-100554')
], CollabPreviewL4);
export { CollabPreviewL4 };
