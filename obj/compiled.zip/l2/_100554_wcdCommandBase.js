export function dispatchEventConciliate() {
    mls.events.fire([2], ['DOMSync']);
}
