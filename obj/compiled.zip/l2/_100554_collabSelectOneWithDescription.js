/// <mls shortName="collabSelectOneWithDescription" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query, queryAll } from 'lit/decorators.js';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_icaLitElement';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_plus } from './_100554_collabIcons';
export const initCollabSelectOneWithDescription = '';
/// **collab_i18n_start**
const message_pt = {
    defaultMsg: 'Passe o mouse sobre as opções para saber mais.',
};
const message_en = {
    defaultMsg: 'Hover over the options to learn more.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabSelectOneWithDescription100554 = class CollabSelectOneWithDescription100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.required = false;
        this.disabled = false;
        this.defaultMsg = '';
        this.currentIndex = -1;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.defaultMsg = this.msg.defaultMsg;
        return html `
            <div class="select_toogle" tabindex="1" @blur=${this.onBlur} @click=${this.onIconClick}>${collab_plus}</div>
            <div tabindex="0" @blur=${this.onBlur} class="select_container">
                <ul>
                    ${this.renderOpt()}
                </ul>
                <div tabindex="0" @blur=${this.onBlur} class="desc_container">
                    ${this.defaultMsg}
                </div>
            </div>
   
    `;
    }
    firstUpdated() {
        this.onkeydown = (e) => {
            this.handleKeyDown(e);
        };
    }
    onIconClick(e) {
        e.stopPropagation();
        this.toogle();
    }
    onBlur(e) {
        if (this.select_container?.contains(e.relatedTarget)) {
            e.preventDefault();
            return;
        }
        this.select_container?.classList.remove('open');
    }
    renderOpt() {
        if (this.options) {
            return html `
                ${this.options.map((opt, index) => {
                return html `
                <li 
                    tabindex="0"  
                    @blur=${this.onBlur} 
                    @mouseover=${this.handleHover}
                    @mouseout=${this.handleOut}
                    @focus=${(ev) => { this.handleFocus(ev, index); }}
                    @click=${() => { this.handleChange(opt.value); }}
                    .description=${opt.description}
                    .val=${opt.value}
                    >
                    ${opt.key}
                </li>`;
            })}
        `;
        }
    }
    handleHover(ev) {
        const target = ev.target;
        if (!this.desc_container || !this.optionItems)
            return;
        this.desc_container.innerHTML = target.description;
        this.optionItems.forEach((item) => item.classList.remove('hover'));
        target.classList.add('hover');
    }
    handleOut() {
        if (!this.desc_container)
            return;
        this.desc_container.innerHTML = this.defaultMsg;
    }
    handleFocus(ev, index) {
        const target = ev.target;
        this.currentIndex = index;
        if (!this.desc_container || !this.optionItems)
            return;
        this.desc_container.innerHTML = target.description;
        this.optionItems.forEach((item) => item.classList.remove('hover'));
        target.classList.add('hover');
    }
    handleChange(value) {
        this.selectedvalue = value;
        this.dispatchEvent(new CustomEvent('select-change', {
            detail: value, bubbles: true, composed: true
        }));
        this.toogle();
    }
    handleKeyDown(event) {
        event.preventDefault();
        switch (event.key) {
            case 'ArrowDown':
                if (this.optionItems && this.currentIndex < this.optionItems.length - 1) {
                    this.currentIndex++;
                    this.optionItems[this.currentIndex].focus();
                }
                break;
            case 'ArrowUp':
                if (this.optionItems && this.currentIndex > 0) {
                    this.currentIndex--;
                    this.optionItems[this.currentIndex].focus();
                }
                break;
            case 'Enter':
            case ' ':
                event.preventDefault();
                if (this.optionItems && this.currentIndex > -1) {
                    const val = this.optionItems[this.currentIndex].val;
                    this.handleChange(val);
                }
                break;
        }
    }
    toogle() {
        if (!this.select_container || !this.optionItems)
            return;
        this.select_container.classList.toggle('open');
        if (this.select_container.classList.contains('open')) {
            this.calculatePopupPosition();
            if (this.optionItems[this.currentIndex])
                this.optionItems[this.currentIndex].focus();
        }
    }
    calculatePopupPosition() {
        if (!this.select_toogle || !this.select_container)
            return;
        const selectBoxRect = this.select_toogle.getBoundingClientRect();
        const popupHeight = this.select_container.offsetHeight;
        const popupWidth = this.select_container.offsetWidth;
        this.select_container.style.left = '';
        this.select_container.style.top = '';
        this.select_container.style.bottom = '';
        const spaceBelow = window.innerHeight - selectBoxRect.bottom;
        const spaceRight = window.innerWidth - selectBoxRect.right;
        if (spaceBelow >= popupHeight)
            this.select_container.style.top = `${30}px`;
        else
            this.select_container.style.top = `-${popupHeight + 5}px`;
        if (spaceRight >= popupWidth)
            this.select_container.style.left = `${5}px`;
        else
            this.select_container.style.right = `${5}px`;
    }
};
CollabSelectOneWithDescription100554.styles = css ` :host{display:block;position:relative} .select_container{font-size:14px;transform:translate3d(0, 0, 0);box-sizing:content-box;border-width:0px;border-style:solid;border-color:var(--bg-primary-color-darker);border-radius:4px;box-shadow:0 12px 24px 8px rgba(0,0,0,0.08),0 8px 16px 4px rgba(0,0,0,0.08),0 4px 8px 2px rgba(0,0,0,0.08),0 2px 6px 0 rgba(0,0,0,0.08),0 -0.5px .5px 0 rgba(0,0,0,0.12) inset,0 .5px .5px 0 rgba(255,255,255,0.12) inset;overflow:hidden;width:300px;position:absolute;background:var(--bg-primary-color-lighter);color:var(--text-primary-color);z-index:9999;top:30px;display:none} .select_toogle{cursor:pointer;width:30px;text-align:center;border-radius:8px;color:var(--text-primary-color)} .select_toogle svg{fill:var(--text-primary-color)} .select_toogle:hover{background:var(--bg-secondary-color-lighter)} .select_container.open{display:block} .desc_container{padding:1rem 0;font-weight:bold;text-align:center} ul{list-style:none;padding-inline-start:0px;border-bottom:1px solid var(--grey-color-dark);margin:0;padding:.5rem 0} ul>li{outline:0px;cursor:default;user-select:none;height:24px;padding:4px 8px} ul>li.hover{background:var(--grey-color-light);font-weight:bold}`;
__decorate([
    propertyDataSource({ type: String })
], CollabSelectOneWithDescription100554.prototype, "hint", void 0);
__decorate([
    property({ type: Boolean })
], CollabSelectOneWithDescription100554.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], CollabSelectOneWithDescription100554.prototype, "disabled", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], CollabSelectOneWithDescription100554.prototype, "label", void 0);
__decorate([
    propertyDataSource()
], CollabSelectOneWithDescription100554.prototype, "options", void 0);
__decorate([
    propertyDataSource()
], CollabSelectOneWithDescription100554.prototype, "selectedvalue", void 0);
__decorate([
    query('.select_container')
], CollabSelectOneWithDescription100554.prototype, "select_container", void 0);
__decorate([
    query('.select_toogle')
], CollabSelectOneWithDescription100554.prototype, "select_toogle", void 0);
__decorate([
    query('.desc_container')
], CollabSelectOneWithDescription100554.prototype, "desc_container", void 0);
__decorate([
    queryAll('ul > li')
], CollabSelectOneWithDescription100554.prototype, "optionItems", void 0);
CollabSelectOneWithDescription100554 = __decorate([
    customElement('collab-select-one-with-description-100554')
], CollabSelectOneWithDescription100554);
export { CollabSelectOneWithDescription100554 };
