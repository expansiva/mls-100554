var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="pluginAgentPlayground" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, repeat } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { loadChatPreferences, saveChatPreferences } from './_100554_collabMessageHelper';
import { getUserIdLocalStorage, getTemporaryContext } from './_100554_aiAgentHelper';
import { listThreads } from './_100554_msgDBController';
import { updateHTML } from './_100554_collabDOMSync';
import { collab_trash } from './_100554_collabIcons';
import { setState } from './_100554_collabState';
let AgentTester = class AgentTester extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.agent = '';
        this.loading = false;
        this.mode = 'input';
        this.result = '';
        this.prompts = [];
        this.list = [];
        this.chatPreferences = {
            translationMode: 'icon',
            language: '',
            threadMaintenance: ''
        };
        this.inEdit = false;
        this.timeSave = 0;
        this.draggedItem = -1;
        this.dropTarget = -1;
        this.dropPosition = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.prompts = this.getPrompts();
        this.innerHTML = '';
        this.style.display = 'block';
    }
    disconnectedCallback() {
        setState('preview.pausePreview', false);
        super.disconnectedCallback();
    }
    async firstUpdated(changedProperties) {
        this.chatPreferences = loadChatPreferences();
        this.list = await listThreads();
    }
    render() {
        const aux = this.loading ? '' : 'none';
        return html `
<div class="overlay" style="display:${aux}">
<div class="spinner"></div>
Running...
</div>
<div class="actions">
${this.renderHead()}
</div>
<div style="height: calc(100% - 85px);">
<div class="tab-header">
<div class="tab-group-left">
<button
class="tab-button ${this.mode === 'input' ? 'active' : ''}" @click=${() => this.selectTabInput()} >
Inputs
</button>
<button
class="tab-button ${this.mode === 'result' ? 'active' : ''}" @click=${() => this.selectTabResult()} >
Result
</button>
<button
class="tab-button ${this.mode === 'settings' ? 'active' : ''}" @click=${() => this.selectTabSettings()} >
Settings
</button>
</div>
</div>
<div class="tab-content">
${this.renderMode()}
</div>
</div>
`;
    }
    renderHead() {
        return html `
<div class="header">
<strong>Agent:</strong> ${this.agent}
</div>
<div>
<button class="action-btn" @click=${() => this.handlePlay()} title="play"><svg style="width: 13px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/></svg></button>
</div>
`;
    }
    renderMode() {
        switch (this.mode) {
            case 'input': return this.renderInputs();
            case 'result': return this.renderResult();
            case 'settings': return this.renderSettings();
            default: return this.renderInputs();
        }
    }
    renderInputs() {
        if (!this.prompts || this.prompts.length === 0)
            return html `
<div class="containerinputs">
<h3>No input found!</h3>
${this.renderButonAdd()}
</div>
`;
        return html `
<div class="containerinputs containerdraganddrop">
${repeat(this.prompts, ((key) => key.type + Date.now()), ((p, idx) => { return this.renderPrompt(p, idx); }))}
${this.renderButonAdd()}
</div>
`;
    }
    renderButonAdd() {
        return html `
<div style="display: flex; width: 99%; max-width: 900px; justify-content: flex-start; padding: .5rem; border-top: 1px solid #e0e0e0;">
<button class="action-btn dropdown-toggle" @click=${() => this.addPrompt('system')}><svg style="width: 14px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg> Message</button>
</div>
`;
    }
    renderPrompt(prompt, idx) {
        let pp = this.escape(prompt.content.trim());
        return html `
<details class="prompt ${prompt.type}" ?open=${prompt.openDetail}
@dragover=${(e) => this.handleDragOver(e, idx, e.currentTarget)}
@dragleave=${(e) => this.handleDragLeave(e, e.currentTarget)}
@drop=${(e) => this.handleDrop(e, e.currentTarget)}
>
<summary @click=${(e) => this.handleDetails(e, prompt)}>
${this.renderMove(idx)}
<div class="pheader">
<div class="type" style="display:flex; align-items: center;gap:.5rem">
${this.renderSelect(prompt)}
<span class="title">
${pp.substring(0, 50)}...
</span>
</div>
<div style="display:flex; gap:.5rem">
<div class="trash itenActions" @click="${(e) => { e.stopPropagation(); this.trashClick(idx); }}">${collab_trash}</div>
<div class="chevron">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
</div>
</div>
</div>
</summary>
<div>
<pre class="content" contenteditable="true" @blur="${(e) => this.promptEvent(e, idx)}" @paste=${this.handlePaste}>${pp}</pre>
</div>
</details>
`;
    }
    renderMove(idx) {
        return html `
<div class="moveelement"
draggable="true"
@dragstart=${(e) => this.handleDragStart(e, idx)}
>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512" style="width:6px"><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512" style="width:6px"><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
</div>
`;
    }
    renderSelect(prompt) {
        return html `
<select .value=${prompt.type.trim()} @change=${(e) => this.updateSelect(e, prompt)}>
<option value="system">System</option>
<option value="human">Human</option>
<option value="ai">AI</option>
<option value="memory">Memory</option>
</select>
`;
    }
    renderResult() {
        return html `
<pre class="result">
${this.escape(this.result)}
</pre >
`;
    }
    renderSettings() {
        return html `
<div class="settings">
${this.renderListThread()}
</div>
`;
    }
    renderListThread() {
        return html `
<label>Thread:</label>
<select id="selectThread" @change=${this.handleThreadChange}>
<option value=""></option>
${repeat(this.list, ((key) => key), ((item) => {
            return html `<option value="${item.threadId}">${item.group}/ ${item.name}</option>`;
        }))}
</select>
`;
    }
    //---------IMPLEMENTATION--------
    selectTabResult() {
        this.mode = 'result';
    }
    selectTabInput() {
        this.mode = 'input';
    }
    selectTabSettings() {
        this.mode = 'settings';
        setTimeout(() => {
            const select = this.renderRoot.querySelector('select#selectThread');
            if (select) {
                select.value = this.chatPreferences?.threadMaintenance ?? '';
            }
        }, 300);
    }
    updateSelect(e, prompt) {
        const el = e.target;
        if (!el)
            return;
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.type = el.value;
        });
        this.handleSave();
    }
    handleDetails(e, prompt) {
        let el = e.target;
        if (!el || ['select', 'option'].includes(el.tagName.toLocaleLowerCase()))
            return;
        if (el.tagName.toLocaleLowerCase() !== 'details')
            el = el.closest('details');
        if (!el)
            return;
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.openDetail = !el.open;
        });
    }
    addPrompt(type) {
        this.prompts = [
            ...this.prompts,
            {
                type,
                content: '',
                openDetail: false
            }
        ];
    }
    trashClick(idx) {
        this.prompts = this.prompts.filter((_, i) => i !== idx);
        this.handleSave();
    }
    promptEvent(e, activeTabIndex) {
        this.inEdit = true;
        const target = e.target;
        const newValue = this.getCleanPreContent(target);
        this.prompts = this.prompts.map((p, idx) => idx === activeTabIndex ? { ...p, content: newValue, openDetail: true } : p);
        this.handleSave();
    }
    getCleanPreContent(preElement) {
        const walker = document.createTreeWalker(preElement, NodeFilter.SHOW_COMMENT);
        const commentsToRemove = [];
        while (walker.nextNode()) {
            const node = walker.currentNode;
            commentsToRemove.push(node);
        }
        for (const comment of commentsToRemove) {
            comment.parentNode?.removeChild(comment);
        }
        return preElement.innerText.trim();
    }
    async handlePlay() {
        this.loading = true;
        this.selectTabResult();
        if (this.inEdit) {
            setTimeout(async () => {
                this.handlePlay();
            }, 1100);
            return;
        }
        try {
            const i = this.prompts.find((p) => p.type === 'memory');
            const message = i ? i.content : '';
            const response = await this._callAgent(this.agent, message);
            this.result = response;
        }
        catch (err) {
            this.result = `Error when testing agent: ${err.message}`;
        }
        finally {
            this.loading = false;
        }
    }
    async handleSave() {
        clearTimeout(this.timeSave);
        this.timeSave = setTimeout(() => {
            setState('preview.pausePreview', true);
            let txt = `<plugin-agent-playground-100554 agent="${this.agent}" style="display:none">`;
            this.prompts.forEach((p) => {
                txt = txt + ` <promptcustom type="${p.type}"> ${this.escapeAngleBrackets(p.content)} </promptcustom> `;
            });
            txt = txt + '</plugin-agent-playground-100554>';
            updateHTML(txt, false);
            this.inEdit = false;
            setTimeout(() => setState('preview.pausePreview', false), 2000);
        }, 500);
    }
    getPrompts() {
        const ret = [];
        Array.from(this.children).forEach((i) => {
            if (i.tagName.toLocaleLowerCase() !== 'promptcustom')
                return;
            const tp = i.getAttribute('type') || 'system';
            const cont = i.innerHTML.trim();
            ret.push({
                type: tp,
                content: cont,
                openDetail: false
            });
        });
        return ret;
    }
    handleThreadChange(e) {
        const target = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            threadMaintenance: target.value
        };
        saveChatPreferences(this.chatPreferences);
    }
    async _callAgent(agentName, message) {
        if (!this.chatPreferences.threadMaintenance) {
            return `Agent "${agentName}" error:
Please configure your maintenance thread at: CollabMessage > Settings > Chat Preferences`;
        }
        const userId = getUserIdLocalStorage();
        const threadId = this.chatPreferences.threadMaintenance;
        if (!userId)
            return `Agent "${agentName}" error: Not found userID`;
        try {
            const moduleAgent = await import(`./${agentName}`);
            if (!moduleAgent)
                return 'Not found agent:' + agentName;
            if (!moduleAgent.createAgent)
                return 'Not found createAgent:' + agentName;
            const agt = moduleAgent.createAgent();
            const context = getTemporaryContext(threadId, userId, '@@' + agt.agentName + ' ' + message);
            context.modeSingleStep = true;
            await agt.beforePrompt(context);
            return `Agent "${agentName}" responded:\n${JSON.stringify(context, null, 2)}`;
        }
        catch (e) {
            return `Agent "${agentName}" error: ${e.message}`;
        }
    }
    escapeAngleBrackets(input) {
        return input
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
    escape(input) {
        return input
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>');
    }
    handleDragStart(event, idx) {
        event.stopPropagation();
        this.draggedItem = idx;
        const img = document.createElement('img');
        img.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMSIgaGVpZ2h0PSIxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4=';
        img.style.opacity = '0';
        event.dataTransfer?.setDragImage(img, 0, 0);
    }
    handleDragOver(event, idx, element) {
        event.stopPropagation();
        event.preventDefault();
        if (this.draggedItem < 0)
            return;
        let clientY = 'clientY' in event ? event.clientY : event.touches[0].clientY;
        const rect = element.getBoundingClientRect();
        const offsetY = clientY - rect.top;
        const height = rect.height;
        const details = element.closest('details');
        if (!details)
            return;
        if (offsetY < (height * 0.3) && details) {
            this.dropPosition = 'above';
            details.style.border = "";
            details.style.border = "";
            details.style.borderTop = "2px solid blue";
        }
        else if (offsetY > (height * 0.6) && details) {
            this.dropPosition = 'below';
            details.style.border = "";
            details.style.border = "";
            details.style.borderBottom = "2px solid blue";
        }
        this.dropTarget = idx;
    }
    handleDragLeave(event, element) {
        const details = element.closest('details');
        if (details)
            details.style.border = "";
        element.style.border = "";
    }
    handleDrop(event, element) {
        try {
            event.preventDefault();
            this.prompts = this.moveItemInArray();
        }
        catch (e) {
            console.info(e.message);
        }
        finally {
            element.style.border = "";
            const details = element.closest('details');
            if (details)
                details.style.border = "";
            this.draggedItem = -1;
            this.dropTarget = -1;
            this.dropPosition = null;
            setTimeout(() => { this.handleSave(); }, 500);
        }
    }
    moveItemInArray() {
        if (this.draggedItem < 0 || this.dropTarget < 0 || this.dropPosition === null || this.draggedItem === this.dropTarget) {
            return this.prompts;
        }
        const updatedArray = [...this.prompts];
        const item = updatedArray.splice(this.draggedItem, 1)[0];
        let insertIndex = this.dropTarget;
        if (this.dropPosition === 'below') {
            insertIndex += 1;
        }
        if (this.draggedItem < this.dropTarget) {
            insertIndex -= 1;
        }
        updatedArray.splice(insertIndex, 0, item);
        return updatedArray;
    }
    handlePaste(e) {
        e.preventDefault();
        const text = (e.clipboardData || window.clipboardData).getData('text');
        const selection = window.getSelection();
        if (!selection?.rangeCount)
            return;
        selection.deleteFromDocument();
        const range = selection.getRangeAt(0);
        range.insertNode(document.createTextNode(text));
        selection.collapseToEnd();
    }
};
__decorate([
    property({ type: String })
], AgentTester.prototype, "agent", void 0);
__decorate([
    query('.containerdraganddrop')
], AgentTester.prototype, "containerdraganddrop", void 0);
__decorate([
    state()
], AgentTester.prototype, "loading", void 0);
__decorate([
    state()
], AgentTester.prototype, "mode", void 0);
__decorate([
    state()
], AgentTester.prototype, "result", void 0);
__decorate([
    state()
], AgentTester.prototype, "prompts", void 0);
__decorate([
    state()
], AgentTester.prototype, "list", void 0);
__decorate([
    state()
], AgentTester.prototype, "chatPreferences", void 0);
AgentTester = __decorate([
    customElement('plugin-agent-playground-100554')
], AgentTester);
export { AgentTester };
