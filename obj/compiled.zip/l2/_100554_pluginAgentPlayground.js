/// <mls shortName="pluginAgentPlayground" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { loadChatPreferences } from './_100554_collabMessageHelper';
import { getUserIdLocalStorage, getTemporaryContext } from './_100554_aiAgentHelper';
import { listThreads } from './_100554_msgDBController';
import { updateHTML } from './_100554_collabDOMSync';
let AgentTester = class AgentTester extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-agent-playground-100554{display:block;border:1px solid #ccc;padding:1rem;border-radius:8px;background:#f9f9f9;font-family:var(--font-family-primary);height:100%;position:relative}plugin-agent-playground-100554 textarea{width:calc(100% - 1rem);height:calc(100% - 1rem);padding:.5rem;margin-top:.5rem;border-radius:4px;border:1px solid #ccc;font-family:monospace;resize:vertical}plugin-agent-playground-100554 .loader{margin-top:1rem;font-style:italic;color:#555}plugin-agent-playground-100554 .tab-header{display:flex;justify-content:space-between;border-bottom:1px solid #ccc;background-color:#f0f0f0;overflow:hidden;flex-shrink:0}plugin-agent-playground-100554 .tab-group-left{display:flex;overflow-x:auto;flex:1;min-width:0;scrollbar-width:thin}plugin-agent-playground-100554 .tab-group-left::-webkit-scrollbar{height:6px}plugin-agent-playground-100554 .tab-group-left::-webkit-scrollbar-thumb{background-color:var(--grey-color-darker);border-radius:4px}plugin-agent-playground-100554 .tab-group-right{display:flex;flex-shrink:0}plugin-agent-playground-100554 .tab-item{display:flex;align-items:center;position:relative}plugin-agent-playground-100554 .tab-delete{position:absolute;right:1rem;top:5px;background:transparent;border:none;color:var(--error-color);cursor:pointer;font-size:14px;margin-left:2px;padding:0 4px}plugin-agent-playground-100554 .tab-delete:hover{color:var(--error-color-hover)}plugin-agent-playground-100554 .tab-button{padding:10px 16px;cursor:pointer;background:none;border:none;border-right:1px solid #ddd;font-size:14px;transition:background-color .2s ease;display:flex;flex-direction:column}plugin-agent-playground-100554 .tab-button:hover{background-color:#e0e0e0}plugin-agent-playground-100554 .tab-button.active{background-color:#ffffff;font-weight:bold;border-bottom:2px solid #007bff}plugin-agent-playground-100554 .tab-content{position:relative;flex:1;padding:0;margin:0;background-color:#ffffff;display:flex;height:100%;flex-grow:1;overflow:auto}plugin-agent-playground-100554 textarea{resize:none;font-family:monospace;font-size:14px;box-sizing:border-box;background-color:#ffffff;color:#333;outline:none}plugin-agent-playground-100554 .header{display:flex;align-items:center}plugin-agent-playground-100554 .actions{display:flex;justify-content:space-between;padding:10px;gap:10px;background:#fafafa}plugin-agent-playground-100554 button.action-btn{position:relative;padding:8px 16px;cursor:pointer;background-color:#fff;color:#403f3f;box-shadow:rgba(0,0,0,0.046) 0 1px 2px 2px;border:none;border-radius:4px;font-size:14px}plugin-agent-playground-100554 .edit::before{content:' ';position:absolute;top:0;right:0;background-color:red;border-radius:50%;width:10px;height:10px}plugin-agent-playground-100554 button.action-btn:hover{opacity:.8}plugin-agent-playground-100554 .dropdown{position:relative;display:inline-block}plugin-agent-playground-100554 .dropdown .dropdown-toggle{position:relative}plugin-agent-playground-100554 .dropdown .dropdown-menu{display:none;position:absolute;background-color:var(--bg-primary-color);box-shadow:0 2px 8px rgba(0,0,0,0.15);z-index:99;min-width:200px;border-radius:4px;overflow:hidden;margin-top:0px}plugin-agent-playground-100554 .dropdown .dropdown-menu div{padding:8px 12px;cursor:pointer;color:var(--text-primary-color);font-size:var(--font-size-16)}plugin-agent-playground-100554 .dropdown .dropdown-menu div:hover{background-color:var(--bg-primary-color-hover)}plugin-agent-playground-100554 .dropdown:hover .dropdown-menu{display:block}plugin-agent-playground-100554 .settings{padding:1rem}plugin-agent-playground-100554 .settings input,plugin-agent-playground-100554 .settings select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;height:25px}plugin-agent-playground-100554 .result{padding:1rem;overflow-y:auto}plugin-agent-playground-100554 .overlay{position:absolute;inset:0;background-color:rgba(0,0,0,0.4);display:flex;justify-content:center;align-items:center;z-index:10;font-size:18px;color:white;font-weight:bold}plugin-agent-playground-100554 .spinner{border:4px solid #f3f3f3;border-top:4px solid #ffffff;border-radius:50%;width:30px;height:30px;animation:spin 1s linear infinite;margin-right:12px}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}`);
        this.agent = '';
        this.isEdit = false;
        this.loading = false;
        this.mode = 'item';
        this.result = '';
        this.activeTabIndex = 0;
        this.prompts = [];
        this.list = [];
        this.chatPreferences = {
            translationMode: 'icon',
            language: '',
            threadMaintenance: ''
        };
    }
    connectedCallback() {
        super.connectedCallback();
        this.prompts = this.getPrompts();
        this.innerHTML = '';
        this.style.display = 'block';
    }
    async firstUpdated(changedProperties) {
        this.chatPreferences = loadChatPreferences();
        this.list = await listThreads();
    }
    render() {
        const aux = this.loading ? '' : 'none';
        return html `
        <div class="overlay" style="display:${aux}">
            <div class="spinner"></div>
            Executando...
        </div>
        
        <div class="actions">
            ${this.renderHead()}
        </div>
        
        <div style="height: calc(100% - 85px);">
            <div class="tab-header">
                <div class="tab-group-left">
                    ${this.prompts.map((prompt, index) => this.renderItemTab(prompt, index))}
                </div>
                <div class="tab-group-right">
                    <button
                        class="tab-button ${this.mode === 'result' ? 'active' : ''}" @click=${() => this.selectTabResult()} >
                        Result
                        
                    </button>
                    <button
                        class="tab-button ${this.mode === 'settings' ? 'active' : ''}" @click=${() => this.selectTabSettings()} >
                        Settings
                        
                    </button>
                </div>
            </div>
            <div class="tab-content">
                ${this.renderMode()}
                
            </div>
        </div>
      
    `;
    }
    renderHead() {
        return html `
        <div class="header">
            <strong>Agente:</strong> ${this.agent}
        </div>
        <div>
            <button class="action-btn" @click=${() => this.deletePrompt()} title="delete"><svg style="width: 14px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M135.2 17.7L128 32 32 32C14.3 32 0 46.3 0 64S14.3 96 32 96l384 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-96 0-7.2-14.3C307.4 6.8 296.3 0 284.2 0L163.8 0c-12.1 0-23.2 6.8-28.6 17.7zM416 128L32 128 53.2 467c1.6 25.3 22.6 45 47.9 45l245.8 0c25.3 0 46.3-19.7 47.9-45L416 128z"/></svg></button>
            <div class="dropdown">
                <button class="action-btn dropdown-toggle"><svg style="width: 14px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg></button>
                <div class="dropdown-menu">
                    <div @click=${() => this.addPrompt('system')}>Add Message System</div>
                    <div @click=${() => this.addPrompt('human')}>Add Message Human</div>
                    <div @click=${() => this.addPrompt('assistant')}>Add Message Assistant</div>
                    <div @click=${() => this.addPrompt('memory')}>Add Message Memory</div>
                </div>
            </div>
            <button class="action-btn" @click=${() => this.handlePlay()} title="play"><svg style="width: 13px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/></svg></button>
            <button class="action-btn ${this.isEdit ? 'edit' : ''}" @click=${() => this.handleSave()} title="save"><svg style="width: 14px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-242.7c0-17-6.7-33.3-18.7-45.3L352 50.7C340 38.7 323.7 32 306.7 32L64 32zm0 96c0-17.7 14.3-32 32-32l192 0c17.7 0 32 14.3 32 32l0 64c0 17.7-14.3 32-32 32L96 224c-17.7 0-32-14.3-32-32l0-64zM224 288a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg></button>
        </div>
        `;
    }
    renderItemTab(prompt, index) {
        return html `
        
            <button class="tab-button ${this.activeTabIndex === index ? 'active' : ''}" @click=${() => this.selectTab(index)} >
                ${prompt.type}
            </button>
        
        `;
    }
    renderMode() {
        switch (this.mode) {
            case 'item': return this.renderItem();
            case 'result': return this.renderResult();
            case 'settings': return this.renderSettings();
            default: return this.renderItem();
        }
    }
    renderItem() {
        if (this.prompts.length === 0)
            return html ``;
        return html `
            <textarea .value="${this.prompts[this.activeTabIndex].content.trim()}"  @input="${(e) => this.updatePromptContent(e)}"></textarea>
        `;
    }
    renderResult() {
        return html `
        <pre class="result">
            ${this.result}
        </pre >
        `;
    }
    renderSettings() {
        return html `
        <div class="settings">
            ${this.renderListThread()}
        </div>
        `;
    }
    renderListThread() {
        return html `
            <label>Thread:</label>
            <select id="selectThread" @change=${this.handleThreadChange}>
                <option value=""></option>
                ${repeat(this.list, ((key) => key), ((item) => {
            return html `<option value="${item.threadId}">${item.group}/ ${item.name}</option>`;
        }))}
            </select>
        `;
    }
    //---------IMPLEMENTATION--------
    selectTabResult() {
        this.activeTabIndex = -1;
        this.mode = 'result';
    }
    selectTabSettings() {
        this.activeTabIndex = -1;
        this.mode = 'settings';
        setTimeout(() => {
            const select = this.renderRoot.querySelector('select#selectThread');
            if (select) {
                select.value = this.chatPreferences?.threadMaintenance ?? '';
            }
        }, 300);
    }
    selectTab(index) {
        this.mode = 'item';
        this.activeTabIndex = index;
    }
    async handlePlay() {
        this.loading = true;
        try {
            this.selectTabResult();
            const i = this.prompts.find((p) => p.type === 'memory');
            const message = i ? i.content : '';
            const response = await this._callAgent(this.agent, message);
            this.result = response;
        }
        catch (err) {
            this.result = `Erro ao testar agente: ${err.message}`;
        }
        finally {
            this.loading = false;
        }
    }
    async handleSave() {
        let txt = `<plugin-agent-playground-100554 agent="${this.agent}" style="display:none">`;
        this.prompts.forEach((p) => {
            txt = txt + `
            <promptcustom type="${p.type}">
                ${p.content}
            </promptcustom>
            `;
        });
        txt = txt + '</plugin-agent-playground-100554>';
        updateHTML(txt);
    }
    addPrompt(type) {
        this.prompts = [
            ...this.prompts,
            {
                type,
                content: ''
            }
        ];
        this.activeTabIndex = this.prompts.length - 1;
        this.mode = 'item';
    }
    deletePrompt() {
        this.prompts = this.prompts.filter((_, i) => i !== this.activeTabIndex);
        // Corrige o activeTabIndex
        if (this.activeTabIndex >= this.prompts.length) {
            this.activeTabIndex = this.prompts.length - 1;
        }
    }
    updatePromptContent(e) {
        const target = e.target;
        const newValue = target.value;
        this.isEdit = true;
        this.prompts = this.prompts.map((p, idx) => idx === this.activeTabIndex ? { ...p, content: newValue } : p);
    }
    getPrompts() {
        const ret = [];
        Array.from(this.children).forEach((i) => {
            if (i.tagName.toLocaleLowerCase() !== 'promptcustom')
                return;
            const tp = i.getAttribute('type') || 'system';
            const cont = i.innerHTML.trim();
            ret.push({
                type: tp,
                content: cont
            });
        });
        return ret;
    }
    handleThreadChange(e) {
        const target = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            threadMaintenance: target.value
        };
    }
    async _callAgent(agentName, message) {
        try {
            if (!this.chatPreferences.threadMaintenance) {
                return `Agente "${agentName}" error:
            Please configure your maintenance thread at: CollabMessage > Settings > Chat Preferences`;
            }
            const userId = getUserIdLocalStorage();
            const threadId = this.chatPreferences.threadMaintenance;
            if (!userId)
                return `Agente "${agentName}" error:
            Not found userID`;
            const moduleAgent = await import(`./${agentName}`);
            if (!moduleAgent)
                throw new Error('Not found agent:' + agentName);
            if (!moduleAgent.createAgent)
                throw new Error('Not found createAgent:' + agentName);
            const agt = moduleAgent.createAgent();
            const context = getTemporaryContext(threadId, userId, '@@ ' + agt.agentName + ' ' + message);
            context.modeSingleStep = true;
            await agt.beforePrompt(context);
            return `Agente "${agentName}" respondeu:\n${JSON.stringify(context, null, 2)}`;
        }
        catch (e) {
            return `Agente "${agentName}" error:
            ${e.message}`;
        }
    }
};
__decorate([
    property({ type: String })
], AgentTester.prototype, "agent", void 0);
__decorate([
    property()
], AgentTester.prototype, "isEdit", void 0);
__decorate([
    state()
], AgentTester.prototype, "loading", void 0);
__decorate([
    state()
], AgentTester.prototype, "mode", void 0);
__decorate([
    state()
], AgentTester.prototype, "result", void 0);
__decorate([
    state()
], AgentTester.prototype, "activeTabIndex", void 0);
__decorate([
    state()
], AgentTester.prototype, "prompts", void 0);
__decorate([
    state()
], AgentTester.prototype, "list", void 0);
__decorate([
    state()
], AgentTester.prototype, "chatPreferences", void 0);
AgentTester = __decorate([
    customElement('plugin-agent-playground-100554')
], AgentTester);
export { AgentTester };
