/// <mls shortName="icaLayoutFlowDividerBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElement } from './_100554_icaLitElement';
export class IcaLayoutFlowDividerBase extends IcaLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
}
