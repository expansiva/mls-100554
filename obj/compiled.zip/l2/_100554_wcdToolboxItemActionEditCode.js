/// <mls shortName="wcdToolboxItemActionEditCode" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WCDToolboxItemActionEditCode = class WCDToolboxItemActionEditCode extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        this.myInfos = { tp: "", attr: "text" };
        this.msg = messages['en'];
        this.text = '';
    }
    createRenderRoot() {
        return this;
    }
    disconnectedCallback() {
        if (this.elMain)
            this.elMain.style.visibility = '';
        this.fireChange();
        super.disconnectedCallback();
    }
    render() {
        if (this.args) {
            try {
                const i = JSON.parse(this.args);
                if (i.tp)
                    this.myInfos.tp = i.tp;
                if (i.attr)
                    this.myInfos.attr = i.attr;
            }
            catch (e) {
                throw new Error('Invalid args: ' + this.args);
            }
        }
        switch (this.myInfos.tp) {
            case 'edit':
                return this.renderEdit();
            case 'click':
                return this.renderClick();
            default: return this.renderButton();
        }
    }
    renderButton() {
        if (this.myParent)
            this.myParent.onclick = (e) => this.clickButton(e);
        this.onclick = (e) => this.clickButton(e);
        return html ``;
    }
    renderClick() {
        if (this.myParent)
            this.myParent.onclick = (e) => this.clickButton(e);
        return html ``;
    }
    renderEdit() {
        if (!this.elMain || !this.myParent)
            return;
        this.style.left = '0';
        this.style.top = '0';
        this.style.background = '#fff';
        this.style.width = '100%;';
        const css = 'outline:none; position:relative; min-width:20px';
        this.text = this.elMain.getAttribute('text') || '';
        this.elMain.style.visibility = 'hidden';
        const ret = html `<pre style="white-space:pre-line;"><code id="edittextwcd" contenteditable="true" spellcheck="false" @keydown=${this.onKeyDown} style="${css}">${this.text}</code></pre>
            <style>
                #edittextwcd *{
                    margin:0px;
                    outline:none;
                }
            </style>
        `;
        setTimeout(() => {
            const el = this.querySelector('*[contenteditable]');
            if (!el)
                return;
            el.focus();
        }, 500);
        return ret;
    }
    onKeyDown(e) {
        if (!this.myParent || !this.elMain)
            return;
        if (['Enter', 'Backspace', 'c', 'v', 'Delete', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
            e.stopPropagation();
        }
        if (!this.contentEditables)
            return;
        const el = (this.elMain.shadowRoot ? this.elMain.shadowRoot.children[0] : this.elMain.children[0]);
        el.innerHTML = this.contentEditables.innerHTML + '<br><br><br>';
    }
    fireChange() {
        if (!this.elICA || !this.contentEditables)
            return;
        let aux = '';
        const lang = (document.documentElement.lang || '').toLowerCase();
        if (this.elICA.globalVariation > 0 && lang !== '')
            aux = '-' + lang;
        const text = this.contentEditables?.textContent || '';
        this.elICA.setAttribute(this.myInfos.attr + aux, text);
        mls.events.fire([2], ['DOMSync']);
    }
    clickButton(e) {
        e.stopPropagation();
        if (!this.myParent)
            return;
        this.myParent.onclick = null;
        this.myParent.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: 'edit-code',
                args: '{"tp":"edit", "attr":"' + this.myInfos.attr + '"}',
                position: 'p-l1',
                toolboxOptions: { background: '#fff' }
            },
        ], false, 'size');
    }
    backButton() {
    }
};
__decorate([
    query('#edittextwcd')
], WCDToolboxItemActionEditCode.prototype, "contentEditables", void 0);
WCDToolboxItemActionEditCode = __decorate([
    customElement('wcd-toolbox-item-action-edit-code-100554')
], WCDToolboxItemActionEditCode);
export { WCDToolboxItemActionEditCode };
