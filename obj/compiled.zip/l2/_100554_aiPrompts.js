/// <mls shortName="aiPrompts" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { descriptionForPrompt } from './_100554_icaBaseDescription';
import { getTokensLess } from './_100554_designSystemBase';
import { getState } from './_100554_collabState';
export function systemAgentsAvailable() {
    return {
        type: 'system',
        content: `## Agentes disponíveis:\n${getAgentsList()}`
    };
}
export function systemRagsAvailable() {
    return {
        type: 'system',
        content: `## RAGs disponíveis:\n${getRagsList()}`
    };
}
export function addRAGAdditionalInformation(rags, prompts) {
    if (!rags || rags.length === 0)
        return;
    prompts.push({
        type: 'system',
        content: `## Informações complementares:\n${rags.join('\n')}`
    });
}
export function systemReturnJsonFormat() {
    return {
        type: 'system',
        content: `
Você deve retornar um array de objetos no formato JSON. Cada objeto representa uma subtarefa, com **apenas um dos seguintes formatos**:
\`\`\` json
[
  {
    "type": "agent",
    "agentName": string,
    "title": string,
    "prompt": string,
    "rags": string[] | null
  },
  {
    "type": "tool",
    "toolName": string,
    "title": string,
    "args": string
  },
  {
    "type": "clarification",
    "clarificationMessage": string,
    "htmlForm?": string
  },
  {
    "type": "result",
    "result": string
  }
]
\`\`\`
`
    };
}
export const preferModelType = (modelType) => `<!-- modelType: ${modelType} -->`;
function getAgentsList() {
    const listAgents = [
        { agent: 'agentAnalyzeNewModule1', description: 'planejamento para a criação de novos projetos, sites ou criação de uma nova página' },
        // { agent: 'agentPlannerNewPage', description: 'planejamento para a criação de novas páginas no sistema, será pedido mais informações ao usuário se necessário.' },
        { agent: 'agentPlannerNewWidget', description: 'criação de novos componentes UI, web components, widgets, estes widgets podem futuramente serem incluidos em uma página html.' },
        { agent: 'agentPlannerNewAPI', description: 'criação de endpoints ou APIs, será pedido mais informações ao usuário se necessário.' },
        { agent: 'agentSupportExternal', description: 'suporte para usuários externos. Executar rag1 antes de enviar o prompt.' },
        { agent: 'agentSupportInternal', description: 'suporte para usuários internos. Executar os RAGs rag1 e rag2 antes de enviar o prompt.' },
        { agent: 'agentGenerateDefs', description: 'criação e atualização do arquivo definition.' },
    ];
    return `Agentes disponíveis:\n${listAgents.map((item) => `•	${item.agent}:${item.description}`).join('\n')}`;
}
function getRagsList() {
    return `
- rag1: base de conhecimento de suporte geral.
- rag2: base de conhecimento da empresa (documentação interna).`;
}
;
export async function systemToolsAvailable() {
    const tools = await getToolsList();
    return {
        type: 'system',
        content: `## Tools disponíveis:\n${tools}`
    };
}
async function getToolsList() {
    const tolls = await getListFilesStart('tool');
    return tolls.join('\n');
}
export async function getListFilesStart(start) {
    const keys = Object.keys(mls.stor.files);
    const ret = [];
    for await (const k of keys) {
        try {
            if (k.indexOf(start) < 0)
                continue;
            const file = mls.stor.files[k];
            const path = `./_${file.project}_${file.shortName}`;
            if (file.extension !== '.ts' || !file.shortName.startsWith(start))
                continue;
            if (start === 'widget') {
                ret.push(file.shortName);
            }
            else {
                const mdl = await import(path);
                if (start === 'tool') {
                    const tool = mdl.createTool();
                    ret.push(getDefTool(tool));
                }
                else {
                    const agent = mdl.createAgent();
                    ret.push(`${agent.agentName}: ${agent.agentDescription}`);
                }
            }
        }
        catch (e) {
            console.info('Erro get list with start: ' + start + ' in key:' + k);
        }
    }
    return ret;
}
function getDefTool(tool) {
    const argsList = Object.keys(tool.argsSchema || {})
        .map(arg => `${arg}:${tool.argsSchema[arg].type} /* ${tool.argsSchema[arg].description} */`)
        .join(', ');
    return `${tool.toolName}: ${tool.description} (args: ${argsList})`;
}
export function systemComponentsInstruction() {
    return {
        type: 'system',
        content: `${descriptionForPrompt}`
    };
}
export async function systemTokensLessInstruction() {
    const { project } = mls.actual[5];
    const theme = 'Default';
    if (!project)
        throw new Error('Invalid Project');
    return {
        type: 'system',
        content: '## LESS TOKENS - DESIGN SYSTEM \n\n' + (await getTokensLess(project, theme)) || ""
    };
}
export async function getPromptByHtml(dt) {
    if (!dt.project || !dt.shortName || !dt.state)
        throw new Error(`[getPromptByHtml]: incomplete parameters.`);
    const keyFile = mls.stor.getKeyToFiles(dt.project, 2, dt.shortName, dt.folder, '.html');
    if (!mls.stor.files[keyFile])
        throw new Error(`[getPromptByHtml]: not found stor.file ${keyFile}.`);
    const content = await mls.stor.files[keyFile].getContent();
    if (!content)
        return [];
    const el = document.createElement('div');
    el.innerHTML = content;
    const itens = el.querySelectorAll('promptcustom');
    const ret = [];
    itens.forEach((item) => {
        let cont = item.innerHTML;
        const tp = item.getAttribute('type');
        if (tp === 'memory' || tp === 'prompt')
            return;
        cont = clearGaps(cont);
        const keys = findKeys(cont);
        keys.forEach((key) => {
            const st = getState(key.trim());
            if (st === undefined || !key.startsWith(dt.state))
                return;
            const rp = `{{${key}}}`;
            cont = escape(cont.replace(rp, st));
        });
        ret.push({
            type: tp,
            content: cont
        });
    });
    return ret;
}
function clearGaps(text) {
    return text.replace(/{{(.*?)}}/g, (_, content) => {
        return `{{${content.trim().replace(/\s+/g, '')}}}`;
    });
}
function findKeys(text) {
    const regex = /{{(.*?)}}/g;
    const resultados = [];
    let match;
    while ((match = regex.exec(text)) !== null) {
        resultados.push(match[1].trim());
    }
    return resultados;
}
function escape(input) {
    return input
        .replace(/&lt;/g, '<')
        .replace(/&gt;/g, '>');
}
