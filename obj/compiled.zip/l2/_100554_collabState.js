/// <mls shortName="collabState" project="100554" enhancement="_blank" />
const isTrace = false;
/**
 * Class responsible for managing shared state.
 */
export class CollabState {
    constructor() {
        this.stateMap = new Map(); // values of variables
        this.componentMap = new Map(); // subscribes
    }
    /**
     * Update state for a given key.
     * @param key - The state key.
     * @param value - The new state value.
     */
    setState(key, value) {
        const oldValue = this.stateMap.get(key);
        if (isTrace)
            console.info('setState key: ' + key + ' value=', value, ", oldValue=", oldValue);
        if (oldValue !== value) {
            this.stateMap.set(key, value);
            this.notify(key);
        }
    }
    /**
     * Retrieve state for a given key.
     * @param key - The state key.
     */
    getState(key) {
        const value = this.stateMap.get(key);
        if (isTrace)
            console.info('getState key: ' + key + ' value=', value);
        return value;
    }
    /**
     * Subscribe a component to a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The subscribing component.
     */
    subscribe(keyOrKeys, component) {
        const keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
        keys.forEach((key) => {
            if (!this.componentMap.has(key)) {
                this.componentMap.set(key, new Set());
            }
            this.componentMap.get(key).add(component);
        });
    }
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    unsubscribe(keyOrKeys, component) {
        const keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
        keys.forEach((key) => {
            this.componentMap.get(key)?.delete(component);
        });
    }
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    notify(key) {
        this.componentMap.get(key)?.forEach((component) => {
            if ('handleCollabStateChange' in component) {
                component['handleCollabStateChange'](key, this.getState(key));
            }
        });
    }
    /**
     * Get statistics about current state keys and their subscribers.
     */
    getStateStatistics() {
        const statistics = new Map();
        this.componentMap.forEach((value, key) => {
            statistics.set(key, value.size);
        });
        return statistics;
    }
}
