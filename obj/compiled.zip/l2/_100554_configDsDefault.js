/// <mls shortName="configDsDefault" project="100554" enhancement="_blank" groupName="other" />
import { Common } from './_100554_configDsDefaultCommon';
import { Doc } from './_100554_configDsDefaultDocs';
import { Token } from './_100554_configDsDefaultTokens2';
import { Asset } from './_100554_configDsDefaultAssets';
import { Css } from './_100554_configDsDefaultCss';
import { Component } from './_100554_configDsDefaultComponent';
import { PreCompileLess } from './_100554_configDsDefaultPreCompileLess';
import { list } from './_100554_libDesignSystem';
export class _100554_configDsDefault {
    constructor(project, dsindex) {
        this.project = 0;
        this.dsindex = 0;
        this.dsname = '';
        this.createdBy = '';
        this.lastUpdated = '';
        this.lastUpdatedBy = '';
        this.init = () => this._init();
        this.dispose = () => this._dispose();
        this.remove = () => this._remove();
        this.create = (project, dsindex, createdAt, reference) => this._createDs(project, dsindex, createdAt, reference);
        this._getOriginalDsJSON = () => this.__getOriginalDsJSON();
        this.getDesignSystemCss = (theme) => this._getDesignSystemCss(theme);
        this.ds = undefined;
        this.methods = new Common(this.ds, this);
        this.project = project;
        this.dsindex = dsindex;
    }
    ;
    ;
    async _init() {
        if (this.ds)
            return;
        this.methods = new Common(this.ds, this);
        const projectDsDetails = await list(this.project);
        const dsInfo = projectDsDetails[this.dsindex];
        // await this.prepareStorFiles(dsInfo.dsName);
        let mainDsFile;
        // mainDsFile = await this.methods.getContentFile(dsInfo.dsName, 'json', `ds/${dsInfo.dsName}`);
        mainDsFile = await this.methods.getContentFile(dsInfo.dsName, 'json', `ds/${dsInfo.dsName}`);
        if (!mainDsFile)
            return;
        this.ds = JSON.parse(mainDsFile);
        if (!this.ds)
            return;
        this.methods = new Common(this.ds, this);
        this.dsname = this.ds.name;
        this.createdBy = this.ds.created_by;
        this.lastUpdated = this.ds.last_updated;
        this.lastUpdatedBy = this.ds.last_updated_by;
        this.docs = new Doc(this, this.ds);
        this.tokens = new Token(this, this.ds);
        this.assets = new Asset(this, this.ds);
        this.css = new Css(this, this.ds);
        this.components = new Component(this, this.ds);
    }
    async _createDs(project, dsindex, createdAt, reference) {
        const projectDsDetails = await list(project);
        const dsInfo = projectDsDetails[dsindex];
        this.methods = new Common(this.ds, this);
        const user = this.methods.getUser();
        const copyFromProjecy = 100554; // Collab WorksSpace
        const defaultProjectDsDetails = await list(copyFromProjecy);
        const defaultDsInfo = defaultProjectDsDetails[0];
        if (!defaultDsInfo) {
            return this.createEmptyDS(dsInfo, user, reference); // Only first time, to create a first ds in system
        }
        return this.createDsByTemplate(defaultDsInfo, dsInfo, copyFromProjecy, user, reference);
    }
    async createDsByTemplate(defaultDsInfo, dsInfo, project, user, reference) {
        await mls.stor.server.loadProjectInfoIfNeeded(project);
        let templateDs;
        try {
            const key = mls.stor.getKeyToFiles(project, 3, defaultDsInfo.dsName, `ds/${defaultDsInfo.dsName}`, '.json');
            const dsFile = mls.stor.files[key];
            if (!dsFile)
                throw new Error('Design system default dont exist');
            const mainDsFile = await dsFile.getContent();
            templateDs = JSON.parse(mainDsFile);
            templateDs.name = dsInfo.dsName;
            templateDs.created_by = user;
            templateDs.last_updated_by = user;
            templateDs.last_updated = this.methods.getDateNow();
            templateDs.created_by = user;
            await this.methods.createNewFile(templateDs.name, `ds/${templateDs.name}`, 'json', JSON.stringify(templateDs));
            await this.copyAllFilesDs(defaultDsInfo.dsName, project, templateDs.name);
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on create design system:' + err.message));
        }
    }
    async createEmptyDS(dsInfo, user, reference) {
        const newDs = {
            name: dsInfo.dsName,
            created_by: user,
            last_updated: this.methods.getDateNow(),
            last_updated_by: user,
            reference,
            assets: { items: [] },
            components: { items: [] },
            docs: { items: [] },
            tokens: { items: [] },
            css: { items: [] }
        };
        try {
            await this.methods.createNewFile(newDs.name, `ds/${newDs.name}`, 'json', JSON.stringify(newDs)); // main json
            await this.methods.createNewFile('help', `ds/${newDs.name}/assets`, 'txt', 'Here upload your assets'); // main json
            await this._init();
            await this.docs?.add(0, 'getStarted', this.methods.docInitial); // doc initial
            await this.css?.add('definitions', this.methods.cssInitial); // css global
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on create design system:' + err.message));
        }
    }
    async copyAllFilesDs(oldDsName, oldDsProject, newDsName) {
        const keys = Object.keys(mls.stor.files);
        for await (const key of keys) {
            if (key.startsWith(`${oldDsProject}_3_ds_${oldDsName}`) && !key.endsWith(`_3_ds_${newDsName}_${newDsName}.json`)) {
                const file = mls.stor.files[key];
                const content = await file.getContent();
                await this.methods.createNewFile(file.shortName, file.folder.replace(oldDsName, newDsName), file.extension, content);
            }
        }
    }
    async _dispose() {
        if (!this.ds)
            return;
        const key = `${this.project}_3_ds_${this.ds.name}_`;
        const filesKeys = Object.keys(mls.stor.files);
        const promises = [];
        const promises2 = [];
        for (const filesKey of filesKeys) {
            if (filesKey.startsWith(key)) {
                const file = mls.stor.files[filesKey];
                const fileInfoValue = {
                    content: null,
                    contentType: undefined,
                };
                promises.push(mls.stor.localStor.setContent(file, fileInfoValue));
                if (file.status === 'new')
                    delete mls.stor.files[filesKey];
                else {
                    mls.stor.files[filesKey].status = 'nochange';
                    mls.stor.files[filesKey].inLocalStorage = false;
                    promises2.push(mls.stor.addOrUpdateFile({
                        extension: file.extension,
                        folder: file.folder,
                        level: file.level,
                        project: file.project,
                        shortName: file.shortName,
                        versionRef: file.versionRef,
                    }));
                }
            }
        }
        await Promise.all(promises);
        await Promise.all(promises2);
        this.ds = undefined;
    }
    async prepareStorFiles(dsname) {
        const filekeys = Object.keys(mls.stor.files);
        const dskey = `${this.project}_3_ds_${dsname}`;
        const readFiles = async () => {
            await Promise.all(filekeys.map(async (key) => {
                const file = mls.stor.files[key];
                if (key.startsWith(dskey)) {
                    file.onAction = (action) => this.methods._onAction(action, file);
                    const info = file.getValueInfo ? await file.getValueInfo() : null;
                    const haveInfo = info && !!info.content;
                    const src = haveInfo ? info?.content : await file.getContent();
                    let originalCRC;
                    if (typeof src === 'string') {
                        originalCRC = haveInfo ? info?.originalCRC : mls.common.crc.crc32(src).toString(16);
                    }
                    mls.stor.files[key].getValueInfo = () => this.methods._getValueInfo(file, undefined, undefined, undefined, originalCRC);
                }
            }));
        };
        await readFiles();
    }
    async __getOriginalDsJSON() {
        const projectDsDetails = await list(this.project);
        const dsInfo = projectDsDetails[this.dsindex];
        let json;
        try {
            const mainDsFile = await this.methods.getContentFile(dsInfo.dsName, 'json', `ds/${dsInfo.dsName}`, true);
            json = JSON.parse(mainDsFile);
        }
        catch (err) {
            json = undefined;
        }
        return json;
    }
    async _getDesignSystemCss(theme) {
        if (!this.css || !this.components)
            return '';
        const css = await this.css.getStylesInLess(theme);
        const allComponentsCss = [];
        for await (const component of Object.keys(this.components.list)) {
            try {
                const lessComponent = await this.components.getStylesLess(component, theme);
                if (lessComponent) {
                    allComponentsCss.push(`// widget: ${component} \n${lessComponent}\n`);
                }
            }
            catch (err) {
                console.info('erro no component:', component);
                continue;
            }
        }
        const allLess = `//global css\n${css}\n${allComponentsCss.join('\n')}`;
        try {
            const preCompileLess = new PreCompileLess();
            const compiledCss = await preCompileLess.compileLess(allLess);
            console.info(compiledCss);
            return compiledCss;
        }
        catch (err) {
            throw new Error(`Error on compile all less : ${err.message}`);
        }
    }
    async _remove() {
    }
}
