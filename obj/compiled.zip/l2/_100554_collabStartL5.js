/// <mls shortName="collabStartL5" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
/// **collab_i18n_start**
const message_pt = {
    desc: 'Descrição',
    news: 'Novidades',
    inDevelopment: 'Em desenvolvimento...',
    details1: 'Sobre esse level',
    module1Title: 'Módulo L5 - Management: Descrição e Funcionalidades',
    module1Text: 'O módulo L5 é voltado para o gerenciamento do projeto. Ele oferece uma série de ferramentas que permitem ao usuário coordenar as tarefas, visualizar o progresso e gerenciar a infraestrutura e recursos humanos.',
    module1List1: 'Visualização de Páginas do Projeto',
    module1List1_1: 'Um quadro Kanban que mostra todas as páginas do projeto categorizadas por status: "Todo", "Planning", "In Progress", "Review" e "Complete".',
    module1List1_2: 'Uma lista simples que exibe todas as páginas do projeto, permitindo uma visão rápida do que está em desenvolvimento.',
    module1List2: 'Infraestrutura',
    module1List2_1: 'Permite definir configurações de hospedagem, banco de dados, plugins, módulos externos e outras opções técnicas para a publicação do aplicativo.',
    module1List3: 'Visualização de Recursos',
    module1List3_1: 'Mostra uma lista de todas as pessoas envolvidas no projeto e métricas sobre sua colaboração, como tarefas concluídas, horas trabalhadas, etc.',
    module2Title: 'Fluxo de Uso',
    module2List1: 'O usuário acessa o módulo L5 e tem uma visão geral através dos dashboards e listas.',
    module2List2: 'Utiliza o Board de Páginas para mover páginas entre diferentes status e acompanhar o progresso.',
    module2List3: 'Acessa a seção Infraestrutura para configurar detalhes técnicos do projeto.',
    module2List4: 'Utiliza a Visualização de Recursos para monitorar a eficácia da equipe e fazer ajustes conforme necessário.',
    moduleExplain: 'Este módulo é crucial para manter o projeto organizado e assegurar que todos os recursos estejam sendo utilizados de forma eficiente. Ele oferece uma visão 360 graus do projeto, permitindo um gerenciamento eficaz.',
};
const message_en = {
    desc: 'Description',
    news: 'News',
    inDevelopment: 'In development...',
    details1: 'About this level',
    module1Title: 'Module L5 - Management: Description and Features',
    module1Text: 'The L5 module focuses on project management. It provides a set of tools enabling users to coordinate tasks, monitor progress, and manage infrastructure and human resources.',
    module1List1: 'Project Pages Overview',
    module1List1_1: 'A Kanban board displaying all project pages categorized by status: "Todo," "Planning," "In Progress," "Review," and "Complete."',
    module1List1_2: 'A simple list view showing all project pages, offering a quick overview of ongoing development.',
    module1List2: 'Infrastructure',
    module1List2_1: 'Allows configuration of hosting, database, plugins, external modules, and other technical options for application deployment.',
    module1List3: 'Resource Overview',
    module1List3_1: 'Displays a list of all project contributors with metrics on their collaboration, such as completed tasks, hours worked, and more.',
    module2Title: 'Usage Flow',
    module2List1: 'The user accesses the L5 module and gets an overview via dashboards and lists.',
    module2List2: 'Uses the Pages Board to move pages across different statuses and track progress.',
    module2List3: 'Accesses the Infrastructure section to configure technical project details.',
    module2List4: 'Utilizes the Resource Overview to monitor team effectiveness and make necessary adjustments.',
    moduleExplain: 'This module is critical to keeping the project organized and ensuring all resources are used efficiently. It provides a 360-degree view of the project for effective management.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabStartL5100554 = class CollabStartL5100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-start-l5-100554{line-height:1.15;position:relative;height:100%;overflow:auto;font-family:'Cambria',serif;font-size:var(--font-size-16);font-weight:400}collab-start-l5-100554 details>summary{cursor:pointer;font-size:var(--font-size-20)}collab-start-l5-100554 .collab-codes-banner{margin-left:auto;margin-right:auto;display:block;width:100%;max-width:100%;position:relative}collab-start-l5-100554 .collab-codes-banner img{width:100% !important;height:auto !important}collab-start-l5-100554 .collab-codes-link{display:flex;justify-content:center;gap:2rem;padding:2rem}collab-start-l5-100554 .collab-codes-link button{cursor:pointer;background:none;border:none;text-decoration:underline;color:var(--active-color)}collab-start-l5-100554 .collab-codes-content{padding:0 .5rem;margin-left:auto;margin-right:auto;max-width:800px;justify-content:center}collab-start-l5-100554 .collab-codes-content details{margin-bottom:1rem}collab-start-l5-100554 .collab-codes-content details>div{padding-left:1.5rem}collab-start-l5-100554 .collab-codes-contents{justify-content:center}collab-start-l5-100554 .collab-codes-contents details{margin-bottom:1rem}collab-start-l5-100554 .collab-codes-contents details>div{padding-left:1.5rem}collab-start-l5-100554 .separator{padding-top:24px;padding-bottom:10px;margin-top:32px;margin-bottom:14px;display:flex;justify-content:center}collab-start-l5-100554 .separator>span{width:4px;height:4px;background-color:var(--text-primary-color);border-radius:50%;display:inline-block;margin-right:20px}collab-start-l5-100554 h1{line-height:52px;font-size:42px;font-weight:700;font-style:normal}collab-start-l5-100554 h2{line-height:30px;font-size:24px;font-weight:600;font-style:normal}collab-start-l5-100554 h1,collab-start-l5-100554 h2,collab-start-l5-100554 h3,collab-start-l5-100554 h4,collab-start-l5-100554 h5,collab-start-l5-100554 h6,collab-start-l5-100554 h7{letter-spacing:-0.011em}collab-start-l5-100554 ol>li,collab-start-l5-100554 ul>li{margin-top:1em}collab-start-l5-100554 span,collab-start-l5-100554 p,collab-start-l5-100554 li{line-height:32px;font-size:20px}collab-start-l5-100554 .collab_marca{position:absolute;bottom:10px;right:20px;opacity:.2}`);
        this.msg = messages['en'];
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <section class="collab-codes-start">
            <div class="collab-codes-banner">
                <img id="serviceStartL5ImageBanner" src="./l3/_100529_/images/startl5.avif" height="250" width="800" alt="banner">
            </div>
            <div class="collab-codes-content">
                <details id="serviceStartL5DetailsAbout" open="open">
                    <summary>${this.msg.details1}</summary>
                    <div>
                        <h1>${this.msg.module1Title}</h1>
                        <div>
                            <h2>${this.msg.desc}</h2>
                            <span>${this.msg.module1Text}

                                <ol>
                                    <li>
                                        <span>${this.msg.module1List1}</span>
                                        <ul>
                                            <li>${this.msg.module1List1_1}</li>
                                            <li>${this.msg.module1List1_2}</li>

                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List2}</span>
                                        <ul>
                                            <li>${this.msg.module1List2_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List3}</span>
                                        <ul>
                                            <li>${this.msg.module1List3_1}</li>
                                        </ul>
                                    </li>
                                </ol>

                            </span>
                        </div>
                          <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module2Title}</h3>
                            <ol>
                                <li>${this.msg.module2List1}</li>
                                <li>${this.msg.module2List2}</li>
                                <li>${this.msg.module2List3}</li>
                                <li>${this.msg.module2List4}</li>
                            </ol>
                            <span>${this.msg.moduleExplain}</span>
                        </div>
                    </div>
                </details>
                <details id="serviceStartL5DetailsNews" open="open">
                    <summary>${this.msg.news}</summary>
                    <div>
                        <span>${this.msg.inDevelopment}</span>
                    </div>
                </details>
            </div>
        </section>
        <img class="collab_marca" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==" height="140" width="140" alt="collab codes">
         `;
    }
};
CollabStartL5100554 = __decorate([
    customElement('collab-start-l5-100554')
], CollabStartL5100554);
export { CollabStartL5100554 };
