/// <mls shortName="widgetChatExample" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_chevron_left } from './_100554_collabIcons';
import './_100554_widgetAiTask';
import './_100554_widgetAiInteraction';
import { startPrompt, afterPrompt } from './_100554_agentPlanner1';
import { execAddTask, execGetTaskUpdate } from './_100554_iaChatBase';
let WidgetChatExample100554 = class WidgetChatExample100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-chat-example-100554{display:flex;flex-direction:column;height:100%}widget-chat-example-100554 .header{height:40px;text-transform:uppercase;display:flex;justify-content:center;border-bottom:1px solid var(--grey-color-light);margin-bottom:1rem;cursor:pointer}widget-chat-example-100554 .chat-container{display:flex;flex-direction:column;padding:10px;width:calc(100% - 20px);height:calc(100% - 20px);overflow-y:auto;max-height:100%}widget-chat-example-100554 .message-time{text-align:center;font-size:.85rem;color:gray;margin-bottom:5px}widget-chat-example-100554 .message{display:flex;flex-direction:column;align-items:flex-start;width:100%;margin-bottom:10px}widget-chat-example-100554 .message.user,widget-chat-example-100554 .message.system{align-items:flex-end}widget-chat-example-100554 .message-prompt{border-top:1px solid var(--grey-color-dark);padding:1rem}widget-chat-example-100554 .message-prompt textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}widget-chat-example-100554 .message-row{max-width:80%;margin-bottom:3px;margin-right:50px;margin-left:50px}widget-chat-example-100554 .message-row .message-card{display:flex;flex-direction:column;background-color:#f9f9f9;border:1px solid #ddd;border-radius:8px;padding:1rem;position:relative}widget-chat-example-100554 .message-row .message-card.user{background-color:#daf8cb;align-self:flex-end}widget-chat-example-100554 .message-row .message-card .message-title{color:#be069c}widget-chat-example-100554 .message-row .message-card .message-content{padding-right:4em;margin-top:.4rem}widget-chat-example-100554 .message-row .message-card .message-footer{font-size:.75rem;color:gray;position:absolute;bottom:5px;right:10px;text-align:right}widget-chat-example-100554 .message-group{display:contents}`);
        this.actualTasks = [];
        this.panel = 'Chat';
    }
    async firstUpdated() {
        const task = await execGetTaskUpdate('20250304200000.1000/20250415175538.1000', "task#1744739738653");
        this.actualTasks = [task];
    }
    render() {
        return html `
        <div @click=${this.handleClickHeader} class="header">    
            <span>${collab_chevron_left}</span>
            <span>${this.panel === 'Chat' ? 'Chat' : `Details: ${this.actualTaskDetails?.PK}`}</span>
        </div>


        ${this.panel === 'Chat'
            ? html `<div class="chat-container">
                        <div class="message-time">10/04/2024</div>
                        ${this.actualTasks.map((taskItem) => {
                return html ` 
                                <div class="message user">
                                    <div class="message-group">
                                        <div class="message-row">
                                        <div class="message-card user">
                                            <div class="message-title">@${taskItem.owner}</div>
                                            <div class="message-content">${taskItem.title}</div>
                                            <div class="message-footer">10:00</div>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                                ${taskItem.iaCompressed?.interaction
                    ? html `
                                    <div class="message system">
                                        <widget-ai-task-100554 
                                            @taskclick=${(ev) => this.handleClickTask(ev, taskItem)}
                                            .task=${taskItem}>
                                        </widget-ai-task-100554>
                                    </div>
                                    `
                    : ''}
                            `;
            })}
                    </div>
                
                    <div class="message-prompt">
                        <textarea id="prompt_textarea"></textarea>
                        <button @click=${this.handleClickSend}>Enviar</button>
                    </div>
                    `
            : html `
                <widget-ai-interaction-100554 stepId=${this.stepIdSelected} taskId=${this.actualTaskDetails?.PK} .interaction=${this.actualTaskDetails?.iaCompressed?.interaction}></widget-ai-interaction-100554>

                `} 
        
    `;
    }
    handleClickHeader() {
        if (this.panel === 'Details')
            this.panel = 'Chat';
    }
    handleClickTask(ev, task) {
        if (ev.detail)
            this.stepIdSelected = ev.detail.stepId;
        else
            this.stepIdSelected = undefined;
        this.actualTaskDetails = task;
        this.panel = 'Details';
    }
    handleClickTask2(task) {
        this.actualTaskDetails = task;
        this.panel = 'Details';
    }
    async handleClickSend() {
        const prompt = this.textarea?.value;
        if (!prompt)
            return;
        const inputs = startPrompt(prompt);
        const task = await execAddTask(inputs, prompt);
        await afterPrompt(task, task.iaCompressed?.interaction?.payload);
    }
};
__decorate([
    state()
], WidgetChatExample100554.prototype, "actualTasks", void 0);
__decorate([
    property()
], WidgetChatExample100554.prototype, "panel", void 0);
__decorate([
    property()
], WidgetChatExample100554.prototype, "actualTaskDetails", void 0);
__decorate([
    property()
], WidgetChatExample100554.prototype, "stepIdSelected", void 0);
__decorate([
    query('#prompt_textarea')
], WidgetChatExample100554.prototype, "textarea", void 0);
WidgetChatExample100554 = __decorate([
    customElement('widget-chat-example-100554')
], WidgetChatExample100554);
export { WidgetChatExample100554 };
