/// <mls shortName="aimTaskGetSourceLanguageTypescript" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
let AimTaskGetSourceLanguageTypescript = class AimTaskGetSourceLanguageTypescript extends AimTaskBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    onInitializing() {
        this.getSource();
    }
    getSource() {
        if (!this.taskRoot.args) {
            this.notifyCompleteByStatus('error', 'Invalid Args');
            return;
        }
        const data = JSON.parse(this.taskRoot.args);
        const shortName = data.fileName;
        this._getSource(shortName).then((ret) => {
            const result = ret;
            this.notifyCompleteByStatus('ok', JSON.stringify(result));
        }).catch((e) => {
            this.notifyCompleteByStatus('error', e);
        });
    }
    _getSource(shortName) {
        return new Promise(async (resolve, reject) => {
            const mfile = mls.l2.editor.mfiles[shortName];
            if (!mfile)
                reject(`No mfile find for file: ${shortName}`);
            const value = mfile.model.getValue();
            const data = getDataInternationalization(value);
            resolve(data);
        });
    }
};
AimTaskGetSourceLanguageTypescript = __decorate([
    customElement('aim-task-get-source-language-typescript-100554')
], AimTaskGetSourceLanguageTypescript);
export function getDataInternationalization(sourceComplete) {
    const regex = /\/\/\/ \*\*collab_i18n_start\*\*([\s\S]*?)\/\/\/ \*\*collab_i18n_end\*\*/g;
    let match;
    let remainingText = sourceComplete;
    let internationalization = undefined;
    match = regex.exec(sourceComplete);
    if (match) {
        const start = match.index;
        const end = regex.lastIndex;
        const beforeBlock = sourceComplete.slice(0, start);
        const block = match[0];
        const afterBlock = sourceComplete.slice(end);
        const startLine = (beforeBlock.match(/\n/g) || []).length + 1;
        const endLine = startLine + (block.match(/\n/g) || []).length;
        const languages = extractLanguages(match[1]);
        internationalization = {
            source: match[1].trim(),
            startLine,
            endLine,
            languages
        };
        remainingText = remainingText.replace(block, '');
    }
    return {
        internationalization,
        source: remainingText.trim(),
        sourceComplete
    };
}
function extractLanguages(text) {
    const regex = /message_([a-zA-Z]+)/g;
    let match;
    const languages = new Set();
    while ((match = regex.exec(text)) !== null) {
        languages.add(match[1]);
    }
    return Array.from(languages);
}
