/// <mls shortName="wcDatePickerRangeCustom" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaFormsInputDateRangeBase } from './_100554_icaFormsInputDateRangeBase';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_collabDecorators';
/**
 * Componente para seleção de intervalo de datas (date range picker), com suporte a limites mínimos/máximos e datas bloqueadas.
 *
 * Estrutura do render:
 * <div class="date-picker-range-wrapper">
 *   <div class="form_error_message">...</div> <!-- se erro -->
 *   <label>...</label>
 *   <div class="date-picker-input" tabindex="0">...</div>
 *   <div class="dropdown-calendar"> <!-- visível se aberto -->
 *     <div class="calendar-container">
 *       ...
 *     </div>
 *     <div class="calendar-actions">...</div>
 *   </div>
 *   <div class="form_hint_message">...</div>
 * </div>
 */
let IcaDatePickerRangeCustom = class IcaDatePickerRangeCustom extends IcaFormsInputDateRangeBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-date-picker-range-custom-100554{display:block;font-family:var(--font-family-primary)}wc-date-picker-range-custom-100554 .date-picker-range-wrapper{width:100%;position:relative}wc-date-picker-range-custom-100554 .form_error_message{color:var(--error-color);font-size:var(--font-size-12);margin-bottom:var(--space-8);font-weight:var(--font-weight-bold);min-height:var(--font-size-16);transition:color var(--transition-normal)}wc-date-picker-range-custom-100554 .form-control-label{display:block;font-size:var(--font-size-16);color:var(--text-primary-color);margin-bottom:var(--space-8);font-weight:var(--font-weight-bold)}wc-date-picker-range-custom-100554 .required{color:var(--error-color);margin-left:2px}wc-date-picker-range-custom-100554 .date-picker-input{display:flex;align-items:center;background:var(--bg-primary-color);border:1px solid var(--grey-color-dark);border-radius:6px;padding:var(--space-8) var(--space-16);cursor:pointer;min-height:40px;font-size:var(--font-size-16);color:var(--text-primary-color);transition:border-color var(--transition-normal)}wc-date-picker-range-custom-100554 .date-picker-input:hover,wc-date-picker-range-custom-100554 .date-picker-input:focus{border-color:var(--active-color);outline:none}wc-date-picker-range-custom-100554 .date-picker-input[disabled],wc-date-picker-range-custom-100554 .date-picker-input[readonly]{background:var(--bg-primary-color-disabled);color:var(--text-primary-color-disabled);cursor:not-allowed}wc-date-picker-range-custom-100554 .date-picker-input .date-picker-value{flex:1;color:var(--text-primary-color)}wc-date-picker-range-custom-100554 .date-picker-input .date-picker-icon{margin-left:var(--space-8);font-size:var(--font-size-20);color:var(--text-secondary-color)}wc-date-picker-range-custom-100554 .dropdown-calendar{position:absolute;top:100%;left:0;z-index:10;background:var(--bg-primary-color-lighter);border:1px solid var(--grey-color-dark);border-radius:8px;box-shadow:0 4px 24px #0002;margin-top:var(--space-8);min-width:320px;padding:var(--space-16)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-controls{display:flex;justify-content:space-between;margin-bottom:var(--space-8)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-controls .calendar-nav{background:none;border:none;font-size:var(--font-size-20);color:var(--text-secondary-color);cursor:pointer;padding:var(--space-8);border-radius:50%;transition:background var(--transition-normal)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-controls .calendar-nav:hover{background:var(--bg-secondary-color-lighter)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-container{display:flex;gap:var(--space-24);justify-content:center;align-items:flex-start}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar{min-width:220px}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-header{text-align:center;font-size:var(--font-size-16);font-weight:var(--font-weight-bold);color:var(--text-secondary-color-darker);margin-bottom:var(--space-8)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid{width:100%}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-weekdays{display:flex;justify-content:space-between;margin-bottom:var(--space-8)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-weekdays .weekday{flex:1;text-align:center;color:var(--text-primary-color-lighter);font-size:var(--font-size-12);font-weight:var(--font-weight-bold)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-week{display:flex;justify-content:space-between;margin-bottom:2px}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-day{flex:1;margin:0 2px;background:var(--bg-primary-color);border:none;border-radius:4px;height:32px;min-width:32px;font-size:var(--font-size-16);color:var(--text-primary-color);cursor:pointer;transition:background var(--transition-fast),color var(--transition-fast)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-day.today{border:1px solid var(--active-color)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-day.selected{background:var(--active-color);color:#fff;font-weight:var(--font-weight-bold)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-day.in-range{background:var(--bg-secondary-color);color:var(--text-primary-color)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-day.disabled,wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-day.blocked{background:var(--bg-secondary-color-lighter);color:var(--error-color);cursor:not-allowed;text-decoration:line-through}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .calendar-day:hover:not(.disabled):not(.blocked):not(.selected){background:var(--bg-secondary-color-lighter-hover);color:var(--text-secondary-color)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar .calendar-grid .empty{flex:1;height:32px;background:none;border:none}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-actions{display:flex;gap:var(--space-8);margin-top:var(--space-16);justify-content:flex-end}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-actions .calendar-action{background:var(--active-color);color:#fff;border:none;border-radius:4px;padding:var(--space-8) var(--space-16);font-size:var(--font-size-16);font-weight:var(--font-weight-bold);cursor:pointer;transition:background var(--transition-normal)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-actions .calendar-action.clear{background:var(--bg-secondary-color);color:var(--text-primary-color)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-actions .calendar-action.close{background:var(--bg-primary-color-lighter);color:var(--text-primary-color-lighter);border:1px solid var(--grey-color)}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-actions .calendar-action:disabled{background:var(--bg-secondary-color-disabled);color:var(--text-primary-color-disabled);cursor:not-allowed}wc-date-picker-range-custom-100554 .dropdown-calendar .calendar-actions .calendar-action:hover:not(:disabled){background:var(--active-color-hover)}wc-date-picker-range-custom-100554 .form_hint_message{color:var(--text-primary-color-lighter);font-size:var(--font-size-12);margin-top:var(--space-8);min-height:var(--font-size-12)}`);
        /** Lista de datas bloqueadas (formato ISO: "2024-06-05"). */
        this.blockedDates = [];
        /** Dica para o usuário. */
        this.hint = '';
        /** Define se o campo é obrigatório. */
        this.required = false;
        /** Define se o widget está desabilitado. */
        this.disabled = false;
        /** Define se o widget é somente leitura. */
        this.readonly = false;
        /** Define se o widget recebe foco automaticamente. */
        this.autofocus = false;
        /** Estado interno: mostra/oculta dropdown */
        this._opened = false;
        /** Estado interno: mensagem de erro atual */
        this._error = '';
        /** Estado interno: mês/ano visível à esquerda */
        this._monthLeft = new Date().getMonth();
        this._yearLeft = new Date().getFullYear();
        /** Estado interno: mês/ano visível à direita */
        this._monthRight = (new Date().getMonth() + 1) % 12;
        this._yearRight = new Date().getMonth() === 11 ? new Date().getFullYear() + 1 : new Date().getFullYear();
    }
    firstUpdated() {
        // Inicializa meses visíveis com base no valor selecionado
        const left = this.startValue ? new Date(this.startValue) : new Date();
        this._monthLeft = left.getMonth();
        this._yearLeft = left.getFullYear();
        const right = new Date(this._yearLeft, this._monthLeft + 1, 1);
        this._monthRight = right.getMonth();
        this._yearRight = right.getFullYear();
    }
    _openDropdown() {
        if (this.disabled || this.readonly)
            return;
        this._opened = true;
        this._tempStart = this.startValue;
        this._tempEnd = this.endValue;
        this._error = '';
    }
    _closeDropdown() {
        this._opened = false;
        this._error = '';
    }
    _onInputKeyDown(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this._openDropdown();
        }
    }
    _onDayClick(dateStr) {
        if (!this._tempStart || (this._tempStart && this._tempEnd)) {
            // Começa nova seleção
            this._tempStart = dateStr;
            this._tempEnd = undefined;
            this._error = '';
        }
        else if (this._tempStart && !this._tempEnd) {
            if (dateStr < this._tempStart) {
                this._error = this.errorMessage || 'A data final deve ser posterior à data inicial.';
                return;
            }
            this._tempEnd = dateStr;
            this._error = '';
        }
    }
    _onConfirm() {
        if (!this._tempStart || !this._tempEnd) {
            this._error = this.errorMessage || 'Selecione o período completo.';
            return;
        }
        if (this._tempStart > this._tempEnd) {
            this._error = this.errorMessage || 'A data final deve ser posterior à inicial.';
            return;
        }
        this.startValue = this._tempStart;
        this.endValue = this._tempEnd;
        this._opened = false;
        this._error = '';
        this.requestUpdate();
    }
    _onClear() {
        this._tempStart = undefined;
        this._tempEnd = undefined;
        this.startValue = undefined;
        this.endValue = undefined;
        this._error = '';
        this._opened = false;
    }
    _isBlocked(dateStr) {
        return this.blockedDates && this.blockedDates.includes(dateStr);
    }
    _isDisabled(date) {
        const iso = date.toISOString().slice(0, 10);
        if (this.minvalue && iso < this.minvalue)
            return true;
        if (this.maxvalue && iso > this.maxvalue)
            return true;
        if (this._isBlocked(iso))
            return true;
        return false;
    }
    _isInRange(dateStr) {
        if (this._tempStart && this._tempEnd) {
            return dateStr >= this._tempStart && dateStr <= this._tempEnd;
        }
        return false;
    }
    _isSelected(dateStr) {
        return dateStr === this._tempStart || dateStr === this._tempEnd;
    }
    _renderCalendar(month, year, side) {
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const todayStr = new Date().toISOString().slice(0, 10);
        const daysInMonth = lastDay.getDate();
        const startWeekDay = firstDay.getDay(); // 0 (domingo) ... 6 (sábado)
        const weeks = [];
        let week = [];
        // Preenche dias do mês anterior
        for (let i = 0; i < startWeekDay; i++) {
            week.push(null);
        }
        for (let d = 1; d <= daysInMonth; d++) {
            week.push(new Date(year, month, d));
            if (week.length === 7) {
                weeks.push(week);
                week = [];
            }
        }
        // Preenche dias do mês seguinte
        if (week.length) {
            while (week.length < 7)
                week.push(null);
            weeks.push(week);
        }
        const monthLabel = `${year}-${String(month + 1).padStart(2, '0')}`;
        const weekDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
        return html `
      <div class="calendar">
        <div class="calendar-header">
          <span class="calendar-label">${monthLabel}</span>
        </div>
        <div class="calendar-grid">
          <div class="calendar-weekdays">
            ${weekDays.map(wd => html `<span class="weekday">${wd}</span>`)}
          </div>
          ${weeks.map(week => html `<div class="calendar-week">
              ${week.map(day => {
            if (!day)
                return html `<span class="calendar-day empty"></span>`;
            const iso = day.toISOString().slice(0, 10);
            const isToday = iso === todayStr;
            const isDisabled = this._isDisabled(day);
            const isBlocked = this._isBlocked(iso);
            const isInRange = this._isInRange(iso);
            const isSelected = this._isSelected(iso);
            return html `
                  <button
                    class="calendar-day${isToday ? ' today' : ''}${isDisabled ? ' disabled' : ''}${isBlocked ? ' blocked' : ''}${isInRange ? ' in-range' : ''}${isSelected ? ' selected' : ''}"
                    ?disabled=${isDisabled}
                    @click=${() => this._onDayClick(iso)}
                    tabindex="-1"
                    aria-label=${iso}
                  >${day.getDate()}</button>
                `;
        })}
            </div>`)}
        </div>
      </div>
    `;
    }
    _prevMonth() {
        // Move ambos os meses para trás
        let leftMonth = this._monthLeft - 1;
        let leftYear = this._yearLeft;
        if (leftMonth < 0) {
            leftMonth = 11;
            leftYear--;
        }
        let rightMonth = leftMonth + 1;
        let rightYear = leftYear;
        if (rightMonth > 11) {
            rightMonth = 0;
            rightYear++;
        }
        this._monthLeft = leftMonth;
        this._yearLeft = leftYear;
        this._monthRight = rightMonth;
        this._yearRight = rightYear;
    }
    _nextMonth() {
        // Move ambos os meses para frente
        let leftMonth = this._monthLeft + 1;
        let leftYear = this._yearLeft;
        if (leftMonth > 11) {
            leftMonth = 0;
            leftYear++;
        }
        let rightMonth = leftMonth + 1;
        let rightYear = leftYear;
        if (rightMonth > 11) {
            rightMonth = 0;
            rightYear++;
        }
        this._monthLeft = leftMonth;
        this._yearLeft = leftYear;
        this._monthRight = rightMonth;
        this._yearRight = rightYear;
    }
    render() {
        const displayValue = this.startValue && this.endValue
            ? `${this.startValue} até ${this.endValue}`
            : (this.placeHolder || 'Selecione o período');
        return html `
      <div class="date-picker-range-wrapper">
        ${this._error ? html `<div class="form_error_message">${this._error}</div>` : nothing}
        ${this.label ? html `<label class="form-control-label">${this.label}${this.required ? html `<span class="required">*</span>` : nothing}</label>` : nothing}
        <div
          class="date-picker-input"
          tabindex="0"
          ?disabled=${this.disabled}
          ?readonly=${this.readonly}
          @click=${this._openDropdown}
          @keydown=${this._onInputKeyDown}
        >
          <span class="date-picker-value">${displayValue}</span>
          <span class="date-picker-icon">&#128197;</span>
        </div>
        ${this._opened ? html `
          <div class="dropdown-calendar">
            <div class="calendar-controls">
              <button class="calendar-nav prev" @click=${this._prevMonth} aria-label="Mês anterior">&#8592;</button>
              <button class="calendar-nav next" @click=${this._nextMonth} aria-label="Próximo mês">&#8594;</button>
            </div>
            <div class="calendar-container">
              ${this._renderCalendar(this._monthLeft, this._yearLeft, 'left')}
              ${this._renderCalendar(this._monthRight, this._yearRight, 'right')}
            </div>
            <div class="calendar-actions">
              <button class="calendar-action confirm" @click=${this._onConfirm} ?disabled=${!(this._tempStart && this._tempEnd)}>Confirmar</button>
              <button class="calendar-action clear" @click=${this._onClear}>Limpar</button>
              <button class="calendar-action close" @click=${this._closeDropdown}>Fechar</button>
            </div>
          </div>
        ` : nothing}
        ${this.hint ? html `<div class="form_hint_message">${this.hint}</div>` : nothing}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], IcaDatePickerRangeCustom.prototype, "startValue", void 0);
__decorate([
    propertyDataSource({ type: String })
], IcaDatePickerRangeCustom.prototype, "endValue", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "minvalue", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "maxvalue", void 0);
__decorate([
    property({ type: Array })
], IcaDatePickerRangeCustom.prototype, "blockedDates", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "label", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "name", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "placeHolder", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], IcaDatePickerRangeCustom.prototype, "hint", void 0);
__decorate([
    property({ type: Boolean })
], IcaDatePickerRangeCustom.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], IcaDatePickerRangeCustom.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], IcaDatePickerRangeCustom.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], IcaDatePickerRangeCustom.prototype, "autofocus", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "errorMessage", void 0);
__decorate([
    property({ type: Boolean })
], IcaDatePickerRangeCustom.prototype, "_opened", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "_tempStart", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "_tempEnd", void 0);
__decorate([
    property({ type: String })
], IcaDatePickerRangeCustom.prototype, "_error", void 0);
__decorate([
    property({ type: Number })
], IcaDatePickerRangeCustom.prototype, "_monthLeft", void 0);
__decorate([
    property({ type: Number })
], IcaDatePickerRangeCustom.prototype, "_yearLeft", void 0);
__decorate([
    property({ type: Number })
], IcaDatePickerRangeCustom.prototype, "_monthRight", void 0);
__decorate([
    property({ type: Number })
], IcaDatePickerRangeCustom.prototype, "_yearRight", void 0);
IcaDatePickerRangeCustom = __decorate([
    customElement('wc-date-picker-range-custom-100554')
], IcaDatePickerRangeCustom);
export { IcaDatePickerRangeCustom };
