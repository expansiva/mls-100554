/// <mls shortName="wcDatePickerRangeCustom" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query, state } from 'lit/decorators.js';
import { IcaFormsInputDateRangeBase } from './_100554_icaFormsInputDateRangeBase';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_icaLitElement';
/**
 * Custom date range picker component for selecting start and end dates.
 *
 * This component renders a date range picker with two consecutive months side by side,
 * allowing users to select a start and end date. It supports minimum and maximum date
 * constraints, blocked dates, and provides visual feedback for the selection process.
 *
 * @element wc-date-picker-range-custom-100554
 *
 * @csspart calendar - The calendar dropdown container
 * @csspart calendar-header - The header section of the calendar
 * @csspart calendar-grid - The grid containing days
 * @csspart calendar-day - Individual day cells
 * @csspart calendar-day-selected - Selected day cells
 * @csspart calendar-day-blocked - Blocked/disabled day cells
 * @csspart calendar-day-in-range - Days between selected start and end dates
 *
 * @fires change - When the date range selection changes
 *
 * @slot - Default slot for custom content
 *
 * @example
 * <wc-date-picker-range-custom-100554
 *   label=\"Select Date Range\"
 *   startValue=\"2023-01-01\"
 *   endValue=\"2023-01-07\"
 *   minvalue=\"2023-01-01\"
 *   maxvalue=\"2023-12-31\"
 *   blockedDates='[\"2023-01-15\", \"2023-01-16\"]'
 * ></wc-date-picker-range-custom-100554>
 */
let WCDatePickerRangeCustom = class WCDatePickerRangeCustom extends IcaFormsInputDateRangeBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-date-picker-range-custom-100554{display:block;position:relative;font-family:'Charlie Display',-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;color:#403f3f;margin-bottom:calc(.25rem * 4)}wc-date-picker-range-custom-100554 .error-message{color:#FF4D4F;font-size:calc(.25rem * 3);margin-bottom:calc(.25rem * 2)}wc-date-picker-range-custom-100554 .form-control-label{display:block;margin-bottom:calc(.25rem * 2);font-weight:700}wc-date-picker-range-custom-100554 .input-container{position:relative;display:flex}wc-date-picker-range-custom-100554 .date-range-input{width:100%;padding:calc(.25rem * 2) calc(.25rem * 4);border:1px solid #D3D3D3;border-radius:4px;font-size:calc(.25rem * 4);background-color:#ffffff;cursor:pointer}wc-date-picker-range-custom-100554 .date-range-input:hover{border-color:#C0C0C0}wc-date-picker-range-custom-100554 .date-range-input:focus{outline:none;border-color:#1890FF;box-shadow:0 0 0 2px rgba(24,144,255,0.2)}wc-date-picker-range-custom-100554 .date-range-input:disabled{background-color:#E6E6E6;cursor:not-allowed}wc-date-picker-range-custom-100554 .calendar-toggle{position:absolute;right:0;top:0;height:100%;padding:0 calc(.25rem * 4);background:transparent;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}wc-date-picker-range-custom-100554 .calendar-toggle:disabled{cursor:not-allowed;opacity:.5}wc-date-picker-range-custom-100554 .hint-text{font-size:calc(.25rem * 3);color:#535353;margin-top:calc(.25rem * 2)}wc-date-picker-range-custom-100554 .calendar-dropdown{position:absolute;top:100%;left:0;z-index:1000;width:100%;max-width:650px;background-color:#ffffff;border:1px solid #D3D3D3;border-radius:4px;box-shadow:0 4px 12px rgba(0,0,0,0.15);margin-top:calc(.25rem * 2);padding:calc(.25rem * 4)}wc-date-picker-range-custom-100554 .calendar-container{display:flex;gap:calc(.25rem * 4);flex-wrap:wrap}wc-date-picker-range-custom-100554 .calendar{flex:1;min-width:280px}wc-date-picker-range-custom-100554 .calendar-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:calc(.25rem * 4)}wc-date-picker-range-custom-100554 .month-year{font-weight:700;font-size:calc(.25rem * 4)}wc-date-picker-range-custom-100554 .nav-button{background:transparent;border:none;cursor:pointer;font-size:calc(.25rem * 4);padding:calc(.25rem * 2);border-radius:50%;display:flex;align-items:center;justify-content:center}wc-date-picker-range-custom-100554 .nav-button:hover{background-color:#F9F9F9}wc-date-picker-range-custom-100554 .weekdays{display:grid;grid-template-columns:repeat(7, 1fr);text-align:center;font-weight:700;font-size:calc(.25rem * 3);margin-bottom:calc(.25rem * 2)}wc-date-picker-range-custom-100554 .weekdays div{padding:calc(.25rem * 2) 0}wc-date-picker-range-custom-100554 .days{display:grid;grid-template-columns:repeat(7, 1fr);gap:2px}wc-date-picker-range-custom-100554 .day{aspect-ratio:1;display:flex;align-items:center;justify-content:center;border:none;background:transparent;cursor:pointer;border-radius:50%;font-size:calc(.25rem * 3);position:relative}wc-date-picker-range-custom-100554 .day:hover:not(.blocked){background-color:#F9F9F9}wc-date-picker-range-custom-100554 .day.other-month{color:#696969}wc-date-picker-range-custom-100554 .day.today{font-weight:700;border:1px solid #1890FF}wc-date-picker-range-custom-100554 .day.selected{background-color:#1890FF;color:#ffffff}wc-date-picker-range-custom-100554 .day.in-range{background-color:rgba(24,144,255,0.2)}wc-date-picker-range-custom-100554 .day.blocked{color:#696969;cursor:not-allowed;text-decoration:line-through}wc-date-picker-range-custom-100554 .calendar-footer{display:flex;justify-content:space-between;align-items:center;margin-top:calc(.25rem * 4);padding-top:calc(.25rem * 4);border-top:1px solid #E6E6E6}wc-date-picker-range-custom-100554 .selection-status{font-size:calc(.25rem * 3);font-style:italic}wc-date-picker-range-custom-100554 .close-button{padding:calc(.25rem * 2) calc(.25rem * 4);background-color:#E6E6E6;border:none;border-radius:4px;cursor:pointer;font-weight:700}wc-date-picker-range-custom-100554 .close-button:hover{background-color:#C0C0C0}`);
        /**
         * Whether the date range picker is required.
         */
        this.required = false;
        /**
         * Whether the date range picker is disabled.
         */
        this.disabled = false;
        /**
         * Whether the date range picker is readonly.
         */
        this.readonly = false;
        /**
         * Placeholder text for the input field.
         */
        this.placeHolder = 'Select date range';
        /**
         * Error message to display when validation fails.
         */
        this.errorMessage = 'Invalid date range selection';
        /**
         * Whether the component should receive focus automatically.
         */
        this.autofocus = false;
        /**
         * Current error message to display.
         */
        this.error = '';
        /**
         * Whether the calendar dropdown is open.
         */
        this.isOpen = false;
        /**
         * The currently displayed month (0-11).
         */
        this.currentMonth = new Date().getMonth();
        /**
         * The currently displayed year.
         */
        this.currentYear = new Date().getFullYear();
        /**
         * The date that is currently being hovered.
         */
        this.hoverDate = null;
        /**
         * The selection mode: 'start' or 'end'.
         */
        this.selectionMode = 'start';
        /**
         * Temporary start date during selection process.
         */
        this.tempStartDate = null;
        /**
         * Temporary end date during selection process.
         */
        this.tempEndDate = null;
        /**
         * Handles clicks outside the component to close the dropdown.
         */
        this.handleClickOutside = (event) => {
            if (this.isOpen && !this.contains(event.target)) {
                this.isOpen = false;
            }
        };
    }
    /**
     * Array of blocked dates parsed from the blockedDates property.
     */
    get parsedBlockedDates() {
        if (!this.blockedDates)
            return [];
        try {
            const dates = JSON.parse(this.blockedDates);
            return dates.map(dateStr => new Date(dateStr));
        }
        catch (e) {
            console.error('Error parsing blockedDates:', e);
            return [];
        }
    }
    /**
     * Minimum date as a Date object.
     */
    get minDate() {
        return this.minvalue ? new Date(this.minvalue) : null;
    }
    /**
     * Maximum date as a Date object.
     */
    get maxDate() {
        return this.maxvalue ? new Date(this.maxvalue) : null;
    }
    /**
     * Start date as a Date object.
     */
    get startDate() {
        return this.startValue ? new Date(this.startValue) : null;
    }
    /**
     * End date as a Date object.
     */
    get endDate() {
        return this.endValue ? new Date(this.endValue) : null;
    }
    /**
     * Formatted display value for the input field.
     */
    get displayValue() {
        if (this.startValue && this.endValue) {
            return `${this.formatDate(new Date(this.startValue))} - ${this.formatDate(new Date(this.endValue))}`;
        }
        return this.placeHolder || '';
    }
    /**
     * Lifecycle method called when the component is first connected to the DOM.
     */
    connectedCallback() {
        super.connectedCallback();
        // Initialize current month/year based on startValue if available
        if (this.startValue) {
            const date = new Date(this.startValue);
            this.currentMonth = date.getMonth();
            this.currentYear = date.getFullYear();
        }
        // Set up click outside listener
        document.addEventListener('click', this.handleClickOutside);
    }
    /**
     * Lifecycle method called when the component is disconnected from the DOM.
     */
    disconnectedCallback() {
        document.removeEventListener('click', this.handleClickOutside);
        super.disconnectedCallback();
    }
    /**
     * Toggles the calendar dropdown.
     */
    toggleCalendar() {
        if (this.disabled || this.readonly)
            return;
        this.isOpen = !this.isOpen;
        // Initialize temp dates when opening
        if (this.isOpen) {
            this.tempStartDate = this.startDate;
            this.tempEndDate = this.endDate;
            this.selectionMode = 'start';
        }
    }
    /**
     * Formats a date as MM/DD/YYYY.
     */
    formatDate(date) {
        return `${date.getMonth() + 1}/${date.getDate()}/${date.getFullYear()}`;
    }
    /**
     * Checks if a date is blocked.
     */
    isDateBlocked(date) {
        // Check if date is in blocked dates
        const isBlocked = this.parsedBlockedDates.some(blockedDate => blockedDate.getFullYear() === date.getFullYear() &&
            blockedDate.getMonth() === date.getMonth() &&
            blockedDate.getDate() === date.getDate());
        // Check if date is outside min/max range
        const isTooEarly = this.minDate ? date < this.minDate : false;
        const isTooLate = this.maxDate ? date > this.maxDate : false;
        return isBlocked || isTooEarly || isTooLate;
    }
    /**
     * Checks if a date is the current date.
     */
    isToday(date) {
        const today = new Date();
        return date.getDate() === today.getDate() &&
            date.getMonth() === today.getMonth() &&
            date.getFullYear() === today.getFullYear();
    }
    /**
     * Checks if a date is selected (either start or end date).
     */
    isSelected(date) {
        if (this.tempStartDate &&
            date.getDate() === this.tempStartDate.getDate() &&
            date.getMonth() === this.tempStartDate.getMonth() &&
            date.getFullYear() === this.tempStartDate.getFullYear()) {
            return true;
        }
        if (this.tempEndDate &&
            date.getDate() === this.tempEndDate.getDate() &&
            date.getMonth() === this.tempEndDate.getMonth() &&
            date.getFullYear() === this.tempEndDate.getFullYear()) {
            return true;
        }
        return false;
    }
    /**
     * Checks if a date is in the selected range (between start and end).
     */
    isInRange(date) {
        if (!this.tempStartDate || (!this.tempEndDate && !this.hoverDate))
            return false;
        const endDate = this.tempEndDate || this.hoverDate;
        if (!endDate)
            return false;
        return date > this.tempStartDate && date < endDate;
    }
    /**
     * Handles date selection.
     */
    handleDateSelect(date) {
        if (this.isDateBlocked(date))
            return;
        if (this.selectionMode === 'start') {
            this.tempStartDate = date;
            this.tempEndDate = null;
            this.selectionMode = 'end';
        }
        else {
            // Ensure end date is after start date
            if (this.tempStartDate && date < this.tempStartDate) {
                this.error = 'End date must be after start date';
                return;
            }
            this.tempEndDate = date;
            this.selectionMode = 'start';
            // Finalize selection
            this.startValue = this.tempStartDate ? this.formatISODate(this.tempStartDate) : undefined;
            this.endValue = this.tempEndDate ? this.formatISODate(this.tempEndDate) : undefined;
            this.error = '';
            this.isOpen = false;
        }
    }
    /**
     * Formats a date as YYYY-MM-DD (ISO format).
     */
    formatISODate(date) {
        return date.toISOString().split('T')[0];
    }
    /**
     * Handles mouse enter on a date cell.
     */
    handleDateHover(date) {
        if (this.selectionMode === 'end' && this.tempStartDate) {
            this.hoverDate = date;
        }
    }
    /**
     * Handles mouse leave on a date cell.
     */
    handleDateLeave() {
        this.hoverDate = null;
    }
    /**
     * Navigates to the previous month.
     */
    prevMonth() {
        if (this.currentMonth === 0) {
            this.currentMonth = 11;
            this.currentYear--;
        }
        else {
            this.currentMonth--;
        }
    }
    /**
     * Navigates to the next month.
     */
    nextMonth() {
        if (this.currentMonth === 11) {
            this.currentMonth = 0;
            this.currentYear++;
        }
        else {
            this.currentMonth++;
        }
    }
    /**
     * Generates the days for a month.
     */
    getDaysInMonth(month, year) {
        const days = [];
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        // Add days from previous month to fill the first week
        const firstDayOfWeek = firstDay.getDay();
        for (let i = firstDayOfWeek - 1; i >= 0; i--) {
            const prevDate = new Date(year, month, -i);
            days.push(prevDate);
        }
        // Add days of current month
        for (let i = 1; i <= lastDay.getDate(); i++) {
            days.push(new Date(year, month, i));
        }
        // Add days from next month to complete the last week
        const lastDayOfWeek = lastDay.getDay();
        for (let i = 1; i < 7 - lastDayOfWeek; i++) {
            days.push(new Date(year, month + 1, i));
        }
        return days;
    }
    /**
     * Gets the month name.
     */
    getMonthName(month) {
        const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        return months[month];
    }
    /**
     * Renders the component.
     */
    render() {
        const currentMonthDays = this.getDaysInMonth(this.currentMonth, this.currentYear);
        const nextMonthIndex = this.currentMonth === 11 ? 0 : this.currentMonth + 1;
        const nextMonthYear = this.currentMonth === 11 ? this.currentYear + 1 : this.currentYear;
        const nextMonthDays = this.getDaysInMonth(nextMonthIndex, nextMonthYear);
        return html `
      <div class=\"date-range-picker\">
        ${this.error ? html `<div class=\"error-message\">${this.error}</div>` : ''}

        <label class=\"form-control-label\" for=\"date-range-input\">
          ${this.label}
        </label>

        <div class=\"input-container\">
          <input
            id=\"date-range-input\"
            class=\"date-range-input\"
            type=\"text\"
            name=${this.name || ''}
            ?disabled=${this.disabled}
            ?readonly=${true}
            ?required=${this.required}
            .value=${this.displayValue}
            ?autofocus=${this.autofocus}
            @click=${this.toggleCalendar}
          />
          <button
            type=\"button\"
            class=\"calendar-toggle\"
            ?disabled=${this.disabled || this.readonly}
            @click=${this.toggleCalendar}
          >
            📅
          </button>
        </div>

        ${this.hint ? html `<div class=\"hint-text\">${this.hint}</div>` : ''}

        ${this.isOpen ? html `
          <div class=\"calendar-dropdown\">
            <div class=\"calendar-container\">
              <!-- First Month -->
              <div class=\"calendar\">
                <div class=\"calendar-header\">
                  <button type=\"button\" class=\"nav-button\" @click=${this.prevMonth}>&#10094;</button>
                  <div class=\"month-year\">${this.getMonthName(this.currentMonth)} ${this.currentYear}</div>
                </div>
                <div class=\"weekdays\">
                  <div>Su</div><div>Mo</div><div>Tu</div><div>We</div><div>Th</div><div>Fr</div><div>Sa</div>
                </div>
                <div class=\"days\">
                  ${currentMonthDays.map(date => {
            const isCurrentMonth = date.getMonth() === this.currentMonth;
            const isBlocked = this.isDateBlocked(date);
            const isSelectedDate = this.isSelected(date);
            const isInSelectedRange = this.isInRange(date);
            const isTodayDate = this.isToday(date);
            return html `
                      <button
                        type=\"button\"
                        class=\"day ${isCurrentMonth ? 'current-month' : 'other-month'}
                               ${isSelectedDate ? 'selected' : ''}
                               ${isInSelectedRange ? 'in-range' : ''}
                               ${isBlocked ? 'blocked' : ''}
                               ${isTodayDate ? 'today' : ''}\"
                        ?disabled=${isBlocked}
                        @click=${() => this.handleDateSelect(date)}
                        @mouseenter=${() => this.handleDateHover(date)}
                        @mouseleave=${this.handleDateLeave}
                      >
                        ${date.getDate()}
                      </button>
                    `;
        })}
                </div>
              </div>

              <!-- Second Month -->
              <div class=\"calendar\">
                <div class=\"calendar-header\">
                  <div class=\"month-year\">${this.getMonthName(nextMonthIndex)} ${nextMonthYear}</div>
                  <button type=\"button\" class=\"nav-button\" @click=${this.nextMonth}>&#10095;</button>
                </div>
                <div class=\"weekdays\">
                  <div>Su</div><div>Mo</div><div>Tu</div><div>We</div><div>Th</div><div>Fr</div><div>Sa</div>
                </div>
                <div class=\"days\">
                  ${nextMonthDays.map(date => {
            const isCurrentMonth = date.getMonth() === nextMonthIndex;
            const isBlocked = this.isDateBlocked(date);
            const isSelectedDate = this.isSelected(date);
            const isInSelectedRange = this.isInRange(date);
            const isTodayDate = this.isToday(date);
            return html `
                      <button
                        type=\"button\"
                        class=\"day ${isCurrentMonth ? 'current-month' : 'other-month'}
                               ${isSelectedDate ? 'selected' : ''}
                               ${isInSelectedRange ? 'in-range' : ''}
                               ${isBlocked ? 'blocked' : ''}
                               ${isTodayDate ? 'today' : ''}\"
                        ?disabled=${isBlocked}
                        @click=${() => this.handleDateSelect(date)}
                        @mouseenter=${() => this.handleDateHover(date)}
                        @mouseleave=${this.handleDateLeave}
                      >
                        ${date.getDate()}
                      </button>
                    `;
        })}
                </div>
              </div>
            </div>

            <div class=\"calendar-footer\">
              <div class=\"selection-status\">
                ${this.selectionMode === 'start' ? 'Select start date' : 'Select end date'}
              </div>
              <button type=\"button\" class=\"close-button\" @click=${() => this.isOpen = false}>Close</button>
            </div>
          </div>
        ` : ''}
      </div>
    `;
    }
};
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "label", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WCDatePickerRangeCustom.prototype, "hint", void 0);
__decorate([
    property({ type: Boolean })
], WCDatePickerRangeCustom.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WCDatePickerRangeCustom.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WCDatePickerRangeCustom.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: String })
], WCDatePickerRangeCustom.prototype, "startValue", void 0);
__decorate([
    propertyDataSource({ type: String })
], WCDatePickerRangeCustom.prototype, "endValue", void 0);
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "placeHolder", void 0);
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "errorMessage", void 0);
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "pattern", void 0);
__decorate([
    property({ type: Boolean })
], WCDatePickerRangeCustom.prototype, "autofocus", void 0);
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "minvalue", void 0);
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "maxvalue", void 0);
__decorate([
    property({ type: String })
], WCDatePickerRangeCustom.prototype, "blockedDates", void 0);
__decorate([
    query('input')
], WCDatePickerRangeCustom.prototype, "inputElement", void 0);
__decorate([
    query('.calendar-dropdown')
], WCDatePickerRangeCustom.prototype, "calendarDropdown", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "error", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "isOpen", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "currentMonth", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "currentYear", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "hoverDate", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "selectionMode", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "tempStartDate", void 0);
__decorate([
    state()
], WCDatePickerRangeCustom.prototype, "tempEndDate", void 0);
WCDatePickerRangeCustom = __decorate([
    customElement('wc-date-picker-range-custom-100554')
], WCDatePickerRangeCustom);
export { WCDatePickerRangeCustom };
