/// <mls shortName="wcTableSelect" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLayoutGroupTableBase } from './_100554_icaLayoutGroupTableBase';
import { propertyDataSource } from './_100554_icaLitElement';
let WcTableSelect100554 = class WcTableSelect100554 extends IcaLayoutGroupTableBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`wc-table-select-100554{display:block;margin-bottom:.5rem}wc-table-select-100554 table{width:100%}wc-table-select-100554 table,wc-table-select-100554 th,wc-table-select-100554 td{border:1px solid}`);
    }
    render() {
        if (!this.data || this.data.length === 0)
            return html ``;
        return html `
            <table>
                <thead>
                    <tr>
                        ${this.renderHeader()}
                    </tr>
                </thead> 
                <tbody>
                    ${this.renderBody()}
                </tbody>
                
            </table>
        `;
    }
    renderHeader() {
        if (!this.data || this.data.length === 0)
            return html ``;
        let header = Object.keys(this.data[0]);
        let max = this.maxcolumn && this.maxcolumn > 0 ? this.maxcolumn : header.length;
        header = header.slice(0, max);
        return html `
            ${repeat(header, ((key) => key), ((k, index) => { return html `<th>${k}</th>`; }))}
        `;
    }
    renderBody() {
        if (!this.data || this.data.length === 0)
            return html ``;
        let header = Object.keys(this.data[0]);
        let max = this.maxcolumn && this.maxcolumn > 0 ? this.maxcolumn : header.length;
        header = header.slice(0, max);
        return html `
            ${repeat(this.data, ((key, idx) => 'it' + idx), ((k, index) => { return html `<tr .info=${{ data: k, index: index }} @click=${this.selectItem}>${this.renderBodyItem(k, header)}</tr>`; }))}
        `;
    }
    renderBodyItem(item, h) {
        return html `
            ${repeat(h, ((key) => key), ((k, index) => { return html `<td>${item[k]}</td>`; }))}
        `;
    }
    //---------IMPLEMENTS---------
    selectItem(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'tr') {
            el = el.closest('tr');
        }
        if (!el)
            return;
        const info = el.info;
        const evento = new CustomEvent('item-selected', {
            detail: info,
            bubbles: true,
            composed: true,
        });
        this.dispatchEvent(evento);
    }
};
__decorate([
    propertyDataSource()
], WcTableSelect100554.prototype, "data", void 0);
__decorate([
    property()
], WcTableSelect100554.prototype, "columns", void 0);
__decorate([
    property()
], WcTableSelect100554.prototype, "maxcolumn", void 0);
__decorate([
    property()
], WcTableSelect100554.prototype, "striped", void 0);
__decorate([
    property()
], WcTableSelect100554.prototype, "bordered", void 0);
WcTableSelect100554 = __decorate([
    customElement('wc-table-select-100554')
], WcTableSelect100554);
export { WcTableSelect100554 };
