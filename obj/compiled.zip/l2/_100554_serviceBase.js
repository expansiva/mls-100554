/// <mls shortName="serviceBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from './_100554_collabLitElement';
import { customElement, property, state } from 'lit/decorators.js';
let ServiceBase = class ServiceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.position = 'left';
        this.visible = 'false';
        this.msize = '';
        this.loading = false;
    }
    // @property({ type: Number, reflect: true })
    get level() { return +(this.getAttribute('level') || 7); }
    ;
    get serviceContent() { return this.getNav3ServiceContent(); }
    get nav3Service() { return this.getNav3Service(); }
    get serviceItemNav() { return this.getServiceItemNav(); }
    get tooltipEl() { return this.getTooltip(); }
    getActualRef() {
        return this.nav3Service?.getAttribute('data-service') || '';
    }
    setError(error) {
        const nav3Service = this.getNav3Service();
        if (!nav3Service)
            return;
        nav3Service['serviceBind'] = this.details.widget;
        nav3Service.setAttribute('error', error);
    }
    toogleBadge(show, serviceName) {
        const mlsNav2 = this.getMlsNav2();
        if (!mlsNav2) {
            console.error('Function toogleBadge: mls-nav-2 dont exist');
            return;
        }
        mlsNav2.toogleBadge(show, serviceName);
    }
    openMe() {
        const itemService = this.serviceItemNav;
        if (itemService)
            itemService.click();
    }
    showNav2Item(show) {
        const itemService = this.serviceItemNav;
        if (itemService && itemService.show)
            itemService.show(show);
    }
    openService(service, position, level) {
        let page = this.closest('collab-page');
        if (!page)
            return;
        const toolbar = page.querySelector(`collab-nav-2[toolbarposition="${position}"]`);
        if (!toolbar)
            return;
        if (this.level !== level) {
            toolbar.state[level][position] = service;
            this.selectLevel(level);
            return;
        }
        const item = toolbar.querySelector(`collab-nav-2-item[data-service="${service}"]`);
        if (item)
            item.click();
        return;
    }
    setFullScreen(level, position) {
        const spliter = this.getSplitter();
        if (!spliter)
            return;
        spliter.setFullScreen(level, position);
    }
    selectLevel(level) {
        const page = this.closest('collab-page');
        const nav = page?.querySelector('collab-nav-1');
        const objIndex = {
            0: 7,
            1: 6,
            2: 5,
            3: 4,
            4: 3,
            5: 2,
            6: 1,
            7: 0,
        };
        if (!nav)
            return;
        nav.setAttribute('tabindexactive', objIndex[level]);
    }
    addScenario(page, fullscreen = false) {
        const nav3 = this.getNav3ServiceMenu();
        if (!nav3)
            return;
        let scenarios = nav3.getAttribute('scenarios');
        if (!scenarios)
            scenarios = page;
        else
            scenarios = `${scenarios},${page}`;
        nav3.setAttribute('scenarios', scenarios);
        if (fullscreen)
            this.setFullScreen(this.level, this.position);
    }
    removeScenario(page, fullscreen) {
        const nav3 = this.getNav3ServiceMenu();
        if (!nav3)
            return;
        let scenarios = nav3.getAttribute('scenarios');
        if (!scenarios)
            return;
        const arrayScenarios = scenarios.split(',');
        const newArrayScenarios = arrayScenarios.filter(element => element !== page);
        if (newArrayScenarios.length === 0)
            nav3.removeAttribute('scenarios');
        else
            nav3.setAttribute('scenarios', newArrayScenarios.join(','));
        if (fullscreen)
            this.setFullScreen(this.level, this.position);
        else if (fullscreen === false)
            this.setFullScreen(this.level, 'default');
    }
    // Internal
    connectedCallback() {
        super.connectedCallback();
        this['mlsWidget'] = this;
        this.serviceContent?.addEventListener('focusin', this.checkFocus.bind(this));
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'visible') {
            const visible = newVal === 'true';
            const reinit = oldVal !== null && visible !== false;
            if (this.onServiceClick && typeof this.onServiceClick === 'function')
                this.onServiceClick(visible, reinit, this.getNav3ServiceContent());
        }
        if (name === 'msize') {
            const [width, height, top, left] = this.msize.split(',');
            if (height)
                this.style.height = height + 'px';
        }
        super.attributeChangedCallback(name, oldVal, newVal);
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('loading')) {
            const loading = changedProperties.get('loading');
            if (loading !== undefined) {
                const nav3Service = this.getNav3Service();
                if (!nav3Service)
                    return;
                nav3Service['serviceBind'] = this.details.widget;
                nav3Service.setAttribute('loading', (!loading).toString());
            }
        }
    }
    checkFocus() {
        if (!this.serviceContent)
            return;
        if (this.serviceContent.contains(document.activeElement)) {
            this.setActualServicePosition();
        }
    }
    setActualServicePosition() {
        if (!this.serviceContent || !this.nav3Service)
            return;
        const service = this.serviceContent.getAttribute('data-service') || '';
        const position = this.nav3Service.getAttribute('toolbarposition') || '';
        mls.setActualPosition(position);
        mls.setActualService(service);
    }
    getMlsNav2() {
        const mlsNav2 = this.closest('collab-nav-3')?.previousElementSibling;
        return mlsNav2;
    }
    getNav3ServiceContent() {
        const parentToolbarContent = this.closest('collab-nav-3-service');
        return parentToolbarContent;
    }
    getNav3Service() {
        const parentToolbarContent = this.closest('collab-nav-3');
        return parentToolbarContent;
    }
    getNav3ServiceMenu() {
        const content = this.getNav3ServiceContent();
        if (!content)
            return null;
        const nav3Menu = content.querySelector('mls-nav3-100529');
        return nav3Menu;
    }
    getTooltip() {
        const tooltip = document.querySelector('collab-tooltip');
        return tooltip;
    }
    getSplitter() {
        const tooltip = this.closest('collab-spliter');
        return tooltip;
    }
    getServiceItemNav() {
        const toolbar = this.getMlsNav2();
        if (!toolbar)
            return null;
        const content = this.getNav3ServiceContent();
        if (!content)
            return null;
        const dataservice = content.getAttribute('data-service');
        const item = toolbar.querySelector(`collab-nav-2-item[data-service="${dataservice}"]`);
        return item;
    }
};
__decorate([
    property({ type: String, reflect: true })
], ServiceBase.prototype, "position", void 0);
__decorate([
    property({ type: String })
], ServiceBase.prototype, "visible", void 0);
__decorate([
    property({ type: String, noAccessor: true })
], ServiceBase.prototype, "msize", void 0);
__decorate([
    state()
], ServiceBase.prototype, "loading", void 0);
ServiceBase = __decorate([
    customElement('service-base-100554')
], ServiceBase);
export { ServiceBase };
