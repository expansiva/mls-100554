"use strict";
/// <mls shortName="agentGeneratePrototype2" project="100554" enhancement="_blank" folder="" />
