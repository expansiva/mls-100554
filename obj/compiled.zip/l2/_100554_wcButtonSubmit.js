/// <mls shortName="wcButtonSubmit" project="100554" enhancement="_100554_enhancementLit" groupName="FormsSubmitSubmit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, ifDefined } from 'lit';
import { customElement, property, } from 'lit/decorators.js';
import { IcaFormsSubmitSubmitBase } from './_100554_icaFormsSubmitSubmitBase';
let WcButtonSubmit = class WcButtonSubmit extends IcaFormsSubmitSubmitBase {
    constructor() {
        super(...arguments);
        this.title = '';
        this.disabled = false; // Whether the field is ready for input or disabled
    }
    render() {
        return html `
            <button 
                name=${ifDefined(this.name)} 
                title=${ifDefined(this.title)} 
                ?disabled=${this.disabled} 
                form=${ifDefined(this.form)}>
                ${this.text || ''}
            </button>
        `;
    }
};
WcButtonSubmit.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "title", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "icon", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "text", void 0);
__decorate([
    property({ type: Boolean })
], WcButtonSubmit.prototype, "disabled", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "form", void 0);
WcButtonSubmit = __decorate([
    customElement('wc-button-submit-100554')
], WcButtonSubmit);
export { WcButtonSubmit };
