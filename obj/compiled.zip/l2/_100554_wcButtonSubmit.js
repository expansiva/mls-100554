/// <mls shortName="wcButtonSubmit" project="100554" enhancement="_100554_enhancementLit" groupName="FormsSubmitSubmit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, } from 'lit/decorators.js';
import { propertyDataSource } from './_100554_collabDecorators';
import { StateLitElement } from './_100554_stateLitElement';
let WcButtonSubmit = class WcButtonSubmit extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-button-submit-100554{display:block}wc-button-submit-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}wc-button-submit-100554 button:hover{background-color:var(--grey-color-light)}`);
        this.title = '';
        this.disabled = false; // Whether the field is ready for input or disabled
    }
    createRenderRoot() {
        return this;
    }
    render() {
        return html `
            <button 
                name=${ifDefined(this.name)} 
                title=${ifDefined(this.title)} 
                ?disabled=${this.disabled} 
                form=${ifDefined(this.form)}
                @click=${this.handleClick}
                >
                ${this.text || ''}
            </button>
        `;
    }
    handleClick() {
        this.clickedAction = this.clickedValue;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'clicked-value' })
], WcButtonSubmit.prototype, "clickedValue", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'clicked-action' })
], WcButtonSubmit.prototype, "clickedAction", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "title", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "icon", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "text", void 0);
__decorate([
    property({ type: Boolean })
], WcButtonSubmit.prototype, "disabled", void 0);
__decorate([
    property({ type: String })
], WcButtonSubmit.prototype, "form", void 0);
WcButtonSubmit = __decorate([
    customElement('wc-button-submit-100554')
], WcButtonSubmit);
export { WcButtonSubmit };
