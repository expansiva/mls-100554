/// <mls shortName="collabLitElement" project="100554" enhancement="_blank" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement } from 'lit';
import { property } from 'lit/decorators.js';
import { CollabState } from './_100554_collabState';
const isTrace = false;
const state1 = new CollabState();
/**
 * Decorator to synchronize a property with a CollabState key.
 * @param customKey - The state key. Defaults to property key.
 */
export function collabState(customKey) {
    return (proto, propertyKey) => {
        const key = customKey || String(propertyKey);
        const { connectedCallback, disconnectedCallback } = proto;
        proto.connectedCallback = function () {
            if (isTrace)
                console.log('connectedCallback, key=' + key);
            connectedCallback?.call(this);
            state1.subscribe(key, this);
            // const value = state1.getState(key);
            // this[propertyKey] = value !== undefined ? value : this[propertyKey];
        };
        proto.disconnectedCallback = function () {
            if (isTrace)
                console.log('disconnectedCallback, key=' + key);
            disconnectedCallback?.call(this);
            state1.unsubscribe(key, this);
        };
        proto.handleCollabStateChange = function (changedKey, value) {
            if (isTrace)
                console.log('handleCollabStateChange, key=' + key + ', value=', value);
            this[propertyKey] = value;
            this.requestUpdate(propertyKey, value);
            // if (changedKey === key && this[propertyKey] !== value) {
            //   this[propertyKey] = value;
            //   this.requestUpdate(propertyKey as string, value);
            // }
        };
        // Object.defineProperty(proto, propertyKey, {
        //   get() {
        //     const value = state1.getState(key);
        //     console.log('state get, key=' + key + ', value=', value);
        //     return value;
        //   },
        //   set(value: any) {
        //     console.log('state set, key=' + key + ', value=', value);
        //     state1.setState(key, value);
        //   },
        //   configurable: true,
        //   enumerable: true
        // });    
    };
}
/**
 * Class extending LitElement with CollabState functionality.
 */
export class CollabLitElement extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.globalVariation = window.globalVariation || 0;
    }
    /**
     * Update shared state.
     * @param key - The state key to update.
     * @param value - The new state value.
     */
    setCollabState(key, value) {
        state1.setState(key, value);
    }
    collabRequestUpdate() {
        super.requestUpdate();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('globalVariation') && changedProperties.get('globalVariation') !== undefined) {
            this.requestUpdate();
        }
    }
    getMessageKey(messages) {
        return getMessageKey(messages);
    }
    loadStyle(css) {
        if (!css)
            return;
        const tagName = this.tagName.toLowerCase();
        const alreadyAdded = document.body.querySelector(`style#${tagName}`);
        if (alreadyAdded) {
            alreadyAdded.textContent = css;
            return;
        }
        const style = document.createElement('style');
        style.id = tagName;
        style.textContent = css;
        document.body.appendChild(style);
    }
}
__decorate([
    property({ type: Number })
], CollabLitElement.prototype, "globalVariation", void 0);
export function getMessageKey(messages) {
    const keys = Object.keys(messages);
    if (!keys || keys.length < 1)
        throw new Error('Error Message not valid for international');
    const firstKey = keys[0];
    const lang = (document.documentElement.lang || '').toLowerCase();
    if (!lang)
        return firstKey;
    if (messages.hasOwnProperty(lang))
        return lang;
    const similarLang = keys.find((key) => lang.substring(0, 2) === key);
    if (similarLang)
        return similarLang;
    return firstKey;
}
