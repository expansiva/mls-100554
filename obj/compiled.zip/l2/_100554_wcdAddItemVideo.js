/// <mls shortName="wcdAddItemVideo" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { collab_video } from './_100554_collabIcons';
import { CollabLitElement } from "./_100554_collabLitElement";
/// **collab_i18n_start**
const message_pt = {
    video: 'Adicionar um video',
};
const message_en = {
    video: 'Add a video',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdAddItemVideo100554 = class WcdAddItemVideo100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <wcd-add-button @keydown=${this.handleKeyDown} @click=${this.handleClick} data-tooltip=${this.msg.video} ><span>${collab_video}</span></wcd-add-button>

    `;
    }
    async handleClick(e) {
        e.stopPropagation();
        this.showHelper();
    }
    async handleKeyDown(e) {
        e.stopPropagation();
        if (e.key === 'Enter') {
            this.handleClick(new MouseEvent('click'));
        }
    }
    showHelper() {
        if (!window.wcdState)
            throw new Error('Invalid window.wcdState');
        if (!window.wcdState.myParent)
            throw new Error('Invalid window.wcdState.myParent');
        window.wcdState.myParent.onclick = null;
        window.wcdState.myParent.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: '_100554_wcdDialogVideo',
                args: '',
                position: 'p-l1',
                level: [2],
                toolboxOptions: { background: '#fff', border: 'none' }
            },
        ], false, 'size');
    }
};
WcdAddItemVideo100554.styles = css ``;
WcdAddItemVideo100554 = __decorate([
    customElement('wcd-add-item-video-100554')
], WcdAddItemVideo100554);
export { WcdAddItemVideo100554 };
