/// <mls shortName="testePageIca" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';
import { globalState } from './_100554_collabState';
let IcaTestPage100554 = class IcaTestPage100554 extends LitElement {
    render() {
        globalState._ica = {
            tables: {
                sex: [{ key: 'm', value: 'masculino' }, { key: 'f', value: 'feminino' }]
            },
            users: [{
                    name: 'Wagner',
                    age: 63,
                    city: 'SP',
                    sex: 'm'
                },
                {
                    name: 'Guilherme',
                    age: 28,
                    city: 'SP',
                    sex: 'm'
                }]
        };
        return html ``;
    }
};
IcaTestPage100554.styles = css `:host {
        display: flex;
    }`;
IcaTestPage100554 = __decorate([
    customElement('teste-page-ica-100554')
], IcaTestPage100554);
export { IcaTestPage100554 };
