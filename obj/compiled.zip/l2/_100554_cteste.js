/// <mls shortName="cteste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState } from './_100554_icaState';
let Cteste100554 = class Cteste100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`cteste-100554 h1{background:linear-gradient(135deg, #f3c5bd 0%, #e86c57 50%, #ea2803 51%, #f60 75%, #c72200 100%);margin-left:0;margin-bottom:2em;margin-right:0;margin-top:10px;padding:1em}`);
    }
    initPage() {
        console.info('teste em Cteste100554');
        globalState._ica = {
            tables: {
                sex: [{ key: 'm', value: 'masculino' }, { key: 'f', value: 'feminino' }],
            },
            newUser: {
                name: 'Jose da Silva',
                age: 10,
                city: '',
                sex: ''
            },
            sum: 0,
        };
    }
    /// **collab_events_start**
    handleClickbuttonSum() {
        // here or code for event
    }
};
Cteste100554 = __decorate([
    customElement('cteste-100554')
], Cteste100554);
export { Cteste100554 };
