/// <mls shortName="aimActionAddLanguage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { tasks, updateTaskOnServer, getInfoMyService } from './_100554_aimHelper';
import { AimActionBase } from './_100554_aimActionBase';
import { initAimSelectWidget100554 } from './_100554_aimSelectWidget';
import { initAimSelectLanguage100554 } from './_100554_aimSelectLanguage';
const myName = '_100554_aimActionAddLanguage';
/// **collab_i18n_start**
const message_pt = {
    "action_title": "verificar e adicionar uma nova linguagem",
    "btn_cancel": "Cancelar",
    "btn_confirm": "Confirmar",
    "filesSelected": "arquivos selecionado",
    "languagesSelected": "linguagens selecionadas",
    "anchorSelectWidget": "selecionar arquivos...",
    "anchorSelectLanguage": "selecionar linguagens...",
    "file": "Arquivo:",
    "language": "Linguagem:",
    "label_checkbox": "Somente criar action se não existir a linguagem selecionada.",
    "message_error_1": "Por favor, selecione um widget para continuar",
    "message_error_2": "Por favor, selecione uma linguagem para continuar",
    "info": "Configurações"
};
const message_en = {
    "action_title": "check and add new language",
    "btn_cancel": "Cancel",
    "btn_confirm": "Confirm",
    "filesSelected": "files selected.",
    "languagesSelected": "languages selected.",
    "anchorSelectWidget": "select files...",
    "anchorSelectLanguage": "select languages...",
    "file": "File:",
    "language": "Language:",
    "label_checkbox": "Only create the action if the selected language does not exist.",
    "message_error_1": "Please select a widget first!",
    "message_error_2": "Please select a language first!",
    "info": "Config"
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let AimActionAddLanguage = class AimActionAddLanguage extends AimActionBase {
    constructor() {
        super();
        this.loadStyle(``);
        this.currentScenario = 'main';
        this.level = 0;
        this.height = 0;
        this.widgets = [];
        this.languages = [];
        this.onlyLanguageDontConfigured = false;
        this.msg = messages['en'];
        this.assistant = "gpt3_typescript";
        this.title = "Add Language";
        this.language = 'english';
        initAimSelectWidget100554();
        initAimSelectLanguage100554();
    }
    getRules() {
        return [{
                level: 2,
                tags: ["*serviceSource*"]
            },
            {
                level: 5,
                tags: ["*"]
            }];
    }
    render() {
        this.info = getInfoMyService(this);
        this.level = this.info?.level || 0;
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return super.render();
    }
    handleCancel() {
        this.dispatchEvent(new CustomEvent('add-task', {
            detail: { cancel: 'true' }, bubbles: true, composed: true
        }));
    }
    changeScenario(ev, s) {
        ev.preventDefault();
        this.currentScenario = s;
    }
    handleSelectLanguageConfirm(e) {
        const languages = e.detail;
        this.languages = [...languages];
        this.handleCancel2();
    }
    handleSelectWidgetConfirm(e) {
        const widgets = e.detail;
        this.widgets = [...widgets];
        this.handleCancel2();
    }
    handleCancel2() {
        this.currentScenario = 'main';
    }
    handleCheckConfig(e) {
        const inp = e.target;
        this.onlyLanguageDontConfigured = inp.checked;
    }
    async handleAdd() {
        if (this.level === 2) {
            if (!this.info || (this.info.actServiceOp && this.info.actServiceOp.tagName !== 'SERVICE-SOURCE-100554')) {
                throw new Error('Invalid service opposite side');
            }
            const position = this.info.position === 'left' ? 'right' : 'left';
            if (!mls.actual[2][position])
                throw new Error('Invalid File in mls.actual[2]');
            const { shortName } = mls.actual[2][position];
            this.widgets = [shortName];
        }
        if (this.widgets.length === 0) {
            window.collabMessages.add(this.msg.message_error_1, 'error', { autoClose: true, timeToClose: 3000 });
            return;
        }
        if (this.languages.length === 0) {
            window.collabMessages.add(this.msg.message_error_2, 'error');
            return;
        }
        const { project } = mls.actual[5];
        if (!project)
            throw new Error('Invalid project');
        for (const widget of this.widgets) {
            this.addTask(project, widget);
        }
    }
    addTask(project, fileName) {
        const args = {
            project,
            fileName,
            languages: this.languages,
            onlyLanguageDontConfigured: this.onlyLanguageDontConfigured
        };
        const taskRoot = {
            mode: 'initializing',
            title: this.msg.action_title,
            widget: myName,
            children: [],
            args: JSON.stringify(args),
            trace: [new Date().toISOString() + ': trask created at ']
        };
        tasks.unshift(taskRoot);
        this.prepareTask1(taskRoot, fileName, project);
        this.dispatchEvent(new CustomEvent('finished-add-task-root', {
            detail: taskRoot, bubbles: true, composed: true
        }));
    }
    renderAdd() {
        if (!this.info)
            throw new Error('Invalid Service Info');
        if (![2, 5].includes(this.level))
            throw new Error('Invalid level');
        this.style.height = this.height + 'px';
        this.style.display = 'block';
        return html `
                ${this.currentScenario === 'main' ? html `
                    <p> ${this.msg.action_title}</p>
                    <hr>
                    <div style="display:flex;">
                        <input id="check-config" type="checkbox" ?checked=${this.onlyLanguageDontConfigured} @change=${this.handleCheckConfig}></input>
                        <label for="check-config">${this.msg.label_checkbox}</label>
                    </div>
                    <div>
                        <fieldset>
                            <legend>${this.msg.info}</legend>
                            <div style=${this.level === 2 ? 'display:none;' : 'display:block;'}>
                                <span>${this.msg.file} ${this.widgets.length === 1 ? this.widgets[0] : this.widgets.length + ' ' + this.msg.filesSelected}</span>
                                <a href="#" @click=${(e) => this.changeScenario(e, 'selectWidget')}> ${this.msg.anchorSelectWidget} </a>
                            </div>
                            <div>
                                <span>${this.msg.language} ${this.languages.length === 1 ? this.languages[0].name + '(' + this.languages[0].code + ')' : this.languages.length + ' ' + this.msg.languagesSelected}</span>
                                <a href="#" @click=${(e) => this.changeScenario(e, 'selectLanguage')} > ${this.msg.anchorSelectLanguage} </a>
                            </div>
                        </fieldset>
                    </div>
                ` : ''}

                ${this.currentScenario === 'selectLanguage' ? html `
                    <div>
                        <aim-select-language-100554
                            height=${this.height}
                            .defaultValue=${this.languages}
                            @select-language-confirm=${this.handleSelectLanguageConfirm} 
                            @select-language-cancel=${this.handleCancel2}>
                        </aim-select-language-100554>
                    </div>
                ` : ''}
    

                ${this.currentScenario === 'selectWidget' ? html `
                    <aim-select-widget-100554
                        height=${this.height}
                        .defaultValue=${this.widgets}
                        @select-widget-confirm=${this.handleSelectWidgetConfirm} 
                        @select-widget-cancel=${this.handleCancel2}>
                    </aim-select-widget-100554>
                ` : ''}

                ${this.currentScenario === 'main' ? html `    
                    <div class="buttonGroup" style="margin-top:1rem;">
                        <button @click="${this.handleCancel}">${this.msg.btn_cancel}</button>
                        <button @click="${this.handleAdd}">${this.msg.btn_confirm}</button>
                    </div>
                ` : ''}
    `;
    }
    getPromptTs(source, languages) {
        const langs = languages.map((lang) => `${lang.name}(${lang.code})`);
        const prompt = `adicionar as linguagens: ${langs.join(';')}  no código abaixo. Manter as linguagens existentes. Não retornar explicações. Retornar um único bloco \`\`\`typescript

${source}
 `;
        return prompt;
    }
    getPromptHTML(source, attributesHTMLWithLanguages, languages) {
        const langs = languages.map((lang) => `${lang.name}(${lang.code})`);
        const prompt = `Complete os atributos: ${attributesHTMLWithLanguages.join(';')} que estão vazios, com os valores traduzidos de acordo com as seguintes linguagens: ${langs.join(';')}.
        
Por favor, não adicione novos atributos nem modifique atributos que já possuem valores. Apenas preencha os atributos que estão explicitamente vazios.

Não retornar explicações.
Retorne somente o código html em um bloco   \`\`\`html 

Aqui esta o codigo HTML: 

${source}
 `;
        return prompt;
    }
    prepareTask1(taskRoot, fileName, project) {
        this.mode = taskRoot.mode = 'in progress';
        const ref = `_${project}_${fileName}`;
        this.addTaskAndWaitForCompletion(taskRoot, {
            mode: 'initializing',
            title: 'get info',
            widget: '_100554_aimTaskGetSourceLanguages',
            ref,
            trace: [],
            nextStep: this.prepareTaskPromptTs.name // danger, loop
        });
    }
    prepareTaskPromptTs(taskFinishResult) {
        const child = taskFinishResult.taskChild;
        const result = taskFinishResult.result || '';
        if (taskFinishResult.status === 'error') {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            return;
        }
        if (!result) {
            child.trace.push(new Date().toISOString() + ': no result find in task child');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        child.mode = 'processed';
        const args = JSON.parse(result);
        console.info(args);
        taskFinishResult.taskRoot.args = JSON.stringify(args);
        if (!args.checkHtml && !args.checkTs) {
            child.trace.push(new Date().toISOString() + ': no html/ts avaliable to add language');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        if (!args.checkTs) {
            this.prepareTaskPromptHTML(taskFinishResult);
            return;
        }
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
            mode: 'initializing',
            title: 'exec prompt',
            widget: '_100554_aimTaskExecLLM',
            ref: child.ref + '.ts',
            agent: this.assistant,
            prompt: this.getPromptTs(args.detailsi18n?.source, args.languages),
            trace: [],
            nextStep: this.prepareTaskResultTs.name // danger, loop
        });
    }
    prepareTaskResultTs(taskFinishResult) {
        const child = taskFinishResult.taskChild;
        const result = child.result || '';
        if (taskFinishResult.status === 'error') {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            return;
        }
        if (!taskFinishResult.taskRoot.args) {
            child.trace.push(new Date().toISOString() + ': taskroot args is missing');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        if (!child.result) {
            child.trace.push(new Date().toISOString() + ': no result in task');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        const infoFile = JSON.parse(taskFinishResult.taskRoot.args);
        child.mode = 'processed';
        const nextStep = infoFile.checkHtml ? this.prepareTaskPromptHTML.name : this.endTasks.name;
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
            mode: 'initializing',
            title: 'add language in typescript source',
            widget: '_100554_aimTaskResultLanguageTypescript',
            ref: infoFile.fileName + '.ts',
            trace: [],
            _tempResult: result,
            nextStep
        });
    }
    prepareTaskPromptHTML(taskFinishResult) {
        const child = taskFinishResult.taskChild;
        const result = taskFinishResult.result || '';
        if (taskFinishResult.status === 'error') {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            return;
        }
        if (!result) {
            child.trace.push(new Date().toISOString() + ': no result find in task child');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        child.mode = 'processed';
        const args = JSON.parse(result);
        taskFinishResult.taskRoot.args = JSON.stringify(args);
        if (!args.checkHtml) {
            child.trace.push(new Date().toISOString() + ': no html avaliable to add language');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
            mode: 'initializing',
            title: 'exec prompt',
            widget: '_100554_aimTaskExecLLM',
            ref: child.ref + '.ts',
            agent: this.assistant,
            prompt: this.getPromptHTML(args.html, args.attributesHTMLWithLanguages, args.languages),
            trace: [],
            nextStep: this.prepareTaskResultHTML.name // danger, loop
        });
    }
    prepareTaskResultHTML(taskFinishResult) {
        const child = taskFinishResult.taskChild;
        const result = child.result || '';
        if (taskFinishResult.status === 'error') {
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            return;
        }
        if (!taskFinishResult.taskRoot.args) {
            child.trace.push(new Date().toISOString() + ': taskroot args is missing');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        if (!child.result) {
            child.trace.push(new Date().toISOString() + ': no result in task');
            this.mode = taskFinishResult.taskRoot.mode = child.mode = 'error';
            this.requestUpdate();
            return;
        }
        const infoFile = JSON.parse(taskFinishResult.taskRoot.args);
        child.mode = 'processed';
        this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
            mode: 'initializing',
            title: 'add language in html source',
            widget: '_100554_aimTaskResultLanguageHtml',
            ref: infoFile.fileName,
            trace: [],
            _tempResult: result,
            nextStep: this.endTasks.name
        });
    }
    endTasks(taskFinishResult) {
        const child = taskFinishResult.taskChild;
        if (taskFinishResult.status === 'error')
            child.mode = 'error';
        else
            child.mode = 'processed';
        this.mode = taskFinishResult.taskRoot.mode = child.mode;
        this.requestUpdate();
        updateTaskOnServer(taskFinishResult.taskIndex);
    }
};
__decorate([
    property({ type: String })
], AimActionAddLanguage.prototype, "currentScenario", void 0);
__decorate([
    property({ type: Number })
], AimActionAddLanguage.prototype, "level", void 0);
__decorate([
    property({ type: Number })
], AimActionAddLanguage.prototype, "height", void 0);
__decorate([
    property({ type: Array })
], AimActionAddLanguage.prototype, "widgets", void 0);
__decorate([
    property({ type: Array })
], AimActionAddLanguage.prototype, "languages", void 0);
__decorate([
    property({ type: Boolean })
], AimActionAddLanguage.prototype, "onlyLanguageDontConfigured", void 0);
AimActionAddLanguage = __decorate([
    customElement('aim-action-add-language-100554')
], AimActionAddLanguage);
export { AimActionAddLanguage };
