/// <mls shortName="pluginNewFilePage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { StateLitElement } from './_100554_stateLitElement';
import { getMessageKey } from "./_100554_collabLitElement";
import { propertyDataSource } from './_100554_collabDecorators';
import { createNewFile, changeTagName, changeClassName, changeWidget } from "./_100554_pluginNewFileBase";
import './_100554_wcCode';
/// **collab_i18n_start**
const message_pt = {
    title: 'Criar um arquivo de pagina.',
    description: "Criar um arquivo do tipo pagina. Na pagina sera possivel manipular o globalState e dos eventos da página.",
    project: "Projeto",
    shortName: "Nome",
    header: "Criar uma pagina",
    btnCreate: 'Criar arquivo',
    loading: 'Criando arquivo...',
    error: 'Nome do arquivo em branco ou invalido',
    errorPageName: 'O nome do arquivo deve começar com "page"',
};
const message_en = {
    title: 'Create a page file.',
    description: "Create a page file. In the page, it will be possible to manipulate the globalState and the page events.",
    project: "Project",
    shortName: "ShortName",
    header: "Create a page",
    btnCreate: 'Create file',
    loading: 'Creating File...',
    error: 'Blank or invalid file name',
    errorPageName: 'File name must start with "page"',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
let msg = messages[lang];
export const details = {
    title: msg.title,
    description: msg.description,
    tags: ["lit", "html", "page"],
};
let PluginNewFilePage = class PluginNewFilePage extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file-page-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-new-file-page-100554 wc-code-100554{font-size:var(--font-size-12)}plugin-new-file-page-100554 button{background-color:var(--active-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#fff;cursor:pointer}plugin-new-file-page-100554 button:hover{background-color:var(--active-color-hover)}`);
        this.position = 'left';
        this.loading = false;
        this.service = this.closest('service-detail-100554');
        this.template = `
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState } from './_100554_collabState';

 @customElement('[tagName]')
 export class [className] extends CollabPageElement {

     initPage() {
          globalState._ica = {
             tables: {
                 sex: [{ key: 'm', value: 'masculino' }, { key: 'f', value: 'feminino' }],
             },
             newUser: {
                 name: '',
                 age: 0,
                 city: '',
                 sex: ''
             },
             sum: 0,
         };
     }

 }`;
        this.enhancement = `_100554_enhancementLit`;
        this.groupName = `other`;
    }
    getTemplateTS() {
        let newExample = this.template;
        if (this.shortName && this.project) {
            newExample = changeTagName(newExample, convertFileNameToTag(`_${this.project}_${this.shortName}`));
            newExample = changeClassName(newExample, this.project, this.shortName);
            newExample = changeWidget(newExample, this.project, this.shortName);
        }
        return `/// <mls shortName="${this.shortName}" project="${this.project}" enhancement="${this.enhancement}" groupName="${this.groupName}" />\n${newExample}\n`;
        ;
    }
    getTemplateHTML() {
        const tagName = convertFileNameToTag(`_${this.project}_${this.shortName}`);
        return `<${tagName} modeoverlay="wcd-overlay-mode-default-100554">\n\t<ica-layout-flow-section-100554 id="section1" class="inset" widget="wc-section-100554">
		\n\t\t<ica-apresentation-text-text-100554 id="apText1" widget="wc-text-100554" text="In development" type="h2">
		</ica-apresentation-text-text-100554>
	\n\t</ica-layout-flow-section-100554>
</${tagName}>`;
    }
    async handleAddFile() {
        if (!this.project || !this.shortName) {
            this.service.setError(msg.error);
            return;
        }
        ;
        if (!this.shortName.startsWith('page')) {
            this.service.setError(msg.errorPageName);
            return;
        }
        this.loading = true;
        try {
            await createNewFile({
                project: this.project,
                position: this.position,
                shortName: this.shortName,
                enhancement: this.enhancement,
                sourceTS: this.getTemplateTS(),
                sourceHTML: this.getTemplateHTML(),
                openPreview: true
            });
        }
        catch (e) {
            this.loading = false;
        }
    }
    render() {
        return html `
            ${this.loading ?
            html `<div>${msg.loading}</div>`
            :
                html `   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>

                    <wc-code-100554 language="typescript" text="${this.getTemplateTS()}"></wc-code-100554>
                    <wc-code-100554 language="html" text="${this.getTemplateHTML()}"></wc-code-100554>

                
                </div>`}
        `;
    }
};
__decorate([
    propertyDataSource()
], PluginNewFilePage.prototype, "shortName", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "project", void 0);
__decorate([
    property()
], PluginNewFilePage.prototype, "position", void 0);
__decorate([
    property()
], PluginNewFilePage.prototype, "loading", void 0);
PluginNewFilePage = __decorate([
    customElement('plugin-new-file-page-100554')
], PluginNewFilePage);
export { PluginNewFilePage };
