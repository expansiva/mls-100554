/// <mls shortName="widgetDefaultText" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyCompositeDataSource } from './_100554_collabDecorators';
import { IcaApresentationTextBase } from './_100554_icaApresentationTextBase';
/**
 * Componente para exibir texto simples, podendo ser texto fixo ou dinâmico.
 * Suporta variações de apresentação: texto, citação (quote) e banner.
 */
let WidgetDefaultText = class WidgetDefaultText extends IcaApresentationTextBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`widget-default-text-100554{font-family:var(--font-family-primary);color:var(--text-primary-color);font-size:var(--font-size-16);line-height:var(--line-height-large)}widget-default-text-100554 .text-content{color:var(--text-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);word-break:break-word}widget-default-text-100554 .text-link{color:var(--link-color);text-decoration:underline}widget-default-text-100554 .text-link:hover{color:var(--link-color-hover)}widget-default-text-100554 .text-link:focus{color:var(--link-color-focus)}widget-default-text-100554 .quote-block{border-left:4px solid var(--text-secondary-color);background:var(--bg-secondary-color-lighter);color:var(--text-primary-color-darker);margin:var(--space-16) 0;padding:var(--space-16) var(--space-24);font-style:italic}widget-default-text-100554 .quote-block .quote-text{display:block;margin-bottom:var(--space-8)}widget-default-text-100554 .quote-block .quote-footer{font-size:var(--font-size-12);color:var(--text-secondary-color-darker)}widget-default-text-100554 .quote-block .quote-footer a{color:var(--link-color);text-decoration:underline}widget-default-text-100554 .banner-content{display:flex;align-items:center;background:var(--bg-secondary-color);border-radius:var(--space-8);padding:var(--space-16)}widget-default-text-100554 .banner-content .banner-img{width:120px;height:60px;object-fit:cover;border-radius:var(--space-8);margin-right:var(--space-16)}widget-default-text-100554 .banner-content .banner-text{color:var(--text-primary-color);font-size:var(--font-size-16);font-weight:var(--font-weight-bold)}widget-default-text-100554 .banner-link{text-decoration:none}widget-default-text-100554 .banner-link:hover .banner-text{color:var(--link-color-hover)}`);
    }
    render() {
        const cfg = this.config || { type: 'text' };
        const multiline = cfg.multiline ?? false;
        const textContent = this.text || '';
        if (cfg.type === 'banner' && cfg.src) {
            const img = html `<img class="banner-img" src="${cfg.src}" alt="${cfg.alt || ''}" />`;
            const content = html `
        <div class="banner-content">
          ${img}
          ${textContent ? html `<span class="banner-text">${multiline ? textContent.split('\n').map(line => html `<span>${line}</span><br />`) : textContent}</span>` : ''}
        </div>
      `;
            return cfg.href ? html `<a class="banner-link" href="${cfg.href}" target="${ifDefined(cfg.target)}" rel="noopener noreferrer">${content}</a>` : content;
        }
        if (cfg.type === 'quote') {
            return html `
        <blockquote class="quote-block">
          <span class="quote-text">${multiline ? textContent.split('\n').map(line => html `<span>${line}</span><br />`) : textContent}</span>
          ${cfg.cite ? html `
            <footer class="quote-footer">
              ${cfg.citeHref ? html `<a href="${cfg.citeHref}" target="_blank" rel="noopener noreferrer">${cfg.cite}</a>` : cfg.cite}
            </footer>
          ` : ''}
        </blockquote>
      `;
        }
        // type: text (default)
        const inner = multiline ? textContent.split('\n').map(line => html `<span>${line}</span><br />`) : textContent;
        const textEl = html `<span class="text-content">${inner}</span>`;
        return cfg.href ? html `<a class="text-link" href="${cfg.href}" target="${ifDefined(cfg.target)}" rel="noopener noreferrer">${textEl}</a>` : textEl;
    }
};
__decorate([
    propertyCompositeDataSource({ type: String })
], WidgetDefaultText.prototype, "text", void 0);
__decorate([
    propertyCompositeDataSource({ type: Object })
], WidgetDefaultText.prototype, "config", void 0);
WidgetDefaultText = __decorate([
    customElement('widget-default-text-100554')
], WidgetDefaultText);
export { WidgetDefaultText };
