/// <mls shortName="serviceProduct" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import './_100554_pluginGithubL4Project';
import './_100554_pluginGithubL4Issues';
let ServiceWorkspace100554 = class ServiceWorkspace100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.msize = '';
        this.activeTab = 'ITasks';
        //----------SERVICE--------------------
        this.details = {
            icon: '&#xf6ff',
            state: 'foreground',
            position: 'left',
            tooltip: 'Product',
            visible: true,
            widget: '_100554_serviceProduct',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            this.activeTab = op;
        };
        this.menu = {
            title: '',
            actions: {},
            icons: {
                IRequirements: 'Requirements;f0a6',
            },
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            iconDefault: 'IRequirements',
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
            getLastMode: undefined,
            updateTitle: undefined
        };
        //----------IMPLEMENTS------------------
    }
    onServiceClick(visible, reinit, el) {
    }
    //------------COMPONENT-----------------
    firstUpdated() {
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.visible)
            return;
        const [w, h] = this.msize.split(',');
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'IRequirements':
                return this.renderRequirements();
            default:
                return html ``;
        }
    }
    renderRequirements() {
        return html `
        <plugin-github-l4-issues-100554 labelfilter="feature request">
        </plugin-github-l4-issues-100554>`;
    }
};
ServiceWorkspace100554.styles = css ``;
__decorate([
    property()
], ServiceWorkspace100554.prototype, "msize", void 0);
__decorate([
    property()
], ServiceWorkspace100554.prototype, "activeTab", void 0);
ServiceWorkspace100554 = __decorate([
    customElement('service-product-100554')
], ServiceWorkspace100554);
export { ServiceWorkspace100554 };
