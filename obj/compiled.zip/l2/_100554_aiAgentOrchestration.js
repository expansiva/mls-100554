/// <mls shortName="aiAgentOrchestration" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { argsValidator, calculateStepsByFilter, updateStepStatus, calculateStepsStatistics, getInteractionStepId, getNextPendentStep, safeParseArgs, appendLongTermMemory, getStepById, getUserIdLocalStorage, notifyTaskChange, dispatchDetailsTaskClose, updateTaskTitle, getNextStepIdAvaliable, } from "./_100554_aiAgentHelper";
import { getTask, getMessage } from "./_100554_msgDBController";
import { loadModuleFromProjectOrDependency } from './_100554_libCommom';
export async function startNewAiTask(agentName, taskTitle, userMessage, threadId, userId, inputAI, context, afterPrompt, longTermMemory) {
    try {
        const args = {
            action: "addMessageAI",
            threadId,
            userId,
            taskTitle,
            userMessage,
            agentName,
            inputAI,
        };
        const oldContextCreateAt = context.message.createAt;
        const value = await mls.api.msgAddMessageAI(args);
        if (!value)
            throw new Error("Error on return addMessageAI, no return");
        if (value.statusCode !== 200)
            throw new Error("Error on addMessageAI: " + (value.msg || ''));
        const ret = value;
        context.task = ret.task;
        if (context.task.iaCompressed) {
            context.task.iaCompressed.modeSingleStep = context.modeSingleStep;
        }
        context.message = ret.message;
        notifyTaskChange(context, oldContextCreateAt);
        if (mls.istraceAgent)
            console.log(JSON.stringify(context, null, 2));
        if (longTermMemory)
            await appendLongTermMemory(context, longTermMemory);
        await afterPrompt(context);
    }
    catch (error) {
        if (context && context.task && 1) {
            const msg = 'Error: ' + error.message || 'addNewStep ';
            context.task = await updateTaskTitle(context.task, msg.substring(0, 100));
            await setFailedStatus(context, 1);
            const step = getNextPendentStep(context.task);
            if (step)
                setFailedStatus(context, step.stepId);
        }
        throw new Error(`[startNewAiTask] ${error.message || error}`);
    }
}
export async function startNewInteractionInAiTask(agentName, taskTitle, inputAI, context, afterPrompt, stepFather) {
    try {
        if (!context || !context.message || !context.task)
            throw new Error("Invalid context");
        if (!agentName)
            throw new Error("addNewInteractionInAiTask: agentName is null");
        if (!context.task.messageid_created)
            throw new Error("addNewInteractionInAiTask: context.task.messageid_created is null");
        const args = {
            action: "addTaskAIInteraction",
            userId: getUserIdLocalStorage() || context.task.owner,
            messageId: context.task.messageid_created,
            taskId: context.task.PK,
            parentStepId: stepFather,
            inputAI
        };
        const value = await mls.api.msgAddTaskAIInteraction(args);
        if (!value) {
            throw new Error("Error on return addTaskAIInteraction, no return");
        }
        if (value.statusCode !== 200) {
            throw new Error("Error on addTaskAIInteraction: " + (value.msg || ''));
        }
        const ret = value;
        context.task = ret.task;
        if (context.task.iaCompressed) {
            context.task.iaCompressed.modeSingleStep = context.modeSingleStep;
        }
        notifyTaskChange(context);
        if (mls.istraceAgent)
            console.log(JSON.stringify(context, null, 2));
        await afterPrompt(context);
    }
    catch (error) {
        if (context && context.task && stepFather) {
            const msg = 'Error: ' + error.message || 'startNewInteractionInAiTask ';
            context.task = await updateTaskTitle(context.task, msg.substring(0, 100));
            await setFailedStatus(context, stepFather);
            const step = getNextPendentStep(context.task);
            if (step)
                setFailedStatus(context, step.stepId);
        }
        console.error(`[startNewInteractionInAiTask] ${error.message || error}`);
    }
}
export async function addNewStep(context, parentStepId, steps, newTaskTitle = "Pending") {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    if (!context.task.messageid_created)
        throw new Error("addNewInteractionInAiTask: context.task.messageid_created is null");
    try {
        const response = await mls.api.msgAddTaskAISteps({
            userId: getUserIdLocalStorage() || context.message.senderId,
            parentStepId,
            steps,
            taskId: context.task.PK,
            messageId: context.task.messageid_created,
            newStatus: 'completed',
            newTaskTitle,
            stepdIdToChangeStatus: parentStepId,
            traceMsg: 'adding new step'
        });
        context.task = response.task;
        // context.task = await updateStepStatus(context.task, parentStep, "completed");
        notifyTaskChange(context);
        executeNextStep(context);
    }
    catch (error) {
        if (context && context.task && parentStepId) {
            const msg = 'Error: ' + error.message || 'addNewStep ';
            context.task = await updateTaskTitle(context.task, msg.substring(0, 100));
            setFailedStatus(context, parentStepId);
        }
        console.error(`[startNewInteractionInAiTask] ${error.message || error}`);
    }
}
const maxCostByTask = 1.01; // 1.01 USD
const maxStepsByTask = 100;
export async function executeNextStep(context) {
    if (!context || !context.message || !context.task || !context.task.iaCompressed)
        throw new Error("Invalid context");
    if (context.task.status === "paused" || context.task.status === "done" || context.modeSingleStep === true)
        return;
    const step = getNextPendentStep(context.task);
    if (!step) {
        console.error("finished all steps");
        return;
    }
    const { totalCost, totalSteps } = calculateStepsStatistics(context.task.iaCompressed.nextSteps, false);
    if (totalCost > maxCostByTask) {
        console.error("max cost reached");
        return;
    }
    if (totalSteps > maxStepsByTask) {
        console.error("max steps reached");
        return;
    }
    switch (step.type) {
        case "agent": return executeNextAgent(context, step);
        case "tool":
            const st = step;
            const totalSimilarTools = calculateStepsByFilter(context.task, { toolName: st.toolName, args: st.args });
            if (totalSimilarTools > 1) {
                console.error("max similar tools reached");
                return;
            }
            return executeNextTool(context, step);
        case "clarification": return executeNextClarification(context, step);
        case "result": return executeNextResult(context, step);
        case "flexible": return executeNextFlexible(context, step);
        default:
            throw new Error(`Unknown step type: ${step.type}`);
    }
}
async function executeNextTool(context, step) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    const rc = await executeTool(step.toolName, step.args);
    if (rc.status !== true) {
        const traceMsg = `Error executing tool ${step.toolName}: ${rc.error}`;
        console.error(traceMsg);
        context = await updateStepStatus(context, step.stepId, "failed", traceMsg);
        if (mls.istraceAgent)
            console.log(JSON.stringify(context.task, null, 2));
        return;
    }
    if (typeof rc.result !== "string")
        throw new Error(`Tool ${step.toolName} did not return a string`);
    const existResults = rc.result.length > 0;
    if (existResults) {
        const interactionStepId = getInteractionStepId(context.task, step.stepId);
        if (!interactionStepId)
            throw new Error(`[executeNextTool] Interaction step not found for stepId ${step.stepId}`);
        const stepdIdToChangeStatus = step.stepId;
        if (!interactionStepId)
            throw new Error(`[executeNextTool] Interaction step not found for stepId ${step.stepId}`);
        const stepInteraction = getStepById(context.task, interactionStepId);
        if (!stepInteraction || stepInteraction.type !== 'agent')
            throw new Error('Interaction must be type: agent');
        const oldPrompt = stepInteraction.interaction?.input.find((item) => item.type === 'human');
        const newStep = {
            type: 'agent',
            agentName: stepInteraction.agentName,
            prompt: `${oldPrompt?.content} \n\n Response from tool ${step.toolName}: ${rc.result}`,
            status: 'pending',
            stepId: getNextStepIdAvaliable(context.task),
            interaction: null,
            nextSteps: null,
            rags: null
        };
        if (mls.istraceAgent)
            console.log(JSON.stringify(context.task, null, 2));
        return await addNewStep(context, stepdIdToChangeStatus, [newStep]);
    }
    return executeNextStep(context);
}
export async function executeTool(toolName, args) {
    const rc = {
        status: false,
        error: "",
        result: []
    };
    if (!toolName) {
        rc.error = "Tool name is missing";
        return rc;
    }
    ;
    try {
        /*//const fileJS = `./${toolName}.js`;
        const fileJS = `./_100554_${toolName}`;
        const module = await import(fileJS);
        if (typeof module.createTool !== "function") throw new Error(`createTool function not found in ${fileJS}`);
        const tool = module.createTool();*/
        const tool = await loadTool(toolName);
        if (!args) {
            // no args provided
            argsValidator({}, tool.argsSchema);
            rc.result = await tool.execute();
        }
        else {
            const parsedArgs = safeParseArgs(args);
            argsValidator(parsedArgs, tool.argsSchema);
            rc.result = await tool.execute(parsedArgs);
        }
        rc.status = true;
    }
    catch (error) {
        console.error(`[executeTool] ${error.message || error}`);
        rc.error = error.message || error;
    }
    return rc;
}
async function executeNextAgent(context, step) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    if (!step.agentName)
        throw new Error("Agent name is missing");
    try {
        const agent = await loadAgent(step.agentName);
        if (!agent)
            throw new Error(`createAgent function not found in ${mls.actual[5].project} ${step.agentName}`);
        await agent.beforePrompt(context);
    }
    catch (error) {
        const msg = 'Error: ' + error.message || 'beforePrompt ' + step.agentName;
        context.task = await updateTaskTitle(context.task, msg.substring(0, 100));
        setFailedStatus(context, step.stepId);
        console.error(`[executeNextAgent] ${error.message || error}`);
    }
}
export async function loadAgent(shortName) {
    try {
        const module = await loadModuleFromProjectOrDependency(shortName, '', '.ts');
        if (typeof module.createAgent !== "function")
            throw new Error(`createAgent function not found in ${shortName}`);
        const agent = module.createAgent();
        if (typeof agent.beforePrompt !== "function")
            throw new Error(`beforePrompt function not found in ${shortName}`);
        if (typeof agent.afterPrompt !== "function")
            throw new Error(`afterPrompt function not found in ${shortName}`);
        return agent;
    }
    catch (error) {
        console.error(`[loadAgent] ${error.message || error}`);
        return undefined;
    }
}
export async function loadTool(shortName) {
    try {
        const module = await loadModuleFromProjectOrDependency(shortName, '', '.ts');
        if (typeof module.createTool !== "function")
            throw new Error(`createTool function not found in ${shortName}`);
        const tool = module.createTool();
        return tool;
    }
    catch (error) {
        console.error(`[loadTool] ${error.message || error}`);
        return undefined;
    }
}
async function executeAgentFunction(context, step, functionName, stepId, args) {
    if (!context || !context.task)
        throw new Error("[executeAgentFunction] Invalid context");
    if (!step.agentName)
        throw new Error("[executeAgentFunction] Agent name is missing");
    try {
        /*//const fileJS = `./${step.agentName}.js`;
        const fileJS = `./_100554_${step.agentName}`;
        const module = await import(fileJS);
        if (typeof module.createAgent !== "function") throw new Error(`[executeAgentFunction] createAgent function not found in ${fileJS}`);
        const agent = module.createAgent();*/
        const agent = await loadAgent(step.agentName);
        if (typeof agent[functionName] !== "function")
            throw new Error(`[executeAgentFunction] ${functionName} function not found in ${step.agentName}`);
        return await agent[functionName](context, stepId, args);
    }
    catch (error) {
        console.error(`[executeAgentFunction] ${error.message || error}`);
    }
}
async function executeNextResult(context, step) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    if (mls.istraceAgent)
        console.log("result:", step.result);
    context = await updateStepStatus(context, step.stepId, "completed");
    notifyTaskChange(context);
    return executeNextStep(context);
}
async function executeNextFlexible(context, step) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    if (mls.istraceAgent)
        console.log("Flexible:", step.result);
    context = await updateStepStatus(context, step.stepId, "completed");
    notifyTaskChange(context);
    return executeNextStep(context);
}
async function executeNextClarification(context, step) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    // if (!step.clarificationMessage) throw new Error("clarification message is missing");
    // notifyTaskChange(context);
    // if ((mls as any).istraceAgent) console.log("clarification:", step.clarificationMessage);
    // context.task = await updateStepStatus(context.task, step.stepId, "waiting_for_user");
}
export async function getAgentContext(taskId) {
    const task = await getTask(taskId);
    if (!task || !task.messageid_created)
        throw new Error("[getAgentContext] Invalid taskId" + taskId);
    const step = getNextPendentStep(task);
    if (!step)
        throw new Error("[getAgentContext] No pending step");
    if (step.type !== "clarification" && step.type !== "tool")
        throw new Error("[getAgentContext] No pending clarification or tool step");
    const interactionId = getInteractionStepId(task, step.stepId);
    if (!interactionId)
        throw new Error("[getAgentContext] Not found interactionId in pending step");
    const interaction = getStepById(task, interactionId);
    if (!interaction || interaction.type !== "agent")
        throw new Error("[getAgentContext] Clarification or tool step not bellow a agent");
    //const messageId: string = task.messageid_created.split("/")[1].trim();
    // const parts = task.messageid_created.split("/");
    // const messageId: string = `${parts[1].trim()}[${parts[0].trim()}]`;
    const messageId = task.messageid_created;
    const message = await getMessage(messageId);
    if (!message)
        throw new Error("[getAgentContext] Message not found:" + messageId);
    const context = {
        message,
        task,
        modeSingleStep: task.iaCompressed?.modeSingleStep || undefined
    };
    return { context, interaction, step };
}
export async function getClarification(taskId) {
    const ret = await getAgentContext(taskId);
    if (ret.step.type !== "clarification")
        throw new Error("[getClarification] Clarification step not not found");
    return await executeAgentFunction(ret.context, ret.interaction, "beforeClarification", ret.step.stepId);
}
export async function postBackClarification(action, clarification) {
    if (typeof clarification !== "object" ||
        !clarification)
        throw new Error("[postBackClarification] Invalid call arguments");
    function findTaskId(obj) {
        if (typeof obj !== "object" || obj === null)
            return null;
        if ("taskId" in obj && typeof obj.taskId === "string")
            return obj.taskId;
        for (const key in obj) {
            const result = findTaskId(obj[key]);
            if (result)
                return result;
        }
        return null;
    }
    const taskId = findTaskId(clarification);
    if (!taskId)
        throw new Error("[postBackClarification] Invalid call arguments, no taskId");
    const ret = await getAgentContext(taskId);
    if (action === "cancel") {
        const messageId = ret.context.task?.messageid_created;
        if (!messageId)
            throw new Error("[postBackClarification] Invalid messageId");
        const resp = await mls.api.msgUpdateStepStatus({
            messageId,
            status: "failed",
            stepId: ret.step.stepId,
            taskId,
            userId: getUserIdLocalStorage() || ret.context.message.senderId,
            traceMsg: "user cancel the task"
        });
        ret.context.task = resp.task;
        await notifyTaskChange(ret.context);
        dispatchDetailsTaskClose();
        return;
    }
    if (ret.step.type !== "clarification")
        throw new Error("[getClarification] Clarification step not not found");
    dispatchDetailsTaskClose();
    return await executeAgentFunction(ret.context, ret.interaction, "afterClarification", ret.step.stepId, clarification);
}
export async function startClarification(context, stepId, modeReadOnly) {
    // called after agent . beforeClarification
    if (!context.task)
        throw new Error("[startClarification] Invalid context.task");
    const step = getStepById(context.task, stepId);
    if (!step || step.type !== "clarification")
        throw new Error(`[startClarification] Invalid step: ${stepId} on task: ${context.task.PK}`);
    let clarification;
    try {
        let ret = step.json;
        if (typeof step.json === "string")
            ret = JSON.parse(step.json || '');
        clarification = {
            taskId: context.task.PK,
            stepId,
            title: ret.title,
            legends: ret.legends || [],
            userLanguage: ret.userLanguage || '',
            questions: ret.questions
        };
    }
    catch (e) {
        console.error(e);
        throw new Error(`[startClarification] Invalid step: ${stepId} on task: ${context.task.PK}, json clarification invalid`);
    }
    const div = document.createElement('div');
    const clariEl = document.createElement('widget-questions-for-clarification-100554');
    clariEl.value = clarification;
    if (modeReadOnly === true)
        clariEl.setAttribute("readonly", "true");
    div.appendChild(clariEl);
    return div;
}
export async function endClarification(clarification, action) {
    // called after press button cancel or continue on clarification
    // call agent afterClarification
    const taskId = clarification.taskId || '';
    if (!taskId)
        throw new Error("[startClarification] Invalid call arguments, no taskId");
    const ret = await getAgentContext(taskId);
    if (ret.step.type !== "clarification")
        throw new Error("[getClarification] Clarification step not not found");
    dispatchDetailsTaskClose();
    if (action === "continue") {
        await executeAgentFunction(ret.context, ret.interaction, "afterClarification", clarification.stepId, clarification);
        return;
    }
    // cancel the task
    const messageId = ret.context.task?.messageid_created;
    if (!messageId)
        throw new Error("[postBackClarification] Invalid messageId");
    const resp = await mls.api.msgUpdateStepStatus({
        messageId,
        status: "failed",
        stepId: ret.step.stepId,
        taskId,
        userId: getUserIdLocalStorage() || ret.context.message.senderId,
        traceMsg: "user cancel the task",
        newTaskStatus: 'failed',
        newTaskTitle: "User canceled task"
    });
    ret.context.task = resp.task;
    notifyTaskChange(ret.context);
}
export function toLLMClarification(value) {
    // remove unnecessary values
    return {
        title: value.title,
        userLanguage: value.userLanguage,
        questions: Object.fromEntries(Object.entries(value.questions).map(([key, q]) => [
            key,
            {
                type: q.type,
                question: q.question,
                answer: q.answer
            }
        ]))
    };
}
async function setFailedStatus(context, step) {
    if (!context.task)
        throw new Error("[setFailedStatus] Invalid context task");
    context = await updateStepStatus(context, step, "failed");
    notifyTaskChange(context);
}
