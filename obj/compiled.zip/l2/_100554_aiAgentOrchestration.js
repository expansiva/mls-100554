/// <mls shortName="aiAgentOrchestration" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import * as helper from "./_100554_aiAgentHelper";
export async function startNewAiTask(agentName, taskTitle, userMessage, threadId, userId, inputAI, afterPrompt) {
    try {
        const args = {
            action: "addMessageAI",
            threadId,
            userId,
            taskTitle,
            userMessage,
            agentName,
            inputAI,
        };
        const value = await mls.api.msgAddMessageAI(args);
        if (!value) {
            throw new Error("Error on return addMessageAI, no return");
        }
        if (value.statusCode !== 200 /*mls.msg.StatusCodeOk*/) {
            throw new Error("Error on addMessageAI: " + (value.msg || ''));
        }
        const ret = value;
        const context = {
            message: ret.message,
            task: ret.task
        };
        console.log(JSON.stringify(context, null, 2));
        await afterPrompt(context, userId, threadId);
    }
    catch (error) {
        console.error(`[startNewAiTask] ${error.message || error}`);
    }
}
export async function startNewInteractionInAiTask(agentName, taskTitle, inputAI, context, afterPrompt) {
    try {
        if (!context || !context.message || !context.task)
            throw new Error("Invalid context");
        if (!agentName)
            throw new Error("addNewInteractionInAiTask: agentName is null");
        if (!context.task.messageid_created)
            throw new Error("addNewInteractionInAiTask: context.task.messageid_created is null");
        const args = {
            action: "addTaskAIInteraction",
            userId: context.task.owner,
            messageId: context.task.messageid_created,
            taskId: context.task.PK,
            parentStepId: 0,
            inputAI
        };
        const value = await mls.api.msgAddTaskAIInteraction(args);
        if (!value) {
            throw new Error("Error on return addTaskAIInteraction, no return");
        }
        if (value.statusCode !== 200 /*mls.msg.StatusCodeOk*/) {
            throw new Error("Error on addTaskAIInteraction: " + (value.msg || ''));
        }
        const ret = value;
        context = {
            message: ret.message,
            task: ret.task
        };
        console.log(JSON.stringify(context, null, 2));
        if (!context.task || !context.task.owner)
            throw new Error("addNewInteractionInAiTask: context.task.owner is null");
        await afterPrompt(context, context.task.owner, '');
    }
    catch (error) {
        console.error(`[startNewInteractionInAiTask] ${error.message || error}`);
    }
}
const maxCostByTask = 1.01; // 1.01 USD
const maxStepsByTask = 100;
export async function executeNextStep(context, userId) {
    if (!context || !context.message || !context.task || !context.task.iaCompressed)
        throw new Error("Invalid context");
    if (context.task.status === "paused" || context.task.status === "done")
        return;
    const step = helper.getNextPendentStep(context.task);
    if (!step) {
        console.error("finished all steps");
        return;
    }
    const { totalCost, totalSteps } = helper.calculateStepsStatistics(context.task.iaCompressed.nextSteps, false);
    if (totalCost > maxCostByTask) {
        console.error("max cost reached");
        return;
    }
    if (totalSteps > maxStepsByTask) {
        console.error("max steps reached");
        return;
    }
    switch (step.type) {
        case "agent": return executeNextAgent(context, step);
        case "tool": return executeNextTool(context, step, userId);
        case "clarification": return executeNextClarification(context, step, userId);
        case "result": return executeNextResult(context, step, userId);
        case "flexible":
            // flexible step type must be processed by the agent
            throw new Error(`Flexible step type is not supported: ${JSON.stringify(step)}`);
        default:
            throw new Error(`Unknown step type: ${step.type}`);
    }
}
async function executeNextTool(context, step, userId) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    const rc = await executeTool(step.toolName, step.args);
    if (rc.status !== true) {
        console.error(`Error executing tool ${step.toolName}: ${rc.error}`);
        const args = {
            action: 'updateStepStatus',
            status: "failed",
            taskId: context.task.PK,
            messageId: context.task.messageid_created || '',
            stepId: step.stepId,
            userId
        };
        //context.task = await mls.api.msgUpdateStepStatus(context.task, step.stepId, "failed");
        context.task = (await mls.api.msgUpdateStepStatus(args)).task;
        return;
    }
    const args = {
        action: 'updateStepStatus',
        status: "completed",
        taskId: context.task.PK,
        messageId: context.task.messageid_created || '',
        stepId: step.stepId,
        userId
    };
    //context.task = await updateStepStatus(context.task, step.stepId, "completed");
    context.task = (await mls.api.msgUpdateStepStatus(args)).task;
    if (rc.result.length > 0) {
        // todo: put content in memory
    }
    return executeNextStep(context, userId);
}
export async function executeTool(toolName, args) {
    const rc = {
        status: false,
        error: "",
        result: []
    };
    if (!toolName) {
        rc.error = "Tool name is missing";
        return rc;
    }
    ;
    try {
        const fileJS = `./${toolName}.js`;
        const module = await import(fileJS);
        if (typeof module.createTool !== "function")
            throw new Error(`createTool function not found in ${fileJS}`);
        const tool = module.createTool();
        if (!args) {
            // no args provided
            helper.argsValidator({}, tool.argsSchema);
            rc.result = await tool.execute();
        }
        else {
            const parsedArgs = helper.safeParseArgs(args);
            helper.argsValidator(parsedArgs, tool.argsSchema);
            rc.result = await tool.execute(parsedArgs);
        }
        rc.status = true;
    }
    catch (error) {
        console.error(`[executeTool] ${error.message || error}`);
        rc.error = error.message || error;
    }
    return rc;
}
async function executeNextAgent(context, step) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    if (!step.agentName)
        throw new Error("Agent name is missing");
    try {
        const fileJS = `./${step.agentName}.js`;
        const module = await import(fileJS);
        if (typeof module.createAgent !== "function")
            throw new Error(`createAgent function not found in ${fileJS}`);
        const agent = module.createAgent();
        if (typeof agent.beforePrompt !== "function")
            throw new Error(`beforePrompt function not found in ${fileJS}`);
        if (typeof agent.afterPrompt !== "function")
            throw new Error(`afterPrompt function not found in ${fileJS}`);
        await agent.beforePrompt(context);
    }
    catch (error) {
        console.error(`[executeNextAgent] ${error.message || error}`);
    }
}
async function executeNextResult(context, step, userId) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    console.log("result:", step.result);
    const args = {
        action: 'updateStepStatus',
        status: "completed",
        taskId: context.task.PK,
        messageId: context.task.messageid_created || '',
        stepId: step.stepId,
        userId
    };
    //context.task = await updateStepStatus(context.task, step.stepId, "completed");
    context.task = (await mls.api.msgUpdateStepStatus(args)).task;
    return executeNextStep(context, userId);
}
async function executeNextClarification(context, step, userId) {
    if (!context || !context.task)
        throw new Error("Invalid context");
    if (!step.clarificationMessage)
        throw new Error("clarification message is missing");
    console.log("clarification:", step.clarificationMessage);
    const args = {
        action: 'updateStepStatus',
        status: "waiting_for_user",
        taskId: context.task.PK,
        messageId: context.task.messageid_created || '',
        stepId: step.stepId,
        userId
    };
    //context.task = await updateStepStatus(context.task, step.stepId, "waiting_for_user");
    context.task = (await mls.api.msgUpdateStepStatus(args)).task;
}
