/// <mls shortName="wcdPopupItemH1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WCDPopupItem } from './_100554_wcdPopupItem';
let WCDPopupItemH1 = class WCDPopupItemH1 extends WCDPopupItem {
    getSvg() {
        return svg `
      <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
        <text x="3" y="17" font-size="18" font-weight="bold">H1</text>
      </svg>
    `;
    }
    render() {
        return html `
      <div @click=${this.handleClick} tabindex="-1">
      ${this.getSvg()}
      </div>
    `;
    }
    handleClick() {
        const selection = document.getSelection();
        if (selection && selection.rangeCount > 0) {
            const range = selection.getRangeAt(0);
            const selectedElement = range.commonAncestorContainer;
            const parentElement = this.findParentParagraphOrHeading(selectedElement);
            if (parentElement) {
                if (parentElement.tagName === 'H1') {
                    const p = document.createElement('p');
                    p.innerHTML = parentElement.innerHTML;
                    parentElement.parentNode?.replaceChild(p, parentElement);
                }
                else if (parentElement.tagName === 'P') {
                    const h1 = document.createElement('h1');
                    h1.innerHTML = parentElement.innerHTML;
                    parentElement.parentNode?.replaceChild(h1, parentElement);
                }
            }
        }
    }
    findParentParagraphOrHeading(element) {
        while (element && element.nodeType === Node.ELEMENT_NODE) {
            const tagName = element.tagName;
            if (tagName === 'P' || tagName === 'H1') {
                return element;
            }
            element = element.parentNode;
        }
        return null;
    }
};
WCDPopupItemH1 = __decorate([
    customElement('wcd-popup-item-h1-100554')
], WCDPopupItemH1);
export { WCDPopupItemH1 };
