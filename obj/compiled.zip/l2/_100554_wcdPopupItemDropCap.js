/// <mls shortName="wcdPopupItemDropCap" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WCDPopupItem } from './_100554_wcdPopupItem';
let WCDPopupItemDropCap = class WCDPopupItemDropCap extends WCDPopupItem {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    getSvg() {
        return svg `
      <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
        <text x="3" y="16" font-size="12" font-weight="bold">T</text>
        <line x1="12" y1="7" x2="20" y2="7" stroke="currentColor" stroke-width="1"/>
        <line x1="12" y1="11" x2="20" y2="11" stroke="currentColor" stroke-width="1"/>
        <line x1="12" y1="15" x2="20" y2="15" stroke="currentColor" stroke-width="1"/>
        <line x1="3" y1="20" x2="20" y2="20" stroke="currentColor" stroke-width="1"/>
      </svg>
    `;
    }
    render() {
        return html `
      <div @click=${this.handleClick} tabindex="-1">
      ${this.getSvg()}
      </div>
    `;
    }
    handleClick() {
        if (!window.wcdState.elMain)
            throw new Error('Invalid wcdState.elMain');
        if (!window.wcdState.elICA)
            throw new Error('Invalid wcdState.elICA');
        const wcdContent = window.wcdState.myParent?.querySelector('#edittextwcd');
        if (!wcdContent)
            throw new Error('Invalid wcdContent id: #edittextwcd');
        window.wcdState.elICA?.classList.toggle('dropcap');
        window.wcdState.elMain?.classList.toggle('dropcap');
        wcdContent.classList.toggle('dropcap');
    }
};
WCDPopupItemDropCap = __decorate([
    customElement('wcd-popup-item-drop-cap-100554')
], WCDPopupItemDropCap);
export { WCDPopupItemDropCap };
