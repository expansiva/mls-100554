/// <mls shortName="collabMessagesChangeAvatar" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import { StateLitElement } from './_100554_stateLitElement';
import { getTemporaryContext } from './_100554_aiAgentHelper';
/// **collab_i18n_start** 
const message_pt = {
    changeAvatar: "Alterar avatar",
    changeButton: "Trocar imagem",
    generateButton: "Gerar com IA",
    panelTitle: "Gerar Avatar com IA",
    generateLabel: "Descreva o avatar",
    generatePlaceholder: "Digite aqui sua descrição...",
    actionGenerate: "Gerar",
    saveButton: "Salvar",
    cancelButton: "Cancelar",
    generating: "Gerando..."
};
const message_en = {
    changeAvatar: "Change avatar",
    changeButton: "Change image",
    generateButton: "Generate with AI",
    panelTitle: "Generate Avatar with AI",
    generateLabel: "Describe the avatar",
    generatePlaceholder: "Type your description here...",
    actionGenerate: "Generate",
    saveButton: "Save",
    cancelButton: "Cancel",
    generating: "Generating..."
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabChangeAvatar = class CollabChangeAvatar extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-change-avatar-100554 .panel{border:1px solid #ddd;padding:12px;border-radius:6px;margin:8px 0}collab-messages-change-avatar-100554 .preview img,collab-messages-change-avatar-100554 .preview svg{width:80px;height:80px;border-radius:50%;object-fit:cover;border:1px solid #ccc;fill:currentColor}collab-messages-change-avatar-100554 textarea{width:100%;min-height:60px}collab-messages-change-avatar-100554 .avatar-section{display:flex;flex-direction:column;align-items:center}collab-messages-change-avatar-100554 .actions-avatar{display:flex;gap:1rem}collab-messages-change-avatar-100554 .actions-ia{margin-top:10px;display:flex;gap:10px;align-items:center}collab-messages-change-avatar-100554 input,collab-messages-change-avatar-100554 select,collab-messages-change-avatar-100554 textarea{width:100%;display:block;font-size:1rem;line-height:1.5;height:33px;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-messages-change-avatar-100554 input[disabled],collab-messages-change-avatar-100554 select[disabled],collab-messages-change-avatar-100554 textarea[disabled]{background-color:var(--grey-color-light)}collab-messages-change-avatar-100554 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer;max-width:200px;text-overflow:ellipsis;white-space:nowrap}collab-messages-change-avatar-100554 button:hover{background-color:var(--info-color-hover)}collab-messages-change-avatar-100554 .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #000;border-radius:50%;animation:spin 1s linear infinite}collab-messages-change-avatar-100554 .upload-wrapper{position:relative;display:inline-block}collab-messages-change-avatar-100554 .upload-btn{background-color:#007bff;color:#fff;border:none;padding:8px 14px;border-radius:4px;cursor:pointer;font-size:14px;transition:background-color .2s ease}collab-messages-change-avatar-100554 .upload-btn:hover{background-color:#0056b3}collab-messages-change-avatar-100554 .hidden-file-input{display:none}@keyframes spin{to{transform:rotate(360deg)}}`);
        this.msg = messages['en'];
        this.defaultImage = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">\x3C!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z"></path></svg>`;
        this.userId = "20250417120841.1000";
        this.threadId = "20250825143728.1000";
        this.avatarPrompt = "";
        this.isOpen = false;
        this.generating = false;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.preview = this.value || this.defaultImage;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
    <div class="avatar-section">
      <div class="preview">
        ${this.preview
            ? this.preview.startsWith("<svg")
                ? html `${this.safeSvg(this.preview)}`
                : html `<img src="${this.preview}" alt="Avatar" />`
            : this.value
                ? this.value.startsWith("<svg")
                    ? html `${this.safeSvg(this.value)}`
                    : html `<img src="${this.value}" alt="Avatar" />`
                : html `<div class="placeholder">?</div>`}
      </div>

      <div class="actions-avatar">
        <a style="display:none"  href="#" class="btn" @click=${this.triggerFileInput}>${this.msg.changeButton}</a>
        <input 
          type="file" 
          accept="image/*" 
          class="hidden-file-input"
          @change=${this.onFileSelect}
        />

        <a href="#" class="btn" @click=${(e) => { e.preventDefault(); this.isOpen = true; }}>
          ${this.msg.generateButton}
        </a>
      </div>
    </div>

    ${this.isOpen ? html `
      <div class="panel">
        <h4>${this.msg.panelTitle}</h4>

        <label>${this.msg.generateLabel}</label>
        <textarea
          placeholder=${this.msg.generatePlaceholder}
          .value=${this.avatarPrompt}
          @input=${(e) => this.avatarPrompt = e.target.value}
        ></textarea>

        <div class="actions-ia">
          <button ?disabled=${this.generating} @click=${this.generateAvatarFromPrompt}>
            ${this.generating ? html `<span class="loader"></span>` : this.msg.actionGenerate}
          </button>
          <button @click=${() => this.isOpen = false}>${this.msg.cancelButton}</button>
        </div>
      </div>
    ` : ""}
  `;
    }
    onFileSelect(e) {
        const input = e.target;
        if (input.files && input.files[0]) {
            this.avatarFile = input.files[0];
            this.preview = URL.createObjectURL(this.avatarFile);
        }
    }
    triggerFileInput(e) {
        e.preventDefault();
        const input = this.querySelector(".hidden-file-input");
        input?.click();
    }
    async generateAvatarFromPrompt() {
        if (!this.avatarPrompt)
            return;
        this.generating = true;
        const agentName = '_100554_agentGenerateAvatarSvg';
        try {
            const moduleAgent = await import(`/${agentName}`);
            if (!moduleAgent?.createAgent || typeof moduleAgent.createAgent !== 'function') {
                throw new Error('Invalid agent');
            }
            const agent = moduleAgent.createAgent();
            const context = getTemporaryContext(this.threadId, this.userId, this.avatarPrompt);
            await agent.beforePrompt(context);
            if (context.task &&
                context.task.iaCompressed &&
                context.task.iaCompressed.nextSteps &&
                context.task.iaCompressed.nextSteps[0] &&
                context.task.iaCompressed.nextSteps[0].interaction &&
                context.task.iaCompressed.nextSteps[0].interaction.payload &&
                context.task.iaCompressed.nextSteps[0].interaction.payload[0]) {
                const svg = (context.task.iaCompressed?.nextSteps[0]?.interaction?.payload[0]).result;
                if (svg && typeof svg === 'string') {
                    this.preview = svg;
                    this.emitValueChanged(this.preview);
                }
            }
        }
        catch (err) {
            console.error("Erro ao gerar avatar via IA", err);
        }
        finally {
            this.generating = false;
        }
    }
    emitValueChanged(value) {
        this.dispatchEvent(new CustomEvent('value-changed', {
            detail: value,
            bubbles: true,
            composed: true
        }));
    }
    safeSvg(svg) {
        return html `${unsafeHTML(svg)}`;
    }
};
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "value", void 0);
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "userId", void 0);
__decorate([
    property({ type: String })
], CollabChangeAvatar.prototype, "threadId", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "avatarPrompt", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "avatarFile", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "isOpen", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "generating", void 0);
__decorate([
    state()
], CollabChangeAvatar.prototype, "preview", void 0);
CollabChangeAvatar = __decorate([
    customElement("collab-messages-change-avatar-100554")
], CollabChangeAvatar);
export { CollabChangeAvatar };
