/// <mls shortName="contentAccordion" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let ContentAccordion = class ContentAccordion extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`content-accordion-100554 .accordion{border-radius:8px;overflow:hidden;border:1px solid #e0e0e0;background:white}content-accordion-100554 .header{cursor:pointer;padding:14px 16px;background:#f9f9f9;border-bottom:1px solid #e0e0e0;transition:background .25s ease;font-weight:500;display:flex;justify-content:space-between;align-items:center;color:#333}content-accordion-100554 .header:hover{background:#f1f1f1}content-accordion-100554 .header[selected]{background:#e8eaf6;color:#3f51b5;font-weight:600}content-accordion-100554 .content{display:none;padding:14px 16px;color:#444;line-height:1.5;background:#fff}content-accordion-100554 .content[open]{display:block;animation:fadeIn .3s ease}@keyframes fadeIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}`);
        this.navItems = [];
        this.contentItems = [];
        this.selectedIndex = 0;
    }
    connectedCallback() {
        super.connectedCallback();
        const div = document.createElement('div');
        div.innerHTML = this.innerHTML;
        this.innerHTML = '';
        this.navItems = Array.from(div.querySelectorAll('nav-item'));
        this.contentItems = Array.from(div.querySelectorAll('content-item'));
    }
    render() {
        return html `
            <div class="accordion">
                ${this.navItems.map((item, i) => {
            const content = this.contentItems[i];
            return html `
                    <nav-item class="header" ?selected=${this.selectedIndex === i} @click=${() => this.toggle(i)}>
                        ${item.innerHTML}
                    </nav-item>
                    <content-item class="content" ?open=${this.selectedIndex === i}>
                        ${unsafeHTML(content?.innerHTML)}
                    </content-item>
                `;
        })}
            </div>
        `;
    }
    toggle(index) {
        this.selectedIndex = this.selectedIndex === index ? -1 : index;
    }
};
__decorate([
    property({ type: Number, reflect: true })
], ContentAccordion.prototype, "selectedIndex", void 0);
ContentAccordion = __decorate([
    customElement('content-accordion-100554')
], ContentAccordion);
export { ContentAccordion };
