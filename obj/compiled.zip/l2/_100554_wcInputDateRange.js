/// <mls shortName="wcInputDateRange" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
let WCInputDateRange = class WCInputDateRange extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-input-date-range-100554 .form-control-label{font-size:var(--font-size-16);color:var(--text-primary-color);font-family:var(--font-family-primary);margin-bottom:var(--space-8)}wc-input-date-range-100554 .input_container{display:flex;align-items:center;gap:var(--space-16)}@media (max-width:544px){wc-input-date-range-100554 .input_container{flex-direction:column}}wc-input-date-range-100554 .input_control{padding:var(--space-8);border:1px solid var(--grey-color);border-radius:var(--space-8);font-size:var(--font-size-16);outline:none;transition:border var(--transition-normal) ease-in-out}wc-input-date-range-100554 .input_control:focus{border-color:var(--text-secondary-color)}wc-input-date-range-100554 .input_control.initial,wc-input-date-range-100554 .input_control.final{width:100%}wc-input-date-range-100554 .divider_textl{font-size:var(--font-size-16);color:var(--text-primary-color-lighter)}wc-input-date-range-100554 .form_hint{font-size:var(--font-size-12);color:var(--text-secondary-color);margin-top:var(--space-8)}wc-input-date-range-100554 .form_error_message{font-size:var(--font-size-12);color:var(--error-color);margin-top:var(--space-8)}wc-input-date-range-100554.neumorphism .input_control{background:var(--bg-primary-color);border:none;box-shadow:8px 8px 16px #d1d1d1,-8px -8px 16px #ffffff}wc-input-date-range-100554.neumorphism .input_control:focus{box-shadow:inset 8px 8px 16px #d1d1d1,inset -8px -8px 16px #ffffff}wc-input-date-range-100554.animation .input_control{transition:box-shadow var(--transition-fast),transform var(--transition-fast)}wc-input-date-range-100554.animation .input_control:hover{box-shadow:0 5px 15px rgba(0,0,0,0.2);transform:scale(1.02)}wc-input-date-range-100554.animation .input_control:focus{transform:scale(1.02)}`);
        this.name = '';
        this.label = '';
        this.widget = '';
        this.pattern = '';
        this.errormessage = '';
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.hint = '';
        this.inputmode = 'none';
        this.valueInitial = '';
        this.valueFinal = '';
        this.separatorText = '';
        this.error = '';
    }
    render() {
        return html `
        <label class="form-control-label">
          ${this.label}
        </label>
        <div class="input_container">
            <input
                class="input_control initial"
                type="date"
                name=${ifDefined(this.name)}
                ?disabled=${this.disabled}
                ?readonly=${this.readonly}
                ?required=${this.required}
                min=${ifDefined(this.minvalue)}    
                .value=${this.valueInitial}
                ?autofocus=${this.autofocus}
                pattern=${ifDefined(this.pattern)}
                inputmode=${ifDefined(this.inputmode)}
                @input=${this.handleChange}
            />

            <span>${this.separatorText}</span>

            <input
                class="input_control final"
                type="date"
                name=${ifDefined(this.name)}
                ?disabled=${this.disabled}
                ?readonly=${this.readonly}
                ?required=${this.required}
                min=${ifDefined(this.valueInitial)}
                max=${ifDefined(this.maxvalue)}
                .value=${this.valueFinal}
                ?autofocus=${this.autofocus}
                pattern=${ifDefined(this.pattern)}
                inputmode=${ifDefined(this.inputmode)}
            />
        </div>
        <small class="form_hint">${this.hint}</small>

        <div class="form_error_message">${this.error}</div>
        `;
    }
    handleChange() {
        if (!this.inputFinal || !this.inputInitial)
            return;
        let maxValue = this.inputInitial.value;
        this.inputFinal.min = maxValue;
        if (this.inputFinal.value < maxValue) {
            this.inputFinal.value = maxValue;
        }
    }
};
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "widget", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "errormessage", void 0);
__decorate([
    property({ type: Number })
], WCInputDateRange.prototype, "maxvalue", void 0);
__decorate([
    property({ type: Number })
], WCInputDateRange.prototype, "minvalue", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "autofocus", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "inputmode", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "valueInitial", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "valueFinal", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "separatorText", void 0);
__decorate([
    query('.input_control.initial')
], WCInputDateRange.prototype, "inputInitial", void 0);
__decorate([
    query('.input_control.final')
], WCInputDateRange.prototype, "inputFinal", void 0);
WCInputDateRange = __decorate([
    customElement('wc-input-date-range-100554')
], WCInputDateRange);
export { WCInputDateRange };
