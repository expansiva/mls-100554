/// <mls shortName="wcInputDateRange" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
let WCInputDateRange = class WCInputDateRange extends LitElement {
    constructor() {
        super(...arguments);
        this.name = '';
        this.label = '';
        this.widget = '';
        this.pattern = '';
        this.errormessage = '';
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.hint = '';
        this.inputmode = 'none';
        this.valueInitial = '';
        this.valueFinal = '';
        this.separatorText = '';
        this.error = '';
    }
    render() {
        return html `
        <label class="form-control-label">
          ${this.label}
        </label>
        <div class="input_container">
            <input
                class="input_control initial"
                type="date"
                name=${ifDefined(this.name)}
                ?disabled=${this.disabled}
                ?readonly=${this.readonly}
                ?required=${this.required}
                min=${ifDefined(this.minvalue)}    
                .value=${this.valueInitial}
                ?autofocus=${this.autofocus}
                pattern=${ifDefined(this.pattern)}
                inputmode=${ifDefined(this.inputmode)}
                @input=${this.handleChange}
            />

            <span>${this.separatorText}</span>

            <input
                class="input_control final"
                type="date"
                name=${ifDefined(this.name)}
                ?disabled=${this.disabled}
                ?readonly=${this.readonly}
                ?required=${this.required}
                min=${ifDefined(this.valueInitial)}
                max=${ifDefined(this.maxvalue)}
                .value=${this.valueFinal}
                ?autofocus=${this.autofocus}
                pattern=${ifDefined(this.pattern)}
                inputmode=${ifDefined(this.inputmode)}
            />
        </div>
        <small class="form_hint">${this.hint}</small>

        <div class="form_error_message">${this.error}</div>
        `;
    }
    handleChange() {
        if (!this.inputFinal || !this.inputInitial)
            return;
        let maxValue = this.inputInitial.value;
        this.inputFinal.min = maxValue;
        if (this.inputFinal.value < maxValue) {
            this.inputFinal.value = maxValue;
        }
    }
};
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "widget", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "errormessage", void 0);
__decorate([
    property({ type: Number })
], WCInputDateRange.prototype, "maxvalue", void 0);
__decorate([
    property({ type: Number })
], WCInputDateRange.prototype, "minvalue", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "autofocus", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "inputmode", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "valueInitial", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "valueFinal", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "separatorText", void 0);
__decorate([
    query('.input_control.initial')
], WCInputDateRange.prototype, "inputInitial", void 0);
__decorate([
    query('.input_control.final')
], WCInputDateRange.prototype, "inputFinal", void 0);
WCInputDateRange = __decorate([
    customElement('wc-input-date-range-100554')
], WCInputDateRange);
export { WCInputDateRange };
