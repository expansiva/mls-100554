/// <mls shortName="beCollabClient" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export class BECollabClient {
    constructor() {
        this.serverIframe = window.previewL1;
        this.requestId = 0;
        this.callbacks = {};
        this.init();
    }
    request(path, method = "GET", body = null) {
        return new Promise((resolve, reject) => {
            if (!this.serverIframe || !this.serverIframe.contentWindow)
                return;
            const id = this.requestId++;
            this.callbacks[id] = { resolve, reject };
            this.serverIframe.contentWindow.postMessage({ id, path, method, body }, "*");
            setTimeout(() => {
                if (this.callbacks[id]) {
                    reject(new Error("Timeout na requisição"));
                    delete this.callbacks[id];
                }
            }, 5000);
        });
    }
    init() {
        if (!this.serverIframe)
            throw new Error('Not found server');
        window.addEventListener("message", (event) => this.handleResponse(event));
    }
    handleResponse(event) {
        const { id, response, error } = event.data;
        if (this.callbacks[id]) {
            if (error) {
                this.callbacks[id].reject(new Error(error));
            }
            else {
                this.callbacks[id].resolve(response);
            }
            delete this.callbacks[id];
        }
    }
}
