/// <mls shortName="icaPageOverlayItem" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getPosition } from './_100554_icaPageOverlayBase';
export function initIcaPageOverlayItem() {
    return true;
}
let IcaPageOverlayItem = class IcaPageOverlayItem extends LitElement {
    //---------COMPONENT--------------
    createRenderRoot() {
        return this; // dont use shadow root
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.setEvents();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level') && changedProperties.get('level') !== undefined) {
            this.checkToChangeWCD();
        }
    }
    render() {
        this.overlay = this.parentElement;
        if (!this.info || !this.boundingPage)
            return html ``;
        const pos = getPosition(this.info, this.boundingPage);
        this.info.element.overlayRef = this;
        this.style.display = 'block';
        this.style.position = 'absolute';
        this.style.width = pos.width;
        this.style.height = pos.height;
        this.style.top = pos.top;
        this.style.left = pos.left;
        return html ``;
    }
    //---------IMPLEMENTS--------------
    setEvents() {
        this.onmouseover = (e) => {
            this.onIcaOverlayItemOver(e);
        };
        this.onmouseleave = (e) => {
            this.onIcaOverlayItemLeave(e);
        };
        this.onclick = (e) => {
            this.onIcaOverlayItemClick(e);
        };
    }
    onIcaOverlayItemLeave(e) {
        this.style.opacity = '';
        this.style.background = '';
    }
    onIcaOverlayItemOver(e) {
        const wcdOther = this.parentElement?.querySelector('wcd-toolbox-100554');
        if (wcdOther) {
            const elSelected = wcdOther.parentElement;
            if (this.isOverlapping(elSelected, this)) {
                return;
            }
        }
        const wcd = this.querySelector('wcd-toolbox-100554');
        if (wcd)
            return;
        this.style.background = '#d3e3fd';
        this.style.opacity = '.3';
    }
    isOverlapping(el1, el2) {
        const rect1 = el1.getBoundingClientRect();
        const rect2 = el2.getBoundingClientRect();
        return !(rect1.top > rect2.bottom ||
            rect1.right < rect2.left ||
            rect1.bottom < rect2.top ||
            rect1.left > rect2.right);
    }
    async onIcaOverlayItemClick(e) {
        e.stopPropagation();
        const origin = e.detail.origin;
        if (origin !== "editor")
            this.selectOnHTML();
        const iHave = this.querySelector('wcd-toolbox-100554');
        if (iHave)
            return;
        await this.addWCDToolbox();
        if (this.level !== '4')
            return;
        //mls.events.fire(4, 'WCDEvent' as any, `{"op":"Navigation"}`);
        mls.events.fire(4, 'WCDEventChange', `{"op":"Navigation"}`);
    }
    async addWCDToolbox() {
        if (!this.overlay || !this.info || !this.level)
            return;
        this.style.opacity = '';
        this.style.background = '';
        const wcds = this.overlay.querySelectorAll('wcd-toolbox-100554');
        wcds.forEach((wc) => {
            const pr = wc.closest('ica-page-overlay-item-100554');
            if (pr && pr.info)
                pr.info.element.setAttribute('renderType', 'edit');
            wc.remove();
        });
        const wcd = document.createElement('wcd-toolbox-100554');
        wcd.setAttribute('level', this.level);
        wcd.elICA = this.info.element;
        this.info.element.setAttribute('renderType', 'editactive');
        await this.setActions();
        let act = this.info.element.actions[this.level];
        if (!act)
            act = [];
        wcd.actions = act;
        wcd.lastHelper = '';
        this.appendChild(wcd);
    }
    selectOnHTML() {
        if (!this.info || !this.info.element)
            return;
        const level = this.info.element.getAttribute('level');
        if (level !== '2')
            return;
        const id = this.info.element.getAttribute('idel');
        if (!id)
            return;
        const infoL2 = mls.actual[2].left;
        const name = mls.l2.editor.getKey({ project: infoL2.project, shortName: infoL2.shortName });
        const mfile = mls.l2.editor.mfiles[name];
        if (!mfile || !mfile.modelHTML)
            return;
        const model = mfile.modelHTML;
        const line = model.findMatches(`id="${id}"`, false, false, false, null, true);
        if (!line || !line[0])
            return;
        const { startLineNumber } = line[0].range;
        mls.events.fire(2, 'WidgetAction', `{"op":"SelectLine", "line":${startLineNumber}, "origin":"preview"}`);
    }
    async setActions() {
        if (!this.info || !this.info.element)
            return;
        const el = this.info.element;
        if (el.isLoadMyAction[this.level])
            return;
        await el.setActions(this.level);
        el.isLoadMyAction[this.level] = true;
    }
    async checkToChangeWCD() {
        const wcd = this.querySelector('wcd-toolbox-100554');
        if (!wcd)
            return;
        if (!this.info || !this.info.element)
            return;
        await this.addWCDToolbox();
    }
};
__decorate([
    property()
], IcaPageOverlayItem.prototype, "info", void 0);
__decorate([
    property()
], IcaPageOverlayItem.prototype, "widget", void 0);
__decorate([
    property()
], IcaPageOverlayItem.prototype, "level", void 0);
IcaPageOverlayItem = __decorate([
    customElement('ica-page-overlay-item-100554')
], IcaPageOverlayItem);
export { IcaPageOverlayItem };
