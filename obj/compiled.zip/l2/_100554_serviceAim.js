/// <mls shortName="serviceAim" project="100554" enhancement="_100554_enhancementLitService" groupName="service"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML, render, styleMap, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { convertFileNameToTag, convertTagToFileName } from './_100554_utilsLit';
import { tasks, readTasks, getUserConfigs, saveUserConfigs } from './_100554_aimHelper';
import { findActions } from './_100554_aimActionBase';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    selectadd: 'por favor selecione abaixo para adicionar',
    allTasksLast: 'Todas as tarefas, últimas',
    user: 'Usuário',
    all: 'Todos',
    ref: 'Ref',
    add: 'Adicionar',
    notFoundReference: 'Referência não encontrada',
    tasksByReference: 'Tarefas por referência',
    noActionsToAdd: 'Nenhuma ação para adicionar',
    selectColumnsYouWant: 'Selecione as colunas que deseja visualizar',
    save: 'Salvar',
    cancel: 'Cancelar'
};
const message_en = {
    loading: 'Loading...',
    selectadd: 'please select below to add',
    allTasksLast: 'All Tasks, last',
    user: 'User',
    all: 'All',
    ref: 'Ref',
    add: 'Add',
    notFoundReference: 'Not found reference',
    tasksByReference: 'Tasks by reference',
    noActionsToAdd: 'No Actions to Add',
    selectColumnsYouWant: 'Select the columns you want to view',
    save: 'Save',
    cancel: 'Cancel'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceAim100554 = class ServiceAim100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-aim-100554{display:block;height:100%;overflow:auto}service-aim-100554 .addTab{height:100%;background-image:linear-gradient(to bottom, #23376a, #600965);color:black}service-aim-100554 .listTab{height:100%;background-image:linear-gradient(to bottom, #23376a, #600965);color:antiquewhite}service-aim-100554 [taskindex]:not([childindex])>details{border-bottom:1px solid var(--grey-color);padding:.25rem}service-aim-100554 [taskindex]:not([childindex])>details>summary{padding:.25rem}service-aim-100554 [taskindex]:not([childindex])>details>summary .action-title{display:inline-flex;align-items:center;flex-wrap:wrap;gap:.6rem}service-aim-100554 [taskindex]:not([childindex])>details>summary .action-title>span{white-space:nowrap}service-aim-100554 [taskindex]:not([childindex])>details>summary .action-title .ac{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block}service-aim-100554 [taskindex]:not([childindex])>details>summary .action-title .ac-prompt{width:20rem}service-aim-100554 [taskindex]:not([childindex])>details>summary .action-title .ac-user{width:6rem}service-aim-100554 [taskindex]:not([childindex])>details>summary .action-title .ac-title{width:10rem}service-aim-100554 [taskindex]:not([childindex])>details>summary .action-title .ac-ref{width:12rem}service-aim-100554 [taskindex]:not([childindex])>details[open]>summary{background-color:var(--grey-color-lighter)}service-aim-100554 details{font-size:16px;padding-left:10px;padding-top:.3rem;padding-bottom:.2rem}service-aim-100554 details details>*{padding-left:20px}service-aim-100554 details [childindex] summary{margin-bottom:1rem}service-aim-100554 [mode="error"] .buttonIcon[title="Error"]{color:var(--error-color)}service-aim-100554 [mode="processed"] .buttonIcon{color:var(--success-color)}service-aim-100554 button{padding:1.3em;border:4px solid transparent}service-aim-100554 summary{cursor:pointer}service-aim-100554 .toolbar{display:inline-flex;margin-right:.5rem;gap:1rem}service-aim-100554 .buttonGroup{display:flex;flex-direction:row;gap:2em}service-aim-100554 .buttonIcon{cursor:pointer;padding:.5rem .5rem;height:auto;display:inline-flex;border:none;background-color:transparent;text-decoration:none;text-rendering:auto;text-align:center;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;user-select:none;-webkit-user-select:none;-ms-user-select:none}service-aim-100554 .ActionItemContainer{display:grid;grid-template-columns:repeat(auto-fill, minmax(20em, 1fr));grid-template-rows:max-content;gap:1em;padding:1em}service-aim-100554 .ActionItem{cursor:pointer;height:3em;width:20em;background-color:#f3e5f5;box-shadow:rgba(55,27,61,0.18) 7px 7px 2px 0;display:flex;justify-content:center;align-items:center;flex-direction:column;border-radius:4px;padding:.5em}service-aim-100554 .addContainer{margin:1em;background-color:#fff;box-shadow:rgba(55,27,61,0.18) 7px 7px 2px 0;border-radius:4px;padding:.5em}service-aim-100554 ul{padding-inline-start:10px;margin:10px}service-aim-100554 .title{color:#fff;background-image:linear-gradient(to right, #a077c5, #7764bf, #4A90E2);text-align:center;margin:0}service-aim-100554 .tb{width:100%;border-collapse:separate;border:1px solid #dedede;border-spacing:3em 1em;overflow-x:auto}service-aim-100554 .th,service-aim-100554 .td{padding:8px;text-align:left;width:auto}service-aim-100554 .th{background-color:#f2f2f2}service-aim-100554 .tabs{display:flex;list-style:none;padding:0}service-aim-100554 .tab{margin-right:2px;padding:10px 15px;cursor:pointer;border:1px solid transparent;border-top-left-radius:.25rem;border-top-right-radius:.25rem}service-aim-100554 .tab:not(.active){border-bottom:1px solid var(--grey-color-dark)}service-aim-100554 .tab.active{background-color:#f0f0f0;border-color:#ccc;border-bottom-color:transparent}service-aim-100554 .tab-content{padding:15px;border:1px solid #ccc;border-top:none;border-radius:0 0 .25rem .25rem;background-color:#f0f0f0}service-aim-100554 .tab-content.active{display:block}service-aim-100554 .tab-content:not(.active){display:none}service-aim-100554 .prompt-suggestion{grid-template-columns:repeat(auto-fit, minmax(450px, 1fr));grid-auto-flow:row;width:100%;gap:.5rem;display:grid;margin:1.5rem 0}service-aim-100554 .prompt-suggestion>span{cursor:pointer;font-size:.875rem;line-height:1.25rem;border-style:solid;border-color:var(--grey-color-light);border-width:1px;display:inline-flex;align-items:center;font-weight:500;border-radius:.75rem;padding-bottom:1rem;padding-top:1rem;padding-left:1rem;padding-right:1rem;text-align:left;white-space:normal}service-aim-100554 .prompt-suggestion>span:hover{background-color:var(--grey-color-lighter)}service-aim-100554 .prompt-suggestion>span>span{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}`);
        this.myMessage = messages['en'];
        this.activeTab = 'All';
        this.useContainerAdd = true; // scenary add list or add action 
        this.actionToOpen = '';
        this.actualServiceOpName = '';
        this.isloading = true;
        this.actualServiceOpLevel = 0;
        this.details = {
            icon: '&#xf03a',
            state: 'foreground',
            position: 'all',
            tooltip: 'AI',
            visible: true,
            widget: '_100554_serviceAim',
            level: [0, 2, 3, 5]
        };
        this.onClickLink = (op) => {
            if (op === 'opColumns')
                return this.showConfigColumns();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            if (this.activeTab === op)
                return;
            this.activeTab = op;
        };
        this.menu = {
            title: 'AI',
            actions: {
                opColumns: 'Columns',
            },
            icons: {
                All: `${this.myMessage.all};f560`,
                User: `${this.myMessage.user};f007`,
                Ref: `${this.myMessage.ref};f15b`,
                Add: `${this.myMessage.add};2b`
            },
            actionDefault: '', // call after close icon clicked
            iconDefault: 'All',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.actions = [];
        this.setEvents();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.myMessage = messages[lang];
        if (this.menu.setIconActive)
            this.menu.setIconActive(this.activeTab);
        if (this.actionToOpen)
            this.activeTab = 'Add';
        switch (this.activeTab) {
            case 'All':
                return this.renderAll();
            case 'User':
                return this.renderUser();
            case 'Ref':
                return this.renderRef();
            case 'Add':
                const renderAddResult = this.renderAdd();
                Promise.resolve().then(() => {
                    this.checkIfHasActionToOpen();
                });
                return renderAddResult;
            default:
                return html ``;
        }
    }
    get invertedPosition() { return this.position === 'left' ? 'right' : 'left'; }
    ;
    async onServiceClick(visible, reinit, el) {
        if (!visible || !reinit)
            return;
        await this.setActions();
        this.requestUpdate();
    }
    setEvents() {
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onToolbarSelectChange(ev));
        this.addEventListener('refresh-request', this.handleRefreshRequest);
    }
    onToolbarSelectChange(ev) {
        if (mls.istrace)
            console.log('serviceAim, toolbarSelected', ev);
        if (this.activeTab !== 'Add')
            return;
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (mls.istrace)
            console.log(`serviceAim, ${data.position}, ${this.position}`);
        if (data.position === this.position || data.level !== this.level) {
            this.useContainerAdd = true;
            return;
        }
        this.actualServiceOpLevel = data.level;
        this.actualServiceOpName = data.to;
        if (this.visible === 'true')
            this.requestUpdate();
    }
    sortKey(arr) {
        function getKey(key) {
            if (!key)
                return -1;
            const parts = key.split('/');
            if (parts.length !== 3)
                return -1;
            const index = Number.parseInt(parts[2]);
            return Number.isNaN(index) ? -1 : index;
        }
        function sort(a, b) {
            if (a.mode === "in progress" && b.mode !== "in progress") {
                return -1;
            }
            else if (a.mode !== "in progress" && b.mode === "in progress") {
                return 1;
            }
            else {
                return getKey(b.key) - getKey(a.key);
            }
        }
        return arr.sort(sort);
    }
    renderAll() {
        const renderTask = (taskRoot, index) => {
            const actionName = convertFileNameToTag(taskRoot.widget);
            const sHtml = `<${actionName} mode="${taskRoot.mode}" taskIndex="${index}" />`;
            return html `${unsafeHTML(sHtml)}`;
        };
        const orderned = this.sortKey(tasks);
        if (mls.istrace)
            console.log(`serviceAim, renderAll`);
        if (this.isloading)
            return html `<span>${this.myMessage.loading}</span>`;
        return html `
        <h4 class='title'>${this.myMessage.allTasksLast} (${tasks.length})</h4>
            ${repeat(orderned, ((task, index) => task.key), ((task, index) => renderTask(task, index)))}
        `;
    }
    renderUser() {
        const userName = localStorage.getItem('loginUser');
        const renderTask = (taskRoot, index) => {
            if (taskRoot.userName !== userName)
                return;
            const actionName = convertFileNameToTag(taskRoot.widget);
            const sHtml = `<${actionName} mode="${taskRoot.mode}" taskIndex="${index}"/>`;
            return html `${unsafeHTML(sHtml)}`;
        };
        const orderned = this.sortKey(tasks);
        return html `
        <h4 class='title'>${this.myMessage.user}: ${userName} </h4>
            ${repeat(orderned, ((task, index) => index), ((task, index) => renderTask(task, index)))}            
        `;
    }
    renderRef() {
        let refOpr = '';
        if (this.nav3Service) {
            const pos = this.position === 'left' ? 'right' : 'left';
            const op = this.nav3Service.getActiveInstance(pos);
            if (op && op.getActualRef)
                refOpr = op.getActualRef();
        }
        const renderTask = (taskRoot, index) => {
            let hasRef = taskRoot.children.filter((c) => c.ref === refOpr);
            if (!hasRef || hasRef.length <= 0)
                return;
            const actionName = convertFileNameToTag(taskRoot.widget);
            const sHtml = `<${actionName} mode="${taskRoot.mode}" taskIndex="${index}"/>`;
            return html `${unsafeHTML(sHtml)}`;
        };
        let orderned = this.sortKey(tasks);
        if (refOpr.length <= 0)
            refOpr = '***notFoundService---';
        const verifyOrderned = orderned.filter((i) => {
            let hasRef = i.children.filter((c) => c.ref === refOpr);
            if (!hasRef || hasRef.length <= 0)
                return false;
            return true;
        });
        return html `
            <h4 class='title'>${this.myMessage.tasksByReference} </h4>
                ${verifyOrderned.length > 0 ? repeat(orderned, ((task, index) => index), ((task, index) => renderTask(task, index))) : html `<h4>${this.myMessage.notFoundReference}</h4>`}
        `;
    }
    updated(changedProperties) {
        super.update(changedProperties);
        if (!changedProperties.has('activeTab'))
            return;
        switch (this.activeTab) {
            case 'All':
                // readTasksFromServer('all', '')
                //     .then(() => this.sendRefreshRequest());
                return;
            case 'User':
                // readTasksFromServer('byUser', '')
                //     .then(() => this.sendRefreshRequest());
                return;
            case 'Ref':
                return;
            case 'Add':
                this.setActions().then(() => this.sendRefreshRequest());
                return;
            case 'Loading':
                return;
            default:
                console.error('invalid activeTab:', this.activeTab);
        }
    }
    sendRefreshRequest() {
        const event = new CustomEvent('refresh-request', { bubbles: true, composed: true });
        this.dispatchEvent(event);
    }
    handleRefreshRequest() {
        this.requestUpdate();
    }
    async connectedCallback() {
        super.connectedCallback();
        if (!this.nav3Service) { // for preview test
            this.actualServiceOpName = '_100554_ServiceSource';
            this.actualServiceOpLevel = 2;
        }
        await readTasks().then(async () => {
            await this.setActions();
            const widgetsDistincts = new Set();
            tasks.forEach(task => {
                widgetsDistincts.add(task.widget);
            });
            const arrayWidgets = Array.from(widgetsDistincts);
            for await (let widget of arrayWidgets) {
                try {
                    await this.loadComponentModule(widget);
                }
                catch (e) {
                    console.log('action don exists: ' + widget);
                }
            }
            this.isloading = false;
            this.requestUpdate();
        });
    }
    async attributeChangedCallback(prop, oldValue, newValue) {
        super.attributeChangedCallback(prop, oldValue, newValue);
        if (prop === 'actualserviceopname' && oldValue !== newValue) {
            await this.setActions();
            this.requestUpdate();
        }
    }
    async setActions() {
        this.actions = await this.getActionsByContext();
    }
    async getActionsByContext() {
        if (!this.actualServiceOpName || this.actualServiceOpLevel !== this.level) {
            const activeInstance = this.nav3Service?.getActiveInstance(this.invertedPosition);
            if (!activeInstance || !(activeInstance instanceof ServiceBase)) {
                return [];
            }
            const tag = activeInstance.tagName;
            const fileName = convertTagToFileName(tag.toLowerCase());
            this.actualServiceOpLevel = activeInstance.level;
            this.actualServiceOpName = fileName;
        }
        const act = await findActions(this.level, [this.actualServiceOpName]);
        return act;
    }
    renderAdd() {
        let filteredActions = [];
        if (!this.nav3Service)
            filteredActions = this.actions; // for preview test
        else
            filteredActions = this.actions.filter((item) => item.tagsValid === true && item.levelsValid);
        const renderItems = () => {
            return filteredActions.map((action, index) => {
                const dataAction = `_${action.project}_${action.shortName}`;
                return html `
                <div data-action=${dataAction} class="ActionItem" @click=${() => this.onAddTask(action, index)}>
                    <div>${action.title}</div>
                    <div>${action.project} - ${action.shortName}</div>
                </div>
            `;
            });
        };
        const showListStyle = { display: !this.useContainerAdd ? 'none' : 'grid' };
        const showContainerStyle = { display: !this.useContainerAdd ? 'block' : 'none' };
        return html `
        <div class='addTab' >
          <h4 class='title'>${this.myMessage.selectadd} : ${this.actualServiceOpName}</h4>
          <div class='ActionItemContainer'  style=${styleMap(showListStyle)}>
            ${filteredActions.length === 0
            ? html `<div class="no-actions" style="color: #fff;">${this.myMessage.noActionsToAdd}</div>`
            : renderItems()}
          </div>
          <div
            id='componentContainer'
            class='addContainer'
            style=${styleMap(showContainerStyle)} 
            @add-task=${this.finishedAddTaskRoot}
            @finished-add-task-root=${this.finishedAddTaskRoot}
          >
          </div> 
        </div>
        `;
    }
    onAddTask(action, index) {
        const webComponentAddHandle = `_${action.project}_${action.shortName}`;
        const container = this.shadowRoot?.getElementById('componentContainer');
        this.loadAndRenderComponent(webComponentAddHandle, container);
    }
    finishedAddTaskRoot(e) {
        if (e.detail.cancel) {
            this.useContainerAdd = true;
            return;
        }
        this.activeTab = 'All';
        this.useContainerAdd = true;
    }
    async loadAndRenderComponent(widget, container) {
        if (!widget || !container) {
            console.error(`invalid call on loadAndRenderComponent: `, !!widget, !!container);
            return;
        }
        try {
            const componentModule = await this.loadComponentModule(widget);
            if (!componentModule) {
                console.error('widget not exists or invalid:' + widget);
                return;
            }
            const tagName = convertFileNameToTag(widget);
            const newTabIndex = ' tabIndex="-1" ';
            const msizeH = this.msize.split(',')[1];
            const height = ` height= "${Number.parseFloat(msizeH) - 95}"`;
            const modeInit = "add";
            const newMode = ' mode="' + modeInit + '"';
            render(html `${unsafeHTML('<' + tagName + newTabIndex + newMode + height + '/> ')}`, container);
            this.useContainerAdd = false;
        }
        catch (error) {
            console.error("Erro ao carregar o componente:" + widget + ", error: ", error);
            this.useContainerAdd = true;
        }
    }
    async loadComponentModule(widget) {
        const componentModule = await import('./' + widget);
        return componentModule;
    }
    renderColums() {
        this.stateColumns = getUserConfigs();
        const keys = Object.keys(this.stateColumns);
        return html `
            ${this.myMessage.selectColumnsYouWant}
            <div style="padding:0 1rem;">
                ${keys.map((key) => {
            const isChecked = this.stateColumns[key] === true;
            const isDisabled = key === 'status';
            return html `
                        <div style="display:flex; align-items:center;">
                            <input
                                id="${key}" 
                                type="checkbox"
                                ?checked=${isChecked} 
                                ?disabled=${isDisabled} 
                                @change=${(event) => this.handleInputChange(event, key)}
                            ></input>
                            <label style="cursor:pointer;" for=${key}>${key}</label>
                        </div>
                    `;
        })}
                <div style="margin-top:1rem;">
                    <button @click=${this.handleSaveColumnClick.bind(this)}>${this.myMessage.save}</button>
                    <button @click=${this.handleCancelColumnClick.bind(this)}>${this.myMessage.cancel}</button>
                </div>
            
            </div>
        `;
    }
    handleInputChange(event, key) {
        const target = event.target;
        const checked = target.checked;
        if (key === 'status')
            return;
        this.stateColumns[key] = checked;
    }
    handleCancelColumnClick() {
        if (this.menu.closeMenu)
            this.menu.closeMenu();
    }
    handleSaveColumnClick() {
        if (this.stateColumns) {
            saveUserConfigs(this.stateColumns);
            this.activeTab = 'Loading';
            setTimeout(() => {
                this.activeTab = 'All';
                if (this.menu.closeMenu)
                    this.menu.closeMenu();
            }, 50);
        }
    }
    showConfigColumns() {
        const div1 = document.createElement('div');
        div1.style.padding = '1rem';
        render(this.renderColums(), div1);
        if (this.menu.setMode)
            this.menu.setMode('page', div1);
        return true;
    }
    checkIfHasActionToOpen() {
        if (!this.actionToOpen)
            return;
        setTimeout(() => {
            const action = this.shadowRoot?.querySelector(`.ActionItem[data-action="${this.actionToOpen}"]`);
            if (action)
                action.click();
            this.actionToOpen = '';
        }, 100);
    }
};
__decorate([
    property()
], ServiceAim100554.prototype, "activeTab", void 0);
__decorate([
    property({ reflect: true })
], ServiceAim100554.prototype, "useContainerAdd", void 0);
__decorate([
    property({ reflect: true })
], ServiceAim100554.prototype, "actionToOpen", void 0);
__decorate([
    property({ reflect: true })
], ServiceAim100554.prototype, "actualServiceOpName", void 0);
__decorate([
    property()
], ServiceAim100554.prototype, "isloading", void 0);
ServiceAim100554 = __decorate([
    customElement('service-aim-100554')
], ServiceAim100554);
export { ServiceAim100554 };
