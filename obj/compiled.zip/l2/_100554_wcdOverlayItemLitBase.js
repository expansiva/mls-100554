/// <mls shortName="wcdOverlayItemLitBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { CollabLitElement } from './_100554_collabLitElement';
import './_100554_wcdToolbox';
export class WcdOverlayItemLitBase extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    fcRemoveWcd() {
        this.info?.element.setAttribute('renderType', 'edit');
        this.removeAttribute('rendertype');
    }
    //---------COMPONENT--------------
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.setEvents();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level') && changedProperties.get('level') !== undefined) {
            this.checkToChangeWCD();
        }
    }
    //-------IMPLEMENT---------
    setEvents() {
        this.onmouseover = (e) => {
            this.onIcaOverlayItemOver(e);
        };
        this.onmouseleave = (e) => {
            this.onIcaOverlayItemLeave(e);
        };
        this.onclick = (e) => {
            this.onIcaOverlayItemClick(e);
        };
    }
    onIcaOverlayItemOver(e) {
        const wcdOther = this.parentElement?.querySelector('wcd-toolbox-100554');
        if (wcdOther) {
            const elSelected = wcdOther.parentElement;
            const isOverlapping = this.isOverlapping(elSelected, this);
            if (isOverlapping) {
                return;
            }
        }
        const wcd = this.querySelector('wcd-toolbox-100554');
        if (wcd)
            return;
        this.style.background = '#d3e3fd';
        this.style.opacity = '.3';
        if (this.fcCallBackOver)
            this.fcCallBackOver(e);
    }
    onIcaOverlayItemLeave(e) {
        this.style.opacity = '';
        this.style.background = '';
        if (this.fcCallBackLeave)
            this.fcCallBackLeave(e);
    }
    async onIcaOverlayItemClick(e) {
        e.stopPropagation();
        const origin = e.detail.origin;
        if (origin !== "editor")
            this.selectOnHTML();
        const iHave = this.querySelector('wcd-toolbox-100554');
        if (iHave)
            return;
        const group = this.findAncestorWithIsicaGroup(this.info?.element);
        if (group && group.overlayRef) {
            group.overlayRef.click();
            return;
        }
        await this.addWCDToolbox(e.x, e.y);
        if (this.fcCallBackClick)
            this.fcCallBackClick(e);
        if (this.level !== '3')
            return;
        mls.events.fire(3, 'WCDEventChange', `{"op":"Navigation"}`);
    }
    async addWCDToolbox(x = 0, y = 0) {
        if (!this.overlay || !this.info || !this.level)
            return;
        this.style.opacity = '';
        this.style.background = '';
        const iHaveEvents = this.querySelector('.itemHasEvent');
        if (iHaveEvents) {
            iHaveEvents.style.display = 'none';
        }
        let lestCssWcd = '';
        const overlayItens = this.overlay.querySelectorAll('*[rendertype="editactive"]');
        (overlayItens).forEach((ovI) => {
            const overlayItem = ovI;
            if (!overlayItem.info)
                return;
            overlayItem.info.element.setAttribute('renderType', 'edit');
            overlayItem.removeAttribute('rendertype');
            const oelHaveEvents = overlayItem.querySelector('.itemHasEvent');
            if (oelHaveEvents)
                oelHaveEvents.style.display = 'flex';
            const wc = overlayItem.querySelector('wcd-toolbox-100554');
            if (wc) {
                lestCssWcd = wc.style.cssText;
                wc.remove();
            }
        });
        const wcd = document.createElement('wcd-toolbox-100554');
        wcd.setAttribute('level', this.level);
        wcd.elICA = this.info.element;
        this.info.element.setAttribute('renderType', 'editactive');
        wcd.setAttribute('initialclick', `${x},${y}`);
        wcd.lastHelper = '';
        if (lestCssWcd)
            wcd.style.cssText = lestCssWcd;
        this.setAttribute('rendertype', 'editactive');
        this.appendChild(wcd);
    }
    findAncestorWithIsicaGroup(element) {
        while (element) {
            if (element !== this.info?.element && element.hasAttribute && element.hasAttribute('isicagroup') && element.getAttribute('isicagroup') === 'true') {
                return element;
            }
            if (element.parentNode) {
                element = element.parentNode;
            }
            else if (element.host) {
                // If inside a shadow DOM, move up to the host
                element = element.host;
            }
            else {
                // Reached the top of the DOM tree
                break;
            }
        }
        return null;
    }
    selectOnHTML() {
        if (!this.info || !this.info.element)
            return;
        const level = this.info.element.getAttribute('level');
        if (level !== '2')
            return;
        const id = this.info.element.getAttribute('idel');
        if (!id)
            return;
        const infoL2 = mls.actual[2].left;
        const name = mls.l2.getKey({ project: infoL2.project, shortName: infoL2.shortName });
        const models = mls.editor.models[name];
        if (!models || !models.html)
            return;
        const model = models.html.model;
        const line = model.findMatches(`id="${id}"`, false, false, false, null, true);
        if (!line || !line[0])
            return;
        const { startLineNumber } = line[0].range;
        mls.events.fire(2, 'WidgetAction', `{"op":"SelectLine", "line":${startLineNumber}, "origin":"preview"}`);
    }
    isOverlapping(el1, el2) {
        const rect1 = el1.getBoundingClientRect();
        const rect2 = el2.getBoundingClientRect();
        const horizontalOverlap = rect1.left < rect2.right && rect1.right > rect2.left;
        const verticalOverlap = rect1.top < rect2.bottom && rect1.bottom > rect2.top;
        return horizontalOverlap && verticalOverlap;
    }
    async checkToChangeWCD() {
        const wcd = this.querySelector('wcd-toolbox-100554');
        if (!wcd)
            return;
        if (!this.info || !this.info.element)
            return;
        await this.addWCDToolbox();
    }
}
