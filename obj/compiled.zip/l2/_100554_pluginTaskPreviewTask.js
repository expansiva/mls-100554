/// <mls shortName="pluginTaskPreviewTask" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let PluginTaskPreviewTask = class PluginTaskPreviewTask extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-task-preview-task-100554{display:block;background:#ffffff;position:relative}plugin-task-preview-task-100554 .tab-header{display:flex;justify-content:space-between;border-bottom:1px solid #ccc;background-color:#f0f0f0;overflow:hidden;flex-shrink:0}plugin-task-preview-task-100554 .tab-group-left{display:flex;overflow-x:auto;flex:1;min-width:0;scrollbar-width:thin}plugin-task-preview-task-100554 .tab-group-left::-webkit-scrollbar{height:6px}plugin-task-preview-task-100554 .tab-group-left::-webkit-scrollbar-thumb{background-color:var(--grey-color-darker);border-radius:4px}plugin-task-preview-task-100554 .tab-group-right{display:flex;flex-shrink:0}plugin-task-preview-task-100554 .tab-button{padding:10px 16px;cursor:pointer;background:none;border:none;border-right:1px solid #ddd;font-size:14px;transition:background-color .2s ease;display:flex;flex-direction:column}plugin-task-preview-task-100554 .tab-button:hover{background-color:#e0e0e0}plugin-task-preview-task-100554 .tab-button.active{background-color:#ffffff;font-weight:bold;border-bottom:2px solid #007bff}plugin-task-preview-task-100554 .tab-content{position:relative;flex:1;padding:.5rem;margin:0;background-color:#ffffff;display:flex;height:100%;flex-grow:1;flex-direction:column}plugin-task-preview-task-100554 .containerinputs{display:flex;flex-direction:column;gap:.5rem;align-items:center;padding:1rem}plugin-task-preview-task-100554 .containerinputs details{width:100%;max-width:900px;border:1px solid #e0e0e0;border-radius:8px;background-color:#fafafa;box-shadow:0 2px 8px rgba(0,0,0,0.05);font-family:'Inter',sans-serif;transition:all .3s ease}plugin-task-preview-task-100554 .containerinputs details[open] .title{display:none}plugin-task-preview-task-100554 .containerinputs details .chevron{transition:transform .3s}plugin-task-preview-task-100554 .containerinputs details[open] .chevron{transform:rotate(90deg)}plugin-task-preview-task-100554 .containerinputs details[open] .moveelement{display:none !important}plugin-task-preview-task-100554 .containerinputs details summary{position:relative;cursor:pointer;padding:1rem;border-bottom:1px solid #e0e0e0;display:flex;align-items:center;justify-content:space-between}plugin-task-preview-task-100554 .containerinputs details summary:hover .moveelement{display:flex}plugin-task-preview-task-100554 .containerinputs details summary .trash{z-index:9999}plugin-task-preview-task-100554 .containerinputs details summary .pheader{width:100%;display:flex;justify-content:space-between;align-items:center}plugin-task-preview-task-100554 .containerinputs details summary .pheader .title{margin-left:1rem}plugin-task-preview-task-100554 .containerinputs details summary .pheader .type .typeMode{appearance:none;padding:.4rem 1rem;font-size:.95rem;border:1px solid #ccc;border-radius:6px;background-color:white;transition:border .3s ease}plugin-task-preview-task-100554 .containerinputs details>div{padding:1rem}plugin-task-preview-task-100554 .containerinputs details>div pre.content{width:calc(100% - 2rem);border:none;resize:vertical;padding:1rem;font-size:.95rem;font-family:'Fira Code',monospace;background-color:#fff;border-radius:6px;color:#333;box-shadow:inset 0 1px 2px rgba(0,0,0,0.05);line-height:1.5;word-break:break-word;white-space:pre-wrap}plugin-task-preview-task-100554 ul{list-style:none;padding:1rem;margin:1rem 0;border-radius:12px;color:#333}plugin-task-preview-task-100554 ul li{margin-bottom:.75rem;padding:.5rem .75rem;background:white;border-radius:8px;transition:background .3s}plugin-task-preview-task-100554 ul li:hover{background:#f0f8ff}plugin-task-preview-task-100554 ul li:last-child{margin-bottom:0}plugin-task-preview-task-100554 ul li code{font-family:'Courier New',monospace;background-color:#eee;padding:2px 6px;border-radius:4px}`);
        this.task = null;
        this.mode = 'info';
    }
    render() {
        if (!this.task) {
            return html `<p>Task not Found.</p>`;
        }
        return html `
            <div style="height: calc(100% - 85px);">
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button
                            class="tab-button ${this.mode === 'info' ? 'active' : ''}" @click=${() => this.selectTabInfo()} >
                            Info                            
                        </button>
                    </div>
                </div>
                <div class="tab-content">
                    ${this.renderMode()}
                    
                </div>
            </div>
        `;
    }
    renderMode() {
        switch (this.mode) {
            case 'info': return this.renderInfo();
            default: return this.renderInfo();
        }
    }
    renderInfo() {
        if (!this.task)
            return html ``;
        return html `
            <header>
                <h2>${this.task.PK}</h2>
                <small>Status: ${this.task.status} | Última atualização: ${new Date(this.task.last_updated).toLocaleString()}</small>
            </header>
        `;
    }
    //------IMPLEMENTATION----------
    selectTabInfo() {
        this.mode = 'info';
    }
};
__decorate([
    property({ type: Object })
], PluginTaskPreviewTask.prototype, "task", void 0);
__decorate([
    state()
], PluginTaskPreviewTask.prototype, "mode", void 0);
PluginTaskPreviewTask = __decorate([
    customElement('plugin-task-preview-task-100554')
], PluginTaskPreviewTask);
export { PluginTaskPreviewTask };
