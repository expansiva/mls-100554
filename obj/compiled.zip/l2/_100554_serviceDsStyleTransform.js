/// <mls shortName="serviceDsStyleTransform" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/**
 * @mlsComponentDetails {
 *  "webComponentDependencies": ["collab-ds-input-range-100554"]
 * }
 */
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabDSInputRange } from './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    scaleX: 'Escala x',
    scaleY: 'Escala y',
    skewX: 'Inclinar x',
    skewY: 'Inclinar Y',
    translateX: 'Traduzir x',
    translateY: 'Traduzir y',
    rotate: 'Girar',
};
const message_en = {
    scaleX: 'Scale x',
    scaleY: 'Scale y',
    skewX: 'Skew x',
    skewY: 'Skew Y',
    translateX: 'Translate x',
    translateY: 'Translate y',
    rotate: 'Rotate',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleTransform = class ServiceDsStyleTransform extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.filter = {
            scaleX: '',
            scaleY: '',
            rotate: '',
            translateX: '',
            translateY: '',
            skewX: '',
            skewY: '',
        };
        this.myUpp = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleTransform';
        this.details = {
            icon: '&#xf2f1',
            state: 'foreground',
            position: 'right',
            tooltip: 'Transform',
            visible: false,
            widget: '_100554_serviceDsStyleTransform',
            tags: ['ds_styles'],
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Transform',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //-------------IMPLEMENTS--------------
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        this.arrayGallery = [
            '',
            'transform: scale(1.5);',
            'transform: rotate(90deg);',
            'transform: rotate(181deg);',
            'transform: rotate(270deg);',
            'transform: skew(50deg);',
            'transform: skew(50deg, -50deg);',
            'transform: skew(-50deg, 0deg);',
            'transform: skew(-50deg, 50deg);'
        ];
        initCollabDSInputRange();
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        if (this.showNav2Item)
            this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        if (this.showNav2Item)
            this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `${this.renderTransform()}${this.renderGallery()}`;
    }
    renderTransform() {
        return html `
            <div>
                <div class="groupEdit">
                    <span>${this.msg.scaleX}</span>
                    <collab-ds-input-range-100554 prop="scaleX" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.scaleY}</span>
                    <collab-ds-input-range-100554 prop="scaleY" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.skewX}</span>
                    <collab-ds-input-range-100554 prop="skewX" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.skewY}</span>
                    <collab-ds-input-range-100554 prop="skewY" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.translateX}</span>
                    <collab-ds-input-range-100554 prop="translateX" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.translateY}</span>
                    <collab-ds-input-range-100554 prop="translateY" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.rotate}</span>
                    <collab-ds-input-range-100554 prop="rotate" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">
                ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `<h5 style="${css}" @click="${this.clickGallery}" .gallery=${css}>Item</h5>`;
        }))}
            </div>
        
        `;
    }
    onChangeProp(obj) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.mountValue();
        }, 500);
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
    mountValue() {
        if (!this.shadowRoot)
            return;
        const elSX = this.shadowRoot.querySelector('*[prop="scaleX"]');
        const elSY = this.shadowRoot.querySelector('*[prop="scaleY"]');
        const elSKX = this.shadowRoot.querySelector('*[prop="skewX"]');
        const elSKY = this.shadowRoot.querySelector('*[prop="skewY"]');
        const elTX = this.shadowRoot.querySelector('*[prop="translateX"]');
        const elTY = this.shadowRoot.querySelector('*[prop="translateY"]');
        const elR = this.shadowRoot.querySelector('*[prop="rotate"]');
        let value = '';
        if (elSX.value || elSY.value) {
            value += 'scale(' + (elSX.value ? elSX.value : '1') + (elSY.value ? ', ' + elSY.value : '') + ')';
        }
        if (elR.value) {
            value += elR.value ? ' rotate(' + elR.value + 'deg)' : '';
        }
        if (elTX.value || elTY.value) {
            value += 'translate(' + (elTX.value ? elTX.value + 'px' : '0px') + (elTY.value ? ', ' + elTY.value : ', 0') + 'px)';
        }
        if (elSKX.value || elSKY.value) {
            value += 'skew(' + (elSKX.value ? elSKX.value + 'deg' : '0deg') + (elSKY.value ? ', ' + elSKY.value : ', 0') + 'deg)';
        }
        const change = {
            key: 'transform',
            value
        };
        this.emitEvent(change);
    }
    setValues(block) {
        Object.keys(this.filter).forEach((item) => { this.filter[item] = ''; });
        const textTransform = block.find((item) => item.key === 'transform');
        if (!textTransform || !this.shadowRoot)
            return;
        this.myUpp = true;
        let { value } = textTransform;
        const myFilter = this.filter;
        const filter = value.split(')');
        filter.forEach((item) => {
            if (!item)
                return;
            const prop = item.substr(0, item.indexOf('(')).trim();
            item = item.substr(item.indexOf('('), item.length);
            if (prop.indexOf('scale') >= 0 || prop.indexOf('translate') >= 0 || prop.indexOf('skew') >= 0) {
                item.split(',').forEach((vl, index) => {
                    if (!vl)
                        return;
                    const num = vl.match(/[\.-\d]/g)?.join('');
                    const prefx = index === 0 ? 'X' : 'Y';
                    if (myFilter[prop + prefx] !== undefined)
                        myFilter[prop + prefx] = num;
                });
            }
            else {
                const num = item.match(/[\.-\d]/g)?.join('');
                if (myFilter[prop] !== undefined)
                    myFilter[prop] = num;
            }
        });
        const elSX = this.shadowRoot.querySelector('*[prop="scaleX"]');
        const elSY = this.shadowRoot.querySelector('*[prop="scaleY"]');
        const elSKX = this.shadowRoot.querySelector('*[prop="skewX"]');
        const elSKY = this.shadowRoot.querySelector('*[prop="skewY"]');
        const elTX = this.shadowRoot.querySelector('*[prop="translateX"]');
        const elTY = this.shadowRoot.querySelector('*[prop="translateY"]');
        const elR = this.shadowRoot.querySelector('*[prop="rotate"]');
        if (elSX)
            elSX.value = this.filter.scaleX;
        if (elSY)
            elSY.value = this.filter.scaleY;
        if (elSKX)
            elSKX.value = this.filter.skewX;
        if (elSKY)
            elSKY.value = this.filter.skewY;
        if (elTX)
            elTX.value = this.filter.translateX;
        if (elTY)
            elTY.value = this.filter.translateY;
        if (elR)
            elR.value = this.filter.rotate;
        this.myUpp = false;
    }
    clickGallery(e) {
        const el = e.target;
        if (!el)
            return;
        const css = el.gallery;
        const commands = css.split(';');
        const changes = [];
        commands.forEach((item) => {
            const [key, value] = item.split(':');
            if (!key)
                return;
            changes.push({
                key: key.trim(),
                value: value.trim()
            });
        });
        if (changes.length <= 0)
            changes.push({ key: 'transform', value: '' });
        this.setValues(changes);
        const rc = {
            emitter: 'right',
            value: changes,
            helper: this.helper
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
};
ServiceDsStyleTransform.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsStyleTransform.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleTransform.prototype, "helper", void 0);
ServiceDsStyleTransform = __decorate([
    customElement('service-ds-style-transform-100554')
], ServiceDsStyleTransform);
export { ServiceDsStyleTransform };
