/// <mls shortName="aiAgentHelper" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
/**
 * Helper function to collect all steps from a task in a flat array
 */
export const getAllSteps = (firstStep) => {
    if (!firstStep || firstStep.length < 1) {
        return [];
    }
    const allSteps = [];
    const queue = [...firstStep];
    // BFS approach to collect all steps
    while (queue.length > 0) {
        const currentStep = queue.shift();
        allSteps.push(currentStep);
        // Add nextSteps to queue if they exist
        if (currentStep.nextSteps) {
            queue.push(...currentStep.nextSteps);
        }
        // Add steps from interaction.payload if they exist
        if (currentStep.interaction?.payload) {
            queue.push(...currentStep.interaction.payload);
        }
    }
    return allSteps;
};
export const getAgentStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.find((step) => step.type === 'agent' && step.agentName === agentName);
    return agentSteps || null;
};
export const getAgentsStepByAgentName = (task, agentName, status) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent' && step.agentName === agentName);
    if (!status)
        return agentSteps || [];
    return agentSteps.filter(step => step.status === status);
};
export const getStepById = (task, stepId) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.stepId === stepId) || null;
};
export const getNextPendentStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.status === 'pending') || null;
};
export const getNextResultStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'result');
    return agentSteps.find(step => step.status === 'completed') || null;
};
export const getNextClarificationStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'clarification');
    return agentSteps.find(step => step.status === 'pending') || null;
};
export const getNextPendingStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'pending' && step.agentName === agentName) || null;
};
export const getNextInProgressStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'in_progress' && step.agentName === agentName) || null;
};
export const getInteractionStepId = (task, stepId) => {
    // nextSteps []
    // | interaction
    // | | nextsSteps []
    // ...
    // this routine find the parent interaction stepId
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    if (!allSteps)
        return null;
    for (const step of allSteps) {
        if (!step.interaction || !step.interaction.payload)
            continue;
        if (step.interaction.payload.length < 1)
            continue;
        if (step.interaction.payload.find(s => s.stepId === stepId))
            return step.stepId;
    }
    return null;
};
export const calculateStepsStatistics = (steps, removeFirstStep) => {
    const allSteps = getAllSteps(steps);
    if (removeFirstStep)
        allSteps.shift();
    return {
        agents: allSteps.filter(step => step.type === 'agent').length,
        tools: allSteps.filter(step => step.type === 'tool').length,
        clarification: allSteps.filter(step => step.type === 'clarification').length,
        result: allSteps.filter(step => step.type === 'result').length,
        flexible: allSteps.filter(step => step.type === 'flexible').length,
        totalCost: allSteps.reduce((sum, step) => sum + (step.interaction?.cost || 0), 0),
        totalSteps: allSteps.length
    };
};
export const calculateStepsByFilter = (task, filter) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    // example: calculateStepsByFilter(task, { toolName: "abc "})
    let result = 0;
    for (const step of allSteps) {
        let allPropertiesMatch = true;
        for (const [key, value] of Object.entries(filter)) {
            const value2 = step[key];
            if (value2 !== value) {
                allPropertiesMatch = false;
                break; // exit for
            }
        }
        if (allPropertiesMatch)
            result += 1;
    }
    return result;
};
export const getTemporaryContext = (threadId, userId, prompt) => {
    // create temporary context
    const context = {
        task: undefined,
        message: {
            threadId: threadId,
            orderAt: "",
            createAt: "",
            senderId: userId,
            content: prompt.trim(),
        }
    };
    return context;
};
export function safeParseArgs(args) {
    // must accept entries like
    // { a: 5, b: 4 }
    // a:5,b:4
    // a=5, b=4
    if (!args)
        throw new Error("No args provided");
    let input = args.trim();
    if (input.startsWith("{")) {
        try {
            return JSON.parse(input);
        }
        catch (e) {
            throw new Error("Invalid JSON format");
        }
    }
    if (input.includes("=") && !input.includes(":")) {
        input = input.replace(/([a-zA-Z0-9_]+)\s*=/g, '"$1":');
    }
    else {
        input = input.replace(/(^|,)\s*([a-zA-Z0-9_]+)\s*:/g, '$1"$2":');
    }
    if (!input.startsWith("{")) {
        input = `{${input}}`;
    }
    try {
        return JSON.parse(input);
    }
    catch (e) {
        throw new Error("Invalid args format, cannot parse.");
    }
}
export function argsValidator(args, schema) {
    for (const key in schema) {
        const isOptional = schema[key].optional === true;
        if (!(key in args)) {
            if (!isOptional) {
                throw new Error(`Missing argument: ${key}`);
            }
            continue; // ok se for opcional
        }
        const expectedType = schema[key].type;
        const actualType = typeof args[key];
        if (expectedType !== actualType) {
            throw new Error(`Invalid type for argument '${key}': expected '${expectedType}', got '${actualType}'`);
        }
    }
}
export async function appendLongTermMemory(context, longTermMemory) {
    if (!context.task)
        throw new Error('[appendLongTermMemory] invalid task');
    const messageId = context.task.messageid_created;
    if (!messageId)
        throw new Error("[appendLongTermMemory] Invalid messageId");
    const ret = await mls.api.msgAppendLongTermMemory({
        longTermMemory,
        messageId,
        taskId: context.task.PK,
        userId: getUserIdLocalStorage() || context.message.senderId,
    });
    if (!ret || ret.statusCode !== 200)
        throw new Error("error on AI appendLongTermMemory , stoped");
    return ret.task;
}
export const updateStepStatus = async (task, stepId, status, traceMsg) => {
    const args = {
        "action": "updateStepStatus",
        "userId": getUserIdLocalStorage() || task.owner || '',
        "messageId": task.messageid_created || '',
        "taskId": task.PK,
        stepId,
        status,
        traceMsg
    };
    const ret = await mls.api.msgUpdateStepStatus(args);
    if (!ret || ret.statusCode !== 200)
        throw new Error("error on AI update status , stoped");
    return ret.task;
};
export const updateTaskTitle = async (task, newTitle) => {
    const args = {
        userId: getUserIdLocalStorage() || task.owner,
        newTitle,
        taskId: task.PK,
        messageId: task.messageid_created || '',
        action: 'updateTaskTitle',
    };
    const ret = await mls.api.msgUpdateTaskTitle(args);
    if (!ret || ret.statusCode !== 200)
        throw new Error("error on AI update task title , stoped");
    return ret.task;
};
export async function appendPromptToInteraction(userId, messageId, taskId, interactionStepId, inputAI, stepdIdToChangeStatus, newStatus) {
    if (!messageId)
        throw new Error("Message ID is undefined");
    if (!taskId)
        throw new Error("Task ID is undefined");
    const args = {
        action: "appendPromptToInteraction",
        userId,
        messageId,
        taskId,
        interactionStepId,
        inputAI,
        stepdIdToChangeStatus,
        newStatus
    };
    const ret = await mls.api.msgAppendPromptToInteraction(args);
    if (!ret || ret.statusCode !== 200)
        throw new Error("error on AI update status , stoped");
    return ret.task;
}
const USER_ID_KEY = 'collabMessages_userId';
export function saveUserIdLocalStorage(userId) {
    localStorage.setItem(USER_ID_KEY, userId);
}
export function getUserIdLocalStorage() {
    return localStorage.getItem(USER_ID_KEY);
}
export function notifyTaskChange(context, oldContextCreateAt) {
    const event = new CustomEvent('task-change', {
        detail: { context, oldContextCreateAt },
        bubbles: true,
        composed: true
    });
    window.dispatchEvent(event);
}
export function notifyTaskCompleted(context, result) {
    const event = new CustomEvent('task-completed', {
        detail: { context, result },
        bubbles: true,
        composed: true
    });
    window.dispatchEvent(event);
}
export function notifyThreadChange(thread) {
    const event = new CustomEvent('thread-change', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    window.dispatchEvent(event);
}
export function dispatchDetailsTaskClose() {
    const event = new CustomEvent('task-details-close', {
        bubbles: true,
        composed: true
    });
    window.dispatchEvent(event);
}
export function getTotalCost(task) {
    let tot = 0;
    const nextSteps = task.iaCompressed?.nextSteps;
    if (!nextSteps || nextSteps.length === 0)
        return tot.toFixed(4);
    const sumCosts = (payload) => {
        payload.forEach((pay) => {
            const { interaction, nextSteps } = pay;
            if (interaction) {
                tot += interaction.cost ? interaction.cost : 0;
                if (interaction.payload)
                    sumCosts(interaction.payload);
            }
            if (nextSteps) {
                nextSteps.forEach((next) => {
                    sumCosts([next]);
                });
            }
        });
    };
    nextSteps.forEach((step) => {
        sumCosts([step]);
    });
    return tot.toFixed(4);
}
export function getNextStepIdAvaliable(task) {
    let nextStepId = 0;
    const nextSteps = task.iaCompressed?.nextSteps;
    if (!nextSteps || nextSteps.length === 0)
        return nextStepId + 1;
    const findNextStepId = (payload) => {
        payload.forEach((pay) => {
            const { interaction, nextSteps, stepId } = pay;
            if (stepId > nextStepId)
                nextStepId = stepId + 1;
            if (interaction) {
                if (interaction.payload)
                    findNextStepId(interaction.payload);
            }
            if (nextSteps) {
                nextSteps.forEach((next) => {
                    if (next.stepId > nextStepId)
                        nextStepId = next.stepId + 1;
                    findNextStepId([next]);
                });
            }
        });
    };
    nextSteps.forEach((step) => {
        if (step.stepId > nextStepId)
            nextStepId = step.stepId + 1;
        findNextStepId([step]);
    });
    console.info({ nextStepId });
    return nextStepId;
}
export function formatTimestamp(timestamp) {
    if (!timestamp || timestamp.length < 14) {
        return;
    }
    const year = timestamp.slice(0, 4);
    const month = timestamp.slice(4, 6);
    const day = timestamp.slice(6, 8);
    const hour = timestamp.slice(8, 10);
    const minute = timestamp.slice(10, 12);
    const second = timestamp.slice(12, 14);
    const utcDate = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, parseInt(day), parseInt(hour), parseInt(minute), parseInt(second)));
    const localYear = utcDate.getFullYear();
    const localMonth = (utcDate.getMonth() + 1).toString().padStart(2, '0');
    const localDay = utcDate.getDate().toString().padStart(2, '0');
    const localHour = utcDate.getHours().toString().padStart(2, '0');
    const localMinute = utcDate.getMinutes().toString().padStart(2, '0');
    const localSecond = utcDate.getSeconds().toString().padStart(2, '0');
    const date = `${localYear}-${localMonth}-${localDay}`;
    const time = `${localHour}:${localMinute}:${localSecond}`;
    const dateFull = `${date} ${time}`;
    return { dateFull, date, time };
}
