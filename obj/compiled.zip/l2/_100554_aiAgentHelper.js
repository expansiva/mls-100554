/// <mls shortName="aiAgentHelper" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
/**
 * Helper function to collect all steps from a task in a flat array
 */
export const getAllSteps = (firstStep) => {
    if (!firstStep || firstStep.length < 1) {
        return [];
    }
    const allSteps = [];
    const queue = [...firstStep];
    // BFS approach to collect all steps
    while (queue.length > 0) {
        const currentStep = queue.shift();
        allSteps.push(currentStep);
        // Add nextSteps to queue if they exist
        if (currentStep.nextSteps) {
            queue.push(...currentStep.nextSteps);
        }
        // Add steps from interaction.payload if they exist
        if (currentStep.interaction?.payload) {
            queue.push(...currentStep.interaction.payload);
        }
    }
    return allSteps;
};
export const getStepById = (task, stepId) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.stepId === stepId) || null;
};
export const getNextPendentStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.status === 'pending') || null;
};
export const getNextPendingStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'pending' && step.agentName === agentName) || null;
};
export const getNextInProgressStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'in_progress' && step.agentName === agentName) || null;
};
export const calculateStepsStatistics = (steps, removeFirstStep) => {
    const allSteps = getAllSteps(steps);
    if (removeFirstStep)
        allSteps.shift();
    return {
        agents: allSteps.filter(step => step.type === 'agent').length,
        tools: allSteps.filter(step => step.type === 'tool').length,
        clarification: allSteps.filter(step => step.type === 'clarification').length,
        result: allSteps.filter(step => step.type === 'result').length,
        flexible: allSteps.filter(step => step.type === 'flexible').length,
        totalCost: allSteps.reduce((sum, step) => sum + (step.interaction?.cost || 0), 0),
        totalSteps: allSteps.length
    };
};
export const getTemporaryContext = (threadId, userId, prompt) => {
    // create temporary context
    const context = {
        task: undefined,
        message: {
            threadId: threadId,
            orderAt: "",
            createAt: "",
            senderId: userId,
            content: prompt.trim(),
        }
    };
    return context;
};
export function safeParseArgs(args) {
    if (!args) {
        throw new Error("No args provided");
    }
    let normalizedArgs = args.trim();
    if (!normalizedArgs.startsWith('{')) {
        normalizedArgs = `{${normalizedArgs}}`;
    }
    try {
        // error example: "a:1, b:2" => "{a:1, b:2}" => '{"a":1, "b":2}'
        normalizedArgs = normalizedArgs.replace(/([{,]\s*)([a-zA-Z0-9_]+)\s*:/g, '$1"$2":');
        return JSON.parse(normalizedArgs);
    }
    catch (error) {
        throw new Error("Invalid args format, cannot parse.");
    }
}
export function argsValidator(args, schema) {
    for (const key in schema) {
        if (!(key in args)) {
            throw new Error(`Missing argument: ${key}`);
        }
        const expectedType = schema[key].type;
        const actualType = typeof args[key];
        if (expectedType !== actualType) {
            throw new Error(`Invalid type for argument '${key}': expected '${expectedType}', got '${actualType}'`);
        }
    }
}
