/// <mls shortName="serviceDsStyleColumn" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabDSInputRange } from './_100554_collabDsInputRange';
import { initCollabDsInputSelectColor } from './_100554_collabDsInputSelectColor';
/// **collab_i18n_start**
const message_pt = {
    columnsCount: 'Contagem de coluna',
    columnsWidth: 'Largura das colunas',
    columnsGap: 'Lacuna de colunas',
    columnsRule: 'Regra de Coluna',
    columnSpan: 'Espanço da coluna',
    breakInside: 'Quebre por dentro'
};
const message_en = {
    columnsCount: 'Columns Count',
    columnsWidth: 'Columns Width',
    columnsGap: 'Columns Gap',
    columnsRule: 'Columns Rule',
    columnSpan: 'Column Span',
    breakInside: 'Break Inside'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleColumn = class ServiceDsStyleColumn extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.myUpp = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleColumn';
        this.details = {
            icon: '&#xf0db',
            state: 'foreground',
            position: 'right',
            tooltip: 'Column',
            visible: false,
            tags: ['ds_styles'],
            widget: '_100554_serviceDsStyleColumn',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Column',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //-------------IMPLEMENTS--------------
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.tpBorder = ['none', 'solid', 'dotted', 'dashed', 'double', 'groove', 'ridge', 'inset', 'outset', 'hidden', 'inherit', 'initial', 'unset'];
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        this.arrayGallery = [
            '',
            'column-count: 2;',
            'column-count: 2; column-gap: 20px; column-rule-width: 1px; column-rule-style: dashed;',
            'column-count: 3;',
            'column-count: 2; column-rule-width: 1px; column-rule-style: solid;'
        ];
        initCollabDSInputRange();
        initCollabDsInputSelectColor();
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    setValues(ar) {
        this.myUpp = true;
        ar.forEach((i) => {
            if (!this.shadowRoot || !i.key)
                return;
            const value = i.value;
            const prop = i.key;
            const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
            if (el)
                el.value = value;
        });
        this.myUpp = false;
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `${this.renderColumn()}${this.renderGallery()}`;
    }
    renderColumn() {
        return html `
            <div>
                
                <div class="groupEdit">
                    <span>${this.msg.columnsCount}</span>
                    <collab-ds-input-range-100554 prop="column-count" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.columnsWidth}</span>
                    <collab-ds-input-range-100554 prop="column-width" value="0px" .arraySelect=${this.tpMeasures}  @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.columnsGap}</span>
                    <collab-ds-input-range-100554 prop="column-gap" value="0px" .arraySelect=${this.tpMeasures}  @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.columnsRule}</span>
                    <collab-ds-input-select-color-100554 prop="column-rule" valueInput="0px" .arrayInputSelect=${this.tpMeasures} .arraySelect=${this.tpBorder} valueSelect="none" group="border" @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-select-color-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.columnSpan}</span>
                    <select @change="${() => this.onChangeProp2("column-span")}" style="width:150px" prop="column-span">
                        <option value=""></option>
                        <option value="row">Row</option>
                        <option value="row-reverse">Row Reverse</option>
                        <option value="column">Column</option>
                        <option value="column-reverse">Column Reverse</option>
                    </select>   
                </div>
                <div class="groupEdit">
                    <span>${this.msg.breakInside}</span>
                    <select @change="${() => this.onChangeProp2("break-inside")}" style="width:150px" prop="break-inside">
                        <option value=""></option>
                        <option value="none">none</option>
                        <option value="auto">auto</option>
                        <option value="avoid">avoid</option>
                        <option value="avoid-page">avoid-page</option>
                        <option value="avoid-column">avoid-column</option>
                        <option value="avoid-region">avoid-region</option>
                        <option value="inherit">inherit</option>
                        <option value="initial">initial</option>
                        <option value="unset">unset</option>
                    </select>   
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">
                ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `
                        <h5 style="width:235px;height:160px;font-size:60%;border: 1px solid #c3c3c3; padding:1rem;${css}" @click="${this.clickGallery}" .gallery=${css}>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor incididunt ut labore et dolore magnaaliqua.</h5>
                        `;
        }))}
            </div>
        
        `;
    }
    onChangeProp(obj) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.emitEvent(obj);
        }, 500);
    }
    onChangeProp2(prop) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            if (!this.shadowRoot)
                return;
            const el = this.shadowRoot.querySelector('*[prop="' + prop + '"]');
            this.emitEvent({ key: prop, value: el.value });
        }, 500);
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
    clickGallery(e) {
        const el = e.target;
        if (!el)
            return;
        const css = el.gallery;
        if (!css)
            return;
        const commands = css.split(';');
        const changes = [];
        commands.forEach((item) => {
            const [key, value] = item.split(':');
            if (!key)
                return;
            changes.push({
                key: key.trim(),
                value: value.trim()
            });
        });
        const rc = {
            emitter: 'right',
            value: changes,
            helper: this.helper
        };
        this.setValues(changes);
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
};
ServiceDsStyleColumn.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsStyleColumn.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleColumn.prototype, "helper", void 0);
ServiceDsStyleColumn = __decorate([
    customElement('service-ds-style-column-100554')
], ServiceDsStyleColumn);
export { ServiceDsStyleColumn };
