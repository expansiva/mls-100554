/// <mls shortName="wcInputDate" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaFormsInputDateBase } from './_100554_icaFormsInputDateBase';
import { propertyDataSource, propertyCompositeDataSource } from './_100554_icaLitElement';
let WCInputDateRange = class WCInputDateRange extends IcaFormsInputDateBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-input-date-100554{display:block}wc-input-date-100554 .input_control{display:block;width:calc(100% - 1.5rem - 1px);padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;-webkit-appearance:none;-moz-appearance:none;appearance:none;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}wc-input-date-100554 .form_error_message{color:red}`);
        this.name = '';
        this.label = '';
        this.pattern = '';
        this.errormessage = 'Data inválida';
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.hint = '';
        this.error = '';
    }
    render() {
        return html `
        <label class="form-control-label">${this.label}</label>
        <input
            class="input_control"
            type="date"
            name=${ifDefined(this.name)}
            ?disabled=${this.disabled}
            ?readonly=${this.readonly}
            ?required=${this.required}
            min=${ifDefined(this.minvalue)}
            max=${ifDefined(this.maxvalue)}
            value=${this.value}
            ?autofocus=${this.autofocus}
            pattern=${ifDefined(this.pattern)}
            @input=${this.handleChange}
        />
        <small class="form_hint">${this.hint}</small>
        <div class="form_error_message">${this.error}</div>
        `;
    }
    handleChange() {
        if (!this.input)
            return;
        const newval = this.input.value;
        if (this.isValidDate(newval)) {
            this.value = newval;
            this.error = '';
            this.dispatchEvent(new CustomEvent('change', { detail: this.value }));
        }
        else {
            this.error = this.errormessage || '';
        }
        this.requestUpdate();
    }
    isValidDate(value) {
        if (!value)
            return false;
        const date = new Date(value);
        const minDate = this.minvalue ? new Date(this.minvalue) : null;
        const maxDate = this.maxvalue ? new Date(this.maxvalue) : null;
        return (!minDate || date >= minDate) && (!maxDate || date <= maxDate);
    }
};
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "name", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WCInputDateRange.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "errormessage", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "maxvalue", void 0);
__decorate([
    property({ type: String })
], WCInputDateRange.prototype, "minvalue", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WCInputDateRange.prototype, "autofocus", void 0);
__decorate([
    propertyCompositeDataSource({ type: String })
], WCInputDateRange.prototype, "hint", void 0);
__decorate([
    propertyDataSource({ type: String })
], WCInputDateRange.prototype, "value", void 0);
__decorate([
    query('input[type="date"]')
], WCInputDateRange.prototype, "input", void 0);
WCInputDateRange = __decorate([
    customElement('wc-input-date-100554')
], WCInputDateRange);
export { WCInputDateRange };
