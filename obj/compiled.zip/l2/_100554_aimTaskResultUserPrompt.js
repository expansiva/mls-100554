/// <mls shortName="aimTaskResultUserPrompt" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeSnippet100554 } from './_100554_collabShowCodeSnippet';
/// **collab_i18n_start**
const message_pt = {
    tryagain_placeholder: "Digite aqui seu prompt.",
    btn_confirmar: "Enviar novo prompt",
    btn_ok: "Finalizar",
};
const message_en = {
    tryagain_placeholder: "Type your prompt here.",
    btn_confirmar: "Send new prompt",
    btn_ok: "Close",
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let AimTaskResulUserPrompt = class AimTaskResulUserPrompt extends AimTaskBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.result = '';
        initCollabShowCodeSnippet100554();
    }
    onInitializing() {
        if (this.taskChild.mode !== 'error' && this.taskChild.mode !== 'processed') {
            this.taskRoot.mode = this.taskChild.mode = 'waiting for user';
        }
        this.openMe();
    }
    renderBody(taskRoot, child) {
        this.modeInternal = this.taskRoot.mode;
        const body = child.result || '';
        this.result = body;
        const chat = this.prepareChat(taskRoot);
        return html `
            <div>
                ${chat.map((item) => {
            if (item.answer) {
                return html `
                    <div style="display: flex;flex-direction: column;align-items: flex-end;gap: .25rem;width: 100%;margin-top: 2rem;">
                        <div style="background:#f4f4f4;max-width: 70%; padding:1.25rem .625rem;border-radius: 1.5rem;">
                            ${item.answer}
                        </div>
                    </div>
                `;
            }
            else {
                return html `
                    <div style="margin-top: 1rem;">
                        ${unsafeHTML(this.formatText(item.response.trim()))}
                    </div>
                `;
            }
        })}
            </div>
            <hr>

            ${this.modeInternal === "waiting for user" ?
            html `
                <div style='margin: 10px;'>
                    <div>
                        <textarea rows="5" placeholder=${this.msg.tryagain_placeholder} style="width:100%"></textarea>
                    </div>
                    <br>
                    <div class="buttonGroup">
                        <button @click="${this.handleCancel}">${this.msg.btn_ok}</button>
                        <button @click="${this.handleConfirm}">${this.msg.btn_confirmar}</button>
                    </div>
                </div> 
                    `
            : ''}
    
        `;
    }
    prepareChat(taskRoot) {
        const rc = [];
        for (let i = 0; i < taskRoot.children.length; i++) {
            const item = taskRoot.children[i];
            const chatItem = {
                answer: '',
                response: '',
            };
            if (item.widget === '_100554_aimTaskExecLLM')
                chatItem.answer = item.prompt || '';
            else if (item.widget === '_100554_aimTaskResultUserPrompt')
                chatItem.response = item.result || '';
            rc.push(chatItem);
        }
        return rc;
    }
    formatText(text) {
        // Regular expression to find code blocks within ```[language] ... ```
        const regex = /```(\w+)\n([\s\S]*?)\n```/g;
        // Replacement function for code blocks
        const replaceCodeBlock = (match, language, code) => {
            return `<collab-show-code-snippet-100554 language="${language}">\n${code}\n</collab-show-code-snippet-100554>`;
        };
        // Replace code blocks with <collab-show-code-snippet-100554> tag
        let formattedText = text.replace(regex, replaceCodeBlock);
        return formattedText;
    }
    openMe() {
        const det = this.closest('details');
        const detInternal = this.querySelector('details');
        if (det)
            det.open = true;
        if (detInternal)
            detInternal.open = true;
    }
    closeMe() {
        const det = this.querySelector('details');
        if (det)
            det.open = false;
    }
    handleCancel() {
        this.notifyCompleteByStatus('ok', this.result);
    }
    handleConfirm() {
        let prompt = '';
        if (this.textarea)
            prompt = this.textarea.value;
        this.notifyCompleteByStatus('userEvent', this.result, prompt);
        this.closeMe();
    }
};
__decorate([
    query('textarea')
], AimTaskResulUserPrompt.prototype, "textarea", void 0);
__decorate([
    property({ type: String, reflect: true })
], AimTaskResulUserPrompt.prototype, "modeInternal", void 0);
AimTaskResulUserPrompt = __decorate([
    customElement('aim-task-result-user-prompt-100554')
], AimTaskResulUserPrompt);
export { AimTaskResulUserPrompt };
