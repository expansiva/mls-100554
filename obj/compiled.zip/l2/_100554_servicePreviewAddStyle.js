/// <mls shortName="servicePreviewAddStyle" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
export const initServicePreviewAddStyle = '';
/// **collab_i18n_start**
const message_pt = {
    groupAndSubgroup: 'Grupo e subgrupo',
    tagsForSearch: 'Tags para busca',
    exInputList: 'ex: entrada, lista',
    addInDesingSystem: 'Adicionar no Sistema de Design',
    thisComponentAlreadyHasStyleAdded: 'Este componente já tem estilo adicionado',
    notAdded: 'Este componente não é adicionado no Design System, adicione abaixo'
};
const message_en = {
    groupAndSubgroup: 'Group and subgroup',
    tagsForSearch: 'Tags for search',
    exInputList: 'ex: input,list',
    addInDesingSystem: 'Add in Desing System',
    thisComponentAlreadyHasStyleAdded: 'This component already has style added',
    notAdded: 'This component is not added in Design System, please add below'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreviewAddStyle = class ServicePreviewAddStyle extends LitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.father = undefined;
        this.widget = '';
        this.level = '';
        this.tags = [];
        this.error = '';
        this.groupName = '';
        this.styleAlready = false;
        this.setTimeLoader = -1;
    }
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    render() {
        const lang = this.father.getMessageKey(messages);
        this.msg = lang ? messages[lang] : message_en;
        if (this.styleAlready)
            return this.renderStyleAlreadyr();
        else
            return this.renderAdd();
    }
    renderStyleAlreadyr() {
        return html `<h3>${this.msg.thisComponentAlreadyHasStyleAdded}</h3>`;
    }
    renderAdd() {
        return html `
            <div>
                <h4 style="text-align:center">${this.msg.notAdded}</h4>
                <span>${this.msg.groupAndSubgroup}</span>
                <input type="text" class="inputGroup" .value="${this.groupName}"></input>
            </div>
            <div style="display:flex; flex-direction: column;">
                <span>${this.msg.tagsForSearch}</span>
                <mls-input-tags>
                    ${repeat(this.tags, ((item) => item), ((vl, index) => this.renderItemTag(vl, index)))}
                    <input type="text" @keydown="${this.addInputTag}"></input>
                </mls-input-tags>
                <span style="font-size:.8rem; color: #595959;">${this.msg.exInputList}</span>
            </div>
            <div style="display:flex; justify-content:center;">
                <button @click="${this.addComponent}">${this.msg.addInDesingSystem}</button>
            </div>
            <h3 style="color:red">${this.error}</h3>
        `;
    }
    renderItemTag(vl, idx) {
        return html `
            <div>
                ${vl}
                <span .idx="${idx}" @click="${this.deleteItemTag}">x</span>
            </div>
        `;
    }
    //-----------IMPLEMENTS---------------
    async init() {
        try {
            this.showLoader(true);
            await this.initds();
            await this.getGroup();
            this.verifyAlready();
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
        }
    }
    verifyAlready() {
        if (!this.widget || !this.dsInstance)
            return;
        const componentName = this.widget;
        const comp = this.dsInstance.components.find(componentName);
        if (!comp)
            this.styleAlready = false;
    }
    async getGroup() {
        mls.actual[0].setFullName(this.widget);
        const model = mls.l2.editor.get({ project: mls.actual[0].project, shortName: mls.actual[0].path });
        if (!model || !model.compilerResults)
            return;
        if (!model.compilerResults.tripleSlashMLS)
            return;
        const { variables } = model.compilerResults.tripleSlashMLS;
        if (!variables)
            return;
        const { groupName } = variables;
        if (!groupName)
            return;
        this.groupName = groupName;
    }
    async initds() {
        this.dsInstance = mls.l3.getDSInstance(mls.actual[5].project, mls.actual[3].mode);
    }
    addInputTag(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const { value } = el;
        if (e.keyCode === 13) {
            this.addTag(value);
            el.value = '';
        }
        else if (e.keyCode === 188) {
            e.preventDefault();
            this.addTag(value);
            el.value = '';
        }
        else if (e.keyCode === 8 && value.length === 0) {
            this.deleteTag(this.tags.length - 1);
        }
    }
    addTag(vl) {
        if (this.tags.includes(vl))
            return;
        this.tags.push(vl);
        this.tags = [...this.tags];
    }
    deleteTag(idx) {
        if (idx > this.tags.length || idx < 0)
            return;
        this.tags.splice(idx, 1);
        this.tags = [...this.tags];
    }
    deleteItemTag(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const idx = +el.idx;
        this.deleteTag(idx);
    }
    showLoader(show) {
        if (!this.father)
            return;
        clearTimeout(this.setTimeLoader);
        this.setTimeLoader = setTimeout(() => {
            this.father.loading = show;
        }, 200);
    }
    async addComponent() {
        if (!this.widget || !this.shadowRoot || !this.dsInstance)
            return;
        const group = this.shadowRoot.querySelector('.inputGroup');
        if (!group || !group.value)
            throw new Error('Not found group');
        this.showLoader(true);
        const componentName = this.widget;
        const widget = {
            docPath: '',
            examples: [],
            group: group.value,
            l4MarketingRef: '',
            name: componentName,
            reference: undefined,
            styles: [],
            tags: this.tags,
            widgetExampleRef: {
                path: '',
                tagname: ''
            }
        };
        try {
            await this.dsInstance.components.add(widget);
            this.styleAlready = true;
        }
        catch (err) {
            this.error = err.message;
        }
        finally {
            this.showLoader(false);
        }
    }
};
ServicePreviewAddStyle.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServicePreviewAddStyle.prototype, "father", void 0);
__decorate([
    property()
], ServicePreviewAddStyle.prototype, "widget", void 0);
__decorate([
    property()
], ServicePreviewAddStyle.prototype, "level", void 0);
__decorate([
    property({ type: Array })
], ServicePreviewAddStyle.prototype, "tags", void 0);
__decorate([
    property()
], ServicePreviewAddStyle.prototype, "error", void 0);
__decorate([
    property()
], ServicePreviewAddStyle.prototype, "groupName", void 0);
__decorate([
    property()
], ServicePreviewAddStyle.prototype, "styleAlready", void 0);
ServicePreviewAddStyle = __decorate([
    customElement('service-preview-add-style-100554')
], ServicePreviewAddStyle);
export { ServicePreviewAddStyle };
