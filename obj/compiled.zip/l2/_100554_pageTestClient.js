var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="pageTestClient" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { BECollabClient } from './_100554_beCollabClient';
let PageTestClient2100554 = class PageTestClient2100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.client = new BECollabClient();
    }
    render() {
        return html `
            <div style="margin-bottom:5px">
                <label>Body requisição</label>
                <input id="body" style="width:99%;padding:3px;outline:none"></input>
            </div>
            <button @click="${this.clickPost}">Post</button>
            <button @click="${this.clickPut}">Put</button>
            <button @click="${this.clickGet}">Get</button>
            <button @click="${this.clickDel}">Del</button>
            <div id="resposta" style="margin-top:10px; border:1px solid gray; padding:1rem"></div>
        `;
    }
    //{"nome":"GUILHERME", "senha":"123"}
    async clickPost() {
        if (!this.resposta || !this.body)
            return;
        try {
            this.clearLog();
            this.resposta.innerHTML = 'aguardando resposta...';
            const bd = JSON.parse(this.body.value);
            let ret = await this.client.request("/api/user", "POST", bd);
            if (typeof ret === 'object')
                ret = JSON.stringify(ret);
            this.resposta.innerHTML = ret;
        }
        catch (e) {
            this.errorLog(e.message);
        }
    }
    //{"id":1, "nome":"GUILHERME", "senha":"123"}
    async clickPut() {
        if (!this.resposta || !this.body)
            return;
        try {
            this.clearLog();
            this.resposta.innerHTML = 'aguardando resposta...';
            const bd = JSON.parse(this.body.value);
            let ret = await this.client.request("/api/user", "PUT", bd);
            if (typeof ret === 'object')
                ret = JSON.stringify(ret);
            this.resposta.innerHTML = ret;
        }
        catch (e) {
            this.errorLog(e.message);
        }
    }
    async clickGet() {
        if (!this.resposta || !this.body)
            return;
        try {
            this.clearLog();
            this.resposta.innerHTML = 'aguardando resposta...';
            let ret = await this.client.request("/api/user", "GET", this.body.value);
            if (typeof ret === 'object')
                ret = JSON.stringify(ret);
            this.resposta.innerHTML = ret;
        }
        catch (e) {
            this.errorLog(e.message);
        }
    }
    async clickDel() {
        if (!this.resposta || !this.body)
            return;
        try {
            this.clearLog();
            this.resposta.innerHTML = 'aguardando resposta...';
            let ret = await this.client.request("/api/user", "DELETE", this.body.value);
            if (typeof ret === 'object')
                ret = JSON.stringify(ret);
            this.resposta.innerHTML = ret;
        }
        catch (e) {
            this.errorLog(e.message);
        }
    }
    clearLog() {
        if (!this.resposta || !this.body)
            return;
        this.resposta.style.color = '';
        this.resposta.innerHTML = '';
    }
    errorLog(msg) {
        if (!this.resposta)
            return;
        this.resposta.style.color = 'red';
        this.resposta.innerHTML = msg;
    }
};
__decorate([
    query('#resposta')
], PageTestClient2100554.prototype, "resposta", void 0);
__decorate([
    query('#body')
], PageTestClient2100554.prototype, "body", void 0);
PageTestClient2100554 = __decorate([
    customElement('page-test-client-100554')
], PageTestClient2100554);
export { PageTestClient2100554 };
