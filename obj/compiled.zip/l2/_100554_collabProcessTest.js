/// <mls shortName="collabProcessTest" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { saveTest } from './_100554_libCommom';
let CollabProcessTest = class CollabProcessTest extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-process-test-100554{display:block}collab-process-test-100554 h3{text-align:center}collab-process-test-100554 div{display:flex;gap:.5rem;align-items:center;justify-content:center}collab-process-test-100554 div input{border-radius:2px;border:1px solid var(--bg-primary-color-disabled);width:300px;height:26px}collab-process-test-100554 textarea{margin-top:1rem;border-radius:2px;border:1px solid var(--bg-primary-color-disabled);width:500px;min-height:250px;outline:none;padding:.3rem}`);
        this.script = '';
    }
    render() {
        return html `
            <h3>Process Test</h3>
            <div>
                <label>Title</label>
                <input type="text" id="inputtitletest"/>
                <button @click="${this.onSave}">Save</button>
            </div>
            <div>
                <textarea id="textareascript" .value="${atob(this.script)}" spellcheck="false">
                </textarea>
            </div>
        `;
    }
    // -------IMPLEMENTATION--------
    async onSave() {
        if (!this.textareascript || !this.inputtitletest || !this.textareascript.value || !this.inputtitletest.value || !mls.actual[2].left) {
            alert('Need more information');
            return;
        }
        const f = mls.actual[2].left;
        const file = mls.stor.getKeyToFiles(f.project, 2, f.shortName, f.folder, '.html');
        const ret = await saveTest(file, this.textareascript.value, this.inputtitletest.value);
        if (ret !== 'ok')
            alert(ret);
        else {
            this.textareascript.value = '';
            this.inputtitletest.value = '';
            alert('Test saved!');
        }
    }
};
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "script", void 0);
__decorate([
    query('#textareascript')
], CollabProcessTest.prototype, "textareascript", void 0);
__decorate([
    query('#inputtitletest')
], CollabProcessTest.prototype, "inputtitletest", void 0);
CollabProcessTest = __decorate([
    customElement('collab-process-test-100554')
], CollabProcessTest);
export { CollabProcessTest };
