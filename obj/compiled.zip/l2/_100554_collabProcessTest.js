/// <mls shortName="collabProcessTest" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { getTestByFile, saveTest, updateTest } from './_100554_libCommom';
let CollabProcessTest = class CollabProcessTest extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-process-test-100554{display:block}collab-process-test-100554 h3{text-align:center}collab-process-test-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}collab-process-test-100554 button:hover{background-color:var(--grey-color-light)}collab-process-test-100554 .input-container{display:flex;gap:1rem}collab-process-test-100554 div{display:flex;gap:.5rem;align-items:center;justify-content:center}collab-process-test-100554 div input,collab-process-test-100554 div textarea{display:block;width:calc(100% - 1.5rem - 1px);padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;-webkit-appearance:none;-moz-appearance:none;appearance:none;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-process-test-100554 textarea{margin-top:1rem;border-radius:2px;border:1px solid var(--bg-primary-color-disabled);width:500px;min-height:250px;outline:none;padding:.3rem}`);
        this.script = '';
        this.mode = 'new';
        this.title = '';
        this.indexEdit = '';
        // -------IMPLEMENTATION--------
        this.actualTestList = [];
    }
    render() {
        return html `
            <h3>Process Test</h3>
            <div>
                <div class="input-container">
                    <label>Title</label>
                    <input type="text" .value=${this.title} id="inputTitle"/>
                </div>
                <button @click="${this.onSave}">Save</button>
            </div>
            <div>
                <textarea id="txtScript" .value="${this.script ? atob(this.script) : ''}" spellcheck="false">
                </textarea>
            </div>
        `;
    }
    async onSave() {
        if (this.mode === 'new') {
            this.onNew();
            return;
        }
        if (this.mode === 'edit') {
            this.onEdit();
        }
    }
    async onEdit() {
        if (!this.txtScript || !this.inputTitle || !this.txtScript.value || !this.inputTitle.value || !mls.actual[2].left) {
            alert('Need more information');
            return;
        }
        const { project, shortName } = mls.actual[2].left;
        this.actualTestList = await getTestByFile(project, shortName, '.html');
        const actualData = this.actualTestList[+this.indexEdit];
        if (!actualData)
            return;
        actualData.title = this.inputTitle.value;
        actualData.script = this.txtScript.value;
        try {
            const key = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
            await updateTest(key, +this.indexEdit, this.txtScript.value, this.inputTitle.value);
            alert('Test updated!');
        }
        catch (err) {
            alert(err.message);
        }
    }
    async onNew() {
        if (!this.txtScript || !this.inputTitle || !this.txtScript.value || !this.inputTitle.value || !mls.actual[2].left) {
            alert('Need more information');
            return;
        }
        const actualFile = mls.actual[2].left;
        const file = mls.stor.getKeyToFiles(actualFile.project, 2, actualFile.shortName, actualFile.folder, '.html');
        const ret = await saveTest(file, this.txtScript.value, this.inputTitle.value);
        if (ret !== 'ok')
            alert(ret);
        else {
            this.txtScript.value = '';
            this.inputTitle.value = '';
            alert('Test saved!');
        }
    }
};
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "script", void 0);
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "mode", void 0);
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "title", void 0);
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "indexEdit", void 0);
__decorate([
    query('#txtScript')
], CollabProcessTest.prototype, "txtScript", void 0);
__decorate([
    query('#inputTitle')
], CollabProcessTest.prototype, "inputTitle", void 0);
CollabProcessTest = __decorate([
    customElement('collab-process-test-100554')
], CollabProcessTest);
export { CollabProcessTest };
