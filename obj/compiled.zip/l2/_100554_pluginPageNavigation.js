/// <mls shortName="pluginPageNavigation" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, repeat } from 'lit';
import { convertTagToFileName } from './_100554_utilsLit';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { execute as executeDel } from './_100554_wcdCommandDel';
import { execute as executeAddTexto } from './_100554_wcdCommandEnter';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item ICA foi encontrado!'
};
const message_en = {
    noItens: 'No ICA items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export class PluginPageNavigation extends PluginBaseModule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-page-navigation-100554{padding:1rem;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-page-navigation-100554 ul{list-style:none;padding:0 0 0 .5rem;border-left:1px solid #d4d4d4}plugin-page-navigation-100554 ul li{position:relative;user-select:none}plugin-page-navigation-100554 ul li .header{border:1px solid transparent;padding:.4rem;cursor:pointer}plugin-page-navigation-100554 ul li .header:hover{border:1px solid #d4d4d4}plugin-page-navigation-100554 ul li .header .dragDropcontainer{display:none;gap:.5rem}plugin-page-navigation-100554 ul li .header.overdragdrop{display:flex !important;justify-content:space-between}plugin-page-navigation-100554 ul li .header.overdragdrop .dragDropcontainer{display:flex;gap:.5rem}plugin-page-navigation-100554 ul li .header .dragDropcontainer span{display:none;justify-content:center;align-items:center;width:20px}plugin-page-navigation-100554 ul li .header .dragDropcontainer.b .dbefore{display:flex !important}plugin-page-navigation-100554 ul li .header .dragDropcontainer.i .din{display:flex !important}plugin-page-navigation-100554 ul li .header .dragDropcontainer.a .dAfter{display:flex !important}plugin-page-navigation-100554 ul li div.activeBranch{border:1px solid #d4d4d4;display:flex;justify-content:space-between;align-items:center;border-radius:5px;background:var(--bg-primary-color-disabled);color:var(--text-primary-color)}plugin-page-navigation-100554 ul li:before{content:' ';position:absolute;width:7px;height:1px;background:#d4d4d4;top:1.2rem;left:-8px}plugin-page-navigation-100554 .groupHiddenList{border-radius:4px;padding:.3rem;transition:all .5s;cursor:pointer;display:none;z-index:9;height:.7rem}plugin-page-navigation-100554 ul li div.activeBranch .groupHiddenList{display:flex;align-items:center;position:relative}plugin-page-navigation-100554 .groupHiddenList::after{content:' ';width:23px;height:19px;position:absolute;right:-15px;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;background-position-y:center}plugin-page-navigation-100554 .groupHiddenList .mls-gpbtnslider-item{display:none;transition:.5s;margin-left:1rem;z-index:10;font-size:16px;line-height:normal}plugin-page-navigation-100554 .groupHiddenList .mls-gpbtnslider-item:hover{color:#1a83ff}plugin-page-navigation-100554 .groupHiddenList.activegpbtnslider{padding-right:24px;padding-left:8px}plugin-page-navigation-100554 .groupHiddenList.activegpbtnslider .mls-gpbtnslider-item{display:inherit;text-align:center;float:left}plugin-page-navigation-100554 mic-command{background-image:url("data:image/svg+xml;charset=UTF-8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 640 512'><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d='M38.8 5.1C28.4-3.1 13.3-1.2 5.1 9.2S-1.2 34.7 9.2 42.9l592 464c10.4 8.2 25.5 6.3 33.7-4.1s6.3-25.5-4.1-33.7L472.1 344.7c15.2-26 23.9-56.3 23.9-88.7l0-40c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 40c0 21.2-5.1 41.1-14.2 58.7L416 300.8 416 96c0-53-43-96-96-96s-96 43-96 96l0 54.3L38.8 5.1zM344 430.4c20.4-2.8 39.7-9.1 57.3-18.2l-43.1-33.9C346.1 382 333.3 384 320 384c-70.7 0-128-57.3-128-128l0-8.7L144.7 210c-.5 1.9-.7 3.9-.7 6l0 40c0 89.1 66.2 162.7 152 174.4l0 33.6-48 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l72 0 72 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-48 0 0-33.6z'/></svg>");background-repeat:no-repeat;background-position:center;background-size:contain;width:20px;height:20px;display:block;cursor:pointer}plugin-page-navigation-100554 mic-command.active{background-image:url("data:image/svg+xml;charset=UTF-8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d='M192 0C139 0 96 43 96 96l0 160c0 53 43 96 96 96s96-43 96-96l0-160c0-53-43-96-96-96zM64 216c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 40c0 89.1 66.2 162.7 152 174.4l0 33.6-48 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l72 0 72 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-48 0 0-33.6c85.8-11.7 152-85.3 152-174.4l0-40c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 40c0 70.7-57.3 128-128 128s-128-57.3-128-128l0-40z'/></svg>") !important}`);
        this.msg = messages['en'];
        this.idLastClick = '';
        //--------COMMANDS-------------------
        this.commands = {
            selecionar: {
                item: this.cmdSelectItem.bind(this)
            },
            setar: {
                color: this.cmdSetCor.bind(this),
                background: this.cmdSetBackground.bind(this),
                margem: {
                    top: (vl) => { this.processStyle('margin-top', vl.replace(/ /g, '')); },
                    button: (vl) => { this.processStyle('margin-bottom', vl.replace(/ /g, '')); },
                    botton: (vl) => { this.processStyle('margin-bottom', vl.replace(/ /g, '')); },
                    left: (vl) => { this.processStyle('margin-left', vl.replace(/ /g, '')); },
                    white: (vl) => { this.processStyle('margin-right', vl.replace(/ /g, '')); },
                    right: (vl) => { this.processStyle('margin-right', vl.replace(/ /g, '')); },
                },
                texto: this.setTexto.bind(this),
            },
            adicionar: {
                elemento: {
                    texto: this.cmdAddTexto.bind(this)
                }
            },
            deletar: this.cmdDel.bind(this)
        };
        this.activationWord = "comando";
        this.setEvents();
        //this.setVoice()
    }
    setEvents() {
        mls.events.addListener(3, 'WCDEventChange', (ev) => this.onWCDEventChange(ev));
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onlevelChange(ev));
    }
    onlevelChange(ev) {
        if (!ev.desc)
            return;
        const j = JSON.parse(ev.desc);
        if (j.level === 3) {
            this.forceUpdate();
        }
    }
    onWCDEventChange(ev) {
        if (this && this.forceUpdate)
            this.forceUpdate();
    }
    //-------COMPONENT----------
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const ar = this.getICAComponents();
        if (ar && ar.length > 0)
            return this.createNavigation(ar);
        return html `<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
    }
    createNavigation(array) {
        //<mic-command @click="${this.startRecognition}"></mic-command>
        const obj = html `
            
            <ul>
                ${repeat(array, ((key, idx) => key.el.tagName + idx), ((item, index) => { return this.renderItemTree(item, index); }))}
            </ul>
        `;
        return obj;
    }
    renderItemTree(item, idx) {
        const name = convertTagToFileName(item.el.tagName.toLocaleLowerCase());
        const cls = item.el.renderType === 'editactive' ? 'activeBranch' : '';
        if (this.idLastClick === name + idx) { // Verifico se preciso forçar um click
            setTimeout(() => {
                const active = this.querySelector('.activeBranch');
                if (active)
                    active.classList.remove('activeBranch');
                this.idLastClick = '';
                item.el.click();
            }, 200);
        }
        let mySymbol = 'fa-cubes';
        if (item.el.mySymbol)
            mySymbol = item.el.mySymbol;
        return html `
            <li>
                <div id="${name + idx}" .info=${item} @mouseover="${this.mouseOver}" @mouseleave="${this.mouseLeave}" class="header ${cls}" @click="${(e) => this.selectItem(e, item)}">
                    <info-item .info=${item}><span class="fa ${mySymbol}" style="margin-right:.5rem"></span>${name}</info-item>
                    <div class="dragDropcontainer">
                        <span class="dbefore fa fa-arrow-up"></span>
                        <span class="din fa fa-arrow-turn-down"></span>
                        <span class="dAfter fa fa-arrow-down"></span>
                    </div>
                    <div class="groupHiddenList" .info=${item} @click="${this.clickGroupHidden}">
                        <span class="mls-gpbtnslider-item fa fa-up-down-left-right" title="move" @click="${this.activeMove}" style="display:none"></span>
                        
                        <span class="mls-gpbtnslider-item fa fa-trash" @click="${this.delEl}" title="remove"></span>
                    </div>
                </div>
                <ul>
                    ${repeat(item.children, ((c, idx) => c.el.tagName + idx), ((i, idxI) => {
            return this.renderItemTree(i, idx + '_' + idxI);
        }))}
                </ul>
            </li>
        `;
        //<span class="mls-gpbtnslider-item fa classLock" @click="${this.setLock}"></span>
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.requestUpdate();
    }
    getICAComponents() {
        let ret = [];
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return ret;
        const reentrance = (array, element) => {
            let info;
            const tag = element.tagName.toLowerCase();
            if (tag.startsWith('ica') && !tag.startsWith('ica-page-overlay')) {
                info = { el: element, children: [] };
                array.push(info);
            }
            const isGroup = element.getAttribute('isFCAGroup');
            if (!isGroup || isGroup === 'false') {
                if (element.shadowRoot) {
                    const children = Array.from(element.shadowRoot.children);
                    for (let i = 0; i < children.length; i++) {
                        const child = children[i];
                        reentrance(info ? info.children : array, child);
                    }
                }
                else {
                    const children = Array.from(element.children);
                    for (let i = 0; i < children.length; i++) {
                        const child = children[i];
                        reentrance(info ? info.children : array, child);
                    }
                }
            }
        };
        reentrance(ret, scope);
        return ret;
    }
    selectItem(e, item) {
        e.stopPropagation();
        let target = e.target;
        if (target && target.className.indexOf('header') < 0) {
            target = target.closest('.header');
        }
        if (!target)
            return;
        const active = this.querySelector('.activeBranch');
        if (active && active === target)
            return;
        if (active)
            active.classList.remove('activeBranch');
        target.classList.add('activeBranch');
        item.el.style.border = '';
        const father = item.el.closest('*[rendertype="editactive"]');
        if (father) {
            this.idLastClick = target.id;
            item.el.overlayRef?.click();
            item.el.overlayRef?.scrollIntoView({ block: 'center' });
        }
        else {
            item.el.overlayRef?.click();
            item.el.overlayRef?.scrollIntoView({ block: 'center' });
        }
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        el.classList.toggle('activegpbtnslider');
        if (!el.info)
            return;
        let lock = 'fa-lock-open';
        const isGroup = el.info.el.getAttribute('isFCAGroup');
        if (isGroup || isGroup === 'true') {
            lock = 'fa-lock';
        }
        const group = el.querySelector('.classLock');
        if (group) {
            group.classList.remove('fa-lock');
            group.classList.remove('fa-lock-open');
            group.title = lock === 'fa-lock' ? 'lock' : 'lock open';
            group.classList.add(lock);
        }
    }
    setLock(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const info = el.parentElement.info;
        if (!info)
            return;
        const isGroup = (el.className.indexOf('fa-lock-open') < 0);
        info.el.setAttribute('isFCAGroup', (!isGroup).toString());
        let lock = 'fa-lock-open';
        if (!isGroup) {
            lock = 'fa-lock';
        }
        el.classList.remove('fa-lock');
        el.classList.remove('fa-lock-open');
        el.title = lock === 'fa-lock' ? 'lock' : 'lock open';
        el.classList.add(lock);
        this.requestUpdate();
    }
    delEl(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const info = el.parentElement.info;
        if (!info)
            return;
        info.el.remove();
        this.requestUpdate();
    }
    activeMove(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const info = el.parentElement.info;
        if (!info)
            return;
        const wc = info.el.querySelector('wcd-toolbox-100554');
        if (!wc || !wc.shadowRoot)
            return;
        const move = wc.shadowRoot.querySelector('wcd-toolbox-item-action-move-100554');
        if (move)
            move.click();
        setTimeout(() => {
            this.setDragDrop(info.el);
        }, 500);
    }
    setDragDrop(active) {
        const dragStart = (e, el) => {
            e.stopPropagation();
            if (!el.info)
                return;
            el.style.opacity = '0.4';
        };
        const dragEnter = (e, el) => {
            e.stopPropagation();
            const elLast = this.querySelector('.overdragdrop');
            if (elLast)
                elLast.classList.remove('overdragdrop');
            el.classList.add('overdragdrop');
        };
        const dragLeave = (e, el) => {
            e.stopPropagation();
            //el.classList.remove('overdragdrop');
        };
        const dragOver = (e, el) => {
            e.stopPropagation();
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            return false;
        };
        const dragDrop = (e, el, mode) => {
            e.stopPropagation();
            if (!el.info)
                return;
            mode.click();
            return false;
        };
        const dragEnd = (e, el) => {
            e.stopPropagation();
            try {
                //mls.events.fire(2,'DSStyleChanged','{"emitter":"left"}',500);
                Array.from(listItens).forEach((el) => {
                    el.removeAttribute('draggable');
                    el.classList.remove('overdragdrop');
                    el.style.opacity = '';
                    el.ondragstart = () => { };
                    el.ondragenter = () => { };
                    el.ondragover = () => { };
                    el.ondragleave = () => { };
                    const elbefore = el.querySelector('.dbefore');
                    const elafter = el.querySelector('.dAfter');
                    const elinn = el.querySelector('.din');
                    if (elbefore) {
                        elbefore.removeAttribute('draggable');
                        elbefore.ondrop = (e) => { };
                    }
                    if (elafter) {
                        elafter.removeAttribute('draggable');
                        elafter.ondrop = (e) => { };
                    }
                    if (elinn) {
                        elinn.removeAttribute('draggable');
                        elinn.ondrop = (e) => { };
                    }
                    const cont = el.querySelector('.dragDropcontainer');
                    if (cont) {
                        cont.classList.remove('b');
                        cont.classList.remove('a');
                        cont.classList.remove('i');
                    }
                    if (el.info) {
                        const elBase = el.info.el;
                        if (!elBase)
                            return;
                        if (elBase.getAttribute('renderType') === 'editactive')
                            return;
                        elBase.style.position = '';
                        const content = elBase.querySelector(':scope > wcd-dragdrop-aux');
                        if (!content)
                            return;
                        content.remove();
                    }
                });
            }
            catch (e) {
                this.requestUpdate();
            }
        };
        const addEventsDragAndDrop = (el) => {
            if (!el.info)
                return;
            const rtp = el.info.el.getAttribute('rendertype');
            const wcd = el.info.el.querySelector(':scope > wcd-dragdrop-aux');
            if (!wcd && rtp === 'edit')
                return;
            const before = wcd ? wcd.querySelector('wcd-dragdrop-aux-before') : undefined;
            const after = wcd ? wcd.querySelector('wcd-dragdrop-aux-after') : undefined;
            const inn = wcd ? wcd.querySelector('wcd-dragdrop-aux-in') : undefined;
            const elbefore = el.querySelector('.dbefore');
            const elafter = el.querySelector('.dAfter');
            const elinn = el.querySelector('.din');
            const cont = el.querySelector('.dragDropcontainer');
            if (cont && before)
                cont.classList.add('b');
            if (cont && after)
                cont.classList.add('a');
            if (cont && inn)
                cont.classList.add('i');
            if (active === el.info.el) {
                el.ondragstart = (e) => dragStart(e, el);
            }
            if (active !== el.info.el) {
                el.ondragenter = (e) => dragEnter(e, el);
                el.ondragover = (e) => dragOver(e, el);
                el.ondragleave = (e) => dragLeave(e, el);
                if (before && elbefore) {
                    elbefore.setAttribute('draggable', 'true');
                    elbefore.ondrop = (e) => dragDrop(e, el, before);
                }
                if (after && elafter) {
                    elafter.setAttribute('draggable', 'true');
                    elafter.ondrop = (e) => dragDrop(e, el, after);
                }
                if (inn && elinn) {
                    elinn.setAttribute('draggable', 'true');
                    elinn.ondrop = (e) => dragDrop(e, el, inn);
                }
            }
            el.ondragend = (e) => dragEnd(e, el);
        };
        const listItens = this.querySelectorAll('.header');
        Array.from(listItens).forEach((el) => {
            el.setAttribute('draggable', 'true');
            addEventsDragAndDrop(el);
        });
    }
    mouseOver(e) {
        e.preventDefault();
        e.stopPropagation();
        let el = e.target;
        if (el && el.className.indexOf('header') < 0) {
            el = el.closest('.header');
        }
        let inOver = el.getAttribute('inOver');
        if (!inOver)
            inOver = 'false';
        if (!el || !el.info || inOver === 'true' || el.className.indexOf('activeBranch') >= 0)
            return;
        //el.info.el.style.border = '1px solid blue';
        el.info.el.style.boxShadow = '0px 0px 2px #0909dd';
    }
    mouseLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        let el = e.target;
        if (el && el.className.indexOf('header') < 0) {
            el = el.closest('.header');
        }
        el.removeAttribute('inOver');
        //el.info.el.style.border = '';
        el.info.el.style.boxShadow = '';
    }
    setTexto(vl) {
        if (!window.preview || !window.preview.iframe || !window.preview.iframe.contentWindow.wcdState || !window.preview.iframe.contentWindow.wcdState.elICA)
            return;
        const ica = window.preview.iframe.contentWindow.wcdState.elICA;
        if (!ica || !ica.overlayRef)
            return;
        if (ica.tagName.toLocaleLowerCase() !== 'ica-apresentation-text-text-100554')
            return;
        console.info(ica);
        ica.setAttribute('text', vl);
        ica.requestUpdate();
    }
    cmdDel() {
        if (!window.preview || !window.preview.iframe || !window.preview.iframe.contentWindow.wcdState || !window.preview.iframe.contentWindow.wcdState.elICA)
            return;
        const ica = window.preview.iframe.contentWindow.wcdState.elICA;
        if (!ica || !ica.overlayRef)
            return;
        const param = {
            args: new KeyboardEvent('keydown', {
                key: 'Del',
                code: 'Del',
                keyCode: 13,
                bubbles: true,
                cancelable: true,
                composed: true,
            }),
            overlay: ica.overlayRef.parentElement,
            selectedIca: ica
        };
        executeDel(param);
    }
    cmdAddTexto() {
        if (!window.preview || !window.preview.iframe || !window.preview.iframe.contentWindow.wcdState || !window.preview.iframe.contentWindow.wcdState.elICA)
            return;
        const ica = window.preview.iframe.contentWindow.wcdState.elICA;
        if (!ica || !ica.overlayRef)
            return;
        const param = {
            args: new KeyboardEvent('keydown', {
                key: 'Enter',
                code: 'Enter',
                keyCode: 13,
                bubbles: true,
                cancelable: true,
                composed: true,
            }),
            overlay: ica.overlayRef.parentElement,
            selectedIca: ica
        };
        executeAddTexto(param);
        this.requestUpdate();
    }
    cmdSetCor(color) {
        try {
            this.processStyle('color', color);
        }
        catch (e) { }
    }
    cmdSetBackground(color) {
        try {
            this.processStyle('background', color);
        }
        catch (e) { }
    }
    processStyle(attr, value) {
        const active = this.querySelector('.activeBranch');
        if (!active)
            return;
        const el = active.querySelector('info-item');
        if (!el)
            return;
        const info = el.info;
        if (!info)
            return;
        const css = info.el.getAttribute('styleel');
        const t = document.createElement('div');
        t.style.cssText = css || '';
        t.style[attr] = value;
        info.el.setAttribute('styleel', t.style.cssText);
    }
    cmdSelectItem(item) {
        try {
            console.info('cmdSelectItem', item);
            const child = ((+item) - 1);
            const all = this.querySelectorAll('li');
            if (!all[child])
                return;
            const el = all[child].querySelector('.header');
            if (el)
                el.click();
        }
        catch (e) {
        }
    }
    setVoice() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (SpeechRecognition) {
            this.recognition = new SpeechRecognition();
            this.recognition.lang = 'pt-BR';
            this.recognition.interimResults = true;
            this.recognition.continuous = true;
            this.recognition.onresult = (event) => this.onSucessVoice(event);
            this.recognition.onerror = (event) => {
                console.error("Erro no reconhecimento de voz:", event.error);
            };
        }
        else {
            console.error("API de Reconhecimento de Voz não é suportada neste navegador.");
        }
    }
    onSucessVoice(event) {
        for (let i = event.resultIndex; i < event.results.length; i++) {
            if (event.results[i].isFinal) {
                const transcript = event.results[i][0].transcript.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");
                console.info("Comando reconhecido:", transcript);
                if (transcript.startsWith(this.activationWord)) {
                    const command = transcript.replace(this.activationWord, "").trim();
                    this.processCommand(command);
                }
                else {
                    console.info(`Aguardando a palavra-chave "${this.activationWord}" para ativar.`);
                }
            }
        }
    }
    processCommand(phrase) {
        const words = phrase.toLowerCase().split(" ");
        let current = this.commands;
        for (let i = 0; i < words.length; i++) {
            let word = words[i];
            if (current[word]) {
                current = current[word];
                if ((i + 1) === words.length && typeof current === "function") {
                    current();
                    return;
                }
            }
            else if (typeof current === "function") {
                current(words.slice(i, words.length).join(' '));
                return;
            }
        }
        //console.error("Comando não encontrado.");
    }
    startRecognition(ev) {
        let el = ev.target;
        if (el.tagName.toLocaleLowerCase() !== 'mic-command') {
            el = el.closest('mic-command');
        }
        if (el.classList.contains('active')) {
            el.classList.remove('active');
            if (this.recognition)
                this.recognition.stop();
        }
        else {
            el.classList.add('active');
            this.recognition.start();
            console.log("Aguardando comando de voz...");
        }
    }
}
if (!customElements.get('plugin-page-navigation-100554')) {
    customElements.define('plugin-page-navigation-100554', PluginPageNavigation);
}
