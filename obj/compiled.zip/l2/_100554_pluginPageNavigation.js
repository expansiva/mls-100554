/// <mls shortName="pluginPageNavigation" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { collab_trash, collab_pencil, collab_bars } from './_100554_collabIcons';
import { convertTagToFileName, convertFileNameToTag } from './_100554_utilsLit';
import { selectLevel, openService } from './_100554_libCommom';
import { formatHtml, setValueInModeKeepingUndo } from './_100554_collabDOMSync';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item foi encontrado!'
};
const message_en = {
    noItens: 'No items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginNavigationRenderOrganism = class PluginNavigationRenderOrganism extends PluginBaseModule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-page-navigation-100554{padding:1rem;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-page-navigation-100554 ul{list-style:none;padding:0 0 0 .5rem;border-left:1px solid #d4d4d4}plugin-page-navigation-100554 ul li.nav-item{position:relative;user-select:none}plugin-page-navigation-100554 ul li.nav-item .move-icon{opacity:0;cursor:grab;margin-right:.1rem;font-size:1rem;user-select:none}plugin-page-navigation-100554 ul li.nav-item .header:hover .move-icon{opacity:1}plugin-page-navigation-100554 ul li.nav-item[draggable="true"] .move-icon:active{cursor:grabbing}plugin-page-navigation-100554 ul li.nav-item small{font-weight:700;font-size:11px}plugin-page-navigation-100554 ul li .header{border:1px solid transparent;padding:.4rem;cursor:pointer}plugin-page-navigation-100554 ul li .header:hover{border:1px solid #d4d4d4}plugin-page-navigation-100554 ul li div.activeBranch{border:1px solid #d4d4d4;display:flex;justify-content:start;align-items:center;border-radius:5px;background:var(--bg-primary-color-disabled);color:var(--text-primary-color)}plugin-page-navigation-100554 ul li:before{content:' ';position:absolute;width:7px;height:1px;background:#d4d4d4;top:1.2rem;left:-8px}plugin-page-navigation-100554 .groupHiddenList{border-radius:4px;padding:.3rem;transition:all .5s;cursor:pointer;display:none;z-index:9;height:.7rem;margin-left:auto}plugin-page-navigation-100554 ul li div.activeBranch .groupHiddenList{display:flex;align-items:center;position:relative}plugin-page-navigation-100554 .groupHiddenList::after{content:' ';width:23px;height:19px;position:absolute;right:-15px;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;background-position-y:center}plugin-page-navigation-100554 .groupHiddenList .mls-gpbtnslider-item{display:none;transition:.5s;margin-left:1rem;z-index:10;font-size:16px;line-height:normal}plugin-page-navigation-100554 .groupHiddenList .mls-gpbtnslider-item:hover{color:#1a83ff}plugin-page-navigation-100554 .groupHiddenList.activegpbtnslider{padding-right:24px;padding-left:8px}plugin-page-navigation-100554 .groupHiddenList.activegpbtnslider .mls-gpbtnslider-item{display:inherit;text-align:center;float:left}plugin-page-navigation-100554 info-item{display:block;white-space:nowrap;width:100%;overflow:hidden;text-overflow:ellipsis;transition:width 2s}`);
        this.msg = messages['en'];
        this.atributeBase = 'id';
        this.nodes = [];
        //-------COMPONENT----------
        this.activeId = '';
        this.dropPosition = 'after';
        this.setEvents();
    }
    setEvents() {
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onlevelChange(ev));
        mls.events.addListener(4, 'L4EditEvents', this.onL4EditEvents.bind(this));
    }
    onL4EditEvents(ev) {
        if (!ev.desc || ev.level !== 4)
            return;
        const info = JSON.parse(ev.desc);
        if (!info || !info.action || !info.position || info.position === 'left')
            return;
        switch (info.action) {
            case ('select'):
                this.onSelect(info);
                break;
            case ('navigation'):
                this.onNavigation(info);
                break;
        }
    }
    onSelect(info) {
        if (!info.id)
            return;
        const els = this.querySelectorAll('.activeBranch');
        els.forEach((el) => el.classList.remove('activeBranch'));
        this.activeId = info.id;
    }
    onNavigation(info) {
        this.requestUpdate();
    }
    onlevelChange(ev) {
        if (!ev.desc)
            return;
        const j = JSON.parse(ev.desc);
        if (j.level === 3) {
            this.forceUpdate();
        }
    }
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        this.nodes = await this.getComponents();
        this.tabIndex = 0;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.nodes && this.nodes.length > 0)
            return this.createNavigation(this.nodes);
        return html `<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
    }
    createNavigation(array) {
        const obj = html `
            
            <ul>
                ${repeat(array, ((key, idx) => key.id), ((item, index) => { return this.renderItemTree(item, index); }))}
            </ul>
        `;
        return obj;
    }
    renderItemTree(item, idx, parentArray = this.nodes) {
        const cls = (item.elDomNavigator && this.activeId && item.elDomNavigator.id === this.activeId) ? 'activeBranch' : '';
        let mySymbol = 'fa-cubes';
        const info = this.getActualFileL4();
        const draggable = item.tagName !== info?.tagName;
        const renderHeader = () => {
            return html `
                <div 
                    .info=${item}
                    id="${item.tagName + idx}"                      
                    class="header ${cls}" 
                    @dblclick="${(e) => this.editEl(e, item)}"
                    @click="${(e) => this.selectItem(e, item)}"  
                    @mouseover="${() => this.onMouseover(item)}"
                    @mouseout="${() => this.onMouseout(item)}"   
                >
                    
                    <info-item .info=${item}>
                        <span class="move-icon" title="Mover">
                            ${collab_bars}
                        </span>
                        <span class="fa ${mySymbol}" style="margin-right:.5rem"></span>
                        ${this.slugToTitle(item.tagName)}
                    </info-item>

                    <div class="groupHiddenList" .info=${item}  @click="${this.clickGroupHidden}">
                        ${item.isOrganism ? html `
                            <span 
                                class="mls-gpbtnslider-item"
                                @click="${(e) => this.editEl(e, item)}" 
                                title="edit"
                            >
                            ${collab_pencil}</span>
                        
                        `
                : ''}
                    
                        <span
                            class="mls-gpbtnslider-item"
                            @click="${this.delEl}" 
                            title="remove"
                        >${collab_trash}</span>
                    </div>
                </div>
                <ul>
                    ${repeat(item.children, ((c, idx) => c.tagName + item.elDomNavigator?.id + idx), ((i, idxI) => this.renderItemTree(i, idx + '_' + idxI, item.children)))}
                </ul>
            `;
        };
        if (draggable) {
            return html `
                <li 
                    class="nav-item"
                    .item=${item}
                    draggable=${draggable} 
                    @dragstart=${(e) => this.onDragStart(e, item, parentArray)}
                    @dragover=${(e) => this.onDragOver(e, item)}
                    @dragleave=${(e) => this.onDragLeave(e)}
                    @drop=${(e) => this.onDrop(e, item, parentArray)}
                    @dragend=${() => this.onDragEnd()}

                    @touchstart=${(e) => this.onTouchStart(e, item, parentArray)}
                    @touchmove=${(e) => this.onTouchMove(e)}
                    @touchend=${(e) => this.onTouchEnd(e, item, parentArray)}
                >
                    ${renderHeader()} 
            </li>`;
        }
        else {
            return html `<li class="nav-item">${renderHeader()}</li>`;
        }
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.requestUpdate();
    }
    getActualFileL4() {
        const { folder, project, shortName } = mls.l2.getPath(`_${mls.actual[4].project}_${mls.actual[4].path}`);
        if (!project || !shortName)
            return undefined;
        const keyStorFile = mls.stor.getKeyToFiles(project, 2, shortName, folder, '.html');
        const keyModels = mls.editor.getKeyModel(project, shortName, folder);
        const storFile = mls.stor.files[keyStorFile];
        const models = mls.editor.models[keyModels];
        const tagName = convertFileNameToTag({ shortName, project, folder });
        return {
            storFile,
            models,
            tagName
        };
    }
    async getComponents() {
        const storFile = this.getActualFileL4()?.storFile;
        if (!storFile)
            return [];
        const content = await storFile.getContent();
        if (!content || typeof content !== 'string')
            return [];
        const parser = new DOMParser();
        const doc = parser.parseFromString(content, 'text/html');
        this.domNavigator = doc.body;
        if (!this.domNavigator)
            return [];
        return this.getComponents2(this.domNavigator);
    }
    getComponents2(scope) {
        const excludeTags = ['script', 'style', 'body', 'head', 'html'];
        let ret = [];
        const reentrance = (array, element) => {
            let info;
            if (!excludeTags.includes(element.tagName.toLocaleLowerCase())) {
                const el = element.id ? scope.querySelector(`#${element.id}`) : null;
                const isOrganism = element.tagName.includes('-') && element.tagName.toLocaleLowerCase().includes('organism-');
                info = { el, id: element.id, children: [], tagName: element.tagName.toLowerCase(), isOrganism, elDomNavigator: element };
                array.push(info);
            }
            const children = Array.from(element.children);
            for (let i = 0; i < children.length; i++) {
                const child = children[i];
                reentrance(info ? info.children : array, child);
            }
        };
        reentrance(ret, scope);
        return ret;
    }
    selectItem(e, item) {
        e.stopPropagation();
        let target = e.target;
        if (target && target.className.indexOf('header') < 0) {
            target = target.closest('.header');
        }
        if (!target)
            return;
        const active = this.querySelector('.activeBranch');
        if (active && active === target) {
            return;
        }
        if (active)
            active.classList.remove('activeBranch');
        target.classList.add('activeBranch');
        item.el?.scrollIntoView({
            behavior: "auto",
            block: "start",
            inline: "nearest"
        });
        if (!this.elPreviewL4 || !this.elPreviewL4.selectElement || !this.elPreviewL4.isConnected)
            this.setElPreview();
        if (!this.elPreviewL4 || !this.elPreviewL4.selectElement || !item.el)
            return;
        this.elPreviewL4.selectElement(item.id);
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        el.classList.toggle('activegpbtnslider');
    }
    delEl(e) {
        e.stopPropagation();
        //setTimeout(() => { this.requestUpdate(); }, 100);
    }
    editEl(e, item) {
        const fileInfo = convertTagToFileName(item.tagName.toLowerCase());
        if (!fileInfo)
            return;
        const { folder, project, shortName } = fileInfo;
        mls.actual[3].setFullName(folder ? `_${project}_${folder}/${shortName}` : `_${project}_${shortName}`);
        selectLevel(3);
        setTimeout(() => { openService('_100554_serviceOrganism', 'left', 3, { "tab": "navigation" }); }, 500);
    }
    onMouseover(item) {
        if (!this.elPreviewL4 || !this.elPreviewL4.setHover || !this.elPreviewL4.isConnected)
            this.setElPreview();
        if (!this.elPreviewL4 || !this.elPreviewL4.setHover || !item.el)
            return;
        this.elPreviewL4.setHover(item.id, true);
    }
    onMouseout(item) {
        if (!this.elPreviewL4 || !this.elPreviewL4.setHover || !this.elPreviewL4.isConnected)
            this.setElPreview();
        if (!this.elPreviewL4 || !this.elPreviewL4.setHover || !item.el)
            return;
        this.elPreviewL4.setHover(item.id, false);
    }
    ;
    setElPreview() {
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return;
        this.elPreviewL4 = scope.querySelector('collab-preview-l4-100554');
    }
    slugToTitle(slug) {
        return slug
            .replace(/^.*--/, "")
            .replace(/-\d+$/, "")
            .replace(/-/g, " ")
            .replace(/\s+/g, " ")
            .trim()
            .replace(/\b\w/g, (char) => char.toUpperCase());
    }
    onDragStart(e, item, parentArray) {
        e.stopPropagation();
        this.dragItem = item;
        this.dragParentArray = parentArray;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setDragImage(new Image(), 0, 0);
    }
    onTouchStart(e, item, parentArray) {
        e.stopPropagation();
        this.dragItem = item;
        this.dragParentArray = parentArray;
    }
    onTouchEnd(e, targetItem, parentArray) {
        e.preventDefault();
        e.stopPropagation();
        if (!this.dragItem || !this.dragParentArray || !this.domNavigator)
            return;
        if (this.dragItem === targetItem || this.isDescendant(this.dragItem, targetItem)) {
            console.warn('Não é permitido mover um pai para dentro do filho');
            this.onDragEnd();
            return;
        }
        const fromIndex = this.dragParentArray.indexOf(this.dragItem);
        if (fromIndex > -1) {
            this.dragParentArray.splice(fromIndex, 1);
        }
        const domDragEl = this.dragItem.elDomNavigator;
        const domTargetEl = targetItem.elDomNavigator;
        if (this.dropPosition === 'inside') {
            targetItem.children.push(this.dragItem);
            if (domDragEl && domTargetEl) {
                domTargetEl.appendChild(domDragEl);
            }
        }
        else {
            let toIndex = parentArray.indexOf(targetItem);
            if (this.dropPosition === 'after') {
                toIndex++;
            }
            parentArray.splice(toIndex, 0, this.dragItem);
            if (domDragEl && domTargetEl && domDragEl !== domTargetEl) {
                const parentDom = domTargetEl.parentElement;
                if (parentDom) {
                    if (this.dropPosition === 'before') {
                        parentDom.insertBefore(domDragEl, domTargetEl);
                    }
                    else {
                        parentDom.insertBefore(domDragEl, domTargetEl.nextSibling);
                    }
                }
            }
        }
        this.prepareHTMLAndSync();
        this.onDragEnd();
    }
    onTouchMove(e) {
        e.preventDefault();
        if (!this.dragItem)
            return;
        const touch = e.touches[0];
        const elemUnderFinger = document.elementFromPoint(touch.clientX, touch.clientY);
        if (!elemUnderFinger)
            return;
        const liTarget = elemUnderFinger.closest("li.nav-item");
        if (!liTarget)
            return;
        const info = liTarget.querySelector(".header")?.info;
        if (!info)
            return;
        const rect = liTarget.getBoundingClientRect();
        const y = touch.clientY - rect.top;
        const third = rect.height / 3;
        let position;
        if (y < third)
            position = 'before';
        else if (y > rect.height - third)
            position = 'after';
        else
            position = 'inside';
        if (position === 'inside' && info.isOrganism) {
            position = 'after';
        }
        if (this.isDescendant(this.dragItem, info)) {
            position = 'invalid';
        }
        this.dropPosition = position;
        this.dragOverTarget = liTarget;
        const borderTarget = liTarget.querySelector('.header');
        if (!borderTarget)
            return;
        borderTarget.style.borderTop = '';
        borderTarget.style.borderBottom = '';
        borderTarget.style.border = '';
        liTarget.style.cursor = 'grab';
        if (position === 'before') {
            borderTarget.style.borderTop = '1px solid blue';
        }
        else if (position === 'after') {
            borderTarget.style.borderBottom = '1px solid blue';
        }
        else if (position === 'inside') {
            borderTarget.style.border = '1px solid blue';
        }
        else if (position === 'invalid') {
            borderTarget.style.border = '1px solid red';
            liTarget.style.cursor = 'not-allowed';
        }
    }
    onDragOver(e, targetItem) {
        e.preventDefault();
        e.stopPropagation();
        e.dataTransfer.dropEffect = 'move';
        const liTarget = e.currentTarget;
        const rect = liTarget.getBoundingClientRect();
        const y = e.clientY - rect.top;
        this.configOverEvent(liTarget, targetItem, y);
    }
    configOverEvent(liTarget, targetItem, y, e) {
        const rect = liTarget.getBoundingClientRect();
        const third = rect.height / 3;
        let position;
        if (y < third)
            position = 'before';
        else if (y > rect.height - third)
            position = 'after';
        else
            position = 'inside';
        if (position === 'inside' && targetItem.isOrganism) {
            position = 'after';
        }
        if (this.isDescendant(this.dragItem, targetItem)) {
            position = 'invalid';
        }
        this.dropPosition = position;
        this.dragOverTarget = liTarget;
        const borderTarget = liTarget.querySelector('.header');
        if (!borderTarget)
            return;
        borderTarget.style.borderTop = '';
        borderTarget.style.borderBottom = '';
        borderTarget.style.border = '';
        liTarget.style.cursor = 'grab';
        if (position === 'before') {
            borderTarget.style.borderTop = '1px solid blue';
        }
        else if (position === 'after') {
            borderTarget.style.borderBottom = '1px solid blue';
        }
        else if (position === 'inside') {
            borderTarget.style.border = '1px solid blue';
        }
        else if (position === 'invalid') {
            borderTarget.style.border = '1px solid red';
            if (e)
                e.dataTransfer.dropEffect = 'none';
            liTarget.style.cursor = 'not-allowed';
        }
    }
    onDragLeave(e) {
        const liTarget = e.currentTarget;
        const borderTarget = liTarget.querySelector('.header');
        if (!borderTarget)
            return;
        borderTarget.style.borderTop = '';
        borderTarget.style.borderBottom = '';
        borderTarget.style.border = '';
    }
    onDrop(e, targetItem, parentArray) {
        e.preventDefault();
        e.stopPropagation();
        if (!this.dragItem || !this.dragParentArray || !this.domNavigator)
            return;
        if (this.dragItem === targetItem || this.isDescendant(this.dragItem, targetItem)) {
            console.warn('Não é permitido mover um pai para dentro do filho');
            this.onDragEnd();
            return;
        }
        const fromIndex = this.dragParentArray.indexOf(this.dragItem);
        if (fromIndex > -1) {
            this.dragParentArray.splice(fromIndex, 1);
        }
        const domDragEl = this.dragItem.elDomNavigator;
        const domTargetEl = targetItem.elDomNavigator;
        if (this.dropPosition === 'inside') {
            targetItem.children.push(this.dragItem);
            if (domDragEl && domTargetEl) {
                domTargetEl.appendChild(domDragEl);
            }
        }
        else {
            let toIndex = parentArray.indexOf(targetItem);
            if (this.dropPosition === 'after') {
                toIndex++;
            }
            parentArray.splice(toIndex, 0, this.dragItem);
            if (domDragEl && domTargetEl && domDragEl !== domTargetEl) {
                const parentDom = domTargetEl.parentElement;
                if (parentDom) {
                    if (this.dropPosition === 'before') {
                        parentDom.insertBefore(domDragEl, domTargetEl);
                    }
                    else {
                        parentDom.insertBefore(domDragEl, domTargetEl.nextSibling);
                    }
                }
            }
        }
        this.prepareHTMLAndSync();
        this.onDragEnd();
    }
    onDragEnd() {
        this.dragItem = undefined;
        this.dragParentArray = undefined;
        this.dragOverTarget = undefined;
        this.querySelectorAll('li >.header').forEach(el => {
            el.style.borderTop = '';
            el.style.borderBottom = '';
            el.style.border = '';
        });
    }
    isDescendant(parent, child) {
        if (!parent)
            return false;
        if (!parent.children || parent.children.length === 0)
            return false;
        for (const c of parent.children) {
            if (c === child)
                return true;
            if (this.isDescendant(c, child))
                return true;
        }
        return false;
    }
    prepareHTMLAndSync() {
        this.requestUpdate();
        const rootEl = this.domNavigator;
        if (!rootEl)
            return;
        const newHtml = formatHtml(rootEl.outerHTML);
        const actualInfo = this.getActualFileL4();
        if (actualInfo && actualInfo.models && actualInfo.models.html) {
            actualInfo.models.html.model.setValue(newHtml);
            setValueInModeKeepingUndo(actualInfo.models && actualInfo.models.html.model, newHtml);
            mls.events.fireFileAction('editorChanged', actualInfo.models.html.storFile, 'left', 0);
        }
    }
};
__decorate([
    state()
], PluginNavigationRenderOrganism.prototype, "nodes", void 0);
__decorate([
    state()
], PluginNavigationRenderOrganism.prototype, "activeId", void 0);
PluginNavigationRenderOrganism = __decorate([
    customElement('plugin-page-navigation-100554')
], PluginNavigationRenderOrganism);
export { PluginNavigationRenderOrganism };
