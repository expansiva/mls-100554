/// <mls shortName="icaApresentationAnimationsLoadingBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { StateLitElement } from './_100554_stateLitElement';
export class IcaApresentationAnimationsLoadingBase extends StateLitElement {
}
