/// <mls shortName="icaApresentationAnimationBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from '/_100554_/l2/icaLitElementBase.js';
export class IcaApresentationAnimationBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.mySymbol = 'fa-table-columns';
        this.baseName = 'IcaApresentationAnimationBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
}
