var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="aimSelectLanguage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, css } from 'lit';
import { customElement, query, queryAll, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { collab_ban } from './_100554_collabIcons';
import { languages } from './_100554_collabLanguages';
/// **collab_i18n_start**
const message_pt = {
    "btn_cancel": "Cancelar",
    "btn_confirm": "Confirmar",
    "label_select_all": "Selecionar todos",
    "clear_all": "Limpar sele��o",
    "btn_search": "Pesquisar",
    "search_placeHolder": "Digite a linguagem"
};
const message_en = {
    "btn_cancel": "Cancel",
    "btn_confirm": "Confirm",
    "label_select_all": "Select all",
    "clear_all": "Clear selection",
    "btn_search": "Search",
    "search_placeHolder": "Enter language"
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export function initAimSelectLanguage100554() {
    return true;
}
let AimSelectLanguage100554 = class AimSelectLanguage100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`aim-select-language-100554 hr{box-sizing:content-box;height:0;overflow:visible;margin-top:1rem;border-width:1px 0px 0px;border-right-style:initial;border-bottom-style:initial;border-left-style:initial;border-right-color:initial;border-bottom-color:initial;border-left-color:initial;border-image:initial;border-top-style:solid;border-top-color:rgba(0,0,0,0.1);margin-bottom:1rem}aim-select-language-100554 button{background-color:#F9F9F9;border-radius:8px;border:none;box-shadow:0 1px 3px 0 #E6E6E6;display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#403f3f;cursor:pointer}aim-select-language-100554 button:hover{background-color:#F2F2F2}aim-select-language-100554 summary{cursor:pointer}aim-select-language-100554 input,aim-select-language-100554 select,aim-select-language-100554 textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}aim-select-language-100554 .select-grid{display:grid;grid-template-columns:repeat(auto-fill, 20em);gap:1px;overflow:auto}aim-select-language-100554 .select-grid .select-grid-item{padding:5px;display:flex;cursor:pointer;height:20px}aim-select-language-100554 .select-grid .select-grid-item label{cursor:pointer;max-width:15em;text-overflow:ellipsis;font-size:calc(.25rem * 4);white-space:nowrap;overflow:hidden}aim-select-language-100554 .select-grid .select-grid-item.selected{background:#F2F2F2;animation:backgroundFadeIn 5s ease-in-out}aim-select-language-100554 .select-search{margin-top:2rem;display:flex;gap:.6em;padding-left:1rem}aim-select-language-100554 .select-search input{width:100%}aim-select-language-100554 .select-search button{width:10em}aim-select-language-100554 .select-btn{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;padding-left:1rem;gap:.5rem}aim-select-language-100554 .select-btn .select-check-all{display:flex;gap:.2rem}aim-select-language-100554 .select-btn .select-check-all label{cursor:pointer}aim-select-language-100554 .select-btn button{width:10em}aim-select-language-100554 .select-btn .select-btn-group{display:flex;align-items:center;gap:1rem}aim-select-language-100554 .select-btn .select-clear-all{display:flex;align-items:center;gap:.2rem}aim-select-language-100554 .select-btn .select-btn-actions{display:flex;gap:1rem}@keyframes backgroundFadeIn{0%{background-color:#F2F2F2}100%{background-color:#E6E6E6}}`);
        this.msg = messages['en'];
        this.height = 700;
        this.defaultValue = [];
    }
    get value() {
        if (!this.listcontainer)
            return [];
        const all = this.listcontainer.querySelectorAll('input');
        const values = Array.from(all).map((inp) => inp.checked ? inp['langObj'] : undefined).filter((item) => !!item);
        return values;
    }
    getLanguages() {
        return languages.sort((a, b) => a.name.localeCompare(b.name, 'pt', { sensitivity: 'base' }));
    }
    handleSearch() {
        if (!this.gridItems || !this.inpSearch)
            return;
        const searchTerm = this.inpSearch.value.toLowerCase();
        this.gridItems.forEach(item => {
            item.classList.remove('selected');
            const label = item.querySelector('label');
            if (label) {
                const labelText = label.textContent?.toLowerCase() || '';
                if (labelText.includes(searchTerm)) {
                    label.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    item.classList.add('selected');
                    setTimeout(() => {
                        item.classList.remove('selected');
                    }, 10000);
                }
            }
        });
    }
    handleSelectAll(e) {
        const inp = e.target;
        if (!this.listcontainer)
            return;
        const all = this.listcontainer.querySelectorAll('input');
        if (inp.checked)
            all.forEach((inp) => inp.checked = true);
        else
            all.forEach((inp) => inp.checked = false);
    }
    handleClearAll(e) {
        const all = this.shadowRoot?.querySelectorAll('input');
        if (all)
            all.forEach((inp) => inp.checked = false);
    }
    handleConfirm() {
        const val = this.value;
        this.dispatchEvent(new CustomEvent('select-language-confirm', {
            detail: val, bubbles: true, composed: true
        }));
    }
    handleCancel() {
        this.dispatchEvent(new CustomEvent('select-language-cancel'));
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const languages = this.getLanguages();
        this.style.display = 'block';
        this.style.height = this.height + 'px';
        return html `
        <div> 
            <div>
                <div class="select-btn">
                    <div class="select-btn-group">
                        <div class="select-check-all">
                            <button>
                                <input id="select-check-all" type="checkbox" @change=${this.handleSelectAll}></input>
                                <label for="select-check-all">${this.msg.label_select_all}</label>
                            </button>
                        </div>
                        <div class="select-clear-all">
                            <button @click=${this.handleClearAll}>
                                <div>${collab_ban}</div>
                                <span>${this.msg.clear_all}</span>
                            </button>
                        </div>
                    </div>
                    <div class="select-btn-actions">
                        <button @click=${this.handleConfirm}>${this.msg.btn_confirm}</button>
                        <button  @click=${this.handleCancel}>${this.msg.btn_cancel}</button>
                    </div>
                </div>
                <div class="select-search">
                    <input type="search"> </input>
                    <button @click=${this.handleSearch}>${this.msg.btn_search}</button>
                </div>
            </div>
            <hr>
            <div class="select-grid" style="height:calc(${this.height + 'px'} - 140px);">
                ${languages.map((lang) => {
            return html `
                    <div class="select-grid-item">
                        <input id="sl_${lang.code}" .langObj=${lang} type="checkbox" ?checked=${!!this.defaultValue.find((item) => item.code === lang.code)}></input>
                        <label for="sl_${lang.code}">${lang.name}(${lang.code})</label>
                    </div>
                    `;
        })}
            </div>
        </div>`;
    }
};
AimSelectLanguage100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property({ type: Number })
], AimSelectLanguage100554.prototype, "height", void 0);
__decorate([
    property()
], AimSelectLanguage100554.prototype, "defaultValue", void 0);
__decorate([
    query('.select-grid')
], AimSelectLanguage100554.prototype, "listcontainer", void 0);
__decorate([
    query('input[type="search"]')
], AimSelectLanguage100554.prototype, "inpSearch", void 0);
__decorate([
    queryAll('.select-grid-item')
], AimSelectLanguage100554.prototype, "gridItems", void 0);
AimSelectLanguage100554 = __decorate([
    customElement('aim-select-language-100554')
], AimSelectLanguage100554);
export { AimSelectLanguage100554 };
