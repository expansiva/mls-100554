var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="aimSelectLanguage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, css } from 'lit';
import { customElement, query, queryAll, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { collab_ban } from './_100554_collabIcons';
import { languages } from './_100554_collabLanguages';
/// **collab_i18n_start**
const message_pt = {
    "btn_cancel": "Cancelar",
    "btn_confirm": "Confirmar",
    "label_select_all": "Selecionar todos",
    "clear_all": "Limpar sele��o",
    "btn_search": "Pesquisar",
    "search_placeHolder": "Digite a linguagem"
};
const message_en = {
    "btn_cancel": "Cancel",
    "btn_confirm": "Confirm",
    "label_select_all": "Select all",
    "clear_all": "Clear selection",
    "btn_search": "Search",
    "search_placeHolder": "Enter language"
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export function initAimSelectLanguage100554() {
    return true;
}
let AimSelectLanguage100554 = class AimSelectLanguage100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.height = 700;
        this.defaultValue = [];
    }
    get value() {
        if (!this.listcontainer)
            return [];
        const all = this.listcontainer.querySelectorAll('input');
        const values = Array.from(all).map((inp) => inp.checked ? inp['langObj'] : undefined).filter((item) => !!item);
        return values;
    }
    getLanguages() {
        return languages.sort((a, b) => a.name.localeCompare(b.name, 'pt', { sensitivity: 'base' }));
    }
    handleSearch() {
        if (!this.gridItems || !this.inpSearch)
            return;
        const searchTerm = this.inpSearch.value.toLowerCase();
        this.gridItems.forEach(item => {
            item.classList.remove('selected');
            const label = item.querySelector('label');
            if (label) {
                const labelText = label.textContent?.toLowerCase() || '';
                if (labelText.includes(searchTerm)) {
                    label.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    item.classList.add('selected');
                    setTimeout(() => {
                        item.classList.remove('selected');
                    }, 10000);
                }
            }
        });
    }
    handleSelectAll(e) {
        const inp = e.target;
        if (!this.listcontainer)
            return;
        const all = this.listcontainer.querySelectorAll('input');
        if (inp.checked)
            all.forEach((inp) => inp.checked = true);
        else
            all.forEach((inp) => inp.checked = false);
    }
    handleClearAll(e) {
        const all = this.shadowRoot?.querySelectorAll('input');
        if (all)
            all.forEach((inp) => inp.checked = false);
    }
    handleConfirm() {
        const val = this.value;
        this.dispatchEvent(new CustomEvent('select-language-confirm', {
            detail: val, bubbles: true, composed: true
        }));
    }
    handleCancel() {
        this.dispatchEvent(new CustomEvent('select-language-cancel'));
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const languages = this.getLanguages();
        this.style.display = 'block';
        this.style.height = this.height + 'px';
        return html `
        <div> 
            <div>
                <div class="select-btn">
                    <div class="select-btn-group">
                        <div class="select-check-all">
                            <button>
                                <input id="select-check-all" type="checkbox" @change=${this.handleSelectAll}></input>
                                <label for="select-check-all">${this.msg.label_select_all}</label>
                            </button>
                        </div>
                        <div class="select-clear-all">
                            <button @click=${this.handleClearAll}>
                                <div>${collab_ban}</div>
                                <span>${this.msg.clear_all}</span>
                            </button>
                        </div>
                    </div>
                    <div class="select-btn-actions">
                        <button @click=${this.handleConfirm}>${this.msg.btn_confirm}</button>
                        <button  @click=${this.handleCancel}>${this.msg.btn_cancel}</button>
                    </div>
                </div>
                <div class="select-search">
                    <input type="search"> </input>
                    <button @click=${this.handleSearch}>${this.msg.btn_search}</button>
                </div>
            </div>
            <hr>
            <div class="select-grid" style="height:calc(${this.height + 'px'} - 140px);">
                ${languages.map((lang) => {
            return html `
                    <div class="select-grid-item">
                        <input id="sl_${lang.code}" .langObj=${lang} type="checkbox" ?checked=${!!this.defaultValue.find((item) => item.code === lang.code)}></input>
                        <label for="sl_${lang.code}">${lang.name}(${lang.code})</label>
                    </div>
                    `;
        })}
            </div>
        </div>`;
    }
};
AimSelectLanguage100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property({ type: Number })
], AimSelectLanguage100554.prototype, "height", void 0);
__decorate([
    property()
], AimSelectLanguage100554.prototype, "defaultValue", void 0);
__decorate([
    query('.select-grid')
], AimSelectLanguage100554.prototype, "listcontainer", void 0);
__decorate([
    query('input[type="search"]')
], AimSelectLanguage100554.prototype, "inpSearch", void 0);
__decorate([
    queryAll('.select-grid-item')
], AimSelectLanguage100554.prototype, "gridItems", void 0);
AimSelectLanguage100554 = __decorate([
    customElement('aim-select-language-100554')
], AimSelectLanguage100554);
export { AimSelectLanguage100554 };
