/// <mls shortName="icaOrganismWireframeBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html } from 'lit';
import { StateLitElement } from './_100554_stateLitElement';
import { convertTagToFileName } from './_100554_utilsLit';
export class IcaOrganismWireframeBase extends StateLitElement {
    render() {
        this.style.display = 'block';
        this.style.border = '1px dashed';
        this.style.padding = '.4rem';
        return html `
            <div>
                <div style="display:flex; gap:1rem;">
                    <h4 style="margin:0">${this.generalDescription}</h4>
                    <a style="cursor:ponter" href="#" @click=${this.onEditClick}>Edit</a>
                </div>

                <small>${this.goal}</small>
            </div>
        `;
    }
    onEditClick(ev) {
        ev.preventDefault();
        console.info({
            generalDescription: this.generalDescription,
            goal: this.goal
        });
        const { shortName, project } = convertTagToFileName(this.tagName.toLowerCase());
        const keyStor = mls.stor.getKeyToFiles(project, 2, shortName, '', '.ts');
        const storFile = mls.stor.files[keyStor];
        this.fireEvents('open', storFile);
    }
    fireEvents(action, file, timeout = 0) {
        const params = {};
        params.action = action;
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = file.extension;
        params.folder = file.folder;
        params.position = 'left';
        if (['open'].includes(action)) {
            mls.actual[2].setFullName(`_${file.project}_${file.shortName}`);
            mls.actual[2].left = {
                project: file.project,
                shortName: file.shortName,
                extension: file.extension,
                folder: file.folder,
            };
        }
        mls.events.fire([2], ['FileAction'], JSON.stringify(params), timeout);
    }
}
