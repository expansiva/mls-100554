/// <mls shortName="icaApresentationTextRichBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from './_100554_icaLitElementBase';
export class IcaApresentationTextRichBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaApresentationTextRichBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
}
