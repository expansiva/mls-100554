/// <mls shortName="collabConsoleL1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let CollabConsoleL1100554 = class CollabConsoleL1100554 extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-console-l1-100554{display:block;height:100%}collab-console-l1-100554 .console{height:100%;background:#000;border-radius:5px;padding:10px;display:flex;flex-direction:column}collab-console-l1-100554 .output{flex:1;overflow-y:auto;padding:5px}collab-console-l1-100554 .output div{color:#d2d2d2}collab-console-l1-100554 .header{display:flex;align-items:center;justify-content:center;border-bottom:1px solid #444;padding:5px;color:#0f0}collab-console-l1-100554 button{background-color:#3c3434;border:1px solid #4c4747;color:#0f0;cursor:pointer}collab-console-l1-100554 .input-area{display:flex;align-items:center;border-top:1px solid #444;padding:5px}collab-console-l1-100554 .prompt{color:#0f0;margin-right:5px}collab-console-l1-100554 .input-box{flex:1;background:transparent;border:none;outline:none;color:#0f0;font-size:16px}`);
    }
    firstUpdated() {
        this.configLog();
    }
    //-----COMPOENENT-----------
    render() {
        return html `
        <div class="console">  
            <div class="header">Collab Server: ${this.file}</div>
            <div class="output" id="output"></div>
            <div class="input-area">
                <span class="prompt">$</span>
                <input type="text" autocomplete="off" @keydown="${this.onKeyDown}" class="input-box" id="inputBox" autofocus>
                <button @click="${this.execute}">&gt;</button>
            </div>
        </div>
        `;
    }
    //-------IMPLEMENTS----------
    onKeyDown(event) {
        if (event.key === "Enter")
            this.execute();
    }
    execute() {
        if (!this.inputBox || !this.output)
            return;
        let command = this.inputBox.value.trim();
        this.inputBox.value = "";
        if (command) {
            this.output.innerHTML += `<div><span class="prompt">$</span> ${command}</div>`;
            try {
                if (!window.consoleScope)
                    window.consoleScope = {};
                let result;
                if (command.startsWith("let ") || command.startsWith("const ") || command.startsWith("var ")) {
                    const varName = command.split(/\s+/)[1].split("=")[0].trim();
                    command = command.split("=")[1].trim();
                    const res = eval(command);
                    window.consoleScope[varName] = res;
                    result = res;
                }
                else
                    result = new Function("with (window.consoleScope) { return " + command + "; }")();
                if (typeof result === 'object')
                    result = JSON.stringify(result);
                this.output.innerHTML += `<div><span class="prompt">&lt;</span> ${result}</div>`;
            }
            catch (error) {
                this.output.innerHTML += `<div style="color: red;">Erro: ${error.message}</div>`;
            }
            this.output.scrollTop = this.output.scrollHeight;
        }
    }
    configLog() {
        const originalLog = console.log;
        console.log = (...args) => {
            if (!this.inputBox || !this.output)
                return;
            const message = args.map(arg => typeof arg === "object" ? JSON.stringify(arg) : arg).join(" ");
            this.output.innerHTML += `<div><span class="prompt">&lt;</span> ${message}</div>`;
            originalLog.apply(console, args);
        };
    }
};
__decorate([
    query('#output')
], CollabConsoleL1100554.prototype, "output", void 0);
__decorate([
    query('#inputBox')
], CollabConsoleL1100554.prototype, "inputBox", void 0);
__decorate([
    property()
], CollabConsoleL1100554.prototype, "file", void 0);
CollabConsoleL1100554 = __decorate([
    customElement('collab-console-l1-100554')
], CollabConsoleL1100554);
export { CollabConsoleL1100554 };
