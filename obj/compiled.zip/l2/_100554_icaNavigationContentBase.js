/// <mls shortName="icaNavigationContentBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from './_100554_icaLitElementBase';
export class IcaNavigationContentBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaNavigationContentBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
}
