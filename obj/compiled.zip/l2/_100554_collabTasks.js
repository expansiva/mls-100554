/// <mls shortName="collabTasks" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_plus, collab_message } from './_100554_collabIcons';
let CollabTasks100554 = class CollabTasks100554 extends IcaLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-tasks-100554{font-size:var(--font-size-12)}collab-tasks-100554 .task-container .task-columns{display:flex;flex-direction:row;padding:0 6px;transition:padding .2s ease-in-out;list-style:none;margin-bottom:8px;overflow-x:auto;overflow-y:hidden;padding-bottom:8px;padding-top:2px;scrollbar-color:#fff6 #00000026;scrollbar-width:auto;-webkit-user-select:none;user-select:none;white-space:nowrap}collab-tasks-100554 .task-container .task-columns .task-column{display:block;flex-shrink:0;align-self:flex-start;padding:0 6px;height:100%;width:272px;white-space:nowrap}collab-tasks-100554 .task-container .task-columns .task-column .task-column-container{display:flex;flex-direction:column;gap:1rem;position:relative;box-sizing:border-box;align-self:start;justify-content:space-between;width:272px;max-height:100%;padding-bottom:8px;border-radius:12px;box-shadow:0 1px 1px #091e4240,0 0 1px #091e424f;vertical-align:top;white-space:normal;background:var(--bg-primary-color-darker);scroll-margin:8px}collab-tasks-100554 .task-container .task-columns .task-column .task-column-container .task-column-title{padding:var(--space-16) 0 0 var(--space-16);display:flex;font-weight:var(--font-weight-bold)}collab-tasks-100554 .task-container .task-columns .task-items-add{padding:.5rem 1rem;margin:0 4px;cursor:pointer;border-radius:8px;display:flex;align-items:center;gap:.5rem}collab-tasks-100554 .task-container .task-columns .task-items-add svg{fill:currentColor}collab-tasks-100554 .task-container .task-columns .task-items-add:hover{background-color:var(--grey-color)}collab-tasks-100554 .task-container .task-columns .task-items{margin-inline-start:0;padding-inline-start:0;display:flex;z-index:1;flex:1 1 auto;flex-direction:column;margin:0 4px;padding:2px 4px;overflow-x:hidden;overflow-y:auto;list-style:none;row-gap:8px;-webkit-overflow-scrolling:touch;scrollbar-color:#091e4224 #091e420f;scrollbar-width:thin}collab-tasks-100554 .task-container .task-columns .task-items .task-item{display:flex;flex-direction:column;gap:.25rem;box-shadow:0 1px 1px #091e4240,0 0 1px #091e424f;padding:.5rem;cursor:pointer;min-height:36px;border-radius:8px;background:var(--bg-primary-color)}collab-tasks-100554 .task-container .task-columns .task-items .task-item .task-item-title{font-size:var(--font-size-12);text-align:left;width:100%;font-weight:600}collab-tasks-100554 .task-container .task-columns .task-items .task-item .task-item-body{font-size:var(--font-size-12)}collab-tasks-100554 .task-container .task-columns .task-items .task-item .task-item-actions{display:flex;gap:.25rem}collab-tasks-100554 .task-container .task-columns .task-items .task-item .task-item-actions .task-item-actions-info{flex:1;display:flex;gap:.3rem;align-items:center}collab-tasks-100554 .task-container .task-columns .task-items .task-item .task-item-actions .task-item-actions-info svg{width:10px;height:10px}collab-tasks-100554 .task-container .task-columns .task-items .task-item .task-item-actions .task-item-actions-info span{font-size:var(--font-size-12)}collab-tasks-100554 .task-container .task-columns .task-items .task-item .task-item-actions .task-item-actions-user img{width:25px;height:25px;background-size:cover;background-position:top center;border-radius:50%}`);
    }
    render() {
        return html `<div class="task-container">

         <ol class="task-columns">
            <li class="task-column">
                <div class="task-column-container"> 
                <div class="task-column-title">Pending</div>
                    <ul class="task-items">
                        <li class="task-item">  
                            <div class="task-item-title"> Task 1</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                            <div class="task-item-actions-info">
                                <div class="info-messages"> ${collab_message} <span>10</span></div>
                                </div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://lh3.googleusercontent.com/a-/AOh14GjhEPN7UazL97l6qFIRIYUoLY-PNNPC93Zw4EVT=s96-c" alt="user avatar">
                                </div>
                            </div>
                        </li>
                        <li class="task-item">  
                            <div class="task-item-title"> Task 2</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                                <div class="task-item-actions-info"></div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://avatars.githubusercontent.com/u/57486730?v=4" alt="user avatar">
                                </div>
                            </div>
                        </li>
                        <li class="task-item">  
                            <div class="task-item-title"> Task 3</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                                <div class="task-item-actions-info"></div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://avatars.githubusercontent.com/u/57486730?v=4" alt="user avatar">
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div class="task-items-add">
                        ${collab_plus}
                        <span>Add new task</span>
                    </div>
                </div>
            
            </li>

            <li class="task-column">
                <div class="task-column-container"> 
                <div class="task-column-title">In progress</div>
                    <ul class="task-items">
                        <li class="task-item">  
                            <div class="task-item-title"> Task 4</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                                <div class="task-item-actions-info">
                                    <div class="info-messages"> ${collab_message} <span>1</span></div>
                                </div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://avatars.githubusercontent.com/u/36516904?v=4" alt="user avatar">
                                </div>
                            </div>
                        </li>
                        <li class="task-item">  
                            <div class="task-item-title"> Task 5</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                                <div class="task-item-actions-info"></div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://lh3.googleusercontent.com/a-/AOh14GjhEPN7UazL97l6qFIRIYUoLY-PNNPC93Zw4EVT=s96-c" alt="user avatar">
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div class="task-items-add">
                        ${collab_plus}
                        <span>Add new task</span>
                    </div>
                </div>
            </li>

            <li class="task-column">
                <div class="task-column-container"> 
                <div class="task-column-title">Completed</div>
                    <ul class="task-items">
                        <li class="task-item">  
                            <div class="task-item-title"> Task 6</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                                <div class="task-item-actions-info">
                                    <div class="info-messages"> ${collab_message} <span>1</span></div>
                                </div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://avatars.githubusercontent.com/u/36516904?v=4" alt="user avatar">
                                </div>
                            </div>
                        </li>
                        <li class="task-item">  
                            <div class="task-item-title"> Task 7</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                                <div class="task-item-actions-info">
                                    <div class="info-messages"> ${collab_message} <span>3</span></div>
                                </div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://lh3.googleusercontent.com/a-/AOh14GjhEPN7UazL97l6qFIRIYUoLY-PNNPC93Zw4EVT=s96-c" alt="user avatar">
                                </div>
                            </div>
                        </li>
                        <li class="task-item">  
                            <div class="task-item-title"> Task 8</div>
                            <div class="task-item-body"></div>
                            <div class="task-item-actions">
                                <div class="task-item-actions-info">
                                    <div class="info-messages"> ${collab_message} <span>1</span></div>
                                </div>
                                <div class="task-item-actions-user">
                                    <img class="avatar" src="https://lh3.googleusercontent.com/a-/AOh14GjhEPN7UazL97l6qFIRIYUoLY-PNNPC93Zw4EVT=s96-c" alt="user avatar">
                                </div>

                            </div>
                        </li>
                    </ul>
                    <div class="task-items-add">
                        ${collab_plus}
                        <span>Add new task</span>
                    </div>
                </div>
            </li>
        

         </ol>

         </div>`;
    }
};
CollabTasks100554 = __decorate([
    customElement('collab-tasks-100554')
], CollabTasks100554);
export { CollabTasks100554 };
