/// <mls shortName="wcdCommandUndo" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export function execute(param) {
    if (!param?.selectedIca)
        throw new Error('invalid param.selectedIca');
    if (!param.overlay || typeof param.overlay.selectItem !== 'function')
        throw new Error('invalid param.overlay');
    if (!param.args || !(param.args instanceof KeyboardEvent))
        throw new Error('invalid param.args');
    const e = param.args;
    e.preventDefault();
    if (!e.ctrlKey && !e.metaKey)
        return;
    if (e.key.toLocaleLowerCase() !== 'z')
        return;
    const { shortName, project } = mls.actual[2]?.left;
    if (!shortName || !project)
        throw new Error('invalid file selected');
    const uri = getUri(`_${project}_${shortName}`, '.html');
    let model = monaco.editor.getModel(uri);
    if (!model)
        throw new Error('invalid model');
    if (model.undo)
        model.undo();
}
function getUri(shortFN, ftype) {
    return monaco.Uri.parse(`file://server/${shortFN}${ftype}`);
}
