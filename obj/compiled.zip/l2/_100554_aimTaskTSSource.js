/// <mls shortName="aimTaskTSSource" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { getInfoMyService } from "./_100554_aimHelper";
import { AimTaskBase } from "./_100554_aimTaskBase";
let AimTaskTSSource = class AimTaskTSSource extends AimTaskBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    onInitializing() {
        this.getSource();
    }
    getSource() {
        // get typescript source from ref
        /*const result = 'let a = b;\nconsole.log("minha laranjeira");';
        this.notifyCompleteByStatus('ok', result);*/
        this.getFileSource().then((ret) => {
            const result = ret;
            this.notifyCompleteByStatus('ok', result);
        }).catch((e) => {
            this.notifyCompleteByStatus('error', e);
        });
    }
    getFileSource() {
        return new Promise(async (resolve, reject) => {
            try {
                const info = getInfoMyService(this);
                if (!info || (info.actServiceOp && info.actServiceOp.tagName !== 'SERVICE-SOURCE-100554')) {
                    reject('Not found info in getFileSource');
                    return;
                }
                const position = info.position === 'left' ? 'right' : 'left';
                if (!mls.actual[2][position]) {
                    reject('No files selected in getFileSource');
                    return;
                }
                const { project, shortName, extension, folder } = mls.actual[2][position];
                const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, extension);
                const file = mls.stor.files[key];
                if (!file) {
                    reject('Not found stor.file in getFileSource');
                    return;
                }
                const ret = await file.getContent();
                this.taskChild.ref = info.actServiceOp.getActualRef();
                resolve(ret);
            }
            catch (e) {
                reject(e);
            }
        });
    }
};
AimTaskTSSource = __decorate([
    customElement('aim-task-t-s-source-100554')
], AimTaskTSSource);
