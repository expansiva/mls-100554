/// <mls shortName="wcdDialogVideo" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { getDSInstance } from './_100554_libDesignSystem';
import { execute } from './_100554_wcdCommandAddVideo';
import { globalWcd } from './_100554_wcdState';
let WcdDialogVideo100554 = class WcdDialogVideo100554 extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.videos = [];
    }
    async initDsInstance(project, dsIndex) {
        this.dsInstance = await getDSInstance(project, dsIndex);
        await this.dsInstance.init();
    }
    async firstUpdated() {
        const { project } = mls.actual[5];
        if (!project)
            return;
        this.project = project;
        await this.initDsInstance(project, 0);
        this.videos = await this.getVideos(project);
    }
    recalculeIcaHeight() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        const height = this.getBoundingClientRect()?.height;
        if (this.lastHeight === undefined)
            this.lastHeight = globalWcd.elICA.style.height;
        globalWcd.elICA.style.height = height + 'px';
    }
    async getVideos(project) {
        if (!this.dsInstance || !this.dsInstance.assets)
            return [];
        const videos = [];
        const list = this.dsInstance.assets.list;
        for await (const item of Object.entries(list)) {
            const [key, value] = item;
            const src = `/l3/${project}/${value.path}/${value.shortname}`;
            if (value.type === 'video') {
                const srcCache = await this.getUrlL3(src) || '';
                const newVideoAssetsItem = {
                    ...value,
                    src,
                    srcCache
                };
                videos.push(newVideoAssetsItem);
            }
        }
        return videos;
    }
    async getUrlL3(src) {
        const parts = src.split('/');
        const folderNumber = parts[2];
        const dsNumber = "3";
        const remainingParts = parts.slice(3).join('_');
        const result = `${folderNumber}_${dsNumber}_${remainingParts}`;
        const storFile = mls.stor.files[result];
        if (!storFile)
            throw new Error('Invalid url');
        const urlCache = await storFile.saveContentInCacheIfNeed();
        return urlCache;
    }
    onUploadClick() {
        if (!this.inputFile)
            return;
        this.inputFile.click();
    }
    onChangeImage(event) {
        const input = event.target;
        if (input.files && input.files[0]) {
            this.addVideo(input.files[0]);
        }
    }
    async addVideo(file) {
        if (!this.dsInstance || !this.dsInstance.assets || !this.project)
            return;
        const dsName = this.dsInstance.dsname;
        const path = `ds/${dsName}/assets`;
        await this.dsInstance.assets.add(path, file.name, [], '', 'video', file);
        this.videos = await this.getVideos(this.project);
        await this.updateComplete;
        const last = this.videos[this.videos.length - 1];
        this.handleClickGallery(last);
    }
    async handleClickGallery(item, ev) {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.myParent)
            throw new Error('Invalid window.wcdState.myParent');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        ev?.preventDefault();
        ev?.stopPropagation();
        await execute({
            args: { src: item.src },
            overlay: globalWcd.myParent?.parentElement?.parentElement,
            selectedIca: globalWcd.elICA,
        });
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('videos')) {
            this.recalculeIcaHeight();
        }
    }
    disconnectedCallback() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (globalWcd.elICA)
            globalWcd.elICA.style.height = this.lastHeight || '';
        else if (this.lastIca)
            this.lastIca.style.height = this.lastHeight || '';
        super.disconnectedCallback();
    }
    render() {
        this.lastIca = globalWcd.elICA;
        return html `

            <div class="container">
                <div class="actions-buttons">
                    <button @click=${this.onUploadClick}>Upload</button>
                    <input @change=${this.onChangeImage} type="file" id="file-input" accept="image/*" style="display: none;">
                </div>
                <div class="gallery">
                    ${this.videos.map((video) => {
            return html `<video controls @click=${(ev) => { this.handleClickGallery(video, ev); }} src=${video.srcCache} alt=${video.description}></video>`;
        })}
                </div>

            </div>

        `;
    }
};
WcdDialogVideo100554.styles = css `

        :host{
            display:block;
            width:100%
        }
        .container{
            padding:1rem;
        }
        .actions-buttons{
            padding: 10px;
            display:flex;
            justify-content:end;
            margin-bottom:1rem;
        }
        .actions-buttons button{

            background-color: var(--active-color);
            border-radius: 8px;
            border:none;
            box-shadow: 0px 1px 3px 0px var(--grey-color);
            display: flex;
            flex-direction: row;
            justify-content: center;
            gap:.2rem;
            font-weight: 700;
            align-items: center;
            height: 40px;
            transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
            padding: 0.5rem;
            color: #fff;;
            cursor:pointer;
            width:150px;
            outline:none;
            &:hover {
                opacity:.8;
            }
         }
        .gallery {
            display: grid;
                grid-template-columns: repeat(auto-fill, minmax(500px, 1fr));
                grid-auto-rows: 500px;
                gap: 10px;
                padding: 10px;
        }

        .gallery video {
            width: 100%;
            height: 100%;
            width: 100%;
            // object-fit: cover;
            display: block;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, filter 0.3s ease;
            cursor:pointer;
        }
        .gallery video:hover {
            filter: brightness(0.7);
        }
        
        @media (max-width: 768px) {
            .gallery {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
        }
    `;
__decorate([
    property()
], WcdDialogVideo100554.prototype, "videos", void 0);
__decorate([
    query('#file-input')
], WcdDialogVideo100554.prototype, "inputFile", void 0);
WcdDialogVideo100554 = __decorate([
    customElement('wcd-dialog-video-100554')
], WcdDialogVideo100554);
export { WcdDialogVideo100554 };
