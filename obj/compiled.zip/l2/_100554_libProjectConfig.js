/// <mls shortName="libProjectConfig" project="100554" enhancement="_blank" groupName="other" />
export const projectConfig = {};
const FILENAME = 'project';
const LEVEL = 5;
const EXTENSION = '.json';
export async function getConfigProject(project) {
    if (projectConfig[project])
        return projectConfig[project];
    if (project === undefined)
        return undefined;
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    let configFile = mls.stor.files[key];
    if (!configFile)
        return undefined;
    const content = await configFile.getContent();
    if (!content || typeof content !== 'string')
        return undefined;
    const config = JSON.parse(content);
    projectConfig[project] = config;
    return projectConfig[project];
}
export async function updateConfigProject(project, newConfig) {
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    projectConfig[project] = newConfig;
    const configFile = mls.stor.files[key];
    if (!configFile)
        throw new Error('No config file!');
    await mls.stor.localStor.setContent(configFile, {
        contentType: 'string',
        content: JSON.stringify(newConfig, null, 2)
    });
}
export async function createConfigFile(project) {
    if (project === undefined)
        throw new Error('Invalid project');
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    let configFile = mls.stor.files[key];
    if (configFile)
        throw new Error('config file already exists');
    const config = await _createConfigFile(project);
    projectConfig[project] = config;
    return projectConfig[project];
}
async function _createConfigFile(project) {
    const newConfig = {
        orgName: '',
        designSystems: [],
        languages: []
    };
    const content = JSON.stringify(newConfig);
    const params = {
        project,
        level: LEVEL,
        shortName: FILENAME,
        extension: EXTENSION,
        versionRef: '0',
        folder: ''
    };
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('invalid file');
    file.status = 'new';
    const fileInfo = {
        content,
        contentType: 'string',
    };
    await mls.stor.localStor.setContent(file, fileInfo);
    return newConfig;
}
