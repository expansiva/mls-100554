/// <mls shortName="libProjectConfig" project="100554" enhancement="_blank" groupName="other" />
export const projectConfig = {};
const FILENAME = 'project';
const LEVEL = 5;
const EXTENSION = '.json';
export async function clearLocalChanges(project) {
    if (project === undefined)
        return;
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    let configFile = mls.stor.files[key];
    if (!configFile)
        return;
    const config = await getConfigProject(project, true);
    if (!config)
        return;
    updateConfigProject(project, config);
    configFile.inLocalStorage = false;
}
export async function getConfigProject(project, ignoreLocalChanges = false) {
    if (project === undefined)
        return undefined;
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    let configFile = mls.stor.files[key];
    if (!configFile)
        return undefined;
    if (!projectConfig[project] /*|| (projectConfig[project].versionRef !== configFile.versionRef)*/ || ignoreLocalChanges) {
        const lastStatus = configFile.inLocalStorage;
        if (ignoreLocalChanges) {
            configFile.inLocalStorage = false;
        }
        const content = await configFile.getContent();
        configFile.inLocalStorage = lastStatus;
        if (!content || typeof content !== 'string')
            return undefined;
        const config = JSON.parse(content);
        projectConfig[project] = {
            config,
            versionRef: configFile.versionRef
        };
    }
    return projectConfig[project].config;
}
export async function updateConfigProject(project, newConfig) {
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    projectConfig[project].config = newConfig;
    const configFile = mls.stor.files[key];
    if (!configFile)
        throw new Error('No config file!');
    await mls.stor.localStor.setContent(configFile, {
        contentType: 'string',
        content: JSON.stringify(newConfig, null, 2)
    });
}
export async function updateConfigProjectPlugins(project, newPlugins) {
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    projectConfig[project].config.plugins = newPlugins;
    const configFile = mls.stor.files[key];
    if (!configFile)
        throw new Error('No config file!');
    await mls.stor.localStor.setContent(configFile, {
        contentType: 'string',
        content: JSON.stringify(projectConfig[project].config, null, 2)
    });
}
export async function createConfigFile(project) {
    if (project === undefined)
        throw new Error('Invalid project');
    const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, '', EXTENSION);
    let configFile = mls.stor.files[key];
    if (configFile)
        throw new Error('config file already exists');
    const config = await _createConfigFile(project);
    projectConfig[project].config = config;
    return projectConfig[project].config;
}
async function _createConfigFile(project) {
    const newConfig = {
        orgName: '',
        designSystems: [],
        languages: [],
        plugins: {},
        reasons: {},
        services: [],
        servicesConfigEnabled: false,
    };
    const content = JSON.stringify(newConfig);
    const params = {
        project,
        level: LEVEL,
        shortName: FILENAME,
        extension: EXTENSION,
        versionRef: '0',
        folder: ''
    };
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('invalid file');
    file.status = 'new';
    const fileInfo = {
        content,
        contentType: 'string',
    };
    await mls.stor.localStor.setContent(file, fileInfo);
    return newConfig;
}
