var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="icaTestPage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, css, LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';
import { getFormComponentsEvents } from './_100554_icaBaseDescription';
let IcaTestPage100554 = class IcaTestPage100554 extends LitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    render() {
        console.info(getFormComponentsEvents('forms', 'input', 'number'));
        window.globalState = {
            wcdAddEventSelected: '',
            tables: {
                sex: [{ key: 'm', value: 'masculino' }, { key: 'f', value: 'feminino' }],
                events: [{ key: 'click', value: 'click', description: 'evento onclick' }, { key: 'blur', value: 'blur', description: 'evento onblur' }, { key: 'change', value: 'change', description: 'evento onchange' }],
            },
            users: [{
                    name: 'Wagner',
                    age: 63,
                    city: 'SP',
                    sex: 'm'
                },
                {
                    name: 'Guilherme',
                    age: 28,
                    city: 'SP',
                    sex: 'm'
                }]
        };
        return html ``;
    }
};
IcaTestPage100554.styles = css `:host {
        display: flex;
    }`;
IcaTestPage100554 = __decorate([
    customElement('ica-test-page-100554')
], IcaTestPage100554);
export { IcaTestPage100554 };
