/// <mls shortName="serviceDsStyleFilter" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabDSInputRange } from './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    grayscale: 'Tons de cinza',
    blur: 'Desfoque',
    sepia: 'Sepia',
    saturate: 'Saturar',
    opacity: 'Opacidade',
    brightness: 'Brilho',
    contrast: 'Contraste',
    hueRotate: 'Rotação de matiz',
    invert: 'Inverter',
};
const message_en = {
    loading: 'Loading...',
    grayscale: 'Grayscale',
    blur: 'Blur',
    sepia: 'Sepia',
    saturate: 'Saturate',
    opacity: 'Opacity',
    brightness: 'Brightness',
    contrast: 'Contrast',
    hueRotate: 'Hue-rotate',
    invert: 'Invert',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsStyleFilter = class ServiceDsStyleFilter extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.filter = {
            grayscale: '',
            blur: '',
            sepia: '',
            saturate: '',
            opacity: '',
            brightness: '',
            contrast: '',
            huerotate: '',
            invert: ''
        };
        this.myUpp = false;
        this.opened = false;
        this.error = '';
        this.helper = '_100554_serviceDsStyleFilter';
        this.details = {
            icon: '&#xf0b0',
            state: 'foreground',
            position: 'right',
            tooltip: 'Filter',
            visible: false,
            tags: ['ds_styles'],
            widget: '_100554_serviceDsStyleFilter',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
        };
        this.menu = {
            title: 'Filter',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            iconDefault: '',
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon
        };
        //-------------IMPLEMENTS--------------
        this.timeonChangeProp = -1;
        this.timeLoader = -1;
        this.arrayGallery = [
            '',
            'filter: brightness(20%) sepia(1) hue-rotate(180deg) saturate(5);',
            'filter: brightness(20%) sepia(1) hue-rotate(310deg) saturate(5);',
            'filter: brightness(70%) sepia(1) hue-rotate(360deg) saturate(6);',
            'filter: brightness(70%) sepia(1) hue-rotate(206deg) saturate(6);',
            'filter: brightness(40%) sepia(1) hue-rotate(-42deg) saturate(6);',
            'filter: brightness(40%) sepia(1) hue-rotate(-40deg);',
            'filter: blur(2px);',
            'filter: invert(100%) sepia(2);',
            'filter: brightness(40%) sepia(1) hue-rotate(-40deg);'
        ];
        initCollabDSInputRange();
        this.setEvents();
    }
    onServiceClick(visible, reinit) {
        if (visible || reinit) {
            if (this.opened === false)
                this.opened = true;
            this.fireEventAboutMe();
        }
    }
    //-------------EVENTS--------------
    setEvents() {
        mls.events.addEventListener([3], ['DSStyleChanged'], (ev) => {
            this.onstylechanged(ev.desc);
        });
        mls.events.addEventListener([3], ['DSStyleSelected'], (ev) => {
            this.onDSStyleSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleUnSelected'], (ev) => {
            this.onDSStyleUnSelected(ev);
        });
        mls.events.addEventListener([3], ['DSStyleCursorChanged'], (ev) => {
            this.onDSStyleCursorChanged(ev);
        });
    }
    onstylechanged(desc) {
        const obj = JSON.parse(desc);
        if (obj.emitter === 'left' && this.visible === 'true' && obj.value.length > 0) {
            this.setValues(obj.value);
        }
    }
    onDSStyleSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.length > 0 && !params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'A');
        if (this.showNav2Item)
            this.showNav2Item(true);
    }
    onDSStyleUnSelected(ev) {
        const params = ev.desc ? JSON.parse(ev.desc) : [];
        if (params.service.includes(this.helper) || !this.serviceItemNav)
            return;
        this.serviceItemNav.setAttribute('mode', 'H');
        if (this.showNav2Item)
            this.showNav2Item(false);
    }
    onDSStyleCursorChanged(ev) {
        const rc = JSON.parse(ev.desc);
        if (rc.helper === this.helper) {
            if (this.visible === 'true' || !this.serviceItemNav)
                return;
            this.serviceItemNav.click();
        }
    }
    //-------------COMPONENT-----------
    connectedCallback() {
        super.connectedCallback();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html ` ${this.opened ?
            html `${this.renderFilter()}${this.renderGallery()}` :
            html `${this.msg.loading}`} 
        `;
    }
    renderFilter() {
        return html `
            <div>
                <div class="groupEdit">
                    <span>${this.msg.grayscale}</span>
                    <collab-ds-input-range-100554 prop="grayscale" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.blur}</span>
                    <collab-ds-input-range-100554 prop="blur" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.sepia}</span>
                    <collab-ds-input-range-100554 prop="sepia" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.saturate}</span>
                    <collab-ds-input-range-100554 prop="saturate" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.opacity}</span>
                    <collab-ds-input-range-100554 prop="opacity" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.brightness}</span>
                    <collab-ds-input-range-100554 prop="brightness" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.contrast}</span>
                    <collab-ds-input-range-100554 prop="contrast" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.hueRotate}</span>
                    <collab-ds-input-range-100554 prop="huerotate" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
                <div class="groupEdit">
                    <span>${this.msg.invert}</span>
                    <collab-ds-input-range-100554 prop="invert" value="0px" useSelect="false" @onchange="${(e) => this.onChangeProp(e.detail)}"></collab-ds-input-range-100554>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div style="display: flex; justify-content: center; align-items: center; gap: 1rem; padding: 1rem; flex-wrap: wrap; cursor:pointer">
                ${repeat(this.arrayGallery, ((key) => key), ((css, index) => {
            return html `
                                <img style="width:60px;${css}" @click="${this.clickGallery}" .gallery=${css} src="https://angrytools.com/css-generator/img/rose.jpg" />
                            `;
        }))}
            </div>
        
        `;
    }
    onChangeProp(obj) {
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.mountValue();
        }, 500);
    }
    fireEventAboutMe() {
        const rc = {
            emitter: 'right-get',
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc), 500);
    }
    emitEvent(obj) {
        if (this.myUpp)
            return;
        const rc = {
            emitter: this.position,
            value: [obj],
            helper: this.helper
        };
        if (typeof mls !== 'object')
            return;
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
    showLoader(loader) {
        clearTimeout(this.timeLoader);
        this.timeLoader = setTimeout(() => {
            this.loading = loader;
        }, 200);
    }
    mountValue() {
        if (!this.shadowRoot)
            return;
        let value = '';
        const elG = this.shadowRoot.querySelector('*[prop="grayscale"]');
        const elB = this.shadowRoot.querySelector('*[prop="blur"]');
        const elS = this.shadowRoot.querySelector('*[prop="sepia"]');
        const elSt = this.shadowRoot.querySelector('*[prop="saturate"]');
        const elO = this.shadowRoot.querySelector('*[prop="opacity"]');
        const elBr = this.shadowRoot.querySelector('*[prop="brightness"]');
        const elC = this.shadowRoot.querySelector('*[prop="contrast"]');
        const elH = this.shadowRoot.querySelector('*[prop="huerotate"]');
        const elI = this.shadowRoot.querySelector('*[prop="invert"]');
        value += elG.value ? 'grayscale(' + elG.value + '%)' : '';
        value += elB.value ? ' blur(' + elB.value + 'px)' : '';
        value += elS.value ? ' sepia(' + elS.value + ')' : '';
        value += elSt.value ? ' saturate(' + elSt.value + ')' : '';
        value += elO.value ? ' opacity(' + elO.value + ')' : '';
        value += elBr.value ? ' brightness(' + elBr.value + '%)' : '';
        value += elC.value ? ' contrast(' + elC.value + '%)' : '';
        value += elH.value ? ' hue-rotate(' + elH.value + 'deg)' : '';
        value += elI.value ? ' invert(' + elI.value + '%)' : '';
        const change = {
            key: 'filter',
            value
        };
        this.emitEvent(change);
    }
    setValues(block) {
        if (!this.shadowRoot)
            return;
        const myFilter = this.filter;
        Object.keys(myFilter).forEach((item) => { myFilter[item] = ''; });
        const textFilter = block.find((item) => item.key === 'filter');
        if (!textFilter)
            return;
        this.myUpp = true;
        const { value } = textFilter;
        const filter = value.split(' ');
        filter.forEach((item) => {
            const prop = item.substr(0, item.indexOf('(')).replace('-', '');
            item = item.substr(item.indexOf('('), item.length);
            const num = item.match(/[\.-\d]/g)?.join('');
            if (myFilter[prop] !== undefined)
                myFilter[prop] = num;
        });
        const elG = this.shadowRoot.querySelector('*[prop="grayscale"]');
        const elB = this.shadowRoot.querySelector('*[prop="blur"]');
        const elS = this.shadowRoot.querySelector('*[prop="sepia"]');
        const elSt = this.shadowRoot.querySelector('*[prop="saturate"]');
        const elO = this.shadowRoot.querySelector('*[prop="opacity"]');
        const elBr = this.shadowRoot.querySelector('*[prop="brightness"]');
        const elC = this.shadowRoot.querySelector('*[prop="contrast"]');
        const elH = this.shadowRoot.querySelector('*[prop="huerotate"]');
        const elI = this.shadowRoot.querySelector('*[prop="invert"]');
        if (elG)
            elG.value = this.filter.grayscale;
        if (elB)
            elB.value = this.filter.blur;
        if (elS)
            elS.value = this.filter.sepia;
        if (elSt)
            elSt.value = this.filter.saturate;
        if (elO)
            elO.value = this.filter.opacity;
        if (elBr)
            elBr.value = this.filter.brightness;
        if (elC)
            elC.value = this.filter.contrast;
        if (elH)
            elH.value = this.filter.huerotate;
        if (elI)
            elI.value = this.filter.invert;
        this.myUpp = false;
    }
    clickGallery(e) {
        const el = e.target;
        if (!el)
            return;
        const css = el.gallery;
        //if (!css) return;
        const commands = css.split(';');
        const changes = [];
        commands.forEach((item) => {
            const [key, value] = item.split(':');
            if (!key)
                return;
            changes.push({
                key: key.trim(),
                value: value.trim()
            });
        });
        if (changes.length <= 0)
            changes.push({ key: 'filter', value: '' });
        this.setValues(changes);
        const rc = {
            emitter: 'right',
            value: changes,
            helper: this.helper
        };
        mls.events.fire([3], ['DSStyleChanged'], JSON.stringify(rc));
    }
};
ServiceDsStyleFilter.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsStyleFilter.prototype, "opened", void 0);
__decorate([
    property()
], ServiceDsStyleFilter.prototype, "error", void 0);
__decorate([
    property()
], ServiceDsStyleFilter.prototype, "helper", void 0);
ServiceDsStyleFilter = __decorate([
    customElement('service-ds-style-filter-100554')
], ServiceDsStyleFilter);
export { ServiceDsStyleFilter };
