/// <mls shortName="pluginStyleMargin" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, query, queryAll } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { propertyDataSource } from './_100554_collabDecorators';
import { globalState } from './_100554_collabState';
import { getMessageKey } from './_100554_collabLitElement';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
import { collab_lock, collab_lock_open, collab_margin_bottom, collab_margin_top, collab_margin_left, collab_margin_right, } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    all: 'Group',
    margin: 'Margin',
    top: 'Superior',
    left: 'Esquerda',
    bottom: 'Inferior',
    right: 'Direita',
    description: 'Este plugin permite ajustar margens de maneira simples e intuitiva. Ideal para desenvolvedores que buscam precisão no espaçamento dos elementos, ele facilita a definição de distâncias internas e externas para garantir um layout consistente e bem estruturado.'
};
const message_en = {
    all: 'Group',
    margin: 'Margin',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
    description: 'This plugin enables easy and intuitive adjustments of margins.Ideal for developers seeking precise element spacing, it streamlines the setup of inner and outer distances to ensure a consistent and well-structured layout.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['margin*'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleSpacing = class PluginStyleSpacing extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-margin-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-margin-100554 .helper-group-title{margin:0;margin-top:var(--space-16);margin-bottom:var(--space-8);display:flex;gap:1.5rem}plugin-style-margin-100554 .helper-group-lock{display:flex;justify-content:start;align-items:center}plugin-style-margin-100554 .helper-group-lock label{cursor:pointer}plugin-style-margin-100554 .helper-group-lock i{margin-left:var(--space-8)}plugin-style-margin-100554 .group{margin-left:var(--space-16);margin-top:var(--space-8);font-size:var(--font-size-12);display:flex;flex-direction:column;gap:.7rem}plugin-style-margin-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-margin-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-margin-100554 .gallery{display:flex;justify-content:start;align-items:center;gap:1rem;padding:1rem;flex-wrap:wrap;cursor:pointer}plugin-style-margin-100554 .gallery .box{background-color:var(--bg-primary-color);border:1px dashed var(--text-primary-color)}plugin-style-margin-100554 .gallery .box>div{background-color:var(--text-primary-color);width:40px;height:40px}`);
        this.msg = messages['en'];
        this.position = 'left';
        this.showFull = 'true';
        this.marginLocked = false;
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.timeonChangeMargin = -1;
        this.gallery = [
            { style: 'margin: 10px', state: { marginBottom: '10px', marginTop: '10px', marginLeft: '10px', marginRight: '10px' } },
            { style: 'margin: 10px 0', state: { marginBottom: '10px', marginTop: '10px', marginLeft: '0', marginRight: '0' } },
            { style: 'margin: 0 10px', state: { marginBottom: '0', marginTop: '0', marginLeft: '10px', marginRight: '10px' } },
            { style: 'margin-left: 10px', state: { marginBottom: '', marginTop: '', marginLeft: '10px', marginRight: '' } },
            { style: 'margin-right: 10px', state: { marginBottom: '', marginTop: '', marginLeft: '', marginRight: '10px' } },
            { style: 'margin-top: 10px', state: { marginBottom: '', marginTop: '10px', marginLeft: '', marginRight: '' } },
            { style: 'margin-bottom: 10px', state: { marginBottom: '10px', marginTop: '', marginLeft: '', marginRight: '' } },
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!_value.selector || !_value.lessCSS || !_value.lessCSS.lessAST || !_value.lessCSS.lessAST.ast[_value.selector])
            return;
        const actualAst = _value.lessCSS.lessAST.ast[_value.selector];
        if (!actualAst)
            return;
        let hasRuleMarginInAST = false;
        Object.keys(actualAst).forEach((prop) => {
            if (prop.startsWith('margin'))
                hasRuleMarginInAST = true;
        });
        this.clear();
        if (hasRuleMarginInAST) {
            this._onIcaStateChange();
        }
    }
    clear() {
        this.marginLeft = undefined;
        this.marginRight = undefined;
        this.marginTop = undefined;
        this.marginBottom = undefined;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `

        ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderMargin()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderMargin() {
        return html `
            <h5 class="helper-group-title" >${this.msg.margin}</h5>
            <div class="helper-group-lock">
                <input id="helper-margin-lock" ?checked=${this.marginLocked} type="checkbox" @change=${this.handleChangeLockMargin}>
                <label for="helper-margin-lock"> ${this.msg.all}</label>
                <i>${this.marginLocked ? collab_lock : collab_lock_open}</i>
            </div>

            <div class="group">

                <div class="group-edit">
                    <i data-tooltip="${this.msg.top}">${collab_margin_top}</i>
                    <collab-ds-input-range-100554
                        prop="margin-top"
                        value=${this.marginTop}
                        .arraySelect=${this.tpMeasures} 
                        group="margin"
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.left}" >${collab_margin_left}</i>
                    <collab-ds-input-range-100554
                        prop="margin-left"
                        value="${this.marginLeft}"
                        .arraySelect=${this.tpMeasures} 
                        group="margin" 
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>   
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.bottom}">${collab_margin_bottom}</i>
                    <collab-ds-input-range-100554
                        prop="margin-bottom"
                        value=${this.marginBottom}
                        .arraySelect=${this.tpMeasures} 
                        group="margin" 
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.right}">${collab_margin_right}</i>
                    <collab-ds-input-range-100554
                        prop="margin-right"
                        value=${this.marginRight}
                        .arraySelect=${this.tpMeasures} 
                        group="margin" 
                        @onchange="${(e) => this.handleChangeMargin(e)}"
                    ></collab-ds-input-range-100554>

                </div>
            </div>

        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `
                <div class="box" @click=${() => { this.onGalleryClick(galleryItem); }}>
                    <div style="${galleryItem.style}"></div>
                </div>`;
        }))}
            </div>
        
        `;
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    handleChangeMargin(e) {
        clearTimeout(this.timeonChangeMargin);
        const el = e.detail.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(prop);
        this.timeonChangeMargin = setTimeout(() => {
            if (!this.marginLocked) {
                if (!convertedProp)
                    return;
                this[convertedProp] = el.value;
                this.setState();
                return;
            }
            this.marginInputs?.forEach((inp) => {
                if (inp === el)
                    return;
                inp.value = el.value;
            });
            this.marginBottom = this.marginLeft = this.marginRight = this.marginTop = el.value;
            this.setState();
        }, 100);
    }
    handleChangeLockMargin() {
        if (!this.inputLockM)
            return;
        this.marginLocked = this.inputLockM.checked;
    }
    setState() {
        const allMargin = [this.marginTop, this.marginLeft, this.marginBottom, this.marginRight];
        const areMarginsAllEqual = allMargin.every(value => value === allMargin[0]);
        const areMarginPairsEqual = (this.marginTop === this.marginBottom) && (this.marginLeft === this.marginRight);
        let marginValue;
        if (areMarginsAllEqual)
            marginValue = this.marginTop;
        else if (areMarginPairsEqual)
            marginValue = `${this.marginTop} ${this.marginRight}`;
        else {
            marginValue = {
                marginTop: this.marginTop,
                marginRight: this.marginRight,
                marginBottom: this.marginBottom,
                marginLeft: this.marginLeft,
            };
        }
        this.updateMargins(marginValue);
    }
    updateMargins(margin) {
        globalState._ica.less[this.position].emitter = 'helper';
        const styles = globalState._ica.less[this.position].lessCSS.styles;
        if (typeof margin === 'string') {
            styles.marginTop = styles.marginRight = styles.marginBottom = styles.marginLeft = '';
            styles.margin = margin;
        }
        else {
            styles.margin = '';
            this.marginTop = styles.marginTop = margin.marginTop || '';
            this.marginRight = styles.marginRight = margin.marginRight || '';
            this.marginBottom = styles.marginBottom = margin.marginBottom || '';
            this.marginLeft = styles.marginLeft = margin.marginLeft || '';
        }
    }
    setValues(rule) {
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (propertyName.startsWith('margin-')) {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const el = this.querySelector(`collab-ds-input-range-100554[prop="${propertyName}"]`);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                    if (el)
                        el.defaultValue = propertyValue;
                }
            }
            this.checkMarginsEquals();
        }
    }
    checkMarginsEquals() {
        if ([this.marginBottom, this.marginLeft, this.marginRight, this.marginTop].every(margin => margin === this.marginBottom)) {
            this.marginLocked = true;
            if (this.inputLockM)
                this.inputLockM.checked = true;
        }
        else {
            this.marginLocked = false;
            if (this.inputLockM)
                this.inputLockM.checked = false;
        }
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    onGalleryClick(item) {
        this.marginBottom = item.state.marginBottom;
        this.marginTop = item.state.marginTop;
        this.marginLeft = item.state.marginLeft;
        this.marginRight = item.state.marginRight;
        this.checkMarginsEquals();
        this.setState();
    }
};
__decorate([
    propertyDataSource()
], PluginStyleSpacing.prototype, "state", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "position", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "showFull", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "marginLocked", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "marginLeft", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "marginRight", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "marginTop", void 0);
__decorate([
    property()
], PluginStyleSpacing.prototype, "marginBottom", void 0);
__decorate([
    query('#helper-margin-lock')
], PluginStyleSpacing.prototype, "inputLockM", void 0);
__decorate([
    queryAll('collab-ds-input-range-100554[group="margin"]')
], PluginStyleSpacing.prototype, "marginInputs", void 0);
PluginStyleSpacing = __decorate([
    customElement('plugin-style-margin-100554')
], PluginStyleSpacing);
export { PluginStyleSpacing };
