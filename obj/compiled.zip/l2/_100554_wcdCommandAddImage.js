/// <mls shortName="wcdCommandAddImage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export function execCommandAddImage(overlay, selectedIca, args) {
    if (!selectedIca)
        return;
    const elImage = document.createElement('ica-apresentation-images-images-100554');
    elImage.setAttribute('widget', 'wc-image-100554');
    // elImage.setAttribute('src', args.src || '');
    elImage.id = 'ica_apImage' + overlay.children.length + 1;
    selectedIca.insertAdjacentElement('afterend', elImage);
}
