/// <mls shortName="configDsDefaultAssets" project="100554" enhancement="_blank" groupName="other" />
import { Common } from './_100554_configDsDefaultCommon';
export class Asset extends mls.l3.Asset {
    constructor(dsIO, ds) {
        super(dsIO);
        this.add = (opt) => this._addAssets(opt.path, opt.shortname, opt.tags, opt.description, opt.assetType, opt.content, opt.reference);
        this.update = (path, shortname, tags, description, assetType) => this._updateAsset(path, shortname, tags, description, assetType);
        this.remove = (path, shortname) => this._removeAssets(path, shortname);
        this.find = (path, shortname) => this._find(path, shortname);
        this.list = {};
        this.ds = ds;
        this.methods = new Common(ds, dsIO);
        this.prepareAssets();
    }
    prepareAssets() {
        this.list = {};
        this.ds.assets.items.forEach((asset) => {
            const key = this.getKeyAsset(asset.path, asset.shortname);
            this.list[key] = asset;
        });
    }
    _find(path, shortname) {
        const key = this.getKeyAsset(path, shortname);
        return this.list[key];
    }
    getKeyAsset(path, shortname) {
        return `${path}_${shortname}`;
    }
    async _addAssets(path, shortname, tags, description, assetType, content, reference) {
        const newShortName = shortname.replace(/_/g, '-');
        const assetsByName = this.find(path, shortname);
        if (assetsByName)
            throw new Error(`assets: ${path}/${shortname} already exists`);
        const ext = newShortName.split('.').pop();
        const extensionIndex = newShortName.lastIndexOf('.');
        const fileNameWithoutExtension = newShortName.slice(0, extensionIndex);
        const fullpath = path;
        const asset = {
            description,
            reference,
            content: '',
            path,
            shortname: newShortName,
            src: '',
            tags,
            type: assetType,
            last_updated_by: this.methods.getUser(),
            last_updated: this.methods.getDateNow(),
        };
        const key = this.getKeyAsset(path, shortname);
        this.list[key] = asset;
        try {
            if (!reference)
                await this.methods.createNewFile(fileNameWithoutExtension, fullpath, ext || '', content);
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on upload assets:' + err.message));
        }
    }
    async _updateAsset(path, shortname, tags, description, assetType) {
        const assetsByName = this.find(path, shortname);
        if (!assetsByName)
            throw new Error(`assets: ${path}/${shortname} dont exists`);
        assetsByName.tags = tags;
        assetsByName.description = description;
        assetsByName.type = assetType;
        const key = this.getKeyAsset(path, shortname);
        this.list[key] = assetsByName;
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove assets:' + err.message));
        }
    }
    async _removeAssets(path, shortname) {
        const assetsByName = this.find(path, shortname);
        if (!assetsByName)
            throw new Error(`assets: ${path}/${shortname} dont exists`);
        const ext = shortname.split('.').pop();
        const extensionIndex = shortname.lastIndexOf('.');
        const fileNameWithoutExtension = shortname.slice(0, extensionIndex);
        const fullpath = path;
        const key = this.getKeyAsset(path, shortname);
        try {
            if (!assetsByName.reference)
                await this.methods.setContentFile(fileNameWithoutExtension, ext || '', fullpath, null);
            delete this.list[key];
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove assets:' + err.message));
        }
    }
}
