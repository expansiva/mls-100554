/// <mls shortName="wcdToolbox" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { CollabLitElement } from './_100554_collabLitElement';
export function initWCDToolbox() {
    return true;
}
let WCDToolbox = class WCDToolbox extends CollabLitElement {
    constructor() {
        // ------------ PROPERTIES ------------------
        super(...arguments);
        this.level = '';
        this.fcBeforeBackButton = undefined;
        this.hasImport = [];
        this.timeResize = 0;
    }
    //public actions: IActionsToolbox[] = [];
    get lastHelper() {
        if (!this.elICA)
            return '';
        return this.elICA['lasthelper'];
    }
    set lastHelper(helper) {
        if (!this.elICA)
            return;
        this.elICA['lasthelper'] = helper;
    }
    // ------------ COMPONENT-------------------
    connectedCallback() {
        super.connectedCallback();
        if (!this.elICA)
            return;
        const widgetName = this.elICA.getAttribute('widget');
        if (!widgetName)
            return;
        const widget = this.elICA.querySelector(widgetName);
        if (!widget)
            return;
        this.elMain = widget;
        this.setAttribute('widget', widget.tagName.toLowerCase());
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
    }
    firstUpdated() {
        if (!this.elMain)
            return;
        this._renderAction();
        this.updateSize(this.elMain, this, true);
        this.initObserverResize();
    }
    render() {
        return html `
         <wcd-toolbox-aux-background></wcd-toolbox-aux-background>
        `;
    }
    //---------------PUBLIC----------------
    updateSize(elBase, elChange, changePosition) {
        return this._updateSize(elBase, elChange, changePosition);
    }
    getAndSetScenaryOutDoor(op) {
        return this._getAndSetScenaryOutDoor(op);
    }
    backNavigationScenaryOutdoor() {
        return this._backNavigationScenaryOutdoor();
    }
    setIconsWcdToolbox(act, useSelf = false, updataSize = 'false') {
        return this._setIconsWcdToolbox(act, useSelf, updataSize);
    }
    updateBaseNoPadding(elBase, elChange) {
        return this._updateBaseNoPadding(elBase, elChange);
    }
    updateBackgroundAuxSize(tp = 'hide') {
        return this._updateBackgroundAuxSize(tp);
    }
    //---------------IMPLEMENTATION----------------
    async _renderAction(actions) {
        const parent = this.parentElement?.parentElement;
        if (!parent || !parent.getActionsTagsDefault)
            return;
        const defaultActions = parent.getActionsTagsDefault();
        if (!this.elICA || !this.elICA.getActionsTags)
            return;
        if (!actions)
            actions = this.elICA.getActionsTags();
        if (!this.shadowRoot)
            return;
        const allItens = this.shadowRoot.querySelectorAll('*');
        allItens.forEach((i) => {
            if (i.tagName.toLocaleLowerCase() === 'wcd-toolbox-aux-background')
                return;
            i.remove();
        });
        this.setDefaultToolBoxOptions();
        for await (let i of actions) {
            if (!this.shadowRoot)
                continue;
            if (defaultActions[i.name]) {
                const args = i.args ? i.args : undefined;
                const pos = i.position ? i.position : undefined;
                const toll = i.toolboxOptions ? i.toolboxOptions : undefined;
                i = Object.assign({}, defaultActions[i.name]);
                if (args)
                    i.args = args;
                if (pos)
                    i.position = pos;
                if (toll)
                    i.toolboxOptions = toll;
            }
            if (i.toolboxOptions)
                this.setToolBoxOptions(i.toolboxOptions);
            if (i.name === 'button') {
                this.addBackButton();
                continue;
            }
            if (!i.name.startsWith('_') || !i.level || (this.level && !i.level.includes(+this.level)))
                continue;
            const ok = await this.importWCDActions(i.name);
            if (!ok)
                continue;
            const el = document.createElement(convertFileNameToTag(i.name));
            el.className = `p ${i.position}`;
            el.myParent = this;
            el.elMain = this.elMain;
            el.elICA = this.elICA;
            el.style.zIndex = '9998';
            el.args = i.args;
            this.shadowRoot.appendChild(el);
        }
        ;
        this.adjustPositionIfNecessary();
    }
    setDefaultToolBoxOptions() {
        this.style.background = '';
        this.style.border = '';
    }
    setToolBoxOptions(info) {
        if (info.background)
            this.style.background = info.background;
        if (info.border)
            this.style.border = info.border;
    }
    async importWCDActions(imports) {
        try {
            if (this.hasImport.includes(imports))
                return true;
            if (!imports.startsWith('./'))
                imports = './' + imports;
            await import(imports);
            this.hasImport.push(imports);
            return true;
        }
        catch (e) {
            console.info(e);
            return false;
        }
    }
    _setIconsWcdToolbox(act, useSelf = false, updataSize = 'false') {
        if (useSelf)
            this._renderAction();
        else
            this._renderAction(act);
        this._updateBackgroundAuxSize();
        if (this.elMain && updataSize === 'size')
            this.updateSize(this.elMain, this, true);
        if (this.elMain && updataSize === 'padding')
            this._updateBaseNoPadding(this.elMain, this);
    }
    addBackButton() {
        if (!this.shadowRoot || !this.parentElement)
            return;
        const el = document.createElement('span');
        el.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM175 175c-9.4 9.4-9.4 24.6 0 33.9l47 47-47 47c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-47-47 47-47c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-47 47-47-47c-9.4-9.4-24.6-9.4-33.9 0z"/></svg>';
        el.className = `wcdBackButton`;
        el.title = 'back';
        el.style.cssText = `width: 18px; background-position: center; height: 18px; background-size: auto; background-repeat: no-repeat; z-index: 9;`;
        el.style.zIndex = '9999';
        el.onclick = (e) => {
            e.stopPropagation();
            if (this.fcBeforeBackButton) {
                this.fcBeforeBackButton(this);
                this.fcBeforeBackButton = undefined;
            }
            this._setIconsWcdToolbox([], true, 'size');
            this.backNavigationScenaryOutdoor();
        };
        this.shadowRoot.appendChild(el);
        setTimeout(() => {
            if (!this.isElementVisible(el)) {
                el.style.top = '0px';
                el.style.right = '0px';
            }
        }, 300);
    }
    getNav3() {
        if (!this)
            return;
        const bd = this.closest('body');
        if (!bd)
            return;
        const service = bd.service;
        if (!service)
            return;
        const nav3 = service.getNav3Service();
        if (!nav3)
            return;
        return nav3;
    }
    isElementVisible(element) {
        const rect = element.getBoundingClientRect();
        return (rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth));
    }
    ensureVisibility(elem) {
        const rect = elem.getBoundingClientRect();
        if (rect.right > window.innerWidth) {
            elem.style.left = `${window.innerWidth - rect.width}px`;
        }
        if (rect.bottom > window.innerHeight) {
            elem.style.top = `${window.innerHeight - rect.height}px`;
        }
    }
    //------SCENARY--------------------
    _getAndSetScenaryOutDoor(op) {
        return new Promise((resolve, reject) => {
            if (this.level !== '4')
                resolve(undefined);
            mls.events.fire(4, 'WCDEvent', `{"op":"${op}"}`);
            setTimeout(() => {
                if (this.wcServiceICA) {
                    resolve(this.wcServiceICA.querySelector('div'));
                }
                else {
                    const nav3 = this.getNav3();
                    if (!nav3 || !this.elMain)
                        resolve(undefined);
                    const wc = nav3.getActiveInstance('left');
                    if (!wc)
                        resolve(undefined);
                    if (wc.tagName !== 'SERVICE-ICA-100554')
                        resolve(undefined);
                    else {
                        this.wcServiceICA = wc;
                        resolve(wc.querySelector('div'));
                    }
                }
            }, 200);
        });
    }
    _backNavigationScenaryOutdoor() {
        if (this.level !== '4')
            return;
        mls.events.fire(4, 'WCDEvent', `{"op":"Navigation"}`);
    }
    initObserverResize() {
        if (!this.elICA)
            return;
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
        this.resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                if (!this.elMain)
                    return;
                clearTimeout(this.timeResize);
                this.timeResize = setTimeout(() => {
                    const attr = this.getAttribute('needresize');
                    if (!this.elMain || attr === 'false')
                        return;
                    this.updateSize(this.elMain, this, true);
                }, 500);
            }
        });
        this.resizeObserver.observe(this.elICA);
    }
    adjustPositionIfNecessary() {
        setTimeout(() => {
            if (!this.shadowRoot)
                return;
            let child = [];
            Array.from(this.shadowRoot.children).forEach((item) => {
                const tag = item.tagName.toLocaleLowerCase();
                const invalid = ['span', 'wcd-toolbox-aux-background'];
                if (invalid.includes(tag))
                    return;
                child.push(item);
            });
            if (child.length > 1) {
                child = this.organizeArray(child);
                for (let idx = 0; idx < child.length; idx++) {
                    const item1 = child[idx];
                    const item2 = child[idx + 1];
                    if (!item1 || !item2)
                        continue;
                    let rect1 = item1.getBoundingClientRect();
                    let rect2 = item2.getBoundingClientRect();
                    const overlap = this.rectsOverlap(rect1, rect2);
                    if (overlap) {
                        const base = item1.style.left !== '' ? parseInt(item1.style.left, 10) : 0;
                        item2.style.left = base > 0 ? (base + 20) + 'px' : `${((rect1.right - rect1.left) + 20)}px`;
                    }
                }
            }
        }, 500);
    }
    calculateHorizontalOffset(element1, element2, padding = 20) {
        const rect1 = element1.getBoundingClientRect();
        const rect2 = element2.getBoundingClientRect();
        if (rect1.right > rect2.left && rect1.left < rect2.right) {
            const offset = (rect1.right - rect2.left) + padding;
            return offset;
        }
        return 0;
    }
    organizeArray(elementsArray) {
        const classOrder = ['p-l1', 'p-m1', 'p-r1',
            'p-l2', 'p-m2', 'p-r2',
            'p-l3', 'p-m3', 'p-r3',
            'p-l4', 'p-m4', 'p-r4'];
        // 2. Função de comparação para usar no sort
        const compareByClass = (a, b) => {
            // Encontre a classe de cada elemento que esteja na lista de ordem
            const aClass = classOrder.find(cls => a.classList.contains(cls));
            const bClass = classOrder.find(cls => b.classList.contains(cls));
            // Compare as posições dessas classes na lista
            return classOrder.indexOf(aClass) - classOrder.indexOf(bClass);
        };
        return elementsArray.sort(compareByClass);
    }
    rectsOverlap(rect1, rect2) {
        return !(rect1.right < rect2.left ||
            rect1.left > rect2.right ||
            rect1.bottom < rect2.top ||
            rect1.top > rect2.bottom);
    }
    _updateSize(elBase, elChange, changePosition) {
        if (!elBase)
            return;
        setTimeout(() => {
            const display = elChange.style.display;
            elChange.style.display = 'none!important';
            //const icaBase = elBase.parentElement;
            //if (!icaBase) return;
            const ad3 = (n1, s1, s2) => n1 + parseInt(s1, 10) + parseInt(s2, 10);
            const { marginTop, marginBottom, marginLeft, marginRight, paddingTop, paddingBottom, paddingLeft, paddingRight } = window.getComputedStyle(elBase);
            let { width, height, y } = elBase.getBoundingClientRect();
            let left = 0;
            let top = 0;
            left -= parseInt(marginLeft, 10);
            top -= parseInt(marginTop, 10);
            width = Math.max(ad3(width, marginLeft, marginRight), ad3(0, paddingLeft, paddingRight));
            if (width > elBase.ownerDocument.body.clientWidth)
                width -= 3;
            height = Math.max(ad3(height, marginTop, marginBottom), ad3(0, paddingTop, paddingBottom));
            const grandFahter = elBase.parentElement && elBase.parentElement.parentElement ? elBase.parentElement.parentElement : undefined;
            if (grandFahter) {
                const display = window.getComputedStyle(grandFahter).display;
                if (['flex'].includes(display) && elBase.parentElement) {
                    const fTop = elBase.parentElement.getClientRects()[0].top;
                    const bTop = elBase.getClientRects()[0].top;
                    top = fTop - bTop;
                    top = top < 0 ? top * -1 : top;
                }
            }
            if (changePosition) {
                elChange.style.left = `${(left - 1) < 0 ? 0 : (left - 1)}px`;
                elChange.style.top = `${top - 1}px`;
            }
            elChange.style.width = `${width + 2}px`;
            elChange.style.height = `${height + 2}px`;
            elChange.style.display = display;
        }, 50);
    }
    _updateBackgroundAuxSize(tp = 'hide') {
        if (!this.shadowRoot)
            return;
        const elChange = this.shadowRoot.querySelector('wcd-toolbox-aux-background');
        const elBase = this.elMain;
        if (!elBase || !elChange || !this.parentElement)
            return;
        if (tp === 'hide') {
            elChange.style.display = 'none';
            return;
        }
        const display = elChange.style.display;
        elChange.style.display = 'none!important';
        const ad3 = (n1, s1, s2) => n1 + parseInt(s1, 10) + parseInt(s2, 10);
        const { marginTop, marginBottom, marginLeft, marginRight, paddingTop, paddingBottom, paddingLeft, paddingRight, fontSize } = window.getComputedStyle(elBase);
        let { width, height } = elBase.getBoundingClientRect();
        const heightori = height;
        let left = 0;
        let top = 0;
        //left -= parseInt(marginLeft, 10);
        //top -= parseInt(marginTop, 10);
        if (top > 0)
            top = 0;
        width = Math.max(ad3(width, marginLeft, marginRight), ad3(0, paddingLeft, paddingRight));
        if (width > elBase.ownerDocument.body.clientWidth)
            width -= 3;
        height = Math.max(ad3(height, marginTop, marginBottom), ad3(0, paddingTop, paddingBottom));
        elChange.style.left = `${(left - 1) < 0 ? 0 : (left - 1)}px`;
        elChange.style.top = `${top - 1}px`;
        elChange.style.width = `${width + 2}px`;
        elChange.style.height = `${height + 2}px`;
        elChange.style.display = display;
        elChange.style.display = this.parentElement.style.display;
        elChange.style.background = '#bdbdbd3d';
        elChange.style.position = 'absolute';
        if (parseInt(paddingTop, 10) !== 0 && ((elBase.style.height && paddingTop) || (paddingTop && paddingBottom))) {
            elChange.style.top = '-' + (parseInt(paddingTop, 10) + parseInt(fontSize, 10)) + 'px';
        }
        else if (paddingTop !== '0px')
            elChange.style.top = '-' + (heightori - 6) + 'px';
        if (paddingLeft !== '0px')
            elChange.style.left = '-' + parseInt(paddingLeft, 10) + 'px';
    }
    _updateBaseNoPadding(elBase, elChange) {
        const st = elChange.style;
        st.position = 'absolute';
        const { borderTopWidth, borderBottomWidth, borderLeftWidth, borderRightWidth, paddingTop, paddingBottom, paddingLeft, paddingRight } = window.getComputedStyle(elBase);
        let { width, height } = elBase.getBoundingClientRect();
        const cd = (v1, v2) => {
            // ex: '1px' + '2px' = '3px'
            let rc = parseInt(v1, 10) + parseInt(v2, 10);
            if (rc < 0)
                rc = 0;
            return rc + 'px';
        };
        const ci = (v1, v2) => {
            // ex: '1px' + '2px' = '3px'
            let rc = parseInt(v1, 10) + parseInt(v2, 10);
            if (rc < 0)
                rc = 0;
            return rc;
        };
        let cWidth = ci(paddingLeft, paddingRight);
        let cHeight = ci(paddingTop, paddingBottom);
        if (cWidth > 0 && cWidth < width)
            width = width - cWidth;
        if (cHeight > 0 && cHeight < height)
            height = height - cHeight;
        st.left = cd(paddingLeft, borderLeftWidth);
        st.bottom = cd(paddingBottom, borderBottomWidth);
        st.top = cd(paddingTop, borderTopWidth);
        st.right = cd(paddingRight, borderRightWidth);
        st.width = width + 'px';
        st.height = height + 'px';
    }
};
//--------------CSS--------------------
WCDToolbox.styles = css `

        :host{
            display:block;
            border:1px solid #d3cece;
            position:absolute;
            user-select:none;
            background: #c8c8c8c2;
        }

        .wcdBackButton{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-2rem;
            right:0px
        }

        .p-l0{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-2rem;
            left:-6px
        }

        .p-l1{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-6px;
            left:-6px
        }

        .p-l2{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            left:-6px;
            transform: translateY(-50%);
        }

        .p-l3{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-6px;
            left:-6px;
        }

        .p-l4{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-2rem;
            left:0px;
        }

        .p-l5{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            left:-23px;
            transform: translateY(-50%);
        }

        .p-r0{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-2rem;
            left: 50%;
            transform: translateX(-50%);
        }

        .p-m1{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-6px;
            left: 50%;
            transform: translateX(-50%);
        }

        .p-m2{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .p-m3{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-6px;
            left: 50%;
            transform: translateX(-50%);
        }

        .p-m4{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-2rem;
            left: 50%;
            transform: translateX(-50%);
        }

        .p-r0{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-2rem;
            right:-6px
        }

        .p-r1{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-6px;
            right:-6px
        }

        .p-r2{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            right:-6px;
            transform: translateY(-50%);
        }

        .p-r3{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-6px;
            right:-6px;
        }

        .p-r4{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-2rem;
            right:-6px;
        }

        .f-button{
            cursor:pointer;
            background:var(--bg-primary-color)!important;
            padding:5px;
            border-radius:5px;
            border: 1px solid var(--grey-color-darker);
            width: 15px;
            height: 15px;
            display: flex;

        }

        .f-circle{
            width:10px;
            height:10px;
            background:#fff;
            border-radius:50%;
            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);
        }
        

        .f-square{
            width:23px;
            height:7px;
            background:#fff;
            border-radius:3px;
            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);
        }

        .p-l1.f-square{
            top:-4px;
            left:-4px
        }

        .p-l2.f-square{
            top:50%;
            left:-4px;
            width:7px;
            height:23px;
        }

        .p-l3.f-square{
            bottom:-4px;
            left:-4px;
        }

        .p-m1.f-square{
            top:-4px;
            width:23px;
            height:7px;
        }

        .p-m2.f-square{
            width:23px;
            height:7px;
        }

        .p-m3.f-square{
            bottom:-4px;
            width:23px;
            height:7px;
        }

        .p-r1.f-square{
            top:-4px;
            right:-4px
        }

        .p-r2.f-square{
            right:-4px;
            width:7px;
            height:23px;
        }

        .p-r3.f-square{
            bottom:-4px;
            right:-4px;
        }


    `;
__decorate([
    property({ type: String, reflect: true })
], WCDToolbox.prototype, "level", void 0);
__decorate([
    property({ type: String, reflect: true })
], WCDToolbox.prototype, "widget", void 0);
WCDToolbox = __decorate([
    customElement('wcd-toolbox-100554')
], WCDToolbox);
export { WCDToolbox };
