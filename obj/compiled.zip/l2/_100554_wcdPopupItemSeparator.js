/// <mls shortName="wcdPopupItemSeparator" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WCDPopupItem } from './_100554_wcdPopupItem';
let WCDPopupItemSeparator = class WCDPopupItemSeparator extends WCDPopupItem {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    render() {
        return html `<div></div>`;
    }
};
WCDPopupItemSeparator.styles = css `
    :host {
      display: inline-block;
      width: 1px;
      height: 22px;
      background-color: rgba(255, 255, 255, 0.3); /* Cor da linha separadora */
      margin: 0 8px; /* Espaçamento à esquerda e à direita da linha */
      vertical-align: middle;
    }
  `;
WCDPopupItemSeparator = __decorate([
    customElement('wcd-popup-item-separator-100554')
], WCDPopupItemSeparator);
export { WCDPopupItemSeparator };
