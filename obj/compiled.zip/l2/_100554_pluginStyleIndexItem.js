/// <mls shortName="pluginStyleIndexItem" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { convertFileNameToTag } from './_100554_utilsLit';
import { collab_heart, collab_heart_o, collab_question, collab_angles_right, collab_chevron_right, collab_info_circle } from './_100554_collabIcons';
let PluginStyleIndexItem = class PluginStyleIndexItem extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-index-item-100554 .plugin-item:not(:last-child){border-bottom:1px solid var(--grey-color-light)}plugin-style-index-item-100554 .plugin-item .plugin-item-header{text-transform:uppercase;font-size:var(--font-size-12);font-weight:var(--font-weight-bold);display:flex;flex-direction:row;justify-content:space-between;gap:.6rem;padding:.3rem;background:var(--grey-color-light)}plugin-style-index-item-100554 .plugin-item .plugin-item-header span{flex:1}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i{user-select:none;cursor:pointer}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i:hover{font-weight:var(--font-weight-bold)}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i:hover svg{transform:scale(1.3)}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i.open svg{animation:rotate .2s linear;animation-iteration-count:1;animation-fill-mode:forwards}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i.i-like{transition:transform .2s ease}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i.i-question.info svg{fill:var(--info-color)}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i.i-like.liked svg{fill:var(--error-color)}plugin-style-index-item-100554 .plugin-item .plugin-item-header .plugin-item-icons i.i-like.likedAnimation svg{animation:heartBeat 1.5s forwards}@keyframes heartBeat{0%{transform:scale(1)}50%{transform:scale(1.4)}100%{transform:scale(1)}}@keyframes rotate{0%{transform:rotate(0deg)}100%{transform:rotate(90deg)}}plugin-style-index-item-100554 .plugin-item .plugin-item-info{padding:var(--space-16)}plugin-style-index-item-100554 .plugin-item .plugin-item-desc{font-size:var(--font-size-12);color:var(--text-primary-color-lighter);padding-left:var(--space-16);text-align:justify}plugin-style-index-item-100554 .plugin-item .plugin-item-container{margin-top:var(--space-8)}plugin-style-index-item-100554 .plugin-item .plugin-item-container.expanded{height:200px;overflow:hidden}`);
        this.help = {
            description: '',
            liked: false,
            likedAnimation: false,
            mode: 'collapsed',
            name: '',
            priority: 0,
            showInfo: false,
            tags: [],
            widget: ''
        };
        this.position = 'left';
    }
    async open() {
        const container = this.querySelector('.plugin-item-container');
        this.openPlugin(container, this.help, false);
    }
    render() {
        return html `
            <div class="plugin-item" .data=${this.help} >
                
                <div class="plugin-item-header">
                    <span>${this.help.name}</span>
                    <div class="plugin-item-icons">
                        <i
                            class="i-expanded ${this.help.mode === 'full' || this.help.mode === 'expanded' ? 'open' : ''}"
                            @click=${(e) => { this.handleExpandedClick(e, this.help); }}
                        >${collab_chevron_right}</i>

                        <i
                            class="i-full ${this.help.mode === 'full' ? 'open' : ''}"
                            @click=${(e) => { this.handleFullClick(e, this.help); }}
                        
                        >${collab_angles_right}</i>
                        <i
                            class="i-question ${this.help.showInfo ? 'info' : ''}"
                            @click=${(e) => { this.handleInfoClick(e, this.help); }}
                        >${collab_question}</i>
                        <i
                            class="i-like ${this.help.liked ? 'liked' : ''} ${this.help.likedAnimation ? 'likedAnimation' : ''}"
                            @click=${(e) => { this.handleLikeClick(e, this.help); }}
                        >${this.help.liked ? collab_heart : collab_heart_o}
                        </i>
                    </div>
                </div>
                
                ${this.help.showInfo ? html `
                    <div class="plugin-item-info">
                        <i>${collab_info_circle}</i>
                        <span>${this.help.widget}</span>
                    </div>
                    <div class="plugin-item-desc">${this.help.description}</div>

                ` : ''}

                <div
                    class="plugin-item-container ${this.help.mode === 'expanded' ? 'expanded' : ''}"
                    style="${this.help.mode !== 'collapsed' ? 'display:block;' : 'display:none;'}"

                >
                </div>            

            </div>`;
    }
    async openPlugin(container, help, close) {
        if (close) {
            container.style.display = 'none';
            return;
        }
        if (container.childElementCount === 0) {
            const tag = convertFileNameToTag(help.widget);
            const item = document.createElement(tag);
            item.setAttribute('state', `{{ less.${this.position} }}`);
            item.setAttribute('showFull', help.mode === 'full' ? 'true' : 'false');
            container.appendChild(item);
        }
        else {
            const item = container.children[0];
            item.setAttribute('showFull', help.mode === 'full' ? 'true' : 'false');
        }
        container.style.display = 'block';
    }
    async handleOpenPlugin(e, help, close = false) {
        e.stopPropagation();
        const target = e.target;
        if (!target)
            return;
        const parent = target.closest('.plugin-item');
        if (!parent)
            return;
        const container = parent.querySelector('.plugin-item-container');
        if (!container)
            return;
        this.openPlugin(container, help, close);
    }
    handleExpandedClick(e, help) {
        if (help.mode === 'expanded' || help.mode === 'full') {
            help.mode = 'collapsed';
            this.requestUpdate();
            this.handleOpenPlugin(e, help, true);
            return;
        }
        help.mode = 'expanded';
        this.requestUpdate();
        this.handleOpenPlugin(e, help);
    }
    handleFullClick(e, help) {
        if (help.mode === 'full') {
            help.mode = 'collapsed';
            this.requestUpdate();
            this.handleOpenPlugin(e, help, true);
            return;
        }
        help.mode = 'full';
        this.requestUpdate();
        this.handleOpenPlugin(e, help);
    }
    async handleLikeClick(e, help) {
        help.liked = !help.liked;
        help.likedAnimation = help.liked;
        this.requestUpdate();
        setTimeout(() => {
            help.likedAnimation = false;
        }, 1000);
    }
    async handleInfoClick(e, help) {
        help.showInfo = !help.showInfo;
        this.requestUpdate();
    }
};
__decorate([
    property()
], PluginStyleIndexItem.prototype, "help", void 0);
__decorate([
    property()
], PluginStyleIndexItem.prototype, "position", void 0);
PluginStyleIndexItem = __decorate([
    customElement('plugin-style-index-item-100554')
], PluginStyleIndexItem);
export { PluginStyleIndexItem };
