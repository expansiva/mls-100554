/// <mls shortName="pluginProjectConfig" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import * as libProjectConfig from './_100554_libProjectConfig';
/// **collab_i18n_start**
const message_pt = {
    clear: 'Limpar alterações',
};
const message_en = {
    clear: 'Clear changes',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Config",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M308.5 135.3c7.1-6.3 9.9-16.2 6.2-25c-2.3-5.3-4.8-10.5-7.6-15.5L304 89.4c-3-5-6.3-9.9-9.8-14.6c-5.7-7.6-15.7-10.1-24.7-7.1l-28.2 9.3c-10.7-8.8-23-16-36.2-20.9L199 27.1c-1.9-9.3-9.1-16.7-18.5-17.8C173.9 8.4 167.2 8 160.4 8l-.7 0c-6.8 0-13.5 .4-20.1 1.2c-9.4 1.1-16.6 8.6-18.5 17.8L115 56.1c-13.3 5-25.5 12.1-36.2 20.9L50.5 67.8c-9-3-19-.5-24.7 7.1c-3.5 4.7-6.8 9.6-9.9 14.6l-3 5.3c-2.8 5-5.3 10.2-7.6 15.6c-3.7 8.7-.9 18.6 6.2 25l22.2 19.8C32.6 161.9 32 168.9 32 176s.6 14.1 1.7 20.9L11.5 216.7c-7.1 6.3-9.9 16.2-6.2 25c2.3 5.3 4.8 10.5 7.6 15.6l3 5.2c3 5.1 6.3 9.9 9.9 14.6c5.7 7.6 15.7 10.1 24.7 7.1l28.2-9.3c10.7 8.8 23 16 36.2 20.9l6.1 29.1c1.9 9.3 9.1 16.7 18.5 17.8c6.7 .8 13.5 1.2 20.4 1.2s13.7-.4 20.4-1.2c9.4-1.1 16.6-8.6 18.5-17.8l6.1-29.1c13.3-5 25.5-12.1 36.2-20.9l28.2 9.3c9 3 19 .5 24.7-7.1c3.5-4.7 6.8-9.5 9.8-14.6l3.1-5.4c2.8-5 5.3-10.2 7.6-15.5c3.7-8.7 .9-18.6-6.2-25l-22.2-19.8c1.1-6.8 1.7-13.8 1.7-20.9s-.6-14.1-1.7-20.9l22.2-19.8zM112 176a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zM504.7 500.5c6.3 7.1 16.2 9.9 25 6.2c5.3-2.3 10.5-4.8 15.5-7.6l5.4-3.1c5-3 9.9-6.3 14.6-9.8c7.6-5.7 10.1-15.7 7.1-24.7l-9.3-28.2c8.8-10.7 16-23 20.9-36.2l29.1-6.1c9.3-1.9 16.7-9.1 17.8-18.5c.8-6.7 1.2-13.5 1.2-20.4s-.4-13.7-1.2-20.4c-1.1-9.4-8.6-16.6-17.8-18.5L583.9 307c-5-13.3-12.1-25.5-20.9-36.2l9.3-28.2c3-9 .5-19-7.1-24.7c-4.7-3.5-9.6-6.8-14.6-9.9l-5.3-3c-5-2.8-10.2-5.3-15.6-7.6c-8.7-3.7-18.6-.9-25 6.2l-19.8 22.2c-6.8-1.1-13.8-1.7-20.9-1.7s-14.1 .6-20.9 1.7l-19.8-22.2c-6.3-7.1-16.2-9.9-25-6.2c-5.3 2.3-10.5 4.8-15.6 7.6l-5.2 3c-5.1 3-9.9 6.3-14.6 9.9c-7.6 5.7-10.1 15.7-7.1 24.7l9.3 28.2c-8.8 10.7-16 23-20.9 36.2L315.1 313c-9.3 1.9-16.7 9.1-17.8 18.5c-.8 6.7-1.2 13.5-1.2 20.4s.4 13.7 1.2 20.4c1.1 9.4 8.6 16.6 17.8 18.5l29.1 6.1c5 13.3 12.1 25.5 20.9 36.2l-9.3 28.2c-3 9-.5 19 7.1 24.7c4.7 3.5 9.5 6.8 14.6 9.8l5.4 3.1c5 2.8 10.2 5.3 15.5 7.6c8.7 3.7 18.6 .9 25-6.2l19.8-22.2c6.8 1.1 13.8 1.7 20.9 1.7s14.1-.6 20.9-1.7l19.8 22.2zM464 304a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"/></svg>
    `;
    }
};
export class PluginProjectConfig extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.msize = '';
        this.template = `window.project_config`;
        this.timeoutChangesEditorStyle = 0;
        this.styles = `
        plugin-project-config-100554 {
            font-family: @font-family-primary;
            display: block;
            height: calc(100% - 55px);
            overflow: auto;
            background: @bg-primary-color;
            font-size: @font-size-16;
        }

        .plugin-body{
            height:100%;
            width: -webkit-fill-available;
            padding:1rem;
            overflow:hidden;
        }
        .plugin-container {
            padding: 10px 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            height:100%;
            width:100%;
        }

        header {
            margin-left: 16px;
        }
        
        header > div{
            display:flex;
            gap:.5rem;
        }
        icon {
            margin-right: 10px;
        }

        h2 {
            font-size: 18px;
            font-weight: bold;
            margin: 0;
            color: #333;
        }
        button{
            background-color: var(--bg-secondary-color-lighter);
            border-radius: 8px;
            border:none;
            box-shadow: 0px 1px 3px 0px var(--grey-color);
            display: flex;
            flex-direction: row;
            justify-content: center;
            gap:.2rem;
            font-weight: 700;
            align-items: center;
            height: 40px;
            transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
            padding: 0.5rem;
            color: @text-primary-color;
            cursor:pointer;
        }
        button:hover{
            background-color: var(--grey-color-light);
        }
    `;
    }
    async prepare() {
        this.createEditor();
        await this.loadProjectConfigs();
        this.setMsizeEditor();
    }
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            this.setMsizeEditor();
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
            <style>${this.styles}</style>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <div>
                    <div>${pluginData.getSvg()}</div>
                    <h2>${pluginData.title}</h2>
                </div>
                <div>
                    <button @click=${this._clearChanges}>${this.msg.clear}</button>
                </div>
            </header>
            
        `;
    }
    renderBody() {
        return html `<div class="plugin-body">
            <mls-editor-100529 ismls2="true"></mls-editor-100529>
        </div>`;
    }
    async setEvents() {
        mls.events.addEventListener([5], ['ProjectSelected'], (ev) => {
            if (!ev.desc)
                return;
            const desc = JSON.parse(ev.desc);
            this.refreshIfNeeded(desc.value);
        });
    }
    _clearChanges() {
        this.loadProjectConfigs(true);
        if (this.lastProject) {
            libProjectConfig.clearLocalChanges(this.lastProject);
            this.refreshIfNeeded(this.lastProject);
        }
    }
    refreshIfNeeded(project) {
        if (this.lastProject !== project) {
            this.loadProjectConfigs();
        }
    }
    setMsizeEditor() {
        this.c2?.setAttribute('msize', this.msize);
    }
    createEditor() {
        if (!this.c2 || this._ed1)
            return;
        const opt = {
            automaticLayout: true,
        };
        this._ed1 = monaco.editor.create(this.c2, opt);
        this.c2['mlsEditor'] = this._ed1;
        this.setMsizeEditor();
    }
    async loadProjectConfigs(ignoreLocal = false) {
        const { project } = mls.actual[5];
        if (!project)
            return;
        this.lastProject = project;
        let config = await libProjectConfig.getConfigProject(project, ignoreLocal);
        if (!config)
            config = await libProjectConfig.createConfigFile(project);
        this.setInitialConfig(JSON.stringify(config, null, 2), project);
    }
    setInitialConfig(value, project) {
        const newValue = this.template + ' = ' + value;
        this.model = this.createOrGetModel('typescript', newValue, project);
        if (!this.model || !this._ed1)
            return;
        this._ed1.setModel(this.model);
    }
    createOrGetModel(editorType, src, project) {
        const uri = this.getUri(`${this.constructor.name}_${project}}`);
        let model1 = monaco.editor.getModel(uri);
        if (!model1) {
            model1 = monaco.editor.createModel(src, editorType, uri);
            this.setEventsModel(model1);
        }
        else {
            model1.setValue(src);
        }
        return model1;
    }
    setEventsModel(model) {
        model.onDidChangeContent((event) => {
            if (this.timeoutChangesEditorStyle)
                clearTimeout(this.timeoutChangesEditorStyle);
            this.timeoutChangesEditorStyle = setTimeout(() => {
                this.onEditorChange();
            }, 1000);
        });
    }
    async onEditorChange() {
        if (!this.model)
            return;
        const val = this.model.getValue();
        const errors = monaco.editor.getModelMarkers(({ resource: this.model.uri }));
        if (errors && errors.length > 0)
            return;
        const that = this;
        (async function scope() {
            eval(val); // eslint-disable-line no-eval
            if (window.project_config && typeof window.project_config === 'object' && that.lastProject) {
                libProjectConfig.updateConfigProject(that.lastProject, window.project_config);
            }
        }).call(this);
    }
    getUri(shortFN) {
        PluginProjectConfig.modelCount = PluginProjectConfig.modelCount + 1 || 1;
        return monaco.Uri.parse(`file://server/${shortFN}_${PluginProjectConfig.modelCount}.ts`);
    }
}
__decorate([
    property({ type: Boolean })
], PluginProjectConfig.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: String })
], PluginProjectConfig.prototype, "msize", void 0);
__decorate([
    query('mls-editor-100529')
], PluginProjectConfig.prototype, "c2", void 0);
__decorate([
    query('.plugin-body')
], PluginProjectConfig.prototype, "body", void 0);
if (!customElements.get('plugin-project-config-100554')) {
    customElements.define('plugin-project-config-100554', PluginProjectConfig);
}
