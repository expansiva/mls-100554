/// <mls shortName="bteste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let MeuTeste = class MeuTeste extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.name = new Date(Date.now()).toString();
    }
    createRenderRoot() {
        return this;
    }
    handleConfirm(e) {
        console.info(e.detail, 'no handleConfirm');
    }
    render() {
        return html `<div class="cls1"><h1>Hello world lucas 3</h1></div>`;
    }
};
__decorate([
    property()
], MeuTeste.prototype, "name", void 0);
MeuTeste = __decorate([
    customElement('bteste-100554')
], MeuTeste);
export { MeuTeste };
