/// <mls shortName="bteste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let MeuTeste = class MeuTeste extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`bteste-100554{font-family:var(--font-family-primary)}bteste-100554 header{margin-bottom:50px}bteste-100554 header h1{background:#385170;padding:2rem;color:var(--warning-color);font-weight:var(--font-weight-light)}bteste-100554 header p{border-top:initial none #403F3F;border-left:8px ridge #8E44AD;border-bottom:initial none #403F3F;border-right:8px groove #16a085;padding:2rem;margin-bottom:4em}bteste-100554 main{display:flex;justify-content:center;flex-direction:row;flex-wrap:wrap;row-gap:1em;gap:1em;margin-bottom:4em}bteste-100554 main section{border:1px solid;min-width:12em;max-width:250px;padding-left:1em;padding-right:1em;padding-bottom:1em}bteste-100554 main section h2{text-align:center;text-transform:uppercase;font-size:98%;padding:.6em;background:radial-gradient(circle, #3f5efb 0%, #fc466b 100%);color:white}bteste-100554 main section p{text-align:justify;line-height:1.3}bteste-100554 div{border-left:1px solid #D33636;border-bottom:none #403F3F;border-right:1px solid #7A962C;border-top:2px solid #5f52a3;position:relative;border-top-right-radius:113px;border-top-left-radius:112px;border-bottom-right-radius:113px;border-bottom-left-radius:113px;padding-left:2em;padding-right:2em;padding-bottom:2em}bteste-100554 div button#btn1{border:1px solid #000000;box-shadow:5px 5px 0px 0px;padding:1em;border-radius:.5em;transition:all .1s ease-out}bteste-100554 div button#btn1:active{box-shadow:3px 3px 0px 0px;transform:translate(2px, 2px)}bteste-100554 div h1{flex:1;text-shadow:0 0 5px #f00;color:var(--text-secondary-color);text-align:center;border:5px dashed #32557F;width:80%;margin-left:auto;margin-right:auto;background:linear-gradient(135deg, #4c4c4c 0%, #595959 12%, #666 25%, #474747 39%, #2c2c2c 50%, #000 51%, #111 60%, #2b2b2b 76%, #1c1c1c 91%, #131313 100%);box-shadow:5px 5px 20px 0px inset}bteste-100554 div p{background-color:burlywood;text-align:justify;padding:1em;column-gap:1.5em;column-count:2;column-rule-color:#403f3f;column-rule-style:double;column-rule-width:.2em;line-height:1.3}`);
        this.name = new Date(Date.now()).toString();
    }
    createRenderRoot() {
        return this;
    }
    handleConfirm(e) {
        console.info(e.detail, 'no handleConfirm');
    }
    texto() {
        return `
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus varius nec neque eu dictum. Nulla at tincidunt purus. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce aliquam eros vitae condimentum posuere. Mauris at fermentum nisl. Integer consectetur placerat ligula, a pretium mauris accumsan eu. Fusce justo est, semper vel iaculis ac, lobortis nec ante. Nullam posuere ac magna non ultrices. Sed tempus ex at blandit rutrum. Pellentesque sit amet facilisis nulla. Maecenas eget nisi sed ligula dictum porta non sed nisi. Cras semper felis ac erat finibus hendrerit.

        Pellentesque orci nisi, viverra eget massa vel, cursus sodales lacus. Suspendisse sagittis est at vehicula mollis. Duis malesuada placerat nulla a placerat. Sed pharetra, libero vitae facilisis porta, neque justo fermentum nulla, tincidunt scelerisque massa quam ac ligula. Vivamus facilisis est arcu, quis feugiat arcu eleifend eu. Donec a hendrerit tellus, a lobortis libero. Mauris sit amet arcu sit amet sapien imperdiet imperdiet nec id ipsum.

        Duis pulvinar, nunc sed tincidunt sodales, lectus mi lobortis justo, sed tempor arcu odio in magna. Etiam quis odio ullamcorper mi ullamcorper finibus ac nec magna. Integer lectus dolor, dignissim vel pellentesque id, porttitor sit amet libero. Vestibulum metus ante, dapibus sed posuere varius, ornare quis sapien. Duis imperdiet fringilla ex sed efficitur. Mauris posuere lectus leo, et congue sem euismod at. Duis tincidunt turpis neque. Nam volutpat velit malesuada mauris sollicitudin, et congue dolor gravida. Nulla porta ut libero a accumsan. Aenean at cursus ex. Nulla pulvinar enim aliquam, varius nisl at, pellentesque justo.
        `;
    }
    render() {
        return html `
        <div class="cls1">
            <h1>Página do Lucas</h1>
            <button id="btn1">clique aqui</button>
            <p id="pg1">${this.texto()}</p>
        </div>`;
    }
};
__decorate([
    property()
], MeuTeste.prototype, "name", void 0);
MeuTeste = __decorate([
    customElement('bteste-100554')
], MeuTeste);
export { MeuTeste };
