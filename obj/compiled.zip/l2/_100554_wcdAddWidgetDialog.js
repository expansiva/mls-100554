/// <mls shortName="wcdAddWidgetDialog" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat, unsafeHTML } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { globalWcd } from './_100554_wcdState';
/// **collab_i18n_start**
const message_pt = {
    add: 'Adicionar',
    placeholder: 'digite palavras chaves para buscar o widget, e pressione Enter',
};
const message_en = {
    add: 'Add',
    placeholder: 'type keywords to search widget, and press Enter'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdAddWidgetDialog100554 = class WcdAddWidgetDialog100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wcd-add-widget-dialog-100554{display:block;width:100%;padding:1rem}wcd-add-widget-dialog-100554 .prompt-content{padding:10px;display:flex;margin-bottom:1rem}wcd-add-widget-dialog-100554 .prompt-content input{border:none;border-bottom:1px solid var(--grey-color);outline:none;width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}wcd-add-widget-dialog-100554 gallery{display:grid;grid-template-columns:repeat(auto-fill, minmax(100px, 1fr));grid-auto-rows:100px;gap:10px;padding:10px;max-height:315px;overflow:auto}wcd-add-widget-dialog-100554 gallery gallery-item{box-shadow:0 4px 8px rgba(0,0,0,0.1);transition:transform .3s ease,filter .3s ease;cursor:pointer;border-radius:8px;position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.5rem}wcd-add-widget-dialog-100554 gallery gallery-item p{position:absolute;bottom:5px;left:5px;font-size:var(--font-size-12);color:#ffffff;display:none}wcd-add-widget-dialog-100554 gallery svg{width:25px;height:25px;display:block;border-radius:8px}wcd-add-widget-dialog-100554 gallery gallery-item:hover{transform:scale(1.05)}wcd-add-widget-dialog-100554 gallery gallery-item:hover p{display:block}wcd-add-widget-dialog-100554 gallery gallery-item svg:hover{filter:brightness(.4)}@media (max-width:768px){wcd-add-widget-dialog-100554 gallery{grid-template-columns:repeat(auto-fill, minmax(100px, 1fr))}}`);
        this.msg = messages['en'];
        this.allWidgets = [];
        this.error = '';
        this.listWidgets = [];
    }
    //-------COMPONENT----------
    disconnectedCallback() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (globalWcd.elICA)
            globalWcd.elICA.style.height = this.lastHeight || '';
        else if (this.lastIca)
            this.lastIca.style.height = this.lastHeight || '';
        super.disconnectedCallback();
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.prompt)
            this.prompt.focus();
        this.getWidgets();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('listWidgets')) {
            this.recalculeIcaHeight();
        }
    }
    render() {
        this.lastIca = globalWcd.elICA;
        if (!this.lastHeight)
            this.lastHeight = globalWcd.elICA?.style.height;
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error)
            return this.renderError();
        return this.renderWidgets();
    }
    renderHeader() {
        return html `
        <div class="prompt-content">
            <input type="text" id="prompt-input" @keydown=${this.handleKeyDown.bind(this)}  placeholder=${this.msg.placeholder}/>
        </div>
        `;
    }
    renderError() {
        return html `
            ${this.renderHeader()}
            <h3>${this.error}</h3>
        
        `;
    }
    renderWidgets() {
        return html `
            ${this.renderHeader()}
            <gallery>
                ${repeat(this.listWidgets, ((key) => key.nome), ((k, index) => { return this.renderItemGallery(k, index); }))}
            </gallery>
        
        `;
    }
    renderItemGallery(item, idx) {
        return html `
            <gallery-item @click="${this.add}" .info=${item}>
                ${unsafeHTML(item.svg)}
                ${item.nome}
            </gallery-item>
        `;
    }
    //------IMPLEMENTS----------
    async handleKeyDown(event) {
        event.stopPropagation();
        if (event.key === 'Enter') {
            this.filter(this.prompt?.value);
        }
    }
    filter(filter = '') {
        const f = this.allWidgets.filter((f) => f.nome.toLowerCase().indexOf(filter) >= 0);
        this.listWidgets = f;
    }
    add(e) {
        let el = e.target;
        if (el.tagName !== 'gallery-item') {
            el = el.closest('gallery-item');
        }
        if (!el || !el.info)
            return;
        const info = el.info;
        console.info('add: ' + info.nome);
    }
    recalculeIcaHeight() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        const height = this.getBoundingClientRect()?.height;
        if (this.lastHeight === undefined)
            this.lastHeight = globalWcd.elICA.style.height;
        globalWcd.elICA.style.height = height + 'px';
    }
    getWidgets() {
        const x = [
            {
                nome: 'Input',
                cat: 'Form',
                svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M288 32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 242.7-73.4-73.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l128 128c12.5 12.5 32.8 12.5 45.3 0l128-128c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L288 274.7 288 32zM64 352c-35.3 0-64 28.7-64 64l0 32c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-32c0-35.3-28.7-64-64-64l-101.5 0-45.3 45.3c-25 25-65.5 25-90.5 0L165.5 352 64 352zm368 56a24 24 0 1 1 0 48 24 24 0 1 1 0-48z"/></svg>`,
                exDefault: '<input-100554 type="text">Input</input-100554>'
            },
            {
                nome: 'Text',
                cat: 'Apresentation',
                svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M32 32C14.3 32 0 46.3 0 64S14.3 96 32 96l128 0 0 352c0 17.7 14.3 32 32 32s32-14.3 32-32l0-352 128 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L192 32 32 32z"/></svg>`,
                exDefault: '<text-100554>Text</text-100554>'
            },
            {
                nome: 'Button',
                cat: 'Action',
                svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M0 192l176 0L176 0 160 0C71.6 0 0 71.6 0 160l0 32zm0 32L0 352c0 88.4 71.6 160 160 160l64 0c88.4 0 160-71.6 160-160l0-128-192 0L0 224zm384-32l0-32C384 71.6 312.4 0 224 0L208 0l0 192 176 0z"/></svg>`,
                exDefault: '<button-100554>button</button-100554>'
            }
        ];
        this.allWidgets = [...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x];
        this.listWidgets = [...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x, ...x];
    }
};
__decorate([
    query('#prompt-input')
], WcdAddWidgetDialog100554.prototype, "prompt", void 0);
__decorate([
    property()
], WcdAddWidgetDialog100554.prototype, "error", void 0);
__decorate([
    property()
], WcdAddWidgetDialog100554.prototype, "listWidgets", void 0);
WcdAddWidgetDialog100554 = __decorate([
    customElement('wcd-add-widget-dialog-100554')
], WcdAddWidgetDialog100554);
export { WcdAddWidgetDialog100554 };
