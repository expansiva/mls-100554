/// <mls shortName="wcdAddWidgetDialog" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat, unsafeHTML } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { globalWcd } from './_100554_wcdState';
import { executeFromTag, getOverlay } from './_100554_wcdCommandAdd';
import { convertFileNameToTag } from './_100554_utilsLit';
import { getDescriptionsRootGroup, getDescriptionsFinalGroup, getDescriptionsSubGroup, } from './_100554_icaBaseDescription';
/// **collab_i18n_start**
const message_pt = {
    add: 'Adicionar',
    placeholder: 'digite palavras chaves para buscar o widget, e pressione Enter',
    suggestion: 'Sugestões'
};
const message_en = {
    add: 'Add',
    placeholder: 'type keywords to search widget, and press Enter',
    suggestion: 'Suggestion'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcdAddWidgetDialog100554 = class WcdAddWidgetDialog100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wcd-add-widget-dialog-100554{display:block;width:100%;padding:1rem;max-height:400px;overflow:auto;background:var(--bg-primary-color)}wcd-add-widget-dialog-100554::-webkit-scrollbar{width:5px}wcd-add-widget-dialog-100554::-webkit-scrollbar-thumb{background-color:#888;border-radius:6px}wcd-add-widget-dialog-100554::-webkit-scrollbar-track{background-color:#f1f1f1}wcd-add-widget-dialog-100554 .prompt-content{padding:10px;display:flex}wcd-add-widget-dialog-100554 .prompt-content input{border:none;border-bottom:1px solid var(--grey-color);outline:none;width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out}wcd-add-widget-dialog-100554 gallery{display:grid;grid-template-columns:repeat(auto-fill, minmax(100px, 1fr));grid-auto-rows:100px;gap:10px;padding:10px}wcd-add-widget-dialog-100554 gallery gallery-item{box-shadow:0 4px 8px rgba(0,0,0,0.1);transition:transform .3s ease,filter .3s ease;cursor:pointer;border-radius:8px;position:relative;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.5rem}wcd-add-widget-dialog-100554 gallery gallery-item p{position:absolute;bottom:5px;left:5px;font-size:var(--font-size-12);color:#ffffff;display:none}wcd-add-widget-dialog-100554 gallery svg{width:25px;height:25px;display:block;border-radius:8px}wcd-add-widget-dialog-100554 gallery gallery-item:hover{transform:scale(1.05)}wcd-add-widget-dialog-100554 gallery gallery-item:hover p{display:block}wcd-add-widget-dialog-100554 gallery gallery-item svg:hover{filter:brightness(.4)}@media (max-width:768px){wcd-add-widget-dialog-100554 gallery{grid-template-columns:repeat(auto-fill, minmax(100px, 1fr))}}wcd-add-widget-dialog-100554 .group-container{border-top:1px solid #c4c3c3;display:flex;gap:1em;padding:.5em;flex-wrap:wrap;margin-top:1rem}wcd-add-widget-dialog-100554 .group-container .group-item{cursor:pointer;min-width:120px;box-shadow:0 4px 8px rgba(0,0,0,0.1);display:flex;justify-content:center;align-items:center;flex-direction:column;border-radius:8px;padding:.5rem}wcd-add-widget-dialog-100554 .group-container .group-item:hover{transform:scale(1.05)}wcd-add-widget-dialog-100554 .breadcrumb{margin:0 1em 1em;padding:.3rem;opacity:.7;border:1px solid #c4c3c3;display:flex;align-items:center;border-radius:3px}wcd-add-widget-dialog-100554 .breadcrumb a{text-decoration:none}wcd-add-widget-dialog-100554 .breadcrumb a:visited{color:#1890FF;text-decoration:inherit}`);
        this.msg = messages['en'];
        this.allWidgets = [];
        this.error = '';
        this.listWidgets = [];
        this.rootBread = 'root';
        this.actualBreadCrumb = [];
        this.actualMode = 'root';
    }
    //-------COMPONENT----------
    disconnectedCallback() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (globalWcd.elICA)
            globalWcd.elICA.style.height = this.lastHeight || '';
        else if (this.lastIca)
            this.lastIca.style.height = this.lastHeight || '';
        super.disconnectedCallback();
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.prompt)
            this.prompt.focus();
        this.getWidgets();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('listWidgets')) {
            this.recalculeIcaHeight();
        }
    }
    render() {
        this.lastIca = globalWcd.elICA;
        if (!this.lastHeight)
            this.lastHeight = globalWcd.elICA?.style.height;
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error)
            return this.renderError();
        return this.renderWidgets();
    }
    renderHeader() {
        return html `
        <div class="prompt-content">
            <input type="text" id="prompt-input" @keydown=${this.handleKeyDown.bind(this)}  placeholder=${this.msg.placeholder}/>
        </div>
        `;
    }
    renderError() {
        return html `
            ${this.renderHeader()}
            <h3>${this.error}</h3>
        
        `;
    }
    renderWidgets() {
        return html `
            ${this.renderHeader()}
            ${this.renderBreadCrumb()}
            <gallery>
                ${repeat(this.listWidgets, ((key) => key.nome), ((k, index) => { return this.renderItemGallery(k, index); }))}
            </gallery>
            ${this.renderGroups()}
        
        `;
    }
    renderItemGallery(item, idx) {
        return html `
            <gallery-item @click="${this.add}" .info=${item}>
                ${unsafeHTML(item.svg)}
                ${item.nome}
            </gallery-item>
        `;
    }
    renderGroups() {
        switch (this.actualMode) {
            case 'root':
                return this.renderGroupsRoot();
            case 'subgroup':
                return this.renderSubGroups();
            case 'finalgroup':
                return this.renderFinalGruops();
            default:
                return html ``;
        }
    }
    renderGroupsRoot() {
        const groups = getDescriptionsRootGroup();
        return html `
        <div class="group-container">

            ${repeat(groups, ((key) => 'gp_' + key), ((k, index) => {
            return html `
                    <div class="group-item" @click=${() => { this.onClickRootGroup(k); }}>
                        <span class="group-title">${k}</span>
                    </div>`;
        }))}
                
        </div>
        `;
    }
    renderSubGroups() {
        const [, rootSelected] = this.actualBreadCrumb;
        const groups = getDescriptionsSubGroup(rootSelected);
        return html `
        <div class="group-container">
            ${groups.map((subGroup) => {
            return html `
            <div class="group-item" @click=${() => { this.onClickSubGroup(rootSelected, subGroup); }}>
                <span class="group-title">${subGroup}</span>
                
            </div>
        `;
        })}
        </div>
        `;
    }
    renderFinalGruops() {
        const [, rootSelected, subGroupSelected] = this.actualBreadCrumb;
        const groups = getDescriptionsFinalGroup(rootSelected, subGroupSelected);
        return html `
        <div class="group-container">
            ${groups.map((finalGroup) => {
            return html `
                <div class="group-item" @click=${() => { this.onClickFinalGroup(rootSelected, subGroupSelected, finalGroup); }}>
                    <span class="group-title">${finalGroup}</span>
                    
                </div>
            `;
        })}
        </div>
        `;
    }
    renderBreadCrumb() {
        if (this.actualBreadCrumb.length === 0)
            return html ``;
        return html `
            <div class="breadcrumb">
                ${this.actualBreadCrumb.map((breadItem, index) => {
            const isLast = index === this.actualBreadCrumb.length - 1;
            return html `
            ${isLast
                ? html `
                    <span @click=${(e) => this.onBreadClick(breadItem, e)}>
                        ${breadItem}${!isLast ? ' > ' : ''}
                    </span>`
                : html `
                    <a href="#" @click=${(e) => this.onBreadClick(breadItem, e)}>
                        ${breadItem}${!isLast ? ' > ' : ''}
                    </a>`}
            `;
        })}
            </div>
        `;
    }
    //------IMPLEMENTS----------
    onBreadClick(breadItem, e) {
        e.preventDefault();
        const index = this.actualBreadCrumb.findIndex((item) => item === breadItem);
        if (index < 0)
            throw new Error('Invalid breadcrumb item');
        this.actualBreadCrumb = this.actualBreadCrumb.slice(0, index + 1);
        if (index === 0) {
            this.actualMode = 'root';
            this.listWidgets = this.allWidgets.filter((i) => i.priority === 0);
            if (this.listWidgets.length === 0) {
                this.listWidgets = this.allWidgets.filter((i) => i.priority === 1);
            }
        }
        if (index === 1)
            this.actualMode = 'subgroup';
        if (index === 2)
            this.actualMode = 'finalgroup';
        this.requestUpdate();
    }
    onClickRootGroup(rootGroup) {
        this.actualBreadCrumb = [this.rootBread, rootGroup];
        this.actualMode = 'subgroup';
        this.listWidgets = this.allWidgets.filter((i) => i.cat.indexOf(this.actualBreadCrumb.join('').replace('root', '')) >= 0);
        this.requestUpdate();
    }
    onClickSubGroup(rootGroup, subGroup) {
        this.actualBreadCrumb = [this.rootBread, rootGroup, subGroup];
        this.actualMode = 'finalgroup';
        this.listWidgets = this.allWidgets.filter((i) => i.cat.indexOf(this.actualBreadCrumb.join('').replace('root', '')) >= 0);
        this.requestUpdate();
    }
    onClickFinalGroup(rootGroup, subGroup, finalGroup) {
        this.actualBreadCrumb = [this.rootBread, rootGroup, subGroup, finalGroup];
        this.actualMode = 'empty';
        this.listWidgets = this.allWidgets.filter((i) => i.cat.indexOf(this.actualBreadCrumb.join('').replace('root', '')) >= 0);
        this.requestUpdate();
    }
    async handleKeyDown(event) {
        event.stopPropagation();
        if (event.key === 'Enter') {
            this.filter(this.prompt?.value);
        }
    }
    filter(filter = '') {
        const f = this.allWidgets.filter((f) => f.nome.toLowerCase().indexOf(filter) >= 0);
        this.listWidgets = f;
    }
    async add(e) {
        let el = e.target;
        if (el.tagName !== 'gallery-item') {
            el = el.closest('gallery-item');
        }
        if (!el || !el.info)
            return;
        const info = el.info;
        if (!info)
            return;
        await executeFromTag(info.tagBase, info.tagMain);
    }
    recalculeIcaHeight() {
        if (!globalWcd)
            throw new Error('Invalid window.wcdState');
        if (!globalWcd.elICA)
            throw new Error('Invalid window.wcdState.elICA');
        const height = this.getBoundingClientRect()?.height;
        if (this.lastHeight === undefined)
            this.lastHeight = globalWcd.elICA.style.height;
        globalWcd.elICA.style.height = height + 'px';
    }
    async getWidgets() {
        const elOverlay = getOverlay();
        if (!elOverlay)
            return;
        if (!mls.actual[5].project)
            return;
        await mls.plugin.loadAll(mls.actual[5].project, false);
        const listIndex = mls.plugin.getAllMenuActions(mls.actual[5].project, { scope: 'l3AddWidget' });
        const list = elOverlay.listWidgetsBase;
        this.allWidgets = await this.configList(listIndex, list);
        if (list.length > 0) {
            this.listWidgets = this.allWidgets.filter((i) => i.priority === 0);
        }
        else {
            this.listWidgets = this.allWidgets.filter((i) => i.priority <= 1);
        }
    }
    async configList(allWidgets, list) {
        const ret = [];
        for await (const item of allWidgets) {
            const i = await this.configListItem(item);
            if (i)
                ret.push(i);
        }
        for (const item of list) {
            ret.forEach((i) => {
                if (i.widget === item.name) {
                    i.priority = 0;
                }
            });
        }
        return ret;
    }
    async configListItem(item) {
        try {
            mls.actual[0].setFullName(item.widget);
            const moduleClass = await import('/' + item.widget);
            const [cls] = Object.keys(moduleClass);
            const extendName = Object.getPrototypeOf((moduleClass)[cls]).name;
            if (!extendName)
                return;
            const tag = convertFileNameToTag('_100554_' + extendName);
            const tagW = convertFileNameToTag(item.widget);
            const i = {
                nome: mls.actual[0].path,
                cat: extendName,
                svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M290.8 48.6l78.4 29.7L288 109.5 206.8 78.3l78.4-29.7c1.8-.7 3.8-.7 5.7 0zM136 92.5l0 112.2c-1.3 .4-2.6 .8-3.9 1.3l-96 36.4C14.4 250.6 0 271.5 0 294.7L0 413.9c0 22.2 13.1 42.3 33.5 51.3l96 42.2c14.4 6.3 30.7 6.3 45.1 0L288 457.5l113.5 49.9c14.4 6.3 30.7 6.3 45.1 0l96-42.2c20.3-8.9 33.5-29.1 33.5-51.3l0-119.1c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-1.3-.5-2.6-.9-3.9-1.3l0-112.2c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-12.8-4.8-26.9-4.8-39.7 0l-96 36.4C150.4 48.4 136 69.3 136 92.5zM392 210.6l-82.4 31.2 0-89.2L392 121l0 89.6zM154.8 250.9l78.4 29.7L152 311.7 70.8 280.6l78.4-29.7c1.8-.7 3.8-.7 5.7 0zm18.8 204.4l0-100.5L256 323.2l0 95.9-82.4 36.2zM421.2 250.9c1.8-.7 3.8-.7 5.7 0l78.4 29.7L424 311.7l-81.2-31.1 78.4-29.7zM523.2 421.2l-77.6 34.1 0-100.5L528 323.2l0 90.7c0 3.2-1.9 6-4.8 7.3z"/></svg>`,
                tagBase: tag,
                tagMain: tagW,
                priority: item.priority,
                widget: item.widget
            };
            return i;
        }
        catch (e) {
            console.info(e);
            return;
        }
    }
    extractAttr(file, src) {
        const firstLine = src.split('\n')[0].trim();
        const rgx = /^\/\/\/\s*<mls\s([^>]+)\/>/;
        const match = firstLine.match(rgx);
        if (!match) {
            throw new Error('File dont have <mls>: ' + file);
        }
        const attrs = {};
        const rgxAttr = /(\w+)="([^"]+)"/g;
        let attMatch;
        while ((attMatch = rgxAttr.exec(match[1])) !== null) {
            const key = attMatch[1];
            const value = attMatch[2];
            attrs[key] = value;
        }
        return attrs;
    }
};
__decorate([
    query('#prompt-input')
], WcdAddWidgetDialog100554.prototype, "prompt", void 0);
__decorate([
    property()
], WcdAddWidgetDialog100554.prototype, "error", void 0);
__decorate([
    property()
], WcdAddWidgetDialog100554.prototype, "listWidgets", void 0);
__decorate([
    property({ type: Array })
], WcdAddWidgetDialog100554.prototype, "actualBreadCrumb", void 0);
__decorate([
    property({ type: String })
], WcdAddWidgetDialog100554.prototype, "actualMode", void 0);
WcdAddWidgetDialog100554 = __decorate([
    customElement('wcd-add-widget-dialog-100554')
], WcdAddWidgetDialog100554);
export { WcdAddWidgetDialog100554 };
