/// <mls shortName="libCompile" project="100554" enhancement="_blank" />
// typescript new file
import { getDSInstance } from './_100554_libDesignSystem';
// import { compileStyleUsingStorFile } from './_100554_enhancementStyle';
export const getDependenciesByHtml = (mfile, html, theme, withCss = false) => {
    return new Promise(async (resolve, reject) => {
        try {
            const ret = await getDependencies(mfile, 'byHtml', html, theme, withCss);
            resolve(ret);
        }
        catch (e) {
            reject(e);
        }
    });
};
export const getDependenciesByMFile = (mfile, withCss = false) => {
    return new Promise(async (resolve, reject) => {
        try {
            if (mfile.storFile.extension !== '.ts')
                throw new Error('Only myfile .ts');
            const tag = convertFileNameToTag(`_${mfile.storFile.project}_${mfile.storFile.shortName}`);
            resolve(await getDependencies(mfile, tag, `<${tag}></${tag}>`, 'Default', withCss));
        }
        catch (e) {
            reject(e);
        }
    });
};
async function getTagsInTypescript(mfile, tags) {
    const tagsInTypescript = getAllWebComponentsInSource(mfile.model.getValue());
    for (const tagTs of tagsInTypescript) {
        if (!tags.includes(tagTs)) {
            const fileName = convertTagToFileName(tagTs);
            const mfile = mls.l2.editor.mfiles[fileName];
            if (mfile) {
                await getTagsInTypescript(mfile, tags);
                tags.push(tagTs);
            }
        }
    }
    return tags;
}
async function getDependencies(mfile, filename, html, theme, withCss = false) {
    const myImportsMap = [];
    const myImports = [];
    const myCss = [];
    let myTokens = [];
    const myErrors = [];
    const myModules = {};
    let tags = extrairTagsCustomizadas(html);
    const tag = convertFileNameToTag(`_${mfile.storFile.project}_${mfile.storFile.shortName}`);
    if (!tags.includes(tag))
        tags.push(tag);
    tags = await getTagsInTypescript(mfile, tags);
    // const globalCss = await getGlobalCss(mfile, theme);
    await loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, withCss, theme);
    return {
        file: filename,
        wcComponents: tags,
        importsMap: myImportsMap,
        importsJs: myImports,
        css: myCss,
        globalCss: '',
        tokens: myTokens,
        errors: myErrors
    };
}
function extrairTagsCustomizadas(html) {
    const regex = /<\/?([a-z][a-z0-9-]*)\b[^>]*>/gi;
    const customTags = [];
    let match;
    while ((match = regex.exec(html)) !== null) {
        const tag = match[1];
        if (tag.indexOf('-') >= 0
            && !customTags.includes(tag)
            && !['mls-showexamplecode-100529', 'mls-usecaseadd-100529', 'mls-head'].includes(tag.replace('<', '').replace('>', ''))) {
            customTags.push(tag.replace('<', '').replace('>', ''));
        }
    }
    return customTags;
}
async function loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, compileCss, theme) {
    try {
        if (tags.length <= 0)
            return;
        const name = convertTagToFileName(tags[0]);
        mls.actual[0].setFullName(name);
        const { project, path } = mls.actual[0];
        if (!project || !path)
            return;
        const ipath = { project, shortName: path };
        const enhacementName = await mls.l2.enhancement.getEnhancementVariable(ipath);
        if (!enhacementName)
            throw new Error('enhacementName not valid');
        if (!myModules[enhacementName]) {
            const mModule = await mls.l2.enhancement.getEnhancementInstance(ipath);
            myModules[enhacementName] = {
                jsMap: false,
                mModule
            };
        }
        //tags = await addRequeries(enhacementName, ipath, tags, myModules);
        await getJSImporMap(myImportsMap, enhacementName, ipath, myModules);
        await getJS(myImports, enhacementName, ipath, myModules);
        if (compileCss) {
            // await getCss(myCss, name, ipath, theme);
            await getCssL2(myCss, ipath, theme);
        }
        await getTokens(myTokens, ipath, theme);
    }
    catch (e) {
        if (tags.length <= 0)
            return;
        myErrors.push({ tag: tags[0], error: e.message });
    }
    finally {
        tags.shift();
        if (tags.length > 0) {
            await loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, compileCss, theme);
        }
    }
}
async function getJSImporMap(myImportsMap, enhacementName, mfile, myModules) {
    if (!myModules[enhacementName]) {
        throw new Error('Enhacement not found ');
    }
    if (myModules[enhacementName].jsMap)
        return;
    myModules[enhacementName].jsMap = true;
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'cdn')
            return;
        myImportsMap.push(`"${i.name}": "${i.ref}"`);
    });
}
async function getJS(myImports, enhacementName, mfile, myModules) {
    if (!myModules[enhacementName]) {
        throw new Error('Enhacement not found ');
    }
    if (myImports.includes(`/_${mfile.project}_${mfile.shortName}`))
        return;
    myImports.push(`/_${mfile.project}_${mfile.shortName}`);
}
async function getCss(myCss, fullName, mfile, theme) {
    try {
        const dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
        const ds = await getDSInstance(mfile.project, dsindex);
        if (!ds || !ds.components)
            return;
        const css = await ds.components.getCSS(fullName, theme);
        myCss.push(css);
    }
    catch (e) {
        if (e.message.indexOf('dont exists') < 0)
            throw new Error(e.message);
    }
}
async function getCssL2(resCss, ipath, theme) {
    // const mfile = mls.l2.editor.get(ipath);
    // if (!mfile) return;
    // const modelHTML = (mfile as any).modelHTML;
    // if (!modelHTML) return;
    // const html = modelHTML.getValue() || '';
    // const components = getAllWebComponentsInSource(html);
    // for await (let component of components) {
    //     const fileName = convertTagToFileName(component);
    //     mls.actual[0].setFullName(fileName);
    //     const shortName = mls.actual[0].path;
    //     const project = mls.actual[0].project;
    //     if (!shortName || !project) continue;
    //     const styleC = await compileStyleUsingStorFile(shortName, project, theme);
    //     if (styleC) resCss.push(styleC);
    // }
}
async function getGlobalCss(mfile, theme) {
    try {
        const dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
        const ds = await getDSInstance(mfile.project, dsindex);
        if (!ds || !ds.css || !ds.components)
            return;
        // const css = await ds.css.getStylesInLess(theme);
        const css2 = await ds.getDesignSystemCss(theme);
        return css2;
    }
    catch (e) {
        if (e.message.indexOf('dont exists') < 0)
            throw new Error(e.message);
    }
}
async function getTokens(myTokens, mfile, theme) {
    try {
        const dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
        const ds = await getDSInstance(mfile.project, dsindex);
        if (!ds || !ds.tokens)
            return;
        const tokens = await ds.tokens.getTokensCss(theme);
        myTokens.push(tokens);
    }
    catch (e) {
        if (e.message.indexOf('dont exists') < 0)
            throw new Error(e.message);
    }
}
export function getAllWebComponentsInSource(source) {
    const regex = /<([a-z0-9]+-[a-z0-9-]*)(?=\s|>|\/|$)/g;
    const matches = source.match(regex) || [];
    const componentNames = matches.map(tag => tag.slice(1));
    return [...new Set(componentNames)];
}
function convertFileNameToTag(widget) {
    const regex = /_([0-9]+)_?(.*)/;
    const match = widget.match(regex);
    if (match) {
        const [, number, rest] = match;
        const convertedSrc = rest.replace(/([A-Z])/g, '-$1').toLowerCase();
        widget = `${convertedSrc}-${number}`;
    }
    return widget;
}
function convertTagToFileName(tag) {
    const regex = /(.+)-(\d+)/;
    const match = tag.match(regex);
    if (match) {
        const [, rest, number] = match;
        const convertedSrc = rest.replace(/-(.)/g, (_, letter) => letter.toUpperCase());
        tag = `_${number}_${convertedSrc}`;
    }
    return tag;
}
