/// <mls shortName="libCompile" project="100554" enhancement="_blank" />
// typescript new file
import { getDSInstance } from './_100554_libDesignSystem';
export const getDependenciesByHtml = (mfile, html, theme, withCss = false) => {
    return new Promise(async (resolve, reject) => {
        try {
            resolve(await getDependencies(mfile, 'byHtml', html, theme, withCss));
        }
        catch (e) {
            reject(e);
        }
    });
};
export const getDependenciesByMFile = (mfile, withCss = false) => {
    return new Promise(async (resolve, reject) => {
        try {
            if (mfile.storFile.extension !== '.ts')
                throw new Error('Only myfile .ts');
            const tag = convertFileNameToTag(`_${mfile.storFile.project}_${mfile.storFile.shortName}`);
            resolve(await getDependencies(mfile, tag, `<${tag}></${tag}>`, 'Default', withCss));
        }
        catch (e) {
            reject(e);
        }
    });
};
async function getTagsInTypescript(mfile, tags) {
    const tagsInTypescript = getAllWebComponentsInSource(mfile.model.getValue());
    for (const tagTs of tagsInTypescript) {
        if (!tags.includes(tagTs)) {
            const fileName = convertTagToFileName(tagTs);
            const mfile = mls.l2.editor.mfiles[fileName];
            if (mfile) {
                await getTagsInTypescript(mfile, tags);
                tags.push(tagTs);
            }
        }
    }
    return tags;
}
async function getDependencies(mfile, filename, html, theme, withCss = false) {
    const myImportsMap = [];
    const myImports = [];
    const myCss = [];
    let myTokens = [];
    const myErrors = [];
    const myModules = {};
    let tags = extrairTagsCustomizadas(html);
    const tag = convertFileNameToTag(`_${mfile.storFile.project}_${mfile.storFile.shortName}`);
    if (!tags.includes(tag))
        tags.push(tag);
    tags = await getTagsInTypescript(mfile, tags);
    const globalCss = await getGlobalCss(mfile, theme);
    await loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, withCss, theme);
    return {
        file: filename,
        wcComponents: tags,
        importsMap: myImportsMap,
        importsJs: myImports,
        css: myCss,
        globalCss,
        tokens: myTokens,
        errors: myErrors
    };
}
function extrairTagsCustomizadas(html) {
    const regex = /<\/?([a-z][a-z0-9-]*)\b[^>]*>/gi;
    const customTags = [];
    let match;
    while ((match = regex.exec(html)) !== null) {
        const tag = match[1];
        if (tag.indexOf('-') >= 0
            && !customTags.includes(tag)
            && !['mls-showexamplecode-100529', 'mls-usecaseadd-100529', 'mls-head'].includes(tag.replace('<', '').replace('>', ''))) {
            customTags.push(tag.replace('<', '').replace('>', ''));
        }
    }
    return customTags;
}
async function loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, compileCss, theme) {
    try {
        if (tags.length <= 0)
            return;
        const name = convertTagToFileName(tags[0]);
        mls.actual[0].setFullName(name);
        const { project, path } = mls.actual[0];
        if (!project || !path)
            return;
        const mfile = mls.l2.editor.get({ project, shortName: path });
        if (!mfile)
            throw new Error('not found');
        if (!mfile.compilerResults || !mfile.compilerResults.prodJS || !mfile.compilerResults.tripleSlashMLS) {
            if (mfile.compilerResults)
                mfile.compilerResults.modelNeedCompile = true;
            await mls.l2.editor.getCompilerResultTS(mfile, true);
        }
        const enhacementName = mfile.compilerResults.tripleSlashMLS.variables.enhancement;
        if (!enhacementName)
            throw new Error('enhacementName not valid');
        if (!myModules[enhacementName]) {
            const mModule = await mls.l2.enhancement.getEnhancementInstance(mfile);
            myModules[enhacementName] = {
                jsMap: false,
                mModule
            };
        }
        tags = await addRequeries(enhacementName, mfile, tags, myModules);
        await getJSImporMap(myImportsMap, enhacementName, mfile, myModules);
        await getJS(myImports, enhacementName, mfile, myModules);
        if (compileCss) {
            await getCss(myCss, name, mfile, theme);
        }
        await getTokens(myTokens, mfile, theme);
    }
    catch (e) {
        if (tags.length <= 0)
            return;
        myErrors.push({ tag: tags[0], error: e.message });
    }
    finally {
        tags.shift();
        if (tags.length > 0) {
            await loadMyNeedsToCompile(tags, myImportsMap, myImports, myCss, myTokens, myErrors, myModules, compileCss, theme);
        }
    }
}
async function addRequeries(enhacementName, mfile, array, myModules) {
    if (!myModules[enhacementName]) {
        throw new Error('Enhacement not found ');
    }
    if (!myModules[enhacementName].mModule || !myModules[enhacementName].mModule.getDesignDetails)
        return array;
    const obj = await myModules[enhacementName].mModule.getDesignDetails(mfile);
    if (!obj || !obj.webComponentDependencies)
        return array;
    for (let i of obj.webComponentDependencies) {
        const tag = convertFileNameToTag(i);
        if (!array.includes(tag)) {
            array.push(tag);
        }
    }
    return array;
}
async function getJSImporMap(myImportsMap, enhacementName, mfile, myModules) {
    if (!myModules[enhacementName]) {
        throw new Error('Enhacement not found ');
    }
    if (myModules[enhacementName].jsMap)
        return;
    myModules[enhacementName].jsMap = true;
    const mmodule = myModules[enhacementName].mModule;
    if (!mmodule || !mmodule.requires)
        return;
    const aRequire = mmodule.requires;
    aRequire.forEach((i) => {
        if (i.type !== 'cdn')
            return;
        myImportsMap.push(`"${i.name}": "${i.ref}"`);
    });
}
async function getJS(myImports, enhacementName, mfile, myModules) {
    if (!myModules[enhacementName]) {
        throw new Error('Enhacement not found ');
    }
    if (mfile.compilerResults && mfile.compilerResults.imports && mfile.compilerResults.imports.length > 0) {
        mfile.compilerResults.imports.forEach((n) => {
            const name = n.replace('./', '/');
            if (!myImports.includes(name) && n.startsWith('./')) {
                myImports.push(name);
            }
            //myImports = verifyMyImportsNeedImport(myImports, name);
        });
    }
    if (myImports.includes(`/_${mfile.project}_${mfile.shortName}`))
        return;
    myImports.push(`/_${mfile.project}_${mfile.shortName}`);
}
function verifyMyImportsNeedImport(myImports, name) {
    name = name.replace('.', '').replace('/', '');
    const { project, path } = mls.actual[0].setFullName(name);
    const key = mls.l2.editor.getKey({ project: project, shortName: path });
    const mfile = mls.l2.editor.mfiles[key];
    if (!mfile)
        return myImports;
    if (mfile.compilerResults && mfile.compilerResults.imports && mfile.compilerResults.imports.length > 0) {
        mfile.compilerResults.imports.forEach((n) => {
            const name = n.replace('./', '/');
            if (!myImports.includes(name) && n.startsWith('./')) {
                myImports.push(name);
            }
        });
    }
    return myImports;
}
;
async function getCss(myCss, fullName, mfile, theme) {
    try {
        const dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
        const ds = await getDSInstance(mfile.project, dsindex);
        if (!ds || !ds.components)
            return;
        const css = await ds.components.getCSS(fullName, theme);
        myCss.push(css);
    }
    catch (e) {
        if (e.message.indexOf('dont exists') < 0)
            throw new Error(e.message);
    }
}
async function getGlobalCss(mfile, theme) {
    try {
        const dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
        const ds = await getDSInstance(mfile.project, dsindex);
        if (!ds || !ds.css)
            return;
        const css = await ds.css.getStylesInLess(theme);
        return css;
    }
    catch (e) {
        if (e.message.indexOf('dont exists') < 0)
            throw new Error(e.message);
    }
}
async function getTokens(myTokens, mfile, theme) {
    try {
        const dsindex = mls.actual[3].mode ? mls.actual[3].mode : 0;
        const ds = await getDSInstance(mfile.project, dsindex);
        if (!ds || !ds.tokens)
            return;
        const tokens = await ds.tokens.getTokensCss(theme);
        myTokens.push(tokens);
    }
    catch (e) {
        if (e.message.indexOf('dont exists') < 0)
            throw new Error(e.message);
    }
}
function getAllWebComponentsInSource(source) {
    const regex = /<([a-z0-9]+-[a-z0-9-]*)(?=\s|>|\/|$)/g;
    const matches = source.match(regex) || [];
    const componentNames = matches.map(tag => tag.slice(1));
    return [...new Set(componentNames)];
}
function convertFileNameToTag(widget) {
    const regex = /_([0-9]+)_?(.*)/;
    const match = widget.match(regex);
    if (match) {
        const [, number, rest] = match;
        const convertedSrc = rest.replace(/([A-Z])/g, '-$1').toLowerCase();
        widget = `${convertedSrc}-${number}`;
    }
    return widget;
}
function convertTagToFileName(tag) {
    const regex = /(.+)-(\d+)/;
    const match = tag.match(regex);
    if (match) {
        const [, rest, number] = match;
        const convertedSrc = rest.replace(/-(.)/g, (_, letter) => letter.toUpperCase());
        tag = `_${number}_${convertedSrc}`;
    }
    return tag;
}
