/// <mls shortName="pluginStyleFilter" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { propertyDataSource } from './_100554_collabDecorators';
import { globalState } from './_100554_collabState';
import { getMessageKey } from './_100554_collabLitElement';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
import './_100554_collabDsInputSelectColor';
import './_100554_collabDsInputRange';
/// **collab_i18n_start**
const message_pt = {
    grayscale: 'Escala de Cinza',
    filterBlur: 'Desfoque',
    sepia: 'Sépia',
    saturate: 'Saturação',
    opacity: 'Opacidade',
    brightness: 'Brilho',
    contrast: 'Contraste',
    hueRotate: 'Rotação de Matiz',
    invert: 'Inverter',
    advanced: 'Avançado',
    description: 'Um plugin versátil para gerenciar e aplicar propriedades de filtro CSS. Controle facilmente filtros como desfoque, brilho, contraste e outros para criar elementos de UI visualmente envolventes e dinâmicos com precisão.'
};
const message_en = {
    grayscale: 'Grayscale',
    filterBlur: 'Blur',
    sepia: 'Sepia',
    saturate: 'Saturate',
    opacity: 'Opacity',
    brightness: 'Brightness',
    contrast: 'Contrast',
    hueRotate: 'HueRotate',
    invert: 'Invert',
    advanced: 'Advanced',
    description: 'A versatile plugin for managing and applying CSS filter properties. Easily control filters like blur, brightness, contrast, and more to create visually engaging and dynamic UI elements with precision.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['filter'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleFilter = class PluginStyleFilter extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-filter-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);padding-top:var(--space-8)}plugin-style-filter-100554 details summary{cursor:pointer}plugin-style-filter-100554 details>div{margin-left:var(--space-16)}plugin-style-filter-100554 .group{margin-top:var(--space-8);display:flex;flex-direction:column;font-size:var(--font-size-12)}plugin-style-filter-100554 .group .group-edit{display:flex;align-items:center;gap:.5rem}plugin-style-filter-100554 .group .group-edit i{display:flex;flex-shrink:0}plugin-style-filter-100554 .gallery{margin-bottom:var(--space-16);display:flex;justify-content:start;align-items:center;gap:3rem;padding:1rem;flex-wrap:wrap;cursor:pointer}`);
        this.showFull = 'true';
        this.position = 'left';
        this.msg = messages['en'];
        this.timeonChangeProp = -1;
        this.gallery = [
            {
                style: 'filter: brightness(40%) sepia(1) hue-rotate(-42deg) saturate(6);',
                state: {
                    filter: 'brightness(40%) sepia(1) hue-rotate(-42deg) saturate(6)'
                }
            },
            {
                style: 'filter: brightness(20%) sepia(1) hue-rotate(180deg) saturate(5);',
                state: {
                    filter: 'brightness(20%) sepia(1) hue-rotate(180deg) saturate(5)'
                }
            },
            {
                style: 'filter: brightness(20%) sepia(1) hue-rotate(310deg) saturate(5);',
                state: {
                    filter: 'brightness(20%) sepia(1) hue-rotate(310deg) saturate(5)'
                }
            },
            {
                style: 'filter: brightness(70%) sepia(1) hue-rotate(360deg) saturate(6);',
                state: {
                    filter: 'brightness(70%) sepia(1) hue-rotate(360deg) saturate(6)'
                }
            },
            {
                style: 'filter: brightness(40%) sepia(1) hue-rotate(-40deg);',
                state: {
                    filter: 'brightness(40%) sepia(1) hue-rotate(-40deg);'
                }
            },
            {
                style: 'filter: blur(2px);',
                state: {
                    filter: 'blur(2px)'
                }
            },
            {
                style: 'filter: invert(100%) sepia(2);',
                state: {
                    filter: 'invert(100%) sepia(2)'
                }
            },
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!_value.selector || !_value.lessCSS || !_value.lessCSS.lessAST || !_value.lessCSS.lessAST.ast[_value.selector])
            return;
        const actualAst = _value.lessCSS.lessAST.ast[_value.selector];
        if (!actualAst)
            return;
        let hasRuleFilterInAST = false;
        Object.keys(actualAst).forEach((prop) => {
            if (prop === 'filter')
                hasRuleFilterInAST = true;
        });
        this.clear();
        if (hasRuleFilterInAST) {
            this._onIcaStateChange();
        }
    }
    clear() {
        this.filter = undefined;
        this.grayscale = undefined;
        this.filterBlur = undefined;
        this.sepia = undefined;
        this.saturate = undefined;
        this.opacity = undefined;
        this.brightness = undefined;
        this.contrast = undefined;
        this.huerotate = undefined;
        this.invert = undefined;
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    setValues(rule) {
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (propertyName === 'filter') {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                }
            }
        }
        this.setValues2();
    }
    setValues2() {
        const auxFilter = {
            grayscale: '',
            blur: '',
            sepia: '',
            saturate: '',
            opacity: '',
            brightness: '',
            contrast: '',
            huerotate: '',
            invert: '',
        };
        const filter = (this.filter || '').split(' ');
        filter.forEach((item) => {
            let prop = item.substring(0, item.indexOf('(')).replace('-', '');
            item = item.substring(item.indexOf('('), item.length);
            const value = item.match(/[\.-\d]/g)?.join('');
            auxFilter[prop] = value;
        });
        this.grayscale = auxFilter.grayscale;
        this.filterBlur = auxFilter.blur;
        this.sepia = auxFilter.sepia;
        this.saturate = auxFilter.saturate;
        this.opacity = auxFilter.opacity;
        this.brightness = auxFilter.brightness;
        this.contrast = auxFilter.contrast;
        this.huerotate = auxFilter.huerotate;
        this.invert = auxFilter.invert;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.showFull === 'true' ?
            html `
                    ${this.renderGallery()}
                    ${this.renderFilter()}

                ` :
            html `
                    ${this.renderGallery()}
                `}
        `;
    }
    renderFilter() {
        return html `
            <div class="group">
                <span>${this.msg.grayscale}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="grayscale" value=${this.grayscale} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.filterBlur}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="filterBlur" value=${this.filterBlur} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.sepia}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="sepia" value=${this.sepia} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.saturate}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="saturate" value=${this.saturate} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.opacity}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="opacity" value=${this.opacity} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.brightness}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="brightness" value=${this.brightness} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.contrast}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="contrast" value=${this.contrast} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.hueRotate}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="huerotate" value=${this.huerotate} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.invert}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="invert" value=${this.invert} useSelect="false"></collab-ds-input-range-100554>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `<img height="70px" width="70px" src="./l3/_100529_/images/startl7.avif" style="${galleryItem.style}" @click=${() => { this.onGalleryClick(galleryItem); }}></img>`;
        }))}
            </div>
        
        `;
    }
    mountValue() {
        let value = '';
        value += this.grayscale ? 'grayscale(' + this.grayscale + '%) ' : '';
        value += this.filterBlur ? 'blur(' + this.filterBlur + 'px) ' : '';
        value += this.sepia ? 'sepia(' + this.sepia + ') ' : '';
        value += this.saturate ? 'saturate(' + this.saturate + ') ' : '';
        value += this.opacity ? 'opacity(' + this.opacity + ') ' : '';
        value += this.brightness ? 'brightness(' + this.brightness + '%) ' : '';
        value += this.contrast ? 'contrast(' + this.contrast + '%) ' : '';
        value += this.huerotate ? 'hue-rotate(' + this.huerotate + 'deg) ' : '';
        value += this.invert ? 'invert(' + this.invert + '%) ' : '';
        this.filter = value.trim();
        this.setState();
    }
    setState() {
        globalState._ica.less[this.position].emitter = 'helper';
        const styles = globalState._ica.less[this.position].lessCSS.styles;
        styles.filter = this.filter || '';
    }
    handleChange(e) {
        clearTimeout(this.timeonChangeProp);
        const el = e.detail ? e.detail.target : e.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        this.timeonChangeProp = setTimeout(() => {
            this[prop] = el.value;
            this.mountValue();
        }, 100);
    }
    async onGalleryClick(item) {
        this.filter = item.state.filter;
        this.setValues2();
        await this.updateComplete;
        this.setState();
    }
};
__decorate([
    property()
], PluginStyleFilter.prototype, "showFull", void 0);
__decorate([
    propertyDataSource()
], PluginStyleFilter.prototype, "state", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "position", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "filter", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "grayscale", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "filterBlur", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "sepia", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "saturate", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "opacity", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "brightness", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "contrast", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "huerotate", void 0);
__decorate([
    property()
], PluginStyleFilter.prototype, "invert", void 0);
PluginStyleFilter = __decorate([
    customElement('plugin-style-filter-100554')
], PluginStyleFilter);
export { PluginStyleFilter };
