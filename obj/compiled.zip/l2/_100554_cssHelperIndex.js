/// <mls shortName="cssHelperIndex" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, when, repeat } from 'lit';
import { customElement, property, queryAll } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { propertyDataSource } from './_100554_icaLitElement';
import { convertFileNameToTag } from './_100554_utilsLit';
/// **collab_i18n_start**
const message_pt = {
    'msg': 'Selecione uma linha no editor'
};
const message_en = {
    'msg': 'Select a line in the editor'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CssHelperIndex = class CssHelperIndex extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`css-helper-index-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}css-helper-index-100554>div{padding:.5rem}css-helper-index-100554 details{cursor:pointer}css-helper-index-100554 details:not(:first-child){margin-top:1rem}css-helper-index-100554 details>summary{text-transform:uppercase;font-size:var(--font-size-12);font-weight:var(--font-weight-bold)}css-helper-index-100554 details>div{padding-left:1.5rem}`);
        this.msg = messages['en'];
        this.helpers = [];
        this.avaliablePlugins = [];
        this.actualProp = '';
        this.actualValue = '';
        this.actualSelector = '';
    }
    handleIcaStateChange(key, value) {
        if (key !== 'style' || !value || value.position !== this.position)
            return;
        const { lineKey, lineValue, selector, lineNumber } = value;
        this.actualProp = lineKey;
        this.actualValue = lineValue;
        this.actualSelector = selector;
        if (lineNumber && lineKey) {
            this.actualProp = lineKey;
            this.actualValue = lineValue;
            this.openAllDetails(false);
        }
        else {
            this.actualProp = '';
            this.actualValue = '';
        }
    }
    async updated(changedProperties) {
        if (changedProperties.has('actualProp') || changedProperties.has('actualValue')) {
            this.helpers = this.filterByProp(this.avaliablePlugins, this.actualProp, this.actualValue);
            await this.updateComplete;
            this.openAllDetails();
        }
    }
    async firstUpdated(a) {
        super.firstUpdated(a);
        const avaliablePlugins = await this.getAvaliablesPlugins();
        this.avaliablePlugins = avaliablePlugins;
        const helpers = this.filterByProp(this.avaliablePlugins, this.actualProp, this.actualValue);
        this.helpers = helpers;
        await this.updateComplete;
        this.openAllDetails();
    }
    async getAvaliablesPlugins() {
        const { project } = mls.actual[5];
        if (!project)
            return [];
        await mls.plugin.loadAll(project, true);
        const allPlugins = mls.plugin.getAllMenuActions(project, { scope: 'l2StyleHelper' });
        const helpers = [];
        for await (let plugin of allPlugins) {
            const instance = await import(`./${plugin.widget}`);
            if (!instance || !instance.tags || !Array.isArray(instance.tags))
                continue;
            const obj = {
                name: plugin.category || 'none',
                widget: plugin.widget,
                tags: instance.tags
            };
            helpers.push(obj);
        }
        return helpers;
    }
    filterByProp(helpers, actualProp, actualValue) {
        return helpers.filter(helper => {
            return helper.tags.some(helperTag => {
                const [tagProperty, tagValue] = helperTag.split(':');
                const validateTagOrProp = (tagCompare, value) => {
                    // Se o valor for vazio, não atende à condição
                    if (!value) {
                        return false;
                    }
                    // Excluir os que começam com prefixo negado (!)
                    if (tagCompare.startsWith('!')) {
                        const prefix = tagCompare.substring(1);
                        if (tagCompare.endsWith('*')) {
                            const trimmedPrefix = prefix.slice(0, -1); // Remove o '*'
                            return !value.startsWith(trimmedPrefix);
                        }
                        // Caso contrário, exclui somente a correspondência exata
                        return value !== prefix;
                    }
                    // Incluir os que começam com o prefixo curinga (*)
                    if (tagCompare.endsWith('*')) {
                        const prefix = tagCompare.slice(0, -1); // Remove o '*'
                        return value.startsWith(prefix);
                    }
                    // Caso não tenha *, verifica se é uma correspondência exata
                    return tagCompare === value;
                };
                // Verifica tanto a actualProp quanto o actualValue
                const propMatches = validateTagOrProp(tagProperty, actualProp);
                const valueMatches = tagValue ? validateTagOrProp(tagValue, actualValue) : true; // Se não houver tagValue, não valida
                return propMatches && valueMatches;
            });
        });
    }
    async handleOpen(e) {
        const target = e.target;
        if (!target)
            return;
        const details = target.closest('details');
        if (!details)
            return;
        this.openDetails(details);
    }
    openAllDetails(open = true) {
        this.allDetails.forEach((det) => this.openDetails(det, open));
    }
    async openDetails(details, open) {
        const container = details.querySelector(':scope>div');
        if (details.open === true && open !== false)
            return;
        if (!container)
            return;
        if (container.childElementCount === 0) {
            const tag = convertFileNameToTag(details.id);
            const item = document.createElement(tag);
            item.setAttribute('state', '{{ style }}');
            container.appendChild(item);
        }
        if (open) {
            details.open = true;
            details.scrollIntoView({ behavior: 'smooth' });
        }
    }
    render() {
        return html `
            <div> ${this.actualSelector} </div>
            ${when(this.helpers.length === 0, () => html `<div>${this.msg.msg}</div>`, () => html `
                <div>
                ${repeat(this.helpers, ((item) => item.widget), ((item, index) => this.renderHelper(item, index)))}
                </div>`)}`;
    }
    renderHelper(help, index) {
        return html `
            <details @click=${this.handleOpen} id=${help.widget}>
                <summary>${help.name} </summary>
                <div></div>
            </details>`;
    }
};
__decorate([
    property()
], CssHelperIndex.prototype, "helpers", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "avaliablePlugins", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "position", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualProp", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualValue", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualSelector", void 0);
__decorate([
    propertyDataSource()
], CssHelperIndex.prototype, "state", void 0);
__decorate([
    queryAll('details')
], CssHelperIndex.prototype, "allDetails", void 0);
CssHelperIndex = __decorate([
    customElement('css-helper-index-100554')
], CssHelperIndex);
export { CssHelperIndex };
