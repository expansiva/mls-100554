/// <mls shortName="cssHelperIndex" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, when, repeat } from 'lit';
import { customElement, property, queryAll } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { propertyDataSource } from './_100554_icaLitElement';
/// **collab_i18n_start**
const message_pt = {
    'msg': 'Nenhum helper disponivel',
    'selector': 'Seletor',
};
const message_en = {
    'msg': 'No helper available.',
    'selector': 'Selector',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CssHelperIndex = class CssHelperIndex extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`css-helper-index-100554{font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}css-helper-index-100554 .helpers{padding:var(--space-8);margin-bottom:2rem;display:flex;flex-direction:column;gap:2rem;z-index:9}css-helper-index-100554 .helpers .plugin-item:not(:last-child){border-bottom:1px solid var(--grey-color-light)}css-helper-index-100554 .helpers .plugin-item .plugin-item-header{text-transform:uppercase;font-size:var(--font-size-12);font-weight:var(--font-weight-bold);display:flex;flex-direction:row;justify-content:space-between;gap:.6rem;padding:.3rem;background:var(--grey-color-light)}css-helper-index-100554 .helpers .plugin-item .plugin-item-header span{flex:1}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i{user-select:none;cursor:pointer}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i:hover{font-weight:var(--font-weight-bold)}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i:hover svg{transform:scale(1.3)}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i.open svg{animation:rotate .2s linear;animation-iteration-count:1;animation-fill-mode:forwards}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i.i-like{transition:transform .2s ease}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i.i-question.info svg{fill:var(--info-color)}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i.i-like.liked svg{fill:var(--error-color)}css-helper-index-100554 .helpers .plugin-item .plugin-item-header .plugin-item-icons i.i-like.likedAnimation svg{animation:heartBeat 1.5s forwards}@keyframes heartBeat{0%{transform:scale(1)}50%{transform:scale(1.4)}100%{transform:scale(1)}}@keyframes rotate{0%{transform:rotate(0deg)}100%{transform:rotate(90deg)}}css-helper-index-100554 .helpers .plugin-item .plugin-item-info{padding:var(--space-16)}css-helper-index-100554 .helpers .plugin-item .plugin-item-desc{font-size:var(--font-size-12);color:var(--text-primary-color-lighter);padding-left:var(--space-16);text-align:justify}css-helper-index-100554 .helpers .plugin-item .plugin-item-container{margin-top:var(--space-8)}css-helper-index-100554 .helpers .plugin-item .plugin-item-container.expanded{height:200px;overflow:hidden}`);
        this.msg = messages['en'];
        this.helpers = [];
        this.avaliablePlugins = [];
        this.position = 'left';
        this.actualProp = '';
        this.actualValue = '';
        this.actualSelector = '';
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        const { key, value, selector, lineNumber } = _value;
        this.actualProp = key;
        this.actualValue = value;
        this.actualSelector = selector;
        this.actualLineNumber = lineNumber;
        if (lineNumber && key) {
            this.actualProp = key;
            this.actualValue = value;
            this.openIfNeeded();
        }
        else {
            this.actualProp = '';
            this.actualValue = '';
        }
    }
    async updated(changedProperties) {
        if (changedProperties.has('actualProp') || changedProperties.has('actualValue') || changedProperties.has('actualLineNumber')) {
            this.helpers = this.filterByProp(this.avaliablePlugins, this.actualProp, this.actualValue).sort((a, b) => a.priority - b.priority);
            await this.updateComplete;
            this.openIfNeeded();
        }
    }
    async firstUpdated(a) {
        super.firstUpdated(a);
        const avaliablePlugins = await this.getAvaliablesPlugins();
        this.avaliablePlugins = avaliablePlugins;
        const helpers = this.filterByProp(this.avaliablePlugins, this.actualProp, this.actualValue);
        this.helpers = helpers;
        // this.helpers = avaliablePlugins;
        await this.updateComplete;
    }
    async getAvaliablesPlugins() {
        const { project } = mls.actual[5];
        if (!project)
            return [];
        await mls.plugin.loadAll(project, true);
        const allPlugins = mls.plugin.getAllMenuActions(project, { scope: 'l2StyleHelper' });
        const helpers = [];
        for await (let plugin of allPlugins) {
            const instance = await import(`./${plugin.widget}`);
            let description = '';
            if (!instance || !instance.tags || !Array.isArray(instance.tags))
                continue;
            if (instance.getDescription && typeof instance.getDescription === 'function') {
                const descriptionRc = instance.getDescription();
                if (descriptionRc && typeof descriptionRc === 'string')
                    description = descriptionRc;
            }
            const obj = {
                name: plugin.category || 'none',
                widget: plugin.widget,
                tags: instance.tags,
                priority: plugin.priority || 1,
                description,
                mode: 'collapsed',
                liked: false,
                likedAnimation: false,
                showInfo: false
            };
            helpers.push(obj);
        }
        return helpers;
    }
    filterByProp(helpers, actualProp, actualValue) {
        if (!window.globalState?.less
            || !window.globalState.less[this.position]
            || !window.globalState.less[this.position].selector
            || !window.globalState.less[this.position].lineNumber)
            return [];
        const rc = helpers.filter(helper => {
            return helper.tags.some(helperTag => {
                const [tagProperty, tagValue] = helperTag.split(':');
                const validateTagOrProp = (tagCompare, value, returnAllIfEmpty = false) => {
                    if (!value && returnAllIfEmpty)
                        return true;
                    if (!value)
                        return false;
                    if (tagCompare.startsWith('!')) {
                        const prefix = tagCompare.substring(1);
                        if (tagCompare.endsWith('*')) {
                            const trimmedPrefix = prefix.slice(0, -1);
                            return !value.startsWith(trimmedPrefix);
                        }
                        return value !== prefix;
                    }
                    if (tagCompare.endsWith('*')) {
                        const prefix = tagCompare.slice(0, -1);
                        return value.startsWith(prefix);
                    }
                    return tagCompare === value;
                };
                const propMatches = validateTagOrProp(tagProperty, actualProp || '', true);
                const valueMatches = tagValue ? validateTagOrProp(tagValue, actualValue || '') : true;
                return propMatches && valueMatches;
            });
        });
        const mode = rc.length < 3 ? 'full' : (rc.length < 7 ? 'expanded' : 'collapsed');
        rc.forEach((help) => help.mode = mode);
        return rc;
    }
    render() {
        return html `
            <div> ${this.msg.selector}: <b>${this.actualSelector} </b> </div>
            ${when(this.helpers.length === 0, () => html `<div>${this.msg.msg}</div>`, () => html `
                <div class="helpers">
                    ${repeat(this.helpers, ((item) => item.widget), ((item, index) => this.renderHelper(item, index)))}
                </div>`)}`;
    }
    renderHelper(help, index) {
        return html `<plugin-style-index-item-100554 position="${this.position}" .help=${help}></plugin-style-index-item-100554>`;
    }
    openIfNeeded() {
        this.allPluginsEls.forEach((pluginEl) => {
            pluginEl.requestUpdate();
            if (pluginEl.help.mode === "expanded" || pluginEl.help.mode === "full") {
                pluginEl.open();
            }
        });
    }
};
__decorate([
    property()
], CssHelperIndex.prototype, "helpers", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "avaliablePlugins", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "position", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualProp", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualValue", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualSelector", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "actualLineNumber", void 0);
__decorate([
    propertyDataSource()
], CssHelperIndex.prototype, "state", void 0);
__decorate([
    queryAll('plugin-style-index-item-100554')
], CssHelperIndex.prototype, "allPluginsEls", void 0);
CssHelperIndex = __decorate([
    customElement('css-helper-index-100554')
], CssHelperIndex);
export { CssHelperIndex };
