/// <mls shortName="wcVideo" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaApresentationVideoEmbeddedVideoBase } from './_100554_icaApresentationVideoEmbeddedVideoBase';
let WcVideo100554 = class WcVideo100554 extends IcaApresentationVideoEmbeddedVideoBase {
    constructor() {
        super(...arguments);
        this.loadStyle(`wc-video-100554{display:block}wc-video-100554 video{width:100%;height:auto;border:1px solid}`);
        this.src = '';
        this.autoplay = false;
        this.controls = true;
        this.loop = false;
        this.muted = false;
        this.preload = 'auto';
    }
    render() {
        return html `
            <video
                .src=${this.src}
                ?autoplay=${this.autoplay}
                ?controls=${this.controls}
                ?loop=${this.loop}
                ?muted=${this.muted}
                .preload=${this.preload}
            ></video>
        `;
    }
};
__decorate([
    property({ type: String })
], WcVideo100554.prototype, "src", void 0);
__decorate([
    property({ type: Boolean })
], WcVideo100554.prototype, "autoplay", void 0);
__decorate([
    property({ type: Boolean })
], WcVideo100554.prototype, "controls", void 0);
__decorate([
    property({ type: Boolean })
], WcVideo100554.prototype, "loop", void 0);
__decorate([
    property({ type: Boolean })
], WcVideo100554.prototype, "muted", void 0);
__decorate([
    property({ type: String })
], WcVideo100554.prototype, "preload", void 0);
__decorate([
    query('video')
], WcVideo100554.prototype, "video", void 0);
WcVideo100554 = __decorate([
    customElement('wc-video-100554')
], WcVideo100554);
export { WcVideo100554 };
