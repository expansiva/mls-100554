/// <mls shortName="collabImport" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
const moduleRegistry = new Map();
const staticImports = new Set(); // Tracks modules imported outside dev mode
export async function collabImport(opts) {
    const moduleId = `${opts.project}-${opts.folder}/${opts.shortName}`;
    const isDev = await fileInDevelopment(opts);
    if (!isDev) {
        const url = getUrlFromFileInfo(opts, null);
        staticImports.add(moduleId);
        return import(/* @vite-ignore */ url);
    }
    const version = await getFileVersion(opts);
    const cached = moduleRegistry.get(moduleId);
    if (cached && cached.version === version) {
        return cached.modulePromise;
    }
    const url = getUrlFromFileInfo(opts, version);
    const modulePromise = import(/* @vite-ignore */ url);
    moduleRegistry.set(moduleId, { version, modulePromise });
    return modulePromise;
}
async function fileInDevelopment(opts) {
    const keyToStorFile = mls.stor.getKeyToFiles(opts.project, 2, opts.shortName, opts.folder, '.ts');
    const storFile = mls.stor.files[keyToStorFile];
    return !!storFile?.inLocalStorage;
}
async function getFileVersion(opts) {
    const modelKey = mls.editor.getKeyModel(opts.project, opts.shortName);
    const model = mls.editor.models[modelKey];
    if (!model || !model.ts)
        return '';
    const crcActual = mls.common.crc.crc32(model.ts.model.getValue()).toString(16);
    return crcActual === model.ts.originalCRC ? '' : crcActual;
}
function getUrlFromFileInfo(opts, version) {
    const base = `/_${opts.project}_${opts.shortName}`;
    return version ? `${base}?t=${version}` : base;
}
