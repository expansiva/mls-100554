/// <mls shortName="serviceDsDocView" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initEditorQuillDocs } from './_100554_editorQuillDocs';
import { collab_plus, collab_trash } from './_100554_collabIcons';
/// **collab_i18n_start**
const message_pt = {
    noDocumentationSelected: 'Nenhum documento selecionado',
    addChild: 'Adicionar filho',
    removeThis: 'Remover este',
};
const message_en = {
    noDocumentationSelected: 'No documentation selected',
    addChild: 'Add child',
    removeThis: 'Remove this',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsDocView100554 = class ServiceDsDocView100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.details = {
            icon: '&#xf06e',
            state: 'foreground',
            tooltip: 'Documentation View',
            visible: false,
            position: "right",
            tags: ['ds_docs'],
            widget: '_100554_serviceDsDocView',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (op === 'opView')
                return true;
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'View',
            actions: {},
            icons: {},
            actionDefault: 'opView', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        initEditorQuillDocs();
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible && reinit) {
        }
    }
    setEvents() {
        mls.events.addEventListener([3], ['DSDocPageClicked'], (ev) => {
            this.onDSDocPageClicked(ev);
        });
        mls.events.addEventListener([3], ['DSDocSelected'], (ev) => {
            this.showNav2Item(true);
            this.openMe();
        });
        mls.events.addEventListener([3], ['DSDocUnSelected'], (ev) => {
            this.showNav2Item(false);
        });
    }
    async onDSDocPageClicked(ev) {
        if (!ev.desc)
            return;
        this.doc = JSON.parse(ev.desc);
        if (!this.editor) {
            await this.waitForEditorLoad();
        }
        if (this.editor && this.doc)
            this.editor.text = this.doc.content;
    }
    waitForEditorLoad() {
        return new Promise((resolve, reject) => {
            const intervalId = setInterval(() => {
                if (this.editor) {
                    clearInterval(intervalId);
                    resolve();
                }
            }, 1000);
            setTimeout(() => {
                clearInterval(intervalId);
                reject('Editor not found');
            }, 5000);
        });
    }
    fireComunication(op) {
        this.setError('');
        if (!this.doc) {
            this.setError('No documentation selected.');
            return;
        }
        if (op === 'Delete' && this.doc.hasChildren) {
            this.setError('Please, remove the subitens first.');
            return;
        }
        if (!this.docTitle || !this.editor)
            return;
        this.doc.title = this.docTitle.innerText;
        this.doc.content = this.editor.text;
        this.doc.op = op;
        const json = JSON.stringify(this.doc);
        mls.events.fire([3], ['DSDocPageChanged'], json);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${!this.doc ?
            html `
                <h4>${this.msg.noDocumentationSelected}!</h4>
                ` :
            html `
                <div style="padding: 1rem;">
                    <div style="display:flex; gap:1rem; justify-content: center;">
                        <button class="btn-docs" @click=${() => { this.fireComunication('Add'); }}>
                            <span>${this.msg.addChild}</span>
                            ${collab_plus}
                        </button>
                        <button class="btn-docs" @click=${() => { this.fireComunication('Delete'); }}>
                            <span>${this.msg.removeThis}</span>
                            ${collab_trash}
                        </button>
                    </div>
                    <div style="width:100%; display: flex; align-items: center;">
                        <h1 contenteditable class="title" @blur=${() => { this.fireComunication('Update'); }}>${this.doc.title}</h1>
                    </div>
                    <editor-quill-docs-100554 opened="false" .cbFinishEdit=${() => { this.fireComunication('Change'); }}></editor-quill-docs-100554>
                </div>
            `}            
        `;
    }
};
ServiceDsDocView100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsDocView100554.prototype, "doc", void 0);
__decorate([
    query('editor-quill-docs-100554')
], ServiceDsDocView100554.prototype, "editor", void 0);
__decorate([
    query('.title')
], ServiceDsDocView100554.prototype, "docTitle", void 0);
ServiceDsDocView100554 = __decorate([
    customElement('service-ds-doc-view-100554')
], ServiceDsDocView100554);
export { ServiceDsDocView100554 };
