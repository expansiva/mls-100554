/// <mls shortName="wcImage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaApresentationImagesImagesBase } from './_100554_icaApresentationImagesImagesBase';
let WcImage100554 = class WcImage100554 extends IcaApresentationImagesImagesBase {
    render() {
        return html `
            <div class="image-container">
                    <img
                        src="${this.src}" 
                        alt="${this.alt || ''}" 
                        width="${this.width || 'auto'}"
                        height="${this.height || 'auto'}
                    "></img>                
            </div>
    `;
    }
};
__decorate([
    property()
], WcImage100554.prototype, "src", void 0);
__decorate([
    property()
], WcImage100554.prototype, "alt", void 0);
__decorate([
    property()
], WcImage100554.prototype, "width", void 0);
__decorate([
    property()
], WcImage100554.prototype, "height", void 0);
WcImage100554 = __decorate([
    customElement('wc-image-100554')
], WcImage100554);
export { WcImage100554 };
