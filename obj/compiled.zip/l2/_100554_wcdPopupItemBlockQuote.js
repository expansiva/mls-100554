/// <mls shortName="wcdPopupItemBlockQuote" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WCDPopupItemH1 } from "./_100554_wcdPopupItemH1";
let WCDPopupItemBlockQuote = class WCDPopupItemBlockQuote extends WCDPopupItemH1 {
    constructor() {
        super();
        this.headerText = 'blockquote';
    }
    getSvg() {
        return svg `
      <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
        <text x="3" y="17" font-size="14" font-weight="bold">"</text>
      </svg>
    `;
    }
};
WCDPopupItemBlockQuote = __decorate([
    customElement('wcd-popup-item-block-quote-100554')
], WCDPopupItemBlockQuote);
export { WCDPopupItemBlockQuote };
