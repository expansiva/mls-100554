/// <mls shortName="pageTest4" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { getState, subscribe, initState, setState, unsubscribe } from './_100554_collabState';
import { initTestState } from './_100554_pageTestBase';
let PageTest4 = class PageTest4 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`page-test4-100554 wc-button-submit-100554{padding-top:1rem}page-test4-100554 wc-button-submit-100554 button{width:100%}`);
    }
    initPage() {
        initTestState();
        initState('projectTest.page4', {
            action: '',
            filter: {
                solicitante: '',
                status: '',
            },
            fields: ['id', 'solicitante', 'item', 'quantidade', 'data', 'status'],
            status: [''].concat(...getState('projectTest.tables.status').map((item) => item.value)),
            actualData: [...getState('projectTest.tables.solicitacoes')]
        });
        subscribe([
            'projectTest.page4.action',
        ], this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        unsubscribe([
            'projectTest.page4.action'
        ], this);
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== 'projectTest.page4.action')
            return;
        if (_value === 'filter') {
            this.handleClickBtnFilter();
        }
    }
    filterData(dados, filtro) {
        return dados.filter(({ solicitante, data, status }) => {
            const statusCorreto = filtro.status ? status === filtro.status : true;
            const solicitanteCorreto = filtro.solicitante ?
                solicitante.toLowerCase().includes(filtro.solicitante.toLowerCase()) : true;
            return statusCorreto && solicitanteCorreto;
        });
    }
    async handleClickBtnFilter() {
        const filterAtual = getState('projectTest.page4.filter');
        const data = [...getState('projectTest.tables.solicitacoes')];
        const filtered = this.filterData(data, filterAtual);
        setState('projectTest.page4.actualData', filtered, true);
        setState('projectTest.page4.action', '', true);
        this.requestUpdate();
    }
};
PageTest4 = __decorate([
    customElement('page-test4-100554')
], PageTest4);
export { PageTest4 };
