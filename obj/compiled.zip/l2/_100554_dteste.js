/// <mls shortName="dteste" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
let Dteste100554 = class Dteste100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.title = 'Titulo';
        this.body = 'Corpo';
    }
    render() {
        return html `
        <section>
            <h2>${this.title}</h2>
            <p>${this.body}</p>
        </section>`;
    }
};
__decorate([
    property()
], Dteste100554.prototype, "title", void 0);
__decorate([
    property()
], Dteste100554.prototype, "body", void 0);
Dteste100554 = __decorate([
    customElement('dteste-100554')
], Dteste100554);
export { Dteste100554 };
