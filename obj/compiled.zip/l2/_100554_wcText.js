/// <mls shortName="wcText" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaApresentationTextTextBase } from './_100554_icaApresentationTextTextBase';
import { propertyDataSource } from './_100554_icaLitElement';
let WcInputText100554 = class WcInputText100554 extends IcaApresentationTextTextBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-text-100554{display:inline-block;width:100%;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color)}wc-text-100554.dropcap p::first-letter{font-size:3em;font-weight:bold;float:left;line-height:1;margin-right:.1em}wc-text-100554 blockquote{border-left:3px solid var(--text-primary-color-darker);padding-left:20px;margin-left:-23px;padding-bottom:2px}`);
        this.error = '';
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        let tag = '';
        switch (this.type) {
            case 'h1':
                tag = 'h1';
                break;
            case 'h2':
                tag = 'h2';
                break;
            case 'h3':
                tag = 'h3';
                break;
            case 'h4':
                tag = 'h4';
                break;
            case 'h5':
                tag = 'h5';
                break;
            case 'h6':
                tag = 'h6';
                break;
            case 'p':
                tag = 'p';
                break;
            case 'blockquote':
                tag = 'blockquote';
                break;
            default:
                tag = 'span';
        }
        if (!this.text)
            this.style.minHeight = '5rem';
        const line = `<${tag}>${this.text}</${tag}>`;
        return unsafeHTML(line);
    }
};
__decorate([
    propertyDataSource({ type: String })
], WcInputText100554.prototype, "datasource", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "text", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "type", void 0);
WcInputText100554 = __decorate([
    customElement('wc-text-100554')
], WcInputText100554);
export { WcInputText100554 };
