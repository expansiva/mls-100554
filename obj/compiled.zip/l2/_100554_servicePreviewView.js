/// <mls shortName="servicePreviewView" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getDependenciesByHtml } from './_100554_libCompile';
import { convertFileNameToTag } from './_100554_utilsLit';
import { getDSInstance } from './_100554_libDesignSystem';
export const initServicePreviewView = '';
/// **collab_i18n_start**
const message_pt = {
    pageNotDefined: 'Página não definida',
    notFoundStorfile: 'Arquivo não encontrado',
    configure: 'Configure seu HTML pela opção do editor!',
    width: 'Largura',
    height: 'Altura'
};
const message_en = {
    pageNotDefined: 'Page not defined',
    notFoundStorfile: 'Not found storfile',
    configure: 'Configure your html by editor option!',
    width: 'Width',
    height: 'Height',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreviewView = class ServicePreviewView extends LitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.file = undefined;
        this.mfile = undefined;
        this.page = '';
        this.mode = 'desktop';
        this.level = '';
        this.isDsComponent = false;
        this.watch = true;
        this.stylechanged = '';
        this.actualtheme = 'Default';
        this.error = '';
        this.lastCompiledUrl = '';
        this.widthP = '300';
        this.heightP = '600';
        this.objVariations = {
            0: 'en-US',
            1: 'pt-BR'
        };
        this.lastHTML = '';
        this.timeShow = -1;
        this.infoDS = {};
        this.scrollMobile = `
        .scroll-custom::-webkit-scrollbar {
            width: 5px;
        }
        .scroll-custom::-webkit-scrollbar-track {
            background: #ddd;
        }
        .scroll-custom::-webkit-scrollbar-thumb {
            background: #666;
        }
        .scroll-custom::scrollbar {
            width: 2px;
        }
        .scroll-custom::scrollbar-track {
            background: #ddd;
        }
        .scroll-custom::scrollbar-thumb {
            background: #666;
        };
    `;
    }
    //-----------EVENTS-----------------
    setEventsCollab() {
        mls.events.addListener(2, 'WidgetAction', this.onWidgetActionEvents.bind(this));
    }
    //---------COMPONENTS---------------
    connectedCallback() {
        super.connectedCallback();
        this.setEventsCollab();
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'stylechanged') {
            if (newVal === 'true')
                this.addStyles();
            return;
        }
        super.attributeChangedCallback(name, oldVal, newVal);
    }
    render() {
        const lang = this.father && this.father.getMessageKey ? this.father.getMessageKey(messages) : 'en-us';
        this.msg = messages[lang];
        if (this.error !== '')
            return this.renderError();
        else
            return this.renderPreview();
    }
    renderError() {
        return html `<h3 style="color:red">${this.error}</h3>`;
    }
    renderPreview() {
        this.watch = this.father.watch;
        this.verifyWC().then((res) => {
            this.isDsComponent = res;
        });
        if (this.mode === 'mobile') {
            this.style.cssText = `
                width:100%;
                height:100vh;
                min-height:700px;
                display: flex!important;
                flex-direction: column;
                align-items: center;
                padding-top:.5rem;
            `;
            return html ` 
                
                <div class="groupSetMobile">
                    <div>
                        <label>${this.msg.width}:</label>
                        <input type="number" value="300" @input="${this.changeWidthP}">
                    </div>
                    <div>
                        <label>${this.msg.height}:</label>
                        <input type="number" value="700" @input="${this.changeHeightP}">
                    </div>
                    </div> 
                <div class="phone" style="width:${this.widthP}px; height:${this.heightP}px">
                    <div class="phone_mic"></div>
                    <div class="phone_screen">
                        <iframe style="width:100%; height:100%; border:none; display:none"  src="/_100554_servicePreview" @load="${this.load}" ></iframe>
                    </div>
                    <div class="phone_button"></div>
                </div>
                
            `;
        }
        else {
            this.style.cssText = `
                display: block;
                width: 100%;
                height: 100%;
            `;
            return html `
            
            <iframe
                style="width:100%; height:100%; border:none; display:none" src="/_100554_servicePreview"
                @load="${this.load}" >
            
            </iframe>`;
        }
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level')) {
            const oldLevel = changedProperties.get('level');
            if (!oldLevel)
                return;
            this.fireChangeICA();
            /*if (this.level === '7') {
                this.fireChangeICA();
                this.load();
            } else if (oldLevel === '7') {
                this.load();
                this.fireChangeICA();
            } else {
                this.fireChangeICA();
            }*/
        }
    }
    //-------- IMPLEMENTS---------
    onWidgetActionEvents(ev) {
        if (ev.level.toString() !== this.level)
            return;
        if (!ev.desc)
            return;
        const json = JSON.parse(ev.desc);
        if (json.op !== 'SelectWidget')
            return;
        this.selectIdinPreview(json.id, json.origin);
    }
    selectIdinPreview(id, origin) {
        if (!id || !this.shadowRoot)
            return;
        const iframe = this.shadowRoot.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        if (origin !== 'editor')
            return;
        const el = this.findElementsStartingWithIca(id);
        if (!el)
            return;
        const ev = new CustomEvent('click', {
            detail: {
                origin,
            }
        });
        const ov = el.overlayRef;
        if (!ov)
            return;
        ov.dispatchEvent(ev);
    }
    findElementsStartingWithIca(id) {
        if (!id || !this.shadowRoot)
            return undefined;
        const iframe = this.shadowRoot.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return undefined;
        const doc = iframe.contentDocument;
        let elements = [];
        // Function to traverse shadow DOM
        function traverseShadowRoot(element) {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                elements.push(element);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child));
                }
            }
        }
        doc.body.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item);
        });
        const newId = `ica_${id}`;
        const ret = elements.find((el) => el.id === newId);
        return ret;
    }
    fireChangeICA() {
        if (!this.shadowRoot)
            return;
        const iframe = this.shadowRoot.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        this.changeLevelIca(iframe.contentDocument.body);
    }
    changeLevelIca(el) {
        const isPage = el.isPage;
        let tagEl = el.tagName.toLowerCase();
        if (tagEl.startsWith('ica-') || isPage) {
            el.setAttribute('level', this.level);
        }
        for (const i of el.children) {
            this.changeLevelIca(i);
        }
    }
    async addStyles() {
        if (!this.mfile)
            return;
        let txt = await this.getFileContent();
        const ret = await getDependenciesByHtml(this.mfile, txt, this.actualtheme, true);
        const iframe = this.shadowRoot?.querySelector('iframe');
        if (!iframe)
            return;
        this.mountCSS(ret, iframe);
        this.mountTokens(ret, iframe);
        this.addGlobalStyle(ret, iframe);
        const tag = convertFileNameToTag(`_${this.mfile.project}_${this.mfile.shortName}`);
        const el = iframe.contentDocument?.body.querySelector(tag);
        if (!el)
            return;
        const css = ret.css.join(' \n');
        const enhacement = await this.getEnhacement();
        if (!enhacement)
            return;
        enhacement.setStylesProcessed(css, el, tag);
        // (el as any).setStylesProcessed(css, el, tag);
    }
    async getEnhacement() {
        if (!this.mfile)
            return;
        const enhacementName = this.mfile.compilerResults.tripleSlashMLS.variables.enhancement;
        if (!enhacementName)
            throw new Error('enhacementName not valid');
        const mModule = await mls.l2.enhancement.getEnhancementInstance(this.mfile);
        return mModule;
    }
    load() {
        this.showLoader(true);
        if (!this.shadowRoot)
            return;
        const iframe = this.shadowRoot.querySelector('iframe');
        const head = iframe.contentDocument?.querySelector('head');
        if (head) {
            const base = document.createElement('base');
            base.href = document.baseURI;
            head.appendChild(base);
        }
        this.init(iframe);
    }
    async init(iframe) {
        try {
            this.setDevice(iframe);
            this.setTheme(iframe);
            this.setMyFile();
            await this.setHTml(iframe);
            iframe.style.display = '';
            const html = iframe.contentDocument?.querySelector('html');
            if (html)
                html.lang = this.objVariations[window.globalVariation] || 'en-US';
            if (iframe.contentDocument)
                iframe.contentDocument.body.style.paddingTop = '55px';
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
            this.showLoader(false);
        }
    }
    setTheme(iframe) {
        const isLight = this.father.light;
        const html = iframe.contentDocument?.querySelector('html');
        if (!isLight && html) {
            html.setAttribute('data-theme', 'dark');
        }
    }
    setDevice(iframe) {
        if (iframe.contentDocument)
            iframe.contentDocument.documentElement.setAttribute('data-device', this.mode);
    }
    setMyFile() {
        if (!this.page || this.page === '')
            throw new Error(this.msg.pageNotDefined);
        mls.actual[0].setFullName(this.page);
        const info = mls.actual[0];
        const key = mls.stor.getKeyToFiles(info.project, 2, info.path, '', '.html');
        const mkey = mls.l2.editor.getKey({
            project: info.project,
            shortName: info.path,
        });
        if (!mls.stor.files[key])
            throw new Error(this.msg.notFoundStorfile + ': ' + key);
        if (!mls.l2.editor.mfiles[mkey])
            throw new Error(this.msg.notFoundStorfile + ' mfile: ' + mkey);
        this.file = mls.stor.files[key];
        this.mfile = mls.l2.editor.mfiles[mkey];
    }
    async setHTml(iframe) {
        if (!iframe.contentDocument || !this.mfile)
            return;
        let txt = await this.getFileContent();
        /*if (this.level === '7') {
            txt = this.cleanTree();
        }*/
        if (this.lastHTML === txt) {
            const h = this.lastCompiledUrl;
            this.lastCompiledUrl = h;
            return;
        }
        this.lastHTML = txt;
        iframe.contentDocument.body.innerHTML = txt;
        iframe.contentDocument.body.style.paddingTop = '10px';
        iframe.contentDocument.body['service'] = this.father;
        const ret = await getDependenciesByHtml(this.mfile, txt, this.actualtheme, true);
        this.mountJSImporMap(ret, iframe);
        this.mountJS(ret, iframe);
        this.mountCSS(ret, iframe);
        this.mountTokens(ret, iframe);
        this.addGlobalStyle(ret, iframe);
    }
    async getFileContent() {
        let txt = '<h3>' + this.msg.configure + '</h3>';
        if (this.file && this.file.getValueInfo)
            txt = (await this.file.getValueInfo()).content;
        if (this.file && txt === null)
            txt = await this.file.getContent();
        return txt;
    }
    mountJSImporMap(info, ifr) {
        try {
            if (info.importsMap.length <= 0 || !ifr.contentDocument)
                return;
            const js = '{"imports": { ' + info.importsMap.join(',\n') + '} }';
            const script = document.createElement('script');
            script.type = 'importmap';
            script.textContent = js;
            ifr.contentDocument.head.appendChild(script);
        }
        catch (e) {
            console.info('Error mountJSImporMap: ' + e.message);
            return;
        }
    }
    mountJS(info, ifr) {
        function loadScripts(scripts) {
            const loadScript = (src) => {
                return new Promise((resolve, reject) => {
                    const script = document.createElement('script');
                    script.type = 'module';
                    script.id = src.replace('/', '');
                    script.src = src;
                    script.onload = resolve;
                    script.onerror = reject;
                    ifr.contentDocument?.body.appendChild(script);
                });
            };
            let nextScript = Promise.resolve();
            for (const script of scripts) {
                nextScript = nextScript.then(() => loadScript(script));
            }
            return nextScript;
        }
        try {
            if (info.importsJs.length <= 0 || !ifr.contentDocument)
                return;
            const s = document.createElement('script');
            s.textContent = `
				window['mls'] = window['mls']  ? window['mls']  : parent.mls ? parent.mls : top['mls'];
				window['globalVariation'] = window['globalVariation']  ? window['globalVariation']  : parent.globalVariation ? parent.globalVariation : top['globalVariation'];
				window['latest'] = window['latest']  ? window['latest']  : parent.latest ? parent.latest : top['latest'];
				window['Quill'] = window['Quill']  ? window['Quill']  : parent.Quill ? parent.Quill : top['Quill'];
				window['EasyMDE'] = window['EasyMDE']  ? window['EasyMDE']  : parent.EasyMDE ? parent.EasyMDE : top['EasyMDE'];
				window['l2_html'] = window['l2_html']  ? window['l2_html']  : parent.l2_html ? parent.l2_html : top['l2_html'];
                window['monaco'] = window['monaco']  ? window['monaco']  : parent.monaco ? parent.monaco : top['monaco'];
				window['l2_fieldTypes'] = window['l2_fieldTypes']  ? window['l2_fieldTypes']  : parent.l2_fieldTypes ? parent.l2_fieldTypes : top['l2_fieldTypes'];window['litDisableBundleWarning'] = true; window['collabActualLevel'] = ${this.level};
				`;
            ifr.contentDocument?.body.appendChild(s);
            loadScripts(info.importsJs)
                .then(() => {
                this.simulateService(info, ifr);
            });
        }
        catch (e) {
            console.info('Error mountJS: ' + e.message);
        }
    }
    async simulateService(info, ifr) {
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        if (this.file && this.mfile) {
            const txt = this.mfile.model.getValue();
            if (txt.indexOf('extends ServiceBase') === -1)
                return;
            const tag = convertFileNameToTag(`_${this.file.project}_${this.file.shortName}`);
            const instance = ifr.contentDocument.body.querySelector(tag);
            if (instance) {
                this.addFA(ifr);
                this.addTooltip(ifr);
                this.addNav3(ifr, instance);
            }
        }
    }
    addTooltip(ifr) {
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        if (!ifr.contentWindow.customElements.get('collab-tooltip')) {
            ifr.contentWindow.customElements.define('collab-tooltip', window['l4_html'].MlsTooltip);
        }
        ifr.contentWindow.customElements.whenDefined('collab-tooltip').then(() => {
            if (!ifr.contentDocument)
                return;
            const collaTbTooltip = document.createElement('collab-tooltip');
            ifr.contentDocument.body.appendChild(collaTbTooltip);
        });
    }
    addNav3(ifr, instance) {
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        if (!ifr.contentWindow.customElements.get('mls-nav3-100529')) {
            ifr.contentWindow.customElements.define('mls-nav3-100529', window['l4_html']._100529_mls_nav3);
        }
        ifr.contentWindow.customElements.whenDefined('mls-nav3-100529').then(() => {
            if (!ifr.contentDocument)
                return;
            const collabNav = document.createElement('collab-nav');
            collabNav.style.position = 'relative';
            collabNav.style.width = '100%';
            collabNav.style.display = 'block';
            collabNav['mlsWidget'] = instance;
            const mlsnav3 = document.createElement('mls-nav3-100529');
            mlsnav3.setAttribute('is-mls2', 'true');
            collabNav.appendChild(mlsnav3);
            ifr.contentDocument.body.insertBefore(collabNav, instance);
        });
    }
    addFA(ifr) {
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        const styleFA = document.createElement('link');
        styleFA.rel = 'stylesheet';
        styleFA.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css';
        styleFA.type = 'text/css';
        ifr.contentDocument.head.appendChild(styleFA);
    }
    removeOlderStyle(ifr) {
        const id = this.getIdStyle();
        if (!ifr.contentDocument || !id)
            return;
        const st = ifr.contentDocument.body.querySelectorAll(`#${id}`);
        st.forEach((s) => s.remove());
    }
    removeOlderTokens(ifr) {
        const id = this.getIdTokens();
        if (!ifr.contentDocument || !id)
            return;
        const st = ifr.contentDocument.body.querySelectorAll(`#${id}`);
        st.forEach((s) => s.remove());
    }
    removeOlderGlobalStyle(ifr) {
        if (!ifr.contentDocument)
            return;
        const st = ifr.contentDocument.body.querySelector(`#css_global`);
        if (st)
            st.remove();
    }
    mountCSS(info, ifr) {
        try {
            if (!ifr.contentDocument)
                return;
            this.removeOlderStyle(ifr);
            let cls = '';
            if (this.mode === 'mobile')
                cls = this.scrollMobile;
            const css = info.css.join(' \n');
            const style = document.createElement('style');
            style.textContent = css + ' \n' + cls;
            style.id = this.getIdStyle();
            ifr.contentDocument.body.className = 'scroll-custom';
            // ifr.contentDocument.body.style.height = 'calc(100vh - 40px)';
            ifr.contentDocument.body.style.width = '98%';
            ifr.contentDocument.body.appendChild(style);
        }
        catch (e) {
            console.info('Error mountCSS: ' + e.message);
        }
    }
    getIdStyle() {
        if (!this.mfile)
            return '';
        return '_' + this.mfile.project + '_' + this.mfile.shortName;
    }
    getIdTokens() {
        if (!this.mfile)
            return 'ds_tokens';
        return '_' + this.mfile.project + '_ds_tokens';
    }
    mountTokens(info, ifr) {
        try {
            if (!ifr.contentDocument)
                return;
            this.removeOlderTokens(ifr);
            const css = info.tokens[0];
            const style = document.createElement('style');
            style.textContent = css;
            style.id = this.getIdTokens();
            ifr.contentDocument.body.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTokens: ' + e.message);
        }
    }
    addGlobalStyle(info, ifr) {
        try {
            if (!ifr.contentDocument || !info.globalCss)
                return;
            this.removeOlderGlobalStyle(ifr);
            const css = info.globalCss;
            const style = document.createElement('style');
            style.textContent = css;
            style.id = 'css_global';
            ifr.contentDocument.body.appendChild(style);
        }
        catch (e) {
            console.info('Error add global styles: ' + e.message);
        }
    }
    changeWidthP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 200)
            return;
        this.widthP = el.value;
    }
    changeHeightP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 250)
            return;
        this.heightP = el.value;
    }
    showLoader(show) {
        clearTimeout(this.timeShow);
        this.timeShow = setTimeout(() => {
            if (!this.father)
                return;
            this.father.loading = show;
        }, 200);
    }
    async verifyWC() {
        const { project } = mls.actual[5];
        if (!project)
            throw new Error('No project selected');
        this.infoDS = {
            ds: await getDSInstance(project, 0),
            level: +this.level,
            project
        };
        let comp;
        await this.infoDS.ds.init();
        mls.actual[0].setFullName(this.page);
        const info = mls.actual[0];
        const compName = `_${info.project}_${info.path}`;
        if (this.infoDS.ds && this.infoDS.ds.components)
            comp = this.infoDS.ds.components.find(compName);
        if (comp)
            return true;
        const isAWebComponent = await this.checkIfIsAWebComponent(compName);
        if (!isAWebComponent)
            return false;
        await this.addComponent(compName, this.infoDS.ds);
        return !!comp;
    }
    async checkIfIsAWebComponent(widget) {
        mls.actual[0].setFullName(widget);
        const { project, path } = mls.actual[0];
        if (!project || !path)
            return false;
        if (path === 'servicePreviewView')
            return false;
        const model = mls.l2.editor.get({ project, shortName: path });
        if (!model)
            return false;
        const file = model.storFile;
        if (!file)
            return false;
        const content = await file.getContent();
        if (typeof content !== 'string')
            return false;
        const regex = /css\`\[\[mls_getDefaultDesignSystem\]\]\`/;
        if (regex.test(content))
            return true;
        return false;
    }
    async getGroup(widget) {
        const defaultGroup = 'other';
        mls.actual[0].setFullName(widget);
        const model = mls.l2.editor.get({ project: mls.actual[0].project, shortName: mls.actual[0].path });
        if (!model || !model.compilerResults || !model.compilerResults.tripleSlashMLS)
            return defaultGroup;
        const { variables } = model.compilerResults.tripleSlashMLS;
        if (!variables)
            return defaultGroup;
        const { groupName } = variables;
        if (!groupName)
            return defaultGroup;
        return groupName;
    }
    async addComponent(name, ds) {
        if (!name || !ds)
            return;
        const group = await this.getGroup(name);
        const componentName = name;
        const widget = {
            docPath: '',
            examples: [],
            group: group,
            l4MarketingRef: '',
            name: componentName,
            reference: undefined,
            styles: [],
            tags: [],
            widgetExampleRef: {
                path: '',
                tagname: ''
            }
        };
        try {
            if (!ds.components)
                return;
            await ds.components.add(widget);
        }
        catch (err) {
            const msg = 'Error on add component in design system';
            this.error = msg;
            throw new Error('Error on add component in design system');
        }
    }
    cleanTree() {
        let ret = '';
        const iframe = this.shadowRoot?.querySelector('iframe');
        if (!iframe)
            return '';
        const div = document.createElement('div');
        const divRet = document.createElement('div');
        const body = iframe.contentDocument?.body;
        if (!body)
            return ret;
        this.cleanTree2(div, body);
        /*const clearChildren = (father: HTMLElement, el: HTMLElement) => {
            let children = [...el.children];

            for (const child of children) {
                const tagname = child.tagName.toLowerCase();
                if (tagname.indexOf('-') > 0) {
                    const clone = child.cloneNode(false);
                    father.appendChild(clone);
                    clearChildren(clone as HTMLElement, child as HTMLElement);
                } else {
                    clearChildren(father, child as HTMLElement);
                }

            }


        }

        clearChildren(divRet, div)*/
        this.cleanTree3(divRet, div);
        return divRet.innerHTML;
    }
    cleanTree2(father, element) {
        const tagname = element.tagName.toLowerCase();
        if (tagname.startsWith('ica-')) {
            let children = [...element.children];
            for (const child of children) {
                this.cleanTree2(father, child);
            }
        }
        else {
            const clone = element.cloneNode(false);
            father.appendChild(clone);
            let children = [];
            if (element.shadowRoot) {
                children = [...element.shadowRoot.children];
            }
            else {
                children = [...element.children];
            }
            for (const child of children) {
                this.cleanTree2(clone, child);
            }
        }
        return father;
    }
    cleanTree3(father, element) {
        let children = [...element.children];
        for (const child of children) {
            const tagname = child.tagName.toLowerCase();
            if (tagname.indexOf('-') > 0) {
                const clone = child.cloneNode(false);
                father.appendChild(clone);
                this.cleanTree3(clone, child);
            }
            else {
                this.cleanTree3(father, child);
            }
        }
    }
};
ServicePreviewView.styles = css `
        :host{
            position:relative;
        }

        .watchDesktop{
            position: absolute;
            background: white;
            box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 2px;
            top: 3px;
            right: 46px;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }

        .groupSetMobile{
            display:flex;
            width:300px;
            gap:.8rem;
            justify-content: center;
            align-items: center;
            margin-bottom:1rem;
        }

        .groupSetMobile div{
            display:flex;
            flex-direction: column;
            
        }

        .groupSetMobile label{
            font-size:.8rem;
            font-weight:bold;
        }

        .groupSetMobile input{
            border:1px solid #cac7c7;
            outline:none;
            width:100px;
            height:20px;
            border-radius:5px;
        }

        .phone {
            z-index: 1;
            padding: 0 0.5rem;
            border: 0.25rem solid #404040;
            border-radius: 1rem;
            display: flex;
            flex-direction: column;
            //box-shadow: 0.5rem 0.5rem rgba(0, 0, 0, 0.3);
            box-shadow:0px 5px 3px 3px rgba(0, 0, 0, 0.3);
            background:white;
        }

        .phone_mic {
            height: 0.25rem;
            width: 4rem;
            margin: 1rem auto;
            border-radius: 999rem;
            background-color: #505050;
        }

        .phone_screen {
            position: relative;
            flex: 1 0 auto;
            border: 1px solid #505050;
            border-radius:5px;
        }

        .phone_screen iframe{
            border-radius:5px;
        }
        
        .phone_button {
            width: 1.5rem;
            height: 1.5rem;
            border: 2px solid #505050;
            border-radius: 50%;
            margin: 1rem auto;
        }
    
    `;
__decorate([
    property()
], ServicePreviewView.prototype, "father", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "page", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "mode", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "level", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "isDsComponent", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "watch", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "stylechanged", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "actualtheme", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "error", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "lastCompiledUrl", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "widthP", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "heightP", void 0);
ServicePreviewView = __decorate([
    customElement('service-preview-view-100554')
], ServicePreviewView);
export { ServicePreviewView };
