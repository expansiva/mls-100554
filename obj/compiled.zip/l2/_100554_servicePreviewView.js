/// <mls shortName="servicePreviewView" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getDependenciesByHtml } from './_100554_libCompile';
import { convertFileNameToTag } from './_100554_utilsLit';
import { compileStyleUsingStorFile } from './_100554_enhancementStyle';
export const initServicePreviewView = '';
/// **collab_i18n_start**
const message_pt = {
    pageNotDefined: 'Página não definida',
    notFoundStorfile: 'Arquivo não encontrado',
    errorCompile: 'Erro ao compilar typescript',
    configure: 'Configure seu HTML pela opção do editor!',
    width: 'Largura',
    height: 'Altura'
};
const message_en = {
    pageNotDefined: 'Page not defined',
    notFoundStorfile: 'Not found storfile',
    errorCompile: 'Error on compiling typescript',
    configure: 'Configure your html by editor option!',
    width: 'Width',
    height: 'Height',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreviewView = class ServicePreviewView extends LitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.file = undefined;
        this.models = undefined;
        this.page = '';
        this.mode = 'desktop';
        this.lang = 'en';
        this.level = '';
        this.isDsComponent = false;
        this.watch = true;
        this.stylechanged = '';
        this.actualtheme = 'Default';
        this.error = '';
        this.lastCompiledUrl = '';
        this.widthP = '300';
        this.heightP = '600';
        this.lastHTML = '';
        this.isService = false;
        this.timeShow = -1;
        this.scrollMobile = `
        .scroll-custom::-webkit-scrollbar {
            width: 5px;
        }
        .scroll-custom::-webkit-scrollbar-track {
            background: #ddd;
        }
        .scroll-custom::-webkit-scrollbar-thumb {
            background: #666;
        }
        .scroll-custom::scrollbar {
            width: 2px;
        }
        .scroll-custom::scrollbar-track {
            background: #ddd;
        }
        .scroll-custom::scrollbar-thumb {
            background: #666;
        };
    `;
    }
    //-----------EVENTS-----------------
    setEventsCollab() {
        mls.events.addListener(2, 'WidgetAction', this.onWidgetActionEvents.bind(this));
    }
    //---------COMPONENTS---------------
    connectedCallback() {
        super.connectedCallback();
        this.setEventsCollab();
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'stylechanged') {
            if (newVal === 'true')
                this.addStyles();
            return;
        }
        super.attributeChangedCallback(name, oldVal, newVal);
    }
    render() {
        const lang = this.father && this.father.getMessageKey ? this.father.getMessageKey(messages) : 'en-us';
        this.msg = messages[lang];
        if (this.error !== '')
            return this.renderError();
        else
            return this.renderPreview();
    }
    renderError() {
        return html `<h3 style="color:red">${this.error}</h3>`;
    }
    renderPreview() {
        this.watch = this.father.watch;
        if (this.mode === 'mobile') {
            this.style.cssText = `
                width:100%;
                height:100vh;
                min-height:700px;
                display: flex!important;
                flex-direction: column;
                align-items: center;
                padding-top:.5rem;
            `;
            return html ` 
                
                <div class="groupSetMobile">
                    <div>
                        <label>${this.msg.width}:</label>
                        <input type="number" value="300" @input="${this.changeWidthP}">
                    </div>
                    <div>
                        <label>${this.msg.height}:</label>
                        <input type="number" value="700" @input="${this.changeHeightP}">
                    </div>
                    </div> 
                <div class="phone" style="width:${this.widthP}px; height:${this.heightP}px">
                    <div class="phone_mic"></div>
                    <div class="phone_screen">
                        <iframe style="width:100%; height:100%; border:none; display:none"  src="/_100554_servicePreview" @load="${this.load}" ></iframe>
                    </div>
                    <div class="phone_button"></div>
                </div>
                
            `;
            // ?t=${Date.now()}
        }
        else {
            this.style.cssText = `
                display: block;
                width: 100%;
                height: 100%;
            `;
            return html `
            
            <iframe
                style="width:100%; height:100%; border:none; display:none" src="/_100554_servicePreview"
                @load="${this.load}" >
            
            </iframe>`;
        }
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level')) {
            const oldLevel = changedProperties.get('level');
            if (!oldLevel)
                return;
            this.fireChangeICA();
        }
    }
    //-------- IMPLEMENTS---------
    onWidgetActionEvents(ev) {
        if (ev.level.toString() !== this.level)
            return;
        if (!ev.desc)
            return;
        const json = JSON.parse(ev.desc);
        if (json.op !== 'SelectWidget')
            return;
        this.selectIdinPreview(json.id, json.origin);
    }
    selectIdinPreview(id, origin) {
        if (!id || !this.shadowRoot)
            return;
        const iframe = this.shadowRoot.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        if (origin !== 'editor')
            return;
        const el = this.findElementsStartingWithIca(id);
        if (!el)
            return;
        const ev = new CustomEvent('click', {
            detail: {
                origin,
            }
        });
        const ov = el.overlayRef;
        if (!ov)
            return;
        ov.dispatchEvent(ev);
    }
    findElementsStartingWithIca(id) {
        if (!id || !this.shadowRoot)
            return undefined;
        const iframe = this.shadowRoot.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return undefined;
        const doc = iframe.contentDocument;
        let elements = [];
        function traverseShadowRoot(element) {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                elements.push(element);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child));
                }
            }
        }
        doc.body.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item);
        });
        const newId = `ica_${id}`;
        const ret = elements.find((el) => el.id === newId);
        return ret;
    }
    fireChangeICA() {
        if (!this.shadowRoot)
            return;
        const iframe = this.shadowRoot.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        this.changeLevelIca(iframe.contentDocument.body);
    }
    changeLevelIca(el) {
        const isPage = el.isPage;
        let tagEl = el.tagName.toLowerCase();
        if (tagEl.startsWith('ica-') || isPage) {
            el.setAttribute('level', this.level);
        }
        for (const i of el.children) {
            this.changeLevelIca(i);
        }
    }
    async addStyles() {
        if (!this.models || !this.models.style || !window.preview.iframe || !window.preview.iframe.contentDocument || !window.preview.iframe.contentWindow)
            return;
        const { project, shortName } = this.models.style.storFile;
        const id = convertFileNameToTag(`_${project}_${shortName}`);
        const oldStyle = window.preview.iframe.contentDocument.head.querySelector(`style[id=${id}]`);
        const newStyle = document.createElement('style');
        const newLess = await compileStyleUsingStorFile(shortName, project, this.actualtheme);
        if (!newLess)
            return;
        newStyle.id = id;
        newStyle.textContent = newLess;
        window.preview.iframe.contentDocument.head.appendChild(newStyle);
        if (oldStyle)
            oldStyle.remove();
        this.stylechanged = 'false';
    }
    load() {
        this.showLoader(true);
        if (!this.shadowRoot)
            return;
        const iframe = this.shadowRoot.querySelector('iframe');
        const head = iframe.contentDocument?.querySelector('head');
        if (head) {
            const base = document.createElement('base');
            base.href = document.baseURI;
            head.appendChild(base);
        }
        this.init(iframe);
        window.preview.iframe = iframe;
        const collabConsole = this.parentElement?.querySelector('collab-console-100554');
        collabConsole.scope = iframe.contentWindow;
    }
    async init(iframe) {
        try {
            this.setDevice(iframe);
            this.setTheme(iframe);
            this.setMyFile();
            if (!this.models
                || this.models.ts?.storFile.hasError
                || this.models.style?.storFile.hasError
                || this.models.html?.storFile.hasError) {
                this.error = this.msg.errorCompile;
                this.showLoader(false);
                this.renderError();
                return;
            }
            await this.setHTml(iframe);
            iframe.style.display = '';
            const html = iframe.contentDocument?.querySelector('html');
            if (html)
                html.lang = this.lang;
            if (iframe.contentDocument)
                iframe.contentDocument.body.style.paddingTop = '55px';
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
            this.showLoader(false);
        }
    }
    setTheme(iframe) {
        const isLight = this.father.light;
        const html = iframe.contentDocument?.querySelector('html');
        const meta = iframe.contentDocument?.querySelector('meta[name="color-scheme"]');
        if (!isLight && html) {
            html.setAttribute('data-theme', 'dark');
        }
        if (meta)
            meta.remove();
    }
    setDevice(iframe) {
        if (iframe.contentDocument)
            iframe.contentDocument.documentElement.setAttribute('data-device', this.mode);
    }
    setMyFile() {
        if (!this.page || this.page === '')
            throw new Error(this.msg.pageNotDefined);
        mls.actual[0].setFullName(this.page);
        const info = mls.actual[0];
        const key = mls.stor.getKeyToFiles(info.project, 2, info.path, '', '.html');
        const mkey = mls.l2.getKey({
            project: info.project,
            shortName: info.path,
        });
        if (!mls.stor.files[key])
            throw new Error(this.msg.notFoundStorfile + ': ' + key);
        if (!mls.editor.models[mkey])
            throw new Error(this.msg.notFoundStorfile + ' mfile: ' + mkey);
        this.file = mls.stor.files[key];
        this.models = mls.editor.models[mkey];
    }
    checkIfIsService() {
        if (!this.file || !this.models || !this.models.ts)
            return false;
        const txt = this.models.ts.model.getValue();
        if (txt.indexOf('extends ServiceBase') === -1)
            return false;
        return true;
    }
    async setHTml(iframe) {
        if (!iframe.contentDocument || !this.models)
            return;
        let txt = await this.getFileContent();
        this.isService = this.checkIfIsService();
        this.lastHTML = txt;
        iframe.contentDocument.body.style.paddingTop = '10px';
        iframe.contentDocument.body['service'] = this.father;
        let ret;
        if (this.isService && this.file) {
            const tag = convertFileNameToTag(`_${this.file.project}_${this.file.shortName}`);
        }
        iframe.contentDocument.body.innerHTML = txt;
        ret = await getDependenciesByHtml(this.models, txt, this.actualtheme, true);
        if (ret.errors.length > 0) {
            this.father.setError(`Error(${ret.errors.length}) when compiling:${ret.errors[0].error}`);
            console.info('Errors in compile', ret.errors);
        }
        this.mountJSImporMap(ret, iframe);
        this.mountJS(ret, iframe);
        this.mountCSS(iframe);
        this.mountTokens(ret, iframe);
    }
    async getFileContent() {
        let txt = '<h3>' + this.msg.configure + '</h3>';
        if (this.file && this.file.getValueInfo)
            txt = (await this.file.getValueInfo()).content;
        if (this.file && txt === null)
            txt = await this.file.getContent();
        return txt;
    }
    mountJSImporMap(info, ifr) {
        try {
            if (info.importsMap.length <= 0 || !ifr.contentDocument)
                return;
            const js = '{"imports": { ' + info.importsMap.join(',\n') + '} }';
            const script = document.createElement('script');
            script.type = 'importmap';
            script.textContent = js;
            ifr.contentDocument.head.appendChild(script);
        }
        catch (e) {
            console.info('Error mountJSImporMap: ' + e.message);
            return;
        }
    }
    mountJS(info, ifr) {
        function loadScripts(scripts) {
            const loadScript = (src) => {
                return new Promise((resolve, reject) => {
                    const script = document.createElement('script');
                    script.type = 'module';
                    script.id = src.replace('/', '');
                    script.src = src;
                    script.onload = resolve;
                    script.onerror = reject;
                    ifr.contentDocument?.body.appendChild(script);
                });
            };
            let nextScript = Promise.resolve();
            for (const script of scripts) {
                nextScript = nextScript.then(() => loadScript(script));
            }
            return nextScript;
        }
        try {
            if (info.importsJs.length <= 0 || !ifr.contentDocument)
                return;
            const s = document.createElement('script');
            s.textContent = `
				window['mls'] = window['mls']  ? window['mls']  : parent.mls ? parent.mls : top['mls'];
				window['globalVariation'] = window['globalVariation']  ? window['globalVariation']  : parent.globalVariation ? parent.globalVariation : top['globalVariation'];
				window['latest'] = window['latest']  ? window['latest']  : parent.latest ? parent.latest : top['latest'];
				window['Quill'] = window['Quill']  ? window['Quill']  : parent.Quill ? parent.Quill : top['Quill'];
				window['EasyMDE'] = window['EasyMDE']  ? window['EasyMDE']  : parent.EasyMDE ? parent.EasyMDE : top['EasyMDE'];
				window['l2_html'] = window['l2_html']  ? window['l2_html']  : parent.l2_html ? parent.l2_html : top['l2_html'];
                window['monaco'] = window['monaco']  ? window['monaco']  : parent.monaco ? parent.monaco : top['monaco'];
				window['l2_fieldTypes'] = window['l2_fieldTypes']  ? window['l2_fieldTypes']  : parent.l2_fieldTypes ? parent.l2_fieldTypes : top['l2_fieldTypes'];window['litDisableBundleWarning'] = true; window['collabActualLevel'] = ${this.level};

                
				`;
            ifr.contentDocument?.body.appendChild(s);
            loadScripts(info.importsJs)
                .then(() => {
                this.simulateService(info, ifr);
            });
        }
        catch (e) {
            console.info('Error mountJS: ' + e.message);
        }
    }
    async simulateService(info, ifr) {
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        if (this.isService) {
            this.addFA(ifr);
            this.addTooltip(ifr);
            this.addStyleMls(ifr);
            this.addNav3(ifr);
        }
    }
    addStyleMls(ifr) {
        const styleMls = document.querySelector('style#mls-style');
        if (!styleMls || !ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        const newStyle = styleMls.cloneNode(true);
        ifr.contentDocument.head.appendChild(newStyle);
    }
    addTooltip(ifr) {
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        if (!ifr.contentWindow.customElements.get('collab-tooltip')) {
            ifr.contentWindow.customElements.define('collab-tooltip', window['l4_html'].MlsTooltip);
        }
        ifr.contentWindow.customElements.whenDefined('collab-tooltip').then(() => {
            if (!ifr.contentDocument)
                return;
            const collaTbTooltip = document.createElement('collab-tooltip');
            ifr.contentDocument.body.appendChild(collaTbTooltip);
        });
    }
    waitForComponents(context, componentNames) {
        const promises = componentNames.map(name => context.customElements.whenDefined(name));
        return Promise.all(promises);
    }
    addNav3(ifr) {
        const wcToAdd = [
            { name: '_100529_collab_nav_3', tag: 'collab-nav-3' },
            { name: '_100529_collabNav3Menu', tag: 'collab-nav-3-menu' },
            { name: '_100529_collab_nav_3_tools_link', tag: 'collab-nav-3-menu-tools-link' },
            { name: '_100529_collab_nav_3_tools_cycle', tag: 'collab-nav-3-menu-tools-cycle' },
            { name: '_100529_collab_nav_3_tools_dropdown', tag: 'collab-nav-3-menu-tools-dropdown' },
        ];
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        wcToAdd.forEach((wc) => {
            if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
                return;
            if (!ifr.contentWindow.customElements.get(wc.tag))
                ifr.contentWindow.customElements.define(wc.tag, window['l4_html'][wc.name]);
        });
        const allTags = wcToAdd.map((item) => item.tag);
        this.waitForComponents(ifr.contentWindow, allTags).then(async () => {
            if (!ifr.contentDocument || !this.file)
                return;
            const dataService = `_${this.file?.project}_${this.file?.shortName}`;
            const tag = convertFileNameToTag(`_${this.file.project}_${this.file.shortName}`);
            const old = ifr.contentDocument.querySelector(tag);
            if (!old)
                return;
            await import(`./_${this.file.project}_${this.file.shortName}`);
            const instance = old.cloneNode();
            const lvl = instance.getAttribute('level') || '2';
            old?.remove();
            const collabNav = document.createElement('collab-nav-3');
            collabNav.setAttribute('toolbarposition', instance.position || 'right');
            collabNav.setAttribute('data-service', dataService);
            collabNav.setAttribute('level', lvl);
            instance.setAttribute('level', lvl);
            const collabNavService = document.createElement('collab-nav-3-service');
            collabNavService.setAttribute('data-service', dataService);
            collabNavService.className = 'active';
            collabNav.style.position = 'relative';
            collabNav.style.width = '100%';
            collabNav.style.display = 'block';
            collabNavService.mlsWidget = instance;
            const mlsnav3 = document.createElement('collab-nav-3-menu');
            mlsnav3.setAttribute('is-mls2', 'true');
            mlsnav3.setAttribute('toolbarposition', instance.position || 'right');
            collabNav.appendChild(collabNavService);
            collabNavService.appendChild(mlsnav3);
            ifr.contentDocument.body.appendChild(collabNav);
            mlsnav3.after(instance);
        });
    }
    addFA(ifr) {
        if (!ifr || !ifr.contentDocument || !ifr.contentWindow)
            return;
        const styleFA = document.createElement('link');
        styleFA.rel = 'stylesheet';
        styleFA.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css';
        styleFA.type = 'text/css';
        ifr.contentDocument.head.appendChild(styleFA);
    }
    removeOlderTokens(ifr) {
        const id = this.getIdTokens();
        if (!ifr.contentDocument || !id)
            return;
        const st = ifr.contentDocument.head.querySelectorAll(`#${id}`);
        st.forEach((s) => s.remove());
    }
    mountCSS(ifr) {
        try {
            if (!ifr.contentDocument)
                return;
            let cls = '';
            if (this.mode === 'mobile')
                cls = this.scrollMobile;
            const style = document.createElement('style');
            style.textContent = ' \n' + cls;
            ifr.contentDocument.body.className = 'scroll-custom';
            ifr.contentDocument.body.style.width = '98%';
            ifr.contentDocument.body.appendChild(style);
        }
        catch (e) {
            console.info('Error mountCSS: ' + e.message);
        }
    }
    getIdTokens() {
        if (!this.models || !this.models.ts)
            return 'ds_tokens';
        const { project } = this.models.ts.storFile;
        return '_' + project + '_ds_tokens';
    }
    mountTokens(info, ifr) {
        try {
            if (!ifr.contentDocument)
                return;
            this.removeOlderTokens(ifr);
            const css = info.tokens[0];
            const style = document.createElement('style');
            style.textContent = css;
            style.id = this.getIdTokens();
            ifr.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTokens: ' + e.message);
        }
    }
    changeWidthP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 200)
            return;
        this.widthP = el.value;
    }
    changeHeightP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 250)
            return;
        this.heightP = el.value;
    }
    showLoader(show) {
        clearTimeout(this.timeShow);
        this.timeShow = setTimeout(() => {
            if (!this.father)
                return;
            this.father.loading = show;
        }, 200);
    }
    cleanTree() {
        let ret = '';
        const iframe = this.shadowRoot?.querySelector('iframe');
        if (!iframe)
            return '';
        const div = document.createElement('div');
        const divRet = document.createElement('div');
        const body = iframe.contentDocument?.body;
        if (!body)
            return ret;
        this.cleanTree2(div, body);
        this.cleanTree3(divRet, div);
        return divRet.innerHTML;
    }
    cleanTree2(father, element) {
        const tagname = element.tagName.toLowerCase();
        if (tagname.startsWith('ica-')) {
            let children = [...element.children];
            for (const child of children) {
                this.cleanTree2(father, child);
            }
        }
        else {
            const clone = element.cloneNode(false);
            father.appendChild(clone);
            let children = [];
            if (element.shadowRoot) {
                children = [...element.shadowRoot.children];
            }
            else {
                children = [...element.children];
            }
            for (const child of children) {
                this.cleanTree2(clone, child);
            }
        }
        return father;
    }
    cleanTree3(father, element) {
        let children = [...element.children];
        for (const child of children) {
            const tagname = child.tagName.toLowerCase();
            if (tagname.indexOf('-') > 0) {
                const clone = child.cloneNode(false);
                father.appendChild(clone);
                this.cleanTree3(clone, child);
            }
            else {
                this.cleanTree3(father, child);
            }
        }
    }
};
ServicePreviewView.styles = css `
        :host{
            position:relative;
        }

        .watchDesktop{
            position: absolute;
            background: white;
            box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 2px;
            top: 3px;
            right: 46px;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }

        .groupSetMobile{
            display:flex;
            width:300px;
            gap:.8rem;
            justify-content: center;
            align-items: center;
            margin-bottom:1rem;
        }

        .groupSetMobile div{
            display:flex;
            flex-direction: column;
            
        }

        .groupSetMobile label{
            font-size:.8rem;
            font-weight:bold;
        }

        .groupSetMobile input{
            border:1px solid #cac7c7;
            outline:none;
            width:100px;
            height:20px;
            border-radius:5px;
        }

        .phone {
            z-index: 1;
            padding: 0 0.5rem;
            border: 0.25rem solid #404040;
            border-radius: 1rem;
            display: flex;
            flex-direction: column;
            //box-shadow: 0.5rem 0.5rem rgba(0, 0, 0, 0.3);
            box-shadow:0px 5px 3px 3px rgba(0, 0, 0, 0.3);
            background:white;
        }

        .phone_mic {
            height: 0.25rem;
            width: 4rem;
            margin: 1rem auto;
            border-radius: 999rem;
            background-color: #505050;
        }

        .phone_screen {
            position: relative;
            flex: 1 0 auto;
            border: 1px solid #505050;
            border-radius:5px;
        }

        .phone_screen iframe{
            border-radius:5px;
        }
        
        .phone_button {
            width: 1.5rem;
            height: 1.5rem;
            border: 2px solid #505050;
            border-radius: 50%;
            margin: 1rem auto;
        }
    
    `;
__decorate([
    property()
], ServicePreviewView.prototype, "father", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "page", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "mode", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "lang", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "level", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "isDsComponent", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "watch", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "stylechanged", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "actualtheme", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "error", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "lastCompiledUrl", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "widthP", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "heightP", void 0);
ServicePreviewView = __decorate([
    customElement('service-preview-view-100554')
], ServicePreviewView);
export { ServicePreviewView };
