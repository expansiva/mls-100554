/// <mls shortName="servicePreviewView" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getDependenciesByHtml, getTokens } from './_100554_libCompile';
import { convertFileNameToTag } from './_100554_utilsLit';
import { compileStyleUsingStorFile } from './_100554_enhancementStyle';
import { StateLitElement } from './_100554_stateLitElement';
import { PreviewModeSinglePage } from './_100554_previewModeSinglePage';
import { PreviewModeMinimum } from './_100554_previewModeMinimum';
/// **collab_i18n_start**
const message_pt = {
    pageNotDefined: 'Página não definida',
    notFoundStorfile: 'Arquivo não encontrado',
    errorCompile: 'Erro ao compilar typescript',
    configure: 'Configure seu HTML pela opção do editor!',
    width: 'Largura',
    height: 'Altura'
};
const message_en = {
    pageNotDefined: 'Page not defined',
    notFoundStorfile: 'Not found storfile',
    errorCompile: 'Error on compiling typescript',
    configure: 'Configure your html by editor option!',
    width: 'Width',
    height: 'Height',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreviewView = class ServicePreviewView extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-preview-view-100554 .error{padding:1rem;color:var(--error-color);font-size:var(--font-size-20)}service-preview-view-100554 .error .error-list{color:var(--text-primary-color);font-size:var(--font-size-16)}service-preview-view-100554.mobile{width:100%;height:100vh;min-height:700px;display:flex !important;flex-direction:column;align-items:center;padding-top:.5rem}service-preview-view-100554.mobile .watchDesktop{position:absolute;background:white;box-shadow:rgba(0,0,0,0.3) 0 1px 2px 2px;top:3px;right:46px;border-radius:50%;width:30px;height:30px;display:flex;justify-content:center;align-items:center;cursor:pointer}service-preview-view-100554.mobile .groupSetMobile{display:flex;width:300px;gap:.8rem;justify-content:center;align-items:center;margin-bottom:1rem}service-preview-view-100554.mobile .groupSetMobile div{display:flex;flex-direction:column}service-preview-view-100554.mobile .groupSetMobile label{font-size:.8rem;font-weight:bold}service-preview-view-100554.mobile .groupSetMobile input{border:1px solid #cac7c7;outline:none;width:100px;height:20px;border-radius:5px}service-preview-view-100554.mobile .phone{z-index:1;padding:0 .5rem;border:.25rem solid #404040;border-radius:1rem;display:flex;flex-direction:column;box-shadow:0 5px 3px 3px rgba(0,0,0,0.3);background:white}service-preview-view-100554.mobile .phone_mic{height:.25rem;width:4rem;margin:1rem auto;border-radius:999rem;background-color:#505050}service-preview-view-100554.mobile .phone_screen{position:relative;flex:1 0 auto;border:1px solid #505050;border-radius:5px}service-preview-view-100554.mobile .phone_screen iframe{border-radius:5px}service-preview-view-100554.mobile .phone_button{width:1.5rem;height:1.5rem;border:2px solid #505050;border-radius:50%;margin:1rem auto}service-preview-view-100554.mobile .scroll-custom::-webkit-scrollbar{width:5px}service-preview-view-100554.mobile .scroll-custom::-webkit-scrollbar-track{background:#ddd}service-preview-view-100554.mobile .scroll-custom::-webkit-scrollbar-thumb{background:#666}service-preview-view-100554.mobile .scroll-custom::scrollbar{width:2px}service-preview-view-100554.mobile .scroll-custom::scrollbar-track{background:#ddd}service-preview-view-100554.mobile .scroll-custom::scrollbar-thumb{background:#666}service-preview-view-100554.desktop{display:block;width:100%;height:100%;overflow:hidden}`);
        this.msg = messages['en'];
        this.file = undefined;
        this.models = undefined;
        this.page = '';
        this.mode = 'desktop';
        this.lang = 'en';
        this.level = '';
        this.isDsComponent = false;
        this.watch = true;
        this.stylechanged = '';
        this.actualtheme = 'Default';
        this.error = '';
        this.lastCompiledUrl = '';
        this.widthP = '300';
        this.heightP = '600';
        this.lastHTML = '';
        this.isService = false;
        this.timeShow = -1;
    }
    setEventsCollab() {
        mls.events.addListener(2, 'WidgetAction', this.onWidgetActionEvents.bind(this));
    }
    connectedCallback() {
        super.connectedCallback();
        this.setEventsCollab();
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'stylechanged') {
            if (newVal === 'true')
                this.addStyles();
            return;
        }
        super.attributeChangedCallback(name, oldVal, newVal);
    }
    render() {
        const lang = this.father && this.father.getMessageKey ? this.father.getMessageKey(messages) : 'en-us';
        this.msg = messages[lang];
        if (this.error !== '')
            return this.renderError();
        else
            return this.renderPreview();
    }
    renderError() {
        return html `<div class="error">${unsafeHTML(this.error)}</div>`;
    }
    renderPreview() {
        this.watch = this.father.watch;
        if (this.mode === 'mobile') {
            this.classList.remove('desktop');
            this.classList.add('mobile');
            return html ` 
                
                <div class="groupSetMobile">
                    <div>
                        <label>${this.msg.width}:</label>
                        <input type="number" value="300" @input="${this.changeWidthP}">
                    </div>
                    <div>
                        <label>${this.msg.height}:</label>
                        <input type="number" value="700" @input="${this.changeHeightP}">
                    </div>
                    </div> 
                <div class="phone" style="width:${this.widthP}px; height:${this.heightP}px">
                    <div class="phone_mic"></div>
                    <div class="phone_screen">
                        <iframe style="width:100%; height:100%; border:none; display:none"  src="/_100554_servicePreview" @load="${this.load}" ></iframe>
                    </div>
                    <div class="phone_button"></div>
                </div>
                
            `;
        }
        else {
            this.classList.add('desktop');
            this.classList.remove('mobile');
            return html `
            <iframe
                style="width:100%; height:100%; border:none; display:none" src="/_100554_servicePreview"
                @load="${this.load}" >
            
            </iframe>`;
        }
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level')) {
            const oldLevel = changedProperties.get('level');
            if (!oldLevel)
                return;
            this.fireChangeICA();
        }
    }
    //-------- IMPLEMENTS---------
    onWidgetActionEvents(ev) {
        if (ev.level.toString() !== this.level)
            return;
        if (!ev.desc)
            return;
        const json = JSON.parse(ev.desc);
        if (json.op !== 'SelectWidget')
            return;
        this.selectIdinPreview(json.id, json.origin);
    }
    selectIdinPreview(id, origin) {
        if (!id)
            return;
        const iframe = this.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        if (origin !== 'editor')
            return;
        const el = this.findElementsStartingWithIca(id);
        if (!el)
            return;
        const ev = new CustomEvent('click', {
            detail: {
                origin,
            }
        });
        const ov = el.overlayRef;
        if (!ov)
            return;
        ov.dispatchEvent(ev);
    }
    findElementsStartingWithIca(id) {
        if (!id)
            return undefined;
        const iframe = this.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return undefined;
        const doc = iframe.contentDocument;
        let elements = [];
        function traverseShadowRoot(element) {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                elements.push(element);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child));
                }
            }
        }
        doc.body.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item);
        });
        const newId = `ica_${id}`;
        const ret = elements.find((el) => el.id === newId);
        return ret;
    }
    fireChangeICA() {
        const iframe = this.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        this.changeLevelIca(iframe.contentDocument.body);
    }
    changeLevelIca(el) {
        const isPage = el.isPage;
        let tagEl = el.tagName.toLowerCase();
        if (tagEl.startsWith('ica-') || isPage) {
            el.setAttribute('level', this.level);
        }
        for (const i of el.children) {
            this.changeLevelIca(i);
        }
    }
    async addStyles() {
        if (!this.models || !this.models.style || !window.preview.iframe || !window.preview.iframe.contentDocument || !window.preview.iframe.contentWindow)
            return;
        const { project, shortName } = this.models.style.storFile;
        const id = convertFileNameToTag(`_${project}_${shortName}`);
        const oldStyle = window.preview.iframe.contentDocument.head.querySelector(`style[id=${id}]`);
        const newStyle = document.createElement('style');
        const newLess = await compileStyleUsingStorFile(shortName, project, this.actualtheme);
        if (newLess) {
            newStyle.id = id;
            newStyle.textContent = newLess;
            window.preview.iframe.contentDocument.head.appendChild(newStyle);
            if (oldStyle)
                oldStyle.remove();
        }
        const tokens = await getTokens({ project, shortName }, this.actualtheme);
        this.mountTokens(tokens || '');
        this.stylechanged = 'false';
    }
    load() {
        this.showLoader(true);
        const iframe = this.querySelector('iframe');
        const head = iframe.contentDocument?.querySelector('head');
        if (head) {
            const base = document.createElement('base');
            base.href = document.baseURI;
            head.appendChild(base);
        }
        this.init(iframe);
        window.preview.iframe = iframe;
        const collabConsole = this.parentElement?.querySelector('collab-console-100554');
        collabConsole.scope = iframe.contentWindow;
    }
    async init(iframe) {
        try {
            this.setDevice(iframe);
            this.setTheme(iframe);
            this.setMyFile();
            if (!this.models
                || this.models.ts?.storFile.hasError
                || this.models.style?.storFile.hasError
                || this.models.html?.storFile.hasError) {
                const trace = this.models?.ts?.compilerResults?.errors.map((err) => err.messageText).join('\n - ');
                this.error = this.msg.errorCompile + '\n' + `<div class="error-list"> - ${trace} </div>`;
                this.showLoader(false);
                this.renderError();
                return;
            }
            await this.setHTml(iframe);
            iframe.style.display = '';
            const html = iframe.contentDocument?.querySelector('html');
            if (html) {
                html.lang = this.lang;
                html.style.overflow = 'hidden';
                html.style.height = '100%';
            }
            if (iframe.contentDocument) {
                iframe.contentDocument.body.style.padding = '35px';
                iframe.contentDocument.body.style.overflowY = 'auto';
                iframe.contentDocument.body.style.overflowX = 'hidden';
                iframe.contentDocument.body.style.margin = '0';
                iframe.contentDocument.body.style.height = 'calc(100% - 70px)';
                iframe.contentDocument.body.style.width = 'calc(100% - 70px)';
            }
            this.showLoader(false);
            this.dispatchEvent(new CustomEvent('preview-loaded', {
                detail: { shortName: this.models.ts?.storFile.shortName, project: this.models.ts?.storFile.project },
                bubbles: true,
                composed: true,
            }));
        }
        catch (e) {
            this.error = e.message;
            this.showLoader(false);
        }
    }
    setTheme(iframe) {
        const isLight = this.father.light;
        const html = iframe.contentDocument?.querySelector('html');
        const meta = iframe.contentDocument?.querySelector('meta[name="color-scheme"]');
        if (!isLight && html) {
            html.setAttribute('data-theme', 'dark');
        }
        if (meta)
            meta.remove();
    }
    setDevice(iframe) {
        if (iframe.contentDocument)
            iframe.contentDocument.documentElement.setAttribute('data-device', this.mode);
    }
    setMyFile() {
        if (!this.page || this.page === '')
            throw new Error(this.msg.pageNotDefined);
        mls.actual[0].setFullName(this.page);
        const info = mls.actual[0];
        const key = mls.stor.getKeyToFiles(info.project, 2, info.path, '', '.html');
        const mkey = mls.l2.getKey({
            project: info.project,
            shortName: info.path,
        });
        if (!mls.stor.files[key])
            throw new Error(this.msg.notFoundStorfile + ': ' + key);
        if (!mls.editor.models[mkey])
            throw new Error(this.msg.notFoundStorfile + ' mfile: ' + mkey);
        this.file = mls.stor.files[key];
        this.models = mls.editor.models[mkey];
    }
    checkIfIsService() {
        if (!this.file || !this.models || !this.models.ts)
            return false;
        const txt = this.models.ts.model.getValue();
        if (txt.indexOf('extends ServiceBase') === -1)
            return false;
        return true;
    }
    async setHTml(iframe) {
        if (!iframe.contentDocument || !this.models)
            return;
        let txt = await this.getFileContent();
        this.isService = this.checkIfIsService();
        this.lastHTML = txt;
        iframe.contentDocument.body['service'] = this.father;
        let ret;
        if (this.isService && this.file) {
            const tag = convertFileNameToTag(`_${this.file.project}_${this.file.shortName}`);
        }
        iframe.contentDocument.body.innerHTML = txt;
        ret = await getDependenciesByHtml(this.models, txt, this.actualtheme, true);
        if (ret.errors.length > 0) {
            this.father.setError(`Error(${ret.errors.length}) when compiling:${ret.errors[0].error}`);
            console.log('Errors in compile:', JSON.stringify(ret.errors));
        }
        switch (mls.modePreview) {
            case 'minimum':
                this.modeMinimum(ret, iframe);
                break;
            case 'singlePage':
                this.modeSinglePage(ret, iframe);
                break;
            default:
                this.modeSinglePage(ret, iframe);
                break;
        }
    }
    async getFileContent() {
        let txt = '<h3>' + this.msg.configure + '</h3>';
        if (this.file && this.file.getValueInfo)
            txt = (await this.file.getValueInfo()).content;
        if (this.file && txt === null)
            txt = await this.file.getContent();
        return txt;
    }
    async modeSinglePage(json, iframe) {
        if (!this.file || !this.models)
            return;
        const c = new PreviewModeSinglePage(json, iframe, this.level, this.isService, this.file);
        await c.init();
    }
    async modeMinimum(json, iframe) {
        if (!this.file || !this.models)
            return;
        const c = new PreviewModeMinimum(json, iframe, this.level, this.isService, this.file, this.models);
        await c.init();
    }
    mountTokens(tokens) {
        try {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentDocument)
                return;
            this.removeOlderTokens(iframe);
            const css = tokens || '';
            if (!css)
                return;
            const style = document.createElement('style');
            style.textContent = css;
            style.id = this.getIdTokens();
            iframe.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTokens: ' + e.message);
        }
    }
    removeOlderTokens(ifr) {
        const id = this.getIdTokens();
        if (!ifr.contentDocument || !id)
            return;
        const st = ifr.contentDocument.head.querySelectorAll(`#${id}`);
        st.forEach((s) => s.remove());
    }
    getIdTokens() {
        if (!this.models || !this.models.ts)
            return 'ds_tokens';
        const { project } = this.models.ts.storFile;
        return '_' + project + '_ds_tokens';
    }
    changeWidthP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 200)
            return;
        this.widthP = el.value;
    }
    changeHeightP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 250)
            return;
        this.heightP = el.value;
    }
    showLoader(show) {
        clearTimeout(this.timeShow);
        this.timeShow = setTimeout(() => {
            if (!this.father)
                return;
            this.father.loading = show;
        }, 200);
    }
    cleanTree() {
        let ret = '';
        const iframe = this.querySelector('iframe');
        if (!iframe)
            return '';
        const div = document.createElement('div');
        const divRet = document.createElement('div');
        const body = iframe.contentDocument?.body;
        if (!body)
            return ret;
        this.cleanTree2(div, body);
        this.cleanTree3(divRet, div);
        return divRet.innerHTML;
    }
    cleanTree2(father, element) {
        const tagname = element.tagName.toLowerCase();
        if (tagname.startsWith('ica-')) {
            let children = [...element.children];
            for (const child of children) {
                this.cleanTree2(father, child);
            }
        }
        else {
            const clone = element.cloneNode(false);
            father.appendChild(clone);
            let children = [];
            if (element.shadowRoot) {
                children = [...element.shadowRoot.children];
            }
            else {
                children = [...element.children];
            }
            for (const child of children) {
                this.cleanTree2(clone, child);
            }
        }
        return father;
    }
    cleanTree3(father, element) {
        let children = [...element.children];
        for (const child of children) {
            const tagname = child.tagName.toLowerCase();
            if (tagname.indexOf('-') > 0) {
                const clone = child.cloneNode(false);
                father.appendChild(clone);
                this.cleanTree3(clone, child);
            }
            else {
                this.cleanTree3(father, child);
            }
        }
    }
};
__decorate([
    property()
], ServicePreviewView.prototype, "father", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "page", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "mode", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "lang", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "level", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "isDsComponent", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "watch", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "stylechanged", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "actualtheme", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "error", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "lastCompiledUrl", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "widthP", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "heightP", void 0);
ServicePreviewView = __decorate([
    customElement('service-preview-view-100554')
], ServicePreviewView);
export { ServicePreviewView };
