/// <mls shortName="configDsDefaultComponent" project="100554" enhancement="_blank" groupName="other" />
import { Common } from './_100554_configDsDefaultCommon';
import { Token } from './_100554_configDsDefaultTokens2';
import { Css } from './_100554_configDsDefaultCss';
import { Example } from './_100554_configDsDefaultExample';
import { Style } from './_100554_configDsDefaultStyle';
import { PreCompileLess } from './_100554_configDsDefaultPreCompileLess';
export class Component {
    constructor(dsIO, ds) {
        this.list = {};
        this.add = (widget) => this._addComponent(widget);
        this.update = (name, widget) => this._updateComponent(name, widget);
        this.remove = (componentName) => this._removeComponent(componentName);
        this.getCSS = (componentName, theme) => this._getComponentCSS(componentName, theme);
        this.getGuidelinesIO = (componentName) => this._getGuidelinesIO(componentName);
        this.setGuidelinesIO = (componentName, content) => this._setGuidelinesIO(componentName, content);
        this.getStylesLess = (componentName, theme) => this._getComponentStylesLess(componentName, theme);
        this.find = (componentName) => this._find(componentName);
        this.ds = ds;
        this._ds = dsIO;
        this.methods = new Common(ds, dsIO);
        this.tokens = new Token(dsIO, ds);
        this.css = new Css(dsIO, ds);
        this.prepareComponents();
        this.examples = new Example(this._ds, this.ds, this);
        this.styles = new Style(this._ds, this.ds, this);
    }
    prepareComponents() {
        this.list = {};
        this.ds.components.items.forEach((comp) => {
            const newComp = { ...comp };
            this.list[comp.name] = newComp;
        });
    }
    _find(componentName) {
        return this.list[componentName];
    }
    async _addComponent(component) {
        const componentByName = this.find(component.name);
        if (componentByName)
            throw new Error(`component: ${component.name} already exists`);
        this.list[component.name] = component;
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on add component:' + err.message));
        }
    }
    async _updateComponent(componentName, widget) {
        const componentByName = this.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        if (componentByName.name !== widget.name)
            throw new Error(`component: ${componentByName.name} cannot change name`);
        componentByName.tags = widget.tags;
        componentByName.docPath = widget.docPath;
        componentByName.l4MarketingRef = widget.l4MarketingRef;
        componentByName.group = widget.group;
        componentByName.tags = widget.tags;
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on add component:' + err.message));
        }
    }
    async _removeComponent(componentName) {
        const componentByName = this.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        const { examples, styles } = componentByName;
        const promises = [];
        for (const ex of examples) {
            if (!ex.reference)
                promises.push(ex.setJsonPExampleIO(null));
        }
        for (const st of styles) {
            if (!st.reference)
                promises.push(st.setStyleLessIO(null));
        }
        await Promise.all(promises);
        delete this.list[componentName];
        try {
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on add component:' + err.message));
        }
    }
    async _getComponentStylesLess(componentName, theme) {
        const componentByName = this.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        const preCompileLess = new PreCompileLess();
        const promisesComponentsStylesLess = componentByName.styles.map(async (st) => st.getStyleLessIO());
        const resultsComponentsStylesLess = await Promise.all(promisesComponentsStylesLess);
        const allCss = resultsComponentsStylesLess.join('\n');
        const tokens = await this.tokens.getTokensLess(theme);
        const res = await preCompileLess.execute(allCss, tokens, theme, this.ds.tokens.items, ':root', false);
        return res;
    }
    async _getComponentCSS(componentName, theme) {
        const componentByName = this.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        // const tokens = await this.tokens.getTokensLess();
        const less = await this._getComponentStylesLess(componentName, theme);
        const globalcss = await this.css.getStylesInLess(theme);
        const allLess = [globalcss, less].join('\n');
        try {
            const preCompileLess = new PreCompileLess();
            const compiledCss = await preCompileLess.compileLess(allLess);
            return compiledCss;
        }
        catch (err) {
            throw new Error(`Error on compile Less on component: ${componentName} : ${err.message}`);
        }
    }
    async _setGuidelinesIO(componentName, content) {
        const componentByName = this.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        let guidelinesRef = componentByName.l4MarketingRef;
        const fullpath = this.methods.getDsComponentFilePath(componentName);
        if (!guidelinesRef) {
            const guidelineName = `${componentByName.name}_guidelines`;
            componentByName.l4MarketingRef = guidelineName;
            guidelinesRef = guidelineName;
            await this.methods.createNewFile(guidelinesRef, fullpath, 'html', content);
            await this.methods.setContentFileDsMain();
            return;
        }
        await this.methods.setContentFileDsMain();
        await this.methods.setContentFile(guidelinesRef, 'html', fullpath, content);
    }
    async _getGuidelinesIO(componentName) {
        const componentByName = this.find(componentName);
        if (!componentByName)
            throw new Error(`component: ${componentName} dont exists`);
        const fullpath = this.methods.getDsComponentFilePath(componentName);
        const guidelinesRef = componentByName.l4MarketingRef;
        if (!guidelinesRef)
            return '';
        return await this.methods.getContentFile(guidelinesRef, 'html', fullpath);
    }
}
