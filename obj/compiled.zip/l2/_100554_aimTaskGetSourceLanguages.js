/// <mls shortName="aimTaskGetSourceLanguages" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { AimTaskBase } from "./_100554_aimTaskBase";
import { getDataInternationalization } from './_100554_aimTaskGetSourceLanguageTypescript';
import { checkAttributteHasVariation } from './_100554_icaBaseDescription';
let AimTaskGetSourceLanguages = class AimTaskGetSourceLanguages extends AimTaskBase {
    onInitializing() {
        this.getSource();
    }
    getSource() {
        if (!this.taskRoot.args) {
            this.taskChild.trace.push(new Date().toISOString() + ': taskroot args is missing');
            this.notifyCompleteByStatus('error', '');
            return;
        }
        const args = JSON.parse(this.taskRoot.args);
        this.prepareInfoFile(args).then((ret) => {
            const result = ret;
            this.notifyCompleteByStatus('ok', JSON.stringify(result));
        }).catch((e) => {
            this.notifyCompleteByStatus('error', e);
        });
    }
    async prepareInfoFile(args) {
        const fileName = `_${args.project}_${args.fileName}`;
        const infoFile = {
            fileName,
            checkHtml: true,
            checkTs: true,
            languages: args.languages,
            html: '',
            detailsi18n: undefined,
            attributesHTML: [],
            attributesHTMLWithLanguages: [],
            htmlTags: [],
            onlyLanguageDontConfigured: args.onlyLanguageDontConfigured
        };
        const models = mls.editor.models[fileName];
        if (!models || !models.ts)
            infoFile.checkTs = false;
        const valueTs = models.ts?.model.getValue() || '';
        if (!valueTs)
            infoFile.checkTs = false;
        const details = getDataInternationalization(valueTs);
        if (!details.internationalization || !details.internationalization.source || details.internationalization.languages.length === 0)
            infoFile.checkTs = false;
        if (args.onlyLanguageDontConfigured && this.allElementsPresent(args.languages.map((lang) => lang.code), details.internationalization?.languages || []))
            infoFile.checkTs = false;
        infoFile.detailsi18n = details.internationalization;
        const keyToFileHTML = mls.stor.getKeyToFiles(args.project, 2, args.fileName, '', '.html');
        const fileHTML = mls.stor.files[keyToFileHTML];
        if (!fileHTML)
            infoFile.checkHtml = false;
        else {
            const valueHTML = await fileHTML.getContent();
            if (typeof valueHTML !== 'string') {
                infoFile.checkHtml = false;
                return infoFile;
            }
            const rc = this.prepareHTMLInfo(valueHTML);
            if (rc.components.length === 0)
                infoFile.checkHtml = false;
            infoFile.htmlTags = rc.components;
            infoFile.attributesHTML = rc.attrs;
            const preparedHtml = this.parseHtmlString(valueHTML, infoFile.htmlTags, infoFile.attributesHTML, infoFile.languages);
            infoFile.html = preparedHtml.text;
            infoFile.attributesHTMLWithLanguages = preparedHtml.attributesHTMLWithLanguages;
        }
        return infoFile;
    }
    prepareHTMLInfo(valueHTML) {
        const rc = {
            attrs: [],
            components: []
        };
        const data = this.analyzeHTML(valueHTML);
        data.attrs.forEach((attr) => {
            const hasVariation = checkAttributteHasVariation(attr);
            if (hasVariation)
                rc.attrs.push(attr);
        });
        rc.components = data.components;
        return rc;
    }
    allElementsPresent(arrayA, arrayB) {
        for (const element of arrayA) {
            if (!arrayB.includes(element)) {
                return false;
            }
        }
        return true;
    }
    analyzeHTML(htmlString) {
        const tempElement = document.createElement('div');
        tempElement.innerHTML = htmlString;
        const data = {
            components: [],
            attrs: []
        };
        function traverseElement(element) {
            if (element.tagName.includes('-')) {
                const tagName = element.tagName.toLowerCase();
                if (!data.components.includes(tagName)) {
                    data.components.push(tagName);
                }
                const attributes = element.getAttributeNames();
                attributes.forEach(attribute => {
                    if (!data.attrs.includes(attribute)) {
                        data.attrs.push(attribute);
                    }
                });
            }
            if (element.children.length > 0) {
                for (let i = 0; i < element.children.length; i++) {
                    traverseElement(element.children[i]);
                }
            }
        }
        traverseElement(tempElement);
        return data;
    }
    parseHtmlString(htmlString, tagsToProcess, propsToProcess, languages) {
        const parser = new DOMParser();
        const doc = parser.parseFromString(htmlString, 'text/html');
        const elements = doc.body.children;
        const attributesHTMLWithLanguages = new Set();
        function containsAnyAttributes(element, attrs) {
            for (const attr of attrs) {
                if (element.hasAttribute(attr))
                    return true;
            }
            return false;
        }
        function addAttributesForEachLanguage(element, attrs, languages) {
            for (const attr of attrs) {
                if (element.hasAttribute(attr)) {
                    for (const lang of languages) {
                        const attrWithLanguage = `${attr}-${lang.code}`;
                        const elementAlreadyHasAttr = element.hasAttribute(attrWithLanguage);
                        if (!elementAlreadyHasAttr) {
                            element.setAttribute(attrWithLanguage, '');
                            attributesHTMLWithLanguages.add(attrWithLanguage);
                        }
                    }
                }
            }
        }
        function traverse(element) {
            const tagName = element.tagName.toLowerCase();
            const elementContainsAnyAttributes = containsAnyAttributes(element, propsToProcess);
            const needProcessTag = tagsToProcess.includes(tagName);
            if (needProcessTag && elementContainsAnyAttributes) {
                addAttributesForEachLanguage(element, propsToProcess, languages);
            }
            if (element.children.length > 0) {
                for (let i = 0; i < element.children.length; i++) {
                    const child = element.children[i];
                    traverse(child);
                }
            }
        }
        function decodeHTMLEntities(str) {
            return str.replace(/&quot;/g, '"').replace(/&apos;/g, "'");
        }
        for (let i = 0; i < elements.length; i++) {
            traverse(elements[i]);
        }
        return { text: doc.body.innerHTML, attributesHTMLWithLanguages: Array.from(attributesHTMLWithLanguages) };
    }
};
AimTaskGetSourceLanguages = __decorate([
    customElement('aim-task-get-source-languages-100554')
], AimTaskGetSourceLanguages);
export { AimTaskGetSourceLanguages };
