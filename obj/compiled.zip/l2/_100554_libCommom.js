/// <mls shortName="libCommom" project="100554" enhancement="_blank" groupName="other" />
import { getMessageKey } from "./_100554_collabLitElement";
import { getAllWebComponentsInSource } from './_100554_libCompile';
import { convertTagToFileName, convertFileNameToTag } from './_100554_utilsLit';
/// **collab_i18n_start**
const message_pt = {
    updatedToday: 'atualizado hoje',
    updated: 'atualizado',
    on: 'em',
    days: 'dias',
    day: 'dia',
    ago: 'atrás',
    jan: 'Jan',
    feb: 'Fev',
    mar: 'Mar',
    apr: 'Abr',
    may: 'Mai',
    june: 'Jun',
    july: 'Jul',
    aug: 'Ago',
    sept: 'Set',
    oct: 'Out',
    nov: 'Nov',
    dec: 'Dez',
};
const message_en = {
    updatedToday: 'updated today',
    updated: 'updated',
    on: 'on',
    days: 'days',
    day: 'day',
    ago: 'ago',
    jan: 'Jan',
    feb: 'Feb',
    mar: 'Mar',
    apr: 'Apr',
    may: 'May',
    june: 'June',
    july: 'July',
    aug: 'Aug',
    sept: 'Sept',
    oct: 'Oct',
    nov: 'Nov',
    dec: 'Dec',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
const msg = messages[lang];
export function getMyKeysBranch(project) {
    try {
        if (!mls.stor.projects[project])
            throw new Error('Not found projectInfo:' + project);
        const obj = mls.l5.getProjectDetails(project);
        if (!obj || !obj.value)
            throw new Error('Error getProjectDetails in:' + project);
        const json = JSON.parse(obj.value);
        if (!json)
            throw new Error('Error getProjectDetails .value json in:' + project);
        let info = '';
        if (!json.projectURL && json.l5_actionPrjSettings)
            info = json.l5_actionPrjSettings.projectURL;
        else if (json.projectURL)
            info = json.projectURL;
        else
            throw new Error('Error project info:' + project);
        if (info.endsWith('/'))
            info = info.substring(0, info.length - 1);
        const array = info.split('/');
        if (array.length < 3)
            throw new Error('Insufficient information to progress');
        return { branch: array[array.length - 3], owner: array[array.length - 2], repo: array[array.length - 1] };
    }
    catch (e) {
        throw new Error('Error get info branch: ' + e.message);
    }
}
export function generateCompactTimestamp() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Month is 0-based, so +1
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    return `${year}${month}${day}${hours}${minutes}${seconds}${milliseconds}`;
}
export function getDateFormated(dt) {
    let lastUpdated;
    const dateToday = new Date();
    const dtLastWrite = new Date(dt);
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    // a and b are javascript Date objects
    function dateDiffInDays(a, b) {
        // Discard the time and time-zone information.
        const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
        const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
        return Math.floor((utc2 - utc1) / _MS_PER_DAY);
    }
    const diffDays = dateDiffInDays(dtLastWrite, dateToday);
    const moreThanTwoDays = diffDays > 1;
    if (diffDays === 0) {
        lastUpdated = msg.updatedToday;
    }
    else if (diffDays < 30) {
        lastUpdated = `${msg.updated} ${diffDays} ${moreThanTwoDays ? msg.days : msg.day} ${msg.ago}`;
    }
    else {
        const lastWriteYear = dtLastWrite.getFullYear();
        const lastWriteMounth = dtLastWrite.getMonth();
        const lastWriteDay = dtLastWrite.getDate();
        const mounthFilter = {
            0: msg.jan,
            1: msg.feb,
            2: msg.mar,
            3: msg.apr,
            4: msg.may,
            5: msg.june,
            6: msg.july,
            7: msg.aug,
            8: msg.sept,
            9: msg.oct,
            10: msg.nov,
            11: msg.dec,
        };
        lastUpdated = `${msg.updated} ${msg.on} ${lastWriteYear}, ${lastWriteDay} ${mounthFilter[lastWriteMounth]} `;
    }
    return lastUpdated;
}
export function escapeHTML(str) {
    return str
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}
export function openService(service, position, level, args) {
    let page = document.querySelector('collab-page');
    if (!page)
        return;
    const toolbar = page.querySelector(`collab-nav-2[toolbarposition="${position}"]`);
    if (!toolbar)
        return;
    if (mls.actualLevel !== level) {
        toolbar.state[level][position] = service;
        selectLevel(level);
        return;
    }
    const item = toolbar.querySelector(`collab-nav-2-item[data-service="${service}"]`);
    const itemNav3Content = page.querySelector(`collab-nav-3-service[data-service="${service}"]`);
    if (itemNav3Content && args) {
        const tagService = convertFileNameToTag(service);
        const serviceItem = itemNav3Content.querySelector(tagService);
        if (serviceItem) {
            Object.entries(args).forEach((arg) => {
                const [key, value] = arg;
                serviceItem.setAttribute(key, value);
            });
        }
    }
    if (item)
        item.click();
    return;
}
export function selectLevel(level) {
    const page = document.querySelector('collab-page');
    const nav = page?.querySelector('collab-nav-1');
    const objIndex = {
        0: 7,
        1: 6,
        2: 5,
        3: 4,
        4: 3,
        5: 2,
        6: 1,
        7: 0,
    };
    if (!nav)
        return;
    nav.setAttribute('tabindexactive', objIndex[level]);
}
export async function forceServiceInstance(level, service) {
    const page = document.querySelector('collab-page');
    const nav = page?.querySelector('collab-nav-1');
    if (!nav)
        return;
    await nav.forceInstanceIfNeed([`${service};${level}`]);
}
export async function loadFileHTMLInContainer(el, shortName, project) {
    const keyFile = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
    const storFile = mls.stor.files[keyFile];
    if (!storFile)
        throw new Error('File not founded');
    const content = await storFile.getContent();
    if (!content || typeof content !== 'string')
        throw new Error('File html invalid');
    el.innerHTML = '';
    const allWcs = getAllWebComponentsInSource(content);
    el.innerHTML = content;
    allWcs.forEach((wc) => {
        const fileName = convertTagToFileName(wc);
        const script = document.createElement('script');
        script.type = 'module';
        script.id = fileName;
        script.src = (`/${fileName}`);
        el.appendChild(script);
    });
}
export function convertColorToHex(color) {
    const element = document.createElement('div');
    element.style.color = color.trim();
    document.body.appendChild(element);
    const computedColor = window.getComputedStyle(element).color;
    document.body.removeChild(element);
    if (!computedColor || !computedColor.startsWith('rgb')) {
        throw new Error(`Invalid color value: ${color}`);
    }
    const match = computedColor.match(/\d+/g);
    if (!match)
        return undefined;
    const rgbMatch = match.map(Number);
    const [r, g, b] = rgbMatch;
    return ('#' +
        [r, g, b]
            .map((val) => val.toString(16).padStart(2, '0'))
            .join('')
            .toUpperCase());
}
export async function getEnhancementName(file) {
    const key = mls.l2.getKey({ project: file.project, shortName: file.shortName });
    const mmodel = mls.editor.models[key];
    if (!mmodel || !mmodel.ts)
        throw new Error('model invalid');
    if (!mmodel.ts.compilerResults)
        throw new Error('model ts not compiled yet');
    const enhacementName = mmodel.ts.compilerResults.tripleSlashMLS?.variables.enhancement;
    if (!enhacementName)
        throw new Error('enhacementName not valid');
    return enhacementName;
}
export async function getLocalStorageTest() {
    const str = localStorage.getItem('collab_interface_test');
    if (!str)
        return undefined;
    try {
        const data = JSON.parse(str);
        return data;
    }
    catch (err) {
        throw new Error('Error on parse test data');
    }
}
export async function saveLocalStorageTest(data) {
    localStorage.setItem('collab_interface_test', JSON.stringify(data));
}
export async function addTest(key, script) {
    if (!script)
        throw new Error('script missing');
    let data = await getLocalStorageTest();
    if (!data)
        data = {};
    const dataByKey = data[key] || '';
    const _tempDiv = document.createElement('div');
    _tempDiv.innerHTML = script;
    const newTest = _tempDiv.querySelector('collab-test-script');
    if (!newTest)
        throw new Error('invalid script');
    const title = newTest.getAttribute('title');
    if (!title)
        throw new Error('title cannot be blank');
    const htmlDecoded = decodeURIComponent(atob(dataByKey));
    if (dataByKey) {
        _tempDiv.innerHTML = htmlDecoded;
        const hasTest = _tempDiv.querySelector(`collab-test-script[title="${title}"]`);
        if (hasTest)
            throw new Error(`Test with title: ${title} already exists`);
    }
    const finalTest = `${htmlDecoded ? htmlDecoded + '\n\n' : ''}${script}`;
    data[key] = btoa(encodeURIComponent(finalTest));
    await saveLocalStorageTest(data);
}
export async function getTests(key) {
    let rc = [];
    try {
        let data = await getLocalStorageTest();
        if (!data)
            return rc;
        const dataByKey = data[key] || '';
        const _tempDiv = document.createElement('div');
        _tempDiv.innerHTML = decodeURIComponent(atob(dataByKey));
        const allTest = Array.from(_tempDiv.querySelectorAll('collab-test-script'));
        rc = allTest.map((test) => {
            return {
                title: test.getAttribute('title') || '',
                description: test.getAttribute('description') || '',
                script: test.outerHTML
            };
        });
        return rc;
    }
    catch (err) {
        throw new Error(err);
    }
}
export async function deleteTest(key, title) {
    try {
        let data = await getLocalStorageTest();
        if (!data)
            return;
        let dataByKey = data[key] || '';
        const _tempDiv = document.createElement('div');
        _tempDiv.innerHTML = decodeURIComponent(atob(dataByKey));
        ;
        const itemToRemove = _tempDiv.querySelector(`collab-test-script[title="${title}"]`);
        if (itemToRemove)
            itemToRemove.remove();
        data[key] = btoa(encodeURIComponent(_tempDiv.innerHTML));
        await saveLocalStorageTest(data);
    }
    catch (err) {
        throw new Error(err);
    }
}
export async function updateTest(key, oldTitle, newScript) {
    try {
        let data = await getLocalStorageTest();
        if (!data)
            return;
        let dataByKey = data[key] || '';
        const _tempDiv = document.createElement('div');
        const _tempDiv2 = document.createElement('div');
        _tempDiv.innerHTML = decodeURIComponent(atob(dataByKey));
        _tempDiv2.innerHTML = newScript;
        const newItemUpdated = _tempDiv2.querySelector('collab-test-script');
        if (!newItemUpdated)
            throw new Error('invalid new script');
        const allScripts = Array.from(_tempDiv.querySelectorAll('collab-test-script'));
        for (let script of allScripts) {
            const title = script.getAttribute('title');
            if (title !== oldTitle)
                continue;
            const newTitle = newItemUpdated.getAttribute('title');
            const same = allScripts.filter((item) => item.getAttribute('title') === newTitle && item !== script);
            if (same.length > 0)
                throw new Error(`The title: ${newTitle} is already in use`);
            script.insertAdjacentElement("afterend", newItemUpdated);
            script.remove();
            break;
        }
        data[key] = btoa(encodeURIComponent(_tempDiv.innerHTML));
        await saveLocalStorageTest(data);
    }
    catch (err) {
        throw new Error(err);
    }
}
