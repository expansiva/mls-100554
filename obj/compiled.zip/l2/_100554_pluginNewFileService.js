/// <mls shortName="pluginNewFileService" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { IcaLitElement } from './_100554_icaLitElement';
import { getMessageKey } from "./_100554_collabLitElement";
import { propertyDataSource } from './_100554_icaLitElement';
import { createNewFile, changeTagName, changeClassName, changeWidget } from "./_100554_pluginNewFileBase";
import './_100554_wcCode';
/// **collab_i18n_start**
const message_pt = {
    title: 'Criar um service',
    description: "Criar um service, que será utilizado no sistema collab.\nUm service no collab.codes, permite a criação de menus após selecionar o level, fica no nav2, com ícones.\nApós criar o arquivo use a inteligência artificial para preparar o service.",
    project: "Projeto",
    shortName: "Nome",
    header: "Criar um service",
    btnCreate: 'Criar arquivo',
    loading: 'Criando arquivo...',
    error: 'Nome do arquivo em branco ou invalido'
};
const message_en = {
    title: 'Create a service in Lit',
    description: "Create a service to be used in the Collab system.\nA service in collab.codes allows creating menus after selecting the level, placed in nav2 with icons.\nAfter creating the file, use artificial intelligence to prepare the service.",
    project: "Project",
    shortName: "ShortName",
    header: "Create a service in Lit",
    btnCreate: 'Create file',
    loading: 'Creating File...',
    error: 'Blank or invalid file name'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
let msg = messages[lang];
export const details = {
    title: msg.title,
    description: msg.description,
    tags: ["lit", "internal", "service"],
};
let PluginNewFileService = class PluginNewFileService extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file-service-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-new-file-service-100554 wc-code-100554{font-size:var(--font-size-12)}plugin-new-file-service-100554 button{background-color:var(--active-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#fff;cursor:pointer}plugin-new-file-service-100554 button:hover{background-color:var(--active-color-hover)}`);
        this.position = 'left';
        this.loading = false;
        this.service = this.closest('service-detail-100554');
        this.template = `
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase, IService, IToolbarContent, IServiceMenu } from './_100554_serviceBase';

@customElement('[tagName]')
export class [className] extends ServiceBase {
    public details: IService = {
        icon: '&#xf15b',
        state: 'foreground',
        position: 'right',
        tooltip: 'Service Example',
        visible: true,
        widget: '[widgetName]',
        level: [5]
    }

    public onClickMain(op: string): void {
        if (this.menu.setMode) this.menu.setMode('initial');
    }

    public menu: IServiceMenu = {
        title: 'Example',
        main: {},
        tools: {},
        tabs: undefined,
        onClickMain: this.onClickMain.bind(this),
    }

    onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null) {

    }


    @property() 
    name: string = 'Somebody';

    render() {
        return html\`<p> Hello, \${ this.name } !</p>\`;
    }
}`;
        this.enhancement = `_100554_enhancementLitService`;
        this.groupName = `other`;
    }
    getTemplate() {
        let newExample = this.template;
        if (this.shortName && this.project) {
            newExample = changeTagName(newExample, convertFileNameToTag(`_${this.project}_${this.shortName}`));
            newExample = changeClassName(newExample, this.project, this.shortName);
            newExample = changeWidget(newExample, this.project, this.shortName);
        }
        return `/// <mls shortName="${this.shortName}" project="${this.project}" enhancement="${this.enhancement}" groupName="${this.groupName}" />\n${newExample}\n`;
        ;
    }
    async handleAddFile() {
        if (!this.project || !this.shortName) {
            this.service.setError(msg.error);
            return;
        }
        ;
        this.loading = true;
        try {
            await createNewFile({
                project: this.project,
                position: this.position,
                shortName: this.shortName,
                enhancement: this.enhancement,
                sourceTS: this.getTemplate(),
                openPreview: true
            });
        }
        catch (e) {
            this.loading = false;
        }
    }
    render() {
        return html `
            ${this.loading ?
            html `<div>${msg.loading}</div>`
            :
                html `   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>

                    <wc-code-100554 language="typescript" text="${this.getTemplate()}"></wc-code-100554>
                
                </div>`}
        `;
    }
};
__decorate([
    propertyDataSource()
], PluginNewFileService.prototype, "shortName", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFileService.prototype, "project", void 0);
__decorate([
    property()
], PluginNewFileService.prototype, "position", void 0);
__decorate([
    property()
], PluginNewFileService.prototype, "loading", void 0);
PluginNewFileService = __decorate([
    customElement('plugin-new-file-service-100554')
], PluginNewFileService);
export { PluginNewFileService };
