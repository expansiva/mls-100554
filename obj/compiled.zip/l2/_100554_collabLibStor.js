/// <mls shortName="collabLibStor" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { convertFileNameToTag } from './_100554_utilsLit';
import { createModel, createAllModels } from './_100554_collabLibModel';
export async function createStorFile(req, needCreateModel) {
    const params = {
        project: req.project,
        level: req.level,
        shortName: req.shortName,
        extension: req.extension,
        versionRef: '0',
        folder: req.folder
    };
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[createStorFile] Invalid storFile');
    file.status = req.status ?? 'new';
    const fileInfo = {
        content: req.source,
        contentType: 'string'
    };
    if (req.fileInfo) {
        fileInfo.originalFolder = req.fileInfo.originalFolder;
        fileInfo.originalProject = req.fileInfo.originalProject;
        fileInfo.originalShortName = req.fileInfo.originalShortName;
    }
    await mls.stor.localStor.setContent(file, fileInfo);
    if (needCreateModel)
        await createModel(file);
    return file;
}
export async function createAllFiles(req, needCreateModel = true) {
    const { folder, shortName, project } = req;
    const template = `/// <mls shortName="${req.shortName}" project="${req.project}" enhancement="${req.enhancement}" folder="${req.folder}" />\n\n// typescript new file\n`;
    const templateHTML = `<h1>${req.shortName}</h1>`;
    const templateLess = `/// <mls shortName="${req.shortName}" project="${req.project}" enhancement="enhancementStyle" folder="${req.folder}" />\n\n${convertFileNameToTag({ project, shortName, folder })} {\n\n// Here your less\n\n }`;
    const templateTest = `/// <mls shortName="${req.shortName}" project="${req.project}" enhancement="_blank" folder="${req.folder}" />\n\n import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST';\n export const integrations: ICANIntegration[] = [];\n export const tests: ICANTest[] = [];`;
    const templateDefs = `/// <mls shortName="${req.shortName}" project="${req.project}" enhancement="_blank" folder="${req.folder}" />\n\n`;
    const newTSSource = req.tsSource || template;
    const newHTMLSource = req.htmlSource || templateHTML;
    const newLessSource = req.lessSource || templateLess;
    const newTestSource = req.testSource || templateTest;
    const newDefsSource = req.defsSource || templateDefs;
    const param = {
        project: req.project,
        shortName: req.shortName,
        folder: req.folder,
        level: req.level,
        extension: '.ts',
        source: newTSSource,
        status: 'new'
    };
    const ret = {
        ts: await safeCreate(param, false)
    };
    ret.html = await safeCreate({ ...param, extension: '.html', source: newHTMLSource }, false);
    ret.less = await safeCreate({ ...param, extension: '.less', source: newLessSource }, false);
    ret.test = await safeCreate({ ...param, extension: '.test.ts', source: newTestSource }, false);
    ret.def = await safeCreate({ ...param, extension: '.defs.ts', source: newDefsSource }, false);
    if (needCreateModel && ret.ts && !(ret.ts instanceof Error))
        await createAllModels(ret.ts);
    return ret;
}
export async function deleteFile(storFile) {
    if (storFile.status === 'new') {
        await deleteFileSystem(storFile);
        return;
    }
    storFile.status = 'deleted';
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder);
    if (storFile.getValueInfo) {
        let valueInfo = mls.editor.models[keyToModel] ? await storFile.getValueInfo() : {};
        if (!valueInfo.content) {
            const src = await storFile.getContent();
            valueInfo = {
                content: src,
                contentType: 'string',
                originalShortName: storFile.shortName,
                originalProject: storFile.project,
                originalCRC: mls.common.crc.crc32(src).toString(16)
            };
        }
        await mls.stor.localStor.setContent(storFile, valueInfo);
    }
}
export async function deleteAllFiles(storFile) {
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        await deleteFile(mls.stor.files[key]);
    }
}
export async function renameFile(storFile, newProject, newShortName) {
    let source = await storFile.getContent();
    if (!source)
        throw new Error('[renameFile] Impossible rename this file:' + storFile.shortName);
    source = replaceTripleslashAndTag(storFile, newProject, newShortName, storFile.folder, source);
    const param = {
        shortName: newShortName,
        project: newProject,
        folder: storFile.folder,
        level: storFile.level,
        source: source,
        extension: storFile.extension,
        status: storFile.status === 'new' ? 'new' : 'renamed',
        fileInfo: {
            originalFolder: storFile.folder,
            originalProject: storFile.project,
            originalShortName: storFile.shortName
        }
    };
    const file = await createStorFile(param, true);
    await deleteFileSystem(storFile);
    return file;
}
export async function renameAllFiles(storFile, newProject, newShortName) {
    const ret = {};
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        const prop = mapExt[ext];
        ret[prop] = await safeRename(mls.stor.files[key], newProject, newShortName);
    }
    return ret;
}
export async function cloneFile(storFile, newProject, newShortName) {
    let source = await storFile.getContent();
    if (!source)
        throw new Error('[cloneFile] Impossible rename this file:' + storFile.shortName);
    source = replaceTripleslashAndTag(storFile, newProject, newShortName, storFile.folder, source);
    const param = {
        shortName: newShortName,
        project: newProject,
        folder: storFile.folder,
        level: storFile.level,
        source: source,
        extension: storFile.extension,
        status: 'new'
    };
    const file = await createStorFile(param, true);
    return file;
}
export async function cloneAllFiles(storFile, newProject, newShortName) {
    const ret = {};
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        const prop = mapExt[ext];
        ret[prop] = await safeClone(mls.stor.files[key], newProject, newShortName);
    }
    return ret;
}
export async function undoFile(storFile, removeProject = true) {
    if (storFile.status === 'nochange' && !storFile.inLocalStorage) {
        return;
    }
    if (storFile.status === 'new') {
        await deleteFileSystem(storFile);
        return;
    }
    if (storFile.status === 'deleted') {
        storFile.status = 'nochange';
    }
    if (storFile.status === 'renamed') {
        await undoFileRenamed(storFile);
        return;
    }
    if (storFile.status === 'changed') {
        storFile.status = 'nochange';
        storFile.inLocalStorage = false;
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        if (storFile.isLocalVersionOutdated && storFile.newVersionRefIfOutdated) {
            storFile.versionRef = storFile.newVersionRefIfOutdated;
            storFile.isLocalVersionOutdated = false;
            storFile.newVersionRefIfOutdated = undefined;
        }
    }
    if (storFile.inLocalStorage) {
        storFile.inLocalStorage = false;
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
    }
    storFile.getValueInfo = undefined;
    const keyToModel = mls.editor.getKeyModel(storFile.project, storFile.shortName, storFile.folder);
    if (!mls.editor.models[keyToModel])
        return;
    const prop = mapExtUndo[storFile.extension];
    if (prop && mls.editor.models[keyToModel]?.[prop]) {
        mls.editor.models[keyToModel][prop]?.model.dispose();
        delete mls.editor.models[keyToModel][prop];
    }
    if (removeProject && storFile)
        await mls.stor.localDB.removePrjInfo(storFile.project);
}
export async function undoAllFiles(storFile) {
    for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts']) {
        const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
        if (!mls.stor.files[key])
            continue;
        await undoFile(mls.stor.files[key], false);
    }
    await mls.stor.localDB.removePrjInfo(storFile.project);
}
function isNewNameValid(newShortName) {
    if (newShortName.length === 0 || newShortName.length > 255)
        return false;
    const invalidCharacters = /[_\/{}\t\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
    return (!invalidCharacters.test(newShortName));
}
//---------AUXILIARY FUNCTIONS AND DEFINITIONS-------------
const mapExt = {
    '.ts': 'ts',
    '.html': 'html',
    '.less': 'less',
    '.test.ts': 'test',
    '.defs.ts': 'def'
};
const mapExtUndo = {
    '.ts': 'ts',
    '.html': 'html',
    '.less': 'style',
    '.test.ts': 'test',
    '.defs.ts': 'defs'
};
function replaceTripleslashAndTag(storFile, newProject, newShortName, newFolder, src) {
    const { folder, project, shortName } = storFile;
    const oldTag = convertFileNameToTag({ folder, project, shortName });
    const newTag = convertFileNameToTag({ folder: newFolder, project: newProject, shortName: newShortName });
    const regex = new RegExp(oldTag.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    src = src.replace(/shortName="[^"]*"/, `shortName="${newShortName}"`).replace(/project="[^"]*"/, `project="${newProject}"`);
    return src.replace(regex, newTag);
}
async function deleteFileSystem(storFile) {
    await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
    mls.editor.deleteModels(storFile.project, storFile.shortName, storFile.folder, true);
    const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
    delete mls.stor.files[keyFiles];
}
async function safeCreate(param, createMdl) {
    try {
        return await createStorFile(param, createMdl);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function safeRename(storFile, newProject, newShortName) {
    try {
        return await renameFile(storFile, newProject, newShortName);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function safeClone(storFile, newProject, newShortName) {
    try {
        return await cloneFile(storFile, newProject, newShortName);
    }
    catch (err) {
        return err instanceof Error ? err : new Error(String(err));
    }
}
async function undoFileRenamed(storFile) {
    const info = storFile.getValueInfo ? await storFile.getValueInfo() : {};
    if (!info.originalProject || !info.originalShortName)
        throw new Error('[undoFileRenamed] Not found info base for rename');
    const originalKey = mls.stor.getKeyToFiles(info.originalProject, storFile.level, info.originalShortName, storFile.folder, storFile.extension);
    const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
    if (!mls.stor.files[originalKey]) {
        const params = {
            project: info.originalProject,
            level: storFile.level,
            shortName: info.originalShortName,
            extension: storFile.extension,
            versionRef: '0',
            folder: storFile.folder
        };
        await mls.stor.addOrUpdateFile(params);
    }
    if (mls.stor.files[key]) {
        await mls.stor.localStor.setContent(mls.stor.files[key], { contentType: 'string', content: null });
        delete mls.stor.files[key];
    }
}
