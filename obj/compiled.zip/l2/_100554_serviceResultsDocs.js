/// <mls shortName="serviceResultsDocs" project="100554" enhancement="_100554_enhancementLit" groupName="internal" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getJson } from './_100554_jsDocLib';
/// **collab_i18n_start**
const message_pt = {
    onlyWithJsdocs: 'Apenas com JSDoc'
};
const message_en = {
    onlyWithJsdocs: 'Only with JSDoc',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceResultDocs100554 = class ServiceResultDocs100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.shortName = '';
        this.project = 0;
        this.level = 0;
        this.position = 'left';
        this.loading = true;
        this.onlyWithComents = false;
        this.data = [];
    }
    async connectedCallback() {
        super.connectedCallback();
        await this.getJsDoc();
        this.loading = false;
    }
    async getJsDoc() {
        this.data = getJson('', this.onlyWithComents);
        return;
        // if (!this.shortName || !this.project) return;
        // const mfile = mls.l2.editor.get({ shortName: this.shortName, project: this.project });
        // if (!mfile) return;
        // if (!mfile.compilerResults?.devDoc) {
        //     if (mfile.compilerResults) mfile.compilerResults.modelNeedCompile = true;
        //     await mls.l2.editor.getCompilerResultTS(mfile);
        // }
        // this.data = getJson(mfile.compilerResults?.devDoc || '', this.onlyWithComents);
        // console.info(this.data)
    }
    goToItem(sel, position) {
        this.querySelector('[data-doc="' + sel + '"]')?.scrollIntoView();
        const params = {
            action: 'gotoPosition',
            extension: '.ts',
            filePosition: position,
            folder: '',
            level: this.level,
            shortName: this.shortName,
            project: this.project,
            position: this.position
        };
        console.info({ goToItem: position });
        mls.events.fire([this.level], ['MonacoAction'], JSON.stringify(params));
    }
    render() {
        return html `
            <div class="docs_container">
                <div class="doc-menu" style="min-width: 200px; overflow: auto;">
                    <div class="check-container">
                        <input id="service_results_docs_check" type="checkbox">
                        <label for="service_results_docs_check">${this.msg.onlyWithJsdocs}</label>
                    </div>
                    <div>
                        ${this.data.map(groups => html `
                            <div>
                                <span class="groups">${groups.name}</span>
                                <div>
                                    ${groups.members?.map(subgroup => html `
                                        <div class="subgroup">${subgroup.name}</div>
                                    `)}
                                </div>
                            </div>
                        `)}
                    </div>
                </div>

            
            </div>
        `;
    }
};
ServiceResultDocs100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceResultDocs100554.prototype, "shortName", void 0);
__decorate([
    property()
], ServiceResultDocs100554.prototype, "project", void 0);
__decorate([
    property()
], ServiceResultDocs100554.prototype, "level", void 0);
__decorate([
    property()
], ServiceResultDocs100554.prototype, "position", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceResultDocs100554.prototype, "loading", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceResultDocs100554.prototype, "onlyWithComents", void 0);
ServiceResultDocs100554 = __decorate([
    customElement('service-results-docs-100554')
], ServiceResultDocs100554);
export { ServiceResultDocs100554 };
