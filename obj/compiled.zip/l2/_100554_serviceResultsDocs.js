/// <mls shortName="serviceResultsDocs" project="100554" enhancement="_100554_enhancementLit" groupName="internal" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getJson } from './_100554_jsDocLib';
/// **collab_i18n_start**
const message_pt = {
    onlyWithJsdocs: 'Apenas com JSDoc'
};
const message_en = {
    onlyWithJsdocs: 'Only with JSDoc',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceResultDocs100554 = class ServiceResultDocs100554 extends LitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.shortName = '';
        this.project = 0;
        this.level = 0;
        this.position = 'left';
        this.loading = true;
        this.onlyWithComents = false;
        this.data = [];
    }
    async connectedCallback() {
        super.connectedCallback();
        await this.getJsDoc();
        this.loading = false;
    }
    async getJsDoc() {
        this.data = getJson('', this.onlyWithComents);
        return;
        // if (!this.shortName || !this.project) return;
        // const mfile = mls.l2.editor.get({ shortName: this.shortName, project: this.project });
        // if (!mfile) return;
        // if (!mfile.compilerResults?.devDoc) {
        //     if (mfile.compilerResults) mfile.compilerResults.modelNeedCompile = true;
        //     await mls.l2.editor.getCompilerResultTS(mfile);
        // }
        // this.data = getJson(mfile.compilerResults?.devDoc || '', this.onlyWithComents);
        // console.info(this.data)
    }
    goToItem(sel, position) {
        this.querySelector('[data-doc="' + sel + '"]')?.scrollIntoView();
        const params = {
            action: 'gotoPosition',
            extension: '.ts',
            filePosition: position,
            folder: '',
            level: this.level,
            shortName: this.shortName,
            project: this.project,
            position: this.position
        };
        console.info({ goToItem: position });
        mls.events.fire([this.level], ['MonacoAction'], JSON.stringify(params));
    }
    render() {
        return html `
            <div class="docs_container">
                <div class="doc-menu" style="min-width: 200px; overflow: auto;">
                    <div class="check-container">
                        <input id="service_results_docs_check" type="checkbox">
                        <label for="service_results_docs_check">${this.msg.onlyWithJsdocs}</label>
                    </div>
                    <div>
                        ${this.data.map(groups => html `
                            <div>
                                <span class="groups">${groups.name}</span>
                                <div>
                                    ${groups.members?.map(subgroup => html `
                                        <div class="subgroup">${subgroup.name}</div>
                                    `)}
                                </div>
                            </div>
                        `)}
                    </div>
                </div>

            
            </div>
        `;
    }
};
ServiceResultDocs100554.styles = css ` .docs_container{position:relative;height:calc(100vh - 110px);display:flex;gap:1rem} .docs_container .check-container{display:flex;align-items:center;margin-bottom:.5rem;padding:.5rem;border-bottom:1px solid #cecece} .docs_container .check-container input{width:auto;margin-right:.5rem} .docs_container .doc-display-none{display:none} .docs_container .doc-menu{min-width:200px;background:#f8f9fa;padding-top:.25rem;padding-left:1rem;height:calc(100vh - 110px);overflow:auto} .docs_container .doc-body{height:calc(100vh - 110px);overflow:auto;flex:1} .docs_container .doc-body ul{padding-inline-start:2rem} .docs_container .doc-body .table{width:100%;margin-bottom:1rem;color:#212529} .docs_container .doc-body .table-bordered, .docs_container .doc-body .table-bordered td, .docs_container .doc-body .table-bordered th{border:1px solid #dee2e6} .docs_container .doc-body .table tbody+tbody{border-top:2px solid #dee2e6} .docs_container .doc-body .table td, .docs_container .doc-body .table th{padding:.75rem;vertical-align:top;border-top:1px solid #dee2e6} .docs_container .title{text-transform:uppercase;font-weight:bold;margin-bottom:.5rem} .docs_container .badge-modifier{display:inline-block;padding:.25em .4em;font-size:75%;font-weight:700;line-height:1;text-align:center;white-space:nowrap;vertical-align:baseline;border-radius:.25rem;color:#fff;background-color:#6183a9;border-color:#6183a9;width:100px;overflow:hidden;text-overflow:ellipsis} .docs_container mls-markdown-100529{margin-left:1.5rem;padding:.5rem;background:#fbfbfb;margin-bottom:1rem;border-radius:4px;font-size:15px} .docs_container .card{display:-ms-flexbox;display:flex;flex-direction:column;min-width:0;background-color:#fff;background-clip:border-box;border:1px solid rgba(0,0,0,0.125);border-radius:.25rem;margin-top:1.5rem;margin-bottom:1.5rem;padding:.5rem;margin-left:1.5rem} .docs_container .groups{cursor:pointer;transition:all .3s} .docs_container .groups:hover, .docs_container .subgroup:hover{color:#2598da;transition:all .3s} .docs_container .subgroup{color:#98999a;padding-left:15px;margin:5px 0px 0px 1rem;border-left:1px solid;border-radius:2px;transition:all .3s;cursor:pointer} .docs_container .active{color:#2598da} .docs_container .tags{border-left:2px solid #42a37e !important;border:1px solid rgba(0,0,0,0.06)} .docs_container .tags h5{color:#42a37e;font-weight:bold;text-transform:capitalize} .docs_container #throws{border-left:1px solid #db514c !important;border:1px solid rgba(0,0,0,0.06)} .docs_container #throws h5{color:#db514c !important;font-weight:bold !important;text-transform:capitalize !important} .docs_container .modifiers{border-left:1px solid #dc975a !important;border:1px solid rgba(0,0,0,0.06)} .docs_container .modifiers h5{color:#dc975a !important;font-weight:bold !important;text-transform:capitalize !important} .docs_container .param{border-left:1px solid #000000 !important;border:1px solid rgba(0,0,0,0.06)} .docs_container .param h5{color:#000000 !important;font-weight:bold !important;text-transform:capitalize !important} .docs_container .parameters{border-left:1px solid #3e89cc !important;border:1px solid rgba(0,0,0,0.06)} .docs_container .parameters h5{color:#3e89cc;font-weight:bold} .docs_container #todo{border-left:1px solid #777 !important;border:1px solid rgba(0,0,0,0.06)} .docs_container #todo h5{color:#777;font-weight:bold} .docs_container #event{border-left:1px solid #673AB7 !important;border:1px solid rgba(0,0,0,0.06)} .docs_container #event h5{color:#673AB7;font-weight:bold} .docs_container .text-cel{height:41px;overflow:auto} .docs_container .comment{font-size:20px;letter-spacing:1px;font-weight:500} .docs_container .section-group{margin-bottom:2em} .docs_container .titleCat{border-bottom:1px solid #dee2e6;font-weight:600 !important} .docs_container .markdownJSDOC{margin-left:5px;word-break:break-all} .docs_container .markdownJSDOC pre{font-size:100%;white-space:normal;white-space:-moz-pre-wrap;white-space:-pre-wrap;white-space:-o-pre-wrap;background-color:#F8F8F8;border:1px solid #DFDFDF;word-wrap:break-word;margin-top:1.5em;margin-bottom:1.5em;padding:.3rem;margin:0;display:block;font-family:monospace} .docs_container .markdownJSDOC pre code{font-size:100%;background-color:transparent;border:0;padding:0;white-space:pre} .docs_container .markdownJSDOC code{background-color:#F8F8F8;border-color:#DFDFDF;border-style:solid;border-width:1px;color:#333;font-weight:normal;padding:.125rem .3125rem .0625rem;font-family:monospace;display:block} .docs_container .markdownJSDOC blockquote{font-size:100%;margin:0 0 1.25rem;padding:.5625rem 1.25rem 0 1.1875rem;border-left:1px solid #ddd} .docs_container .markdownJSDOC blockquote cite{display:block;font-size:.8125rem;color:#555} .docs_container .markdownJSDOC blockquote cite:before{content:"\2014 \0020"} .docs_container .markdownJSDOC blockquote cite a, .docs_container .markdownJSDOC blockquote cite a:visited{color:#555} .docs_container .markdownJSDOC blockquote, .docs_container .markdownJSDOC blockquote p{line-height:1.6;color:#6f6f6f}`;
__decorate([
    property()
], ServiceResultDocs100554.prototype, "shortName", void 0);
__decorate([
    property()
], ServiceResultDocs100554.prototype, "project", void 0);
__decorate([
    property()
], ServiceResultDocs100554.prototype, "level", void 0);
__decorate([
    property()
], ServiceResultDocs100554.prototype, "position", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceResultDocs100554.prototype, "loading", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceResultDocs100554.prototype, "onlyWithComents", void 0);
ServiceResultDocs100554 = __decorate([
    customElement('service-results-docs-100554')
], ServiceResultDocs100554);
export { ServiceResultDocs100554 };
