/// <mls shortName="icaFormsInputNumberBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElement } from './_100554_icaLitElement';
export class IcaFormsInputNumberBase extends IcaLitElement {
}
