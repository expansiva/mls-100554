/// <mls shortName="pluginExploreStories" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg, repeat } from 'lit';
import { property } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { selectLevel, forceServiceInstance, openService } from './_100554_libCommom';
/// **collab_i18n_start**
const message_pt = {
    draft: 'Rascunho',
    published: 'Publicados',
    noPragraph: "Nenhum paragrafo encontrado",
    editDraft: 'Editar rascunho',
    delDraft: 'Deletar rascunho'
};
const message_en = {
    draft: 'Draft',
    published: 'Published',
    noPragraph: "Didn't find any paragraphs",
    editDraft: 'Edit draft',
    delDraft: 'Delete draft'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Stories",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
export class PluginExploreStories extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-explore-stories-100554{font-family:var(--font-family-primary);font-size:var(--font-size-20);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-explore-stories-100554 ul{list-style:none}plugin-explore-stories-100554 li{border-bottom:1px solid #e7e7e75e;margin-bottom:2rem;padding-bottom:1rem;cursor:pointer}plugin-explore-stories-100554 li h3{margin-bottom:0px;padding-bottom:0px}plugin-explore-stories-100554 li span{font-size:1.1rem}plugin-explore-stories-100554 li menuitems{display:inline-block;position:relative;min-width:10rem}plugin-explore-stories-100554 li menuitems menubox{display:none}plugin-explore-stories-100554 li menuitems menuicon{display:block;width:15px;height:15px;cursor:pointer}plugin-explore-stories-100554 li menuitems menuitem{font-size:1rem;cursor:pointer}plugin-explore-stories-100554 li menuitems menuitem:hover{background-color:var(--grey-color-light)}plugin-explore-stories-100554 li menuitems[mode=open] menubox{position:absolute;display:flex;flex-direction:column;background-color:var(--bg-primary-color);padding:.5rem;box-shadow:0 0 12px 7px #e6e6e6a3;border-radius:5px;top:30px;left:-50%;transform:translate(41%, 0%)}plugin-explore-stories-100554 li menuitems[mode=open] menubox::before{content:" ";clip-path:polygon(50% 0%, 0% 100%, 100% 100%);background-color:var(--bg-primary-color);position:absolute;width:22px;height:15px;top:-4px;left:50%;transform:translate(-50%, -50%)}`);
        this.msg = messages['en'];
        this.project = 1;
        this.position = 'left';
        this.level = 0;
        this.autoPrepare = false;
        this.files = [];
        this.activeTab = 'icDraft';
        this.timeBlur = 0;
    }
    async prepare() {
        this.init();
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
        forceServiceInstance(2, '_100554_serviceSource');
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'icDraft':
                return this.renderDraft();
            case 'icPublished':
                return this.renderPublished();
            default:
                return html ``;
        }
    }
    renderDraft() {
        return html `
                <ul>
                    ${this.renderList()}
                </ul>
        
            </div>
        `;
    }
    renderPublished() {
        return html ``;
    }
    renderList() {
        return html `
            ${this.files.length <= 0 ? '' :
            html `
                    ${repeat(this.files, ((item) => item.name), ((file, index) => {
                return this.renderLiItem(file, index, false);
            }))}
                `}
        `;
    }
    renderLiItem(file, index, inHistory) {
        const aux = file.file.status === 'deleted' ? "text-decoration: line-through; color: #cf0707;" : '';
        return html `
            <li @click="${this.clickLi}" .myFile=${file.file} .nameFilter="${file.name}">
                <div class="elContent">
                    <h3 style="${aux}">${file.name}</h3>
                    <span>${file.desc}</span>
                    <menuitems @click="${this.clickMenu}" @mouseleave="${this.blurMenu}" @mouseover="${this.overMenu}">
                        <menuicon>
                            <svg xmlns='http://www.w3.org/2000/svg' style="fill:#8f8f8ffa"  viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path  d='M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z'/></svg>
                        </menuicon>
                        <menubox>
                            <menuitem @click="${this.clickOptOpen}">${this.msg.editDraft}</menuitem>
                            <menuitem @click="${this.clickOptDel}">${this.msg.delDraft}</menuitem>
                        </menubox>
                    </menuitems>
                </div>
            </li>
        `;
    }
    async init() {
        this.project = mls.actual[5].project;
        await this.getFiles();
    }
    async getFiles() {
        try {
            const arraySf = await this.getFilesProject();
            this.files = [...arraySf];
        }
        catch (e) {
            console.info(e);
        }
    }
    async getFilesProject() {
        if (!window['mls'])
            return [];
        const arraySf = [];
        const ext = '.html';
        for await (const i of Object.keys(mls.stor.files).sort()) {
            const sf = mls.stor.files[i];
            if (sf.project !== this.project || sf.shortName.toLocaleLowerCase().indexOf('page') < 0 ||
                sf.extension !== ext)
                continue;
            const keyTS = mls.stor.getKeyToFiles(sf.project, sf.level, sf.shortName, sf.folder, '.ts');
            const fTS = mls.stor.files[keyTS];
            if (!fTS)
                continue;
            const content = await fTS.getContent();
            if (content.indexOf('extends') < 0)
                continue;
            const start = content.indexOf('extends') + 'extends'.length;
            const end = content.substring(start, content.length).indexOf('{');
            const extendsPage = content.substr(start, end);
            if (extendsPage.toLocaleLowerCase().indexOf('page') < 0)
                continue;
            const div = document.createElement('div');
            div.innerHTML = await sf.getContent();
            let name = div.querySelector('.story-title')?.getAttribute('text') || sf.shortName;
            let desc = div.querySelector('.story-desc')?.getAttribute('text') || this.msg.noPragraph;
            arraySf.push({
                desc,
                name,
                file: sf
            });
        }
        return arraySf;
    }
    clickLi(e) {
        e.stopPropagation();
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'li')
            el = el.closest('li');
        if (!el)
            return;
        openService('_100554_servicePreview', 'right', +this.level);
        this.fireEvents('open', el.myFile, {});
    }
    clickMenu(e) {
        e.stopPropagation();
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'menuitems')
            el = el.closest('menuitems');
        if (!el)
            return;
        if (el.getAttribute('mode') === 'open') {
            el.setAttribute('mode', '');
        }
        else
            el.setAttribute('mode', 'open');
    }
    blurMenu(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'menuitems')
            el = el.closest('menuitems');
        if (!el || !el.getAttribute('mode'))
            return;
        this.timeBlur = setTimeout(() => {
            el.setAttribute('mode', '');
        }, 800);
    }
    overMenu(e) {
        if (!this.timeBlur)
            return;
        clearTimeout(this.timeBlur);
    }
    clickOptOpen(e) {
        e.stopPropagation();
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'li')
            el = el.closest('li');
        if (!el)
            return;
        selectLevel(2);
        this.fireEvents('open', el.myFile, {});
    }
    clickOptDel(e) {
        e.stopPropagation();
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'li')
            el = el.closest('li');
        if (!el)
            return;
        this.fireEvents('delete', el.myFile, {});
        setTimeout(() => {
            this.requestUpdate();
        }, 800);
    }
    fireEvents(action, file, info, timeout = 0) {
        const params = {};
        params.action = action;
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = '.ts';
        params.folder = file.folder;
        params.position = this.position;
        if (info && info.shortName) {
            params.newshortName = info.shortName;
            params.newProject = info.project;
            params.newfolder = file.folder;
        }
        if (['open'].includes(action)) {
            mls.actual[2].setFullName(`_${file.project}_${file.shortName}`);
            mls.actual[2][this.position] = {
                project: file.project,
                shortName: file.shortName,
                extension: '.ts',
                folder: file.folder,
            };
        }
        mls.events.fire([2], ['FileAction'], JSON.stringify(params), timeout);
    }
}
__decorate([
    property()
], PluginExploreStories.prototype, "position", void 0);
__decorate([
    property()
], PluginExploreStories.prototype, "level", void 0);
__decorate([
    property({ type: Boolean })
], PluginExploreStories.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: Array })
], PluginExploreStories.prototype, "files", void 0);
__decorate([
    property()
], PluginExploreStories.prototype, "activeTab", void 0);
if (!customElements.get('plugin-explore-stories-100554')) {
    customElements.define('plugin-explore-stories-100554', PluginExploreStories);
}
