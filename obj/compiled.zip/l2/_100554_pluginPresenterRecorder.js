/// <mls shortName="pluginPresenterRecorder" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { property, customElement } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
import { getMessageKey } from "./_100554_collabLitElement";
/// **collab_i18n_start**
const message_pt = {
    title: "Gravação de Apresentação",
    btnStart: 'Iniciar',
    btnStop: 'Parar',
    msgDesc: `Grava a tela do navegador e sua câmera (avatar) no canto, com áudio. Após parar, faça o download do vídeo e compartilhe onde quiser, como no WhatsApp.`
};
const message_en = {
    title: "Presentation Recording",
    btnStart: 'Start',
    btnStop: 'Stop',
    msgDesc: `Records the browser screen and your camera (avatar) in the corner, with audio. After stopping, download the video and share it anywhere, such as WhatsApp.`
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
const lang = getMessageKey(messages);
let msg = messages[lang];
/// **collab_i18n_end**
export const pluginData = {
    title: "Record Presenter",
    getSvg() {
        return svg `<svg width="22" height="22" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512">
      <path d="M512 80h-64l-34-56a32 32 0 0 0-27-16h-192a32 32 0 0 0-27 16l-34 56H64A64 64 0 0 0 0 144v304a64 64 0 0 0 64 64h448a64 64 0 0 0 64-64V144a64 64 0 0 0-64-64zm-256 80a112 112 0 1 1 0 224 112 112 0 0 1 0-224zm0 48a64 64 0 1 0 0 128 64 64 0 0 0 0-128z"/></svg>`;
    }
};
let PluginPresenterRecorder = class PluginPresenterRecorder extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-presenter-recorder-100554{font-family:var(--font-family-primary);background:transparent;color:var(--text-primary-color);font-size:var(--font-size-16);padding:var(--space-24);border-radius:12px;box-shadow:0 2px 12px rgba(0,0,0,0.05);max-width:600px;margin:auto;min-height:220px}plugin-presenter-recorder-100554 h3{font-size:var(--font-size-20);font-weight:var(--font-weight-bold);color:var(--text-primary-color);margin-bottom:var(--space-16)}plugin-presenter-recorder-100554 p{color:var(--text-primary-color-lighter);font-size:var(--font-size-16);margin-bottom:var(--space-24)}plugin-presenter-recorder-100554 button{margin:0 var(--space-8) var(--space-8) 0;font-size:var(--font-size-16);padding:var(--space-8) var(--space-24);border-radius:8px;border:1px solid var(--grey-color);background:var(--bg-secondary-color);color:var(--text-secondary-color-darker);cursor:pointer;transition:background var(--transition-slow)}plugin-presenter-recorder-100554 button:hover{background:var(--bg-secondary-color-hover);color:var(--text-secondary-color);border-color:var(--grey-color-dark)}plugin-presenter-recorder-100554 button:active,plugin-presenter-recorder-100554 button:focus{outline:none;border-color:var(--active-color)}plugin-presenter-recorder-100554 button:disabled{background:var(--bg-secondary-color-disabled);color:var(--text-primary-color-disabled);cursor:not-allowed}plugin-presenter-recorder-100554 a[download]{font-size:var(--font-size-16);color:var(--link-color);text-decoration:underline;margin-left:var(--space-16)}plugin-presenter-recorder-100554 a[download]:hover{color:var(--link-color-hover)}plugin-presenter-recorder-100554 #pip-avatar-container{position:fixed;bottom:1rem;right:1rem;width:160px;height:160px;background:#000;border:3px solid var(--active-color);box-shadow:0 2px 12px rgba(0,0,0,0.18);z-index:9999;overflow:hidden;pointer-events:none;display:flex;align-items:center;justify-content:center}plugin-presenter-recorder-100554 .pip-avatar-round{border-radius:50% !important;overflow:hidden}plugin-presenter-recorder-100554 .pip-avatar-square{border-radius:10px !important;overflow:hidden}plugin-presenter-recorder-100554 #plugin-presenter-camera-preview{width:100%;height:100%;object-fit:cover;object-position:center;border:none;box-shadow:none;background:transparent;transition:transform .2s}plugin-presenter-recorder-100554 #plugin-presenter-camera-preview.avatar-zoom-1x{transform:scale(1)}plugin-presenter-recorder-100554 #plugin-presenter-camera-preview.avatar-zoom-15x{transform:scale(1.5)}plugin-presenter-recorder-100554 #plugin-presenter-camera-preview.avatar-zoom-2x{transform:scale(2)}plugin-presenter-recorder-100554 .avatar-round{border-radius:50% !important;overflow:hidden}plugin-presenter-recorder-100554 .avatar-zoom-1x{transform:scale(1);object-fit:cover;object-position:center}plugin-presenter-recorder-100554 .avatar-zoom-15x{transform:scale(1.5);object-fit:cover;object-position:center}plugin-presenter-recorder-100554 .avatar-zoom-2x{transform:scale(2);object-fit:cover;object-position:center}plugin-presenter-recorder-100554 fieldset{display:flex;flex-direction:column;gap:1rem;border:1px solid var(--grey-color-light);border-radius:10px;padding:1rem 1.5rem 1.5rem 1.5rem;margin-bottom:var(--space-24);background:transparent}plugin-presenter-recorder-100554 legend{font-size:var(--font-size-16);font-weight:var(--font-weight-bold);margin-bottom:var(--space-8);color:var(--text-primary-color)}plugin-presenter-recorder-100554 .radio-row{display:flex;align-items:center;gap:2rem;margin-bottom:.5rem}plugin-presenter-recorder-100554 .zoom-row{display:flex;align-items:center;gap:1rem;margin-top:.5rem}@media (max-width:544px){plugin-presenter-recorder-100554 plugin-presenter-recorder-100554{padding:var(--space-8)}plugin-presenter-recorder-100554 plugin-presenter-recorder-100554 h3{font-size:var(--font-size-16)}plugin-presenter-recorder-100554 plugin-presenter-recorder-100554 #plugin-presenter-camera-preview{width:120px}}`);
        this.screenStream = null;
        this.cameraStream = null;
        this.mediaRecorder = null;
        this.chunks = [];
        this.downloadUrl = null;
        // Appearance config (reactive properties)
        this.avatarShape = 'square';
        this.avatarZoom = 1;
        this.isRecording = false;
        this.isCountdown = false;
        this.countdownValue = 5;
    }
    render() {
        return html `
<div>
  <h3>🎤 ${msg.title}</h3>
  <p>${msg.msgDesc}</p>
  <fieldset>
    <legend><b>Camera Style</b></legend>
    <div class="radio-row">
      <label>
        <input type="radio" name="shape" value="square" .checked=${this.avatarShape === 'square'} @change=${() => this.avatarShape = 'square'}>
        Square
      </label>
      <label>
        <input type="radio" name="shape" value="round" .checked=${this.avatarShape === 'round'} @change=${() => this.avatarShape = 'round'}>
        Round
      </label>
    </div>
    <div class="zoom-row">
      <span>Zoom:</span>
      <select @change=${this.handleZoomChange}>
        <option value="1" ?selected=${this.avatarZoom === 1}>1x</option>
        <option value="1.5" ?selected=${this.avatarZoom === 1.5}>1.5x</option>
        <option value="2" ?selected=${this.avatarZoom === 2}>2x</option>
      </select>
    </div>
  </fieldset>
  <br>
  ${this.isCountdown ? html `
    <div style="font-size:2rem; color:#ff4444; margin:1rem 0; font-weight:bold;">
      Recording starts in ${this.countdownValue}...
    </div>
  ` : ''}
  <br>
  <button 
    @click=${this.startRecording} 
    ?disabled=${this.isRecording || this.isCountdown}
  >🎥 ${msg.btnStart}</button>
  <button 
    @click=${this.stopRecording} 
    ?disabled=${!this.isRecording}
  >🛑 ${msg.btnStop}</button>

  ${this.downloadUrl ? html `
    <a href="${this.downloadUrl}" download="apresentacao.webm" style="margin-left:1rem;">
      ⬇️ Baixar vídeo
    </a>` : ''}
  <div id="pip-avatar-container" class="pip-avatar-${this.avatarShape === 'round' ? 'round' : 'square'}">
    <video
      id="plugin-presenter-camera-preview"
      autoplay
      muted
      class="avatar-zoom-${this.avatarZoom === 1 ? '1x' : this.avatarZoom === 1.5 ? '15x' : '2x'}"
    ></video>
  </div>
</div>
  `;
    }
    // Event for zoom combo
    handleZoomChange(e) {
        const value = +e.target.value;
        this.avatarZoom = value;
    }
    updated() {
        const preview = this.querySelector('#plugin-presenter-camera-preview');
        if (preview && this.cameraStream) {
            preview.srcObject = this.cameraStream;
        }
    }
    async startRecording() {
        this.downloadUrl = null;
        this.chunks = [];
        this.requestUpdate();
        try {
            this.screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
            this.cameraStream = await navigator.mediaDevices.getUserMedia({
                video: true,
                audio: {
                    echoCancellation: false,
                    noiseSuppression: false,
                    sampleRate: 48000,
                }
            });
            // Start countdown before recording
            this.countdownValue = 5;
            this.isCountdown = true;
            this.requestUpdate();
            this.countdownTimer = window.setInterval(() => {
                this.countdownValue -= 1;
                this.requestUpdate();
                if (this.countdownValue <= 0) {
                    clearInterval(this.countdownTimer);
                    this.isCountdown = false;
                    this._doStartRecording();
                }
            }, 1000);
        }
        catch (err) {
            this.isRecording = false;
            this.isCountdown = false;
            this.screenStream = null;
            this.cameraStream = null;
            this.requestUpdate();
        }
    }
    _doStartRecording() {
        if (!this.screenStream || !this.cameraStream)
            return;
        this.isRecording = true;
        this.showPipPreview();
        const preview = this.querySelector('#plugin-presenter-camera-preview');
        if (preview) {
            preview.srcObject = this.cameraStream;
        }
        const combinedStream = new MediaStream([
            ...this.screenStream.getVideoTracks(),
            ...this.cameraStream.getAudioTracks()
        ]);
        this.mediaRecorder = new MediaRecorder(combinedStream);
        this.mediaRecorder.ondataavailable = (e) => this.chunks.push(e.data);
        this.mediaRecorder.onstop = () => {
            this.saveRecording();
            this.isRecording = false;
            this.requestUpdate();
        };
        this.mediaRecorder.start();
        this.requestUpdate();
    }
    stopRecording() {
        if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
            this.mediaRecorder.stop();
        }
        this.screenStream?.getTracks().forEach((t) => t.stop());
        this.cameraStream?.getTracks().forEach((t) => t.stop());
        this.hidePipPreview();
        // this.isRecording = false;
        // this.requestUpdate();
    }
    saveRecording() {
        const blob = new Blob(this.chunks, { type: 'video/webm' });
        this.downloadUrl = URL.createObjectURL(blob);
        this.chunks = [];
        this.requestUpdate();
        // Download automático
        const a = document.createElement('a');
        a.href = this.downloadUrl;
        a.download = 'apresentacao.webm';
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    }
    showPipPreview() {
        const container = ensureGlobalPipContainer();
        container.innerHTML = '';
        const pipDiv = document.createElement('div');
        pipDiv.id = 'plugin-global-pip-preview';
        pipDiv.className = `pip-avatar-${this.avatarShape === 'round' ? 'round' : 'square'}`;
        pipDiv.style.width = '160px';
        pipDiv.style.height = '160px';
        pipDiv.style.background = '#000';
        pipDiv.style.border = '3px solid #1890FF';
        pipDiv.style.borderRadius = this.avatarShape === 'round' ? '50%' : '10px';
        pipDiv.style.overflow = 'hidden';
        pipDiv.style.display = 'flex';
        pipDiv.style.alignItems = 'center';
        pipDiv.style.justifyContent = 'center';
        pipDiv.style.position = 'relative';
        pipDiv.style.pointerEvents = 'auto';
        // Video element (always visible)
        const video = document.createElement('video');
        video.id = 'plugin-presenter-camera-preview';
        video.autoplay = true;
        video.muted = true;
        video.style.width = '100%';
        video.style.height = '100%';
        video.style.objectFit = 'cover';
        video.className = `avatar-zoom-${this.avatarZoom === 1 ? '1x' : this.avatarZoom === 1.5 ? '15x' : '2x'}`;
        pipDiv.appendChild(video);
        // Control buttons (hidden by default)
        const stopBtn = document.createElement('button');
        stopBtn.innerHTML = '🛑';
        stopBtn.title = 'Stop Recording';
        stopBtn.style.position = 'absolute';
        stopBtn.style.bottom = '10px';
        stopBtn.style.right = '10px';
        stopBtn.style.zIndex = '10001';
        stopBtn.style.background = 'rgba(255,255,255,0.9)';
        stopBtn.style.border = 'none';
        stopBtn.style.borderRadius = '8px';
        stopBtn.style.padding = '4px 10px';
        stopBtn.style.cursor = 'pointer';
        stopBtn.style.fontSize = '1.2rem';
        stopBtn.style.boxShadow = '0 1px 8px rgba(0,0,0,0.10)';
        stopBtn.style.display = 'none';
        stopBtn.onclick = () => this.stopRecording();
        const resumeBtn = document.createElement('button');
        resumeBtn.innerHTML = '▶️';
        resumeBtn.title = 'Resume Recording';
        resumeBtn.style.position = 'absolute';
        resumeBtn.style.bottom = '10px';
        resumeBtn.style.left = '10px';
        resumeBtn.style.zIndex = '10001';
        resumeBtn.style.background = 'rgba(255,255,255,0.9)';
        resumeBtn.style.border = 'none';
        resumeBtn.style.borderRadius = '8px';
        resumeBtn.style.padding = '4px 10px';
        resumeBtn.style.cursor = 'pointer';
        resumeBtn.style.fontSize = '1.2rem';
        resumeBtn.style.boxShadow = '0 1px 8px rgba(0,0,0,0.10)';
        resumeBtn.style.display = 'none';
        resumeBtn.onclick = () => {
            this.mediaRecorder?.resume();
            // Hide buttons again on resume
            stopBtn.style.display = 'none';
            resumeBtn.style.display = 'none';
        };
        pipDiv.appendChild(stopBtn);
        pipDiv.appendChild(resumeBtn);
        // On click: if recording, pause and show buttons
        pipDiv.onclick = (e) => {
            // Prevent click from affecting parent
            e.stopPropagation();
            if (this.mediaRecorder?.state === 'recording') {
                this.mediaRecorder.pause();
                // Show control buttons on pause
                stopBtn.style.display = '';
                resumeBtn.style.display = '';
            }
        };
        // Hide buttons when not paused
        if (this.mediaRecorder?.state !== 'paused') {
            stopBtn.style.display = 'none';
            resumeBtn.style.display = 'none';
        }
        container.appendChild(pipDiv);
        if (this.cameraStream)
            video.srcObject = this.cameraStream;
    }
    hidePipPreview() {
        const container = document.getElementById('pip-global-container');
        if (container)
            container.innerHTML = '';
    }
};
__decorate([
    property({ type: String })
], PluginPresenterRecorder.prototype, "avatarShape", void 0);
__decorate([
    property({ type: Number })
], PluginPresenterRecorder.prototype, "avatarZoom", void 0);
__decorate([
    property({ type: Boolean })
], PluginPresenterRecorder.prototype, "isRecording", void 0);
__decorate([
    property({ type: Boolean })
], PluginPresenterRecorder.prototype, "isCountdown", void 0);
__decorate([
    property({ type: Number })
], PluginPresenterRecorder.prototype, "countdownValue", void 0);
PluginPresenterRecorder = __decorate([
    customElement('plugin-presenter-recorder-100554')
], PluginPresenterRecorder);
export { PluginPresenterRecorder };
function ensureGlobalPipContainer() {
    let container = document.getElementById('pip-global-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'pip-global-container';
        // Importante: z-index bem alto, posição fixed, pointer-events none, etc.
        container.style.position = 'fixed';
        container.style.bottom = '1rem';
        container.style.right = '1rem';
        container.style.zIndex = '9999';
        container.style.pointerEvents = 'none';
        document.body.appendChild(container);
    }
    return container;
}
