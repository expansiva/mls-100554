/// <mls shortName="serviceExploreProjects" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, queryAll, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { setProjectDetails, getProjectDetails } from './_100554_libCommom';
import './_100554_pluginCreateNewProject';
/// **collab_i18n_start**
const message_pt = {
    select: 'Selecionar',
    detail: 'Detalhe',
    inDevelopment: 'Em Desenvolvimento',
    noProjectSelected: 'Nenhum projeto selecionado!',
    detailsResume: 'Resumo',
    detailsConnections: 'Conexão',
    detailsBranchs: 'Branchs',
    detailsFiles: 'Arquivos Iniciais',
    detailsFilesDesc: 'Atualiza os arquivos iniciais do projeto, que irão servir para compilar o projeto inicialmente, estes arquivos são criados automaticamente na criação do projeto',
    detailsInfo: 'Info',
    name: 'Nome',
    projectDriver: 'Driver',
    projectOrg: 'Organização',
    projectOwner: 'Proprietário',
    projectCreatedAt: 'Criado em',
    projectURL: 'URL do Projeto',
    designSystems: 'Design systems',
    lastModified: 'Última modificação',
    files: 'Arquivos',
    keyGithub: 'Chave do GitHub',
    project: 'Projeto',
    noProject: 'Nenhum projeto selecionado, por favor selecione.',
    selectProject: 'Selecione o projeto',
    btnChange: 'Alterar',
    btnUpdate: 'Atualizar',
    btnAddNewProject: 'Criar novo projeto',
    btnCreateProject: 'Criar projeto',
    btnRefreshOrg: 'Atualizar',
    btnOpenProject: 'Abrir projeto',
    addProject: 'Novo projeto',
    placeholderFilter: 'Filtro',
    push: 'Permite que os desenvolvedores façam push diretamente para a branch principal.',
    pullRequest: 'Exige que todas as mudanças sejam feitas através de Pull Requests, permitindo revisões de código e aprovação antes da integração na branch principal.',
    projectNameLabel: 'Nome do projeto',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organização',
    visibilityLabel: 'Visibilidade do projeto',
    visibilityPublicOption: 'Público - Qualquer pessoa pode ver este repositório.',
    visibilityPrivateOption: 'Privado - Você escolhe quem pode ver.',
    teamLabel: 'Time',
    loadingAddText1: 'Buscando informações do usuário',
    loadingAddText2: 'Buscando organizações do usuário',
    step1Title: 'Passo 1',
    step2Title: 'Passo 2',
    step3Title: 'Passo 3',
    step1Msg: 'Escolha o driver para carregar suas organizações existentes.',
    step2Msg: 'Agora selecione a organização e o modo de atualização.',
    step3Msg: 'Finalmente, selecione a equipe e a visibilidade do projeto.'
};
const message_en = {
    select: 'Select',
    detail: 'Detail',
    inDevelopment: 'in development',
    noProjectSelected: 'No project selected!',
    detailsResume: 'Resume',
    detailsConnections: 'Connection',
    detailsBranchs: 'Branchs',
    detailsFiles: 'Files initials',
    detailsFilesDesc: 'Updates the project initial files, which we will use to compile the project initially, these files are created automatically when the project is created',
    detailsInfo: 'Info',
    name: 'Name',
    projectDriver: 'Project Driver',
    projectOrg: 'Organization',
    projectOwner: 'Owner',
    projectCreatedAt: 'CreatedAt',
    projectURL: 'Project URL',
    designSystems: 'Design systems',
    lastModified: 'Last Modified',
    files: 'Files',
    keyGithub: 'Key Github',
    project: 'Project',
    noProject: 'No project selected, please select',
    selectProject: 'Select project',
    btnChange: 'Change',
    btnUpdate: 'Update',
    btnAddNewProject: 'Create new Project',
    btnCreateProject: 'Create project',
    btnRefreshOrg: 'Refresh',
    btnOpenProject: 'Open project',
    addProject: 'New project',
    placeholderFilter: 'Filter',
    push: 'Allows developers to push directly to the main branch.',
    pullRequest: 'Requires all changes to be made through Pull Requests, allowing code reviews and approval before integration into the main branch.',
    projectNameLabel: 'Project name',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organization',
    visibilityLabel: 'Project visibility',
    visibilityPublicOption: 'Public - Anyone can see this repository.',
    visibilityPrivateOption: 'Private - You choose who can see.',
    teamLabel: 'Team',
    loadingAddText1: 'Loading user informations',
    loadingAddText2: 'Loading user organizations',
    step1Title: 'Step 1',
    step2Title: 'Step 2',
    step3Title: 'Step 3',
    step1Msg: 'Choose the driver to load your existing organizations.',
    step2Msg: 'Now select the organization and the update mode.',
    step3Msg: 'Finally select the team and the visibility of the project.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceExploreProjects100554 = class ServiceExploreProjects100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-explore-projects-100554{display:block;height:calc(100% - 55px);overflow:auto;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}service-explore-projects-100554 input,service-explore-projects-100554 select,service-explore-projects-100554 textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}service-explore-projects-100554 button{border:none;display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;cursor:pointer;background:none;color:var(--active-color)}service-explore-projects-100554 button:hover{color:var(--active-color-hover);text-decoration:underline}service-explore-projects-100554 .l5-project-list{font-family:'Charlie Display',-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;overflow-y:auto;height:calc(100vh - 110px);width:100%;scroll-behavior:smooth}service-explore-projects-100554 .l5-project-list .filter-container{padding:.5rem}service-explore-projects-100554 .l5-project-list .serviceListTitle{padding:.3em 1em;list-style-type:none;background:#f7f7f7;color:#000;font-weight:600;cursor:default}service-explore-projects-100554 .l5-project-list .serviceListList{display:flex;-ms-flex-direction:column;flex-direction:column;padding-left:0}service-explore-projects-100554 .l5-project-list .serviceListList li{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:.5rem;cursor:pointer;display:flex;justify-content:space-between;align-items:center}service-explore-projects-100554 .l5-project-list .serviceListList li[disabled]{opacity:.5;cursor:not-allowed}service-explore-projects-100554 .l5-project-list .serviceListList li[disabled] .linkItem{font-weight:var(--font-weight-normal);cursor:not-allowed}service-explore-projects-100554 .l5-project-list .serviceListList li[disabled] .linkItem:hover{text-decoration:none}service-explore-projects-100554 .l5-project-list .serviceListList li:hover,service-explore-projects-100554 .l5-project-list .serviceListList li.selected{background:var(--grey-color)}service-explore-projects-100554 .l5-project-list .serviceListList li:hover .linkItem,service-explore-projects-100554 .l5-project-list .serviceListList li.selected .linkItem{font-weight:var(--font-weight-bolder);color:var(--link-color-hover)}service-explore-projects-100554 .l5-project-list .serviceListList li div{display:flex;gap:.5rem}service-explore-projects-100554 .l5-project-list .serviceListList li .serviceListChanged{color:lightskyblue;font-size:13px;display:flex;justify-content:center;align-items:center}service-explore-projects-100554 .l5-project-list .serviceListList li .serviceBugChanged{color:#a90303;font-size:13px;display:flex;justify-content:center;align-items:center}service-explore-projects-100554 .l5-project-list .serviceListList li .linkItem{color:var(--active-color);cursor:pointer}service-explore-projects-100554 .l5-project-list .serviceListList li .linkItem:hover{text-decoration:underline}service-explore-projects-100554 #button-see-project{background-color:var(--active-color);color:#fff}`);
        this.msg = messages['en'];
        this.projectCreated = false;
        this.state = { history: [], orgs: [], projectSelected: undefined };
        this.currentScenario = 'select';
        this.activeTab = 'IMyProject';
        //----------CONFIG SERVICE------------------
        this.details = {
            icon: '&#xf0b1',
            state: 'background',
            position: 'left',
            tooltip: 'Projects',
            visible: true,
            widget: '_100554_serviceExploreProjects',
            level: [6]
        };
        this.menu = {
            title: '',
            main: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [
                    { text: 'My Projects', icon: 'e571' },
                    { text: 'Explore', icon: 'f542' },
                ]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.filterTimeout = 0;
        this.projectCreatedNumber = 100554;
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        this.activeTab = ETabs[index];
    }
    onServiceClick(visible, reinit, el) {
        if (this.lastPrjId && mls.actualLevel === 6 && visible) {
            this.firedetail({ project: +this.lastPrjId, name: '', doSelect: true });
        }
    }
    //----------EVENTS---------------------
    setEvents() {
        mls.events.addEventListener([6], ['ProjectExplore'], (details) => {
            this.openService('_100554_serviceExploreProjects', 'left', 6);
        });
    }
    //----------COMPONENT------------------
    connectedCallback() {
        super.connectedCallback();
        this.setEvents();
        this.getLastProject();
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'IMyProject':
                return this.renderMyProject();
            case 'IExplore':
                return this.renderExplore();
            default:
                return html ``;
        }
    }
    renderExplore() {
        return html `<h3 style="padding:2rem">Explore others projects , in development</h3>`;
    }
    renderMyProject() {
        switch (this.currentScenario) {
            case 'select':
                return html `
                    ${this.renderSelectProject()}
                `;
            case 'add':
                return html `
                    ${this.renderAdd()}
                `;
        }
    }
    renderSelectProject() {
        this.getOrgsAndProjects();
        this.state.history = this.loadHistory();
        return html `
            <div class="scroll-custom l5-project-list">
                <div class="filter-container" style="display:flex">
                    <input style="width:calc(100% - 160px)" type="text" placeholder="Filter" @input=${this._filterProjects}>
                    <button style="margin-left:5px; width:150px;" @click=${this.onAddNewProjectClick}>${this.msg.btnAddNewProject}</button>
                </div>
                ${this.renderHistory()}
                ${this.renderList()}
                
            </div>
        `;
    }
    renderHistory() {
        return html `
            <div class="l5-project-list-history" style="${this.state.history.length === 0 ? 'display:none' : 'display: block'}">
                <div class="serviceListTitle">History</div>
                <ul class="serviceListList">
                    ${this.state.history.map((his) => html `
                        <li ?disabled=${!his.doSelect} class=${this.lastPrjId && +this.lastPrjId === his.project ? "selected" : ""} >
                            <div>
                                <span>${his.name + ' (' + his.project.toString() + ')'}</span>
                            </div>
                            <div style="display:flex; gap:1rem;font-size:.8rem">
                                <span class="linkItem" @click=${() => { this.onHistoryClick(his); }}>
                                    ${this.msg.select}
                                </span>
                                <span class="linkItem" @click=${() => this.firedetail(his)}>
                                    ${this.msg.detail}
                                </span>
                            </div>
                        </li>
                    `)}
                </ul>
            </div>
        `;
    }
    renderList() {
        return html `
            <div class="serviceListProjects">
                ${this.state.orgs.map((org) => {
            return html `
                    <div class="serviceListTitle">${org.key}</div>
                    <ul class="serviceListList">
                        ${org.projects.map((prj) => html `
                            <li ?disabled=${!prj.doSelect} class=${this.lastPrjId && +this.lastPrjId === prj.project ? "selected" : ""} >
                                <div>
                                    <span>${prj.name + ' (' + prj.project.toString() + ')'}</span>
                                </div>
                                <div style="display:flex; gap:1rem;font-size:.8rem">
                                    <span class="linkItem" @click=${() => this.onProjectClick(prj)}>
                                        ${this.msg.select}
                                    </span>
                                    <span class="linkItem" @click=${() => this.firedetail(prj)}>
                                        ${this.msg.detail}
                                    </span>
                                </div>
                            </li>
                        `)}
                    </ul>
                `;
        })}
    
            </div>
        `;
    }
    renderAdd() {
        return html `
            <div @click="${this.backScenaryList}" style="padding-left: 1rem; padding-top: .5rem; cursor: pointer;">< Back</div>
            <plugin-create-new-project-100554>
            </plugin-create-new-project-100554>
        `;
    }
    //----------IMPLEMENTS------------------
    async firedetail(prj) {
        if (!prj.doSelect)
            return;
        localStorage.setItem('serviceDetail', '{"action":"open", "prj":' + prj.project + '}');
        mls.events.fire(2, 'PluginDetails', JSON.stringify({
            shortName: 'pluginProjectDetail',
            project: 100554
        }), 0);
    }
    backScenaryList() {
        this.changeScenario('select');
    }
    getLastProject() {
        const info = getProjectDetails();
        if (info)
            this.lastPrjId = info.project.toString();
        else
            this.lastPrjId = localStorage.getItem('l5-last-project');
        return this.lastPrjId;
    }
    getOrgsAndProjects() {
        this.clearState();
        Object.keys(mls.stor.orgs).forEach((org, index) => {
            const { name, description, created_at, projects } = mls.stor.orgs[org].sett;
            const prj = [];
            projects.forEach((p) => {
                try {
                    const json = JSON.parse(p.value);
                    if (!p.id)
                        return;
                    const info = mls.l5.getProjectSettings(p.id);
                    let doSelect = true;
                    let projectDriver = '';
                    let projectURL = '';
                    if (!json.projectURL && json.l5_actionPrjSettings) {
                        projectDriver = json.l5_actionPrjSettings.projectDriver || '';
                        projectURL = json.l5_actionPrjSettings.projectURL || '';
                    }
                    else if (json.projectURL) {
                        projectDriver = json.projectDriver || '';
                        projectURL = json.projectURL || '';
                    }
                    if (!projectDriver || !projectURL || projectDriver === 'mls')
                        return;
                    if (!info || !info.projectDriver || !info.projectURL)
                        doSelect = false;
                    prj.push({
                        project: p.id,
                        name: p.name,
                        doSelect
                    });
                    /*let projectDriver = '';
                    let projectURL = '';


                    if (!json.projectURL && json.l5_actionPrjSettings) {

                        projectDriver = json.l5_actionPrjSettings.projectDriver || '';
                        projectURL = json.l5_actionPrjSettings.projectURL || '';

                    } else if (json.projectURL) {

                        projectDriver = json.projectDriver || '';
                        projectURL = json.projectURL || '';

                    }

                    if (!projectDriver || !projectURL || projectDriver === 'mls') return;*/
                    /*if (
                        !json.l5_actionPrjSettings ||
                        !json.l5_actionPrjSettings.projectDriver ||
                        json.l5_actionPrjSettings.projectDriver === 'mls') return;

                    prj.push(p);*/
                }
                catch (e) {
                    //console.info('Erro to parse' + p.name);
                }
            });
            if (prj.length <= 0)
                return;
            const obj = {
                name,
                created_at,
                description,
                key: org,
                projects: prj
            };
            this.state.orgs.push(obj);
        });
    }
    clearState() {
        this.state.history = [];
        this.state.orgs = [];
    }
    loadHistory() {
        const lcHistory = localStorage.getItem('l5-projects-history');
        let rc = [];
        if (!lcHistory)
            return rc;
        try {
            rc = JSON.parse(lcHistory);
        }
        catch (err) {
            throw new Error('Error on load l5 project history');
        }
        return rc;
    }
    _filterProjects(ev) {
        const filterText = ev.target.value;
        clearTimeout(this.filterTimeout);
        this.filterTimeout = setTimeout(() => {
            if (filterText) {
                this.titleList?.forEach((item) => { item.style.display = 'none'; });
                if (this.historieEl)
                    this.historieEl.style.display = 'none';
            }
            else {
                this.titleList?.forEach((item) => { item.style.display = ''; });
                if (this.historieEl)
                    this.historieEl.style.display = 'block';
            }
            this.list?.forEach((li) => {
                li.style.display = '';
                const text = li.querySelector('span')?.innerText;
                if (text && text.toLowerCase().indexOf(filterText.toLowerCase()) < 0)
                    li.style.display = 'none';
            });
        }, 100);
    }
    onAddNewProjectClick() {
        this.changeScenario('add');
    }
    async changeScenario(scenario) {
        this.currentScenario = scenario;
    }
    async onHistoryClick(item) {
        if (!item.doSelect)
            return;
        this.setProjectActual(item.project);
        this.setOrgActual(item.project);
        this._fireEventProjectSelected(item.project);
        this.changeScenario('select');
        await this.loadProjectActual(item.project);
        await mls.stor.server.unzipSourcesIfNeeded(item.project);
        this.openExplore();
    }
    async onProjectClick(item) {
        if (!item.doSelect)
            return;
        this.setProjectActual(item.project);
        this.setOrgActual(item.project);
        this.addOnHistory(item);
        this._fireEventProjectSelected(item.project);
        this.changeScenario('details');
        await this.loadProjectActual(item.project);
        await mls.stor.server.unzipSourcesIfNeeded(item.project);
        this.openExplore();
    }
    openExplore() {
        this.selectLevel(5);
        mls.events.fire([5], ['ProjectSelected'], '');
    }
    setProjectActual(project) {
        mls.actual[5].project = project;
        this.state.projectSelected = project;
        setProjectDetails(project);
        //localStorage.setItem('l5-last-project', project.toString());    
    }
    setOrgActual(project) {
        const orgIndex = mls.l5.getProjectOrgIndex(project);
        mls.l5.setActualOrg(orgIndex);
    }
    _fireEventProjectSelected(project) {
        const params = {
            emitter: 'left',
            value: project
        };
        mls.events.fire(5, ['ProjectSelected'], JSON.stringify(params));
    }
    async loadProjectActual(project) {
        await mls.stor.server.loadProjectInfoIfNeeded(project);
    }
    addOnHistory(item) {
        const indexInHistory = this.state.history.findIndex((his) => his.name === item.name && his.project === item.project);
        if (indexInHistory > -1)
            this.state.history.splice(indexInHistory, 1);
        const historyItem = {
            project: item.project,
            name: item.name,
            doSelect: item.doSelect
        };
        this.state.history.unshift(historyItem);
        if (this.state.history.length > 9)
            this.state.history.pop();
        localStorage.setItem('l5-projects-history', JSON.stringify(this.state.history));
    }
    async onProjectCreated(ev) {
        this.projectCreated = true;
        this.projectCreatedNumber = ev.detail;
        /*setTimeout(() => {
            if (this.buttonSeePrj) this.buttonSeePrj.scrollIntoView();
        }, 150);*/
    }
};
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "projectCreated", void 0);
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "state", void 0);
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "lastPrjId", void 0);
__decorate([
    property({ type: String })
], ServiceExploreProjects100554.prototype, "currentScenario", void 0);
__decorate([
    queryAll('.serviceListProjects .serviceListList li')
], ServiceExploreProjects100554.prototype, "list", void 0);
__decorate([
    queryAll('.serviceListProjects .serviceListTitle')
], ServiceExploreProjects100554.prototype, "titleList", void 0);
__decorate([
    query('.l5-project-list-history')
], ServiceExploreProjects100554.prototype, "historieEl", void 0);
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "activeTab", void 0);
ServiceExploreProjects100554 = __decorate([
    customElement('service-explore-projects-100554')
], ServiceExploreProjects100554);
export { ServiceExploreProjects100554 };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["IMyProject"] = 0] = "IMyProject";
    ETabs[ETabs["IExplore"] = 1] = "IExplore";
})(ETabs || (ETabs = {}));
