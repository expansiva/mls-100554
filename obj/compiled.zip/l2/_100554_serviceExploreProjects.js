/// <mls shortName="serviceExploreProjects" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property, queryAll, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import './_100554_pluginCreateNewProject';
/// **collab_i18n_start**
const message_pt = {
    inDevelopment: 'Em Desenvolvimento',
    noProjectSelected: 'Nenhum projeto selecionado!',
    detailsResume: 'Resumo',
    detailsConnections: 'Conexão',
    detailsBranchs: 'Branchs',
    detailsFiles: 'Arquivos Iniciais',
    detailsFilesDesc: 'Atualiza os arquivos iniciais do projeto, que irão servir para compilar o projeto inicialmente, estes arquivos são criados automaticamente na criação do projeto',
    detailsInfo: 'Info',
    name: 'Nome',
    projectDriver: 'Driver',
    projectOrg: 'Organização',
    projectOwner: 'Proprietário',
    projectCreatedAt: 'Criado em',
    projectURL: 'URL do Projeto',
    designSystems: 'Design systems',
    lastModified: 'Última modificação',
    files: 'Arquivos',
    keyGithub: 'Chave do GitHub',
    project: 'Projeto',
    noProject: 'Nenhum projeto selecionado, por favor selecione.',
    selectProject: 'Selecione o projeto',
    btnChange: 'Alterar',
    btnUpdate: 'Atualizar',
    btnAddNewProject: 'Criar novo projeto',
    btnCreateProject: 'Criar projeto',
    btnRefreshOrg: 'Atualizar',
    btnOpenProject: 'Abrir projeto',
    addProject: 'Novo projeto',
    placeholderFilter: 'Filtro',
    push: 'Permite que os desenvolvedores façam push diretamente para a branch principal.',
    pullRequest: 'Exige que todas as mudanças sejam feitas através de Pull Requests, permitindo revisões de código e aprovação antes da integração na branch principal.',
    projectNameLabel: 'Nome do projeto',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organização',
    visibilityLabel: 'Visibilidade do projeto',
    visibilityPublicOption: 'Público - Qualquer pessoa pode ver este repositório.',
    visibilityPrivateOption: 'Privado - Você escolhe quem pode ver.',
    teamLabel: 'Time',
    loadingAddText1: 'Buscando informações do usuário',
    loadingAddText2: 'Buscando organizações do usuário',
    step1Title: 'Passo 1',
    step2Title: 'Passo 2',
    step3Title: 'Passo 3',
    step1Msg: 'Escolha o driver para carregar suas organizações existentes.',
    step2Msg: 'Agora selecione a organização e o modo de atualização.',
    step3Msg: 'Finalmente, selecione a equipe e a visibilidade do projeto.'
};
const message_en = {
    inDevelopment: 'in development',
    noProjectSelected: 'No project selected!',
    detailsResume: 'Resume',
    detailsConnections: 'Connection',
    detailsBranchs: 'Branchs',
    detailsFiles: 'Files initials',
    detailsFilesDesc: 'Updates the project initial files, which we will use to compile the project initially, these files are created automatically when the project is created',
    detailsInfo: 'Info',
    name: 'Name',
    projectDriver: 'Project Driver',
    projectOrg: 'Organization',
    projectOwner: 'Owner',
    projectCreatedAt: 'CreatedAt',
    projectURL: 'Project URL',
    designSystems: 'Design systems',
    lastModified: 'Last Modified',
    files: 'Files',
    keyGithub: 'Key Github',
    project: 'Project',
    noProject: 'No project selected, please select',
    selectProject: 'Select project',
    btnChange: 'Change',
    btnUpdate: 'Update',
    btnAddNewProject: 'Create new Project',
    btnCreateProject: 'Create project',
    btnRefreshOrg: 'Refresh',
    btnOpenProject: 'Open project',
    addProject: 'New project',
    placeholderFilter: 'Filter',
    push: 'Allows developers to push directly to the main branch.',
    pullRequest: 'Requires all changes to be made through Pull Requests, allowing code reviews and approval before integration into the main branch.',
    projectNameLabel: 'Project name',
    driverNameLabel: 'Driver',
    organizationLabel: 'Organization',
    visibilityLabel: 'Project visibility',
    visibilityPublicOption: 'Public - Anyone can see this repository.',
    visibilityPrivateOption: 'Private - You choose who can see.',
    teamLabel: 'Team',
    loadingAddText1: 'Loading user informations',
    loadingAddText2: 'Loading user organizations',
    step1Title: 'Step 1',
    step2Title: 'Step 2',
    step3Title: 'Step 3',
    step1Msg: 'Choose the driver to load your existing organizations.',
    step2Msg: 'Now select the organization and the update mode.',
    step3Msg: 'Finally select the team and the visibility of the project.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceExploreProjects100554 = class ServiceExploreProjects100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.inFullscreen = false;
        this.projectCreated = false;
        this.state = { history: [], orgs: [], projectSelected: undefined };
        this.currentScenario = 'select';
        this.activeTab = 'IMyProject';
        //----------CONFIG SERVICE------------------
        this.details = {
            icon: '&#xf0b1',
            state: 'background',
            position: 'left',
            tooltip: 'Projects',
            visible: true,
            widget: '_100554_serviceExploreProjects',
            level: [6]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            this.activeTab = op;
        };
        this.menu = {
            title: '',
            actions: {},
            icons: {
                IMyProject: 'My Project;e571',
                IExplore: 'Explore;f542',
            },
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            iconDefault: 'IMyProject',
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.filterTimeout = 0;
        this.projectCreatedNumber = 100554;
    }
    onServiceClick(visible, reinit, el) {
        /*if (visible) {

            if (!this.inFullscreen) {
                //this.setFullScreen(6, 'left')
                this.inFullscreen = false;
            }

        } else if (!visible) {

            if (this.inFullscreen) {
                //this.setFullScreen(6, 'default')
                this.inFullscreen = false;
            }

        }*/
    }
    //----------EVENTS---------------------
    setEvents() {
        mls.events.addEventListener([6], ['ProjectExplore'], (details) => {
            this.openService('_100554_serviceExploreProjects', 'left', 6);
        });
    }
    //----------COMPONENT------------------
    connectedCallback() {
        super.connectedCallback();
        this.setEvents();
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'IMyProject':
                return this.renderMyProject();
            case 'IExplore':
                return this.renderExplore();
            default:
                return html ``;
        }
    }
    renderExplore() {
        return html `<h3 style="padding:2rem">Explore others projects , in development</h3>`;
    }
    renderMyProject() {
        this.getLastProject();
        switch (this.currentScenario) {
            case 'select':
                return html `
                    ${this.renderSelectProject()}
                `;
            case 'add':
                return html `
                    ${this.renderAdd()}
                `;
        }
    }
    renderSelectProject() {
        this.getOrgsAndProjects();
        this.state.history = this.loadHistory();
        return html `
            <div class="scroll-custom l5-project-list">
                <div class="filter-container" style="display:flex">
                    <input style="width:calc(100% - 160px)" type="text" placeholder="Filter" @input=${this._filterProjects}>
                    <button style="margin-left:5px; width:150px;" @click=${this.onAddNewProjectClick}>${this.msg.btnAddNewProject}</button>
                </div>
                <div class="l5-project-list-history" style="${this.state.history.length === 0 ? 'display:none' : 'display: block'}">
                    <div class="serviceListTitle">History</div>
                    <ul class="serviceListList">
                        ${this.state.history.map((his) => html `
                            <li class=${this.lastPrjId && +this.lastPrjId === his.project ? "selected" : ""} >
                                <div>
                                    <span>${his.name + ' (' + his.project.toString() + ')'}</span>
                                </div>
                                <div style="display:flex; gap:1rem;font-size:.8rem">
                                    <span class="linkItem"  @click=${() => { this.onHistoryClick(his); }}>
                                        Select
                                    </span>
                                    <span class="linkItem" @click=${() => this.firedetail(his)}>
                                        Detail
                                    </span>
                                </div>
                            </li>
                        `)}
                    </ul>
                </div>
                <div class="serviceListProjects">
                    ${this.state.orgs.map((org) => {
            return html `
                            <div class="serviceListTitle">${org.key}</div>
                            <ul class="serviceListList">
                                ${org.projects.map((prj) => html `
                                <li class=${this.lastPrjId && +this.lastPrjId === prj.id ? "selected" : ""} >
                                    <div>
                                        <span>${prj.name + ' (' + prj.id.toString() + ')'}</span>
                                    </div>
                                    <div style="display:flex; gap:1rem;font-size:.8rem">
                                        <span class="linkItem"  @click=${() => this.onProjectClick(prj)}>
                                            Select
                                        </span>
                                        <span class="linkItem" @click=${() => this.firedetail(prj)}>
                                            Detail
                                        </span>
                                    </div>
                                </li>
                            `)}
                            </ul>
                            `;
        })}
                
                </div>
            </div>
        `;
    }
    renderAdd() {
        return html `
            <div @click="${this.backScenaryList}" style="padding-left: 1rem; padding-top: .5rem; cursor: pointer;">< Back</div>
            <plugin-create-new-project-100554>
            </plugin-create-new-project-100554>
        `;
        /*return html`
        <collab-new-project-100554 @collab-new-project=${this.onProjectCreated}></collab-new-project-100554>
        <div style="display:flex; justify-content:center;">
            ${this.projectCreated ? html`<button id="button-see-project" >${this.msg.btnOpenProject}</button>` : ''}
        </div>
        `*/
    }
    //----------IMPLEMENTS------------------
    async firedetail(prj) {
        localStorage.setItem('serviceDetail', '{"action":"open", "prj":' + prj.project + '}');
        mls.events.fire(2, 'PluginDetails', JSON.stringify({
            shortName: 'pluginProjectDetail',
            project: 100554
        }), 0);
    }
    backScenaryList() {
        this.changeScenario('select');
    }
    getLastProject() {
        this.lastPrjId = localStorage.getItem('l5-last-project');
        return this.lastPrjId;
    }
    getOrgsAndProjects() {
        this.clearState();
        Object.keys(mls.stor.orgs).forEach((org, index) => {
            const { name, description, created_at, projects } = mls.stor.orgs[org].sett;
            const prj = [];
            projects.forEach((p) => {
                try {
                    const json = JSON.parse(p.value);
                    let projectDriver = '';
                    let projectURL = '';
                    if (!json.projectURL && json.l5_actionPrjSettings) {
                        projectDriver = json.l5_actionPrjSettings.projectDriver || '';
                        projectURL = json.l5_actionPrjSettings.projectURL || '';
                    }
                    else if (json.projectURL) {
                        projectDriver = json.projectDriver || '';
                        projectURL = json.projectURL || '';
                    }
                    if (!projectDriver || !projectURL || projectDriver === 'mls')
                        return;
                    /*if (
                        !json.l5_actionPrjSettings ||
                        !json.l5_actionPrjSettings.projectDriver ||
                        json.l5_actionPrjSettings.projectDriver === 'mls') return;*/
                    prj.push(p);
                }
                catch (e) {
                    //console.info('Erro to parse' + p.name);
                }
            });
            if (prj.length <= 0)
                return;
            const obj = {
                name,
                created_at,
                description,
                key: org,
                projects: prj
            };
            this.state.orgs.push(obj);
        });
    }
    clearState() {
        this.state.history = [];
        this.state.orgs = [];
    }
    loadHistory() {
        const lcHistory = localStorage.getItem('l5-projects-history');
        let rc = [];
        if (!lcHistory)
            return rc;
        try {
            rc = JSON.parse(lcHistory);
        }
        catch (err) {
            throw new Error('Error on load l5 project history');
        }
        return rc;
    }
    _filterProjects(ev) {
        const filterText = ev.target.value;
        clearTimeout(this.filterTimeout);
        this.filterTimeout = setTimeout(() => {
            if (filterText) {
                this.titleList?.forEach((item) => { item.style.display = 'none'; });
                if (this.historieEl)
                    this.historieEl.style.display = 'none';
            }
            else {
                this.titleList?.forEach((item) => { item.style.display = ''; });
                if (this.historieEl)
                    this.historieEl.style.display = 'block';
            }
            this.list?.forEach((li) => {
                li.style.display = '';
                const text = li.querySelector('span')?.innerText;
                if (text && text.toLowerCase().indexOf(filterText.toLowerCase()) < 0)
                    li.style.display = 'none';
            });
        }, 100);
    }
    onAddNewProjectClick() {
        this.changeScenario('add');
    }
    async changeScenario(scenario) {
        this.currentScenario = scenario;
    }
    async onHistoryClick(item) {
        this.setProjectActual(item.project);
        this.setOrgActual(item.project);
        this._fireEventProjectSelected(item.project);
        this.changeScenario('select');
        await this.loadProjectActual(item.project);
        await mls.stor.server.unzipSourcesIfNeeded(item.project);
        this.openExplore();
    }
    async onProjectClick(item) {
        this.setProjectActual(item.id);
        this.setOrgActual(item.id);
        this.addOnHistory(item);
        this._fireEventProjectSelected(item.id);
        this.changeScenario('details');
        await this.loadProjectActual(item.id);
        await mls.stor.server.unzipSourcesIfNeeded(item.id);
        this.openExplore();
    }
    openExplore() {
        this.selectLevel(5);
        mls.events.fire([5], ['ProjectSelected'], '');
    }
    setProjectActual(project) {
        mls.actual[5].project = project;
        this.state.projectSelected = project;
        localStorage.setItem('l5-last-project', project.toString());
    }
    setOrgActual(project) {
        const orgIndex = mls.l5.getProjectOrgIndex(project);
        mls.l5.setActualOrg(orgIndex);
    }
    _fireEventProjectSelected(project) {
        const params = {
            emitter: 'left',
            value: project
        };
        mls.events.fire(5, ['ProjectSelected'], JSON.stringify(params));
    }
    async loadProjectActual(project) {
        await mls.stor.server.loadProjectInfoIfNeeded(project);
    }
    addOnHistory(item) {
        const indexInHistory = this.state.history.findIndex((his) => his.name === item.name && his.project === item.id);
        if (indexInHistory > -1)
            this.state.history.splice(indexInHistory, 1);
        const historyItem = {
            project: item.id,
            name: item.name
        };
        this.state.history.unshift(historyItem);
        if (this.state.history.length > 9)
            this.state.history.pop();
        localStorage.setItem('l5-projects-history', JSON.stringify(this.state.history));
    }
    async onProjectCreated(ev) {
        this.projectCreated = true;
        this.projectCreatedNumber = ev.detail;
        /*setTimeout(() => {
            if (this.buttonSeePrj) this.buttonSeePrj.scrollIntoView();
        }, 150);*/
    }
};
ServiceExploreProjects100554.styles = css `html{font-family:var(--font-family-primary);line-height:1.15}body{margin:0 !important;font-size:20px;font-weight:400;line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);font-family:'Cambria',serif}h1,h2,h3,h4,h5,h6{margin-top:0;margin-bottom:.5rem}hr{box-sizing:content-box;height:0;overflow:visible;margin-top:1rem;border-width:1px 0px 0px;border-right-style:initial;border-bottom-style:initial;border-left-style:initial;border-right-color:initial;border-bottom-color:initial;border-left-color:initial;border-image:initial;border-top-style:solid;border-top-color:rgba(0,0,0,0.1);margin-bottom:1rem}button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}button:hover{background-color:var(--grey-color-light)}summary{cursor:pointer}input,select,textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}table{width:100%;margin-bottom:1rem;color:#212529}table th,table td{padding:.75rem;vertical-align:top;border-top:1px solid #dee2e6}table thead th{vertical-align:bottom;border-bottom:2px solid #dee2e6}table tbody+tbody{border-top:2px solid #dee2e6}.fa{display:inline-block}.fa.fa-file{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' height='1em' viewBox='0 0 384 512'><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M0 64C0 28.7 28.7 0 64 0H224V128c0 17.7 14.3 32 32 32H384V448c0 35.:host(.7) 64-64 64H64c-35.3 0-64-28.7-64-64V64zm384 64H256V0L384 128z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-location-dot{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z' fill='rgb(135,206,250,1)'/></svg>");background-repeat:no-repeat;width:16px;height:16px;background-position-y:center;background-position-x:50%}.fa.fa-rotate-left{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M48.5 224H40c-13.3 0-24-10.7-24-24V72c0-9.7 5.8-18.5 14.8-22.2s19.3-1.7 26.2 5.2L98.6 96.6c87.6-86.5 228.7-86.2 315.8 1c87.5 87.5 87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3c-62.2-62.2-162.7-62.5-225.3-1L185 183c6.9 6.9 8.9 17.2 5.2 26.2s-12.5 14.8-22.2 14.8H48.5z'/></svg>");background-repeat:no-repeat;width:16px;height:16px;background-position-y:center}.fa.fa-bug{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M256 0c53 0 96 43 96 96v3.6c0 15.7-12.7 28.4-28.4 28.4H188.4c-15.7 0-28.4-12.7-28.4-28.4V96c0-53 43-96 96-96zM41.4 105.4c12.5-12.5 32.8-12.5 45.3 0l64 64c.7 .7 1.3 1.4 1.9 2.1c14.2-7.3 30.4-11.4 47.5-11.4H312c17.1 0 33.2 4.1 47.5 11.4c.6-.7 1.2-1.4 1.9-2.1l64-64c12.5-12.5 32.8-12.5 45.3 0s12.5 32.8 0 45.3l-64 64c-.7 .7-1.4 1.3-2.1 1.9c6.2 12 10.1 25.3 11.1 39.5H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H416c0 24.6-5.5 47.8-15.4 68.6c2.2 1.3 4.2 2.9 6 4.8l64 64c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0l-63.1-63.1c-24.5 21.8-55.8 36.2-90.3 39.6V240c0-8.8-7.2-16-16-16s-16 7.2-16 16V479.2c-34.5-3.4-65.8-17.8-90.3-39.6L86.6 502.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3l64-64c1.9-1.9 3.9-3.4 6-4.8C101.5 367.8 96 344.6 96 320H32c-17.7 0-32-14.3-32-32s14.3-32 32-32H96.3c1.1-14.1 5-27.5 11.1-39.5c-.7-.6-1.4-1.2-2.1-1.9l-64-64c-12.5-12.5-12.5-32.8 0-45.3z' fill='rgb(169,3,3,1)'/></svg>");background-repeat:no-repeat;width:10px;background-position-y:center}.fa.fa-unbalanced{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' height='1em' viewBox='0 0 512 512'><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480H40c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24V296c0 13.3 10.7 24 24 24s24-10.7 24-24V184c0-13.3-10.7-24-24-24zm32 224a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z' fill='rgb(249 139 5)'/></svg>");background-repeat:no-repeat;width:16px;height:16px;background-position-y:center}.fa.fa-chevron-right{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:12px;height:12px;background-position-y:center}.fa.fa-undo{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M125.7 160H176c17.7 0 32 14.3 32 32s-14.3 32-32 32H48c-17.7 0-32-14.3-32-32V64c0-17.7 14.3-32 32-32s32 14.3 32 32v51.2L97.6 97.6c87.5-87.5 229.3-87.5 316.8 0s87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3s-163.8-62.5-226.3 0L125.7 160z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-clone{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M272 0H396.1c12.7 0 24.9 5.1 33.9 14.1l67.9 67.9c9 9 14.1 21.2 14.1 33.9V336c0 26.5-21.5 48-48 48H272c-26.5 0-48-21.5-48-48V48c0-26.5 21.5-48 48-48zM48 128H192v64H64V448H256V416h64v48c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V176c0-26.5 21.5-48 48-48z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-file-pen{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M0 64C0 28.7 28.7 0 64 0H224V128c0 17.7 14.3 32 32 32H384V285.7l-86.8 86.8c-10.3 10.3-17.5 23.1-21 37.2l-18.7 74.9c-2.3 9.2-1.8 18.8 1.3 27.5H64c-35.3 0-64-28.7-64-64V64zm384 64H256V0L384 128zM549.8 235.7l14.4 14.4c15.6 15.6 15.6 40.9 0 56.6l-29.4 29.4-71-71 29.4-29.4c15.6-15.6 40.9-15.6 56.6 0zM311.9 417L441.1 287.8l71 71L382.9 487.9c-4.1 4.1-9.2 7-14.9 8.4l-60.1 15c-5.5 1.4-11.2-.2-15.2-4.2s-5.6-9.7-4.2-15.2l15-60.1c1.4-5.6 4.3-10.8 8.4-14.9z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:14px !important;height:17px;background-position-y:center}.fa.fa-trash{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M135.2 17.7L128 32H32C14.3 32 0 46.3 0 64S14.3 96 32 96H416c17.7 0 32-14.3 32-32s-14.3-32-32-32H320l-7.2-14.3C307.4 6.8 296.3 0 284.2 0H163.8c-12.1 0-23.2 6.8-28.6 17.7zM416 128H32L53.2 467c1.6 25.3 22.6 45 47.9 45H346.9c25.3 0 46.3-19.7 47.9-45L416 128z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;width:11px !important;height:17px;background-position-y:center}.fa.fa-ellipsis-vertical{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;background-position-y:center}.fa.fa-ban{background-image:url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 512 512"><!--! Font Awesome Free 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M367.2 412.5L99.5 144.8C77.1 176.1 64 214.5 64 256c0 106 86 192 192 192c41.5 0 79.9-13.1 111.2-35.5zm45.3-45.3C434.9 335.9 448 297.5 448 256c0-106-86-192-192-192c-41.5 0-79.9 13.1-111.2 35.5L412.5 367.2zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256z " fill="rgb(66,65,65,1)"/></svg>');background-repeat:no-repeat;width:17px !important;height:17px;background-position-y:center}.fa.fa-file-signature{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 0C28.7 0 0 28.7 0 64V448c0 35.3 28.7 64 64 64H320c35.3 0 64-28.7 64-64V428.7c-2.7 1.1-5.4 2-8.2 2.7l-60.1 15c-3 .7-6 1.2-9 1.4c-.9 .1-1.8 .2-2.7 .2H240c-6.1 0-11.6-3.4-14.3-8.8l-8.8-17.7c-1.7-3.4-5.1-5.5-8.8-5.5s-7.2 2.1-8.8 5.5l-8.8 17.7c-2.9 5.9-9.2 9.4-15.7 8.8s-12.1-5.1-13.9-11.3L144 381l-9.8 32.8c-6.1 20.3-24.8 34.2-46 34.2H80c-8.8 0-16-7.2-16-16s7.2-16 16-16h8.2c7.1 0 13.3-4.6 15.3-11.4l14.9-49.5c3.4-11.3 13.8-19.1 25.6-19.1s22.2 7.8 25.6 19.1l11.6 38.6c7.4-6.2 16.8-9.7 26.8-9.7c15.9 0 30.4 9 37.5 23.2l4.4 8.8h8.9c-3.1-8.8-3.7-18.4-1.4-27.8l15-60.1c2.8-11.3 8.6-21.5 16.8-29.7L384 203.6V160H256c-17.7 0-32-14.3-32-32V0H64zM256 0V128H384L256 0zM549.8 139.7c-15.6-15.6-40.9-15.6-56.6 0l-29.4 29.4 71 71 29.4-29.4c15.6-15.6 15.6-40.9 0-56.6l-14.4-14.4zM311.9 321c-4.1 4.1-7 9.2-8.4 14.9l-15 60.1c-1.4 5.5 .2 11.2 4.2 15.2s9.7 5.6 15.2 4.2l60.1-15c5.6-1.4 10.8-4.3 14.9-8.4L512.1 262.7l-71-71L311.9 321z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-user{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-calendar-days{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M128 0c17.7 0 32 14.3 32 32V64H288V32c0-17.7 14.3-32 32-32s32 14.3 32 32V64h48c26.5 0 48 21.5 48 48v48H0V112C0 85.5 21.5 64 48 64H96V32c0-17.7 14.3-32 32-32zM0 192H448V464c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V192zm64 80v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V272c0-8.8-7.2-16-16-16H80c-8.8 0-16 7.2-16 16zm128 0v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V272c0-8.8-7.2-16-16-16H208c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V272c0-8.8-7.2-16-16-16H336zM64 400v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V400c0-8.8-7.2-16-16-16H80c-8.8 0-16 7.2-16 16zm144-16c-8.8 0-16 7.2-16 16v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V400c0-8.8-7.2-16-16-16H208zm112 16v32c0 8.8 7.2 16 16 16h32c8.8 0 16-7.2 16-16V400c0-8.8-7.2-16-16-16H336c-8.8 0-16 7.2-16 16z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-book{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M96 0C43 0 0 43 0 96V416c0 53 43 96 96 96H384h32c17.7 0 32-14.3 32-32s-14.3-32-32-32V384c17.7 0 32-14.3 32-32V32c0-17.7-14.3-32-32-32H384 96zm0 384H352v64H96c-17.7 0-32-14.3-32-32s14.3-32 32-32zm32-240c0-8.8 7.2-16 16-16H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16zm16 48H336c8.8 0 16 7.2 16 16s-7.2 16-16 16H144c-8.8 0-16-7.2-16-16s7.2-16 16-16z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-list-check{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M152.1 38.2c9.9 8.9 10.7 24 1.8 33.9l-72 80c-4.4 4.9-10.6 7.8-17.2 7.9s-12.9-2.4-17.6-7L7 113C-2.3 103.6-2.3 88.4 7 79s24.6-9.4 33.9 0l22.1 22.1 55.1-61.2c8.9-9.9 24-10.7 33.9-1.8zm0 160c9.9 8.9 10.7 24 1.8 33.9l-72 80c-4.4 4.9-10.6 7.8-17.2 7.9s-12.9-2.4-17.6-7L7 273c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l22.1 22.1 55.1-61.2c8.9-9.9 24-10.7 33.9-1.8zM224 96c0-17.7 14.3-32 32-32H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H256c-17.7 0-32-14.3-32-32zm0 160c0-17.7 14.3-32 32-32H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H256c-17.7 0-32-14.3-32-32zM160 416c0-17.7 14.3-32 32-32H480c17.7 0 32 14.3 32 32s-14.3 32-32 32H192c-17.7 0-32-14.3-32-32zM48 368a48 48 0 1 1 0 96 48 48 0 1 1 0-96z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-folder-tree{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 32C64 14.3 49.7 0 32 0S0 14.3 0 32v96V384c0 35.3 28.7 64 64 64H256V384H64V160H256V96H64V32zM288 192c0 17.7 14.3 32 32 32H544c17.7 0 32-14.3 32-32V64c0-17.7-14.3-32-32-32H445.3c-8.5 0-16.6-3.4-22.6-9.4L409.4 9.4c-6-6-14.1-9.4-22.6-9.4H320c-17.7 0-32 14.3-32 32V192zm0 288c0 17.7 14.3 32 32 32H544c17.7 0 32-14.3 32-32V352c0-17.7-14.3-32-32-32H445.3c-8.5 0-16.6-3.4-22.6-9.4l-13.3-13.3c-6-6-14.1-9.4-22.6-9.4H320c-17.7 0-32 14.3-32 32V480z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-cube{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M234.5 5.7c13.9-5 29.1-5 43.1 0l192 68.6C495 83.4 512 107.5 512 134.6V377.4c0 27-17 51.2-42.5 60.3l-192 68.6c-13.9 5-29.1 5-43.1 0l-192-68.6C17 428.6 0 404.5 0 377.4V134.6c0-27 17-51.2 42.5-60.3l192-68.6zM256 66L82.3 128 256 190l173.7-62L256 66zm32 368.6l160-57.1v-188L288 246.6v188z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-pen-nib{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M368.4 18.3L312.7 74.1 437.9 199.3l55.7-55.7c21.9-21.9 21.9-57.3 0-79.2L447.6 18.3c-21.9-21.9-57.3-21.9-79.2 0zM288 94.6l-9.2 2.8L134.7 140.6c-19.9 6-35.7 21.2-42.3 41L3.8 445.8c-3.8 11.3-1 23.9 7.3 32.4L164.7 324.7c-3-6.3-4.7-13.3-4.7-20.7c0-26.5 21.5-48 48-48s48 21.5 48 48s-21.5 48-48 48c-7.4 0-14.4-1.7-20.7-4.7L33.7 500.9c8.6 8.3 21.1 11.2 32.4 7.3l264.3-88.6c19.7-6.6 35-22.4 41-42.3l43.2-144.1 2.8-9.2L288 94.6z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-chevron-right{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-plus{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-check{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-pencil{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-cubes{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M290.8 48.6l78.4 29.7L288 109.5 206.8 78.3l78.4-29.7c1.8-.7 3.8-.7 5.7 0zM136 92.5V204.7c-1.3 .4-2.6 .8-3.9 1.3l-96 36.4C14.4 250.6 0 271.5 0 294.7V413.9c0 22.2 13.1 42.3 33.5 51.3l96 42.2c14.4 6.3 30.7 6.3 45.1 0L288 457.5l113.5 49.9c14.4 6.3 30.7 6.3 45.1 0l96-42.2c20.3-8.9 33.5-29.1 33.5-51.3V294.7c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-1.3-.5-2.6-.9-3.9-1.3V92.5c0-23.3-14.4-44.1-36.1-52.4l-96-36.4c-12.8-4.8-26.9-4.8-39.7 0l-96 36.4C150.4 48.4 136 69.3 136 92.5zM392 210.6l-82.4 31.2V152.6L392 121v89.6zM154.8 250.9l78.4 29.7L152 311.7 70.8 280.6l78.4-29.7c1.8-.7 3.8-.7 5.7 0zm18.8 204.4V354.8L256 323.2v95.9l-82.4 36.2zM421.2 250.9c1.8-.7 3.8-.7 5.7 0l78.4 29.7L424 311.7l-81.2-31.1 78.4-29.7zM523.2 421.2l-77.6 34.1V354.8L528 323.2v90.7c0 3.2-1.9 6-4.8 7.3z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-floppy-disk{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 32C28.7 32 0 60.7 0 96V416c0 35.3 28.7 64 64 64H384c35.3 0 64-28.7 64-64V173.3c0-17-6.7-33.3-18.7-45.3L352 50.7C340 38.7 323.7 32 306.7 32H64zm0 96c0-17.7 14.3-32 32-32H288c17.7 0 32 14.3 32 32v64c0 17.7-14.3 32-32 32H96c-17.7 0-32-14.3-32-32V128zM224 288a64 64 0 1 1 0 128 64 64 0 1 1 0-128z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-xmark{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-arrow-up-long{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M214.6 9.4c-12.5-12.5-32.8-12.5-45.3 0l-128 128c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L160 109.3V480c0 17.7 14.3 32 32 32s32-14.3 32-32V109.3l73.4 73.4c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-128-128z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-arrow-down-long{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M169.4 502.6c12.5 12.5 32.8 12.5 45.3 0l128-128c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L224 402.7 224 32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 370.7L86.6 329.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l128 128z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center}.fa.fa-ellipsis-vertical{background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z'/></svg>");background-repeat:no-repeat;width:15px;height:15px;background-position-y:center} :host{font-family:var(--font-family-primary);display:block;height:calc(100% - 55px);overflow:auto;background:var(--bg-primary-color);font-size:var(--font-size-16)} .l5-project-list{font-family:'Charlie Display',-apple-system,BlinkMacSystemFont,'Segoe UI','Roboto','Oxygen','Ubuntu','Fira Sans','Droid Sans','Helvetica Neue',sans-serif;overflow-y:auto;height:calc(100vh - 110px);width:100%;scroll-behavior:smooth} .l5-project-list .filter-container{padding:.5rem} .l5-project-list .serviceListTitle{padding:.3em 1em;list-style-type:none;background:#f7f7f7;color:#000;font-weight:600;cursor:default} .l5-project-list .serviceListList{display:flex;-ms-flex-direction:column;flex-direction:column;padding-left:0} .l5-project-list .serviceListList li{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:.5rem;cursor:pointer;display:flex;justify-content:space-between;align-items:center} .l5-project-list .serviceListList li div{display:flex;gap:.5rem} .l5-project-list .serviceListList li:hover{background:#f7f7f7} .l5-project-list .serviceListList li.selected{background:#e3e3e3} .l5-project-list .serviceListList li .serviceListChanged{color:lightskyblue;font-size:13px;display:flex;justify-content:center;align-items:center} .l5-project-list .serviceListList li .serviceBugChanged{color:#a90303;font-size:13px;display:flex;justify-content:center;align-items:center} .l5-project-list .serviceListList li .linkItem{color:var(--active-color);cursor:pointer} .l5-project-list .serviceListList li .linkItem:hover{text-decoration:underline} #button-see-project{background-color:var(--active-color);color:#fff}`;
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "projectCreated", void 0);
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "state", void 0);
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "lastPrjId", void 0);
__decorate([
    property({ type: String })
], ServiceExploreProjects100554.prototype, "currentScenario", void 0);
__decorate([
    queryAll('.serviceListProjects .serviceListList li')
], ServiceExploreProjects100554.prototype, "list", void 0);
__decorate([
    queryAll('.serviceListProjects .serviceListTitle')
], ServiceExploreProjects100554.prototype, "titleList", void 0);
__decorate([
    query('.l5-project-list-history')
], ServiceExploreProjects100554.prototype, "historieEl", void 0);
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "activeTab", void 0);
ServiceExploreProjects100554 = __decorate([
    customElement('service-explore-projects-100554')
], ServiceExploreProjects100554);
export { ServiceExploreProjects100554 };
