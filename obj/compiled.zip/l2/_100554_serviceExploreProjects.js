/// <mls shortName="serviceExploreProjects" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
/// **collab_i18n_start**
const message_pt = {
    inDevelopment: 'Em Desenvolvimento'
};
const message_en = {
    inDevelopment: 'in development'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceExploreProjects100554 = class ServiceExploreProjects100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.inFullscreen = false;
        this.name = 'Somebody';
        //----------CONFIG SERVICE------------------
        this.details = {
            icon: '&#xf0b1',
            state: 'background',
            position: 'left',
            tooltip: 'Explore Projects',
            visible: true,
            widget: '_100554_serviceExploreProjects',
            level: [6]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Explore Projects',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        //----------IMPLEMENTS------------------
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            if (!this.inFullscreen) {
                this.setFullScreen(6, 'left');
                this.inFullscreen = true;
            }
        }
        else if (!visible) {
            if (this.inFullscreen) {
                this.setFullScreen(6, 'default');
                this.inFullscreen = false;
            }
        }
    }
    //----------EVENTS---------------------
    setEvents() {
        mls.events.addEventListener([6], ['ProjectExplore'], (details) => {
            this.openService('_100554_serviceExploreProjects', 'left', 6);
        });
    }
    //----------COMPONENT------------------
    connectedCallback() {
        this.setEvents();
    }
    render() {
        return html `<h2> ${this.msg.inDevelopment} !</h2>`;
    }
};
ServiceExploreProjects100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceExploreProjects100554.prototype, "name", void 0);
ServiceExploreProjects100554 = __decorate([
    customElement('service-explore-projects-100554')
], ServiceExploreProjects100554);
export { ServiceExploreProjects100554 };
