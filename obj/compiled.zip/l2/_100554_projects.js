/// <mls shortName="projects" project="100554" enhancement="_100554_enhancementLit" groupName="other" folder="" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
let Projects102009 = class Projects102009 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`projects-100554{display:block;padding:2rem;color:#fff}projects-100554 .header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:2rem}projects-100554 .filters{display:flex;gap:.5rem;flex-wrap:wrap}projects-100554 .filter-button{background:#333;border:none;padding:.5rem 1rem;border-radius:1rem;color:#fff;cursor:pointer}projects-100554 .projects-grid{display:grid;grid-template-columns:repeat(auto-fill, minmax(300px, 1fr));gap:1.5rem}projects-100554 .project-card{background:#1e1e1e;border-radius:12px;overflow:hidden;box-shadow:0 4px 10px rgba(0,0,0,0.3);transition:transform .2s}projects-100554 .project-card:hover{transform:scale(1.02)}projects-100554 .thumbnail{width:100%;height:180px;object-fit:cover;background:#444}projects-100554 .card-content{padding:1rem}projects-100554 .project-title{font-size:1.1rem;margin:0 0 .5rem;color:#fff}projects-100554 .project-meta{display:flex;justify-content:end;font-size:.9rem;color:#aaa}projects-100554 .tag{background:#555;padding:.2rem .5rem;border-radius:.5rem;font-size:.75rem;color:#fff}projects-100554 .actions{display:flex;justify-content:space-between;gap:.5rem;margin-top:1rem}projects-100554 .actions a{flex:1;text-align:center;text-decoration:none;background:#2a2a2a;color:white;padding:.5rem;border-radius:6px;transition:background .2s}projects-100554 .actions a:hover{background:#444}projects-100554 .project-details{padding:2rem;margin:2rem auto;color:#000;box-shadow:0 0 15px rgba(0,0,0,0.5)}projects-100554 .back-button{background:none;border:none;font-size:1rem;cursor:pointer;margin-bottom:1rem;color:var(--active-color)}projects-100554 .back-button:hover{text-decoration:underline}projects-100554 .project-details input{width:100%;padding:.5rem;border:1px solid #444;border-radius:4px}projects-100554 .project-details button:not(.back-button){background:var(--text-primary-color);color:#fff;border:none;padding:.5rem 1rem;margin-top:.5rem;cursor:pointer;border-radius:4px}`);
        this.currentView = 'list';
        this.archiveConfirmationText = '';
        this.selectedProject = null;
        this.mockProjects = [
            {
                title: 'Robot',
                type: 'Website',
                remixes: 20454,
                thumbnail: 'https://img.freepik.com/premium-vector/ai-robot-with-chip-processor-website-landing-page_683014-600.jpg',
            },
            {
                title: 'Crypto',
                type: 'Dashboard',
                remixes: 12743,
                thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            },
            {
                title: 'Petshop',
                type: 'Website',
                remixes: 6453,
                thumbnail: 'https://res2.weblium.site/site/60ba356b4f789e0021d15ae8/preview1600_1000',
            },
            {
                title: 'Robot',
                type: 'Website',
                remixes: 20454,
                thumbnail: 'https://img.freepik.com/premium-vector/ai-robot-with-chip-processor-website-landing-page_683014-600.jpg',
            },
            {
                title: 'Crypto',
                type: 'Dashboard',
                remixes: 12743,
                thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            },
            {
                title: 'Petshop',
                type: 'Website',
                remixes: 6453,
                thumbnail: 'https://res2.weblium.site/site/60ba356b4f789e0021d15ae8/preview1600_1000',
            },
            {
                title: 'Robot',
                type: 'Website',
                remixes: 20454,
                thumbnail: 'https://img.freepik.com/premium-vector/ai-robot-with-chip-processor-website-landing-page_683014-600.jpg',
            },
            {
                title: 'Crypto',
                type: 'Dashboard',
                remixes: 12743,
                thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            },
            {
                title: 'Petshop',
                type: 'Website',
                remixes: 6453,
                thumbnail: 'https://res2.weblium.site/site/60ba356b4f789e0021d15ae8/preview1600_1000',
            },
            {
                title: 'Robot',
                type: 'Website',
                remixes: 20454,
                thumbnail: 'https://img.freepik.com/premium-vector/ai-robot-with-chip-processor-website-landing-page_683014-600.jpg',
            },
            {
                title: 'Crypto',
                type: 'Dashboard',
                remixes: 12743,
                thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            },
            {
                title: 'Petshop',
                type: 'Website',
                remixes: 6453,
                thumbnail: 'https://res2.weblium.site/site/60ba356b4f789e0021d15ae8/preview1600_1000',
            },
            {
                title: 'Robot',
                type: 'Website',
                remixes: 20454,
                thumbnail: 'https://img.freepik.com/premium-vector/ai-robot-with-chip-processor-website-landing-page_683014-600.jpg',
            },
            {
                title: 'Crypto',
                type: 'Dashboard',
                remixes: 12743,
                thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
            },
            {
                title: 'Petshop',
                type: 'Website',
                remixes: 6453,
                thumbnail: 'https://res2.weblium.site/site/60ba356b4f789e0021d15ae8/preview1600_1000',
            },
        ];
    }
    render() {
        return html `
    ${this.currentView === 'list'
            ? this.renderProjectList()
            : this.renderProjectDetails()}
  `;
    }
    renderProjectList() {
        return html `
      <div class="header">
        <h2>From the Community</h2>
        <div class="filters">
          <button class="filter-button">Recents</button>
          <button class="filter-button">Prototype</button>
        </div>
      </div>

      <div class="projects-grid">
        ${this.mockProjects.map((project) => html `
            <div class="project-card">
              <img class="thumbnail" src=${project.thumbnail} alt=${project.title} />
              <div class="card-content">
                <div class="project-title">${project.title}</div>
                <div class="project-meta">
                  <div class="actions">
                     <a href="#"> Select </a>
                     <a href="#" @click=${(e) => this.openDetails(e, project)}>⋯</a>
                  </div>
                </div>
              </div>
            </div>
          `)}
      </div>
    `;
    }
    renderProjectDetails() {
        return html `
    <div class="project-details">
      <button class="back-button" @click=${this.goBack}>← Back</button>
      <h2>Project: ${this.selectedProject?.title}</h2>

      <section>
        <h3>Archive</h3>
        <input
          type="text"
          .value=${this.archiveConfirmationText}
          placeholder="deletar permanentemente"
          @input=${(e) => this.archiveConfirmationText = e.target.value}
        />
        <small>archive project ${this.selectedProject?.id} and delete after 30 days</small>
        <br>
        <button @click=${this.confirmArchive}>Confirm Archive</button>
      </section>

      <section>
        <h3>Get Details</h3>
        <small> In develpoment </small>
      </section>
    </div>
  `;
    }
    openDetails(ev, project) {
        ev.preventDefault();
        this.selectedProject = project;
        this.currentView = 'details';
        this.archiveConfirmationText = '';
    }
    goBack() {
        this.currentView = 'list';
        this.selectedProject = null;
        this.archiveConfirmationText = '';
    }
    confirmArchive() {
        const expected = `archive project ${this.selectedProject.id} and delete after 30 days`;
        if (this.archiveConfirmationText.trim().toLowerCase() === expected) {
            alert('Archived!');
            this.goBack();
        }
        else {
            alert('Confirmation text does not match.');
        }
    }
};
__decorate([
    state()
], Projects102009.prototype, "currentView", void 0);
__decorate([
    state()
], Projects102009.prototype, "archiveConfirmationText", void 0);
__decorate([
    state()
], Projects102009.prototype, "selectedProject", void 0);
Projects102009 = __decorate([
    customElement('projects-100554')
], Projects102009);
export { Projects102009 };
