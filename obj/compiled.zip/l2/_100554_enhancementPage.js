/// <mls shortName="enhancementPage" project="100554" enhancement="_100554_enhancementVanilla" />
import { injectStyle } from './_100554_processCssLit';
export const description = "Use this enhancement for pages";
export const example = ``;
export const requires = [];
export const getExample = (project, shortname) => {
    let newExample = example;
    return newExample;
};
export const getDesignDetails = (model) => {
    return new Promise((resolve, reject) => {
        try {
            const ret = {};
            ret.defaultHtmlExamplePreview = '<h1>Simple page</h1>';
            ret.properties = [];
            ret.webComponentDependencies = [];
            ret['servicePreviewDefault'] = '_100554_servicePreview';
            resolve(ret);
        }
        catch (e) {
            reject(e);
        }
    });
};
export const prepareAdd = (prompt) => {
    const aiHeader = ``;
    const aiBody = prompt;
    const aiDelimiter = ':::';
    const sourceTS = '';
    const ret = { sourceTS, aiHeader, aiBody, aiDelimiter };
    return ret;
};
export const onAfterChange = async (mfile) => {
    try {
        return;
    }
    catch (e) {
        return e.message || e;
    }
};
export const getPromptDefault = () => {
    return ``;
};
export const onAfterCompile = async (mfile) => {
    await injectStyle(mfile, 0);
    return;
};
