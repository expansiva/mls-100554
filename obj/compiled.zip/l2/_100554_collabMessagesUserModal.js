/// <mls shortName="collabMessagesUserModal" project="100554" enhancement="_100554_enhancementLit" groupName="other" folder="" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { collab_message } from './_100554_collabIcons';
let CollabMessagesUserModal100554 = class CollabMessagesUserModal100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-user-modal-100554{z-index:9999;position:absolute}collab-messages-user-modal-100554 .collab-messages-user-modal-box{background:var(--bg-primary-color-darker);color:var(--text-primary-color);border-radius:8px;padding:16px;width:280px;font-family:sans-serif;box-shadow:0 4px 12px rgba(0,0,0,0.4)}collab-messages-user-modal-100554 .collab-messages-user-modal-header{display:flex;align-items:center;margin-bottom:12px}collab-messages-user-modal-100554 .collab-messages-user-modal-avatar{width:48px;height:48px;border-radius:4px;margin-right:12px}collab-messages-user-modal-100554 .collab-messages-user-modal-userName{font-weight:bold;font-size:var(--font-size-16)}collab-messages-user-modal-100554 .collab-messages-user-modal-userId{font-size:var(--font-size-12);color:var(--text-primary-color-lighter)}collab-messages-user-modal-100554 .collab-messages-user-modal-userStatus{margin-top:.5rem;font-size:var(--font-size-12);color:var(--grey-color-darker)}collab-messages-user-modal-100554 .collab-messages-user-modal-userStatus.active{color:var(--success-color)}collab-messages-user-modal-100554 .collab-messages-user-modal-actions{display:flex;gap:8px}collab-messages-user-modal-100554 .collab-messages-user-modal-actions button{flex:1;display:flex;align-items:center;justify-content:center;gap:.5rem;padding:6px 8px;border:none;border-radius:4px;cursor:pointer;font-size:14px}collab-messages-user-modal-100554 .collab-messages-user-modal-actions button svg{fill:currentColor}collab-messages-user-modal-100554 .collab-messages-user-modal-message-btn{background:#3F46AD;color:white}`);
        this.open = true;
        this.handleGlobalMouseMove = (e) => {
            const modal = this.querySelector('collab-messages-user-modal-100554');
            if (modal && !modal.contains(e.target)) {
                this.destroy();
            }
        };
    }
    close() {
        this.open = false;
    }
    firstUpdated() {
        document.addEventListener('mousemove', this.handleGlobalMouseMove);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('mousemove', this.handleGlobalMouseMove);
    }
    destroy() {
        this.remove();
    }
    render() {
        if (!this.open)
            return null;
        return html `
        <div class="collab-messages-user-modal-box"
            @mouseover=${(e) => e.stopPropagation()}
            @mouseleave=${(e) => { e.stopPropagation(); this.destroy(); }}
            @click=${(e) => e.stopPropagation()}
        >
            <div class="collab-messages-user-modal-header">
            <img class="collab-messages-user-modal-avatar" src=${this.user?.avatar_url} alt=${this.user?.name} />
                <div>
                    <div class="collab-messages-user-modal-userName">${this.user?.name}<span class="collab-messages-user-modal-userId"> (${this.user?.userId})</span></div>
                    <div class="collab-messages-user-modal-userStatus ${this.user?.status}"> ● ${this.user?.status}</div>
                </div>
            </div>
            <div class="collab-messages-user-modal-actions">
                <button class="collab-messages-user-modal-message-btn">${collab_message} Message</button>
            </div>
        </div>
    
    `;
    }
};
__decorate([
    property({ type: Boolean })
], CollabMessagesUserModal100554.prototype, "open", void 0);
__decorate([
    property()
], CollabMessagesUserModal100554.prototype, "user", void 0);
CollabMessagesUserModal100554 = __decorate([
    customElement('collab-messages-user-modal-100554')
], CollabMessagesUserModal100554);
export { CollabMessagesUserModal100554 };
