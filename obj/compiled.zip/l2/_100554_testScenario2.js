export function _100554_testScenario2_getScenaryDetails() {
    const html = document.createElement('div');
    html.innerHTML = 'Conteudo do cenario 2';
    return {
        description: 'Cenário 2',
        html
    };
}
