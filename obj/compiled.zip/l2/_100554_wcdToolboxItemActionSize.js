/// <mls shortName="wcdToolboxItemActionSize" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, render } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdToolboxItemBase } from './_100554_wcdToolboxItemBase';
//version 4
/// **collab_i18n_start**
const message_pt = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const message_en = {
    margin: 'Margin',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WCDToolboxItemActionSize = class WCDToolboxItemActionSize extends WcdToolboxItemBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.myMsg = messages['en'];
        this.startX = 0;
        this.startY = 0;
        this.startWidth = 0;
        this.startHeight = 0;
        this.timeonChangeProp = -1;
        //---------DRAG----------------------
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
    }
    //------COMPONENT-------------------
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.elMain || !this.myParent)
            return;
        if (this.args && ['all', 'height', 'width'].includes(this.args)) {
            this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
            this.myParent.updateBackgroundAuxSize('show');
            this.onmousedown = (e) => this.initDragging(e);
        }
    }
    render() {
        switch (this.args) {
            case 'height':
                return this.renderOne('height');
            case 'width':
                return this.renderOne('width');
            case 'all':
                return this.renderAll();
            default: return this.renderButton();
        }
    }
    renderButton() {
        this.onclick = (e) => this.clickButton(e);
        this.classList.add('f-button');
        return html `<svg xmlns="http://www.w3.org/2000/svg" height="15px" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M160 64c0-17.7-14.3-32-32-32s-32 14.3-32 32v64H32c-17.7 0-32 14.3-32 32s14.3 32 32 32h96c17.7 0 32-14.3 32-32V64zM32 320c-17.7 0-32 14.3-32 32s14.3 32 32 32H96v64c0 17.7 14.3 32 32 32s32-14.3 32-32V352c0-17.7-14.3-32-32-32H32zM352 64c0-17.7-14.3-32-32-32s-32 14.3-32 32v96c0 17.7 14.3 32 32 32h96c17.7 0 32-14.3 32-32s-14.3-32-32-32H352V64zM320 320c-17.7 0-32 14.3-32 32v96c0 17.7 14.3 32 32 32s32-14.3 32-32V384h64c17.7 0 32-14.3 32-32s-14.3-32-32-32H320z"/></svg>`;
    }
    renderOne(pos) {
        this.classList.add('f-square');
        switch (pos) {
            case 'height':
                this.style.cursor = 'ns-resize';
                break;
            case 'width':
                this.style.cursor = 'ew-resize';
                break;
            default: '';
        }
        return html ``;
    }
    renderAll() {
        return html ``;
    }
    //--------IMPLEMENTATION-------------
    clickButton(e) {
        e.stopPropagation();
        if (!this.myParent)
            return;
        this.myParent.setIconsWcdToolbox([
            {
                name: 'backButton'
            },
            {
                name: 'size',
                args: 'height',
                position: 'p-m3'
            },
            {
                name: 'size',
                args: 'width',
                position: 'p-r2'
            }
        ], false, 'size');
        const params = {
            level: 4,
            position: 'right',
            wdcPath: this.myParent.title,
            op: 'Styles',
        };
        mls.events.fire([4], 'WCDEvent', JSON.stringify(params));
    }
    //------EXTERAL SCENARY----------------
    async renderOutdoorScenary() {
        if (!this.myParent || this.myParent.level !== '4')
            return;
        this.elExternal = await this.myParent.getAndSetScenaryOutDoor('Styles');
        if (!this.elExternal)
            return;
        render(this.renderSize(), this.elExternal);
        setTimeout(() => {
            if (!this.elExternal)
                return;
            const el = this.elExternal.querySelector('#scriptInputRange');
            if (el)
                return;
            const script = document.createElement('script');
            script.src = '/_100554_collabDsInputRange';
            script.id = 'scriptInputRange';
            script.type = 'module';
            this.elExternal.appendChild(script);
        }, 500);
    }
    renderSize() {
        if (!this.elMain)
            return html ``;
        return html `
            <div style="display:flex; flex-direction:column; gap:.5rem ;padding:1rem" class="myAuxGroup">
                <p style=" margin-bottom: 5px;">A <b>width</b> propriedade CSS define a largura de um elemento.<br/>A <b>height</b> propriedade CSS especifica a altura de um elemento.</p>
                <h4 style="display:flex; gap:1.5rem;margin:0px" >Size</h4>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">Width</div>
                    <collab-ds-input-range-100554 prop="width" value="${this.elMain.style.width}" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div>
                <div style="display:flex; gap:.5rem">
                    <div style="width:70px">Height</div>
                    <collab-ds-input-range-100554 prop="height" value="${this.elMain.style.height}" .arraySelect=${this.tpMeasures} @onchange="${(e) => this.onChangeProp(e)}"></collab-ds-input-range-100554>
                </div> 
            </div>
        `;
    }
    onChangeProp(e) {
        const el = e.currentTarget;
        clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = setTimeout(() => {
            this.changeEl(el);
        }, 500);
    }
    changeEl(el) {
        const prop = el.getAttribute('prop');
        if (!prop || !this.elMain || !this.myParent)
            return;
        this.elMain.style[prop] = el.value;
        this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
        this.myParent.updateBackgroundAuxSize('show');
        this.fireEvent();
    }
    initDragging(e) {
        if (!this.elMain || !document.defaultView)
            return;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.startWidth = parseInt(document.defaultView.getComputedStyle(this.elMain).width, 10);
        this.startHeight = parseInt(document.defaultView.getComputedStyle(this.elMain).height, 10);
        const doDragging = (e) => {
            if (!this.elMain || !this.myParent)
                return;
            console.info(this.args);
            if (!this.args || ['all', 'width'].includes(this.args)) {
                this.elMain.style.width = (this.startWidth + e.clientX - this.startX) + 'px';
            }
            if (!this.args || ['all', 'height'].includes(this.args)) {
                this.elMain.style.height = (this.startHeight + e.clientY - this.startY) + 'px';
            }
            this.renderOutdoorScenary();
            this.myParent.updateBaseNoPadding(this.elMain, this.myParent);
            this.myParent.updateBackgroundAuxSize('show');
        };
        const stopDragging = (e) => {
            if (!this.elMain)
                return;
            document.body.removeEventListener('mousemove', doDragging, false);
            document.body.removeEventListener('mouseup', stopDragging, false);
            this.fireEvent();
        };
        document.body.addEventListener('mousemove', doDragging, false);
        document.body.addEventListener('mouseup', stopDragging, false);
    }
    //----------FIRE----------------
    fireEvent(ret = '') {
        if (!this.elMain || !this.myParent)
            return;
        if (ret === '') {
            ret = `width: ${this.elMain.style.width}; height: ${this.elMain.style.height};`;
            if (this.args === 'width')
                ret = `width: ${this.elMain.style.width};`;
            if (this.args === 'height')
                ret = `height: ${this.elMain.style.height};`;
        }
        this.myParent.setStyle(ret);
    }
};
WCDToolboxItemActionSize = __decorate([
    customElement('wcd-toolbox-item-action-size-100554')
], WCDToolboxItemActionSize);
export { WCDToolboxItemActionSize };
