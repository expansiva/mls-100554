/// <mls shortName="collabIcaTree" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement } from 'lit/decorators.js';
import { convertTagToFileName } from './_100554_utilsLit';
import { CollabLitElement } from './_100554_collabLitElement';
export const initCollabICATree = '';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item ICA foi encontrado!'
};
const message_en = {
    noItens: 'No ICA items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabFCATree = class CollabFCATree extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.idLastClick = '';
        this.myCss = `
        collab-ica-tree-100554{
            padding: 1rem;
            display:block;
        }
        collab-ica-tree-100554 ul {
            list-style: none;
            padding: 0px 0rem 0rem .5rem;
            border-left: 1px solid #d4d4d4;
        }

        collab-ica-tree-100554 ul li {
            position: relative;
            user-select:none;

        }

        collab-ica-tree-100554 ul li .header {
            border: 1px solid transparent;
            padding: .4rem;
            cursor: pointer;
        }

        collab-ica-tree-100554 ul li .header:hover {
            border: 1px solid #d4d4d4;

        }

        collab-ica-tree-100554 ul li .header .dragDropcontainer {
            display:none;
            gap:0.5rem;
        }

        collab-ica-tree-100554 ul li .header.overdragdrop {
            display: flex!important;
            justify-content: space-between;
        }

        collab-ica-tree-100554 ul li .header.overdragdrop .dragDropcontainer {
            display:flex;
            gap:0.5rem;
        }

        collab-ica-tree-100554 ul li .header .dragDropcontainer span {
            display: none;
            justify-content: center;
            align-items: center;
            width:20px;
            heigth:20px;
        }

        collab-ica-tree-100554 ul li .header .dragDropcontainer.b .dbefore {
            display: flex!important;
        }

        collab-ica-tree-100554 ul li .header .dragDropcontainer.i .din {
            display: flex!important;
        }

        collab-ica-tree-100554 ul li .header .dragDropcontainer.a .dAfter {
            display: flex!important;
        }

        collab-ica-tree-100554 ul li div.activeBranch{
            border: 1px solid #d4d4d4;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 5px;
            background: #f8f8f8;
        }

        collab-ica-tree-100554 ul li:before {
            content: ' ';
            position: absolute;
            width: 7px;
            height: 1px;
            background: #d4d4d4;
            top: 1.2rem;
            left: -8px;
        }

        collab-ica-tree-100554 .groupHiddenList {
            border-radius: 4px;
            padding: .3rem;
            transition: all 0.5s;
            cursor: pointer;
            display: none; //flex!important;
            z-index: 9;
            height: .7rem;
            
        }

        collab-ica-tree-100554 ul li div.activeBranch .groupHiddenList{
            display: flex;
            align-items: center;
            position: relative;
        }

        collab-ica-tree-100554 .groupHiddenList::after {
            content: ' ';
            width: 23px;
            height: 19px;
            position: absolute;
            right: -15px;
            background-image:  url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");
            background-repeat:no-repeat;
            background-position-y: center;
        }

        collab-ica-tree-100554 .groupHiddenList .mls-gpbtnslider-item {
            display: none;
            transition: 0.5s;
            margin-left: 1rem;
            z-index: 10;
            font-size: 16px;
            line-height: normal;
        }

        collab-ica-tree-100554 .groupHiddenList .mls-gpbtnslider-item:hover {
            color: #1a83ff;
        }
        

        collab-ica-tree-100554 .groupHiddenList.activegpbtnslider {
            padding-right: 24px;
            padding-left: 8px;
        }

        collab-ica-tree-100554 .groupHiddenList.activegpbtnslider .mls-gpbtnslider-item {
            display: inherit;
            text-align: center;
            float: left;
        }
        
    `;
    }
    //--------------COMPONENT---------------
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const ar = this.getICAComponents();
        if (ar && ar.length > 0)
            return this.createNavigation(ar);
        return html `<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
    }
    createNavigation(array) {
        const obj = html `
            <ul>
                ${repeat(array, ((key, idx) => key.el.tagName + idx), ((item, index) => {
            return this.renderItemTree(item, index);
        }))}
            </ul><style>${this.myCss}</style>
        `;
        return obj;
    }
    renderItemTree(item, idx) {
        const name = convertTagToFileName(item.el.tagName.toLocaleLowerCase());
        const cls = item.el.renderType === 'editactive' ? 'activeBranch' : '';
        if (this.idLastClick === name + idx) { // Verifico se preciso forçar um click
            setTimeout(() => {
                const active = this.querySelector('.activeBranch');
                if (active)
                    active.classList.remove('activeBranch');
                this.idLastClick = '';
                item.el.click();
            }, 200);
        }
        let mySymbol = 'fa-cubes';
        if (item.el.mySymbol)
            mySymbol = item.el.mySymbol;
        return html `
            <li>
                <div id="${name + idx}" .info=${item} @mouseover="${this.mouseOver}" @mouseleave="${this.mouseLeave}" class="header ${cls}" @click="${(e) => this.selectItem(e, item)}">
                    <info-item .info=${item}><span class="fa ${mySymbol}" style="margin-right:.5rem"></span>${name}</info-item>
                    <div class="dragDropcontainer">
                        <span class="dbefore fa fa-arrow-up"></span>
                        <span class="din fa fa-arrow-turn-down"></span>
                        <span class="dAfter fa fa-arrow-down"></span>
                    </div>
                    <div class="groupHiddenList" .info=${item} @click="${this.clickGroupHidden}">
                        <span class="mls-gpbtnslider-item fa fa-up-down-left-right" title="move" @click="${this.activeMove}"></span>
                        
                        <span class="mls-gpbtnslider-item fa fa-trash" @click="${this.delEl}" title="remove"></span>
                    </div>
                </div>
                <ul>
                    ${repeat(item.children, ((c, idx) => c.el.tagName + idx), ((i, idxI) => {
            return this.renderItemTree(i, idx + '_' + idxI);
        }))}
                </ul>
            </li>
        `;
        //<span class="mls-gpbtnslider-item fa classLock" @click="${this.setLock}"></span>
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.requestUpdate();
    }
    setServicePreview() {
        if (this.servicePreview || !this.myParent)
            return;
        const nav3 = this.myParent.nav3Service;
        if (!nav3)
            return;
        const wc = nav3.getActiveInstance('right');
        if (!wc)
            return;
        if (wc.tagName.toLowerCase() === 'service-preview-100554') {
            this.servicePreview = wc;
        }
    }
    getICAComponents() {
        this.setServicePreview();
        let ret = [];
        if (!this.servicePreview || !this.servicePreview.parentElement)
            return ret;
        const view = this.servicePreview.parentElement.querySelector('service-preview-view-100554');
        if (!view || !view.shadowRoot)
            return ret;
        const iframe = view.shadowRoot.querySelector('iframe');
        if (!iframe)
            return ret;
        const scope = iframe.contentDocument?.body;
        if (!scope)
            return ret;
        const reentrance = (array, element) => {
            let info;
            const tag = element.tagName.toLowerCase();
            if (tag.startsWith('ica') && !tag.startsWith('ica-page-overlay')) {
                info = { el: element, children: [] };
                array.push(info);
            }
            const isGroup = element.getAttribute('isFCAGroup');
            if (!isGroup || isGroup === 'false') {
                if (element.shadowRoot) {
                    const children = Array.from(element.shadowRoot.children);
                    for (let i = 0; i < children.length; i++) {
                        const child = children[i];
                        reentrance(info ? info.children : array, child);
                    }
                }
                else {
                    const children = Array.from(element.children);
                    for (let i = 0; i < children.length; i++) {
                        const child = children[i];
                        reentrance(info ? info.children : array, child);
                    }
                }
            }
        };
        reentrance(ret, scope);
        return ret;
    }
    selectItem(e, item) {
        e.stopPropagation();
        let target = e.target;
        if (target && target.className.indexOf('header') < 0) {
            target = target.closest('.header');
        }
        if (!target)
            return;
        const active = this.querySelector('.activeBranch');
        if (active && active === target)
            return;
        if (active)
            active.classList.remove('activeBranch');
        target.classList.add('activeBranch');
        item.el.style.border = '';
        const father = item.el.closest('*[rendertype="editactive"]');
        if (father) {
            this.idLastClick = target.id;
            item.el.overlayRef?.click();
            item.el.overlayRef?.scrollIntoView({ block: 'center' });
        }
        else {
            item.el.overlayRef?.click();
            item.el.overlayRef?.scrollIntoView({ block: 'center' });
        }
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        el.classList.toggle('activegpbtnslider');
        if (!el.info)
            return;
        let lock = 'fa-lock-open';
        const isGroup = el.info.el.getAttribute('isFCAGroup');
        if (isGroup || isGroup === 'true') {
            lock = 'fa-lock';
        }
        const group = el.querySelector('.classLock');
        if (group) {
            group.classList.remove('fa-lock');
            group.classList.remove('fa-lock-open');
            group.title = lock === 'fa-lock' ? 'lock' : 'lock open';
            group.classList.add(lock);
        }
    }
    setLock(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const info = el.parentElement.info;
        if (!info)
            return;
        const isGroup = (el.className.indexOf('fa-lock-open') < 0);
        info.el.setAttribute('isFCAGroup', (!isGroup).toString());
        let lock = 'fa-lock-open';
        if (!isGroup) {
            lock = 'fa-lock';
        }
        el.classList.remove('fa-lock');
        el.classList.remove('fa-lock-open');
        el.title = lock === 'fa-lock' ? 'lock' : 'lock open';
        el.classList.add(lock);
        this.requestUpdate();
    }
    delEl(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const info = el.parentElement.info;
        if (!info)
            return;
        info.el.remove();
        this.requestUpdate();
    }
    activeMove(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const info = el.parentElement.info;
        if (!info)
            return;
        const wc = info.el.querySelector('wcd-toolbox-100554');
        if (!wc || !wc.shadowRoot)
            return;
        const move = wc.shadowRoot.querySelector('wcd-toolbox-item-action-move-100554');
        if (move)
            move.click();
        setTimeout(() => {
            this.setDragDrop(info.el);
        }, 500);
    }
    setDragDrop(active) {
        const dragStart = (e, el) => {
            e.stopPropagation();
            if (!el.info)
                return;
            el.style.opacity = '0.4';
        };
        const dragEnter = (e, el) => {
            e.stopPropagation();
            const elLast = this.querySelector('.overdragdrop');
            if (elLast)
                elLast.classList.remove('overdragdrop');
            el.classList.add('overdragdrop');
        };
        const dragLeave = (e, el) => {
            e.stopPropagation();
            //el.classList.remove('overdragdrop');
        };
        const dragOver = (e, el) => {
            e.stopPropagation();
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            return false;
        };
        const dragDrop = (e, el, mode) => {
            e.stopPropagation();
            if (!el.info)
                return;
            mode.click();
            return false;
        };
        const dragEnd = (e, el) => {
            e.stopPropagation();
            try {
                //mls.events.fire(2,'DSStyleChanged','{"emitter":"left"}',500);
                Array.from(listItens).forEach((el) => {
                    el.removeAttribute('draggable');
                    el.classList.remove('overdragdrop');
                    el.style.opacity = '';
                    el.ondragstart = () => { };
                    el.ondragenter = () => { };
                    el.ondragover = () => { };
                    el.ondragleave = () => { };
                    const elbefore = el.querySelector('.dbefore');
                    const elafter = el.querySelector('.dAfter');
                    const elinn = el.querySelector('.din');
                    if (elbefore) {
                        elbefore.removeAttribute('draggable');
                        elbefore.ondrop = (e) => { };
                    }
                    if (elafter) {
                        elafter.removeAttribute('draggable');
                        elafter.ondrop = (e) => { };
                    }
                    if (elinn) {
                        elinn.removeAttribute('draggable');
                        elinn.ondrop = (e) => { };
                    }
                    const cont = el.querySelector('.dragDropcontainer');
                    if (cont) {
                        cont.classList.remove('b');
                        cont.classList.remove('a');
                        cont.classList.remove('i');
                    }
                    if (el.info) {
                        const elBase = el.info.el;
                        if (!elBase)
                            return;
                        if (elBase.getAttribute('renderType') === 'editactive')
                            return;
                        elBase.style.position = '';
                        const content = elBase.querySelector(':scope > wcd-dragdrop-aux');
                        if (!content)
                            return;
                        content.remove();
                    }
                });
            }
            catch (e) {
                this.requestUpdate();
            }
        };
        const addEventsDragAndDrop = (el) => {
            if (!el.info)
                return;
            const rtp = el.info.el.getAttribute('rendertype');
            const wcd = el.info.el.querySelector(':scope > wcd-dragdrop-aux');
            if (!wcd && rtp === 'edit')
                return;
            const before = wcd ? wcd.querySelector('wcd-dragdrop-aux-before') : undefined;
            const after = wcd ? wcd.querySelector('wcd-dragdrop-aux-after') : undefined;
            const inn = wcd ? wcd.querySelector('wcd-dragdrop-aux-in') : undefined;
            const elbefore = el.querySelector('.dbefore');
            const elafter = el.querySelector('.dAfter');
            const elinn = el.querySelector('.din');
            const cont = el.querySelector('.dragDropcontainer');
            if (cont && before)
                cont.classList.add('b');
            if (cont && after)
                cont.classList.add('a');
            if (cont && inn)
                cont.classList.add('i');
            if (active === el.info.el) {
                el.ondragstart = (e) => dragStart(e, el);
            }
            if (active !== el.info.el) {
                el.ondragenter = (e) => dragEnter(e, el);
                el.ondragover = (e) => dragOver(e, el);
                el.ondragleave = (e) => dragLeave(e, el);
                if (before && elbefore) {
                    elbefore.setAttribute('draggable', 'true');
                    elbefore.ondrop = (e) => dragDrop(e, el, before);
                }
                if (after && elafter) {
                    elafter.setAttribute('draggable', 'true');
                    elafter.ondrop = (e) => dragDrop(e, el, after);
                }
                if (inn && elinn) {
                    elinn.setAttribute('draggable', 'true');
                    elinn.ondrop = (e) => dragDrop(e, el, inn);
                }
            }
            el.ondragend = (e) => dragEnd(e, el);
        };
        const listItens = this.querySelectorAll('.header');
        Array.from(listItens).forEach((el) => {
            el.setAttribute('draggable', 'true');
            addEventsDragAndDrop(el);
        });
    }
    mouseOver(e) {
        e.preventDefault();
        e.stopPropagation();
        let el = e.target;
        if (el && el.className.indexOf('header') < 0) {
            el = el.closest('.header');
        }
        let inOver = el.getAttribute('inOver');
        if (!inOver)
            inOver = 'false';
        if (!el || !el.info || inOver === 'true' || el.className.indexOf('activeBranch') >= 0)
            return;
        //el.info.el.style.border = '1px solid blue';
        el.info.el.style.boxShadow = '0px 0px 2px #0909dd';
    }
    mouseLeave(e) {
        e.preventDefault();
        e.stopPropagation();
        let el = e.target;
        if (el && el.className.indexOf('header') < 0) {
            el = el.closest('.header');
        }
        el.removeAttribute('inOver');
        //el.info.el.style.border = '';
        el.info.el.style.boxShadow = '';
    }
};
CollabFCATree = __decorate([
    customElement('collab-ica-tree-100554')
], CollabFCATree);
export { CollabFCATree };
