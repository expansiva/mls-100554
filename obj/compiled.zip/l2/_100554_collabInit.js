/// <mls shortName="collabInit" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
let CollabSelectOneWithDescription100554 = class CollabSelectOneWithDescription100554 extends CollabLitElement {
    get isAnonymoys() { return this.getAttribute('isAnonymous') === 'true'; }
    get avatarUrl() { return this.getAttribute('avatarUrl') || ''; }
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
        this.actualProject = 0;
        this.flags = {
            'en-US': './l3/_100529_/images/estados-unidos.png',
            'pt-BR': './l3/_100529_/images/brasil.png',
        };
        this.actualProject = mls.actual[5].project || 0;
    }
    firstUpdated() {
        this.init();
    }
    render() {
        return html ``;
    }
    /**
     * Initializes the configuration of life cycle for the system.
     */
    init() {
        this.setDriver();
        const language = this.setAndGetBaseUrl();
        this.setHTMLLang(language);
        this.setTheme();
        this.setTokensCss();
        this.enableNav(this.avatarUrl, language, this.isAnonymoys);
    }
    /**
     * Asynchronous method responsible for loading and setting up collaboration drivers.
     */
    async setDriver() {
        if (window.traceLifeCycle)
            console.info('loading: drivers collab');
        await this.instanceDriverGitHub();
    }
    /**
     * Asynchronous method that imports, instantiates, and registers the GitHub driver in the system.
     *
     */
    async instanceDriverGitHub() {
        if (window.traceLifeCycle)
            console.info('loading: driver github');
        const { DriverGitHub } = await import('./_100554_driverGithub');
        const instanceGitHub = new DriverGitHub();
        const driverInstanceGitHub = mls.stor.others.getDriver(instanceGitHub.project, instanceGitHub.shortName);
        if (!driverInstanceGitHub)
            mls.stor.others.addDriver(instanceGitHub);
    }
    setAndGetBaseUrl() {
        if (window.traceLifeCycle)
            console.info('setting: baseUrl');
        const language = this.getUserLanguageOrDefault();
        const base = document.head.querySelector('base');
        if (!base)
            return language;
        const lastHref = base.href;
        const parts = lastHref.split('/');
        parts.pop();
        parts.pop();
        const newHref = parts.join('/') + '/' + language.split('-')[0] + '/';
        base.href = newHref;
        return language;
    }
    getUserLanguageOrDefault() {
        const navigatorLanguage = this.getNavigatorLanguage();
        const acceptLanguages = ['en-US', 'pt-BR'];
        const defaultLang = acceptLanguages.includes(navigatorLanguage) ? navigatorLanguage : 'en-US';
        let rcLanguage = defaultLang;
        const userSettings = localStorage.getItem('userSettings');
        if (userSettings) {
            const data = JSON.parse(userSettings);
            if (data.language && acceptLanguages.includes(data.language)) {
                rcLanguage = data.language;
            }
        }
        return rcLanguage;
    }
    ;
    getNavigatorLanguage() {
        const lg = navigator.language ? navigator.language : '';
        return lg;
    }
    ;
    setHTMLLang(lang) {
        if (window.traceLifeCycle)
            console.info('setting: htmlLang');
        const htmlEl = document.documentElement;
        if (htmlEl)
            htmlEl.lang = lang;
    }
    ;
    setTheme() {
        if (window.traceLifeCycle)
            console.info('setting: theme');
        const theme = this.getTheme();
        const htmlEl = document.documentElement;
        if (theme === 'dark' && htmlEl) {
            htmlEl.setAttribute('data-theme', 'dark');
        }
    }
    ;
    getTheme() {
        let theme = localStorage.getItem('_100554_serviceUserSettings_theme');
        if (!theme || theme === 'default') {
            theme = this.getUserThemeOS();
        }
        return theme;
    }
    ;
    getUserThemeOS() {
        const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        return isDarkMode ? 'dark' : 'light';
    }
    ;
    async setTokensCss() {
        if (window.traceLifeCycle)
            console.info('setting: tokens');
        const cacheDsName = '/local/_100554_ds/collabDesignsystem/collabDesignsystem.json';
        const themeName = 'Default';
        const cacheName = 'mls-v2';
        const cache = await caches.open(cacheName);
        const keys = await cache.keys();
        const match = keys.filter((request) => request.url.includes(cacheDsName));
        if (!match || match.length === 0)
            return;
        const response = await cache.match(match[match.length - 1]);
        if (!response)
            return;
        const responseText = await response.text();
        if (!responseText || typeof responseText !== 'string')
            return;
        const ds = JSON.parse(responseText);
        const tokens = ds.tokens.items;
        if (!tokens || tokens.length === 0)
            return;
        const tokenByTheme = tokens.find((t) => t.themeName === themeName);
        if (!tokenByTheme)
            return;
        let cssLight = ':root {\n';
        let cssDark = '[data-theme="dark"] {\n';
        function convertValue(value) {
            const tokenRegex = /@([a-zA-Z0-9-]+)/g;
            return value.replace(tokenRegex, (_, token) => `var(--${token})`);
        }
        function processCategory(category) {
            Object.entries(category).forEach(([key, value]) => {
                value = convertValue(value);
                if (key.startsWith('_dark-')) {
                    const tokenName = key.replace('_dark-', '');
                    cssDark += `\t--${tokenName}: ${value};\n`;
                }
                else {
                    cssLight += `\t--${key}: ${value};\n`;
                }
            });
        }
        if (tokenByTheme.color)
            processCategory(tokenByTheme.color);
        if (tokenByTheme.typography)
            processCategory(tokenByTheme.typography);
        if (tokenByTheme.global)
            processCategory(tokenByTheme.global);
        cssLight += '}\n';
        cssDark += '}\n';
        const all = cssLight + cssDark;
        const style = document.createElement('style');
        style.textContent = all;
        style.id = 'collab-tokens';
        document.head.appendChild(style);
    }
    ;
    enableNav(avatarUrl, language, isAnonymous) {
        const collabNav1 = document.querySelector('collab-nav-1');
        if (!collabNav1)
            return;
        if (avatarUrl)
            collabNav1.changeIconToImage(7, avatarUrl, { text: language, img: this.flags[language] });
        const state = isAnonymous ? 'anonymous' : 'enabled';
        if (window.traceLifeCycle)
            console.info(`setting: status collab-nav-1 : ${state}`);
        collabNav1.setAttribute('status', state);
    }
    ;
};
CollabSelectOneWithDescription100554 = __decorate([
    customElement('collab-init-100554')
], CollabSelectOneWithDescription100554);
export { CollabSelectOneWithDescription100554 };
