/// <mls shortName="pageTest3" project="100554" enhancement="_blank" />
export const integrations = [];
export const tests = [
    {
        functionName: "test1",
        params: [
            {
                indexSel: 0,
                cnpj: "15.704.863/0001-17",
                action: "save"
            },
        ]
    },
];
export function test1(args) {
    return 'ok, test pass';
}
