/// <mls shortName="wcClarificationAnalyzeNewModule1" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { postBackClarification } from "./_100554_aiAgentOrchestration";
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    cancel: 'Cancelar Task',
    continue: 'Continuar',
    goalPrincipal: 'Objectivo principal',
    entitities: 'Entidades',
    features: 'Características',
    openQuestions: 'Questões abertas',
    constraints: 'Restrições',
    stylePreferences: 'Preferências de estilo',
    brandPersonality: 'Personalidade da Marca',
    toneOfVoice: 'Tom de Voz',
    userPrompt: 'Prompt de alteração',
    sincerityI: 'Frio',
    excitementI: 'Calmo',
    competenceI: 'Amador',
    sophisticationI: 'Simples',
    ruggednessI: 'Leve',
    funny_seriousI: 'Divertido',
    formal_casualI: 'Formal',
    respectful_irreverentI: 'Respeitoso',
    enthusiastic_matterOfFactI: 'Entusiasmado',
    sincerityF: 'Acolhedor',
    excitementF: 'Vibrante',
    competenceF: 'Profissional',
    sophisticationF: 'Elegante',
    ruggednessF: 'Forte',
    funny_seriousF: 'Sério',
    formal_casualF: 'Casual',
    respectful_irreverentF: 'Irreverente',
    enthusiastic_matterOfFactF: 'Neutro',
    promptDesc: 'Digite o prompt para ser reavaliado, esta clarificação será enviado novamente após o processamento'
};
const message_en = {
    loading: 'Loading...',
    cancel: 'Cancel Task',
    continue: 'Continue',
    goalPrincipal: 'Main Goal',
    entitities: 'Entities',
    features: 'Features',
    openQuestions: 'Open Questions',
    constraints: 'Constraints',
    stylePreferences: 'Style Preferences',
    brandPersonality: 'Brand Personality',
    toneOfVoice: 'Tone of Voice',
    userPrompt: 'Change Request',
    sincerityI: 'Cold',
    excitementI: 'Calm',
    competenceI: 'Amateur',
    sophisticationI: 'Plain',
    ruggednessI: 'Light',
    funny_seriousI: 'Funny',
    formal_casualI: 'Formal',
    respectful_irreverentI: 'Respectful',
    enthusiastic_matterOfFactI: 'Enthusiastic',
    sincerityF: 'Warm',
    excitementF: 'Vibrant',
    competenceF: 'Professional',
    sophisticationF: 'Elegant',
    ruggednessF: 'Strong',
    funny_seriousF: 'Serious',
    formal_casualF: 'Casual',
    respectful_irreverentF: 'Irreverent',
    enthusiastic_matterOfFactF: 'Neutral',
    promptDesc: 'Enter the prompt to be re-evaluated, this clarification will be sent again after processing'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let WcClarificationPlannerNewWidget100554 = class WcClarificationPlannerNewWidget100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-clarification-analyze-new-module1-100554{font-family:Arial,sans-serif;padding:20px;font-size:var(--font-size-12)}wc-clarification-analyze-new-module1-100554 input,wc-clarification-analyze-new-module1-100554 select,wc-clarification-analyze-new-module1-100554 textarea{width:100%;display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}wc-clarification-analyze-new-module1-100554 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}wc-clarification-analyze-new-module1-100554 .section{margin-bottom:20px;padding:15px;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,0.1)}wc-clarification-analyze-new-module1-100554 .section h2{margin-top:0;text-transform:capitalize}wc-clarification-analyze-new-module1-100554 .entities form input{margin-bottom:.4rem}wc-clarification-analyze-new-module1-100554 .entities form textarea{margin-bottom:2rem}wc-clarification-analyze-new-module1-100554 .question{margin-bottom:1rem}wc-clarification-analyze-new-module1-100554 .style-preferences label{display:block;font-weight:600;margin:1rem 0 .3rem}wc-clarification-analyze-new-module1-100554 .style-preferences .slider-row{margin:1.5rem 0}wc-clarification-analyze-new-module1-100554 .style-preferences .slider-title{font-weight:bold;margin-bottom:.25rem}wc-clarification-analyze-new-module1-100554 .style-preferences .slider-wrap{display:flex;align-items:center;gap:.5rem}wc-clarification-analyze-new-module1-100554 .style-preferences .slider-label{font-size:.85rem;width:80px;text-align:center}wc-clarification-analyze-new-module1-100554 .style-preferences input[type=range]{width:300px}wc-clarification-analyze-new-module1-100554 .style-preferences .desc{margin-top:.25rem}wc-clarification-analyze-new-module1-100554 .style-preferences h4{text-transform:uppercase;padding-top:1rem;border-bottom:1px solid}wc-clarification-analyze-new-module1-100554 .buttons{margin-top:30px;display:flex;gap:1rem}wc-clarification-analyze-new-module1-100554 .cancel{background-color:var(--warning-color);color:white}wc-clarification-analyze-new-module1-100554 .cancel:hover{background-color:var(--warning-color-hover)}wc-clarification-analyze-new-module1-100554 .continue{background-color:var(--success-color);color:white}wc-clarification-analyze-new-module1-100554 .continue:hover{background-color:var(--success-color-hover)}`);
        this.msg = messages['en'];
        this.develpoment = false;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.develpoment)
            this.setDevelpoment();
        if (!this.data)
            return html `No data finded`;
        return html `
        <div>
            ${Object.keys(this.data.json).map((key) => {
            switch (key) {
                case 'goal':
                    return this.renderGoal(this.data?.json.goal || '');
                case 'entities':
                    return this.renderEntities(this.data?.json.entities || []);
                case 'features':
                    return this.renderFeatures(this.data?.json.features || []);
                case 'openQuestions':
                    return this.renderOpenQuestions(this.data?.json.openQuestions || []);
                case 'stylePreferences':
                    return this.renderStylePreferences(this.data?.json.stylePreferences);
                case 'constraints':
                    return this.renderConstraints(this.data?.json.constraints || []);
            }
        })}
            ${this.renderPromptUser()}
            <div class="buttons">
                <button class="cancel" @click=${this.handleCancel}>${this.msg.cancel}</button>
                <button class="continue" @click=${this.handleOk}>${this.msg.continue}</button>
            </div>

        </div>`;
    }
    renderGoal(goal) {
        return html `
            <div class="section">
                <h2 class="title">${this.msg.goalPrincipal}</h2>
                <p class="desc">${goal}</p>
            </div>
        `;
    }
    renderEntities(entities) {
        return html `
            <div class="section entities">
                <h3>${this.msg.entitities}</h3>
                <form>  
                    ${entities.map((entitie, index) => html `
                        <input
                            type="text"
                            .value="${entitie.name}" 
                            @input=${(e) => this.handleEntetiesNameInput(e, index)}
                        /input>

                        <textarea
                            @input=${(e) => this.handleEntetiesValueInput(e, index)}
                            .value=${entitie.fields.join(', ')}
                        >
                            
                        </textarea>

                    `)}
                </form>     
            </div>
        `;
    }
    renderFeatures(features) {
        return html `
            <div class="section">
                <h3>${this.msg.features}</h3>
                <textarea
                    rows=${features.length}
                    .value = "- ${features.join('\n -')}"
                    @input=${(e) => this.handleFeaturesInput(e, features)}
                    >
                </textarea>
            </div>
        `;
    }
    renderOpenQuestions(openQuestions) {
        return html `
            <div class="section">
                <h3>${this.msg.openQuestions}</h3>
                <form>  
                    ${openQuestions.map((q, index) => html `
                        <div class="question">
                            <span>${q.question}</span>

                            <textarea
                                @input=${(e) => this.handleOpenQuestionsInput(e, index)}
                            >    
                            </textarea>
                        </div>

                    `)}
                </form>  
            </div>
        `;
    }
    renderConstraints(constraints) {
        return html `
            <div class="section">
                <h3>${this.msg.constraints}</h3>
                <textarea
                    rows=${constraints.length}
                    .value = "- ${constraints.join('\n -')}"
                    @input=${(e) => this.handleConstraintsInput(e, constraints)}
                    >
                </textarea>
            </div>
        `;
    }
    renderStylePreferences(preferences) {
        if (!preferences)
            return html ``;
        const keyInitial = {
            sincerity: this.msg.sincerityI,
            excitement: this.msg.excitementI,
            competence: this.msg.competenceI,
            sophistication: this.msg.sophisticationI,
            ruggedness: this.msg.ruggednessI,
            funny_serious: this.msg.funny_seriousI,
            formal_casual: this.msg.formal_casualI,
            respectful_irreverent: this.msg.respectful_irreverentI,
            enthusiastic_matterOfFact: this.msg.enthusiastic_matterOfFactI,
        };
        const keyFinal = {
            sincerity: this.msg.sincerityF,
            excitement: this.msg.excitementF,
            competence: this.msg.competenceF,
            sophistication: this.msg.sophisticationF,
            ruggedness: this.msg.ruggednessF,
            funny_serious: this.msg.funny_seriousF,
            formal_casual: this.msg.formal_casualF,
            respectful_irreverent: this.msg.respectful_irreverentF,
            enthusiastic_matterOfFact: this.msg.enthusiastic_matterOfFactF,
        };
        return html `
            <div class="section style-preferences">
                <h3>${this.msg.stylePreferences}</h3>

                <h4>${this.msg.brandPersonality}</h4>
                ${Object.keys(preferences.brandPersonality).map((key) => {
            return html `
                        <div class="slider-row">
                            <div class="slider-title">${key}</div>
                            <div class="slider-wrap">
                                <span class="slider-label">${keyInitial[key]}</span>
                                <input
                                    type="range"
                                    min="0"
                                    max="100"
                                    @change=${(e) => this.handleBrandPersonalityChange(e, key)}
                                    .value="${preferences.brandPersonality[key].value}" 
                                />
                                <span class="slider-label">${keyFinal[key]}</span>
                            </div>
                            <small class="desc">${preferences.brandPersonality[key].description}</small>
                        </div>`;
        })}

                <h4>${this.msg.toneOfVoice}</h4>
                ${Object.keys(preferences.toneOfVoice).map((key) => {
            return html `
                        <div class="slider-row">
                            <div class="slider-title">${key}</div>
                            <div class="slider-wrap">
                                <span class="slider-label">${keyInitial[key]}</span>
                                <input
                                    type="range"
                                    min="0"
                                    max="100"
                                    @change=${(e) => this.handleToneOfVoiceChange(e, key)}
                                    .value="${preferences.toneOfVoice[key].value}" 
                                />
                                <span class="slider-label">${keyFinal[key]}</span>
                            </div>
                            <small class="desc">${preferences.toneOfVoice[key].description}</small>
                        </div>`;
        })}

            </div>
        `;
    }
    renderPromptUser() {
        return html `
            <div class="section">
                <h2 class="title">${this.msg.userPrompt}</h2>
                <textarea
                    rows=5
                    @input=${(e) => this.handlePromptUserInput(e)}
                    >
                </textarea>
                <p class="desc">${this.msg.promptDesc}</p>
            </div>
        `;
    }
    handlePromptUserInput(e) {
        if (!this.data)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.promptUser = target.value.trim();
    }
    handleFeaturesInput(e, item) {
        if (!this.data || !this.data.json || !this.data.json.features)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.json.features = target.value.trim().split('\n');
    }
    handleConstraintsInput(e, item) {
        if (!this.data || !this.data.json || !this.data.json.constraints)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.json.constraints = target.value.trim().split('\n');
    }
    handleEntetiesNameInput(e, index) {
        if (!this.data || !this.data.json || !this.data.json.entities)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.json.entities[index].name = target.value.trim();
    }
    handleEntetiesValueInput(e, index) {
        if (!this.data || !this.data.json || !this.data.json.entities)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.json.entities[index].fields = target.value.trim().split(',').map(f => f.trim());
    }
    handleOpenQuestionsInput(e, index) {
        if (!this.data || !this.data.json || !this.data.json.openQuestions)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.json.openQuestions[index].userResponse = target.value.trim();
    }
    handleBrandPersonalityChange(e, key) {
        if (!this.data || !this.data.json || !this.data.json.stylePreferences.brandPersonality)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.json.stylePreferences.brandPersonality[key].value = +target.value.trim();
    }
    handleToneOfVoiceChange(e, key) {
        if (!this.data || !this.data.json || !this.data.json.stylePreferences.toneOfVoice)
            throw new Error('Missing keys in json');
        const target = e.target;
        this.data.json.stylePreferences.toneOfVoice[key].value = +target.value.trim();
    }
    handleCancel() {
        this.handleAction('cancel');
    }
    handleOk() {
        this.handleAction('continue');
    }
    async handleAction(action) {
        if (!this.data)
            return;
        console.info(this.data);
        await postBackClarification(action, this.data);
    }
    setDevelpoment() {
        this.data = {
            clarificationMessage: '',
            stepId: 123,
            taskId: '123',
            promptUser: '',
            json: {
                goal: "Desenvolver um site para um petshop que apresente os produtos e serviços oferecidos, facilite o contato com clientes e possibilite vendas online.",
                entities: [
                    { name: "Produto", fields: ["nome", "descrição", "preço", "categoria", "imagem", "estoque"] },
                    { name: "Serviço", fields: ["nome", "descrição", "preço", "duração", "imagem"] },
                    { name: "Cliente", fields: ["nome", "email", "telefone", "endereço", "senha"] },
                    { name: "Pedido", fields: ["cliente", "produtos", "quantidade", "valor total", "status", "data"] },
                    { name: "Contato", fields: ["nome", "email", "mensagem", "data"] }
                ],
                features: [
                    "Catálogo de produtos com busca e filtros",
                    "Página de serviços oferecidos (banho, tosa, consulta veterinária, etc.)",
                    "Carrinho de compras e finalização de pedidos",
                    "Cadastro e login de clientes",
                    "Formulário de contato",
                    "Página institucional (sobre o petshop, missão, valores)",
                    "Integração com meios de pagamento",
                    "Área administrativa para gestão de produtos, serviços e pedidos"
                ],
                openQuestions: [
                    { id: "q1", question: "O site deverá permitir agendamento online de serviços (banho, tosa, consultas)?", userResponse: "você decide" },
                    { id: "q2", question: "Quais métodos de pagamento serão aceitos (cartão, boleto, Pix)?", userResponse: "você decide" },
                    { id: "q3", question: "O site terá integração com redes sociais ou chat online?", userResponse: "você decide" },
                    { id: "q4", question: "Haverá programa de fidelidade ou descontos promocionais?", userResponse: "você decide" },
                    { id: "q5", question: "O site será apenas informativo ou terá e-commerce completo?", userResponse: "você decide" }
                ],
                constraints: [
                    "Deve ser responsivo para dispositivos móveis",
                    "Deve garantir segurança dos dados dos clientes",
                    "Deve ser fácil de atualizar (produtos, serviços, promoções)",
                    "Possível integração com sistemas de estoque ou ERP"
                ],
                stylePreferences: {
                    brandPersonality: {
                        sincerity: {
                            value: 85,
                            description: "Indicates warmth, honesty, and trust. High values suggest soft colors, friendly language, and empathetic tone."
                        },
                        excitement: {
                            value: 60,
                            description: "Measures energy and boldness. Higher values lead to vibrant palettes, fast animations, and youthful aesthetics."
                        },
                        competence: {
                            value: 80,
                            description: "Reflects professionalism and efficiency. High scores imply clean layout, technical precision, and trustworthy tone."
                        },
                        sophistication: {
                            value: 40,
                            description: "Captures elegance and exclusivity. Higher values suggest premium feel, serif fonts, generous spacing, and refined visuals."
                        },
                        ruggedness: {
                            value: 30,
                            description: "Conveys strength and robustness. High values suggest bold fonts, textured backgrounds, and strong visual contrast."
                        }
                    },
                    toneOfVoice: {
                        funny_serious: {
                            value: 30,
                            description: "Low values use humor and playfulness; high values use a formal, authoritative tone in texts and CTAs."
                        },
                        formal_casual: {
                            value: 70,
                            description: "Controls the vocabulary and sentence structure. Low = formal and structured; high = relaxed and conversational."
                        },
                        respectful_irreverent: {
                            value: 20,
                            description: "Defines politeness level. Low = traditional and polite; high = informal, bold, possibly sarcastic copy."
                        },
                        enthusiastic_matterOfFact: {
                            value: 60,
                            description: "Low values are objective and neutral; high values use expressive, motivational tone and dynamic CTAs."
                        }
                    }
                }
            }
        };
    }
};
__decorate([
    property()
], WcClarificationPlannerNewWidget100554.prototype, "data", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], WcClarificationPlannerNewWidget100554.prototype, "develpoment", void 0);
WcClarificationPlannerNewWidget100554 = __decorate([
    customElement('wc-clarification-analyze-new-module1-100554')
], WcClarificationPlannerNewWidget100554);
export { WcClarificationPlannerNewWidget100554 };
