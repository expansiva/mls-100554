/// <mls shortName="collabDOMSync" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export function sync() {
    if (!window.preview.editor || !window.preview.iframe)
        return;
    const model = window.preview.editor.getModel();
    if (!model)
        return;
    const newHTMLOnlyICA = clearTree(window.preview.iframe);
    const formatedNewHTML = formatHtml(newHTMLOnlyICA);
    setValueInModeKeepingUndo2(model, formatedNewHTML);
}
function setValueInModeKeepingUndo2(model, newContent) {
    const editor = window.preview.editor;
    if (!editor)
        throw new Error('No find editor');
    editor.setModel(model);
    const lastLineNumber = model.getLineCount();
    const lastLineLength = model.getLineLength(lastLineNumber);
    const range = new monaco.Range(1, 1, lastLineNumber, lastLineLength + 1);
    editor.pushUndoStop();
    editor.executeEdits('userEdit', [{
            range: range,
            text: newContent
        }]);
    editor.pushUndoStop();
    editor.layout();
}
export function formatHtml(html) {
    const container = document.createElement('div');
    container.innerHTML = html.trim();
    function formatNode(node, indentLevel = 0) {
        const indent = '\t'.repeat(indentLevel);
        const childIndent = '\t'.repeat(indentLevel + 1);
        let formattedHtml = '';
        if (node.nodeType === Node.ELEMENT_NODE) {
            formattedHtml += `${indent}<${node.nodeName.toLowerCase()}`;
            for (const attr of node.attributes) {
                formattedHtml += `\n${childIndent}${attr.name}="${attr.value}"`;
            }
            const isSelfClosing = ['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'keygen', 'link', 'meta', 'param', 'source', 'track', 'wbr'].includes(node.nodeName.toLowerCase());
            if (node.children.length === 0 && isSelfClosing) {
                formattedHtml += ' />';
            }
            else {
                formattedHtml += '>';
                let childHtml = '';
                for (const child of node.childNodes) {
                    const childFormatted = formatNode(child, indentLevel + 1);
                    if (childFormatted) {
                        childHtml += `\n${childFormatted}`;
                    }
                }
                formattedHtml += childHtml;
                formattedHtml += `\n${indent}</${node.nodeName.toLowerCase()}>`;
            }
        }
        else if (node.nodeType === Node.TEXT_NODE) {
            const trimmedText = node.nodeValue.trim();
            if (trimmedText) {
                formattedHtml += (indent + trimmedText);
            }
        }
        return formattedHtml;
    }
    let result = formatNode(container.firstChild);
    result = result
        .split('\n')
        .filter(line => line.trim() !== '')
        .join('\n');
    return result;
}
function getDiffs(originalLines, modifiedLines) {
    const diffs = [];
    originalLines.forEach((line, index) => {
        if (line !== modifiedLines[index]) {
            diffs.push({
                lineNumber: index + 1,
                originalLine: line,
                modifiedLine: modifiedLines[index]
            });
        }
    });
    return diffs;
}
function applyDiffs(originalModel, diffs) {
    const editor = window.preview.editor;
    if (!editor)
        throw new Error('No find editor');
    editor.setModel(originalModel);
    const edits = [];
    diffs.forEach(diff => {
        if (!diff.lineNumber)
            return;
        const lines = originalModel.getLineCount();
        let lineContent = 0;
        if (diff.lineNumber <= lines)
            lineContent = originalModel.getLineLength(diff.lineNumber);
        else
            lineContent = diff.modifiedLine?.length || 0;
        let range;
        range = new monaco.Range(diff.lineNumber, 1, diff.lineNumber, lineContent + 1);
        const edit = {
            range,
            text: diff.modifiedLine || '',
            forceMoveMarkers: true,
        };
        edits.push(edit);
    });
    editor.executeEdits('my-source', edits);
}
function clearTree(iframe) {
    let ret = '';
    const div = document.createElement('div');
    const divRet = document.createElement('div');
    const body = iframe.contentDocument?.body;
    if (!body)
        return ret;
    clearTree2(div, body);
    clearTree3(divRet, div);
    return divRet.innerHTML;
}
function clearTree2(parent, element) {
    const tagname = element.tagName.toLowerCase();
    if (element && element.getAttribute('modeoverlay')) {
        const clone = element.cloneNode(false);
        clone.removeAttribute('style');
        clone.removeAttribute('level');
        parent.appendChild(clone);
        let children = [];
        if (element.shadowRoot)
            children = [...element.shadowRoot.children];
        else
            children = [...element.children];
        for (const child of children) {
            clearTree2(clone, child);
        }
    }
    if (tagname.startsWith('ica-')) {
        const clone = element.cloneNode(false);
        const idEl = clone.id;
        clone.removeAttribute('idel');
        clone.removeAttribute('style');
        clone.removeAttribute('level');
        clone.removeAttribute('rendertype');
        if (idEl && idEl.startsWith('ica_'))
            clone.setAttribute('id', idEl.substring(4, idEl.length));
        parent.appendChild(clone);
        let children = [];
        if (element.shadowRoot)
            children = [...element.shadowRoot.children];
        else
            children = [...element.children];
        for (const child of children) {
            clearTree2(clone, child);
        }
    }
    else {
        let children = [];
        if (element.shadowRoot)
            children = [...element.shadowRoot.children];
        else
            children = [...element.children];
        for (const child of children) {
            clearTree2(parent, child);
        }
    }
    return parent;
}
function clearTree3(parent, element) {
    let children = [...element.children];
    for (const child of children) {
        const tagname = child.tagName.toLowerCase();
        if (tagname.indexOf('-') > 0) {
            const clone = child.cloneNode(false);
            parent.appendChild(clone);
            clearTree3(clone, child);
        }
        else {
            clearTree3(parent, child);
        }
    }
}
