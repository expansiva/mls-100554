/// <mls shortName="wcdPopupItemBold" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { WCDPopupItem } from './_100554_wcdPopupItem';
let WCDPopupItemBold = class WCDPopupItemBold extends WCDPopupItem {
    constructor() {
        super();
        console.log('in wcdPopupItemBold');
        this.label = 'Bold';
    }
    //   static styles = [
    //     WCDPopupItem.styles,
    //     css`
    //       :host {
    //         width: 40px;
    //         height: 40px;
    //         display: inline-flex;
    //         align-items: center;
    //         justify-content: center;
    //       }
    //     `
    //   ];
    // Handle the click event to apply bold to the selected text
    handleClick() {
        document.execCommand('bold', false, undefined);
        console.log(`Clicked: ${this.label}`);
    }
};
WCDPopupItemBold = __decorate([
    customElement('wcd-popup-item-bold-100554')
], WCDPopupItemBold);
export { WCDPopupItemBold };
