/// <mls shortName="wcdPopupItemBold" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WCDPopupItem } from './_100554_wcdPopupItem';
let WCDPopupItemBold = class WCDPopupItemBold extends WCDPopupItem {
    getSvg() {
        return svg `
      <svg width="22" height="22" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" fill="currentColor">
        <text x="3" y="17" font-size="18" font-weight="bold">B</text>
      </svg>
    `;
    }
    render() {
        return html `
      <div @click=${this.handleClick} tabindex="-1">
      ${this.getSvg()}
      </div>
    `;
    }
    handleClick() {
        // execCommand is obsolete, but still in use , ref: https://stackoverflow.com/questions/60581285/execcommand-is-now-obsolete-whats-the-alternative
        document.execCommand('bold', false);
    }
};
WCDPopupItemBold = __decorate([
    customElement('wcd-popup-item-bold-100554')
], WCDPopupItemBold);
export { WCDPopupItemBold };
