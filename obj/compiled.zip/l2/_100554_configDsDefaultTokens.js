/// <mls shortName="configDsDefaultTokens" project="100554" enhancement="_blank" groupName="other" />
import { Common } from './_100554_configDsDefaultCommon';
import { PreCompileLess } from './_100554_configDsDefaultPreCompileLess';
export class Token extends mls.l3.Token {
    constructor(dsIO, ds) {
        super(dsIO);
        this.add = (key, value, category) => this._addToken(key, value, category);
        this.update = (key, newValue) => this._updateToken(key, newValue);
        this.remove = (key) => this._removeToken(key);
        this.find = (key) => this._find(key);
        this.list = {};
        this.getTokensLess = () => this._getTokensLess();
        this.getTokensCss = () => this._getTokensCss();
        this.setTokenList = (tokens) => this._addTokenList(tokens);
        this.getOriginalTokens = () => this._getOriginalTokens();
        this.getThemeList = () => this._getThemeList();
        this.getTheme = (themename) => this._getTheme(themename);
        this.updateTheme = (themename, theme) => this._updateTheme(themename, theme);
        this.removeTheme = (themename) => this._removeTheme(themename);
        this.setTheme = (themename, content) => this._setTheme(themename, content);
        this.ds = ds;
        this.dsIO = dsIO;
        this.methods = new Common(ds, dsIO);
        this.prepareTokens();
    }
    prepareTokens() {
        this.list = {};
        this.ds.tokens.items.forEach((token) => {
            this.list[token.key] = token;
        });
    }
    async _getOriginalTokens() {
        const originalJson = await this.dsIO._getOriginalDsJSON();
        if (!originalJson)
            return this.methods.tokensInitial;
        return originalJson.tokens.items;
    }
    _find(key) {
        return this.list[key];
    }
    async _getThemeList() {
        const keyStarts = `${this._ds.project}_3_ds_cssthemes`;
        const themes = (Object.keys(mls.stor.files).filter((key) => key.startsWith(keyStarts))).map((theme) => mls.stor.files[theme].shortName);
        return themes;
    }
    async _getTheme(themename) {
        const fullpath = this.methods.getDsThemeFilePath();
        const key = mls.stor.getKeyToFiles(this._ds.project, 3, themename, fullpath, '.json');
        const jsonThemes = mls.stor.files[key];
        if (!jsonThemes)
            throw new Error('Theme name dont exist');
        const str = await this.methods.getContentFile(themename, 'json', fullpath);
        const theme = JSON.parse(str);
        return theme;
    }
    async _updateTheme(themename, theme) {
        const fullpath = this.methods.getDsThemeFilePath();
        const key = mls.stor.getKeyToFiles(this._ds.project, 3, themename, fullpath, '.json');
        const jsonThemes = mls.stor.files[key];
        if (!jsonThemes)
            throw new Error('Theme dont exist');
        await this.methods.setContentFile(themename, 'json', fullpath, JSON.stringify(theme));
    }
    async _removeTheme(themename) {
        const fullpath = this.methods.getDsThemeFilePath();
        const key = mls.stor.getKeyToFiles(this._ds.project, 3, themename, fullpath, '.json');
        const jsonThemes = mls.stor.files[key];
        if (!jsonThemes)
            throw new Error('Theme dont exist');
        try {
            await this.methods.setContentFile(themename, 'json', fullpath, null);
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove theme:' + err.message));
        }
    }
    async _setTheme(themename, content) {
        const list = await this.getThemeList();
        if (list.includes(themename))
            throw new Error('This name already used in another theme');
        const fullpath = this.methods.getDsThemeFilePath();
        const key = mls.stor.getKeyToFiles(this._ds.project, 3, themename, fullpath, '.json');
        const jsonThemes = mls.stor.files[key];
        if (!jsonThemes) {
            await this.methods.createNewFile(themename, fullpath, 'json', content);
            return;
        }
        await this.methods.setContentFile(themename, 'json', fullpath, content);
    }
    _getTokensLess() {
        const keys = Object.keys(this.list);
        const tokensLess = keys.map((item) => `@${this.list[item].key}: ${this.list[item].value};`).join('\n');
        return Promise.resolve(tokensLess);
    }
    async _getTokensCss(prefix = ':root') {
        const tokensLess = await this._getTokensLess();
        try {
            const preCompileLess = new PreCompileLess();
            const tokensCss = await preCompileLess.execute('', tokensLess, this.ds.tokens.items, prefix); // mls.l2.compileLess(allLess);
            return tokensCss;
        }
        catch (err) {
            throw new Error(`Error on compile tokens Less: ${err.message}`);
        }
    }
    // private async createOrUpdateFileTokens() {
    //     if (!this.css) this.css = this.dsIO.css;
    //     const name = 'tokens';
    //     const tokensCss = await this.getTokensCss();
    //     const tokensItem = this.css.list[name];
    //     if (!tokensItem) await this.css.add(name, tokensCss);
    //     else await tokensItem.setContent(tokensCss);
    // }
    async _addTokenList(tokens) {
        this.list = {};
        tokens.forEach((token) => {
            this.list[token.key] = token;
        });
        try {
            await this.methods.setContentFileDsMain();
            // await this.createOrUpdateFileTokens();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on add new token:' + err.message));
        }
    }
    async _addToken(key, value, category) {
        const tokenByKey = this.find(key);
        if (tokenByKey)
            throw new Error(`token: ${key} already exists`);
        const token = {
            key,
            value,
            category
        };
        this.list[key] = token;
        try {
            await this.methods.setContentFileDsMain();
            // await this.createOrUpdateFileTokens();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on add new token:' + err.message));
        }
    }
    async _updateToken(key, value) {
        const tokenByKey = this.find(key);
        if (!tokenByKey)
            throw new Error(`token: ${key} dont exists`);
        tokenByKey.value = value;
        try {
            this.list[key] = tokenByKey;
            await this.methods.setContentFileDsMain();
            // await this.createOrUpdateFileTokens();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on update token:' + err.message));
        }
    }
    async _removeToken(key) {
        const tokenByKey = this.find(key);
        if (!tokenByKey)
            throw new Error(`token: ${key} dont exists`);
        delete this.list[key];
        try {
            await this.methods.setContentFileDsMain();
            // await this.createOrUpdateFileTokens();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on remove token:' + err.message));
        }
    }
}
