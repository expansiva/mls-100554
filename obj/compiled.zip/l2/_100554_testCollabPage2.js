/// <mls shortName="testCollabPage2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from './_100554_collabPageElement';
import { customElement } from 'lit/decorators.js';
import { globalState } from './_100554_icaState';
let TestCollabPage2100554 = class TestCollabPage2100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    initPage() {
        if (globalState._ica) {
            globalState._ica = {
                ...globalState._ica,
                ...{
                    users: [{
                            name: 'Wagner',
                            age: 63,
                            city: 'SP',
                            sex: 'm'
                        },
                        {
                            name: 'Guilherme',
                            age: 28,
                            city: 'SP',
                            sex: 'm'
                        }]
                }
            };
        }
        else {
            globalState._ica = {
                users: [{
                        name: 'Wagner',
                        age: 63,
                        city: 'SP',
                        sex: 'm'
                    },
                    {
                        name: 'Guilherme',
                        age: 28,
                        city: 'SP',
                        sex: 'm'
                    }]
            };
        }
    }
    handleClickinput2Desktop() {
        console.log('Click handler desktop for element with ID 2 in page collabPage2');
    }
};
TestCollabPage2100554 = __decorate([
    customElement('test-collab-page2-100554')
], TestCollabPage2100554);
export { TestCollabPage2100554 };
