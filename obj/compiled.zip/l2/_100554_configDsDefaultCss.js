/// <mls shortName="configDsDefaultCss" project="100554" enhancement="_blank" groupName="other" />
import { Common } from './_100554_configDsDefaultCommon';
import { Token } from './_100554_configDsDefaultTokens';
import { PreCompileLess } from './_100554_configDsDefaultPreCompileLess';
export class Css extends mls.l3.Css {
    constructor(dsIO, ds) {
        super(dsIO);
        this.list = {};
        this.add = (name, content) => this._addCss(name, content);
        this.setHTMLPreview = (content) => this._setHTMLPreview(content);
        this.getHTMLPreview = () => this._getHTMLPreview();
        this.find = (name) => this._find(name);
        this.getStylesInLess = () => this._getCssGlobalLess();
        this.cacheCss = {};
        this.ds = ds;
        this.methods = new Common(ds, dsIO);
        this.tokens = new Token(dsIO, ds);
        this.prepareCss();
    }
    prepareCss() {
        this.list = {};
        this.ds.css.items.forEach((css) => {
            this._addCss2(css);
        });
    }
    _find(name) {
        return this.list[name];
    }
    getExtension(name) {
        let ext = 'less';
        if (name === 'tokens')
            ext = 'css';
        return ext;
    }
    async _addCss(name, content) {
        const cssByName = this.find(name);
        if (cssByName)
            throw new Error(`css file: ${name} already exists`);
        const shortName = name;
        const fullpath = this.methods.getDsCssFilePath();
        const css = {
            name,
            getContent: () => { return Promise.resolve(''); },
            setContent: () => { return Promise.resolve(true); }
        };
        try {
            await this.methods.createNewFile(shortName, fullpath, this.getExtension(name), content);
            this._addCss2(css);
            await this.methods.setContentFileDsMain();
            return Promise.resolve();
        }
        catch (err) {
            return Promise.reject(new Error('Error on create new css:' + err.message));
        }
    }
    _addCss2(css) {
        css.getContent = () => this.getCssContent(css);
        css.setContent = (newcontent) => this.setCssContent(css, newcontent);
        this.list[css.name] = css;
    }
    async getCssContent(css) {
        const shortName = css.name;
        const ext = this.getExtension(shortName);
        const fullpath = this.methods.getDsCssFilePath();
        const key = shortName;
        const keyToFile = mls.stor.getKeyToFiles(this._ds.project, 3, shortName, fullpath, `.${ext}`);
        const file = mls.stor.files[keyToFile];
        if (file
            && file.status === 'nochange'
            && this.cacheCss[key] && file.versionRef === this.cacheCss[key].version) {
            return this.cacheCss[key].content;
        }
        const content = await this.methods.getContentFile(shortName, ext, fullpath);
        this.cacheCss[key] = {
            content,
            version: file.versionRef
        };
        return content;
    }
    async setCssContent(css, content) {
        if (content === null)
            Promise.resolve(false);
        const lessTokens = await this.tokens.getTokensLess();
        const fullpath = this.methods.getDsCssFilePath();
        const contentWithLessTokens = content + '\n' + lessTokens;
        const shortName = css.name;
        const ext = this.getExtension(shortName);
        await this.methods.setContentFile(shortName, ext, fullpath, content);
        // await this.methods.setContentFileDsMain();
        return new Promise((resolve, reject) => {
            mls.l2.compileLess(contentWithLessTokens).then(async (res) => {
                this.methods.setFileError(shortName, fullpath, ext, false);
                resolve(true);
            }).catch(async (err) => {
                this.methods.setFileError(shortName, fullpath, ext, true);
                reject(new Error(err.message));
            });
        });
    }
    async _getCssGlobalLess() {
        const preCompileLess = new PreCompileLess();
        const keys = Object.keys(this.list);
        const promisesDsLess = keys.map(async (css) => this.list[css].getContent());
        const resultsDsLess = await Promise.all(promisesDsLess);
        const lessStr = resultsDsLess.join('\n');
        const tokens = await this.tokens.getTokensLess();
        const res = await preCompileLess.execute(lessStr, tokens, this.ds.tokens.items, ':host', false);
        return res;
    }
    async _setHTMLPreview(content) {
        const fullpath = this.methods.getDsCssFilePath();
        const key = mls.stor.getKeyToFiles(this._ds.project, 3, 'preview', fullpath, '.html');
        const previewFile = mls.stor.files[key];
        if (!previewFile) {
            await this.methods.createNewFile('preview', fullpath, 'html', content);
            return;
        }
        await this.methods.setContentFile('preview', 'html', fullpath, content);
    }
    async _getHTMLPreview() {
        const fullpath = this.methods.getDsCssFilePath();
        const key = mls.stor.getKeyToFiles(this._ds.project, 3, 'preview', fullpath, '.html');
        const previewFile = mls.stor.files[key];
        if (!previewFile)
            return '';
        const html = await this.methods.getContentFile('preview', 'html', fullpath);
        return html;
    }
}
