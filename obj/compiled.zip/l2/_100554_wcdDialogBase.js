/// <mls shortName="wcdDialogBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { CollabLitElement } from './_100554_collabLitElement';
export class WcdDialogBase extends CollabLitElement {
    get icaEl() { return undefined; }
    ;
    get wcdOverlayEl() { return this.closest('wcd-toolbox-100554'); }
    ;
}
