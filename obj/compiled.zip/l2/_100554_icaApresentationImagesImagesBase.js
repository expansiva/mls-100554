/// <mls shortName="icaApresentationImagesImagesBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { StateLitElement } from './_100554_stateLitElement';
export class IcaApresentationImagesImagesBase extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(``);
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.src && this.src.startsWith('/') && window['mls']) {
            const newSrc = await this.getUrlL3(this.src);
            if (newSrc)
                this.src = newSrc;
        }
    }
    async getUrlL3(src) {
        //Example Url => /100554/l3/assets/image1 => 100554_3_assets_image1
        const result = src.replace(/^\/(\d+)\/l(\d+)\//, '$1_$2_').replace(/\//g, '_');
        const storFile = mls.stor.files[result];
        if (!storFile)
            throw new Error('Invalid url');
        const urlCache = await storFile.saveContentInCacheIfNeed();
        return urlCache;
    }
}
