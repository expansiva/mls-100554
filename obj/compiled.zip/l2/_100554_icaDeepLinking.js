/// <mls shortName="icaDeepLinking" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { globalState } from './_100554_icaState';
let IcaDeepLinking100554 = class IcaDeepLinking100554 extends IcaLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.params = new Set();
        this.trace = [];
        this.develpoment = false;
        this.timeoutChangePrompt = 0;
    }
    exec(params) {
        this.trace.push(`Find elements in page`);
        this.findAndChangeElementsInPage(params);
    }
    findAndChangeElementsInPage(params) {
        const allElements = document.querySelectorAll('*');
        const pathToChange = this.findParameterReferences(allElements, Array.from(params));
        for (let changes of pathToChange) {
            this.trace.push(`Set state: key => ${changes.key} value => ${changes.value} `);
            globalState.globalStateManagment.setState(changes.key, changes.value);
        }
    }
    findParameterReferences(elements, parameters) {
        const fields = [];
        parameters.forEach(param => {
            const paramName = param.key.split('.').pop(); // Pegando apenas o último nó do nome do parâmetro
            elements.forEach(element => {
                const attributes = element.getAttributeNames();
                attributes.forEach(attribute => {
                    const attributeValue = element.getAttribute(attribute);
                    if (attributeValue) {
                        const matches = attributeValue.match(new RegExp(`{{\\s*[^{}]*\\b${paramName}\\b[^{}]*\\s*}}`, 'g'));
                        if (matches) {
                            matches.forEach(match => {
                                fields.push({
                                    fieldName: `${element.tagName.toLowerCase()}[${attribute}]`,
                                    value: match,
                                    newValue: param.value
                                });
                            });
                        }
                    }
                });
            });
        });
        fields.forEach(field => {
            field.value = field.value.replace(/{{|}}/g, ''); // Remove '{{' , '}}'
        });
        const uniqueValues = {};
        fields.forEach(field => {
            if (!uniqueValues[field.value]) {
                uniqueValues[field.value] = field.newValue;
            }
        });
        return Object.entries(uniqueValues).map(([key, value]) => ({ key, value }));
    }
    setParamsByUrl() {
        this.trace.push(`---------------------------- `);
        this.trace.push(`Set params by url: ${this.url} `);
        if (!this.url)
            return;
        const urlParams = new URLSearchParams(this.url.substring(this.url.indexOf('?') + 1));
        this.params = new Set();
        for (const [key, value] of urlParams) {
            this.params.add({ key, value });
        }
    }
    setParamsByPrompt(value) {
        this.trace.push(`---------------------------- `);
        const jsonParams = JSON.parse(value);
        this.trace.push(`Set params by prompt: ${JSON.stringify(jsonParams)} `);
        this.params = new Set();
        for (const obj of jsonParams) {
            this.params.add({ key: obj.key, value: obj.value });
        }
    }
    createPrompt() {
        return html `
      <textarea
      rows="10"
      style="width:100%;"
      placeholder="Alterar o globalState..."
      .value = ${JSON.stringify(Array.from(this.params), null, 2) || ''}
      @input=${(e) => this.handleChange(e.target.value)}>
    `;
    }
    createDetailsIcon() {
        return html `
      <details>
        <summary>Trace</summary>
        <div style="margin-left:2rem;">
            <pre style="white-space: pre-line;font-size: 12px;">
                ${this.trace.join('\n')}
            </pre>
        </div>

      </details>
    `;
    }
    getAllWebComponentTags() {
        const webComponentTags = [];
        const elements = document.querySelectorAll('*');
        elements.forEach(element => {
            if (element.tagName.includes('-')) {
                webComponentTags.push(element.tagName.toLowerCase());
            }
        });
        return webComponentTags;
    }
    handleChange(inputValue) {
        if (this.timeoutChangePrompt)
            clearTimeout(this.timeoutChangePrompt);
        this.timeoutChangePrompt = setTimeout(() => {
            this.setParamsByPrompt(inputValue);
            this.exec(this.params);
        }, 1000);
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('url')) {
            const allWcs = this.getAllWebComponentTags();
            this.trace.push('Check and waiting all web components defined');
            Promise.all(allWcs.map((wc) => customElements.whenDefined(wc))).then(async () => {
                this.setParamsByUrl();
                this.exec(this.params);
            });
        }
    }
    renderOptional() {
        return html `
            ${this.createPrompt()}
            ${this.createDetailsIcon()}
        `;
    }
    render() {
        return html `${this.develpoment ? this.renderOptional() : ''}`;
    }
};
__decorate([
    property()
], IcaDeepLinking100554.prototype, "url", void 0);
__decorate([
    property()
], IcaDeepLinking100554.prototype, "params", void 0);
__decorate([
    property()
], IcaDeepLinking100554.prototype, "trace", void 0);
__decorate([
    property()
], IcaDeepLinking100554.prototype, "develpoment", void 0);
IcaDeepLinking100554 = __decorate([
    customElement('ica-deep-linking-100554')
], IcaDeepLinking100554);
export { IcaDeepLinking100554 };
