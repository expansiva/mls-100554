/// <mls shortName="collabMessagesTaskInfo" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query, state } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { getClarification } from './_100554_aiAgentOrchestration';
import { getNextPendentStep, getNextClarificationStep, getInteractionStepId, getStepById } from './_100554_aiAgentHelper';
import './_100554_collabMessagesTaskDetails';
import './_100554_pluginTaskPreview';
let WidgetAiInteraction100554 = class WidgetAiInteraction100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-info-100554{display:block;overflow:auto;font-family:var(--font-family-primary);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color);height:100%;padding:0 .5rem}collab-messages-task-info-100554 .tabs{display:flex;border-bottom:1px solid #ccc;margin-bottom:1rem}collab-messages-task-info-100554 .tab{padding:.5rem 1rem;cursor:pointer;border-bottom:2px solid transparent;transition:border-color .3s,color .3s;font-size:.9rem;color:#666}collab-messages-task-info-100554 .tab:hover{color:#000}collab-messages-task-info-100554 .tab.active{border-bottom:2px solid #0078D4;font-weight:600;color:#000}collab-messages-task-info-100554 .content{height:calc(100% - 1rem);padding:.5rem 0}`);
        this.task = undefined;
        this.stepid = '';
        this.seen = new Set();
        this.activeTab = 'workflow';
    }
    async firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (this.interactionClarification) {
            this.setClarification();
        }
    }
    render() {
        if (!this.task)
            return html `No task.`;
        let isClarificationPending = false;
        if (this.task) {
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification')
                isClarificationPending = true;
        }
        if (isClarificationPending)
            return this.renderDirectClarification();
        return this.renderTab();
    }
    renderTab() {
        return html `
            <div style="height: calc(100% - 3rem);">
                <div class="tabs">
                <div
                    class="tab ${this.activeTab === 'workflow' ? 'active' : ''}"
                    @click=${() => this.setTab('workflow')}
                >Workflow</div>
                <div
                    class="tab ${this.activeTab === 'step' ? 'active' : ''}"
                    @click=${() => this.setTab('step')}
                >Step</div>
                <div
                    class="tab ${this.activeTab === 'raw' ? 'active' : ''}"
                    @click=${() => this.setTab('raw')}
                >Raw</div>
                </div>

                <div class="content">
                    ${this.renderTabContent()}
                </div>
            </div>
        `;
    }
    renderTabContent() {
        switch (this.activeTab) {
            case 'workflow': return html `workflow`;
            case 'step': return this.renderStep();
            case 'raw': return this.renderRaw();
            default: return html `workflow`;
        }
    }
    renderRaw() {
        return html `<collab-messages-task-details-100554 .task=${this.task} taskId=${this.task?.PK}></collab-messages-task-details-100554>`;
    }
    renderStep() {
        return html `<plugin-task-preview-100554 .task=${this.task}></plugin-task-preview-100554>`;
    }
    renderDirectClarification() {
        if (!this.task)
            throw new Error('Invalid task');
        const payload = getNextClarificationStep(this.task);
        if (!payload)
            return html ``;
        return html `<div class="direct-clarification">${this.renderClarification(payload)}</div>`;
    }
    renderClarification(payload) {
        if (!this.task)
            return html `Invalid task`;
        const parentInteraction = getInteractionStepId(this.task, payload.stepId);
        if (!parentInteraction)
            return html `No found parentInteraction ${payload.stepId} on task: ${this.task.PK} `;
        const interaction = getStepById(this.task, parentInteraction);
        this.interactionClarification = interaction;
        if (!interaction)
            return html `Invalid interaction id:${parentInteraction} on task: ${this.task.PK} `;
        if (!interaction.agentName)
            return html `Invalid agent name for step id:${interaction.stepId} on task: ${this.task.PK} `;
        return html `<div class="content"> Processing...</div>`;
    }
    //---------IMPLEMENTATION -----------
    async setClarification() {
        if (!this.directClarificationContent || !this.task)
            return;
        const clarification = await getClarification(this.task.PK);
        if (!clarification)
            return;
        this.directClarificationContent.innerHTML = '';
        this.directClarificationContent.appendChild(clarification);
        this.executeHTMLClarificationScript();
    }
    executeHTMLClarificationScript() {
        this.directClarification?.querySelectorAll('script').forEach(oldScript => {
            const newScript = document.createElement('script');
            newScript.type = oldScript.type || 'text/javascript';
            if (!newScript.type) {
                newScript.type = 'text/javascript';
            }
            if (oldScript.hasAttribute('type') && oldScript.getAttribute('type') === 'module') {
                newScript.type = 'module';
            }
            if (oldScript.src) {
                newScript.src = oldScript.src;
            }
            else {
                newScript.textContent = oldScript.textContent;
            }
            oldScript.replaceWith(newScript);
        });
    }
    setTab(tab) {
        this.activeTab = tab;
    }
};
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "task", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "stepid", void 0);
__decorate([
    property({ attribute: false })
], WidgetAiInteraction100554.prototype, "seen", void 0);
__decorate([
    property()
], WidgetAiInteraction100554.prototype, "interactionClarification", void 0);
__decorate([
    query('.direct-clarification')
], WidgetAiInteraction100554.prototype, "directClarification", void 0);
__decorate([
    query('.direct-clarification .content')
], WidgetAiInteraction100554.prototype, "directClarificationContent", void 0);
__decorate([
    state()
], WidgetAiInteraction100554.prototype, "activeTab", void 0);
WidgetAiInteraction100554 = __decorate([
    customElement('collab-messages-task-info-100554')
], WidgetAiInteraction100554);
export { WidgetAiInteraction100554 };
