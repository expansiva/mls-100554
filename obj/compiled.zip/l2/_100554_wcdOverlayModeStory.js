/// <mls shortName="wcdOverlayModeStory" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { WcdOverlayLitBase, getPosition } from './_100554_wcdOverlayLitBase';
import { initWcdOverlayModeStoryItem } from './_100554_wcdOverlayModeStoryItem';
let WcdOverlayModeStory = class WcdOverlayModeStory extends WcdOverlayLitBase {
    constructor() {
        super();
        initWcdOverlayModeStoryItem();
    }
    getActionsTagsDefault() {
        return {
            'events': {
                name: '_100554_wcdToolboxItemActionEvents',
                position: 'p-r1',
                args: '',
                level: [2]
            },
            'backButton': {
                name: 'button',
                position: 'p-r0',
                args: '',
                level: [1, 2, 3, 4, 5, 6]
            },
            'margin': {
                name: '_100554_wcdToolboxItemActionMargin',
                position: 'p-m4',
                args: '',
                level: [4]
            },
            'padding': {
                name: '_100554_wcdToolboxItemActionPadding',
                position: 'p-l4',
                args: '',
                level: [4]
            },
            'size': {
                name: '_100554_wcdToolboxItemActionSize',
                position: 'p-r4',
                args: '',
                level: [4]
            },
            'menu': {
                name: '_100554_wcdToolboxItemActionMenu',
                position: 'p-m1',
                args: '',
                level: [4]
            },
            'add': {
                name: "_100554_wcdAdd",
                level: [2, 4],
                position: 'p-l4',
                args: ''
            },
            'edit': {
                name: "_100554_wcdToolboxItemActionEditText",
                level: [2, 4],
                position: 'p-r4',
                args: ''
            }
        };
    }
    //---------COMPONENT----------------
    firstUpdated() {
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
        this.resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                this.updateSizeOverlayItems();
            }
        });
        this.resizeObserver.observe(this);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('globalVariation') && changedProperties.get('globalVariation') !== undefined) {
            setTimeout(() => this.updateSizeOverlayItems(), 500);
        }
    }
    render() {
        this.style.display = 'block';
        this.style.position = 'absolute';
        this.style.width = '100%';
        this.style.height = 'calc(100% + 55px)'; //'calc(100vh - 50px)';//'100%';
        this.style.zIndex = '9000';
        this.style.top = '0';
        return html ``;
    }
    //---------IMPLEMENTS---------------
    changeOverlayItemsLevel() {
        if (!this)
            return;
        Array.from(this.children).forEach((item) => {
            item.setAttribute('level', this.level);
        });
    }
    createOverlayItems() {
        const boundingPage = this.getBoundingClientRect();
        this.myItens.forEach((item) => {
            item.element.setAttribute('level', this.level);
            this.createOverlayItem(item, this, boundingPage);
        });
    }
    createOverlayItem(icaInfo, content, boundingPage) {
        const icaOverlayItem = document.createElement('wcd-overlay-mode-story-item-100554');
        icaOverlayItem.setAttribute('widget', icaInfo.element.tagName.toLowerCase());
        icaOverlayItem.setAttribute('level', this.level);
        icaOverlayItem.info = icaInfo;
        icaOverlayItem.boundingPage = boundingPage;
        content.appendChild(icaOverlayItem);
    }
    updateSizeOverlayItems() {
        const items = Array.from(this.children);
        const boundingPage = this.getBoundingClientRect();
        items.forEach((item) => {
            if (!item.info)
                return;
            const { x, y, height, width } = item.info.element.getBoundingClientRect();
            item.info.x = x;
            item.info.y = y;
            item.info.height = height;
            item.info.width = width;
            const pos = getPosition(item.info, boundingPage);
            item.style.width = pos.width;
            item.style.height = pos.height;
            item.style.top = pos.top;
            item.style.left = pos.left;
        });
    }
};
WcdOverlayModeStory = __decorate([
    customElement('wcd-overlay-mode-story-100554')
], WcdOverlayModeStory);
export { WcdOverlayModeStory };
