/// <mls shortName="serviceDsComponentDetails" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { initCollabInputTag } from './_100554_collabInputTag';
import { getDSInstance } from './_100554_libDesignSystem';
/// **collab_i18n_start**
const message_pt = {
    noComponentSelected: 'Nenhum componente selecionado',
    component: 'Componente',
    editStyle: 'Editar estilo',
    removeComponent: 'Remover componente',
    group: 'Grupo',
    tags: 'Tags',
};
const message_en = {
    noComponentSelected: 'No component selected',
    component: 'Component',
    editStyle: 'Edit style',
    removeComponent: 'Remove component',
    group: 'Group',
    tags: 'Tags',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceDsComponentDetails100554 = class ServiceDsComponentDetails100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.details = {
            icon: '&#xf1b3',
            state: 'foreground',
            position: 'right',
            tooltip: 'Details Component',
            visible: false,
            tags: ['ds_components'],
            widget: '_100554_serviceDsComponentDetails',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Details Component',
            actions: {},
            icons: {},
            actionDefault: '', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        mls.events.addListener(3, 'DSWidgetsChanged', (ev) => this.onDsWidgetsChanged(ev));
        mls.events.addListener(3, 'DSWidgetsSelected', (ev) => this.onDsWidgetsSelected());
        mls.events.addListener(3, 'DSWidgetsUnSelected', (ev) => this.onDsWidgetsUnSelected());
        initCollabInputTag();
    }
    onServiceClick(visible, reinit, el) {
    }
    onDsWidgetsSelected() {
        this.showNav2Item(true);
        if (this.visible === 'false')
            this.openMe();
    }
    onDsWidgetsUnSelected() {
        this.showNav2Item(false);
    }
    onDsWidgetsChanged(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        if (data.position === this.position)
            return;
        if (!data.value)
            return;
        this.state = { ...data.value };
        this.group = data.value.group;
    }
    onEditStyleClick() {
        if (!this.state)
            return;
        this.openService('_100554_serviceDsStyles', 'left', 3);
        mls.actual[0].setFullName(this.state.name);
        const info = mls.actual[0];
        const rc = {
            emitter: 'right',
            less: '',
            isComponent: true,
            widget: `_${info.project}_${info.path}`,
            helper: '_100554_servicePreview',
            origemLevel: +this.level,
            dsindex: mls.actual[3].mode
        };
        mls.events.fire(3, 'DSStyleChanged', JSON.stringify(rc), 500);
    }
    async removeComponent() {
        if (!this.state)
            return;
        const { project } = mls.actual[5];
        const { mode } = mls.actual[3];
        if (project === undefined || mode === undefined)
            return;
        const ds = await getDSInstance(project, mode);
        await ds.init();
        await ds.components.remove(this.state.name);
        this.state = undefined;
        const params = {
            op: 'update',
            position: this.position,
            value: undefined
        };
        mls.events.fire(3, 'DSWidgetsChanged', JSON.stringify(params), 300);
    }
    async updateComponent() {
        if (!this.state)
            return;
        const { project } = mls.actual[5];
        const { mode } = mls.actual[3];
        if (project === undefined || mode === undefined)
            return;
        const ds = await getDSInstance(project, mode);
        await ds.init();
        await ds.components['update'](this.state.name, this.state);
        const params = {
            op: 'update',
            position: this.position,
            value: undefined
        };
        mls.events.fire(3, 'DSWidgetsChanged', JSON.stringify(params), 300);
    }
    handleInputChangeGroup(event) {
        if (!event || !this.state)
            return;
        const target = event.target;
        if (!target)
            return;
        if (target.value === '')
            return;
        this.state.group = target.value;
        this.group = target.value;
        if (this.timeoutGroup)
            clearTimeout(this.timeoutGroup);
        this.timeoutGroup = setTimeout(() => {
            this.updateComponent();
        }, 1000);
    }
    handleInputChangeTags(value) {
        if (!this.state)
            return;
        this.state.tags = value.split(',');
        this.updateComponent();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        ${!this.state
            ?
                html `<h4>${this.msg.noComponentSelected}!</h4>`
            :
                html `
                <section>
                    <p> ${this.msg.component}: ${this.state?.name}</p>
                    <div class="actions">
                        <button class="edit" @click=${() => this.onEditStyleClick()}>${this.msg.editStyle}</button>
                        <button class="remove" @click=${() => this.removeComponent()}>${this.msg.removeComponent}</button>
                    </div>

                    <div>
                        <label>${this.msg.group}:</label>
                        <br>
                        <input .value=${this.group} @input="${this.handleInputChangeGroup}"></input>
                    </div>
                    <div>
                        <label>${this.msg.tags}:</label>
                        <collab-input-tag-100554 .onValueChanged=${(value) => { this.handleInputChangeTags(value); }} .value=${this.state.tags.join(',')}></collab-input-tag-100554>
                    </div>
                <section>
                
                `}
        `;
    }
};
ServiceDsComponentDetails100554.styles = css `[[mls_getDefaultDesignSystem]]`;
__decorate([
    property()
], ServiceDsComponentDetails100554.prototype, "state", void 0);
__decorate([
    property()
], ServiceDsComponentDetails100554.prototype, "group", void 0);
ServiceDsComponentDetails100554 = __decorate([
    customElement('service-ds-component-details-100554')
], ServiceDsComponentDetails100554);
export { ServiceDsComponentDetails100554 };
