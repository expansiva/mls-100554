/// <mls shortName="serviceUser" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import './_100554_collabPanel';
import './_100554_collabPanelItem';
/// **collab_i18n_start**
const message_pt = {
    installPlugin: 'Explore e adicione novos plug-ins',
};
const message_en = {
    installPlugin: 'Explore and add new plugins',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceUser100554 = class ServiceUser100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(``);
        this.msg = messages['en'];
        this.data = {};
        this.activeTab = 'Settings';
        this.plugin = '';
        this.details = {
            icon: '&#xf4fe',
            state: 'foreground',
            position: 'right',
            tooltip: 'User',
            visible: true,
            widget: '_100554_serviceUser',
            level: [0]
        };
        this.onClickLink = (op) => {
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.onClickIcon = (op) => {
            this.activeTab = op;
        };
        this.menu = {
            title: '',
            actions: {},
            icons: {
                Settings: 'Settings;f013',
            },
            iconDefault: 'Settings',
            iconMenuType: 'full',
            actionDefault: '', // call after close icon clicked
            setMode: undefined,
            updateTitle: undefined,
            getLastMode: undefined,
            lastIcon: undefined,
            setIconActive: undefined,
            onClickLink: this.onClickLink,
            onClickIcon: this.onClickIcon,
        };
    }
    onServiceClick(visible, reinit, el) {
    }
    async updated(changedP) {
        super.updated(changedP);
        if (this.plugin !== "" && this.collabPanel && this.visible === 'true') {
            await this.updateComplete;
            await this.collabPanel.updateComplete;
            const item = this.querySelector(`collab-panel-item-100554[widget="${this.plugin}"]`);
            if (item)
                item.click();
        }
    }
    async firstUpdated() {
        await this.setMyData();
        this.requestUpdate();
        await this.updateComplete;
        if (this.plugin && this.collabPanel) {
            await this.collabPanel.updateComplete;
            const item = this.querySelector(`collab-panel-item-100554[widget="${this.plugin}"]`);
            if (item)
                item.click();
            this.plugin = '';
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'Settings':
                return this.renderSettings();
            default:
                return html ``;
        }
    }
    renderSettings() {
        const keys = Object.keys(this.data);
        return html `
        <div>
            ${repeat(keys, ((key, idx) => key + idx), ((item, index) => {
            return this.renderPanel(item, index);
        }))}
        </div>`;
    }
    renderPanel(key, index) {
        return html `
            <collab-panel-100554 .myData=${this.data[key]}></collab-panel-100554>
        `;
    }
    async setMyData() {
        const prj = mls.actual[5].project;
        if (!prj)
            return;
        let array = [];
        await mls.plugin.loadAll(prj, false);
        array = mls.plugin.getAllMenuActions(prj, { scope: 'l5UserSettings' });
        array.forEach((item) => {
            const cat = item.category;
            item.mode = 'tag';
            if (!this.data[cat])
                this.data[cat] = [item];
            else
                this.data[cat].push(item);
        });
        this.requestUpdate();
    }
};
__decorate([
    property()
], ServiceUser100554.prototype, "activeTab", void 0);
__decorate([
    property()
], ServiceUser100554.prototype, "plugin", void 0);
__decorate([
    query('collab-panel-100554')
], ServiceUser100554.prototype, "collabPanel", void 0);
ServiceUser100554 = __decorate([
    customElement('service-user-100554')
], ServiceUser100554);
export { ServiceUser100554 };
