/// <mls shortName="servicePanel" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
import { loadPluginProject } from './_100554_libCommom';
import './_100554_collabPanel';
let ServicePanel100554 = class ServicePanel100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-panel-100554{display:block;overflow:auto}service-panel-100554 servicePanel{display:flex;background:#ebeff3;flex-direction:column;gap:.5rem;align-items:center;overflow-y:auto}`);
        this.msize = '';
        this.myData = {};
        this.inLoading = 'true';
        this.activeTab = 'ISite';
        //----------SERVICE--------------------
        this.details = {
            icon: '&#xf5ba',
            state: 'foreground',
            position: 'left',
            tooltip: 'Panel',
            visible: true,
            widget: '_100554_servicePanel',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.menu = {
            title: '',
            main: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [
                    { text: 'Site', icon: 'f1c9' },
                    { text: 'History', icon: 'f233' },
                ]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        //----------IMPLEMENTS------------------
        this.timeFilter = 0;
        this.baseProject = 100554;
    }
    onClickMain(op) {
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        this.activeTab = ESceneries[index];
    }
    onServiceClick(visible, reinit, el) {
    }
    //------------COMPONENT-----------------
    firstUpdated(changedProperties) {
        super.updated(changedProperties);
        this.setMyData();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (!this.visible)
            return;
        const [w, h] = this.msize.split(',');
        if (!this.servicePanel)
            return;
        this.servicePanel.style.height = h + 'px';
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'ISite':
                return this.renderSite();
            case 'IHistory':
                return this.renderHistory();
            default:
                return html ``;
        }
    }
    renderHistory() {
        return html `<div style="padding:2rem">History of the latest changes to the website in production - in development</div>`;
    }
    renderSite() {
        if (this.inLoading === 'true') {
            this.loading = true;
            return html ``;
        }
        this.loading = false;
        return this.renderItens();
    }
    renderItens() {
        const keys = Object.keys(this.myData);
        return html `
        <servicePanel>
            ${this.renderFilter()}
            ${repeat(keys, ((key, idx) => key + idx), ((item, index) => {
            return this.renderItem(item, index);
        }))}
        </servicePanel>
        `;
    }
    renderFilter() {
        return html `
            <div style="background:#fff;padding:.2rem;margin-bottom:1rem;margin-top:1rem; width:80%; border:1px solid #dfdfdf; border-radius:10px;display:flex;gap:.2rem">
                <input type="text" @input="${this.filter}"style="border:none;border-right:1px solid #dfdfdf;outline:none;height:25px; width:calc(100% - 30px)" placeholder="Filter plugins ...">
                <svg xmlns="http://www.w3.org/2000/svg" style="width:15px" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg>
            </div>
        `;
    }
    renderItem(key, index) {
        return html `
            <collab-panel-100554 .myData=${this.myData[key]}>
            </collab-panel-100554>
        
        `;
    }
    filter(e) {
        const el = e.target;
        clearTimeout(this.timeFilter);
        this.timeFilter = setTimeout(() => {
            const val = el.value.toLocaleLowerCase();
            const all = this.shadowRoot?.querySelectorAll('collab-panel-item-100554');
            if (!all)
                return;
            Array.from(all).forEach((i) => {
                i.style.display = '';
                const f = i.getAttribute('filter');
                if (f.toLocaleLowerCase().indexOf(val) < 0) {
                    i.style.display = 'none';
                }
            });
        }, 500);
    }
    async setMyData() {
        const prj = mls.actual[5].project;
        if (!prj)
            return;
        let array = await loadPluginProject(prj, 'l5Panel', false);
        array.forEach((item) => {
            const cat = item.category;
            if (!this.myData[cat])
                this.myData[cat] = [item];
            else
                this.myData[cat].push(item);
        });
        this.setAttribute('inLoading', '');
    }
};
__decorate([
    property()
], ServicePanel100554.prototype, "msize", void 0);
__decorate([
    query('servicePanel')
], ServicePanel100554.prototype, "servicePanel", void 0);
__decorate([
    property({ reflect: true })
], ServicePanel100554.prototype, "inLoading", void 0);
__decorate([
    property()
], ServicePanel100554.prototype, "activeTab", void 0);
ServicePanel100554 = __decorate([
    customElement('service-panel-100554')
], ServicePanel100554);
export { ServicePanel100554 };
var ESceneries;
(function (ESceneries) {
    ESceneries[ESceneries["ISite"] = 0] = "ISite";
    ESceneries[ESceneries["IHistory"] = 1] = "IHistory";
})(ESceneries || (ESceneries = {}));
