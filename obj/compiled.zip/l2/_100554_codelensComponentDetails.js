/// <mls shortName="codelensComponentDetails" project="100554" enhancement="_100554_enhancementLit" groupName="internal" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, unsafeHTML } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
export function initCodelensComponentDetails() {
    return true;
}
/// **collab_i18n_start**
const message_pt = {
    usage: 'Uso',
    p1: 'O par�metro mlsComponentDetails � usado para determinar se h� depend�ncias em quaisquer componentes da web. Esta defini��o � importante para o funcionamento/compila��o adequada do componente.<br> Para fazer esta defini��o, use JsDoc no in�cio do arquivo, configurando a tag mlsComponentDetails.'
};
const message_en = {
    usage: 'Usage',
    p1: 'The parameter mlsComponentDetails is used to determine if there are any dependencies on any web components. This definition is important for the proper functioning/compilation of the component.<br> To make this definition, use JsDoc at the beginning of the file, setting the mlsComponentDetails tag.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CodeLensComponentDetails100554 = class CodeLensComponentDetails100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.textCode = `
        /**
         <br>
         * @mlsComponentDetails {"webComponentDependencies": ["my-web-component-100541"]}
        <br>
         */
        <br>
        <br>

        import { html, LitElement } from 'lit';
        <br>
        import { customElement } from 'lit/decorators.js';
        <br>
         <br>
        @customElement('example-100541')
        <br>
        export class Example extends LitElement { [...] }

    `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <h1> mlsComponentDetails</h1>
        <p> ${this.msg.p1} </p>
        
        <hr>
        <h2>${this.msg.usage}:</h2>
        <code>${unsafeHTML(this.textCode)}</code>

        `;
    }
};
CodeLensComponentDetails100554.styles = css `[[mls_getDefaultDesignSystem]]`;
CodeLensComponentDetails100554 = __decorate([
    customElement('codelens-component-details-100554')
], CodeLensComponentDetails100554);
export { CodeLensComponentDetails100554 };
