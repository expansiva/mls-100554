/// <mls shortName="pluginNavigationRenderOrganism" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { PluginBaseModule } from './_100554_pluginBaseModule';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item foi encontrado!'
};
const message_en = {
    noItens: 'No items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginNavigationRenderOrganism = class PluginNavigationRenderOrganism extends PluginBaseModule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-navigation-render-organism-100554{padding:1rem;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-navigation-render-organism-100554 ul{list-style:none;padding:0 0 0 .5rem;border-left:1px solid #d4d4d4}plugin-navigation-render-organism-100554 ul li{position:relative;user-select:none}plugin-navigation-render-organism-100554 ul li small{font-weight:700;font-size:11px}plugin-navigation-render-organism-100554 .dragging{opacity:.5}plugin-navigation-render-organism-100554 .drop-target{background:#d3f9d8}plugin-navigation-render-organism-100554 ul li .header{border:1px solid transparent;padding:.4rem;cursor:pointer}plugin-navigation-render-organism-100554 ul li .header:hover{border:1px solid #d4d4d4}plugin-navigation-render-organism-100554 ul li div.activeBranch{border:1px solid #d4d4d4;display:flex;justify-content:space-between;align-items:center;border-radius:5px;background:var(--bg-primary-color-disabled);color:var(--text-primary-color)}plugin-navigation-render-organism-100554 ul li:before{content:' ';position:absolute;width:7px;height:1px;background:#d4d4d4;top:1.2rem;left:-8px}plugin-navigation-render-organism-100554 .groupHiddenList{border-radius:4px;padding:.3rem;transition:all .5s;cursor:pointer;display:none;z-index:9;height:.7rem}plugin-navigation-render-organism-100554 ul li div.activeBranch .groupHiddenList{display:flex;align-items:center;position:relative}plugin-navigation-render-organism-100554 .groupHiddenList::after{content:' ';width:23px;height:19px;position:absolute;right:-15px;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;background-position-y:center}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item{display:none;transition:.5s;margin-left:1rem;z-index:10;font-size:16px;line-height:normal}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item:hover{color:#1a83ff}plugin-navigation-render-organism-100554 .groupHiddenList.activegpbtnslider{padding-right:24px;padding-left:8px}plugin-navigation-render-organism-100554 .groupHiddenList.activegpbtnslider .mls-gpbtnslider-item{display:inherit;text-align:center;float:left}`);
        this.msg = messages['en'];
        this.atributeBase = 'id';
        //-------COMPONENT----------
        this.activeId = '';
        this.timeFireEventMode = 0;
        this.timeFireSelectEdit = 0;
        this.setEvents();
    }
    setEvents() {
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onlevelChange(ev));
        mls.events.addListener(3, 'L3EditEvents', this.onL3EditEvents.bind(this));
    }
    onL3EditEvents(ev) {
        if (!ev.desc || ev.level !== 3)
            return;
        const info = JSON.parse(ev.desc);
        if (!info || !info.action || !info.position || info.position === 'left')
            return;
        switch (info.action) {
            case ('select'):
                this.onSelect(info);
                break;
            case ('navigation'):
                this.onNavigation(info);
                break;
        }
    }
    onSelect(info) {
        if (!info.id)
            return;
        this.activeId = info.id;
    }
    onNavigation(info) {
        console.info('foi');
        this.requestUpdate();
    }
    onlevelChange(ev) {
        if (!ev.desc)
            return;
        const j = JSON.parse(ev.desc);
        if (j.level === 3) {
            this.forceUpdate();
        }
    }
    createRenderRoot() {
        return this;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const ar = this.getComponents();
        this.fireEventMode('edit');
        if (ar && ar.length > 0)
            return this.createNavigation(ar);
        return html `<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
    }
    createNavigation(array) {
        const obj = html `
            
            <ul>
                ${repeat(array, ((key, idx) => key.id), ((item, index) => { return this.renderItemTree(item, index); }))}
            </ul>
        `;
        return obj;
    }
    renderItemTree(item, idx) {
        const cls = item.el.id === this.activeId || item.el.hasAttribute('clb_mode') ? 'activeBranch' : '';
        let mySymbol = 'fa-cubes';
        if (item.el.mySymbol)
            mySymbol = item.el.mySymbol;
        return html `
            <li>
                <div 
                    .info=${item}
                    id="${item.el.tagName.toLocaleLowerCase() + idx}"                      
                    class="header ${cls}" 
                    @click="${(e) => this.selectItem(e, item)}" 
                    @mouseover="${(e) => this.onMouseover(item)}"
                    @mouseout="${(e) => this.onMouseout(item)}"   
                >
                    <info-item .info=${item}>
                        <span class="fa ${mySymbol}" style="margin-right:.5rem"></span>
                        ${item.el.tagName.toLocaleLowerCase()}<small>(${item.el.id})</small>
                    </info-item>
                    <div class="groupHiddenList" .info=${item}  @click="${this.clickGroupHidden}" >
                        <span class="mls-gpbtnslider-item fa fa-trash" @click="${this.delEl}" title="remove"></span>
                    </div>
                </div>
                <ul>
                    ${repeat(item.children, ((c, idx) => c.el.tagName + idx), ((i, idxI) => { return this.renderItemTree(i, idx + '_' + idxI); }))}
                </ul>
            </li>
        `;
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.requestUpdate();
    }
    getComponents() {
        const lessTags = ['script', 'style', 'body', 'head', 'html'];
        let ret = [];
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return ret;
        const reentrance = (array, element) => {
            let info;
            if (element.getAttribute(this.atributeBase) && !lessTags.includes(element.tagName.toLocaleLowerCase())) {
                info = { el: element, id: element.id, children: [] };
                array.push(info);
            }
            if (element.shadowRoot) {
                const children = Array.from(element.shadowRoot.children);
                for (let i = 0; i < children.length; i++) {
                    const child = children[i];
                    reentrance(info ? info.children : array, child);
                }
            }
            else {
                const children = Array.from(element.children);
                for (let i = 0; i < children.length; i++) {
                    const child = children[i];
                    reentrance(info ? info.children : array, child);
                }
            }
        };
        reentrance(ret, scope);
        return ret;
    }
    selectItem(e, item) {
        e.stopPropagation();
        let target = e.target;
        if (target && target.className.indexOf('header') < 0) {
            target = target.closest('.header');
        }
        if (!target)
            return;
        const active = this.querySelector('.activeBranch');
        if (active && active === target) {
            return;
        }
        if (active)
            active.classList.remove('activeBranch');
        target.classList.add('activeBranch');
        this.fireSelectEdit(item.id);
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        el.classList.toggle('activegpbtnslider');
        if (!el.info)
            return;
        let lock = 'fa-lock-open';
        const isGroup = el.info.el.getAttribute('isFCAGroup');
        if (isGroup || isGroup === 'true') {
            lock = 'fa-lock';
        }
        const group = el.querySelector('.classLock');
        if (group) {
            group.classList.remove('fa-lock');
            group.classList.remove('fa-lock-open');
            group.title = lock === 'fa-lock' ? 'lock' : 'lock open';
            group.classList.add(lock);
        }
    }
    delEl(e) {
        e.stopPropagation();
        setTimeout(() => { this.requestUpdate(); }, 100);
    }
    onMouseover(item) {
        this.highlightElement(item.el);
    }
    onMouseout(item) {
        this.unhighlightElement(item.el);
    }
    ;
    createOverlay() {
        const div = document.createElement("collab-aux-overlay");
        div.style.outlineOffset = '-2px';
        div.style.position = 'absolute';
        div.style.backgroundColor = 'rgb(0 183 255 / 22%)';
        div.style.zIndex = '99999';
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return div;
        scope.appendChild(div);
        return div;
    }
    highlightElement(el) {
        if (!this.elOverlay)
            this.elOverlay = this.createOverlay();
        const rect = el.getBoundingClientRect();
        this.elOverlay.style.display = 'block';
        this.elOverlay.style.top = `${rect.top + window.scrollY}px`;
        this.elOverlay.style.left = `${rect.left + window.scrollX}px`;
        this.elOverlay.style.width = `${rect.width}px`;
        this.elOverlay.style.height = `${rect.height}px`;
    }
    unhighlightElement(el) {
        if (this.elOverlay)
            this.elOverlay.style.display = 'none';
    }
    fireEventMode(mode) {
        clearTimeout(this.timeFireEventMode);
        this.timeFireEventMode = setTimeout(() => {
            const param = {
                'position': 'left',
                'action': mode === 'edit' ? 'modeEdit' : 'modePreview'
            };
            mls.events.fire(3, 'L3EditEvents', JSON.stringify(param));
        }, 500);
    }
    fireSelectEdit(id) {
        clearTimeout(this.timeFireSelectEdit);
        this.timeFireSelectEdit = setTimeout(() => {
            const param = {
                'position': 'left',
                'action': 'select',
                'id': id,
            };
            mls.events.fire(3, 'L3EditEvents', JSON.stringify(param));
        }, 500);
    }
};
__decorate([
    state()
], PluginNavigationRenderOrganism.prototype, "activeId", void 0);
PluginNavigationRenderOrganism = __decorate([
    customElement('plugin-navigation-render-organism-100554')
], PluginNavigationRenderOrganism);
export { PluginNavigationRenderOrganism };
