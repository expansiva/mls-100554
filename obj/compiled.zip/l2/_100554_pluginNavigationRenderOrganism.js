/// <mls shortName="pluginNavigationRenderOrganism" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, state, property, query } from 'lit/decorators.js';
import { convertFileNameToTag } from './_100554_utilsLit';
import { executeAgentByFile } from './_100554_aiAgentHelper';
import { PluginBaseModule } from './_100554_pluginBaseModule';
/// **collab_i18n_start** 
const message_pt = {
    noItens: 'Nenhum item foi encontrado!',
    msg1: 'Describe the new element to add inside the organism (e.g., button, text, nav).',
    msg2: 'Type what to create inside the organism, like "add button" or "add text".',
};
const message_en = {
    noItens: 'No items were found!',
    msg1: 'Describe the new element to add inside the organism (e.g., button, text, nav).',
    msg2: 'Type what to create inside the organism, like "add button" or "add text".'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginNavigationRenderOrganism = class PluginNavigationRenderOrganism extends PluginBaseModule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-navigation-render-organism-100554{display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-navigation-render-organism-100554 .contentNav{padding:1rem}plugin-navigation-render-organism-100554 ul{list-style:none;padding:0 0 0 .5rem;border-left:1px solid #d4d4d4}plugin-navigation-render-organism-100554 ul li{position:relative;user-select:none}plugin-navigation-render-organism-100554 ul li small{font-weight:700;font-size:11px}plugin-navigation-render-organism-100554 .dragging{opacity:.5}plugin-navigation-render-organism-100554 .drop-target{background:#d3f9d8}plugin-navigation-render-organism-100554 ul li .header{border:1px solid transparent;padding:.4rem;cursor:pointer}plugin-navigation-render-organism-100554 ul li .header:hover{border:1px solid #d4d4d4}plugin-navigation-render-organism-100554 ul li div.activeBranch{border:1px solid #d4d4d4;display:flex;justify-content:space-between;align-items:center;border-radius:5px;background:var(--bg-primary-color-disabled);color:var(--text-primary-color)}plugin-navigation-render-organism-100554 ul li:before{content:' ';position:absolute;width:7px;height:1px;background:#d4d4d4;top:1.2rem;left:-8px}plugin-navigation-render-organism-100554 .groupHiddenList{border-radius:4px;padding:.3rem;transition:all .5s;cursor:pointer;display:none;z-index:9;height:.7rem}plugin-navigation-render-organism-100554 ul li div.activeBranch .groupHiddenList{display:flex;align-items:center;position:relative}plugin-navigation-render-organism-100554 .groupHiddenList::after{content:' ';width:23px;height:19px;position:absolute;right:-15px;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><!--! Font Awesome Pro 6.4.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");background-repeat:no-repeat;background-position-y:center}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item{display:none;transition:.5s;margin-left:1rem;z-index:10;font-size:16px;line-height:normal}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item:hover{color:#1a83ff}plugin-navigation-render-organism-100554 info-item{display:block;white-space:nowrap;width:100%;overflow:hidden;text-overflow:ellipsis}plugin-navigation-render-organism-100554 .activegpbtnslider info-item{visibility:hidden !important;height:0px}plugin-navigation-render-organism-100554 .activegpbtnslider .groupHiddenList{padding-right:24px;padding-left:8px}plugin-navigation-render-organism-100554 .activegpbtnslider .groupHiddenList .mls-gpbtnslider-item{display:inherit;text-align:center;float:left}plugin-navigation-render-organism-100554 .headerNav{height:40px;background:var(--bg-primary-color-darker-hover);border-bottom:1px solid var(--bg-primary-color-lighter);display:flex;align-items:center;justify-content:center;position:relative;box-shadow:0 1px 3px var(--bg-primary-color-lighter)}plugin-navigation-render-organism-100554 .headerNav h1{font-size:16px;font-weight:500;color:var(--text-primary-color);margin:0;pointer-events:none}plugin-navigation-render-organism-100554 .headerNav .btn-nav{position:absolute;top:50%;transform:translateY(-50%);border:none;background-color:var(--grey-color-darker);color:var(--text-primary-color);width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s}plugin-navigation-render-organism-100554 .headerNav.left .btn-nav{left:10px}plugin-navigation-render-organism-100554 .headerNav.right .btn-nav{right:10px}plugin-navigation-render-organism-100554 .headerNav .btn-nav:hover{opacity:.5}plugin-navigation-render-organism-100554 .headerNav .btn-nav svg{width:14px;height:14px;fill:#fff}plugin-navigation-render-organism-100554 .form-container{background:var(--bg-primary-color);color:var(--text-primary-color);padding:20px 24px}plugin-navigation-render-organism-100554 .form-group{display:flex;flex-direction:column;margin-bottom:14px}plugin-navigation-render-organism-100554 .form-group label{font-size:13px;margin-bottom:6px}plugin-navigation-render-organism-100554 .form-group small{font-size:11px;color:var(--text-primary-color-disabled)}plugin-navigation-render-organism-100554 .form-group input,plugin-navigation-render-organism-100554 .form-group textarea,plugin-navigation-render-organism-100554 .form-group select{padding:8px 10px;border:1px solid var(--grey-color);border-radius:6px;font-size:14px;outline:none;transition:border-color .2s,box-shadow .2s}plugin-navigation-render-organism-100554 .form-group input:disabled{color:var(--text-primary-color)}plugin-navigation-render-organism-100554 .form-group input:focus,plugin-navigation-render-organism-100554 .form-group textarea:focus,plugin-navigation-render-organism-100554 .form-group select:focus{border-color:#4A90E2;box-shadow:0 0 0 2px rgba(74,144,226,0.2)}plugin-navigation-render-organism-100554 .form-group textarea{resize:vertical;min-height:60px}plugin-navigation-render-organism-100554 .btn-save{width:100%;padding:10px;background:#4A90E2;color:#fff;font-size:14px;font-weight:500;border:none;border-radius:6px;cursor:pointer;transition:background .2s}plugin-navigation-render-organism-100554 .btn-save:hover{background:#357ABD}`);
        this.msg = messages['en'];
        this.atributeBase = 'id';
        this.scenary = 'list';
        this.els = [];
        //-------COMPONENT----------
        this.activeId = '';
        this.tryRender = 0;
        this.setEvents();
    }
    setEvents() {
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onlevelChange(ev));
        mls.events.addListener(3, 'L3EditEvents', this.onL3EditEvents.bind(this));
        mls.events.addListener(3, 'FineshPreview', this.fineshPreview.bind(this));
    }
    onL3EditEvents(ev) {
        if (!ev.desc || ev.level !== 3)
            return;
        const info = JSON.parse(ev.desc);
        if (!info || !info.action || !info.position || info.position === 'left')
            return;
        switch (info.action) {
            case ('select'):
                this.onSelect(info);
                break;
            case ('navigation'):
                this.onNavigation(info);
                break;
        }
    }
    async fineshPreview(ev) {
        if (ev.level !== 3)
            return;
        this.forceUpdate();
    }
    onSelect(info) {
        if (!info.id)
            return;
        this.activeId = info.id;
    }
    onNavigation(info) {
        this.forceUpdate();
    }
    onlevelChange(ev) {
        if (!ev.desc)
            return;
        const j = JSON.parse(ev.desc);
        if (j.level === 3) {
            this.forceUpdate();
        }
    }
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        this.init();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.setElPreview();
        switch (this.scenary) {
            case ('list'):
                return this.renderNav();
            case ('prop'):
                return this.renderProperties();
            case ('details'):
                return this.renderDetails();
            case ('add'):
                return this.renderAdd();
        }
    }
    renderHeader(txt, btn, pos) {
        return html `
            <div class="headerNav ${pos}">
                <h1>${txt}</h1>
                ${btn}               
            </div>
        `;
    }
    renderProperties() {
        let btn = html `
            <button class="btn-nav" title="add organism" @click="${() => this.goToScenary('list')}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg>
            </button>
        `;
        return html `
            ${this.renderHeader('Properties', btn, 'left')}
            <h3>In developed</h3>
        `;
    }
    renderAdd() {
        let btn = html `
            <button class="btn-nav" title="add organism" @click="${() => this.goToScenary('list')}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg>
            </button>
        `;
        const { project, path } = mls.actual[3];
        const info = mls.l2.getPath(`_${project}_${path}`);
        return html `
            ${this.renderHeader('Add', btn, 'left')}
        
            <div class="form-container">

                <div class="form-group">
                    <label for="project">Projetc</label>
                    <input type="text" disabled .value="${mls.actualProject}"/>
                </div>

                <div class="form-group">
                    <label for="module">Module</label>
                    <input type="text" disabled .value="${info.folder}"/>
                </div>

                <div class="form-group">
                    <label for="organism">Organism</label>
                    <input type="text" disabled .value="${info.shortName}"/>
                </div>

                <div class="form-group">
                    <label for="prompt">Prompt</label>
                    <textarea id="iptPrompt" placeholder="Write your prompt..."></textarea>
                    <div style=" display: flex ; flex-direction: column;">
                        <small>${this.msg.msg1}</small>
                        <small>${this.msg.msg2}</small>
                    </div>
                </div>

                <button class="btn-save" @click=${this.createFile}>Save</button>
            </div>
        `;
    }
    renderDetails() {
        let btn = html `
            <button class="btn-nav" title="add organism" @click="${() => this.goToScenary('list')}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg>
            </button>
        `;
        return html `
            ${this.renderHeader('Details', btn, 'left')}
            <h3>In developed</h3>
        `;
    }
    renderNav() {
        let btn = html `
            <button class="btn-nav" title="add organism" @click="${() => this.goToScenary('add')}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg>
            </button>
        `;
        return html `
            ${this.renderHeader(mls.actual[3].getFullName(), btn, 'right')}
            ${this.renderNav2()}
        `;
    }
    renderNav2() {
        if (this.els && this.els.length > 0)
            return this.createNavigation(this.els);
        return html `<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
    }
    createNavigation(array) {
        const obj = html `
            <div class="contentNav">
            <ul>
                ${repeat(array, ((key, idx) => key.id), ((item, index) => { return this.renderItemTree(item, index); }))}
            </ul>
            </div>
        `;
        return obj;
    }
    renderItemTree(item, idx) {
        const cls = item.el.id === this.activeId || item.el.hasAttribute('clb_mode') ? 'activeBranch' : '';
        let mySymbol = 'fa-cubes';
        if (item.el.mySymbol)
            mySymbol = item.el.mySymbol;
        //const name = item.el.tagName.length > 30 ? item.el.tagName.toLocaleLowerCase().substring(0, 29) + '...' : item.el.tagName.toLocaleLowerCase();
        const name = item.el.tagName.toLocaleLowerCase();
        return html `
            <li>
                <div 
                    .info=${item}
                    id="${item.el.tagName.toLocaleLowerCase() + idx}"                      
                    class="header ${cls}" 
                    @click="${(e) => this.selectItem(e, item)}" 
                    @mouseover="${(e) => this.onMouseover(item)}"
                    @mouseout="${(e) => this.onMouseout(item)}"   
                >
                    <info-item .info=${item}>
                        <span class="fa ${mySymbol}" style="margin-right:.5rem"></span>
                        ${name}
                        <small>(${item.el.id})</small>
                    </info-item>
                    <div class="groupHiddenList" .info=${item}  @click="${this.clickGroupHidden}" >
                        
                        <span class="mls-gpbtnslider-item" @click="${() => this.goToScenary('details')}" title="details">
                            <svg xmlns="http://www.w3.org/2000/svg" width="7px" viewBox="0 0 192 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M48 80a48 48 0 1 1 96 0A48 48 0 1 1 48 80zM0 224c0-17.7 14.3-32 32-32l64 0c17.7 0 32 14.3 32 32l0 224 32 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 512c-17.7 0-32-14.3-32-32s14.3-32 32-32l32 0 0-192-32 0c-17.7 0-32-14.3-32-32z"/></svg>
                        </span>
                        <span class="mls-gpbtnslider-item" @click="${this.delEl}" title="remove">
                            <svg xmlns="http://www.w3.org/2000/svg" width="13px" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M135.2 17.7L128 32 32 32C14.3 32 0 46.3 0 64S14.3 96 32 96l384 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-96 0-7.2-14.3C307.4 6.8 296.3 0 284.2 0L163.8 0c-12.1 0-23.2 6.8-28.6 17.7zM416 128L32 128 53.2 467c1.6 25.3 22.6 45 47.9 45l245.8 0c25.3 0 46.3-19.7 47.9-45L416 128z"/></svg>
                        </span>
                        <span class="mls-gpbtnslider-item" @click="${() => this.goToScenary('prop')}" title="properties">
                            <svg xmlns="http://www.w3.org/2000/svg" width="15px" viewBox="0 0 512 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M0 416c0 17.7 14.3 32 32 32l54.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48L480 448c17.7 0 32-14.3 32-32s-14.3-32-32-32l-246.7 0c-12.3-28.3-40.5-48-73.3-48s-61 19.7-73.3 48L32 384c-17.7 0-32 14.3-32 32zm128 0a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM320 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm32-80c-32.8 0-61 19.7-73.3 48L32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l246.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48l54.7 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-54.7 0c-12.3-28.3-40.5-48-73.3-48zM192 128a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm73.3-64C253 35.7 224.8 16 192 16s-61 19.7-73.3 48L32 64C14.3 64 0 78.3 0 96s14.3 32 32 32l86.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48L480 128c17.7 0 32-14.3 32-32s-14.3-32-32-32L265.3 64z"/></svg>
                        </span>
                    </div>
                </div>
                <ul>
                    ${repeat(item.children, ((c, idx) => c.el.tagName + idx), ((i, idxI) => { return this.renderItemTree(i, idx + '_' + idxI); }))}
                </ul>
            </li>
        `;
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.init();
    }
    async init() {
        setTimeout(async () => { this.els = await this.getComponents(); }, 500);
    }
    goToScenary(scenary) {
        this.scenary = scenary;
    }
    tryRenderAgain() {
        if (this.tryRender === 10)
            return;
        this.tryRender++;
        setTimeout(() => this.forceUpdate(), 800);
    }
    setElPreview() {
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return;
        this.elPreviewL3 = scope.querySelector('collab-preview-l3-100554');
    }
    async getComponents() {
        const lessTags = ['script', 'style', 'body', 'head', 'html'];
        let ret = [];
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return ret;
        const infoFile = mls.l2.getPath(mls.actual[3].getFullName());
        const tag = convertFileNameToTag(infoFile);
        const root = scope.querySelector(tag);
        if (root)
            await root.updateComplete;
        const reentrance = (array, element) => {
            let info;
            if (element.getAttribute(this.atributeBase) && !lessTags.includes(element.tagName.toLocaleLowerCase())) {
                info = { el: element, id: element.id, children: [] };
                array.push(info);
            }
            else if (tag === element.tagName.toLocaleLowerCase()) {
                info = { el: element, id: element.id, children: [] };
                array.push(info);
            }
            if (element.shadowRoot) {
                const children = Array.from(element.shadowRoot.children);
                for (let i = 0; i < children.length; i++) {
                    const child = children[i];
                    reentrance(info ? info.children : array, child);
                }
            }
            else {
                const children = Array.from(element.children);
                for (let i = 0; i < children.length; i++) {
                    const child = children[i];
                    reentrance(info ? info.children : array, child);
                }
            }
        };
        reentrance(ret, scope);
        return ret;
    }
    selectItem(e, item) {
        e.stopPropagation();
        let target = e.target;
        if (target && target.className.indexOf('header') < 0) {
            target = target.closest('.header');
        }
        if (!target)
            return;
        const active = this.querySelector('.activeBranch');
        if (active && active === target) {
            return;
        }
        if (active)
            active.classList.remove('activeBranch');
        target.classList.add('activeBranch');
        if (this.elPreviewL3)
            this.elPreviewL3.selectElement(item.el);
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const father = el.closest('.header');
        if (!father)
            return;
        father.classList.toggle('activegpbtnslider');
        if (!el.info)
            return;
        let lock = 'fa-lock-open';
        const isGroup = el.info.el.getAttribute('isFCAGroup');
        if (isGroup || isGroup === 'true') {
            lock = 'fa-lock';
        }
        const group = el.querySelector('.classLock');
        if (group) {
            group.classList.remove('fa-lock');
            group.classList.remove('fa-lock-open');
            group.title = lock === 'fa-lock' ? 'lock' : 'lock open';
            group.classList.add(lock);
        }
    }
    delEl(e) {
        e.stopPropagation();
        setTimeout(() => { this.requestUpdate(); }, 100);
    }
    onMouseover(item) {
        this.highlightElement(item.el);
    }
    onMouseout(item) {
        this.unhighlightElement(item.el);
    }
    ;
    highlightElement(el) {
        if (!this.elPreviewL3 || !this.elPreviewL3.setHover)
            return;
        this.elPreviewL3.setHover(el, true);
    }
    unhighlightElement(el) {
        if (!this.elPreviewL3 || !this.elPreviewL3.setHover)
            return;
        this.elPreviewL3.setHover(el, false);
    }
    async createFile() {
        try {
            this.showLoad(true);
            if (!this.iptPrompt || !this.iptPrompt.value) {
                throw new Error('Enter the prompt');
            }
            const path = mls.actual[3].getFullName();
            if (!path)
                throw new Error('Not found path');
            const info = mls.l2.getPath(path);
            const key = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, '.ts');
            if (!mls.stor.files[key])
                throw new Error('Not found storFile');
            const pp = { page: path, prompt: this.iptPrompt.value, position: 'left' };
            await this.fireImprove(mls.stor.files[key], JSON.stringify(pp));
            mls.events.fireFileAction('statusOrErrorChanged', mls.stor.files[key], 'left', 0);
            this.scenary = 'list';
            this.iptPrompt.value = '';
            this.showLoad(false);
        }
        catch (e) {
            this.showError('[createFile]' + e.message);
            this.showLoad(false);
        }
    }
    async fireImprove(file, prompt) {
        await executeAgentByFile('agentImprovePrototypeOrganism', prompt, file);
    }
    showLoad(active) {
        setTimeout(() => {
            if (!this.service)
                return;
            this.service.loading = active;
        }, 500);
    }
    showError(msg) {
        if (!this.service)
            return;
        this.service.setError(msg);
    }
};
__decorate([
    property()
], PluginNavigationRenderOrganism.prototype, "service", void 0);
__decorate([
    property()
], PluginNavigationRenderOrganism.prototype, "scenary", void 0);
__decorate([
    property()
], PluginNavigationRenderOrganism.prototype, "els", void 0);
__decorate([
    query('#iptModule')
], PluginNavigationRenderOrganism.prototype, "iptModule", void 0);
__decorate([
    query('#iptOrganism')
], PluginNavigationRenderOrganism.prototype, "iptOrganism", void 0);
__decorate([
    query('#iptPrompt')
], PluginNavigationRenderOrganism.prototype, "iptPrompt", void 0);
__decorate([
    state()
], PluginNavigationRenderOrganism.prototype, "activeId", void 0);
PluginNavigationRenderOrganism = __decorate([
    customElement('plugin-navigation-render-organism-100554')
], PluginNavigationRenderOrganism);
export { PluginNavigationRenderOrganism };
