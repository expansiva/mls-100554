/// <mls shortName="aimTaskExecLLM" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { executePrompt } from "./_100554_aimHelper";
import { AimTaskBase } from "./_100554_aimTaskBase";
let AimTaskExecLLM = class AimTaskExecLLM extends AimTaskBase {
    onInitializing() {
        this.senderToServer(this.taskRoot);
    }
    senderToServer(taskRoot) {
        this.taskChild.trace.push(new Date().toISOString() + ': sending to server');
        executePrompt(this.taskIndex)
            .then((value) => {
            if (!value)
                throw new Error('invalid task retorned');
            this.taskChild.trace.push(new Date().toISOString() + ': received from server, len=' + (JSON.stringify(taskRoot)).length);
            this.taskChild.mode = taskRoot.mode = 'processed';
            this.notifyCompleteByStatus('ok', '');
            return;
        }).catch((reason) => {
            this.taskChild.trace.push(new Date().toISOString() + ': error on executePrompt: ' + reason.message || '?');
            this.taskChild.mode = taskRoot.mode = 'error';
            this.notifyCompleteByStatus("error", '');
            return;
        });
    }
    onIconClick(action) {
        // this.task.result.len += 1;
        this.requestUpdate();
    }
};
AimTaskExecLLM = __decorate([
    customElement('aim-task-exec-l-l-m-100554')
], AimTaskExecLLM);
export { AimTaskExecLLM };
