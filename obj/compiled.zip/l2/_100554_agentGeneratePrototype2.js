/// <mls shortName="agentGeneratePrototype2" project="100554" enhancement="_blank" />
import { svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import { getPayload1 } from './_100554_agentGeneratePrototype';
import { getNextPendingStepByAgentName, getStepById, getNextStepIdAvaliable, getAgentStepByAgentName, notifyTaskChange, getNextInProgressStepByAgentName, updateStepStatus, updateTaskTitle } from "./_100554_aiAgentHelper";
import { startNewInteractionInAiTask, startNewAiTask, executeNextStep, addNewStep, startClarification } from "./_100554_aiAgentOrchestration";
const agentName = "agentGeneratePrototype2";
const project = 100554;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent for create a new Module - 2",
        visibility: "private",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async replayForSupport(context, payload) {
            return _replayForSupport(context, payload);
        },
        async beforeClarification(context, stepId) {
            return _beforeClarification(context, stepId);
        },
        async afterClarification(context, stepId, clarification) {
            return _afterClarification(context, stepId, clarification);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning 2...";
    if (!context || !context.message)
        throw new Error(`[${agentName}](_beforePrompt) Invalid context`);
    if (!context.task) {
        // use mock
        const inputs = await getPrompts(getPayload1Mock());
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
        return;
    }
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step) {
        throw new Error(`[${agentName}](beforePrompt) No pending step found for this agent.`);
    }
    // context.task = await updateStepStatus(context.task, step.stepId, "in_progress");
    // don't need updateStepStatus, addInteractionAiTask put this task in 'in_process'
    const inputs = await getPrompts(getPayload1(context));
    await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error(`[${agentName}](_afterPrompt) Invalid context`);
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}](afterPrompt) No in progress interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    if (context.task)
        context.task = await updateTaskTitle(context.task, "Waiting for user");
    notifyTaskChange(context);
    await executeNextStep(context);
};
const _replayForSupport = async (context, payload) => {
    throw new Error("[replayForSupport] not implemented");
};
const _beforeClarification = async (context, stepId) => {
    const projectStart = context.task?.iaCompressed?.longMemory['project'];
    if (mls.actualProject?.toString() !== projectStart) {
        const div = document.createElement('div');
        div.innerHTML = 'This task may only be continued on project: ' + projectStart;
        return div;
    }
    return startClarification(context, stepId);
};
const _afterClarification = async (context, stepId, clarification) => {
    if (!context || !context.message || !context.task)
        throw new Error(`[${agentName}](afterClarification) Invalid context`);
    if (!clarification)
        throw new Error(`[${agentName}](afterClarification) Invalid json after clarification`);
    const step = getStepById(context.task, stepId);
    if (!step || step.type !== "clarification") {
        throw new Error(`[${agentName}](afterClarification) No found step: ${stepId} for this agent.`);
    }
    const newStep = {
        type: 'agent',
        agentName: 'agentGeneratePrototype3',
        status: 'pending',
        prompt: "...",
        stepId: getNextStepIdAvaliable(context.task),
        interaction: null,
        nextSteps: null,
        rags: null
    };
    // complete this step (payload) and push another step
    await addNewStep(context, step.stepId, [newStep], "Waiting ...");
};
async function getPrompts(payload1) {
    if (!payload1 || !payload1.title || !payload1.userPrompt)
        throw new Error(`Erro [${agentName}](getPrompts) invalid payload1`);
    const data = {
        userPrompt: payload1.userPrompt,
        resumeClarification: JSON.stringify({
            title: payload1.title,
            userLanguage: payload1.userLanguage,
            questions: payload1.questions
        }, null, 2)
    };
    return await getPromptByHtml({ project, shortName: agentName, folder: '', data });
}
function getPayload1Mock() {
    return {
        userPrompt: "criar um web site para petshop",
        userLanguage: "pt-BR",
        title: "Esclarecimento 1/2",
        questions: {
            roles: {
                type: "open",
                question: "Quais papéis de usuário o site deve ter? (ex: administrador, cliente, funcionário)",
                answer: "Administrador e cliente"
            },
            publicTarget: {
                type: "open",
                question: "Qual é o público-alvo principal do site? (ex: donos de pets, veterinários, fornecedores)",
                answer: "Donos de pets"
            },
            tone: {
                type: "open",
                question: "Qual tom o site deve transmitir? (ex: amigável, profissional, descontraído)",
                answer: "Amigável e profissional"
            },
            languages: {
                type: "open",
                question: "O site deve ser multilíngue? Se sim, quais idiomas?",
                answer: "Apenas português"
            },
            openQuestion1: {
                type: "open",
                question: "Quais funcionalidades principais o site deve ter? (ex: agendamento, loja online, blog)",
                answer: "Agendamento de serviços e loja online"
            },
            openQuestion2: {
                type: "open",
                question: "Você já possui conteúdo e imagens para o site ou precisa que sejam criados?",
                answer: "Preciso que sejam criados"
            },
            openQuestion3: {
                type: "open",
                question: "Há alguma referência de design ou sites que você gostaria que fossem usados como inspiração?",
                answer: "Sim, sites modernos e limpos"
            }
        },
        legends: [
            "Este é o primeiro esclarecimento",
            "antes de criar algo"
        ]
    };
}
export function getPayload2(context) {
    if (!context || !context.task)
        throw new Error(`[${agentName}] [getPayload] Invalid context`);
    const agentStep = getAgentStepByAgentName(context.task, agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agentName}] [getPayload] no agent found`);
    // get result
    const resultStep = agentStep.interaction?.payload?.[0];
    if (!resultStep || resultStep.type !== "clarification" || !resultStep.json)
        throw new Error(`[${agentName}] [getPayload] No step clarification found for this agent.`);
    let payload2 = resultStep.json;
    if (typeof payload2 === "string")
        payload2 = JSON.parse(payload2);
    return payload2;
}
