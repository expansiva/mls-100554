var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls shortName="wcInputText" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { IcaFormsInputStringBase } from './_100554_icaFormsInputStringBase';
import { propertyDataSource } from './_100554_icaLitElement';
let WcInputText100554 = class WcInputText100554 extends IcaFormsInputStringBase {
    constructor() {
        super(...arguments);
        this.loadStyle(`wc-input-text-100554{display:block}wc-input-text-100554 .input_control{display:block;width:calc(100% - 1.5rem - 1px);padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;-webkit-appearance:none;-moz-appearance:none;appearance:none;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}wc-input-text-100554 .form_hint{color:blue}wc-input-text-100554 .form_error_message{color:red}`);
        this.maxlength = undefined;
        this.minlength = undefined;
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.autocorrect = undefined;
        this.autoCapitalize = undefined;
        this.error = '';
    }
    render() {
        return html `
        <label class="form-control-label">
          ${this.label}
        </label>

        <input
            class="input_control"
            type="text"
            name=${ifDefined(this.name)}
            ?disabled=${this.disabled}
            ?readonly=${this.readonly}
            ?required=${this.required}
            maxlength=${ifDefined(this.minlength)}    
            minlength=${ifDefined(this.maxlength)}
            autocomplete=${ifDefined(this.autocomplete)}
            placeholder=${ifDefined(this.placeholder)}
            .value=${this.datasource || ''}
            ?autofocus=${this.autofocus}
            pattern=${ifDefined(this.pattern)}
            @input=${this.handleChange}

        
        />
        <small class="form_hint">${this.hint}</small>
        <div class="form_error_message">${this.error}</div>
        `;
    }
    handleChange(event) {
        const input = event.target;
        this.datasource = input.value;
    }
};
__decorate([
    propertyDataSource({ type: String })
], WcInputText100554.prototype, "datasource", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputText100554.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "errormessage", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "placeholder", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "autocomplete", void 0);
__decorate([
    property({ type: Number })
], WcInputText100554.prototype, "maxlength", void 0);
__decorate([
    property({ type: Number })
], WcInputText100554.prototype, "minlength", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "autofocus", void 0);
__decorate([
    propertyDataSource({ type: String })
], WcInputText100554.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "autocorrect", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "autoCapitalize", void 0);
__decorate([
    query('.input_control')
], WcInputText100554.prototype, "input", void 0);
WcInputText100554 = __decorate([
    customElement('wc-input-text-100554')
], WcInputText100554);
export { WcInputText100554 };
