/// <mls shortName="beDatabaseBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
export class DatabaseClient {
}
;
