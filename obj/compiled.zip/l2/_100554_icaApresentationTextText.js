/// <mls shortName="icaApresentationTextText" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElementBase } from './_100554_icaLitElementBase';
let IcaApresentationTextText = class IcaApresentationTextText extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.mySymbol = 'fa-t';
    }
    getActionsTags() {
        let isBlankLine = !this.getAttribute('text');
        if (isBlankLine) {
            let auxEdt = '{"tp":"edit", "attr":"text"}';
            let auxAdd = '';
            const addOpen = this.getAttribute('addOpen');
            this.removeAttribute('addOpen');
            if (addOpen) {
                auxAdd = '{"open":true, "buttons" : "image,unsplash,video,embed,code,part"}';
                auxEdt = '{"tp":"click", "attr":"text"}';
            }
            return [
                { name: "add", args: auxAdd },
                { name: "edit", args: auxEdt, position: 'p-m2' },
                { name: "backButton" }
            ];
        }
        let rc = [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "events" },
            { name: "edit", args: '{"tp":"btn", "attr":"text"}' },
            { name: "title" },
        ];
        return rc;
    }
    changeStateHtml(html) {
    }
    allowCommand(cmd, scope, target) {
        return { inside: false, before: false, after: false };
    }
    commandMove(scope, target) {
        return { inside: false, before: false, after: false };
    }
};
__decorate([
    property({ type: String })
], IcaApresentationTextText.prototype, "type", void 0);
IcaApresentationTextText = __decorate([
    customElement('ica-apresentation-text-text-100554')
], IcaApresentationTextText);
export { IcaApresentationTextText };
