/// <mls shortName="serviceDsAssetsVideo" project="100554" enhancement="_100554_enhancementLit" groupName="service" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css } from 'lit';
import { customElement, query } from 'lit/decorators.js';
import { ServiceBase } from './_100554_serviceBase';
let ServiceDsAssetsVideo100554 = class ServiceDsAssetsVideo100554 extends ServiceBase {
    constructor() {
        super();
        this.details = {
            icon: '&#xf03d',
            state: 'foreground',
            tooltip: 'Assets Video',
            visible: false,
            position: "right",
            tags: ['ds_assets'],
            widget: '_100554_serviceDsAssetsVideo',
            level: [3]
        };
        this.onClickLink = (op) => {
            if (op === 'opHelper')
                return this.showInitial();
            if (this.menu.setMode)
                this.menu.setMode('initial');
            return false;
        };
        this.menu = {
            title: 'Assets Video',
            actions: {
                opHelper: 'Assets Video',
            },
            icons: {},
            actionDefault: 'opHelper', // call after close icon clicked
            setMode: undefined, // child will set this
            onClickLink: this.onClickLink,
            getLastMode: undefined,
            updateTitle: undefined
        };
        this.setEvents();
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible) {
            this.setVideo();
            if (el && typeof el.layout === 'function')
                el.layout();
        }
    }
    setEvents() {
        mls.events.addEventListener([this.level], ['DSAssetsUnSelected'], (ev) => {
            this.onDsAssetsUnSelected(ev);
        });
        mls.events.addEventListener([this.level], ['DSAssetsChanged'], (ev) => {
            this.onDsAssetsChanged(ev);
        });
    }
    showInitial() {
        this.menu.title = 'Assets Video';
        return true;
    }
    onDsAssetsUnSelected(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.service.includes('_100554_serviceDsAssetsVideo'))
            return;
        this.showNav2Item(false);
    }
    onDsAssetsChanged(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.position === 'right')
            return;
        if (params.info.helper.includes('_100554_serviceDsAssetsVideo')) {
            this.data = params;
            this.showNav2Item(true);
            this.openMe();
        }
        else
            this.showNav2Item(false);
    }
    async setVideo() {
        if (!this.data)
            return;
        if (!this.data.info.filesSelectedArr)
            return undefined;
        const [fileSelected] = this.data.info.filesSelectedArr;
        if (!fileSelected)
            return undefined;
        const { folder, extension, level, project, shortName } = fileSelected;
        const keyFile = mls.stor.getKeyToFiles(project, level, shortName, folder, extension);
        const value = await mls.stor.files[keyFile]?.getContent();
        const file = value;
        const reader = new FileReader();
        if (!file)
            return;
        reader.addEventListener('load', () => {
            const base64String = btoa(reader.result);
            const base64Full = `data:${file.type};base64,${base64String}`;
            if (this.videoEl)
                this.videoEl.src = base64Full;
        });
        reader.readAsBinaryString(file);
    }
    render() {
        return html `
            <div class="service_assets_video">
                <video id="serviceassetsvideo_video" controls=""></video>
            </div>
        `;
    }
};
ServiceDsAssetsVideo100554.styles = css ` .service_assets_video{display:flex;justify-content:center;align-items:center;padding:2rem} .service_assets_video video{width:100%;max-height:100%}`;
__decorate([
    query('#serviceassetsvideo_video')
], ServiceDsAssetsVideo100554.prototype, "videoEl", void 0);
ServiceDsAssetsVideo100554 = __decorate([
    customElement('service-ds-assets-video-100554')
], ServiceDsAssetsVideo100554);
export { ServiceDsAssetsVideo100554 };
