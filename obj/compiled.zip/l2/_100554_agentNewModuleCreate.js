/// <mls shortName="agentNewModuleCreate" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { getPayload3 } from './_100554_agentNewModule3';
import { getTask } from './_100554_msgDBController';
let AgentNewModuleCreate100554 = class AgentNewModuleCreate100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`agent-new-module-create-100554{color:#e7d6d6;background-color:#000000;display:block;height:100%;width:100%}agent-new-module-create-100554 :host{display:flex;flex-direction:column;padding:1rem;gap:1rem;background-color:#121212;color:#e0e0e0;height:100%;width:100%;box-sizing:border-box;font-family:'Segoe UI',sans-serif}agent-new-module-create-100554 label{font-weight:bold;margin-top:.5rem;margin-left:1em}agent-new-module-create-100554 select,agent-new-module-create-100554 input{padding:.4rem;background:#1e1e1e;border:1px solid #444;color:white;border-radius:4px;width:fit-content;min-width:150px}agent-new-module-create-100554 button{margin-top:.5rem;margin-left:2em;padding:.5rem 1rem;background-color:#2e8bff;color:white;border:none;border-radius:4px;cursor:pointer}agent-new-module-create-100554 button:hover{background-color:#1a6edc}agent-new-module-create-100554 pre{background-color:#1a1a1a;padding:1rem;border-radius:4px;overflow:auto;max-height:60vh;white-space:pre-wrap;font-size:.85rem}`);
        this.type = "table";
        this.index = 0;
        this.taskId = "task#1750787911355";
        this.result = "";
        this.project = 100554;
        this.folder = "";
    }
    render() {
        return html `
      <div>
        <label>TaskId:</label>
        <input type="string" .value=${this.taskId} @input=${(e) => this.taskId = e.target.value} />
        <label>Type:</label>
        <select @change=${(e) => this.type = e.target.value}>
          <option value="table">table</option>
          <option value="plugin">plugin</option>
          <option value="organism">organism</option>
          <option value="page">page</option>
        </select>

        <label>Index:</label>
        <input type="number" .value=${this.index} @input=${(e) => this.index = Number(e.target.value)} />

        <button @click=${this.generate}>Generate .defs</button>
      </div>

      <pre><code>${this.result}</code></pre>
    `;
    }
    async generate() {
        const task = await getTask(this.taskId);
        if (!task)
            return `// invalid taskid selected`;
        const context = {
            message: {
                threadId: "",
                orderAt: "",
                createAt: "",
                senderId: "",
                content: "",
            },
            task,
            modeSingleStep: true,
        };
        const payload3 = getPayload3(context);
        this.result = generate(this.type, payload3, this.project, this.folder, this.index);
    }
};
AgentNewModuleCreate100554.properties = {
    type: { type: String },
    index: { type: Number },
    result: { type: String }
};
AgentNewModuleCreate100554 = __decorate([
    customElement('agent-new-module-create-100554')
], AgentNewModuleCreate100554);
export { AgentNewModuleCreate100554 };
function generate(fileType, payload3, project, folder, index) {
    try {
        switch (fileType) {
            case "table":
                return generateTableDefsFromLLM(payload3, index, project, folder);
            case "plugin":
                return generatePluginDefsFromLLM(payload3, index, project, folder);
            case "organism":
                return generateOrganismDefsFromLLM(payload3, index, project, folder);
            case "page":
                return generatePageDefsFromLLM(payload3, index, project, folder);
            default:
                return "// Invalid type selected.";
        }
    }
    catch (err) {
        return `// Error: ${err.message}`;
    }
}
//
// ------
//
function verifyIfExists(args) {
    const key = mls.stor.getKeyToFiles(args.project, 2, args.shortName, args.folder, ".defs");
    return !!mls.stor.files[key];
}
function sanitizeMeta(baseShortName, project, folder) {
    let candidateName = baseShortName;
    let suffix = 1;
    while (verifyIfExists({ project, shortName: candidateName, folder })) {
        candidateName = `${baseShortName}${suffix}`;
        suffix++;
    }
    return candidateName;
}
function extractTablesFromDataNeeds(dataNeeds) {
    const tables = new Set();
    for (const entry of dataNeeds) {
        const parts = entry.split(':')[0].split(',').map(p => p.trim());
        for (const item of parts) {
            const base = item.split('.')[0].trim();
            if (base && base.toLowerCase() !== "pages" && base.toLowerCase() !== "business") {
                tables.add(`table${capitalizeFirstLetter(base)}`);
            }
        }
    }
    return Array.from(tables);
}
function capitalizeFirstLetter(text) {
    return text.charAt(0).toUpperCase() + text.slice(1);
}
function generateOrganismDefsFromLLM(payload, index, project, folder) {
    const organism = payload.organism[index];
    const shortName = sanitizeMeta(organism.organismTag, project, folder);
    const tableImports = extractTablesFromDataNeeds(organism.organismDataNeeds);
    const defs = {
        meta: {
            projectId: project,
            folder,
            shortName,
            type: "widget",
            group: payload.finalModuleDetails.moduleName,
            tags: ["lit", "organism"]
        },
        references: {
            widgets: [],
            plugins: organism.organismPlugins,
            statesRO: [],
            statesRW: [],
            statesWO: [],
            imports: tableImports
        },
        planning: {
            generalDescription: organism.planning?.context || '',
            goal: organism.planning.goal,
            userStories: organism.planning?.userStories,
            userRequestsEnhancements: organism.planning.userRequestsEnhancements || [],
            constraints: organism.planning.constraints || []
        }
    };
    return `/// <mls shortName="${shortName}" project="${project}" enhancement="_blank" />\n\n` +
        `// Do not change – automatically generated code.\n\n` +
        `export const defs: mls.l4.BaseDefs = ${JSON.stringify(defs, null, 2)}\n`;
}
function generatePluginDefsFromLLM(payload, index, project, folder) {
    const plugin = payload.plugins[index];
    const shortName = sanitizeMeta(plugin.pluginName, project, folder);
    const defs = {
        meta: {
            projectId: project,
            folder,
            shortName,
            type: "plugin",
            group: payload.finalModuleDetails.moduleName,
            tags: ["plugin"]
        },
        references: {
            widgets: [],
            plugins: [],
            statesRO: [],
            statesRW: [],
            statesWO: [],
            imports: []
        },
        planning: {
            generalDescription: "",
            goal: plugin.pluginGoal,
            userStories: [
                {
                    story: `Como sistema, quero integrar o plugin ${plugin.pluginName} para ${plugin.pluginGoal.toLowerCase()}`,
                    derivedRequirements: plugin.pluginRequirements.map(req => ({ description: req }))
                }
            ],
            userRequestsEnhancements: [],
            constraints: []
        }
    };
    return `/// <mls shortName="${shortName}" project="${project}" enhancement="_blank" />\n\n` +
        `// Do not change – automatically generated code.\n\n` +
        `export const defs: mls.l4.BaseDefs = ${JSON.stringify(defs, null, 2)}\n`;
}
function extractOrganismTagsFromHtml(pageHtml) {
    const tags = new Set();
    for (const line of pageHtml) {
        const match = line.match(/<organism-[\w-]+/g);
        if (match) {
            match.forEach(tag => {
                const clean = tag.replace("<", "").split(" ")[0].trim();
                tags.add(clean);
            });
        }
    }
    return Array.from(tags);
}
function generatePageDefsFromLLM(payload, index, project, folder) {
    const page = payload.pages[index];
    const shortName = sanitizeMeta(page.pageName, project, folder);
    const wireframe = payload.pagesWireframe.find(p => p.pageSequential === page.pageSequential);
    const widgets = wireframe ? extractOrganismTagsFromHtml(wireframe.pageHtml) : [];
    const defs = {
        meta: {
            projectId: project,
            folder,
            shortName,
            type: "page",
            group: payload.finalModuleDetails.moduleName,
            tags: ["lit", "page"]
        },
        references: {
            widgets,
            plugins: [],
            statesRO: [],
            statesRW: [],
            statesWO: [],
            imports: []
        },
        planning: {
            generalDescription: "",
            goal: page.pageGoal,
            userStories: [
                {
                    story: `Como visitante, quero acessar a página "${page.pageName}" para ${page.pageGoal.toLowerCase()}`,
                    derivedRequirements: page.pageRequirements.map(desc => ({ description: desc }))
                }
            ],
            userRequestsEnhancements: [],
            constraints: []
        }
    };
    return `/// <mls shortName="${shortName}" project="${project}" enhancement="_blank" />\n\n` +
        `// Do not change – automatically generated code.\n\n` +
        `export const defs: mls.l4.BaseDefs = ${JSON.stringify(defs, null, 2)}\n`;
}
function generateTableDefsFromLLM(payload, index, project, folder) {
    const entity = payload.hierarchicalPersistentData[index];
    const shortName = sanitizeMeta(entity.entityName.toLowerCase(), project, folder);
    const defs = {
        meta: {
            projectId: project,
            folder,
            shortName,
            type: "table",
            group: payload.finalModuleDetails.moduleName,
            tags: ["data", "table"]
        },
        references: {
            widgets: [],
            plugins: [],
            statesRO: [],
            statesRW: [],
            statesWO: [],
            imports: []
        },
        planning: {
            generalDescription: `Tabela de dados representando a entidade ${entity.entityName}.`,
            goal: `Armazenar informações da entidade ${entity.entityName} de forma estruturada.`,
            userStories: [
                {
                    story: `Como sistema, quero gerenciar dados da entidade ${entity.entityName} para uso no frontend e backend.`,
                    derivedRequirements: []
                }
            ],
            userRequestsEnhancements: [],
            constraints: []
        }
    };
    const interfaceBlock = entity.entityDefinitions.length
        ? `// <interfaces>\n${entity.entityDefinitions.join("\n")}\n// </interfaces>\n\n`
        : "";
    return `/// <mls shortName="${shortName}" project="${project}" enhancement="_blank" />\n\n` +
        `// Do not change – automatically generated code.\n\n` +
        `export const defs: mls.l4.BaseDefs = ${JSON.stringify(defs, null, 2)}\n\n\n` + interfaceBlock;
}
