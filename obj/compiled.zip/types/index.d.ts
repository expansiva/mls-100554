declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_100554_/l2/agentArchitectMind" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getDefs(): Promise<string>;
    export type Output = {
        type: "flexible";
        result: IResult[];
    };
    interface IResult {
        files: [
            {
                file: string;
                description: string;
            }
        ];
    }
}
declare module "_100554_/l2/agentBotInstall.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from '_102036_/l2/shared/interfaces';
    export * from '_102036_/l2/shared/interfaces';
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module '/_102036_/l2/shared/interfaces.js' {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/shared/api" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from '_102036_/l2/collabMessagesIndexedDB';
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<any>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<any>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<any>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: any;
        agentId: any;
        connectorId: any;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_100554_/l2/agentBotInstall" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function disableBot(context: mls.msg.ExecutionContext, projectId: number, shortName: string, folder: string): Promise<boolean>;
}
declare module "_100554_/l2/agentBotWeddingGifts.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentBotWeddingGifts" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: WeddingGifts;
    } | {
        type: "result";
        result: string[];
    };
    interface WeddingGifts {
        gifts: GiftItem[];
    }
    export interface GiftItem {
        name: string;
        originalNames: string[];
        status: "available" | "reserved" | "purchased" | "declined";
        reservedBy?: string;
        date?: string;
        message?: string;
        purchaseUrl?: string;
    }
}
declare module "../l2/agentCompareAgentsClarification" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class AgentToBeConceptual2Clarification extends CollabLitElement {
        entitiesCount: number;
        rulesCount: number;
        capabilitiesCount: number;
        suggestions: string[];
        firstUpdated(changed: Map<string, any>): void;
        updated(changed: Map<string, any>): void;
        render(): any;
        private renderContentSuggestions;
        private onAction;
    }
}
declare module "_100554_/l2/agentCompareAgents" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        agentNames: string[];
        promptUser: string;
        promptCompare: string;
    };
    export type Output3 = {
        type: "clarification";
        json: Suggestions;
    };
    export interface Suggestions {
        suggestions: [
            "Please provide the names of the agents for analysis, separated by commas.",
            "Please provide the user prompt.",
            "Do you want me to analyze something specific?"
        ];
    }
}
declare module "_100554_/l2/agentCompareAgents2" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: any;
    };
}
declare module "_100554_/l2/agentCompareAgents3" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Assessment;
    };
    export type Assessment = {
        correctness: number;
        completeness: number;
        quality: number;
        efficiency: number;
        robustness: number;
        finalScore: number;
        summary: string;
    };
}
declare module "_100554_/l2/agentCompareAgentsClarification" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class AgentToBeConceptual2Clarification extends CollabLitElement {
        entitiesCount: number;
        rulesCount: number;
        capabilitiesCount: number;
        suggestions: string[];
        firstUpdated(changed: Map<string, any>): void;
        updated(changed: Map<string, any>): void;
        render(): any;
        private renderContentSuggestions;
        private onAction;
    }
}
declare module "_100554_/l2/agentDesignRef2Image.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentDesignRef2Image" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getPayload1(context: mls.msg.ExecutionContext): PayLoad1;
    export type Output1 = {
        type: "flexible";
        result: string;
    };
    export interface PayLoad1 {
        prompt: string;
    }
}
declare module "_100554_/l2/agentDesignRef2Image2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentDesignRef2Image2" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_100554_/l2/agentFix.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        dsGlobalCss?: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "../l2/collabDOMSync" {
    export function sync(): void;
    export function updateHTML(html: string, format?: boolean): void;
    export function setValueInModeKeepingUndo(model: monaco.editor.ITextModel, newContent: string): void;
    export function formatHtml(html: string): string;
}
declare module "../l2/lessMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines: (url: string) => string[];
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine: (url: string, lineNr: number, line: string) => boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine: (url: string, lineNr: number) => boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines: (url: string, startLine: number, countLines: number) => boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine: (url: string, lineNr: number, columnNr: number, newText: string) => boolean;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (url: string) => void;
    }
}
declare module "../l2/lessAST" {
    import { MonacoDriver } from "_100554_/l2/lessMonaco";
    interface ILessAST {
        root: {
            [token: string]: {
                value: string;
                line: number;
                column: number;
            };
        };
        [selector: string]: {
            _startLine?: number;
            _endLine?: number;
            [property: string]: {
                value: string;
                line: number;
                column: number;
            } | number | undefined;
        };
    }
    /**
     * @class LessAst
     *
     * This class parses a LESS model, building an AST and converting LESS selectors
     * into a CSS-compatible format. Note that this implementation supports only a subset
     * of LESS functionalities. Advanced features, such as variable interpolation within selectors,
     * parameterized mixins, and color manipulation functions, are not supported.
     *
     * ### Supported Features
     * - **Basic Selector Nesting**: Supports nesting selectors with `&`, converting them to a CSS-compatible format.
     * - **Simple Variables**: Allows the use of variables within properties (e.g., `@color-primary: #333;`).
     * - **Basic LESS Structure**: Parses basic selectors, properties, and tokens, ignoring advanced logic.
     *
     * ### Unsupported Features
     * - **Variable Interpolation within Selectors**: Selectors like `@{variable}-name` are not expanded in the AST.
     * - **Parameterized Mixins**: Mixins with parameters are not evaluated or expanded.
     * - **Mathematical and Color Functions**: Functions like `darken`, `lighten`, or `add` are not processed.
     * - **Looping and Iteration**: Constructs such as `each` or `for` are ignored, as they are not supported in CSS.
     * - **Global Scope Management**: Selectors with `:global` will not retain global scoping behavior.
     *
     * ### Usage Example
     * ```typescript
     * const lessAst = new LessAst("your-url");
     * lessAst.parse();
     * const cssSelector = lessAst.selectorLESS2CSS("less-a-s-t-100554 &:hover");
     * console.log(cssSelector); // Output: less-a-s-t-100554:hover
     * ```
     *
     * ### Limitations
     * Since this class does not handle dynamic processing features of LESS, it is recommended
     * only for static LESS-to-CSS conversions that do not require runtime evaluation.
     */
    export class LessAst {
        ast: ILessAST;
        url: string;
        monacoDriver: MonacoDriver;
        stack: string[];
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * parse a full LESS model (monaco editor)
         */
        parse: () => void;
        /**
         * Parses a single line and updates the AST accordingly.
         */
        private parseLine;
        /**
         * Finds the column index where the given `value` starts in the provided `line`.
         *
         * This method calculates the precise position of the `value` in the string `line`
         * after the first occurrence of a colon (`:`), considering any leading spaces.
         * If the `value` is not found or the colon is absent, it returns undefined.
         *
         * @param {string} line - The line of text to be searched.
         * @param {string} value - The target string to locate within the `line`.
         * @returns {number} - The zero-based index of the starting position of `value` in `line`,
         *                     or undefined if the colon or value is not found.
         *
         * @example
         * // Example 1:
         * const line = "        text-shadow: 3em -8em 3em;";
         * const value = "3em -8em 3em";
         * findColumn(line, value); // Returns: 23
         *
         * // Example 2:
         * const line = "        flex-wrap: wrap;";
         * const value = "wrap";
         * findColumn(line, value); // Returns: 21
         *
         * // Example 3:
         * const line = "invalid line without colon";
         * const value = "anything";
         * findColumn(line, value); // Returns: undefined
         */
        private findColumn;
        /**
         * Lists all themes available in the AST.
         * Each theme is identified by its selector. If the selector has a `.`, the part after the dot is the theme name.
         * If no dot is present, the theme is named "default".
         *
         * @returns An object where each key is a theme name (e.g., "default", "theme2") and each value is the corresponding selector.
         */
        listThemes(): {
            [themeName: string]: string;
        };
        /**
         * Adds a new theme to the specified component variation.
         *
         * @param variation The name of the new theme variation (e.g., "theme3").
         * @returns `true` if the theme was added successfully, `false` otherwise.
         */
        addTheme(variation: string): boolean;
        /**
         * Deletes a theme from the specified component variation.
         *
         * @param variation The name of the theme variation to delete (e.g., "theme2").
         * If `null`, deletes the "default" theme (the main component selector).
         * @returns `true` if the theme was deleted successfully, `false` otherwise.
         */
        deleteTheme(variation: string | null): boolean;
        /**
         * Retrieves the description comments for a specified theme.
         *
         * @param variation The name of the theme variation (e.g., "theme2").
         *                  If `null`, retrieves the "default" theme.
         * @returns An array of comment lines that describe the theme, or an empty array if no comments are found.
         */
        getThemeDescription(variation: string | null): string[];
        private getThemeRangeLines;
        /**
         * Converts a full CSS selector back to the LESS format using "&" where appropriate.
         * - If the selector parts match a parent selector, it replaces the match with "&".
         *
         * @param selector The CSS selector to convert to LESS format.
         * @returns The converted LESS format selector with "&" where possible.
         */
        selectorCSS2LESS: (selector: string) => string;
        selectorLESS2CSS: (selector: string) => string;
        /**
         * Converts a kebab-case property name to camelCase, e.g., background-color to backgroundColor.
         * This ensures property names align with JavaScript/TypeScript conventions.
         */
        toCamelCaseProperty(property: string): string;
        /**
         * Converts a camelCase property name to kebab-case, e.g., backgroundColor to background-color.
         * This ensures property names align with CSS/LESS conventions.
         */
        toKebabCaseProperty(property: string): string;
        getProperty(selector: string, property: string): string | undefined;
        private updateASTAfterInsertLine;
        saveProperty(selector: string, property: string, newValue: string | undefined): boolean;
        /**
         * Returns the last line number within a selector block. aka "}"
         */
        findLastLineInSelector(selectorLESS: string): number;
        findInfoByLine(selectorLESS: string, lineNumber: number): {
            key: string;
            value: string;
        } | undefined;
        /**
         * Finds the most specific LESS selector path for a given line number in the source.
         * - This method searches the AST to determine the most specific selector block containing the specified line.
         * - It returns the full path of the most deeply nested selector in LESS format (e.g., `.cl1 .cl2 &:hover`).
         *
         * ### Usage
         * This method is useful for identifying the exact selector block a line belongs to, especially
         * in scenarios where nested selectors exist in the LESS structure.
         *
         * @param lineNr The line number to check for a corresponding selector.
         * @returns The most specific LESS selector path as a string if found; otherwise, `undefined`.
         */
        findSelectorByLine(lineNr: number): string | undefined;
        /**
         * Finds the start line of the first selector after the root in a JSON representation of a stylesheet.
         *
         * @param json - A JSON object representing a stylesheet, where keys are selectors and values contain metadata.
         * @param tagName - The tag name to exclude from the search.
         * @returns The start line of the first selector after the root, or `null` if no such selector exists.
         */
        findFirstSelectorAfterRoot(ast: Record<string, any>): number | null;
        /**
         * Inserts a new selector into the AST and the Monaco model if it does not exist.
         * - Example: If the AST only contains ".cl1" and `newSelectorLESS` is ".cl1 .cl2 &:hover",
         *   the function will:
         *   1. Check if ".cl1 .cl2" exists in the AST.
         *   2. If not, insert ".cl2" as a nested block within ".cl1".
         *   3. Then insert "&:hover" as a nested selector inside ".cl1 .cl2".
         *
         * This function supports nested selectors by iteratively checking each level
         * and inserting any missing selectors in sequence.
         *
         * @param newSelectorLESS The LESS selector to add to the AST and source code.
         * @result start line of the block
         */
        insertSelector(newSelectorLESS: string): number;
    }
}
declare module "../l2/lessCSS" {
    import { LessAst } from "_100554_/l2/lessAST";
    /**
     * A unique symbol used as a key for properties that should be ignored during JSON serialization.
     *
     * Properties defined with this symbol as a key will not appear in the output of `JSON.stringify`,
     * ensuring that the property is excluded from serialization while avoiding key collisions.
     *
     * @const {symbol} ignoredProperty - A unique symbol for marking non-serializable properties.
     */
    const _editor: unique symbol;
    export class LessCSS {
        lessAST: LessAst;
        selector: string;
        position: "left" | "right";
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        _url: string;
        styles: CSSStyleDeclaration;
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor, position?: "left" | "right");
        setEditor(editor: monaco.editor.IStandaloneCodeEditor): void;
        /**
         * Sets the current selector for which properties will be applied.
         */
        setSelector(selector: string): void;
        /**
         * Retrieves a specific CSS property value for the current selector from the AST.
         * @param property The CSS property to retrieve
         */
        getProperty(property: string): string | undefined;
        /**
         * Sets or updates a CSS property in the AST and source model.
         * @param property The CSS property to set
         * @param value The new value for the property
         */
        setProperty(property: string, value: string): void;
        refresh(): void;
        setStateByLine(lineNumber: number, lineContent: string, emitter: 'editor' | 'helper' | 'preview'): void;
        private clearState;
        private updateState;
        private initStateIfNeeded;
    }
    export interface ICSSState {
        uri: string;
        selector: string | undefined;
        lineNumber: number | undefined;
        lineContent: string | undefined;
        key: string | undefined;
        value: string | undefined;
        lessCSS: LessCSS | undefined;
        emitter: 'editor' | 'helper' | 'preview';
    }
}
declare module "../l2/collabIcons" {
    export const collab_terminal: any;
    export const collab_home: any;
    export const collab_bars: any;
    export const collab_magnifying_glass: any;
    export const collab_file_half_dashed: any;
    export const collab_book_skull: any;
    export const collab_rectangle_list: any;
    export const collab_lightbulb: any;
    export const collab_translate: any;
    export const collab_file_fragment: any;
    export const collab_file_code: any;
    export const collab_dot: any;
    export const collab_minus: any;
    export const collab_user_plus: any;
    export const collab_bell: any;
    export const collab_bell_slash: any;
    export const collab_message: any;
    export const collab_money: any;
    export const collab_clock: any;
    export const collab_clock_static: any;
    export const collab_test: any;
    export const collab_html: any;
    export const collab_typescript: any;
    export const collab_less: any;
    export const collab_fileTest: any;
    export const collab_record: any;
    export const collab_stop: any;
    export const collab_copy: any;
    export const collab_check: any;
    export const collab_double_check: any;
    export const collab_file: any;
    export const collab_location_dot: any;
    export const collab_rotate_left: any;
    export const collab_bug: any;
    export const collab_bug_x12: any;
    export const collab_unbalanced: any;
    export const collab_info: any;
    export const collab_info_circle: any;
    export const collab_question: any;
    export const collab_heart: any;
    export const collab_heart_o: any;
    export const collab_angles_right: any;
    export const collab_chevron_right: any;
    export const collab_chevron_left: any;
    export const collab_chevron_down: any;
    export const collab_undo: any;
    export const collab_clone: any;
    export const collab_file_pen: any;
    export const collab_trash: any;
    export const collab_ellipsis_vertical: any;
    export const collab_ban: any;
    export const collab_file_signature: any;
    export const collab_calendar_days: any;
    export const collab_user: any;
    export const collab_users: any;
    export const collab_book: any;
    export const collab_list_check: any;
    export const collab_folder_tree: any;
    export const collab_cube: any;
    export const collab_pen_nib: any;
    export const collab_plus: any;
    export const collab_bolt: any;
    export const collab_pencil: any;
    export const collab_cubes: any;
    export const collab_floppy_disk: any;
    export const collab_xmark: any;
    export const collab_arrow_up_long: any;
    export const collab_arrow_down_long: any;
    export const collab_arrows_up_down_left_right: any;
    export const collab_caret_righttv: any;
    export const collab_repeat: any;
    export const collab_thumbs_down_solid: any;
    export const collab_thumbs_down: any;
    export const collab_thumbs_up_solid: any;
    export const collab_thumbs_up: any;
    export const collab_edit_style: any;
    export const collab_play: any;
    export const collab_pause: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
    export const collab_commit: any;
    export const collab_branch: any;
    export const collab_pull_request: any;
    export const collab_arrows_rotate: any;
    export const collab_circle_notch: any;
    export const collab_triangle_exclamation: any;
    export const collab_circle_exclamation: any;
    export const collab_gear: any;
    export const collab_spinner_clock: any;
    export const collab_lock: any;
    export const collab_lock_open: any;
    export const collab_image: any;
    export const collab_unsplash: any;
    export const collab_video: any;
    export const collab_code: any;
    export const collab_ellipsis: any;
    export const collab_link: any;
    export const collab_border_top: any;
    export const collab_border_left: any;
    export const collab_border_bottom: any;
    export const collab_border_right: any;
    export const collab_border_topLeft: any;
    export const collab_border_bottomLeft: any;
    export const collab_border_bottomRight: any;
    export const collab_border_topRight: any;
    export const collab_margin_top: any;
    export const collab_margin_left: any;
    export const collab_margin_bottom: any;
    export const collab_margin_right: any;
    export const collab_padding_top: any;
    export const collab_padding_left: any;
    export const collab_padding_bottom: any;
    export const collab_padding_right: any;
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "../l2/collabSpliterVerticalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterVerticalVarFixed100554 extends LitElement {
        fixedheight: string;
        complementcolor: string;
        spliterHeight: number;
        withresize: string;
        actualfixedheight: string;
        msize: string;
        isBottomPaneOpen: boolean;
        slotTop: HTMLElement | undefined;
        slotBottom: HTMLElement | undefined;
        private resizeObserver?;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        private getMSize;
        private getMSizeTop;
        private getMSizeBottom;
        updatePanelsMSize(): void;
        private forceRefreshMsize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        timeoutResize: number | undefined;
        _distributeContent(): void;
        render(): any;
        private styles;
    }
}
declare module "../l2/collabSpliterHorizontalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterHorizontalVarFixed100554 extends LitElement {
        fixedwidth: string;
        complementcolor: string;
        fixedvisible: 'hidden' | 'visible' | 'closed';
        spliterWidth: number;
        actualfixedwidth: string;
        msize: string;
        open: boolean;
        openUser: boolean | undefined;
        slotLeft: HTMLElement[] | undefined;
        slotRight: HTMLElement[] | undefined;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private setFixedValueInPx;
        private getMSize;
        private getMSizeLeft;
        private getMSizeRight;
        private updateMyHeight;
        delay(): Promise<void>;
        private updatePanelsMSize;
        resizeItens(): void;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        firstUpdated(): void;
        render(): any;
        private styles;
    }
}
declare module "../l2/cssHelperIndexBase" {
    export type IMode = 'collapsed' | 'expanded' | 'full';
    export interface IHelpers {
        name: string;
        priority: number;
        widget: string;
        tags: string[];
        description: string;
        mode: IMode;
        liked: boolean;
        likedAnimation: boolean;
        showInfo: boolean;
    }
}
declare module "../l2/pluginStyleIndexItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { IHelpers } from '_100554_/l2/cssHelperIndexBase';
    export class PluginStyleIndexItem extends CollabLitElement {
        help: IHelpers | undefined;
        position: 'left' | 'right';
        mode: 'collapsed' | 'expanded' | 'full';
        pluginLoaded: boolean;
        firstUpdated(): void;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private pluginEl;
        private openPlugin;
        handleOpenPlugin(e: MouseEvent, help: IHelpers, close?: boolean): Promise<void>;
        handleExpandedClick(e: MouseEvent): Promise<void>;
        handleFullClick(e: MouseEvent): void;
        handleLikeClick(e: MouseEvent): Promise<void>;
        handleInfoClick(e: MouseEvent): Promise<void>;
    }
}
declare module "../l2/cssHelperIndex" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { PluginStyleIndexItem } from '_100554_/l2/pluginStyleIndexItem';
    import { IHelpers } from '_100554_/l2/cssHelperIndexBase';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/pluginStyleIndexItem.js';
    export class CssHelperIndex extends StateLitElement {
        private msg;
        private minValueToOpen;
        helpers: IHelpers[];
        avaliablePlugins: IHelpers[];
        position: 'right' | 'left';
        actualProp: string | undefined;
        actualValue: string | undefined;
        actualSelector: string | undefined;
        actualLineContent: string | undefined;
        actualLineNumber: number | undefined;
        private isFirtsLoading;
        state: ICSSState | undefined;
        allPluginsEls: PluginStyleIndexItem[];
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        updated(changedProperties: any): Promise<void>;
        private mergeHelpersArrays;
        firstUpdated(a: any): Promise<void>;
        private baseProject;
        private getAvaliablesPlugins;
        private filterByProp;
        render(): any;
        renderHelper(help: IHelpers, index: number): any;
    }
}
declare module "_102027_/l2/collabMonacoEditor" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMonacoEditor extends StateLitElement {
        msize: string;
        mlsEditor: any;
        get isMls2(): boolean;
        render(): any;
        updated(changed: Map<PropertyKey, unknown>): void;
        private _onMsizeChange;
    }
}
declare module "_102027_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102027_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "../l2/enhancementStyle" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const onAfterChange: (models: mls.editor.IModels) => string;
    export const onAfterMarkersChange: (models: mls.editor.IModels) => string;
    export const onAfterCompile: (modelStyle: mls.editor.IModelStyle) => Promise<void>;
    export const getDesignDetails: (modelStyle: mls.editor.IModelStyle) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export function verifyMarkersError(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function validateStyle(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function getLineByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getLineSelectorByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getRootSelectors(lessContent: string): string[];
    export function isCommentLine(line: string): boolean;
    export function setStylesProcessed(newCss: string, el: HTMLElement, tag: string): Promise<void>;
}
declare module "../l2/serviceSource" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import { LessCSS } from "_100554_/l2/lessCSS";
    import '/_100554_/l2/collabSpliterVerticalVarFixed.js';
    import '/_100554_/l2/collabSpliterHorizontalVarFixed.js';
    import '/_100554_/l2/cssHelperIndex.js';
    import "_102027_/l2/collabMonacoEditor";
    export class ServiceSource100554 extends ServiceBase {
        constructor();
        private baseProject;
        msize: string;
        panelRightOpened: boolean;
        activeModels: mls.editor.IModels | undefined;
        isModeHistory: boolean;
        mode: IModes;
        textOverlayLoading: string;
        currentHistorySourceWithoutSave: string | undefined;
        previousHistorySourceWithoutSave: string | undefined;
        currentHistorySource: string | undefined;
        previousHistorySource: string | undefined;
        historyLanguage: 'typescript' | 'html' | 'less' | 'defs';
        selectedMode: 'icTs' | 'icStyle' | 'icHTML' | 'icTest' | 'icDefs' | 'History' | undefined;
        lockMap: Map<string, boolean>;
        private MINWIDTHTPANELRIGHT;
        lessCSS: LessCSS | undefined;
        private viewState;
        private msg;
        private modeToExt;
        onClickMain(op: string): void;
        onClickTabs: (op: number) => void;
        private readonly tabConfig;
        private readonly opModelMap;
        private ensureAndActivateModel;
        private ensureStorFileExists;
        private refreshActiveModels;
        private activateModelForOp;
        private createModelIfNeedWithOutActiveModel;
        onClickTitle: () => void;
        onClickTools(op: string): void;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        private openActualL2;
        inCreate: Record<string, Promise<void> | undefined>;
        getEditorValue(): string;
        setEditorValue(val: string): boolean;
        setEditorValueByLineTs(val: string, line: number): boolean;
        setEditorValueByLineHtml(val: string, line: number): boolean;
        replaceEditorLineHTML(val: string, line: number): boolean;
        searchLineByStringTs(search: string): number | undefined;
        goToLine(line: number): void;
        setEditorHTMLValue(val: string): boolean;
        getEditorHTMLValue(): string;
        setValueInModeKeepingUndo(model: monaco.editor.ITextModel, val: string, checkFirstLine: boolean): void;
        private setValueInModelInSpecificLine;
        private replaceLineValueInModelInSpecificLine;
        formatMonaco(): void;
        private editorEl;
        private editorHistoryEl;
        overlayLoading: HTMLElement | undefined;
        private verticalSpliter;
        private horizontalSpliter;
        last: mls.IActual | undefined;
        _ed1: monaco.editor.IStandaloneCodeEditor | undefined;
        private _edDiff;
        private mConfEditor;
        private confE2;
        get confE(): string;
        get confETS(): string;
        get confEJS(): string;
        private saveViewState;
        private restaureViewState;
        private toogleHistory;
        private getHistories;
        private openRepo;
        private showHistory;
        private showHistorie2;
        private showPageTheme;
        private showMonacoReset;
        private showConfEditor;
        private onMonacoEvents;
        private goToPosition;
        private mapExt;
        private onMLSEvents;
        private lessChangedEditor;
        private fireEditorEvents;
        private openFiles;
        private activeThisService;
        private closeMenu;
        delay(ms: number): Promise<void>;
        private showThisModel;
        private initProviders;
        private initModelStyle;
        private showActiveModel;
        private initMonaco;
        private monacoGlobalInitialized;
        private initMonaco_GlobalEditor;
        private timeHtmlChangeCursor;
        private lastIdSelected;
        private lastLineNumber;
        private initMonaco_Editor;
        private actionAgentFix;
        private addFixAction;
        private lockEditorForFile;
        private isEditorLocked;
        private unlockEditorForFile;
        private removeFixAction;
        private updateActionBasedOnError;
        private getActualL2File;
        private fireAgentFix;
        private toogleOverlayLoading;
        private initMonaco_EditorDiff;
        private setHistories;
        private createOrGetModelHistory;
        private extractIdValue;
        private loadMonacoConfigurations;
        private getUri;
        private setModelConfEditor;
        private createModelConf;
        timeout_compileConfEditor: number;
        private compileSrcEditor;
        private loadConfEditorFromLocalStorage;
        private saveConfEditorToLocalStorage;
        private getActualTheme;
        private loadMonacoThemeFromLocalStorage;
        private saveMonacoGlobalThemeToLS;
        private getConfEditorToTypescript;
        private setConfEditorFromJavascript;
        private updateMonacoConfigutarions;
        private updateMonacoGlobalTheme;
        private getGlobalPageSetTHeme;
        private _formatIfNeeded;
        private getPosition;
        private getLocalStorageInfo;
        private saveLocalStorageInfo;
        private isReadOnlyArea;
        private getIntervalLinesReadOnly;
        private updatedMSizeEditor;
        private toogleIconsError;
        private currentReviewDecorationIds;
        private highlightReviewLines;
        private changeMode;
        private saveLocalStorageLastOpen;
        private openLastFile;
        getActualRef(): string;
        private lastOrigin;
        private onWidgetActionEvents;
        private selectLineinHTML;
        private registerProviderHTML;
        private isHTMLSystemChange;
        private syncDom;
        handleIcaStateChange(_key: string, _value: any): void;
        updated(changedProperties: any): void;
        connectedCallback(): void;
        firstUpdated(changedProperties: any): void;
        render(): any;
    }
    export type FormattableModel = monaco.editor.ITextModel & {
        needFormat: boolean;
    };
    type IModes = 'icTs' | 'icStyle' | 'icHTML' | 'icTest' | 'icDefs';
}
declare module "_100554_/l2/agentFix" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateFiles(context: mls.msg.ExecutionContext, result: IDataResult): Promise<void>;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
}
declare module "_100554_/l2/agentFullScan.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentFullScan" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output1 = {
        type: "flexible";
        result: INextsTools;
    } | {
        type: "flexible";
        result: INextsAgents[];
    };
    interface INextsTools {
        type: "tool";
        title: string;
        toolName: "toolFilterFilesL2";
        args: string;
    }
    interface INextsAgents {
        id: string;
        type: "agent";
        agentName: string;
        title: string;
        prompt: string;
        page: string;
        position: string;
        mode: "typescript" | "less" | "html";
    }
}
declare module "_100554_/l2/agentImprove.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentImprove" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateFiles(context: mls.msg.ExecutionContext, result: IDataResult): Promise<void>;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
}
declare module "_100554_/l2/agentJudge.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentJudge" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent2(): IAgentAsync;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        title: "A";
        points: 10;
        desc: string;
    }
}
declare module "_100554_/l2/agentPlanner1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/aiPrompts" {
    export function systemAgentsAvailable(): mls.msg.IAMessageInputType;
    export function systemRagsAvailable(): mls.msg.IAMessageInputType;
    export function addRAGAdditionalInformation(rags: string[] | null, prompts: mls.msg.IAMessageInputType[]): void;
    export function systemReturnJsonFormat(): mls.msg.IAMessageInputType;
    export function getAgentsList(): IAgentList[];
    export function getToolsList(): Promise<IToolList[]>;
    export function getRagsList(): string;
    export function systemToolsAvailable(): Promise<mls.msg.IAMessageInputType>;
    export function getListFilesStart(start: 'widget' | 'tool' | 'agent'): Promise<string[]>;
    export function systemTokensLessInstruction(): Promise<mls.msg.IAMessageInputType>;
    export function getPromptByHtml(dt: {
        project: number;
        shortName: string;
        folder: string;
        data?: any;
    }): Promise<mls.msg.IAMessageInputType[]>;
    export function getSource(dt: mls.stor.IFileInfo): Promise<string | null>;
    interface IAgentList {
        agent: string;
        description: string;
    }
    interface IToolList {
        tool: string;
        description: string;
    }
}
declare module "_100554_/l2/agentPlanner1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output1 = {
        type: "result";
        result: string;
    } | {
        type: "agent";
        agentName: string;
        title: string;
        prompt: string;
        rags: string[] | null;
    } | {
        type: "agent";
        agentName: string;
        title: string;
        prompt: string;
        rags: string[] | null;
    };
}
declare module "_100554_/l2/agentReview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentReview" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateFiles(context: mls.msg.ExecutionContext, result: IDataResult): Promise<void>;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
}
declare module "_100554_/l2/aiAgentDefaultFeedback.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class AiAgentDefaultFeedback100554 extends StateLitElement {
        father: HTMLElement | undefined;
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private getChildren;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private clickDetails;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
    }
}
declare module "_100554_/l2/aiPrompts.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/aiPrompts" {
    export function systemAgentsAvailable(): mls.msg.IAMessageInputType;
    export function systemRagsAvailable(): mls.msg.IAMessageInputType;
    export function addRAGAdditionalInformation(rags: string[] | null, prompts: mls.msg.IAMessageInputType[]): void;
    export function systemReturnJsonFormat(): mls.msg.IAMessageInputType;
    export function getAgentsList(): IAgentList[];
    export function getToolsList(): Promise<IToolList[]>;
    export function getRagsList(): string;
    export function systemToolsAvailable(): Promise<mls.msg.IAMessageInputType>;
    export function getListFilesStart(start: 'widget' | 'tool' | 'agent'): Promise<string[]>;
    export function systemTokensLessInstruction(): Promise<mls.msg.IAMessageInputType>;
    export function getPromptByHtml(dt: {
        project: number;
        shortName: string;
        folder: string;
        data?: any;
    }): Promise<mls.msg.IAMessageInputType[]>;
    export function getSource(dt: mls.stor.IFileInfo): Promise<string | null>;
    interface IAgentList {
        agent: string;
        description: string;
    }
    interface IToolList {
        tool: string;
        description: string;
    }
}
declare module "_100554_/l2/ateste.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/ateste" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class SimpleGreeting extends CollabLitElement {
        teste: HTMLTextAreaElement | undefined;
        list: string[];
        current: number;
        tot: number;
        render(): any;
        clickBusca(): Promise<void>;
        changeSource(file: mls.stor.IFileInfo): Promise<string>;
        private parseXMLTripleSlash;
        private parseXML;
    }
    export interface ITripleSlashVariables {
        [key: string]: string;
    }
    export interface ITripleSlash {
        tagName: string;
        variables: ITripleSlashVariables;
    }
}
declare module "_100554_/l2/coachMarks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/coachMarks" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export function addCoachMark(json: ICoachMarks): void;
    export class CoachMarks100554 extends CollabLitElement {
        info: ICoachMarks | undefined;
        error: string;
        firstUpdated(): void;
        render(): any;
        renderError(): any;
        private setInfo;
        private setCoachMarks;
        private clearMe;
        private close;
        private setKey;
        private inLocalStorage;
        private timeInterval;
        private setGlobalDefinitions;
        private createSteps;
        private addAnimation;
        private addTextWithArrow;
        private positionStep;
        private transparency;
        private arrow;
    }
    export interface ICoachMarks {
        key: string;
        transparency: ITransparency;
        fontSize: string;
        timeClose: number;
        steps: ICoachMarkStep[];
    }
    interface ICoachMarkStep {
        elementRef?: string;
        text: string;
        position?: IPosition;
        positionNoRef?: IPositionNoRef;
        marginH?: number;
        marginV?: number;
        arrow?: IArrown;
        duration?: number;
        animation?: IAnimation;
        timeAnimation?: number;
        loopAni?: boolean;
        autoClose: boolean;
    }
    type ITransparency = 'light' | 'normal' | 'strong';
    type IPosition = 'bottom' | 'top' | 'left' | 'right';
    type IPositionNoRef = 'top-start' | 'top-center' | 'top-end' | 'center-start' | 'center-center' | 'center-end' | 'bottom-start' | 'bottom-center' | 'bottom-end';
    type IArrown = 'down' | 'up' | 'left' | 'right' | '';
    type IAnimation = 'flip' | 'pulse' | 'shake';
}
declare module "_100554_/l2/collabActionHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabActionHelper" {
    export const ambient: "RPC" | "";
    export function callBackend<Req = any, Res = any>(config: ActionRef, req: Req): Promise<Res>;
    export interface CollabTrace {
        traceId: string;
        correlationId: string;
        parentId?: string;
        layer: "organism" | "usecase" | "table" | "backend";
        module: string;
        action: string;
        origem: string;
        status?: "ok" | "warn" | "error";
        userId?: string;
        timestamp: string;
        durationMs?: number;
        params?: any;
        result?: string;
        details?: Record<string, string>;
    }
    export interface UserInfo {
        userId: string;
        name: string;
        rules: string[];
    }
    export interface ExecutionContext {
        user: UserInfo;
        authority: string[];
        tenantId: string;
        io: Record<string, string>;
        correlationId: string;
    }
    export function getExecutionContext(): ExecutionContext;
    export function addOrganismTrace(trace: CollabTrace): void;
    export function getOrganismTraces(): CollabTrace[];
    export function traceOrganismAction<Req, Res>(config: {
        module: string;
        organism: string;
        action: string;
    }, req: Req, exec: (ctx: ExecutionContext) => Promise<Res>): Promise<Res>;
    export interface ActionRef {
        module: string;
        organism: string;
        action: string;
    }
    export function withInstrumentation<Req, Res>(meta: ActionRef, handler: (req: Req, ctx: ExecutionContext) => Promise<Res>): (req: Req) => Promise<Res>;
    export function CollabAction<Req, Res>(meta: ActionRef, handler: (req: Req) => Promise<Res>): (req: Req) => Promise<Res>;
}
declare module "_100554_/l2/collabConsole.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabConsole" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabConsole100554 extends StateLitElement {
        logs: Array<{
            type: string;
            message: string;
        }>;
        height: string;
        mode: 'enabled' | 'disabled';
        scope: Window & typeof globalThis;
        private oldLog?;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private changeMode;
        private interceptConsole;
        addLog(type: string, args: any): void;
        render(): any;
    }
}
declare module "_100554_/l2/collabConsoleL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabConsoleL1" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabConsoleL1100554 extends CollabLitElement {
        output: HTMLElement | undefined;
        inputBox: HTMLInputElement | undefined;
        file: string | undefined;
        firstUpdated(): void;
        render(): any;
        private onKeyDown;
        private execute;
        private configLog;
    }
}
declare module "_100554_/l2/collabDOMSync.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabDOMSync" {
    export function sync(): void;
    export function updateHTML(html: string, format?: boolean): void;
    export function setValueInModeKeepingUndo(model: monaco.editor.ITextModel, newContent: string): void;
    export function formatHtml(html: string): string;
}
declare module "_100554_/l2/collabDsInputRange.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabDsInputRange" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export function initCollabDSInputRange(): void;
    export class CollabDSInputRange extends StateLitElement {
        arraySelect: string[];
        useSelect: string;
        value: string;
        valueInput: string;
        prop: string;
        min: number;
        max: number;
        render(): any;
        renderSelect(): any;
        updated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private cursorPosition;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private changeSelect;
        private allChange;
        private fireEvents;
    }
}
declare module "_100554_/l2/collabDsInputSelectColor.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabDsInputSelectColor" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export function initCollabDsInputSelectColor(): void;
    export class CollabDsInputSelectColor extends CollabLitElement {
        get value(): string;
        set value(str: string);
        get valueInput(): string;
        set valueInput(str: string);
        get valueSelect(): string;
        set valueSelect(str: string);
        get valueColor(): string;
        set valueColor(str: string);
        arrayInputSelect: string[];
        arraySelect: string[];
        _valueInput: string;
        _valueSelect: string;
        _valueColor: string;
        prop: string;
        useInput: string;
        useSelect: string;
        useColor: string;
        render(): any;
        renderInput(): any;
        renderSelect(): any;
        renderColor(): any;
        updated(): void;
        private configGetValue;
        private configSetValue;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private allChange;
        private fireEvents;
    }
}
declare module "_100554_/l2/collabEditMd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabEditMd" {
    import { LitElement } from 'lit';
    export function initEditorQuillMD(): boolean;
    export class CollabEditMd extends LitElement {
        private value;
        private opened;
        containerEditor: HTMLElement | undefined;
        containerQuillEditor: HTMLTextAreaElement | undefined;
        iconFinish: HTMLElement | undefined;
        iconEdit: HTMLElement | undefined;
        set cbFinishEdit(fc: Function);
        get text(): any;
        firstUpdated(changedProperties: any): void;
        private cbFinishFc;
        private openedToolbar;
        id: string;
        easyMDE: any;
        editor: any;
        private initEditor;
        private onOpenedChanged;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private _initEditor;
        private onEditClick;
        private onFinishClick;
        render(): any;
        static styles: any;
    }
}
declare module "_100554_/l2/collabEditorPreviewMd" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class PageMdPreview extends CollabLitElement {
        private _tree;
        private _error;
        _html: string;
        private _rawMd;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private configHTML;
        private parseAttrs;
        private parseAttrs_old;
        private parseFieldProps;
        private parseMd;
        private attrsStr;
        private renderNode;
        private colsToGrid;
        private renderChildren;
    }
}
declare module "_100554_/l2/collabFileSystemAccess.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabFileSystemAccess" {
    type CollabFsPermissionMode = 'read' | 'readwrite';
    type CollabFsPermissionDescriptor = {
        mode: CollabFsPermissionMode;
    };
    type CollabFsWritable = {
        write(data: string | Blob | BufferSource): Promise<void>;
        close(): Promise<void>;
    };
    export type CollabFsFileHandle = {
        kind: 'file';
        name: string;
        getFile(): Promise<File>;
        createWritable(): Promise<CollabFsWritable>;
    };
    export type CollabFsDirectoryHandle = {
        kind: 'directory';
        name: string;
        entries(): AsyncIterableIterator<[string, CollabFsDirectoryHandle | CollabFsFileHandle]>;
        getDirectoryHandle(name: string, options?: {
            create?: boolean;
        }): Promise<CollabFsDirectoryHandle>;
        getFileHandle(name: string, options?: {
            create?: boolean;
        }): Promise<CollabFsFileHandle>;
        removeEntry(name: string, options?: {
            recursive?: boolean;
        }): Promise<void>;
        queryPermission?(descriptor: CollabFsPermissionDescriptor): Promise<PermissionState>;
        requestPermission?(descriptor: CollabFsPermissionDescriptor): Promise<PermissionState>;
    };
    global {
        interface Window {
            showDirectoryPicker?: (options?: {
                mode?: CollabFsPermissionMode;
            }) => Promise<CollabFsDirectoryHandle>;
        }
    }
    export interface CollabFsLocalFile {
        path: string;
        content?: string | Blob;
        size: number;
        lastModified: number;
    }
    export interface CollabFsAccessProgress {
        current: number;
        path: string;
    }
    export interface CollabFsListOptions {
        readContent?: boolean;
    }
    export interface CollabFsAccessAdapter {
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
    }
    export class FileSystemAccessAdapter implements CollabFsAccessAdapter {
        isSupported(): boolean;
        showDirectoryPicker(): Promise<CollabFsDirectoryHandle>;
        ensurePermission(handle: CollabFsDirectoryHandle, mode?: CollabFsPermissionMode): Promise<boolean>;
        saveHandle(project: number, handle: CollabFsDirectoryHandle): Promise<void>;
        saveBaseHandle(handle: CollabFsDirectoryHandle): Promise<void>;
        getBaseHandle(): Promise<CollabFsDirectoryHandle | null>;
        removeHandle(project: number): Promise<void>;
        getHandle(project: number): Promise<CollabFsDirectoryHandle | null>;
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
        walkTextFiles(directory: CollabFsDirectoryHandle, prefix: string, files: CollabFsLocalFile[], onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<void>;
        getFileHandleByPath(directory: CollabFsDirectoryHandle, path: string, create: boolean): Promise<CollabFsFileHandle | null>;
        assertSafePath(path: string): void;
        shouldIgnoreDirectory(name: string): boolean;
        shouldIgnoreFile(path: string): boolean;
        shouldReadAsText(path: string): boolean;
        getProjectKey(project: number): string;
        openDB(): Promise<IDBDatabase>;
        requestToPromise<T>(request: IDBRequest<T>): Promise<T>;
        transactionDone(tx: IDBTransaction): Promise<void>;
    }
}
declare module "_100554_/l2/collabFileSystemSync.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabFileSystemSync" {
    export type CollabFsChangeKind = 'browserOnly' | 'localOnly' | 'modified' | 'unsupported' | 'browserModified' | 'diskModified' | 'bothModified' | 'diskOnly' | 'diskDeleted' | 'browserDeleted';
    interface CollabFsFileHandleLike {
        kind: 'file';
        name: string;
        getFile(): Promise<File>;
    }
    interface CollabFsDirectoryHandle {
        kind: 'directory';
        name: string;
        entries(): AsyncIterableIterator<[string, CollabFsDirectoryHandle | CollabFsFileHandleLike]>;
    }
    interface CollabFsLocalFile {
        path: string;
        content?: string | Blob;
        size: number;
        lastModified: number;
    }
    interface CollabFsAccessProgress {
        current: number;
        path: string;
    }
    export interface CollabFsManifest {
        schemaVersion: 1;
        project: number;
        selectedAt: string;
        lastSyncAt: string;
        syncMode: 'manual';
        files: Record<string, CollabFsManifestFile>;
    }
    export interface CollabFsManifestFile {
        path: string;
        versionRef: string;
        browserHash?: string;
        diskHash?: string;
        diskSize?: number;
        diskLastModified?: number;
        lastDirection: CollabFsManifestDirection;
    }
    export interface CollabFsBrowserEntry {
        path: string;
        key: string;
        file: mls.stor.IFileInfo;
        content?: string | Blob;
        hash?: string;
        versionRef: string;
        unsupported: boolean;
    }
    export interface CollabFsLocalEntry {
        path: string;
        content?: string | Blob;
        hash?: string;
        size: number;
        lastModified: number;
    }
    export interface CollabFsChange {
        path: string;
        kind: CollabFsChangeKind;
        file?: mls.stor.IFileInfo;
        browserContent?: string | Blob;
        localContent?: string | Blob;
        browserHash?: string;
        localHash?: string;
        message?: string;
    }
    export interface CollabFsScanResult {
        project: number;
        browserCount: number;
        localCount: number;
        unsupportedCount: number;
        changes: CollabFsChange[];
        scannedAt: string;
    }
    export interface CollabFsPullResult {
        written: number;
        deleted: number;
        skipped: number;
        manifest: CollabFsManifest;
    }
    export interface CollabFsPushResult {
        created: number;
        updated: number;
        deleted: number;
        skipped: number;
        manifest: CollabFsManifest;
    }
    export interface CollabFsFirstSyncValidation {
        empty: boolean;
    }
    export interface CollabFsPullPlan {
        write: string[];
        delete: string[];
        conflict: string[];
        keepLocal: string[];
    }
    export interface CollabFsPushPlan {
        create: string[];
        update: string[];
        delete: string[];
        blocked: string[];
    }
    export interface CollabFsDiffLine {
        type: 'context' | 'added' | 'removed';
        text: string;
    }
    export interface CollabFsProgress {
        phase: 'browser' | 'local' | 'compare' | 'write' | 'delete' | 'push' | 'manifest';
        current: number;
        total?: number;
        path?: string;
    }
    type CollabFsManifestDirection = 'browser-to-fs' | 'fs-to-browser' | 'linked';
    interface CollabFsSyncAdapter {
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: {
            readContent?: boolean;
        }): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
    }
    export class CollabFileSystemSync {
        private adapter;
        constructor(adapter: CollabFsSyncAdapter);
        validateFirstSync(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsFirstSyncValidation>;
        ensureManifest(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsManifest>;
        scan(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsScanResult>;
        planPull(changes: CollabFsChange[]): CollabFsPullPlan;
        planPush(changes: CollabFsChange[]): CollabFsPushPlan;
        pullToFs(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsPullResult>;
        pushToBrowser(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsPushResult>;
        resolveConflict(project: number, handle: CollabFsDirectoryHandle, path: string, keep: 'browser' | 'disk', onProgress?: (progress: CollabFsProgress) => void): Promise<void>;
        private upsertManifestEntry;
        private removeManifestEntry;
        readManifest(handle: CollabFsDirectoryHandle): Promise<CollabFsManifest | null>;
        buildDiff(localContent: string, browserContent: string, maxLines?: number): CollabFsDiffLine[];
        private buildSimpleDiff;
        private hasBrowserChangedSinceManifest;
        private hasLocalChangedSinceManifest;
        private getModifiedKind;
        private isBrowserSideChange;
        private isDiskSideChange;
        private applyManifestHashesToLocalMap;
        private shouldSkipPullWrite;
        private withManifestBrowserHash;
        private createBrowserFile;
        private updateBrowserFile;
        private shouldCreateModel;
        private fireBrowserFileChanged;
        private getBrowserEntries;
        private getBrowserContent;
        private getLocalEntries;
        private getLocalEntriesFromFiles;
        private hydrateBrowserEntry;
        private hydrateLocalEntry;
        private writeManifest;
        private isBrowserFileMappable;
        private isIgnoredRootFile;
        private isProjectLayoutPath;
        private formatPathExamples;
        private isUnchangedByManifest;
        private getBrowserPath;
        private parseLocalPath;
        private isSafeRelativePath;
        private mapByPath;
        private buildTrashStamp;
        private hashContent;
    }
}
declare module "_100554_/l2/collabIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabIcons" {
    export const collab_terminal: any;
    export const collab_home: any;
    export const collab_bars: any;
    export const collab_magnifying_glass: any;
    export const collab_file_half_dashed: any;
    export const collab_book_skull: any;
    export const collab_rectangle_list: any;
    export const collab_lightbulb: any;
    export const collab_translate: any;
    export const collab_file_fragment: any;
    export const collab_file_code: any;
    export const collab_dot: any;
    export const collab_minus: any;
    export const collab_user_plus: any;
    export const collab_bell: any;
    export const collab_bell_slash: any;
    export const collab_message: any;
    export const collab_money: any;
    export const collab_clock: any;
    export const collab_clock_static: any;
    export const collab_test: any;
    export const collab_html: any;
    export const collab_typescript: any;
    export const collab_less: any;
    export const collab_fileTest: any;
    export const collab_record: any;
    export const collab_stop: any;
    export const collab_copy: any;
    export const collab_check: any;
    export const collab_double_check: any;
    export const collab_file: any;
    export const collab_location_dot: any;
    export const collab_rotate_left: any;
    export const collab_bug: any;
    export const collab_bug_x12: any;
    export const collab_unbalanced: any;
    export const collab_info: any;
    export const collab_info_circle: any;
    export const collab_question: any;
    export const collab_heart: any;
    export const collab_heart_o: any;
    export const collab_angles_right: any;
    export const collab_chevron_right: any;
    export const collab_chevron_left: any;
    export const collab_chevron_down: any;
    export const collab_undo: any;
    export const collab_clone: any;
    export const collab_file_pen: any;
    export const collab_trash: any;
    export const collab_ellipsis_vertical: any;
    export const collab_ban: any;
    export const collab_file_signature: any;
    export const collab_calendar_days: any;
    export const collab_user: any;
    export const collab_users: any;
    export const collab_book: any;
    export const collab_list_check: any;
    export const collab_folder_tree: any;
    export const collab_cube: any;
    export const collab_pen_nib: any;
    export const collab_plus: any;
    export const collab_bolt: any;
    export const collab_pencil: any;
    export const collab_cubes: any;
    export const collab_floppy_disk: any;
    export const collab_xmark: any;
    export const collab_arrow_up_long: any;
    export const collab_arrow_down_long: any;
    export const collab_arrows_up_down_left_right: any;
    export const collab_caret_righttv: any;
    export const collab_repeat: any;
    export const collab_thumbs_down_solid: any;
    export const collab_thumbs_down: any;
    export const collab_thumbs_up_solid: any;
    export const collab_thumbs_up: any;
    export const collab_edit_style: any;
    export const collab_play: any;
    export const collab_pause: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
    export const collab_commit: any;
    export const collab_branch: any;
    export const collab_pull_request: any;
    export const collab_arrows_rotate: any;
    export const collab_circle_notch: any;
    export const collab_triangle_exclamation: any;
    export const collab_circle_exclamation: any;
    export const collab_gear: any;
    export const collab_spinner_clock: any;
    export const collab_lock: any;
    export const collab_lock_open: any;
    export const collab_image: any;
    export const collab_unsplash: any;
    export const collab_video: any;
    export const collab_code: any;
    export const collab_ellipsis: any;
    export const collab_link: any;
    export const collab_border_top: any;
    export const collab_border_left: any;
    export const collab_border_bottom: any;
    export const collab_border_right: any;
    export const collab_border_topLeft: any;
    export const collab_border_bottomLeft: any;
    export const collab_border_bottomRight: any;
    export const collab_border_topRight: any;
    export const collab_margin_top: any;
    export const collab_margin_left: any;
    export const collab_margin_bottom: any;
    export const collab_margin_right: any;
    export const collab_padding_top: any;
    export const collab_padding_left: any;
    export const collab_padding_bottom: any;
    export const collab_padding_right: any;
}
declare module "_100554_/l2/collabInit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/driverLib" {
    export function myFetchQL(info: IFetchQl): Promise<{
        status: number;
        ret: any;
    }>;
    export function getMyKeysBranch(project: number, needVerifyBranch?: boolean): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function base64ToBlob(content: string, tp: string, name: string): Promise<string | Blob>;
    export function fileToBase64(file: Blob | File): Promise<string>;
    export function base64EncodeUnicode(str: string): string;
    export function base64DecodeUnicode(str: string): string;
    interface IFetchQl {
        query: string;
        variables: any;
        url: string;
        method: string;
        headers: any;
    }
}
declare module "../l2/driverGithub" {
    export function init(initString: string): void;
    export class DriverGitHub extends mls.stor.others.DriverIOBase {
        shortName: mls.cbe.Provider;
        project: number;
        driverVersion: string;
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        getHistory(fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(fileInfo: mls.stor.IFileInfo, ref: string): Promise<string | null>;
        getUrl(file: mls.stor.IFileInfo): string;
        getVersionFromFiles(options: {
            owner: string;
            repo: string;
            branchName: string;
            files: mls.stor.IFileInfo[];
        }): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(owner: string, repo: string, branchName: string): Promise<boolean>;
        createNewBranch(option: {
            owner: string;
            repo: string;
            branch: string;
            newBranch: string;
        }): Promise<boolean>;
        createPullRequest(options: {
            owner: string;
            repo: string;
            title: string;
            branch: string;
            description: string;
        }): Promise<boolean>;
        reviewPullRequest(options: {
            owner: string;
            repo: string;
            branch: string;
            idRequest: string;
            isApproved: boolean;
        }): Promise<boolean>;
        listPullRequests(owner: string, repo: string): Promise<mls.stor.others.IPullRequest[]>;
        listForks(owner: string, repo: string): Promise<mls.stor.others.IFork[]>;
        listBranches(owner: string, repo: string): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(login: string): Promise<mls.stor.others.IOrg[]>;
        createRepository(login: string, repo: string, organization: string, description: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        deleteRepository(repo: string, organization: string): Promise<boolean>;
        createFork(login: string, repoOri: string, orgOri: string, orgDest: string): Promise<boolean>;
        renameRepository(owner: string, repo: string, newName: string): Promise<boolean>;
        createFileInRepo(owner: string, repo: string, path: string, content: string | Uint8Array): Promise<boolean>;
        deleteFileInRepo(owner: string, repo: string, path: string): Promise<boolean>;
        changeVisibility(owner: string, repo: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        verifyRepositoryNew(owner: string, repo: string, user: string): Promise<"free" | "reuse" | "wait" | "error">;
        verifyPermission(owner: string, repo: string, login: string): Promise<mls.stor.others.IPermission>;
        setPermissionAction(owner: string, repo: string, login: string): Promise<boolean>;
        addVariable2(owner: string, repo: string, name: string, value: string): Promise<boolean>;
        addVariable(name: string, value: string): Promise<boolean>;
        updateVariable(name: string, value: string): Promise<boolean>;
        listVariables(): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(name: string): Promise<boolean>;
        checkFork(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        syncFork(options: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        private _getUrl;
        private _getContents;
        private getContents2;
        private getContent3;
        private _setContents;
        private _setContentsOld;
        private setContents2;
        private afterSave;
        private setContentAddFile;
        private verifyAndGetContent;
        private _loadFilesInfo;
        private getFilesRepo;
        private auxLoadFilesInfo2Reenter;
        private _getHistory;
        private _getHistoryContent;
        private fecthQl;
        buildFileGroups(files: mls.stor.IFileInfo[], maxSizeBytes?: number): Promise<{
            type: 'single' | 'group';
            files: mls.stor.IFileInfo[];
        }[]>;
        private processFiles;
        private githubRequest;
        private getSha;
        private saveFile;
        private deleteFile;
        private processFilesOld;
        syncForkIO(opt: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        checkForkIO(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        private delVariableIO;
        private listVariablesIO;
        private updateVariableIO;
        private addVariableIO;
        private setPermissionActionIO;
        private verifyPermissionIO;
        private verifyRepositoryNewIO;
        private changeVisibilityIO;
        private createFileInRepoIO;
        private renameRepositoryIO;
        private createForkIO;
        private deleteRepositoryIO;
        private createRepositoryIO;
        private getOrganizationsIO;
        private getUserInfoIO;
        private listBranchesIO;
        private listForksIO;
        private listPullRequestsIO;
        private reviewPullRequestIO;
        private createPullRequestIO;
        private sleep;
        private createNewBranchIO;
        private checkBranchExistenceIO;
        private getHistoryContentIO;
        private getFilesIO;
        private getFilesRestIO;
        private verifyMKey;
        private saveMultipleFilesIO;
        private getFilesRepoIO;
        private getHistoryIO;
        private getVersionFromFilesIO;
        private getOidLastCommitFromInfoIO;
        private getIdProjectIO;
        private getOidLastCommitIO;
        private convertToBase64;
    }
}
declare module "../l2/driverGitlab" {
    export function init(initString: string): void;
    export class DriverGitLab extends mls.stor.others.DriverIOBase {
        shortName: mls.cbe.Provider;
        project: number;
        driverVersion: string;
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        getHistory(fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(fileInfo: mls.stor.IFileInfo, ref: string): Promise<string | null>;
        getUrl(file: mls.stor.IFileInfo): string;
        getVersionFromFiles(options: {
            owner: string;
            repo: string;
            branchName: string;
            files: mls.stor.IFileInfo[];
        }): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(owner: string, repo: string, branchName: string): Promise<boolean>;
        createNewBranch(option: {
            owner: string;
            repo: string;
            branch: string;
            newBranch: string;
        }): Promise<boolean>;
        createPullRequest(options: {
            owner: string;
            repo: string;
            title: string;
            branch: string;
            description: string;
        }): Promise<boolean>;
        reviewPullRequest(options: {
            owner: string;
            repo: string;
            branch: string;
            idRequest: string;
            isApproved: boolean;
        }): Promise<boolean>;
        listPullRequests(owner: string, repo: string): Promise<mls.stor.others.IPullRequest[]>;
        listForks(owner: string, repo: string): Promise<mls.stor.others.IFork[]>;
        listBranches(owner: string, repo: string): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(login: string): Promise<mls.stor.others.IOrg[]>;
        createRepository(login: string, repo: string, organization: string, description: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        deleteRepository(repo: string, organization: string): Promise<boolean>;
        createFork(login: string, repoOri: string, orgOri: string, orgDest: string): Promise<boolean>;
        renameRepository(owner: string, repo: string, newName: string): Promise<boolean>;
        createFileInRepo(owner: string, repo: string, path: string, content: string | Uint8Array): Promise<boolean>;
        changeVisibility(owner: string, repo: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        verifyRepositoryNew(owner: string, repo: string, user: string): Promise<"free" | "reuse" | "wait" | "error">;
        verifyPermission(owner: string, repo: string, login: string): Promise<mls.stor.others.IPermission>;
        addVariable(name: string, value: string): Promise<boolean>;
        updateVariable(name: string, value: string): Promise<boolean>;
        listVariables(): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(name: string): Promise<boolean>;
        checkFork(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        syncFork(options: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        private _getUrl;
        private _getContents;
        private getContents2;
        private getContent;
        private _setContents;
        private setContentsnew;
        private verifyAndGetContent;
        private _loadFilesInfo;
        private getFilesRepo;
        private fecthQl;
        private myFetchGet;
        private _getHistoryContentIO;
        private _getHistoryIO;
        private getFilesRepoIO;
        private saveMultipleFilesIO;
        private getFilesIO;
        private syncForkIO;
        private checkForkIO;
        private delVariableIO;
        private listVariablesIO;
        private updateVariableIO;
        private addVariableIO;
        private verifyPermissionIO;
        private verifyRepositoryNewIO;
        private changeVisibilityIO;
        private getVersionFromFilesIO;
        private createFileInRepoIO;
        private renameRepositoryIO;
        private createForkIO;
        private deleteRepositoryIO;
        private createRepositoryIO;
        private getOrganizationsIO;
        private getUserInfoIO;
        private listBranchesIO;
        private listForksIO;
        private listPullRequestsIO;
        private reviewPullRequestIO;
        private createPullRequestIO;
        private createNewBranchIO;
        private checkBranchExistenceIO;
        private getLastCommitFromInfo;
        private getIDProject;
    }
}
declare module "../l2/coachMarks" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export function addCoachMark(json: ICoachMarks): void;
    export class CoachMarks100554 extends CollabLitElement {
        info: ICoachMarks | undefined;
        error: string;
        firstUpdated(): void;
        render(): any;
        renderError(): any;
        private setInfo;
        private setCoachMarks;
        private clearMe;
        private close;
        private setKey;
        private inLocalStorage;
        private timeInterval;
        private setGlobalDefinitions;
        private createSteps;
        private addAnimation;
        private addTextWithArrow;
        private positionStep;
        private transparency;
        private arrow;
    }
    export interface ICoachMarks {
        key: string;
        transparency: ITransparency;
        fontSize: string;
        timeClose: number;
        steps: ICoachMarkStep[];
    }
    interface ICoachMarkStep {
        elementRef?: string;
        text: string;
        position?: IPosition;
        positionNoRef?: IPositionNoRef;
        marginH?: number;
        marginV?: number;
        arrow?: IArrown;
        duration?: number;
        animation?: IAnimation;
        timeAnimation?: number;
        loopAni?: boolean;
        autoClose: boolean;
    }
    type ITransparency = 'light' | 'normal' | 'strong';
    type IPosition = 'bottom' | 'top' | 'left' | 'right';
    type IPositionNoRef = 'top-start' | 'top-center' | 'top-end' | 'center-start' | 'center-center' | 'center-end' | 'bottom-start' | 'bottom-center' | 'bottom-end';
    type IArrown = 'down' | 'up' | 'left' | 'right' | '';
    type IAnimation = 'flip' | 'pulse' | 'shake';
}
declare module "../l2/collabManagerCoachMarks" {
    export function initManagerCoachMark(): void;
}
declare module "_100554_/l2/collabInit" {
    import { LitElement } from 'lit';
    export function initCompileMonaco(project: number): Promise<boolean>;
    export class CollabInit extends LitElement {
        private actualProject;
        /**
         * Indicates if the user is anonymous based on the cookie loginUser
         * @returns `true` if the user is anonymous; otherwise, `false`.
         */
        get isAnonymous(): boolean;
        /**
         * Retrieves the avatar URL from the `avatarUrl` attribute.
         * @returns The URL of the avatar, or an empty string if not defined.
         */
        get avatarUrl(): string;
        /**
         * Retrieves the base Project from the `baseProject` attribute.
         * @returns The URL of the avatar, or an empty string if not defined.
         */
        get baseProject(): number;
        /**
         * Lit lifecycle method called after the component is first updated.
         * Initializes the component's configuration.
         */
        firstUpdated(): void;
        render(): any;
        /**
         * Initializes the system life cycle.
         * To show logs using: https://collab.codes/?traceLifeCycle=true
         */
        private init;
        private setEventsModel;
        private setEvents;
        private onLevelChanged;
        private firstAccessLevels;
        private levelHandlers;
        private onLevelChangedToL2;
        /**
         * Loads and sets up collaboration drivers asynchronously.
         */
        private setDrivers;
        /**
         * Instantiates and registers the GitHub collaboration driver asynchronously.
         */
        private instanceDriverGitHub;
        /**
         * Instantiates and registers the GitLab collaboration driver asynchronously.
         */
        private instanceDriverGitLab;
        /**
         * Sets the base URL for the project and retrieves the user's language.
         * @returns The user's language (e.g., 'en-US', 'pt-BR').
         */
        private setAndGetBaseUrl;
        /**
         * Retrieves the user's preferred language or defaults to 'en-US'.
         * @returns The user's language.
         */
        private getUserLanguageOrDefault;
        /**
         * Retrieves the browser's language setting.
         * @returns The browser's language.
         */
        private getNavigatorLanguage;
        /**
         * Sets the `lang` attribute of the HTML `<html>` element.
         * @param lang The language code to set (e.g., 'en-US').
         */
        private setHTMLLang;
        private initCoachMark;
        /**
         * Sets the theme for the application based on user settings or OS preferences.
         */
        private setTheme;
        /**
         * Retrieves the theme from user settings or defaults to the OS preference.
         * @returns The theme ('dark' or 'light').
         */
        private getTheme;
        /**
         * Retrieves the user's OS theme preference.
         * @returns The OS theme preference ('dark' or 'light').
         */
        private getUserThemeOS;
        /**
         * Sets CSS tokens for light and dark themes by retrieving data from a cache.
         */
        private setTokensCss;
        /**
         * Configures navigation settings, including avatar and status, for the collaboration interface.
         * @param avatarUrl The URL of the avatar.
         * @param language The user's language.
         * @param isAnonymous Indicates whether the user is anonymous.
         */
        private enableNav;
        private flags;
        /**
         * Retrieves the last selected project ID from localStorage.
         * @returns The last selected project ID as a number, or `undefined` if not found.
         */
        private getLastProjectSelected;
        /**
         * Sets the actual project in the `mls` structure based on the last selected project.
         * @returns The last selected project ID as a number, or `undefined` if not found.
         */
        private setProjectActual;
        /**
         * Sets the current organization in the `mls` structure based on the provided project ID.
         * @param project The project ID to determine the organization index.
         */
        private setOrgActual;
        /**
         * Asynchronously loads the base project information if it is not already loaded.
         * Utilizes the `mls.stor.server.loadProjectInfoIfNeeded` method with the base project ID.
         * @returns A promise that resolves when the base project information is loaded.
         */
        private loadProjectBase;
        /**
         * Loads the information of the last accessed project if it exists.
         * If the `actualProject` is defined, it attempts to load the project's information
         * from the server using the `loadProjectInfoIfNeeded` method.
         *
         * Optionally logs the lifecycle trace if the global `traceLifeCycle` is enabled.
         *
         * @returns A promise that resolves when the project information has been loaded.
         */
        private loadLastProject;
        private setLastOpenedFiles;
        private FILEL6;
        private FILEL5;
        private setDefaultFiles;
        private restoreSideFile;
        private getPath;
        private setLastModule;
        /**
         * Checks for the presence of a `<collab-sticky-notification>` element on the page.
         * If found, it invokes the `show()` method on the element to display notifications.
         */
        private showMessagesIfNeeded;
        private anonymousServices;
        /**
         * Retrieves a list of services for the current project, either for anonymous users or regular users.
         * If the user is anonymous, it returns the `anonymousServices`. Otherwise, it loads project-specific
         * services by fetching and sorting the available menu actions for different levels and positions (Left/Right).
         *
         * @returns A promise that resolves to an object containing an array of services, sorted by priority.
         * The services are categorized by levels and positions (Left/Right) and are returned as a semicolon-separated
         * string for each level.
         */
        private getServices;
    }
}
declare module "_100554_/l2/collabInputSearch" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabInputSearch extends CollabLitElement {
        private msg;
        placeholder: string;
        value: string;
        private focused;
        firstUpdated(): void;
        render(): any;
        private _onInput;
        private _onFocus;
        private _onBlur;
        private _clear;
        private _onKeyDown;
    }
}
declare module "_100554_/l2/collabInputTag.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabInputTag" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export function initCollabInputTag(): boolean;
    export class CollabInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_100554_/l2/collabL3EditText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabL3PreviewText" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabL3PreviewText extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "../l2/collabL3PreviewTextAttr" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabL3PreviewText extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "../l2/collabL3PreviewTextI18n" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabL3PreviewTextI18n extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "_100554_/l2/collabL3EditText" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabL3PreviewText.js';
    import '/_100554_/l2/collabL3PreviewTextAttr.js';
    import '/_100554_/l2/collabL3PreviewTextI18n.js';
    export class CollabL3EditText extends CollabLitElement {
        dev: boolean;
        target: HTMLElement | null;
        private json;
        private baseTexti18n;
        private baseSearch;
        constructor();
        firstUpdated(): void;
        render(): any;
        private getBaseI18n;
        private process;
        private initState;
        private addEls;
        save(): Promise<boolean>;
        private replaceValueAfterKeyWithUndo;
        private replaceAttributeValueWithUndo;
        private replaceI18nValueWithUndo;
    }
}
declare module "_100554_/l2/collabL3PreviewText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabL3PreviewText" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabL3PreviewText extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "_100554_/l2/collabL3PreviewTextAttr.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabL3PreviewTextAttr" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabL3PreviewText extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "_100554_/l2/collabL3PreviewTextI18n.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabL3PreviewTextI18n" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabL3PreviewTextI18n extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "_100554_/l2/collabLanguages.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabLanguages" {
    export const languages: ICollabLanguage[];
    export interface ICollabLanguage {
        code: string;
        name: string;
    }
}
declare module "_100554_/l2/collabManagerCoachMarks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabManagerCoachMarks" {
    export function initManagerCoachMark(): void;
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_pin: any;
    export const collab_star: any;
    export const collab_paperclip: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_circle_check: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
    export const collab_trash: any;
    export const collab_link: any;
    export const collab_plug: any;
    export const collab_robot: any;
    export const collab_refresh: any;
    export const collab_floppy_disk: any;
    export const collab_crm: any;
    export const collab_tasks: any;
    export const collab_connect: any;
    export const collab_moments: any;
    export const collab_apps: any;
    export const collab_warning: any;
    export const collab_signal: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
}
declare module "_102025_/l2/collabMessagesTaskDetails" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTaskDetails extends StateLitElement {
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderTaskModeJson;
        private renderTaskModeDetails;
        private renderDirectResult;
        private renderDirectClarification;
        private hasPendingClarification;
        private renderlLongMemory;
        private renderTaskInfo;
        private renderTaskInteractions;
        private renderPayload;
        private renderPayloadAgent;
        private renderInteration;
        private renderAgent;
        private renderTool;
        private renderClarificationDetails;
        private renderFlexible;
        private renderClarification;
        private renderResult;
        private setClarification;
        private executeHTMLClarificationScript;
        private syntaxHighlight;
        private onTaskChange;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewAgent" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabMessagesTaskPreviewAgent extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIAgentStep | null;
        agentDescription: string;
        private prompts;
        private mode;
        elEditor: IHTMLEditorElement | undefined;
        private lastKey;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): void;
        update(changedProperties: any): void;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderInputs(): any;
        renderTools(tools: any[], toolChoice: any): any;
        private toolName;
        private renderJsonCard;
        renderPayload(): any;
        renderPrompt(prompt: mls.msg.IAMessageInputType, idx: number): any;
        renderResults(): any;
        private init;
        private getDescription;
        private getPrompts;
        private selectTabInput;
        private selectTabInfo;
        private selectTabResult;
        private selectTabPayload;
        private ensureEditorCreated;
        private mountEditor;
        private createModel;
        private updateEditorContent;
        private getPayloadTabValue;
        private hasPayloadTabValue;
        private getTracePayload;
        private parseTracePayloadItem;
        private isTracePayloadItem;
        private readonly editorConf;
        private canRestartStep;
        private isParallelChild;
        private restartStep;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewClarification" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabMessagesTaskPreviewClarification extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIClarificationStep | null;
        private mode;
        private tag;
        clarificationid: HTMLDivElement | undefined;
        private elClarification;
        firstUpdated(): void;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderClarification(): any;
        renderResults(): any;
        private selectTabClarification;
        private selectTabInfo;
        private getFile;
        private getAgentBeforeStep;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewFlexible" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabMessagesTaskPreviewFlexible extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private createModel;
        private updateEditorContent;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewTools" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabMessagesTaskPreviewTools extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIToolStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderTools(): any;
        renderResults(): any;
        private selectTabTools;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewResult" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabMessagesTaskPreviewResult extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIResultStep | null;
        private mode;
        render(): any;
        renderMode(): any;
        renderInfo(): any;
        renderSummary(title: string): any;
        renderResults(): any;
        private selectTabInfo;
        private selectTabResult;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreviewRaw" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabMessagesTaskPreviewRaw extends CollabLitElement {
        private mode;
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        step: mls.msg.AIFlexibleResultStep | null;
        msize: string;
        elEditor: IHTMLEditorElement | undefined;
        private resizeObserver;
        private get sharedEditor();
        private get sharedMonaco();
        firstUpdated(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, any>): void;
        private ensureEditorCreated;
        /**
         * Called every time the flexible tab becomes visible.
         * Creates the shared editor once, then re-appends it to the fresh #elEditor node.
         */
        private mountEditor;
        private observeEditorHost;
        private createModel;
        private updateEditorContent;
        private layoutEditor;
        render(): any;
        private setMode;
        private renderMode;
        private renderInfo;
        private renderTaskModeDetails;
        private renderTaskInfo;
        private renderlLongMemory;
        private renderSummary;
        private renderFlexible;
        private renderResults;
        private readonly editorConf;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_102025_/l2/collabMessagesTaskPreview" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "_102025_/l2/collabMessagesTaskPreviewAgent";
    import "_102025_/l2/collabMessagesTaskPreviewClarification";
    import "_102025_/l2/collabMessagesTaskPreviewFlexible";
    import "_102025_/l2/collabMessagesTaskPreviewTools";
    import "_102025_/l2/collabMessagesTaskPreviewResult";
    import "_102025_/l2/collabMessagesTaskPreviewRaw";
    export class CollabMessagesTaskPreview extends CollabLitElement {
        message: mls.msg.Message | null;
        task: mls.msg.TaskData | null;
        modeTest: boolean;
        father: HTMLElement | undefined;
        initialStep: string;
        private stepMap;
        private navigationStack;
        private currentStepId;
        private allSteps;
        private lastStepId;
        private payloadStepIds;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderStep(): any;
        renderNavigation(stepId: number): any;
        private navigableStepIds;
        private setCurrentStep;
        private goFirst;
        private goPrev;
        private goNext;
        private goLast;
        renderStepDetails(step: any | undefined): any;
        renderBreadcrumb(): any;
        renderRaw(): any;
        renderAgent(step: mls.msg.AIAgentStep): any;
        renderClarification(step: mls.msg.AIClarificationStep): any;
        renderFlexible(step: mls.msg.AIFlexibleResultStep): any;
        renderTools(step: mls.msg.AIToolStep): any;
        renderResult(step: mls.msg.AIResultStep): any;
        renderWorkflow(step: {
            stepId: number;
            type: string;
            workflowName?: string;
            status?: string;
            nextSteps?: any[];
        }): any;
        private init;
        private onTaskChange;
        private buildStepMap;
        private tryNext;
        private navigateToStep;
        private goBack;
    }
}
declare module "_102025_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class AiAgentDefaultFeedback102025 extends StateLitElement {
        father: HTMLElement | undefined;
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        private openCapableAgents;
        private openedView;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private resolveOpenCapableAgents;
        private clickOpen;
        private renderOpenedView;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private rowIndex;
        private getChildren;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private clickDetails;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
    }
}
declare module "_102025_/l2/collabMessagesTaskLogPreview" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/aiAgentDefaultFeedback";
    export class PluginTaskLogPreview102025 extends StateLitElement {
        currentStepId: number;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        father: HTMLElement | undefined;
        template?: TemplateResult;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: any): void;
        render(): any;
        private onTaskChange;
        private createFeedBack;
    }
}
declare module "_102025_/l2/collabMessagesSyncNotifications" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const threadSyncMap: Map<string, boolean>;
    type NotificationTarget = {
        threadId: string;
        sourceThreadId: string;
        taskId?: string;
    };
    export function removeThreadFromSync(threadId: string): void;
    export function clearThreadNotification(threadId: string): void;
    export function clearTaskNotification(taskId: string): void;
    export function refreshNotificationIndicator(): Promise<void>;
    export function markThreadReadLocally(threadId: string, lastMessageReadTime?: string, notificationTarget?: NotificationTarget): Promise<msg.ThreadPerformanceCache | undefined>;
    export function hasThreadNotificationPending(threadId: string): boolean;
    export function hasTaskNotificationPending(taskId: string): boolean;
    export function getPendingTaskNotificationsForThread(threadId: string): string[];
    export function checkIfNotificationUnread(): Promise<boolean>;
    export function listenToThreadEvents(): Promise<void>;
    export function getThreadUpdateInBackground(reference: string): Promise<void>;
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        alt: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichTextParser" {
    export type RichToken = {
        type: 'text';
        value: string;
    } | {
        type: 'bold';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'italic';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'strike';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'inline-code';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'heading';
        level: number;
        children: RichToken[];
    } | {
        type: 'horizontal-rule';
    } | {
        type: 'blockquote';
        children: RichToken[];
        lines: RichToken[][];
    } | {
        type: 'list';
        ordered: boolean;
        items: RichListItem[];
    };
    export interface RichListItem {
        marker: string;
        children: RichToken[];
    }
    export function parseRichText(input: string): RichToken[];
    export function parseInlineRichText(input: string, skipCodeBlock?: boolean): RichToken[];
}
declare module "_102025_/l2/collabMessagesPromptEditing" {
    export interface EditResult {
        text: string;
        selectionStart: number;
        selectionEnd: number;
    }
    interface LineInfo {
        start: number;
        end: number;
        text: string;
    }
    interface ListMarker {
        indent: string;
        marker: string;
        spacing: string;
        content: string;
        ordered: boolean;
    }
    export function getLineInfo(text: string, cursor: number): LineInfo;
    export function replaceRange(text: string, start: number, end: number, value: string, cursorOffset?: number): EditResult;
    export function insertText(text: string, selectionStart: number, selectionEnd: number, value: string, cursorOffset?: number): EditResult;
    export function getListMarker(line: string): ListMarker | undefined;
    export function getNextListPrefix(marker: ListMarker): string;
    export function applySmartNewline(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function indentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function outdentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function wrapSelection(text: string, selectionStart: number, selectionEnd: number, before: string, after: string, placeholder?: string): EditResult;
    export function makeCodeBlock(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function makeLinePrefix(text: string, selectionStart: number, selectionEnd: number, prefix: string): EditResult;
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabMessagesAvatar";
    export function serializeUserMentions(text: string, users: msg.User[]): string;
    export function deserializeUserMentions(text: string, users?: msg.User[]): string;
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        overlayElement?: HTMLElement;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: msg.User[];
        allUsersValids: msg.User[];
        hasSelection: boolean;
        selectedFiles: File[];
        sendError: string;
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        allowAttachments: boolean;
        showSubmitButton: boolean;
        submitOnEnter: boolean;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        enableRichPreview?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        private handleScroll;
        private renderRichToken;
        private renderRichOverlay;
        render(): any;
        private renderToolbar;
        private renderReply;
        private renderSelectedAttachments;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private preventToolbarFocus;
        private updateSelectionState;
        private clearSelectionState;
        private applyEditResult;
        private syncTextAreaEdit;
        private applyInlineFormat;
        private applyCodeBlock;
        private applyLinePrefix;
        private applyLink;
        private openAttachmentPicker;
        private handleAttachmentInput;
        private removeSelectedAttachment;
        private emitTextChange;
        private formatFileSize;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private handlePaste;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102025_/l2/collabMessagesChatMessage" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IChatPreferences, IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    export class CollabMessagesChatMessage102025 extends StateLitElement {
        message?: IMessage;
        messageId?: string;
        allThreads: msg.Thread[];
        actualThread: IThreadInfo | undefined;
        usersAvaliables: msg.User[];
        currentUser: msg.User | undefined;
        userId: string | undefined;
        toolbarHighlighted: boolean;
        openedReactionMessageId?: string;
        reactionPickerTarget?: HTMLElement;
        openedMenuFor?: string;
        messageMenuTarget?: HTMLElement;
        openedReactionListMessageId?: string;
        reactionListTarget?: HTMLElement;
        openedFollowupActionsMessageId?: string;
        followupActionTarget?: HTMLElement;
        followupActionAnchor?: DOMRect;
        userPreferenceChat?: IChatPreferences;
        private messageMenuPlacement;
        private reactionListPlacement;
        private isEditingMessage;
        private editContent;
        private showEditHistory;
        private showFullContent;
        onTaskClick?: Function;
        private msg;
        private readonly documentClickHandler;
        private readonly documentScrollHandler;
        private readonly reactionEmojis;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(): void;
        render(): any;
        private renderMessage;
        private renderMessageByLanguage;
        private renderMessageContentByLanguage;
        private renderModerationNotice;
        private renderEditMessageForm;
        private renderEditHistory;
        private renderHistoryToggle;
        private hasMessageHistory;
        private hasReadConfirmationHistory;
        private renderAttachments;
        private renderAttachment;
        private renderDeleteAttachmentButton;
        private openAttachment;
        private refreshAttachmentImage;
        private loadAttachmentUrl;
        private onDeleteAttachmentClick;
        private canDeleteAttachment;
        private canWriteThread;
        private canModerateThread;
        private isMessageContentHidden;
        private canDeleteMessage;
        private canModerateMessage;
        private canEditMessage;
        private parseCompactDate;
        private getUserName;
        private formatFileSize;
        private replyCache;
        private renderReplyPreview;
        private loadReplyPreview;
        private onReplyPreviewClick;
        private renderMessageResultByLanguage;
        private renderReadConfirmations;
        private renderExecutionFollowup;
        private getReadConfirmationStatusByUser;
        private getReadConfirmationKind;
        private getActiveExecutionFollowup;
        private getFollowupStatusItems;
        private hasExecutionFollowup;
        private isFollowupReaction;
        private getFollowupReactionForUser;
        private renderFollowupIcon;
        private getFollowupLabel;
        private renderUserLabel;
        private formatLocalDateTime;
        private renderMessageFooterResult;
        private renderCollabMessagesRichPreview;
        private renderSeeMoreButton;
        private onMentionClick;
        private positionModalByTarget;
        private isCurrentThreadDirectMessage;
        private onChannelHover;
        private removeAllUserModal;
        private removeAllChannelModal;
        private getTitleMessageTranslated;
        private renderReactions;
        private renderReactionListPopup;
        private findUser;
        private getEmojiReactionListItems;
        private getFollowupReactionListItems;
        private getReactionListItems;
        private getReactionSummaryItems;
        private getReadConfirmationSummaryItems;
        private getReadConfirmationReactionListItems;
        private getActiveReadConfirmationStatuses;
        private getReactionIcon;
        private getReactionLabel;
        private openReactionList;
        private updateReactionListPlacement;
        private removeReactionFromList;
        private closeReactionList;
        private renderSideAction;
        private renderFollowupQuickActions;
        private getFollowupActions;
        private renderReactionButtonAdd;
        private renderReactionPicker;
        private onPickerEmojiSelect;
        private onReadConfirmationPickerClick;
        private onFollowupActionClick;
        private openFollowupActionMenu;
        private closeFollowupActionMenu;
        private onDocumentClick;
        private isPopupInteractionTarget;
        private closeLocalPopups;
        private openReactionPicker;
        private closeReactionPicker;
        private toggleReaction;
        private updateReactionOnDb;
        private animateReactionPicker;
        private positionReactionPicker;
        private positionFollowupActionMenu;
        private renderSubMenuButton;
        private openMessageMenu;
        private positionMessageMenu;
        private closeMessageMenu;
        private renderMessageMenu;
        private onReplyClick;
        private onCopyTextClick;
        private onCopyLinkClick;
        private getMessageLink;
        private onMarkUnreadClick;
        private onForwardClick;
        private onEditClick;
        private onEditCancelClick;
        private onEditSaveClick;
        private onViewHistoryClick;
        private onHistoryToggleClick;
        private onPinClick;
        private onFavoriteClick;
        private onReadConfirmationClick;
        private onFollowupActionsMenuClick;
        private onMessageActionClick;
        private isPinned;
        private isFavorite;
        private getMentionedUserIds;
        private hasReadConfirmation;
        private hasPendingReadConfirmation;
        private hasAllReadConfirmationsConfirmed;
        private canCancelReadConfirmation;
        private closeAllPopups;
        private updateMessageMenuPlacement;
        private getMessageOrderAt;
        private normalizeMessageId;
    }
}
declare module "_102025_/l2/collabMessagesTaskRoom" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import * as msg from "_102025_/l2/shared/interfaces";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesPrompt";
    export class CollabMessagesTaskRoom extends StateLitElement {
        task: msg.TaskData | undefined;
        message: msg.Message | undefined;
        userId: string | undefined;
        private roomThread;
        private roomUsers;
        private messages;
        private loading;
        private error;
        private showScrollToBottom;
        private messagesContainer?;
        private ensuredKey;
        private lastRenderedMessageCount;
        private didInitialScroll;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onMessagesScroll;
        private scrollToBottom;
        private scrollMessagesToBottom;
        private ensureRoom;
        private ensureRoomOnServer;
        private openKnownRoom;
        private syncMessages;
        private loadLocalMessages;
        private markRoomReadLocally;
        private sendMessage;
        private cacheRoomThread;
        private getLastOrderAt;
        private getResponseLastOrderAt;
        private onThreadChange;
        private onMessageChange;
        private getUserId;
        private getParentThreadId;
        private getEnsureKey;
        private canUseTaskRoom;
        private toMessageView;
    }
}
declare module "_102025_/l2/collabMessagesTaskInfo" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabMessagesTaskDetails";
    import "_102025_/l2/collabMessagesTaskPreview";
    import "_102025_/l2/collabMessagesTaskLogPreview";
    import "_102025_/l2/collabMessagesTaskRoom";
    type TaskInfoTab = 'workflow' | 'step' | 'raw' | 'todo' | 'chat' | 'statistics';
    export type TaskLLMCall = {
        stepId: number;
        title: string;
        provider: string;
        model: string;
        alias: string;
        stage: string;
        inputTokens: number;
        outputTokens: number;
        cost: number;
        llmMs: number;
    };
    export type TaskModelStatistic = {
        key: string;
        provider: string;
        model: string;
        alias: string;
        stage: string;
        calls: number;
        inputTokens: number;
        outputTokens: number;
        cost: number;
        llmMs: number;
    };
    export type TaskExecutionStatistics = {
        totalSteps: number;
        interactions: number;
        totalCost: number;
        interactionCost: number;
        traceCost: number;
        llmCalls: number;
        inputTokens: number;
        outputTokens: number;
        totalLlmMs: number;
        totalExecutionMs: number;
        errorCount: number;
        failedSteps: number;
        fallbackCount: number;
        traceRecords: number;
        jsonTraceRecords: number;
        byStatus: Record<string, number>;
        byType: Record<string, number>;
        models: TaskModelStatistic[];
        slowestCalls: TaskLLMCall[];
        errorLines: string[];
    };
    export function buildTaskStatistics(task: mls.msg.TaskData | undefined): TaskExecutionStatistics;
    export class CollabMessagesTaskInfo extends StateLitElement {
        private elParent;
        private contentPluginStyle;
        private forceViewRaw;
        private hasTodo;
        private currentStepId;
        private msg;
        task: mls.msg.TaskData | undefined;
        message: mls.msg.Message | undefined;
        restartPooling: boolean;
        isTest: boolean;
        stepid: string;
        seen: Set<string>;
        interactionClarification: mls.msg.AIAgentStep | undefined;
        directClarification: HTMLElement | undefined;
        directClarificationContent: HTMLElement | undefined;
        private activeTab;
        isClarificationPending: boolean;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderTab(isClarificationPending?: boolean): any;
        renderTabContent(activeTab: TaskInfoTab): any;
        renderRaw(): any;
        renderStep(): any;
        renderTodo(): any;
        renderChat(): any;
        renderStatistics(): any;
        renderDirectClarification(): any;
        private hasPendingClarification;
        renderClarification(payload: mls.msg.AIClarificationStep): any;
        private clickForceViewRaw;
        private setClarification;
        private executeHTMLClarificationScript;
        private setTab;
        private renderStatKpi;
        private renderModelsTable;
        private renderStatsBars;
        private renderSlowCalls;
        private formatMoney;
        private formatInteger;
        private formatDuration;
        private canUseTaskRoom;
        private onTaskChange;
        private normalizeServiceDetailContainer;
        private restoreServiceDetailContainer;
    }
}
declare module "_100554_/l2/collabMessagesEnvironment" {
    import { CollabMessagesEnvironment } from '_102036_/l2/environmentContract';
    export const collabEnvironment: CollabMessagesEnvironment;
}
declare module "_100554_/l2/collabNav4Menu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabNav4Menu" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    interface TabItem {
        text: string;
        icon?: string;
        allowClose?: boolean;
    }
    export class CollabNav4Menu extends StateLitElement {
        selectedIndex: number;
        mode: 'full' | 'onlyicon' | 'fixed';
        options: TabItem[];
        private isDropdownOpen;
        private toggleDropdown;
        private handleSelect;
        private handleClose;
        render(): any;
        private renderNav;
    }
}
declare module "_100554_/l2/collabOrgHome.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-home-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-home-100554\n  file: _100554_/l2/collabOrgHome.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays an organization overview card with name, description and\n    counters for projects, users and teams. Data is read from mls.stor\n    on connectedCallback.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during initial fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed in the error state\n    - name: _data\n      type: OrgData | null\n      default: null\n      description: Organization data fetched from mls.stor\n\n  interfaces:\n    OrgData:\n      name: string\n      description: string\n      totalProjects: number\n      totalUsers: number\n      totalTeams: number\n\n  lifecycle:\n    connectedCallback: calls _fetchOrg()\n\n  methods:\n    _fetchOrg:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', _data = null, call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - populate _data from lastOrg.sett\n        - on catch: set _error from err.message or msg.error\n        - finally: set _loading = false, call requestUpdate()\n      field_mapping:\n        name: orgName\n        description: lastOrg.sett.description\n        totalProjects: lastOrg.sett.projects.length\n        totalUsers: lastOrg.sett.users.length\n        totalTeams: lastOrg.sett.teams.length\n\n  events: []\n\n  render:\n    priority_order:\n      - if _loading \u2192 _renderLoading()\n      - if _error   \u2192 _renderError()\n      - if _data    \u2192 _renderData(_data)\n      - fallback    \u2192 empty template\n\n    loading_state:\n      element: div.state-loading\n      children:\n        - span.spinner\n        - span \u2192 msg.loading\n\n    error_state:\n      element: div.state-error\n      children:\n        - span.error-icon \u2192 \u26A0 (static)\n        - span \u2192 this._error\n        - button @click \u2192 _fetchOrg() \u2192 msg.again\n\n    data_state:\n      element: div.org-card\n      children:\n        - div.org-header:\n            children:\n              - h1.org-name \u2192 data.name\n              - p.org-description \u2192 data.description or 'no description' if empty\n        - div.org-counters:\n            children:\n              - div.counter:\n                  - span.counter-value \u2192 data.totalProjects\n                  - span.counter-label \u2192 msg.projects\n              - div.counter:\n                  - span.counter-value \u2192 data.totalUsers\n                  - span.counter-label \u2192 msg.users\n              - div.counter:\n                  - span.counter-value \u2192 data.totalTeams\n                  - span.counter-label \u2192 msg.teams\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgHome" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabOrgHome extends CollabLitElement {
        private msg;
        project: number;
        private _loading;
        private _error;
        private _data;
        connectedCallback(): void;
        private _fetchOrg;
        private _renderLoading;
        private _renderError;
        private _renderData;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgInviteUser.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-invite-user-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-invite-user-100554\n  file: _100554_/l2/collabOrgInviteUser.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Form for inviting a user to an organization. Receives teams list and\n    loading/status state from the parent via props. Dispatches invite-submit\n    with form data, leaving submission logic to the parent.\n\n  props:\n    - name: teams\n      type: string[]\n      default: []\n      description: List of team names used to populate the team select options\n    - name: loading\n      type: boolean\n      default: false\n      description: Disables all fields and submit button when true\n    - name: status\n      type: InviteStatus\n      default: idle\n      description: Controls which feedback message is displayed\n\n  internal_state:\n    - name: _usernameOrEmail\n      type: string\n      default: \"\"\n      description: Current value of the username or email input\n    - name: _initialTeam\n      type: string\n      default: \"\"\n      description: Current value of the team select\n    - name: _complementaryText\n      type: string\n      default: \"\"\n      description: Current value of the complementary text textarea\n\n  interfaces:\n    InviteStatus: \"'idle' | 'success' | 'error'\"\n\n  methods:\n    _handleInput:\n      returns: void\n      params:\n        - field: \"'username' | 'team' | 'text'\"\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement\n        - if field === 'username': set _usernameOrEmail = target.value\n        - if field === 'team': set _initialTeam = target.value\n        - if field === 'text': set _complementaryText = target.value\n        - call requestUpdate()\n\n    _handleSubmit:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - call e.preventDefault()\n        - dispatch CustomEvent('invite-submit') with detail below, bubbles true, composed true\n        - detail: { username_or_email: _usernameOrEmail, initial_team: _initialTeam, complementary_text: _complementaryText }\n\n    _renderFeedback:\n      returns: TemplateResult\n      steps:\n        - if status === 'success' \u2192 div.feedback.success with msg.feedbackSuccess\n        - if status === 'error'   \u2192 div.feedback.error with msg.feedbackError\n        - otherwise \u2192 empty template\n\n  events:\n    - name: invite-submit\n      when: form is submitted\n      detail:\n        username_or_email: string\n        initial_team: string\n        complementary_text: string\n      options: { bubbles: true, composed: true }\n\n  render:\n    root:\n      element: form.invite-form\n      event: \"@submit \u2192 _handleSubmit(e)\"\n      fields:\n        - id: invite-username\n          label_key: fieldUsername\n          element: input\n          type: text\n          value_binding: _usernameOrEmail\n          disabled_when: loading\n          event: \"@input \u2192 _handleInput('username', e)\"\n\n        - id: invite-team\n          label_key: fieldTeam\n          element: select\n          value_binding: _initialTeam\n          disabled_when: loading\n          event: \"@change \u2192 _handleInput('team', e)\"\n          options:\n            - value: \"\" \u2192 msg.fieldTeamPlaceholder (default option)\n            - map this.teams to option[value=t] with t as label\n\n        - id: invite-text\n          label_key: fieldCompText\n          element: textarea\n          rows: 3\n          value_binding: _complementaryText\n          disabled_when: loading\n          event: \"@input \u2192 _handleInput('text', e)\"\n\n      footer:\n        - _renderFeedback()\n        - div.form-actions:\n            - button.btn-primary type=submit ?disabled=loading\n                label: if loading then msg.btnSubmitting else msg.btnSubmit\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgInviteUser" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    type InviteStatus = 'idle' | 'success' | 'error';
    export class CollabOrgInviteUser extends CollabLitElement {
        teams: string[];
        loading: boolean;
        status: InviteStatus;
        private msg;
        private _usernameOrEmail;
        private _initialTeam;
        private _complementaryText;
        private _handleInput;
        private _handleSubmit;
        private _renderFeedback;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgManager.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-manager-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-manager-100554\n  file: _100554_/l2/collabOrgManager.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Shell component that renders a sidebar navigation and dynamically displays\n    the active section component. Acts as the layout manager for all\n    organization sub-pages.\n\n  imports:\n    - /_100554_/l2/collabOrgHome.js\n    - /_100554_/l2/collabOrgSettings.js\n    - /_100554_/l2/collabOrgProjects.js\n    - /_100554_/l2/collabOrgUsers.js\n    - /_100554_/l2/collabOrgTeams.js\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index passed down to every section component\n    - name: activeSection\n      type: string\n      default: home\n      description: Key of the currently active section\n\n  internal_state:\n    - name: _menuItems\n      type: Array<{ section: string; label: string }>\n      description: Static list of visible menu entries\n      value:\n        - { section: home,     label: Home }\n        - { section: settings, label: Settings }\n        - { section: projects, label: Projects }\n        - { section: users,    label: Users }\n        - { section: teams,    label: Teams }\n      commented_out:\n        - { section: trash,    label: Trash }\n        - { section: explorer, label: Explorer }\n        - { section: verify,   label: Verify }\n\n  methods:\n    _handleSectionClick:\n      returns: void\n      params:\n        - section: string\n      steps:\n        - set this.activeSection = section\n        - dispatch CustomEvent('section-changed') with detail { section }, bubbles true, composed true\n\n    _renderIcon:\n      returns: TemplateResult\n      params:\n        - section: string\n      steps:\n        - define a Record<string, TemplateResult> map with inline SVG for each key\n        - return icons[section] or html`` if not found\n      icon_keys:\n        - home\n        - settings\n        - projects\n        - trash\n        - users\n        - teams\n        - explorer\n        - verify\n\n    _renderSection:\n      returns: TemplateResult\n      steps:\n        - define a Record<string, TemplateResult> sectionMap with one child element per key\n        - each child receives prop project=\"${this.project}\"\n        - return sectionMap[this.activeSection] or div.fallback if not found\n      section_map:\n        home:     collab-org-home-100554\n        settings: collab-org-settings-100554\n        projects: collab-org-projects-100554\n        trash:    collab-org-trash-100554\n        users:    collab-org-users-100554\n        teams:    collab-org-teams-100554\n        explorer: collab-org-explorer-100554\n        verify:   collab-org-verify-100554\n\n  events:\n    - name: section-changed\n      when: when a menu item is clicked\n      detail: { section: string }\n      options: { bubbles: true, composed: true }\n\n  render:\n    root:\n      element: div.layout\n      children:\n        - nav.sidebar:\n            content: >\n              maps _menuItems to div.menu-item elements.\n              active item receives class \"active\" when section === activeSection.\n              each item has @click \u2192 _handleSectionClick(item.section).\n              each item has @keydown \u2192 calls _handleSectionClick on Enter or Space.\n              each item has tabindex=\"0\".\n            children_per_item:\n              - span.menu-icon \u2192 _renderIcon(item.section)\n              - span.menu-label \u2192 this.msg[item.section] (cast as any)\n              - span.menu-arrow \u2192 \u203A (static)\n        - main.content:\n            content: _renderSection()\n\n  i18n:\n    languages: [en, pt]\n    default: en\n\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "../l2/collabOrgHome" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabOrgHome extends CollabLitElement {
        private msg;
        project: number;
        private _loading;
        private _error;
        private _data;
        connectedCallback(): void;
        private _fetchOrg;
        private _renderLoading;
        private _renderError;
        private _renderData;
        render(): TemplateResult;
    }
}
declare module "../l2/collabOrgSettings" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabOrgSettings extends CollabLitElement {
        project: number;
        private msg;
        private _loading;
        private _saving;
        private _error;
        private _successMessage;
        private _form;
        connectedCallback(): void;
        private _fetchSettings;
        private _handleSave;
        private _handleInput;
        private _handleArchive;
        private _handleDelete;
        private _renderLoading;
        private _renderFeedback;
        private _renderForm;
        private _renderDangerZone;
        render(): TemplateResult;
    }
}
declare module "../l2/collabOrgProjects" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabOrgProjects extends CollabLitElement {
        project: number;
        private msg;
        private projects;
        private searchQuery;
        private _loading;
        private _error;
        connectedCallback(): void;
        private fetchProjects;
        private handleSearch;
        private handleViewProject;
        private getFiltered;
        private renderProjectList;
        render(): TemplateResult;
    }
}
declare module "../l2/collabOrgInviteUser" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    type InviteStatus = 'idle' | 'success' | 'error';
    export class CollabOrgInviteUser extends CollabLitElement {
        teams: string[];
        loading: boolean;
        status: InviteStatus;
        private msg;
        private _usernameOrEmail;
        private _initialTeam;
        private _complementaryText;
        private _handleInput;
        private _handleSubmit;
        private _renderFeedback;
        render(): TemplateResult;
    }
}
declare module "../l2/collabOrgUsers" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "/_100554_/l2/collabOrgInviteUser.js";
    export class CollabOrgUsers extends CollabLitElement {
        project: number;
        private msg;
        private _members;
        private _accessMap;
        private _loading;
        private _error;
        private _inviteOpen;
        connectedCallback(): void;
        private _fetchMembers;
        private configUsers;
        private _fetchAllAccess;
        private _fetchRepoAccess;
        private _toggleInvite;
        private _handleInviteSuccess;
        private _renderAccessBadge;
        private _renderAccessCell;
        private _renderTable;
        render(): TemplateResult;
    }
}
declare module "../l2/collabOrgTeamCard" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    interface Member {
        idx: number;
        name: string;
        avatar: string;
    }
    export class CollabOrgTeamCard extends CollabLitElement {
        private team;
        project: number;
        members: Member[];
        users: Member[];
        loading: boolean;
        private msg;
        private _addOpen;
        private _addUsername;
        private _confirmingRemove;
        firstUpdated(): void;
        private _toggleAdd;
        private _handleAddInput;
        private _handleAdd;
        private _requestRemove;
        private _cancelRemove;
        private _confirmRemove;
        private _renderMember;
        private _renderAddForm;
        render(): TemplateResult;
    }
}
declare module "../l2/collabOrgTeams" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabOrgTeamCard.js';
    export class CollabOrgTeams extends CollabLitElement {
        project: number;
        private msg;
        private _teams;
        private _loading;
        private _error;
        private _expandedTeam;
        private _newTeamOpen;
        private _newTeamName;
        private _formStatus;
        private _formError;
        connectedCallback(): void;
        private _fetchTeams;
        private configTeams;
        private _handleCreate;
        private _toggleExpand;
        private _toggleNewTeam;
        private _handleNameInput;
        private _emitViewProjects;
        private _emitViewUsers;
        private _renderNewTeamForm;
        private _renderTable;
        private _renderRow;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgManager" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabOrgHome.js';
    import '/_100554_/l2/collabOrgSettings.js';
    import '/_100554_/l2/collabOrgProjects.js';
    import '/_100554_/l2/collabOrgUsers.js';
    import '/_100554_/l2/collabOrgTeams.js';
    export class CollabOrgManager extends CollabLitElement {
        private msg;
        project: number;
        activeSection: string;
        private _handleSectionClick;
        private _renderIcon;
        private _renderSection;
        private _menuItems;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgProjects.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-projects-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-projects-100554\n  file: _100554_/l2/collabOrgProjects.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays active and archived projects of an organization, with a search\n    filter. Each project has a \"View project\" button that switches the active\n    project and reloads the page.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: projects\n      type: mls.cbe.IPrj_settings[]\n      default: []\n      description: Full list of projects fetched from mls.stor\n    - name: searchQuery\n      type: string\n      default: \"\"\n      description: Current value of the search input\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed when fetch fails\n\n  lifecycle:\n    connectedCallback: calls fetchProjects()\n\n  methods:\n    fetchProjects:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - set this.projects = lastOrg.sett.projects\n        - on catch: set _error from err.message or 'Unknown error'\n        - finally: set _loading = false, call requestUpdate()\n\n    handleSearch:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement\n        - set this.searchQuery = input.value\n        - call requestUpdate()\n\n    handleViewProject:\n      returns: void\n      params:\n        - project: mls.cbe.IPrj_settings\n      steps:\n        - call mls.setActualProject(project.id)\n        - call mls.l5.getProjectOrgIndex(project.id) to get orgIndex\n        - call mls.l5.setActualOrg(orgIndex)\n        - call window.location.reload()\n\n    getFiltered:\n      returns: mls.cbe.IPrj_settings[]\n      params:\n        - archived: boolean\n      steps:\n        - lowercase this.searchQuery into query\n        - filter this.projects where p.name includes query\n        - when archived=true also require p.archived_at !== ''\n        - when archived=false no archived_at restriction\n\n    renderProjectList:\n      returns: TemplateResult\n      params:\n        - items: mls.cbe.IPrj_settings[]\n      steps:\n        - if items.length === 0 return p.no-results with msg.noResults\n        - otherwise return ul.project-list\n        - each item is li.project-item with span.project-name and button.btn-view\n        - span.project-name shows p.name(p.id)\n        - button.btn-view @click \u2192 handleViewProject(p) \u2192 msg.viewProject\n\n  events: []\n\n  render:\n    priority_order:\n      - if _loading \u2192 div.state-loading with span.spinner and span msg.loading\n      - if _error   \u2192 div.feedback.error with msg.error\n      - default     \u2192 full layout\n\n    default_layout:\n      element: div.container\n      children:\n        - input.search-input:\n            type: text\n            placeholder: msg.searchPlaceholder\n            value binding: this.searchQuery\n            event: \"@input \u2192 handleSearch\"\n        - section.section:\n            title: h2.section-title \u2192 msg.activeProjects\n            content: renderProjectList(getFiltered(false))\n        - section.section:\n            title: h2.section-title \u2192 msg.archivedProjects\n            content: renderProjectList(getFiltered(true))\n  \n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgProjects" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabOrgProjects extends CollabLitElement {
        project: number;
        private msg;
        private projects;
        private searchQuery;
        private _loading;
        private _error;
        connectedCallback(): void;
        private fetchProjects;
        private handleSearch;
        private handleViewProject;
        private getFiltered;
        private renderProjectList;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgSettings.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-settings-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-settings-100554\n  file: _100554_/l2/collabOrgSettings.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Form for editing an organization's registration data, with data reading\n    via mls.stor, save with feedback, and a danger zone section with\n    destructive actions.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during initial fetch\n    - name: _saving\n      type: boolean\n      default: false\n      description: Disables Save button and shows \"Saving\u2026\" during submit\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed below the form\n    - name: _successMessage\n      type: string\n      default: \"\"\n      description: Success message displayed below the form\n    - name: _form\n      type: OrgSettings\n      default: { url: \"\", company: \"\", location: \"\", email: \"\", logo: \"\", description: \"\" }\n      description: Form data being edited\n\n  interfaces:\n    OrgSettings:\n      url: string\n      company: string\n      location: string\n      email: string\n      logo: string\n      description: string\n\n  lifecycle:\n    connectedCallback: calls _fetchSettings()\n\n  methods:\n    _fetchSettings:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName].value and JSON.parse it\n        - extract l5_actionOrgSettings from parsed object\n        - map fields to _form\n        - if org not found: set _error = \"Not found organization\"\n        - on catch: set _error from err.message\n        - finally: set _loading = false, call requestUpdate()\n      field_mapping:\n        html_url: url\n        company: company\n        location: location\n        email: email\n        logo: logo\n        description: description\n\n    _handleSave:\n      returns: Promise<void>\n      steps:\n        - call e.preventDefault()\n        - set _saving = true, clear _error and _successMessage, call requestUpdate()\n        - build payload { l5_actionOrgSettings: { ...this._form } } typed as any\n        - call mls.l5.setProjectSettings() \u2014 pending, keep commented\n        - simulate 600ms delay via Promise + setTimeout\n        - set _successMessage = this.msg.feedbackSuccess\n        - dispatch org-updated event\n        - on catch: set _error from err.message\n        - finally: set _saving = false, call requestUpdate()\n\n    _handleInput:\n      returns: void\n      params:\n        - field: keyof OrgSettings\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement | HTMLTextAreaElement\n        - update _form immutably with new field value\n        - clear _successMessage\n\n    _handleArchive:\n      returns: void\n      steps:\n        - empty body, future implementation\n\n    _handleDelete:\n      returns: void\n      steps:\n        - dispatch org-deleted event\n\n  events:\n    - name: org-updated\n      when: after saving successfully\n      options: { bubbles: true, composed: true }\n    - name: org-deleted\n      when: when Delete button is clicked\n      options: { bubbles: true, composed: true }\n\n  render:\n    loading_state:\n      element: div.state-loading\n      children:\n        - span.spinner\n        - span with msg.loadingSettings\n\n    feedback:\n      - condition: _successMessage truthy\n        element: div.feedback.success\n      - condition: _error truthy\n        element: div.feedback.error\n      - condition: neither\n        element: empty template\n\n    form:\n      element: form.settings-form\n      event: submit \u2192 _handleSave\n      fields:\n        - label_key: fieldUrl\n          element: input\n          type: url\n          field: url\n        - label_key: fieldCompany\n          element: input\n          type: text\n          field: company\n        - label_key: fieldLocation\n          element: input\n          type: text\n          field: location\n        - label_key: fieldEmail\n          element: input\n          type: email\n          field: email\n        - label_key: fieldLogo\n          element: input\n          type: url\n          field: logo\n        - label_key: fieldDescription\n          element: textarea\n          rows: 6\n          field: description\n          label_hint: fieldDescriptionHint\n      footer:\n        - feedback block\n        - button.btn-primary type=submit\n          disabled_when: _saving\n          label_key_default: btnSave\n          label_key_saving: btnSaving\n\n    danger_zone:\n      element: section.danger-zone\n      title: h2.danger-title \u2192 msg.dangerTitle\n      items:\n        - title_key: archiveTitle\n          desc_key: archiveDesc\n          button_class: btn-warning\n          action: _handleArchive()\n        - title_key: deleteTitle\n          desc_key: deleteDesc\n          button_class: btn-danger\n          action: _handleDelete()\n\n    root:\n      condition: not _loading\n      element: div.settings-root\n      children:\n        - h1.page-title \u2192 msg.pageTitle\n        - _renderForm()\n        - _renderDangerZone()\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgSettings" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabOrgSettings extends CollabLitElement {
        project: number;
        private msg;
        private _loading;
        private _saving;
        private _error;
        private _successMessage;
        private _form;
        connectedCallback(): void;
        private _fetchSettings;
        private _handleSave;
        private _handleInput;
        private _handleArchive;
        private _handleDelete;
        private _renderLoading;
        private _renderFeedback;
        private _renderForm;
        private _renderDangerZone;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgTeamCard.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-settings-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-team-card-100554\n  file: _100554_/l2/collabOrgTeamCard.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays the member list of a single team. Allows adding a new member\n    via a select dropdown and removing existing members with an inline\n    confirmation step. Data is read from mls.stor on firstUpdated.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n    - name: members\n      type: Member[]\n      default: []\n      description: Current list of members in this team, populated on firstUpdated\n    - name: users\n      type: Member[]\n      default: []\n      description: Full list of org users used to populate the add select, populated on firstUpdated\n    - name: loading\n      type: boolean\n      default: false\n      description: Disables action buttons when true\n\n  internal_state:\n    - name: team\n      type: Team | undefined\n      default: undefined\n      description: >\n        Team object passed via property binding (.team) from parent.\n        Not decorated with @property \u2014 received as a direct property set.\n    - name: _addOpen\n      type: boolean\n      default: false\n      description: Controls visibility of the add user form\n    - name: _addUsername\n      type: string\n      default: \"\"\n      description: Current value of the add user select\n    - name: _confirmingRemove\n      type: string | null\n      default: null\n      description: Username currently pending removal confirmation, null if none\n\n  interfaces:\n    Member:\n      idx: number\n      name: string\n      avatar: string\n\n    Team:\n      name: string\n      auth: string\n      projectCount: number\n      userCount: number\n      users: Member[]\n\n  lifecycle:\n    firstUpdated:\n      steps:\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: return early\n        - if this.team is defined: set this.members = this.team.users\n        - iterate lastOrg.sett.users and build Member[] with idx, name, avatar placeholder\n        - assign result to this.users\n\n  methods:\n    _toggleAdd:\n      returns: void\n      steps:\n        - toggle _addOpen\n        - reset _addUsername = ''\n        - call requestUpdate()\n\n    _handleAddInput:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement\n        - set _addUsername = target.value\n\n    _handleAdd:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - call e.preventDefault()\n        - if _addUsername.trim() is empty: return\n        - set _addOpen = false, _addUsername = ''\n        - call requestUpdate()\n      note: actual add logic is not yet implemented, body is a placeholder\n\n    _requestRemove:\n      returns: void\n      params:\n        - username: string\n      steps:\n        - set _confirmingRemove = username\n        - call requestUpdate()\n\n    _cancelRemove:\n      returns: void\n      steps:\n        - set _confirmingRemove = null\n        - call requestUpdate()\n\n    _confirmRemove:\n      returns: void\n      params:\n        - username: string\n      steps:\n        - set _confirmingRemove = null\n        - call requestUpdate()\n      note: actual remove logic is not yet implemented, body is a placeholder\n\n    _renderMember:\n      returns: TemplateResult\n      params:\n        - m: Member\n      steps:\n        - derive confirming = _confirmingRemove === m.name\n        - render li.member-item with div.member-info (img.avatar + span.member-name)\n        - if confirming: render div.confirm-inline with\n            span.confirm-label \u2192 msg.confirmMessage\n            button.btn-danger ?disabled=loading @click \u2192 _confirmRemove(m.name) \u2192 msg.confirmRemove\n            button.btn-secondary @click \u2192 _cancelRemove() \u2192 msg.cancelRemove\n        - otherwise: render button.btn-remove ?disabled=loading @click \u2192 _requestRemove(m.name) with \uD83D\uDDD1 icon\n\n    _renderAddForm:\n      returns: TemplateResult\n      steps:\n        - render form.add-form @submit \u2192 _handleAdd(e)\n        - select.add-input with placeholder=msg.addUserPlaceholder, .value=_addUsername, ?disabled=loading, @input \u2192 _handleAddInput\n          options:\n            - option value=\"-1\" empty label (default)\n            - map this.users to option[value=u.idx] with u.name as label\n        - button.btn-primary type=submit ?disabled=loading \u2192 msg.btnAdd\n        - button.btn-secondary type=button @click \u2192 _toggleAdd() \u2192 msg.btnCancel\n\n  events: []\n\n  render:\n    root:\n      element: div.team-card\n      children:\n        - ul.member-list:\n            if members.length > 0: map members to _renderMember(m)\n            otherwise: li.no-members \u2192 msg.noMembers\n        - div.add-section:\n            if _addOpen: _renderAddForm()\n            otherwise: button.btn-add-toggle ?disabled=loading @click \u2192 _toggleAdd()\n                        label: \"+ \" + msg.addUser\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgTeamCard" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    interface Member {
        idx: number;
        name: string;
        avatar: string;
    }
    export class CollabOrgTeamCard extends CollabLitElement {
        private team;
        project: number;
        members: Member[];
        users: Member[];
        loading: boolean;
        private msg;
        private _addOpen;
        private _addUsername;
        private _confirmingRemove;
        firstUpdated(): void;
        private _toggleAdd;
        private _handleAddInput;
        private _handleAdd;
        private _requestRemove;
        private _cancelRemove;
        private _confirmRemove;
        private _renderMember;
        private _renderAddForm;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgTeams.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-teams-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-teams-100554\n  file: _100554_/l2/collabOrgTeams.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays a table of organization teams with name, auth, project count\n    and user count. Supports expanding a row to show a team card, and\n    includes a togglable form to create new teams.\n\n  imports:\n    - /_100554_/l2/collabOrgTeamCard.js\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _teams\n      type: Team[]\n      default: []\n      description: List of teams fetched from mls.stor\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed when fetch fails\n    - name: _expandedTeam\n      type: Team | null\n      default: null\n      description: Currently expanded team row, null if none\n    - name: _newTeamOpen\n      type: boolean\n      default: false\n      description: Controls visibility of the new team form\n    - name: _newTeamName\n      type: string\n      default: \"\"\n      description: Current value of the new team name input\n    - name: _formStatus\n      type: FormStatus\n      default: idle\n      description: Current status of the create form\n    - name: _formError\n      type: string\n      default: \"\"\n      description: Error message shown inside the create form\n\n  interfaces:\n    Team:\n      name: string\n      auth: string\n      projectCount: number\n      userCount: number\n      users: \"{ idx: number; name: string; avatar: string }[]\"\n\n    FormStatus: \"'idle' | 'saving' | 'success' | 'error'\"\n\n  lifecycle:\n    connectedCallback: calls _fetchTeams()\n\n  methods:\n    _fetchTeams:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - call configTeams(lastOrg) and assign to _teams\n        - on catch: set _error from err.message or 'Unknown error'\n        - finally: set _loading = false, call requestUpdate()\n\n    configTeams:\n      returns: Team[]\n      params:\n        - info: mls.cbe.IOrgInfo\n      steps:\n        - iterate info.sett.teams with forEach\n        - for each team build Team with name, auth, projectCount=0, userCount=t.usrIndex.length, users=[]\n        - iterate info.sett.users and push { idx, name, avatar placeholder } if usrIndex includes idx\n        - return teams array\n\n    _handleCreate:\n      returns: Promise<void>\n      params:\n        - e: Event\n      steps:\n        - call e.preventDefault()\n        - set _formStatus = 'saving', _formError = '', call requestUpdate()\n        - simulate 600ms delay (real fetch commented out, keep as comment)\n        - dispatch CustomEvent('team-created') with detail { name: _newTeamName }, bubbles true, composed true\n        - set _formStatus = 'success', clear _newTeamName\n        - call _fetchTeams()\n        - set _newTeamOpen = false, _formStatus = 'idle'\n        - on catch: set _formStatus = 'error', _formError from err.message or 'Unknown error'\n        - finally: call requestUpdate()\n\n    _toggleExpand:\n      returns: void\n      params:\n        - team: Team\n      steps:\n        - if _expandedTeam === team set _expandedTeam = null, otherwise set _expandedTeam = team\n        - call requestUpdate()\n\n    _toggleNewTeam:\n      returns: void\n      steps:\n        - toggle _newTeamOpen\n        - reset _newTeamName = '', _formStatus = 'idle', _formError = ''\n        - call requestUpdate()\n\n    _handleNameInput:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement\n        - set _newTeamName = target.value\n\n    _emitViewProjects:\n      returns: void\n      params:\n        - teamName: string\n      steps:\n        - dispatch CustomEvent('view-team-projects') with detail { team_name: teamName }, bubbles true, composed true\n\n    _emitViewUsers:\n      returns: void\n      params:\n        - teamName: string\n      steps:\n        - dispatch CustomEvent('view-team-users') with detail { team_name: teamName }, bubbles true, composed true\n\n    _renderNewTeamForm:\n      returns: TemplateResult\n      steps:\n        - derive saving = _formStatus === 'saving'\n        - render div.new-team-form-wrapper containing form.new-team-form\n        - form @submit \u2192 _handleCreate(e)\n        - div.form-group with label and input#new-team-name\n          input: type text, .value=_newTeamName, ?disabled=saving, @input \u2192 _handleNameInput\n        - if _formStatus === 'error': div.feedback.error with _formError or msg.feedbackError\n        - div.form-actions with two buttons:\n            - button.btn-secondary type=button ?disabled=saving @click \u2192 _toggleNewTeam() \u2192 msg.btnCancel\n            - button.btn-primary type=submit ?disabled=saving \u2192 msg.btnCreating if saving else msg.btnCreate\n\n    _renderTable:\n      returns: TemplateResult\n      steps:\n        - if _teams.length === 0 \u2192 p.no-teams with msg.noTeams\n        - otherwise \u2192 div.table-wrapper with table.teams-table\n      table_structure:\n        thead:\n          columns: [colTeam, colAuth, colProjects, colUsers]\n        tbody:\n          row_per_team: _renderRow(t)\n\n    _renderRow:\n      returns: TemplateResult\n      params:\n        - t: Team\n      steps:\n        - derive expanded = _expandedTeam?.name === t.name\n        - render tr.team-row with class 'expanded' if expanded\n          cells:\n            - td.td-name \u2192 t.name\n            - td.td-auth \u2192 span.badge.auth-{t.auth} with t.auth\n            - td.td-link \u2192 \"{t.projectCount} projects\" (static text)\n            - td.td-link \u2192 button.btn-link @click \u2192 _toggleExpand(t) showing \"{t.userCount} {msg.viewUsers}\"\n        - if expanded: render tr.expand-row with td colspan=5 containing\n            collab-org-team-card-100554 with .team=${t} and project=\"${this.project}\"\n\n  events:\n    - name: team-created\n      when: after team is created successfully\n      detail: { name: string }\n      options: { bubbles: true, composed: true }\n    - name: view-team-projects\n      when: _emitViewProjects is called\n      detail: { team_name: string }\n      options: { bubbles: true, composed: true }\n    - name: view-team-users\n      when: _emitViewUsers is called\n      detail: { team_name: string }\n      options: { bubbles: true, composed: true }\n\n  render:\n    priority_order:\n      - if _loading \u2192 div.state-loading with span.spinner and span msg.loading\n      - if _error   \u2192 div.feedback.error with this._error\n      - default     \u2192 full layout\n\n    default_layout:\n      element: div.teams-root\n      children:\n        - div.header:\n            children:\n              - h1.page-title \u2192 msg.title\n              - button.btn-primary @click \u2192 _toggleNewTeam()\n                  label: if _newTeamOpen then msg.btnCancel else msg.btnNewTeam\n        - new team form (conditional on _newTeamOpen):\n            content: _renderNewTeamForm()\n        - _renderTable()\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n";
}
declare module "_100554_/l2/collabOrgTeams" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabOrgTeamCard.js';
    export class CollabOrgTeams extends CollabLitElement {
        project: number;
        private msg;
        private _teams;
        private _loading;
        private _error;
        private _expandedTeam;
        private _newTeamOpen;
        private _newTeamName;
        private _formStatus;
        private _formError;
        connectedCallback(): void;
        private _fetchTeams;
        private configTeams;
        private _handleCreate;
        private _toggleExpand;
        private _toggleNewTeam;
        private _handleNameInput;
        private _emitViewProjects;
        private _emitViewUsers;
        private _renderNewTeamForm;
        private _renderTable;
        private _renderRow;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgUsers.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-users-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-users-100554\n  file: _100554_/l2/collabOrgUsers.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays a table of organization members with their avatar, username,\n    teams and repository access status (GitHub and GitLab). Includes a\n    togglable invite panel powered by collab-org-invite-user-100554.\n\n  imports:\n    - /_100554_/l2/collabOrgInviteUser.js\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _members\n      type: Member[]\n      default: []\n      description: List of organization members\n    - name: _accessMap\n      type: AccessMap\n      default: {}\n      description: Map of username to RepoAccess fetched in parallel\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed when fetch fails\n    - name: _inviteOpen\n      type: boolean\n      default: false\n      description: Controls visibility of the invite panel\n\n  interfaces:\n    Member:\n      id: number\n      username: string\n      avatarUrl: string\n      teams: string[]\n\n    RepoAccess:\n      github: boolean | null\n      gitlab: boolean | null\n\n    AccessMap: \"{ [username: string]: RepoAccess }\"\n\n  lifecycle:\n    connectedCallback: calls _fetchMembers()\n\n  methods:\n    _fetchMembers:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - call this.configUsers(lastOrg) and assign to _members\n        - call _fetchAllAccess()\n        - on catch: set _error from err.message or 'Unknown error'\n        - finally: set _loading = false, call requestUpdate()\n\n    configUsers:\n      returns: Member[]\n      params:\n        - info: mls.cbe.IOrgInfo\n      steps:\n        - iterate info.sett.users with forEach((u, idx))\n        - for each user build Member with id=idx, username=u, avatarUrl fixed placeholder, teams=[]\n        - iterate info.sett.teams and push team.name to user.teams if team.usrIndex includes idx\n        - return users array\n\n    _fetchAllAccess:\n      returns: Promise<void>\n      steps:\n        - map _members with Promise.all calling _fetchRepoAccess(m.username) for each\n        - each promise resolves to [username, RepoAccess] tuple\n        - assign Object.fromEntries(entries) to _accessMap\n\n    _fetchRepoAccess:\n      returns: Promise<RepoAccess>\n      params:\n        - username: string\n      steps:\n        - simulate 300ms delay via Promise + setTimeout\n        - return { github: false, gitlab: false }\n\n    _toggleInvite:\n      returns: void\n      steps:\n        - toggle _inviteOpen\n        - call requestUpdate()\n\n    _handleInviteSuccess:\n      returns: void\n      steps:\n        - set _inviteOpen = false\n        - call _fetchMembers()\n\n    _renderAccessBadge:\n      returns: TemplateResult\n      params:\n        - value: boolean | null\n        - platform: string\n      steps:\n        - if value === null \u2192 span.badge.badge-neutral with \"{platform} \u2013\"\n        - if value === true \u2192 span.badge.badge-ok with \"{platform} \u2713\"\n        - if value === false \u2192 span.badge.badge-fail with \"{platform} \u2717\"\n\n    _renderAccessCell:\n      returns: TemplateResult\n      params:\n        - username: string\n      steps:\n        - look up _accessMap[username]\n        - if not found \u2192 span.access-loading with msg.loadingAccess\n        - otherwise \u2192 div.access-badges with _renderAccessBadge for github and gitlab\n\n    _renderTable:\n      returns: TemplateResult\n      steps:\n        - if _members.length === 0 \u2192 p.no-members with msg.noMembers\n        - otherwise \u2192 div.table-wrapper with table.members-table\n      table_structure:\n        thead:\n          columns: [colAvatar, colUser, colTeams, colAccess]\n        tbody:\n          row_per_member:\n            - td.td-avatar \u2192 img.avatar with src=m.avatarUrl and alt=m.username\n            - td.td-user \u2192 m.username\n            - td.td-teams \u2192 div.tags-wrapper\n                if teams > 0: map to span.team-tag\n                otherwise: span.no-teams with \"\u2014\"\n            - td.td-access \u2192 _renderAccessCell(m.username)\n\n  events: []\n\n  render:\n    priority_order:\n      - if _loading \u2192 div.state-loading with span.spinner and span msg.loading\n      - if _error   \u2192 div.feedback.error with this._error\n      - default     \u2192 full layout\n\n    default_layout:\n      element: div.users-root\n      children:\n        - div.header:\n            children:\n              - h1.page-title \u2192 msg.title\n              - button.btn-invite @click \u2192 _toggleInvite()\n                  label: if _inviteOpen then '\u2715' else '+ ' + msg.inviteToggle\n        - invite panel (conditional on _inviteOpen):\n            element: div.invite-wrapper\n            children:\n              - collab-org-invite-user-100554\n                  prop: project=\"${this.project}\"\n                  event: \"@invite-success \u2192 _handleInviteSuccess()\"\n        - _renderTable()\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n";
}
declare module "_100554_/l2/collabOrgUsers" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "/_100554_/l2/collabOrgInviteUser.js";
    export class CollabOrgUsers extends CollabLitElement {
        project: number;
        private msg;
        private _members;
        private _accessMap;
        private _loading;
        private _error;
        private _inviteOpen;
        connectedCallback(): void;
        private _fetchMembers;
        private configUsers;
        private _fetchAllAccess;
        private _fetchRepoAccess;
        private _toggleInvite;
        private _handleInviteSuccess;
        private _renderAccessBadge;
        private _renderAccessCell;
        private _renderTable;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabPageElement.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPageElement" {
    import { PropertyValueMap, LitElement } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export const PREFIX_ICA_ID = "ica_";
    export function toPascalCase(str: string): string;
    export abstract class CollabPageElement extends StateLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        initPageComplete: boolean;
        level: string;
        overlay: any | undefined;
        isPage: boolean;
        recreateOverlay(): void;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        private setupIds;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
    }
    export interface LitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        baseName: string;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
    }
    interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | 'p-title-top' | '';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
}
declare module "_100554_/l2/collabPanel.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabPanelItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabPanelItem extends CollabLitElement {
        widget: string;
        badge: string;
        loading: string;
        mode: 'html' | 'tag';
        private myInfo;
        firstUpdated(): void;
        render(): any;
        private clickItem;
        private setMyInfo;
    }
}
declare module "_100554_/l2/collabPanel" {
    import '/_100554_/l2/collabPanelItem.js';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabPanel extends CollabLitElement {
        detail: HTMLDetailsElement | undefined;
        open: boolean;
        icon?: any;
        myData: IPluginMenuAction[];
        createRenderRoot(): this;
        render(): any;
        renderItem(item: IPluginMenuAction, index: number): any;
        private changeSummary;
        private minus;
        private plus;
    }
    interface IPluginMenuAction extends mls.plugin.MenuAction {
        mode: 'html' | 'tag';
    }
}
declare module "_100554_/l2/collabPanelHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPanelHelper" {
    import { LitElement, PropertyValueMap } from 'lit';
    export class CollabPanelHelper100554 extends LitElement {
        plugin: string;
        isHelperContainerOpen: boolean;
        containerHelpers: HTMLDivElement | undefined;
        private handleOpenHelperClick;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        static styles: any;
    }
}
declare module "_100554_/l2/collabPanelItem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPanelItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabPanelItem extends CollabLitElement {
        widget: string;
        badge: string;
        loading: string;
        mode: 'html' | 'tag';
        private myInfo;
        firstUpdated(): void;
        render(): any;
        private clickItem;
        private setMyInfo;
    }
}
declare module "_100554_/l2/collabPreviewL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabL3EditText" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabL3PreviewText.js';
    import '/_100554_/l2/collabL3PreviewTextAttr.js';
    import '/_100554_/l2/collabL3PreviewTextI18n.js';
    export class CollabL3EditText extends CollabLitElement {
        dev: boolean;
        target: HTMLElement | null;
        private json;
        private baseTexti18n;
        private baseSearch;
        constructor();
        firstUpdated(): void;
        render(): any;
        private getBaseI18n;
        private process;
        private initState;
        private addEls;
        save(): Promise<boolean>;
        private replaceValueAfterKeyWithUndo;
        private replaceAttributeValueWithUndo;
        private replaceI18nValueWithUndo;
    }
}
declare module "_100554_/l2/collabPreviewL3" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabL3EditText.js';
    export class CollabPreviewL3 extends CollabLitElement {
        constructor();
        private elOverlayHover;
        private elOverlaySelected;
        setHover(el: HTMLElement | undefined, active: boolean): void;
        selectElement(el: HTMLElement): void;
        render(): any;
        private init;
        private setEventsMouse;
        private createOverlay;
        private createOverlaySelected;
        private _setHover;
        private _selectElement;
        private addEdit;
    }
}
declare module "_100554_/l2/collabPreviewL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPreviewL4" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabL3EditText.js';
    export class CollabPreviewL4 extends CollabLitElement {
        constructor();
        private elOverlayHover;
        private elOverlaySelected;
        private elMenuOverlay;
        disconnectedCallback(): void;
        render(): any;
        setHover(elId: string, active: boolean): void;
        selectElement(elId: string): void;
        private init;
        private setEventsMouse;
        private createOverlay;
        private createOverlaySelected;
        private observer;
        private _setElement;
        private _setHover;
        private caculetePosSelected;
        private _selectElement;
        private editEl;
    }
}
declare module "_100554_/l2/collabProcessTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/tsTestMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines(model: monaco.editor.ITextModel): string[];
        replaceLines(model: monaco.editor.ITextModel, lineNrInit: number, lineNrInitEnd: number, newContent: string): boolean;
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine(model: monaco.editor.ITextModel, lineNr: number, line: string): boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine(model: monaco.editor.ITextModel, lineNr: number): boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines(model: monaco.editor.ITextModel, startLine: number, countLines: number): boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine(model: monaco.editor.ITextModel, lineNr: number, columnNr: number, newText: string): boolean;
        /**
         * Moves the editor's cursor to the specified lines, selects the text between them,
         * and scrolls the editor to bring the selection into view.
         *
         * @param {monaco.editor.ITextModel} model - The text model associated with the editor.
         * @param {number} start - The starting line number for the selection.
         * @param {number} end - The ending line number for the selection.
         *
         * @returns {void}
         */
        goTo(model: monaco.editor.ITextModel, start: number, end: number): void;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (model: monaco.editor.ITextModel) => void;
    }
}
declare module "../l2/tsTestAST" {
    import { MonacoDriver } from "_100554_/l2/tsTestMonaco";
    /**
     * Represents an AST node.
     * @typedef {Object} ASTNode
     * @property {string} type - The type of the AST node (e.g., 'Program', 'FunctionDeclaration').
     * @property {string} [name] - The name of the node (e.g., function name).
     * @property {any} [value] - The value associated with the node (e.g., function body or array content).
     * @property {ASTNode[]} [children] - An array of child nodes.
     * @property {number} [startLine] - The start line of the node in the source code.
     * @property {number} [endLine] - The end line of the node in the source code.
     */
    type ASTNode = {
        type: string;
        name?: string;
        value?: any;
        children?: ASTNode[];
        startLine: number;
        endLine: number;
    };
    /**
     * Class to parse a TypeScript test file and generate an AST.
     */
    export class TsTestAst {
        ast: ASTNode | undefined;
        modelTest: mls.editor.IModelTest | undefined;
        monacoDriver: MonacoDriver;
        editor: monaco.editor.IStandaloneCodeEditor;
        /**
         * Creates an instance of TsTestAst.
         * @param {mls.editor.IModelTest} modelTest - The Monaco editor model test instance.
         */
        constructor(modelTest: mls.editor.IModelTest, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * Parses the TypeScript code from the model test and returns the AST.
         * @returns {ASTNode | undefined} The generated AST, or undefined if parsing fails.
         */
        parse: () => ASTNode | undefined;
        /**
         * Gets the integrations from the parsed AST.
         * @returns {any[]} The integrations parsed from the AST.
         */
        getIntegrations(): ICANIntegration[];
        /**
         * Gets the tests from the parsed AST.
         * @returns {any[]} The tests parsed from the AST.
         */
        getTests(): ICANTest[];
        /**
         * Adds a new test to the AST and inserts it into the test array in the Monaco editor.
         * @param {ICANTest} test - The test object to be added.
         * @param {Function} fcTest - The test function to be associated with the test.
         * @returns {boolean} True if the test was added successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        addTest(test: ICANTest, fcTest: Function | string): boolean;
        /**
         * Deletes a test from the AST and updates the Monaco editor.
         * @param {String} testName - The test name to be removed.
         * @returns {boolean} True if the test was removed successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        deleteTest(testName: string, index?: number): boolean;
        /**
         * Navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        goToTest(testName: string): boolean;
        /**
         * Retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        getTestInfo(functionName: string, paramsIndex?: number): ITestInfo;
        /**
        * Executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        runTest(testName: string, paramsIndex?: number): Promise<string>;
        /**
         * Adds a new integration to the test file.
         * @param {ICANIntegration} integration - The integration to be added.
         * @param {Function} fc - The function associated with the integration.
         * @returns {boolean} Returns true if the integration was successfully added.
         */
        addIntegration(integration: ICANIntegration, fc: Function | string): boolean;
        /**
         * Parses TypeScript code into an AST.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode} The generated AST from the code.
         */
        private parseTypeScript;
        /**
         * Parses imports from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the imports in the code.
         */
        private parseImports;
        /**
         * Parses arrays from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the arrays in the code.
         */
        private parseArrays;
        /**
         * Parses function names from TypeScript code and returns an array of function declarations as AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing function declarations in the code.
         */
        private parseFunctionNames;
        /**
         * Parses and retrieves the integrations from the AST's children.
         * @returns {ICANIntegration[]} The parsed integrations.
         * @throws {Error} Throws an error if parsing the integrations fails.
         */
        private _getIntegrations;
        /**
         * Parses and retrieves the tests from the AST's children.
         * @returns {ICANTest[]} The parsed tests.
         * @throws {Error} Throws an error if parsing the tests fails.
         */
        private _getTests;
        /**
         * Internal method to add a test to the AST and update the Monaco editor.
         * @param {ICANTest} test - The test object to add.
         * @param {Function} fcTest - The test function to add.
         * @returns {boolean} True if the test was successfully added.
         * @throws {Error} Throws an error if the test already exists or AST information is missing.
         */
        private _addTest;
        /**
         * Internal method to deletes a test from the AST and updates the Monaco editor.
         * @param {string} testName - The name of the test to delete.
         * @throws {Error} Throws an error if the test does not exist or deletion fails.
         */
        private _deleteTest2;
        /**
     * Internal method to delete a test from the AST and update the Monaco editor.
     * @param {string} functionName - The name of the test to delete.
     * @param {number} [index] - (Optional) The index of the parameter to remove.
     * @throws {Error} Throws an error if the test does not exist or deletion fails.
     */
        private _deleteTest;
        /**
        * Internal method to executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        private _runTest;
        /**
         * Internal method to retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        private _getTestInfo;
        /**
         * Internal method to navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        private _goToTest;
        /**
         * Intenal method to delete a function on the AST and updates the Monaco editor.
         * @param {String} fcName - The function name to be deleted.
         * @returns {boolean} True if the function was successfully deleted.
         * @throws {Error} Throws an error if the test model is invalid.
         */
        private _deleteFunction;
        /**
         * Adds a new integration to the AST and updates the Monaco editor.
         * @param {ICANIntegrations} integration - The integration object to add.
         * @param {Function} fcIntegration - The integration function to add.
         * @throws {Error} Throws an error if the integration already exists or if AST information is missing.
         */
        private _addIntegration;
        /**
         * Deletes an integration from the AST and updates the Monaco editor.
         * @param {string} integrationName - The name of the integration to delete.
         * @throws {Error} Throws an error if the integration does not exist or deletion fails.
         */
        private _deleteIntegration;
        /**
         * Adds a new function to the AST and updates the Monaco editor.
         * @param {Function} fc - The function to add.
         * @returns {boolean} True if the function was successfully added.
         * @throws {Error} Throws an error if AST information is missing or the test model is invalid.
         */
        private _addFunction;
        private checkImports;
        /**
         * Adds an import statement to the TypeScript code.
         * If an interval is provided, it replaces the existing import.
         * Otherwise, it inserts the import after the root startLine.
         *
         * @param {string} value - The import statement to add.
         * @param {Object} [interval] - The optional start and end line to replace.
         */
        private _addImport;
        private _formatEditor;
    }
    export interface ITestInfo {
        fileName: string;
        functionName: string;
        params: Record<string, any>;
    }
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_100554_/l2/collabProcessTest" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabProcessTest extends CollabLitElement {
        script: string;
        labelError: string;
        labelOk: string;
        txtScript: HTMLTextAreaElement | undefined;
        iptnamefunc: HTMLInputElement | undefined;
        checkintegration: HTMLInputElement | undefined;
        render(): any;
        private decodeHtmlEntities;
        private changeNameFunc;
        private onSave;
        private createObjeTest;
        private addInEditor;
    }
}
declare module "_100554_/l2/collabResultTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabResultTest" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabConsole100554 extends StateLitElement {
        testName: string;
        status: 'pending' | 'running' | 'finished';
        resultStatus: 'pass' | 'failed';
        result: string;
        timeResult: number;
        timeStart: number;
        timeEnd: number;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private renderRunning;
        private renderFinished;
        render(): any;
    }
}
declare module "_100554_/l2/collabSelectOneWithDescription.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabSelectOneWithDescription" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export const initCollabSelectOneWithDescription = "";
    export class CollabSelectOneWithDescription100554 extends StateLitElement {
        private msg;
        hint: string | undefined;
        required: boolean;
        disabled: boolean;
        label: string | undefined;
        options: IOptionItem[] | undefined;
        selectedvalue: string | undefined;
        select_container: HTMLDivElement | undefined;
        select_toogle: HTMLDivElement | undefined;
        desc_container: HTMLDivElement | undefined;
        optionItems: HTMLElement[] | undefined;
        render(): any;
        firstUpdated(): void;
        private defaultMsg;
        private currentIndex;
        private onIconClick;
        private onBlur;
        renderOpt(): any;
        handleHover(ev: MouseEvent): void;
        handleOut(): void;
        handleFocus(ev: MouseEvent, index: number): void;
        handleChange(value: string): void;
        handleKeyDown(event: KeyboardEvent): void;
        toogle(): void;
        calculatePopupPosition(): void;
    }
    export interface IOptionItem {
        key: string;
        value: string;
        description: string;
    }
}
declare module "_100554_/l2/collabShowCodeDiff.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabShowCodeDiff" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "_102027_/l2/collabMonacoEditor";
    export function initCollabShowCodeDiff100554(): boolean;
    export class CollabShowCodeDiff extends CollabLitElement {
        private msg;
        static monaco_css: string;
        static inLoadingCss: boolean;
        static loadingPromise: Promise<string>;
        msize: string;
        language: string;
        withCopy: boolean;
        withAccept: boolean;
        withReject: boolean;
        withTryAgain: boolean;
        withDiff: boolean;
        coping: boolean;
        onAccept: Function | undefined;
        onReject: Function | undefined;
        onTryAgain: Function | undefined;
        private _ed1Diff;
        private _ed1Result;
        private modelResult;
        private modelDiffOriginal;
        private modelDiffModified;
        private actualEditor;
        actualTextDiffOriginal: string;
        actualTextDiffModified: string;
        actualTextResult: string;
        private c1;
        private inputDiff;
        init(): void;
        private createEditorDiff;
        private createEditorResult;
        private createModelDiff;
        private createModelResult;
        private setDiffValue;
        private setResultValue;
        private setMsizeEditor;
        private onCopyClick;
        private onAcceptClick;
        private onRejectClick;
        private onTryAgainClick;
        private getCssMonaco;
        private styleElement;
        loadCSS(): Promise<void>;
        private renderWithCopy;
        private renderWithAccept;
        private renderTryAgain;
        private renderReject;
        private handleChangeDiff;
        private renderShowDiff;
        firstUpdated(): void;
        render(): any;
        static styles: any;
    }
}
declare module "_100554_/l2/collabSpliterHorizontalVarFixed.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabSpliterHorizontalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterHorizontalVarFixed100554 extends LitElement {
        fixedwidth: string;
        complementcolor: string;
        fixedvisible: 'hidden' | 'visible' | 'closed';
        spliterWidth: number;
        actualfixedwidth: string;
        msize: string;
        open: boolean;
        openUser: boolean | undefined;
        slotLeft: HTMLElement[] | undefined;
        slotRight: HTMLElement[] | undefined;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private setFixedValueInPx;
        private getMSize;
        private getMSizeLeft;
        private getMSizeRight;
        private updateMyHeight;
        delay(): Promise<void>;
        private updatePanelsMSize;
        resizeItens(): void;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        firstUpdated(): void;
        render(): any;
        private styles;
    }
}
declare module "_100554_/l2/collabSpliterVerticalVarFixed.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabSpliterVerticalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterVerticalVarFixed100554 extends LitElement {
        fixedheight: string;
        complementcolor: string;
        spliterHeight: number;
        withresize: string;
        actualfixedheight: string;
        msize: string;
        isBottomPaneOpen: boolean;
        slotTop: HTMLElement | undefined;
        slotBottom: HTMLElement | undefined;
        private resizeObserver?;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        private getMSize;
        private getMSizeTop;
        private getMSizeBottom;
        updatePanelsMSize(): void;
        private forceRefreshMsize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        timeoutResize: number | undefined;
        _distributeContent(): void;
        render(): any;
        private styles;
    }
}
declare module "_100554_/l2/collabStartL0.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL0" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabStartL0100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL1" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabStartL1100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL2" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabStartL2100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL3" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabStartL3100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL4" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabStartL4100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL5.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL5" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabStartL5100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL6.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL6" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabStartL6100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStore.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStore" {
    /**
     * use this state to set and increment count
     * each access on page, increment this
     */
    export const COUNTHITSPAGES = "CountHitsPages";
}
declare module "_100554_/l2/collabTabSlider.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTabSlider" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class PluginCreateProject extends StateLitElement {
        activeIndex: number;
        animationTimer: number;
        private previousIndex;
        updated(changedProps: Map<string, any>): void;
        private switchTab;
        render(): any;
    }
}
declare module "_100554_/l2/collabTasks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTasks" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabTasks100554 extends StateLitElement {
        private view;
        private selectedTask;
        private _backToList;
        render(): any;
        private _renderTaskDetails;
        _renderTaskList(): any;
        private _openTaskDetails;
    }
}
declare module "_100554_/l2/collabTiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "../l2/collabTilesItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabTilesItem extends CollabLitElement {
        private startX;
        private startY;
        private startWidth;
        private startHeight;
        myinfo: ITilesItem | undefined;
        position: string;
        plugin: string;
        index: string;
        edit: string;
        mode: string;
        collabtileitemresize: HTMLElement | undefined;
        private elPlugin;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): any;
        renderResize(): any;
        private setEnabled;
        private loadingPlugin;
        private setPlugin;
        private clickPlugin;
        private initDragging;
        private doDragging;
        private stopDragging;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_/l2/collabTiles" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabTilesItem.js';
    import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js';
    export class CollabTiles extends CollabLitElement {
        config: string;
        tilesItens: ITilesItem[];
        text: string;
        example: string;
        collabTiles: HTMLElement | undefined;
        private oldJson;
        createRenderRoot(): this;
        render(): any;
        renderItem(item: ITilesItem, idx: number): any;
        renderConfigItens(): any;
        renderConfigItensOpen(): any;
        renderConfigItensClose(): any;
        renderItemConfig(item: ITilesItem, index: number): any;
        private sort;
        private setDragAndDrop;
        private open;
        private close;
        private onlyclose;
        private verifyNeedSaveAndSave;
        private changeConfig;
        private setInfoPlugin;
        private fireChange;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_/l2/collabTilesItem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTilesItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabTilesItem extends CollabLitElement {
        private startX;
        private startY;
        private startWidth;
        private startHeight;
        myinfo: ITilesItem | undefined;
        position: string;
        plugin: string;
        index: string;
        edit: string;
        mode: string;
        collabtileitemresize: HTMLElement | undefined;
        private elPlugin;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): any;
        renderResize(): any;
        private setEnabled;
        private loadingPlugin;
        private setPlugin;
        private clickPlugin;
        private initDragging;
        private doDragging;
        private stopDragging;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_/l2/collabTokensVisualization.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTokensVisualization" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export class CollabTokensVisuzalization100554 extends StateLitElement {
        tokens: IDesignSystemTokens[];
        project: number;
        firstUpdated(prop: any): Promise<void>;
        render(): any;
        getTokens(): Promise<IDesignSystemTokens[]>;
    }
}
declare module "_100554_/l2/contentAccordion.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/contentAccordion" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class ContentAccordion extends CollabLitElement {
        private navItems;
        private contentItems;
        selectedIndex: number;
        connectedCallback(): void;
        render(): any;
        private toggle;
    }
}
declare module "_100554_/l2/contentCarousel.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/contentCarousel" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class ContentTabs extends CollabLitElement {
        private navItems;
        private contentItems;
        selectedIndex: number;
        connectedCallback(): void;
        render(): any;
        renderNav(): any;
        renderContent(): any;
        private handleSelect;
        private handleClickPrevius;
        private handleClickNext;
    }
}
declare module "_100554_/l2/contentTabs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/contentTabs" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class ContentTabs extends CollabLitElement {
        private navItems;
        private contentItems;
        selectedIndex: number;
        connectedCallback(): void;
        render(): any;
        renderNav(): any;
        renderContent(): any;
        private handleSelect;
    }
}
declare module "_100554_/l2/cssHelperIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/cssHelperIndex" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { PluginStyleIndexItem } from '_100554_/l2/pluginStyleIndexItem';
    import { IHelpers } from '_100554_/l2/cssHelperIndexBase';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/pluginStyleIndexItem.js';
    export class CssHelperIndex extends StateLitElement {
        private msg;
        private minValueToOpen;
        helpers: IHelpers[];
        avaliablePlugins: IHelpers[];
        position: 'right' | 'left';
        actualProp: string | undefined;
        actualValue: string | undefined;
        actualSelector: string | undefined;
        actualLineContent: string | undefined;
        actualLineNumber: number | undefined;
        private isFirtsLoading;
        state: ICSSState | undefined;
        allPluginsEls: PluginStyleIndexItem[];
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        updated(changedProperties: any): Promise<void>;
        private mergeHelpersArrays;
        firstUpdated(a: any): Promise<void>;
        private baseProject;
        private getAvaliablesPlugins;
        private filterByProp;
        render(): any;
        renderHelper(help: IHelpers, index: number): any;
    }
}
declare module "_100554_/l2/cssHelperIndexBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/cssHelperIndexBase" {
    export type IMode = 'collapsed' | 'expanded' | 'full';
    export interface IHelpers {
        name: string;
        priority: number;
        widget: string;
        tags: string[];
        description: string;
        mode: IMode;
        liked: boolean;
        likedAnimation: boolean;
        showInfo: boolean;
    }
}
declare module "_100554_/l2/designSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_100554_/l2/docMd" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class DocMd extends CollabLitElement {
        private _html;
        private _marked;
        private oriHtml;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private _importMarked;
        private _parse;
        private init;
    }
}
declare module "_100554_/l2/driverGithub.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverGithub" {
    export function init(initString: string): void;
    export class DriverGitHub extends mls.stor.others.DriverIOBase {
        shortName: mls.cbe.Provider;
        project: number;
        driverVersion: string;
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        getHistory(fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(fileInfo: mls.stor.IFileInfo, ref: string): Promise<string | null>;
        getUrl(file: mls.stor.IFileInfo): string;
        getVersionFromFiles(options: {
            owner: string;
            repo: string;
            branchName: string;
            files: mls.stor.IFileInfo[];
        }): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(owner: string, repo: string, branchName: string): Promise<boolean>;
        createNewBranch(option: {
            owner: string;
            repo: string;
            branch: string;
            newBranch: string;
        }): Promise<boolean>;
        createPullRequest(options: {
            owner: string;
            repo: string;
            title: string;
            branch: string;
            description: string;
        }): Promise<boolean>;
        reviewPullRequest(options: {
            owner: string;
            repo: string;
            branch: string;
            idRequest: string;
            isApproved: boolean;
        }): Promise<boolean>;
        listPullRequests(owner: string, repo: string): Promise<mls.stor.others.IPullRequest[]>;
        listForks(owner: string, repo: string): Promise<mls.stor.others.IFork[]>;
        listBranches(owner: string, repo: string): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(login: string): Promise<mls.stor.others.IOrg[]>;
        createRepository(login: string, repo: string, organization: string, description: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        deleteRepository(repo: string, organization: string): Promise<boolean>;
        createFork(login: string, repoOri: string, orgOri: string, orgDest: string): Promise<boolean>;
        renameRepository(owner: string, repo: string, newName: string): Promise<boolean>;
        createFileInRepo(owner: string, repo: string, path: string, content: string | Uint8Array): Promise<boolean>;
        deleteFileInRepo(owner: string, repo: string, path: string): Promise<boolean>;
        changeVisibility(owner: string, repo: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        verifyRepositoryNew(owner: string, repo: string, user: string): Promise<"free" | "reuse" | "wait" | "error">;
        verifyPermission(owner: string, repo: string, login: string): Promise<mls.stor.others.IPermission>;
        setPermissionAction(owner: string, repo: string, login: string): Promise<boolean>;
        addVariable2(owner: string, repo: string, name: string, value: string): Promise<boolean>;
        addVariable(name: string, value: string): Promise<boolean>;
        updateVariable(name: string, value: string): Promise<boolean>;
        listVariables(): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(name: string): Promise<boolean>;
        checkFork(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        syncFork(options: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        private _getUrl;
        private _getContents;
        private getContents2;
        private getContent3;
        private _setContents;
        private _setContentsOld;
        private setContents2;
        private afterSave;
        private setContentAddFile;
        private verifyAndGetContent;
        private _loadFilesInfo;
        private getFilesRepo;
        private auxLoadFilesInfo2Reenter;
        private _getHistory;
        private _getHistoryContent;
        private fecthQl;
        buildFileGroups(files: mls.stor.IFileInfo[], maxSizeBytes?: number): Promise<{
            type: 'single' | 'group';
            files: mls.stor.IFileInfo[];
        }[]>;
        private processFiles;
        private githubRequest;
        private getSha;
        private saveFile;
        private deleteFile;
        private processFilesOld;
        syncForkIO(opt: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        checkForkIO(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        private delVariableIO;
        private listVariablesIO;
        private updateVariableIO;
        private addVariableIO;
        private setPermissionActionIO;
        private verifyPermissionIO;
        private verifyRepositoryNewIO;
        private changeVisibilityIO;
        private createFileInRepoIO;
        private renameRepositoryIO;
        private createForkIO;
        private deleteRepositoryIO;
        private createRepositoryIO;
        private getOrganizationsIO;
        private getUserInfoIO;
        private listBranchesIO;
        private listForksIO;
        private listPullRequestsIO;
        private reviewPullRequestIO;
        private createPullRequestIO;
        private sleep;
        private createNewBranchIO;
        private checkBranchExistenceIO;
        private getHistoryContentIO;
        private getFilesIO;
        private getFilesRestIO;
        private verifyMKey;
        private saveMultipleFilesIO;
        private getFilesRepoIO;
        private getHistoryIO;
        private getVersionFromFilesIO;
        private getOidLastCommitFromInfoIO;
        private getIdProjectIO;
        private getOidLastCommitIO;
        private convertToBase64;
    }
}
declare module "_100554_/l2/driverGitlab.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverGitlab" {
    export function init(initString: string): void;
    export class DriverGitLab extends mls.stor.others.DriverIOBase {
        shortName: mls.cbe.Provider;
        project: number;
        driverVersion: string;
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        getHistory(fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(fileInfo: mls.stor.IFileInfo, ref: string): Promise<string | null>;
        getUrl(file: mls.stor.IFileInfo): string;
        getVersionFromFiles(options: {
            owner: string;
            repo: string;
            branchName: string;
            files: mls.stor.IFileInfo[];
        }): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(owner: string, repo: string, branchName: string): Promise<boolean>;
        createNewBranch(option: {
            owner: string;
            repo: string;
            branch: string;
            newBranch: string;
        }): Promise<boolean>;
        createPullRequest(options: {
            owner: string;
            repo: string;
            title: string;
            branch: string;
            description: string;
        }): Promise<boolean>;
        reviewPullRequest(options: {
            owner: string;
            repo: string;
            branch: string;
            idRequest: string;
            isApproved: boolean;
        }): Promise<boolean>;
        listPullRequests(owner: string, repo: string): Promise<mls.stor.others.IPullRequest[]>;
        listForks(owner: string, repo: string): Promise<mls.stor.others.IFork[]>;
        listBranches(owner: string, repo: string): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(login: string): Promise<mls.stor.others.IOrg[]>;
        createRepository(login: string, repo: string, organization: string, description: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        deleteRepository(repo: string, organization: string): Promise<boolean>;
        createFork(login: string, repoOri: string, orgOri: string, orgDest: string): Promise<boolean>;
        renameRepository(owner: string, repo: string, newName: string): Promise<boolean>;
        createFileInRepo(owner: string, repo: string, path: string, content: string | Uint8Array): Promise<boolean>;
        changeVisibility(owner: string, repo: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        verifyRepositoryNew(owner: string, repo: string, user: string): Promise<"free" | "reuse" | "wait" | "error">;
        verifyPermission(owner: string, repo: string, login: string): Promise<mls.stor.others.IPermission>;
        addVariable(name: string, value: string): Promise<boolean>;
        updateVariable(name: string, value: string): Promise<boolean>;
        listVariables(): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(name: string): Promise<boolean>;
        checkFork(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        syncFork(options: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        private _getUrl;
        private _getContents;
        private getContents2;
        private getContent;
        private _setContents;
        private setContentsnew;
        private verifyAndGetContent;
        private _loadFilesInfo;
        private getFilesRepo;
        private fecthQl;
        private myFetchGet;
        private _getHistoryContentIO;
        private _getHistoryIO;
        private getFilesRepoIO;
        private saveMultipleFilesIO;
        private getFilesIO;
        private syncForkIO;
        private checkForkIO;
        private delVariableIO;
        private listVariablesIO;
        private updateVariableIO;
        private addVariableIO;
        private verifyPermissionIO;
        private verifyRepositoryNewIO;
        private changeVisibilityIO;
        private getVersionFromFilesIO;
        private createFileInRepoIO;
        private renameRepositoryIO;
        private createForkIO;
        private deleteRepositoryIO;
        private createRepositoryIO;
        private getOrganizationsIO;
        private getUserInfoIO;
        private listBranchesIO;
        private listForksIO;
        private listPullRequestsIO;
        private reviewPullRequestIO;
        private createPullRequestIO;
        private createNewBranchIO;
        private checkBranchExistenceIO;
        private getLastCommitFromInfo;
        private getIDProject;
    }
}
declare module "_100554_/l2/driverLib.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverLib" {
    export function myFetchQL(info: IFetchQl): Promise<{
        status: number;
        ret: any;
    }>;
    export function getMyKeysBranch(project: number, needVerifyBranch?: boolean): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function base64ToBlob(content: string, tp: string, name: string): Promise<string | Blob>;
    export function fileToBase64(file: Blob | File): Promise<string>;
    export function base64EncodeUnicode(str: string): string;
    export function base64DecodeUnicode(str: string): string;
    interface IFetchQl {
        query: string;
        variables: any;
        url: string;
        method: string;
        headers: any;
    }
}
declare module "_100554_/l2/driverTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverTest" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class DriverTest extends CollabLitElement {
        drivername: string;
        private instance;
        iptDriver: HTMLInputElement | undefined;
        iptClass: HTMLInputElement | undefined;
        selFc: HTMLSelectElement | undefined;
        showParam: HTMLElement | undefined;
        textlog: HTMLElement | undefined;
        createRenderRoot(): this;
        render(): any;
        private changeDriver;
        private load;
        private separeteLine;
        private run;
        private setValueFromEl;
        private diffTime;
        private dateToTime;
        private changeFunction;
        private createItem;
        private createElItem;
        private functions;
    }
}
declare module "_100554_/l2/enhancementAgent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_100554_/l2/enhancementAgent" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string) => Promise<string>;
}
declare module "_100554_/l2/enhancementLit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/validateLit" {
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
    export function validateRender(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102027_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_100554_/l2/enhancementLit" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_100554_/l2/enhancementLitService.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/enhancementLit" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_100554_/l2/enhancementLitService" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_100554_/l2/enhancementPage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/enhancementPage" {
    export const description = "Use this enhancement for pages";
    export const example = "";
    export const requires: mls.l2.enhancement.IRequire[];
    export const getExample: (project: number, shortname: string) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const prepareAdd: (prompt: string) => {
        sourceTS: string;
        aiHeader: string;
        aiBody: string;
        aiDelimiter: string;
    };
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const getPromptDefault: () => string;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
}
declare module "_100554_/l2/enhancementStyle.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/enhancementStyle" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const onAfterChange: (models: mls.editor.IModels) => string;
    export const onAfterMarkersChange: (models: mls.editor.IModels) => string;
    export const onAfterCompile: (modelStyle: mls.editor.IModelStyle) => Promise<void>;
    export const getDesignDetails: (modelStyle: mls.editor.IModelStyle) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export function verifyMarkersError(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function validateStyle(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function getLineByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getLineSelectorByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getRootSelectors(lessContent: string): string[];
    export function isCommentLine(line: string): boolean;
    export function setStylesProcessed(newCss: string, el: HTMLElement, tag: string): Promise<void>;
}
declare module "_100554_/l2/lessAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessAST" {
    import { MonacoDriver } from "_100554_/l2/lessMonaco";
    interface ILessAST {
        root: {
            [token: string]: {
                value: string;
                line: number;
                column: number;
            };
        };
        [selector: string]: {
            _startLine?: number;
            _endLine?: number;
            [property: string]: {
                value: string;
                line: number;
                column: number;
            } | number | undefined;
        };
    }
    /**
     * @class LessAst
     *
     * This class parses a LESS model, building an AST and converting LESS selectors
     * into a CSS-compatible format. Note that this implementation supports only a subset
     * of LESS functionalities. Advanced features, such as variable interpolation within selectors,
     * parameterized mixins, and color manipulation functions, are not supported.
     *
     * ### Supported Features
     * - **Basic Selector Nesting**: Supports nesting selectors with `&`, converting them to a CSS-compatible format.
     * - **Simple Variables**: Allows the use of variables within properties (e.g., `@color-primary: #333;`).
     * - **Basic LESS Structure**: Parses basic selectors, properties, and tokens, ignoring advanced logic.
     *
     * ### Unsupported Features
     * - **Variable Interpolation within Selectors**: Selectors like `@{variable}-name` are not expanded in the AST.
     * - **Parameterized Mixins**: Mixins with parameters are not evaluated or expanded.
     * - **Mathematical and Color Functions**: Functions like `darken`, `lighten`, or `add` are not processed.
     * - **Looping and Iteration**: Constructs such as `each` or `for` are ignored, as they are not supported in CSS.
     * - **Global Scope Management**: Selectors with `:global` will not retain global scoping behavior.
     *
     * ### Usage Example
     * ```typescript
     * const lessAst = new LessAst("your-url");
     * lessAst.parse();
     * const cssSelector = lessAst.selectorLESS2CSS("less-a-s-t-100554 &:hover");
     * console.log(cssSelector); // Output: less-a-s-t-100554:hover
     * ```
     *
     * ### Limitations
     * Since this class does not handle dynamic processing features of LESS, it is recommended
     * only for static LESS-to-CSS conversions that do not require runtime evaluation.
     */
    export class LessAst {
        ast: ILessAST;
        url: string;
        monacoDriver: MonacoDriver;
        stack: string[];
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * parse a full LESS model (monaco editor)
         */
        parse: () => void;
        /**
         * Parses a single line and updates the AST accordingly.
         */
        private parseLine;
        /**
         * Finds the column index where the given `value` starts in the provided `line`.
         *
         * This method calculates the precise position of the `value` in the string `line`
         * after the first occurrence of a colon (`:`), considering any leading spaces.
         * If the `value` is not found or the colon is absent, it returns undefined.
         *
         * @param {string} line - The line of text to be searched.
         * @param {string} value - The target string to locate within the `line`.
         * @returns {number} - The zero-based index of the starting position of `value` in `line`,
         *                     or undefined if the colon or value is not found.
         *
         * @example
         * // Example 1:
         * const line = "        text-shadow: 3em -8em 3em;";
         * const value = "3em -8em 3em";
         * findColumn(line, value); // Returns: 23
         *
         * // Example 2:
         * const line = "        flex-wrap: wrap;";
         * const value = "wrap";
         * findColumn(line, value); // Returns: 21
         *
         * // Example 3:
         * const line = "invalid line without colon";
         * const value = "anything";
         * findColumn(line, value); // Returns: undefined
         */
        private findColumn;
        /**
         * Lists all themes available in the AST.
         * Each theme is identified by its selector. If the selector has a `.`, the part after the dot is the theme name.
         * If no dot is present, the theme is named "default".
         *
         * @returns An object where each key is a theme name (e.g., "default", "theme2") and each value is the corresponding selector.
         */
        listThemes(): {
            [themeName: string]: string;
        };
        /**
         * Adds a new theme to the specified component variation.
         *
         * @param variation The name of the new theme variation (e.g., "theme3").
         * @returns `true` if the theme was added successfully, `false` otherwise.
         */
        addTheme(variation: string): boolean;
        /**
         * Deletes a theme from the specified component variation.
         *
         * @param variation The name of the theme variation to delete (e.g., "theme2").
         * If `null`, deletes the "default" theme (the main component selector).
         * @returns `true` if the theme was deleted successfully, `false` otherwise.
         */
        deleteTheme(variation: string | null): boolean;
        /**
         * Retrieves the description comments for a specified theme.
         *
         * @param variation The name of the theme variation (e.g., "theme2").
         *                  If `null`, retrieves the "default" theme.
         * @returns An array of comment lines that describe the theme, or an empty array if no comments are found.
         */
        getThemeDescription(variation: string | null): string[];
        private getThemeRangeLines;
        /**
         * Converts a full CSS selector back to the LESS format using "&" where appropriate.
         * - If the selector parts match a parent selector, it replaces the match with "&".
         *
         * @param selector The CSS selector to convert to LESS format.
         * @returns The converted LESS format selector with "&" where possible.
         */
        selectorCSS2LESS: (selector: string) => string;
        selectorLESS2CSS: (selector: string) => string;
        /**
         * Converts a kebab-case property name to camelCase, e.g., background-color to backgroundColor.
         * This ensures property names align with JavaScript/TypeScript conventions.
         */
        toCamelCaseProperty(property: string): string;
        /**
         * Converts a camelCase property name to kebab-case, e.g., backgroundColor to background-color.
         * This ensures property names align with CSS/LESS conventions.
         */
        toKebabCaseProperty(property: string): string;
        getProperty(selector: string, property: string): string | undefined;
        private updateASTAfterInsertLine;
        saveProperty(selector: string, property: string, newValue: string | undefined): boolean;
        /**
         * Returns the last line number within a selector block. aka "}"
         */
        findLastLineInSelector(selectorLESS: string): number;
        findInfoByLine(selectorLESS: string, lineNumber: number): {
            key: string;
            value: string;
        } | undefined;
        /**
         * Finds the most specific LESS selector path for a given line number in the source.
         * - This method searches the AST to determine the most specific selector block containing the specified line.
         * - It returns the full path of the most deeply nested selector in LESS format (e.g., `.cl1 .cl2 &:hover`).
         *
         * ### Usage
         * This method is useful for identifying the exact selector block a line belongs to, especially
         * in scenarios where nested selectors exist in the LESS structure.
         *
         * @param lineNr The line number to check for a corresponding selector.
         * @returns The most specific LESS selector path as a string if found; otherwise, `undefined`.
         */
        findSelectorByLine(lineNr: number): string | undefined;
        /**
         * Finds the start line of the first selector after the root in a JSON representation of a stylesheet.
         *
         * @param json - A JSON object representing a stylesheet, where keys are selectors and values contain metadata.
         * @param tagName - The tag name to exclude from the search.
         * @returns The start line of the first selector after the root, or `null` if no such selector exists.
         */
        findFirstSelectorAfterRoot(ast: Record<string, any>): number | null;
        /**
         * Inserts a new selector into the AST and the Monaco model if it does not exist.
         * - Example: If the AST only contains ".cl1" and `newSelectorLESS` is ".cl1 .cl2 &:hover",
         *   the function will:
         *   1. Check if ".cl1 .cl2" exists in the AST.
         *   2. If not, insert ".cl2" as a nested block within ".cl1".
         *   3. Then insert "&:hover" as a nested selector inside ".cl1 .cl2".
         *
         * This function supports nested selectors by iteratively checking each level
         * and inserting any missing selectors in sequence.
         *
         * @param newSelectorLESS The LESS selector to add to the AST and source code.
         * @result start line of the block
         */
        insertSelector(newSelectorLESS: string): number;
    }
}
declare module "_100554_/l2/lessASTTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessASTTest" {
    import { LitElement } from 'lit';
    import { LessCSS } from "_100554_/l2/lessCSS";
    export class LessASTTest100554 extends LitElement {
        rootSelector: string;
        fileToTest: string;
        url1: monaco.editor.ITextModel;
        render(): any;
        exeTest: () => string;
        test1: (lessCSS: LessCSS, rootSelector: string) => string;
        test2: (lessCSS: LessCSS, rootSelector: string) => string;
        test3: (lessCSS: LessCSS, rootSelector: string) => string;
        testt1: (lessCSS: LessCSS, rootSelector: string) => string;
        testt2: (lessCSS: LessCSS, rootSelector: string) => string;
    }
}
declare module "_100554_/l2/lessCSS.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessCSS" {
    import { LessAst } from "_100554_/l2/lessAST";
    /**
     * A unique symbol used as a key for properties that should be ignored during JSON serialization.
     *
     * Properties defined with this symbol as a key will not appear in the output of `JSON.stringify`,
     * ensuring that the property is excluded from serialization while avoiding key collisions.
     *
     * @const {symbol} ignoredProperty - A unique symbol for marking non-serializable properties.
     */
    const _editor: unique symbol;
    export class LessCSS {
        lessAST: LessAst;
        selector: string;
        position: "left" | "right";
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        _url: string;
        styles: CSSStyleDeclaration;
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor, position?: "left" | "right");
        setEditor(editor: monaco.editor.IStandaloneCodeEditor): void;
        /**
         * Sets the current selector for which properties will be applied.
         */
        setSelector(selector: string): void;
        /**
         * Retrieves a specific CSS property value for the current selector from the AST.
         * @param property The CSS property to retrieve
         */
        getProperty(property: string): string | undefined;
        /**
         * Sets or updates a CSS property in the AST and source model.
         * @param property The CSS property to set
         * @param value The new value for the property
         */
        setProperty(property: string, value: string): void;
        refresh(): void;
        setStateByLine(lineNumber: number, lineContent: string, emitter: 'editor' | 'helper' | 'preview'): void;
        private clearState;
        private updateState;
        private initStateIfNeeded;
    }
    export interface ICSSState {
        uri: string;
        selector: string | undefined;
        lineNumber: number | undefined;
        lineContent: string | undefined;
        key: string | undefined;
        value: string | undefined;
        lessCSS: LessCSS | undefined;
        emitter: 'editor' | 'helper' | 'preview';
    }
}
declare module "_100554_/l2/lessMonaco.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines: (url: string) => string[];
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine: (url: string, lineNr: number, line: string) => boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine: (url: string, lineNr: number) => boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines: (url: string, startLine: number, countLines: number) => boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine: (url: string, lineNr: number, columnNr: number, newText: string) => boolean;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (url: string) => void;
    }
}
declare module "_100554_/l2/libGithubIo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/libGithubIo" {
    export function addIssueInProject(req: IReq, idProject: string, idIssue: string): Promise<string | undefined>;
    export function removeIssueInProject(req: IReq, idProject: string, idIssueProject: string): Promise<boolean>;
    export function updateFieldSelectProjects(req: IReq, idProject: string, idItem: string, idField: string, idOption: string): Promise<boolean>;
    export function getIssuesInProjects(req: IReq, idProject: string): Promise<IItemProject[]>;
    export function getProjectFields(req: IReq, idProject: string): Promise<IFieldsProject[]>;
    export function getProjects(req: IReq): Promise<IProject[]>;
    export function addNewIssueIO(req: IReq, user: IInfo, repositoryId: string, labelsId: string[], title: string, desc: string): Promise<IIssues | undefined>;
    export function removeReact(req: IReq, issueid: string, reactid: string): Promise<boolean>;
    export function addReact(req: IReq, issueid: string): Promise<string>;
    export function getIssues(req: IReq, state?: string): Promise<IIssues[]>;
    export function getIssue(req: IReq, id: string): Promise<IIssues | undefined>;
    export function addComment(req: IReq, issue: IIssues, comment: string): Promise<IComments | undefined>;
    export function getIssueComments(req: IReq, issue: IIssues): Promise<IComments[]>;
    export function getRepositoryId(req: IReq): Promise<string>;
    export function addMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function addLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<ILabel | undefined>;
    export function removeMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function removeLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<boolean>;
    export function getLabels(req: IReq): Promise<ILabel[]>;
    export function getUsers(req: IReq): Promise<IAssignees[]>;
    export function getLabelIdOrAdd(req: IReq, repositoryId: string): Promise<ILabelsCollab | undefined>;
    export function createLabelIO(req: IReq, repositoryId: string, label: string, color: string): Promise<ILabel | undefined>;
    export function getUserInfoIO(req: IReq): Promise<IInfo>;
    export interface IItemProject {
        id: string;
        issue: IIssues;
        fieldValues: IItemProjectValues[];
    }
    export interface IAssignees {
        id: string;
        login: string;
        avatarUrl: string;
    }
    export interface IItemProjectValues {
        value: string;
        valueText: string;
        fieldName: string;
        fieldId: string;
    }
    export interface IProject {
        id: string;
        number: number;
        title: string;
        createdAt: string;
        author: string;
        avatarUrl: string;
        url: string;
        fields: IFieldsProject[];
    }
    export interface IFieldsProject {
        id: string;
        name: string;
        dataType: string;
        options: {
            id: string;
            name: string;
        }[];
    }
    export interface IReq {
        owner: string;
        repo: string;
        branch: string;
    }
    export interface IIssues {
        id: string;
        numberIssues: number;
        createdAt: string;
        title: string;
        bodyText: string;
        state: string;
        url: string;
        author: string;
        avatarUrl: string;
        labels: ILabel[];
        reactionsTU: number;
        reactions: IReactions[];
        comments: IComments[];
        assignees: IAssignees[];
        project: IProjectMain;
    }
    export interface IProjectMain {
        number: number;
        title: string;
        id: string;
    }
    export interface IReactions {
        id: string;
        user: string;
    }
    export interface ILabel {
        id: string;
        color: string;
        name: string;
    }
    export interface IComments {
        createdAt: string;
        id: string;
        bodyText: string;
        author: string;
        avatarUrl: string;
    }
    export interface IInfo {
        name: string;
        login: string;
        avatarUrl: string;
    }
    export interface ILabelsCollab {
        feature: string;
        low: string;
        medium: string;
        high: string;
    }
}
declare module "_100554_/l2/libManagementCan.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/libManagementCan" {
    /**
     * Inicializa ou atualiza o estado global em um caminho específico.
     */
    export function initState(path?: string, value?: string | object | unknown[]): void;
    /**
     * Atualiza o estado em um caminho.
     */
    export function setState(path: string, value: any): boolean;
    /**
     * Espera até que o estado em `path` seja igual a `value`.
     * Se `timeout` for 0 ou undefined, espera indefinidamente.
     */
    export function waitingState(path: string, value: any, options?: IVerifyOptions): Promise<void>;
    export function waitForNonEmptyState(path: string, options?: {
        retryInterval?: number;
        timeout?: number;
    }): Promise<string>;
    /**
     * Vigia continuamente um estado. Se ele mudar de valor, lança erro.
     * Fica rodando até chamar `unwatchState` ou `clearWatchers`.
     */
    export function watchState(path: string, expectedValue: any, options?: IVerifyOptions): void;
    /** Cancela observação de um path específico */
    export function unwatchState(path: string): void;
    /** Cancela todos os watchers ativos */
    export function clearWatchers(): void;
    /**
     * Verifica estado com timeout opcional, retornando boolean em vez de erro.
     */
    export function verifyState(path: string, value: any, options?: IVerifyOptions): Promise<boolean>;
    interface IVerifyOptions {
        timeout?: number;
        retryInterval?: number;
    }
}
declare module "_100554_/l2/libProviders.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/libProviders" {
    export function gitHubLogin(): void;
    export function gitLabLogin(): void;
    export function googleLogin(): void;
    export function isProviderConnected(provider: mls.cbe.Provider): boolean;
    export function googleIcon(): any;
    export function githubIcon(): any;
    export function gitlabIcon(): any;
}
declare module "_100554_/l2/mlsFileTree" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    interface TreeNode {
        name: string;
        fullPath: string;
        isFolder: boolean;
        children: TreeNode[];
        fileKey?: string;
        extension?: string;
        file: mls.stor.IFileInfo;
    }
    export class MlsFileTree extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderNode;
        renderItem(node: TreeNode, depth: number): any;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleFolder;
        private selectFile;
        private clickGroupHidden;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private getLevel;
        private clearPath;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "_100554_/l2/mlsHistoryList.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/mlsHistoryList" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class MlsHistoryList extends CollabLitElement {
        project: number;
        shortName: string;
        position: 'left' | 'right';
        folder: string;
        level: number;
        extension: string;
        loading: boolean;
        private error;
        private data;
        connectedCallback(): Promise<void>;
        getListHistory(): Promise<void>;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        private createJson;
        private createJson2;
        private filters;
        private findFirstInFilters;
        private getWeekOffet;
        private formatDate;
        handleClick(a: PointerEvent): void;
        render(): any;
    }
    export interface IHistoryItem {
        author: string;
        time: string;
        dateAm: string;
        hash: string;
        subject?: string;
        linesInserted: number | undefined;
        linesDeleted: number | undefined;
        authorUrl: string;
        type: 'item' | 'title';
    }
}
declare module "../l2/pluginNewFileBase" {
    export interface IDetails {
        title: string;
        description: string;
        tags: string[];
    }
    export function changeClassName(source: string, project: number, shortname: string): string;
    export function changeWidget(source: string, project: number, shortname: string): string;
    export function changeShortName(source: string, shortname: string): string;
    export function changeTagName(source: string, tagName: string): string;
    export function changeProject(source: string, project: number): string;
    export function changeFolder(source: string, folder: string): string;
    export function changeStateName(source: string, stateName: string): string;
    export function getTemplateImport(projectBase: number, shortName: string, folder: string): string;
    export interface IRequestNewFile {
        project: number;
        position: 'left' | 'right';
        shortName: string;
        folder?: string;
        enhancement: string;
        sourceTS: string;
        sourceHTML?: string;
        sourceLess?: string;
        sourceTest?: string;
        sourceDefs?: string;
        openPreview: boolean;
    }
    export function createNewFile(args: IRequestNewFile): Promise<void>;
}
declare module "_100554_/l2/moduleToBeAST" {
    export function getModuleToBeInfo(project: number, moduleName: string): Promise<{
        ok: boolean;
        message: string;
        toBe?: undefined;
        toBePages?: undefined;
    } | {
        ok: boolean;
        toBe: any;
        toBePages: any;
        message?: undefined;
    }>;
    export function saveModuleToBe(project: number, moduleName: string, toBe: Object | undefined, toBePage: Object | undefined): Promise<{
        ok: boolean;
        message?: undefined;
    } | {
        ok: boolean;
        message: string;
    }>;
}
declare module "_100554_/l2/modules.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/modules" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class Modules extends CollabLitElement {
        private msg;
        private viewMode;
        private modules;
        loading: boolean;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private fetchModules;
        private getLocal;
        private loadModule;
        private getModulesByActualProject;
        private moveActualToFirst;
        private handleAddClick;
        private handleBackClick;
        private selectThis;
        private setLocal;
        private goToL4;
        private renderListView;
        private renderAddView;
        render(): any;
    }
}
declare module "_100554_/l2/pluginAgentPlayground.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/docMd" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class DocMd extends CollabLitElement {
        private _html;
        private _marked;
        private oriHtml;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private _importMarked;
        private _parse;
        private init;
    }
}
declare module "_100554_/l2/pluginAgentPlayground" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "/_100554_/l2/docMd.js";
    export class AgentTester extends CollabLitElement {
        private _agent;
        private inError;
        agent: string;
        containerdraganddrop: HTMLElement | undefined;
        selCompare: HTMLSelectElement | undefined;
        private activeJudge;
        private msgSelectGroup;
        private activeGroup;
        private combinations;
        private groups;
        private actualGrup;
        private loading;
        private mode;
        private result;
        private prompts;
        private list;
        private chatPreferences;
        actualTaskInDetails?: mls.msg.TaskData;
        actualDetails?: HTMLElement;
        private inEdit;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderHead(): any;
        renderMode(): any;
        renderInputs(): any;
        renderGroups(): any;
        renderGroupSelector(): any;
        renderButonAdd(): any;
        renderPrompt(prompt: Iprompts, idx: number): any;
        renderMove(idx: number): any;
        renderSelect(prompt: Iprompts): any;
        renderResult(): any;
        renderCompare(): any;
        renderSettings(): any;
        renderListThread(): any;
        private init;
        private verifyProp;
        private selectTabResult;
        private selectTabInput;
        private selectTabSettings;
        private updateSelect;
        private handleDetails;
        private addPrompt;
        private trashClick;
        private promptEvent;
        private getCleanPreContent;
        private handlePlay;
        private timeSave;
        private handleSave;
        private getPrompts;
        private handleThreadChange;
        private _callAgent;
        private escapeAngleBrackets;
        private escape;
        private draggedItem;
        private dropTarget;
        private dropPosition;
        private handleDragStart;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private moveItemInArray;
        private handlePaste;
        private addGroup;
        private changeGrups;
        private sortGroup;
        private setDefaultGroup;
        private removeGroup;
        private handleSelectChange;
        private getPar;
        private _onCheckboxChange;
        private _onCheckboxChangeJudge;
        private openInDetails;
        private extractJsonString;
        private openInMessage;
    }
    interface Iprompts {
        type: string;
        content: string;
        openDetail: boolean;
        group: string;
    }
}
declare module "_100554_/l2/pluginAttrDataset.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginBaseModule" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_100554_/l2/pluginAttrDataset" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginAttrDataSet extends PluginBaseModule {
        private msg;
        expandedPaths: Set<string>;
        selectedPath: string;
        data: {};
        constructor();
        render(): any;
        renderTree(data: any, path?: string): any;
        renderTreeItem(path: string, key: string, value: any): any;
        private setConfig;
        private toggleExpand;
        private selectItem;
        private formatPath;
        private init;
        private getState;
        private css;
    }
}
declare module "_100554_/l2/pluginBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginBase" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export abstract class PluginBase extends CollabLitElement {
        scope: string;
        abstract description: string;
        abstract getSvg(): TemplateResult;
    }
}
declare module "_100554_/l2/pluginBaseIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_100554_/l2/pluginBaseModule.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginBaseModule" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_100554_/l2/pluginCodeInsights" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { IdefModule } from "_102027_/l2/libMindMap";
    export class pluginCodeInsights extends PluginBaseModule {
        private error;
        allItens: Record<string, IdefModule> | undefined;
        element: Required<CodeInsights> | undefined;
        private activeCategory;
        private selectedFile;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderDetails(): TemplateResult;
        private formatCategory;
        loadDefs(): Promise<void>;
        private getWithCodeInsights;
        private groupCodeInsightsByCategory;
        private onClickItem;
        private closeDetails;
        fireEvents(action: string, file: mls.stor.IFileInfo, timeout?: number): Promise<void>;
    }
    type CodeInsights = {
        todos?: Record<string, IdefModule>;
        securityWarnings?: Record<string, IdefModule>;
        unusedImports?: Record<string, IdefModule>;
        deadCodeBlocks?: Record<string, IdefModule>;
        accessibilityIssues?: Record<string, IdefModule>;
        i18nWarnings?: Record<string, IdefModule>;
        performanceHints?: Record<string, IdefModule>;
    };
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginCodelensCustomElement.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/widgetTextCode" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class WidgetTextCode extends CollabLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        firstUpdated(): void;
        render(): any;
        private onChangeText;
    }
}
declare module "_100554_/l2/pluginCodelensCustomElement" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/widgetTextCode.js';
    export class PluginCodelensCustomElement extends CollabLitElement {
        private msg;
        textCode2: string;
        render(): any;
    }
}
declare module "_100554_/l2/pluginCodelensFileReferences.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCodelensFileReferences" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class PluginCodelensFileReferences extends CollabLitElement {
        private msg;
        references: mls.editor.IModelTS[];
        project: number;
        shortName: string;
        position: string;
        firstUpdated(): Promise<void>;
        render(): any;
        private handleClick;
        private getReferences;
    }
}
declare module "_100554_/l2/pluginCodelensServiceDetails.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCodelensServiceDetails" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class PluginCodelensServiceDetails extends CollabLitElement {
        private msg;
        render(): any;
        textExampleIcon: string;
        textExampleNormal: string;
        textExampleCustom: string;
        textExampleCustomLevel: string;
    }
}
declare module "_100554_/l2/pluginCollabCoreIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default_1: "disabled";
    export default _default_1;
}
declare module "_100554_/l2/pluginCollabCoreIndex" {
    import { PluginBaseIndex } from '_100554_/l2/pluginBaseIndex';
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_2: PluginCollabCoreIndex;
    export default _default_2;
}
declare module "_100554_/l2/pluginCollabLogin.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCollabLogin" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginCollabLogin100554 extends PluginBaseModule {
        private msg;
        private googleState;
        private origin;
        render(): any;
        renderBackButton(): any;
        renderTitle(): any;
        renderDivider(text: string): any;
        renderButton(provider: mls.cbe.Provider, icon: TemplateResult, clickHandler: () => void): any;
        renderLogOff(text: string, icon: TemplateResult, clickHandler: () => void): any;
        renderFooter(): any;
        logoff(): void;
        getState(provider: mls.cbe.Provider): StateProvider;
        isProviderConnected(provider: mls.cbe.Provider): boolean;
        getRedirectLink(): string;
        googleLogin(): void;
        gitHubLogin(): void;
        gitLabLogin(): void;
        verifyDisconnect(provider: mls.cbe.Provider): boolean;
        generateRandomState(): string;
        onBackButtonClick(): void;
        LogoffIcon(): any;
        googleIcon(): any;
        githubIcon(): any;
        gitlabIcon(): any;
    }
    export const pluginData: mls.plugin.IPluginData;
    type StateProvider = 'connected' | 'canSignIn' | 'canDisconnect' | 'canAdd';
}
declare module "../l2/previewModeUtil" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export function mountJSImporMap(info: IJSONDependence, ifr: HTMLIFrameElement): void;
    export function mountCSS(ifr: HTMLIFrameElement): void;
    export function mountLinks(info: IJSONDependence, ifr: HTMLIFrameElement): void;
    export function mountTokens(tokens: string, file: mls.stor.IFileInfo): void;
    export function removeOlderTokens(ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): void;
    export function getIdTokens(file: mls.stor.IFileInfo): string;
    export function simulateService(info: IJSONDependence, ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): Promise<void>;
    export function addFA(ifr: HTMLIFrameElement): void;
    export function addTooltip(ifr: HTMLIFrameElement): void;
    export function addStyleMls(ifr: HTMLIFrameElement): void;
    export function addNav3(ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): void;
    export function waitForComponents(context: Window, componentNames: string[]): Promise<CustomElementConstructor[]>;
    export function addJsReference(ifr: HTMLIFrameElement, level: string): void;
}
declare module "../l2/previewModeSinglePage" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export class PreviewModeSinglePage {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        private esbuild;
        private needAwait;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        buildJS(other: string[]): Promise<any>;
        private configIframe;
        private _buildJS;
        private parseImportsMap;
        private findWidgets;
        private loadEsbuild;
        private initializeEsBuild;
        private loadCache;
    }
}
declare module "_100554_/l2/pluginCollabPublish" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginCollabPublish extends PluginBaseModule {
        private myState;
        private msg;
        completed: number[];
        current: number;
        languages: ILanguage[];
        pages: mls.stor.IFileInfo[];
        inPublish: boolean;
        logs: string[];
        logBox: HTMLElement | undefined;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderWizard(): any;
        renderScenary(): any;
        renderScenary1(): any;
        renderScenary2(): any;
        renderScenary3(): any;
        private init;
        private getLanguages;
        private getPages;
        private getAssets;
        private next;
        private isValid1;
        private isValid2;
        private startPublish;
        private publishByLanguage;
        private publishPage;
        private mounHTML;
        private importJSON;
        private addGlobalCss;
        private modeSinglePage;
        private addLog;
        private isRemovedFork;
        private owner;
        private repo;
        private branch;
        private onSave;
        private onSaveAssets;
        private clearLocalHIstoryCurrentInfoDriver;
        private firePullrequest;
        private onSavenewPullrequest;
        private fireCreateForkOrUpdate;
        private getLocalHIstoryCurrentInfoDriver;
        private removeFork;
        private fireCreateNewBranch;
        private setLocalHIstoryCurrentInfoDriver;
        private waitRender;
    }
    interface ILanguage {
        language: string;
        name: string;
        path: string;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginCollabPublishS3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginCollabPublishS3 extends PluginBaseModule {
        private msg;
        private aws;
        private s3;
        bucket: string;
        accessKeyId: string;
        secretAccessKey: string;
        region: string;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderInfo(): TemplateResult;
        private addAws;
        private getAwsSDK;
        private connectS3;
        private setConnectionConfig;
        private sendFile;
        private getContentType;
        private convertToBLob;
        private setConfigS3;
        private getConfigS3;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginCollabWidgetIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCollabWidgetIndex" {
    import { PluginBaseIndex } from '_100554_/l2/pluginBaseIndex';
    export class PluginCollabWidgetIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_3: PluginCollabWidgetIndex;
    export default _default_3;
}
declare module "_100554_/l2/pluginConfigLinks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginConfigLinks" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginConfigLinks extends PluginBaseModule {
        myLinks: ILinks[];
        autoPrepare: boolean;
        private myConfig;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderLink(l: ILinks, idx: number): TemplateResult;
        renderEdit(): TemplateResult;
        private init;
        private addLink;
        private updateConfig;
        private clickDel;
        private removeModeEdit;
        private setModeEdit;
        private test;
    }
    interface ILinks {
        title: string;
        url: string;
        color: string;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginCreateProject.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libNewProject" {
    export interface IProjectType {
        id: string;
        name: string;
        dependencies: number[];
        agent?: string;
    }
    export const projectTypes: IProjectType[];
    export const template_tsconfig: {
        ext: string;
        template: string;
    };
    export const template_l5Project: {
        ext: string;
        template: string;
    };
    export const template_package: {
        ext: string;
        template: string;
    };
    export const template_build: {
        ext: string;
        template: string;
    };
    export const template_l2Project: {
        ext: string;
        template: string;
    };
    export const template_coreIndex: {
        ext: string;
        template: string;
    };
    export const template_ds: {
        ext: string;
        template: string;
    };
}
declare module "_100554_/l2/pluginCreateProject" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class PluginCreateProject extends CollabLitElement {
        private msg;
        currentScenario: IScenaries;
        projectName: string;
        projectType: 'blank' | 'prompt';
        projectPrompt: string;
        selectedProjectTypeId: string;
        errorName: string;
        errorPrompt: string;
        alreadyHasProjectLocal: boolean;
        isLoading: boolean;
        projectCreatedSucessfully: boolean;
        private projectNumber;
        private get selectedProjectType();
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private renderScenario;
        private renderSelect;
        private renderProjectCreatedOk;
        private handleCancel;
        private handleProjectTypeChange;
        private validateForm;
        private handleCreate;
        private setProjectActual;
        private createFiles;
        private createInitialProject;
        private createInitialConfigL5File;
        private createInitialDSFile;
        private createNewFileL2;
    }
    type IScenaries = 'select';
}
declare module "_100554_/l2/pluginCreateProjectLocalToDriver.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/libProviders" {
    export function gitHubLogin(): void;
    export function gitLabLogin(): void;
    export function googleLogin(): void;
    export function isProviderConnected(provider: mls.cbe.Provider): boolean;
    export function googleIcon(): any;
    export function githubIcon(): any;
    export function gitlabIcon(): any;
}
declare module "../l2/pluginNewProjectLog" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '/_102029_/l2/collabLitElement';
    export class CollabLogLine100554 extends CollabLitElement {
        text: string;
        status: ILogStatus;
        private iconsByStatus;
        render(): any;
    }
    export type ILogStatus = 'waiting' | 'inprogress' | 'finish' | 'error';
    export type IIconsByStatus = {
        [key in ILogStatus]: TemplateResult<2>;
    };
}
declare module "_100554_/l2/pluginCreateProjectLocalToDriver" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/pluginNewProjectLog.js';
    export class PluginCreateProject extends CollabLitElement {
        private msg;
        private selectedProvider?;
        private githubConnected;
        private gitlabConnected;
        private errorMessage;
        actualOrgs: mls.stor.others.IOrg[];
        actualTeams: string[];
        orgSelected: boolean;
        isLoadingOrgs: boolean;
        activeScenerie: IScenerie;
        logs: ILogs[];
        errorName: string;
        errorOrg: string;
        logsContainer: HTMLDivElement | undefined;
        progress: HTMLDivElement | undefined;
        form: HTMLFormElement | undefined;
        private instanceDriver;
        private login;
        private secret;
        private orgName;
        private projectLocalNumber;
        private newProjectName;
        private newProjectNumber;
        private newProjectTeam;
        private newProjectVisibility;
        private NEWREPONAME;
        private VALIDADEFILE;
        private drivers;
        private urls;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private handleSelect;
        private handleConnect;
        private handleContinue;
        private loadOrgsByDriver;
        private getOrgsByUser;
        private onOrgChanged;
        private onRefreshOrgsClick;
        private loadTeamByOrg;
        private getLoginUser;
        private addLog;
        private setProgress;
        private setProgressError;
        private setProgressFinished;
        private changeStatusLastLog;
        private getUniquePassword;
        private toogleForm;
        private sleep;
        private onCancelStep2;
        private tryItem;
        private setPermissionAction;
        private setVariableAction;
        private createInitialReadMe;
        private createInitialBuildFile;
        private createInitialPackageFile;
        private createInitialTSConfigFile;
        private createPrjInfo;
        private addTempObject;
        private addFileInfoItem;
        private migrateAllFiles;
        private migrateFile;
        private prepareToAddFileInfo;
        private deleteOldFiles;
        private migrateLocalFiles;
        private replaceSpecificProjectId;
        private createProjecInCollab;
        private validateForm;
        private onCreateProjectClickTest;
        private onCreateProjectClick;
        private setProjectActual;
        private setOrgActual;
        private deleteLastOpenedFileOnLocalStorage;
        private renderSelectProvider;
        private renderCreateProject;
        private renderLogs;
        render(): any;
        renderScenaries(): any;
    }
    interface ILogs {
        pre: string;
        log: string;
        status: string;
    }
    type IScenerie = 'select' | 'form';
}
declare module "_100554_/l2/pluginDeleteModule.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/projectAST" {
    export function addModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message?: undefined;
    } | {
        ok: boolean;
        message: string;
    }>;
    export function configureMasterFrontEnd(project: number, start: string, build: string, liveView: string): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
    export function removeModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
}
declare module "_100554_/l2/pluginDeleteModule" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class PluginDeleteModule extends CollabLitElement {
        private msg;
        moduleName: string;
        project: string;
        filesToDelete: mls.stor.IFileInfo[];
        confirmInput: string;
        isDeleting: boolean;
        isDeleted: boolean;
        feedbackMsg: string;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): TemplateResult;
        private getFilesModule;
        private getFileKey;
        private handleDelete;
        private deleteAllFiles;
        private removeTokensIfNeeded;
    }
}
declare module "_100554_/l2/pluginEditStyleAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginEditStyleAST" {
    type Block = {
        start: number;
        end: number;
    };
    export class LessAST {
        private model;
        selected: string | null;
        blocks: Map<string, Block>;
        rules: Record<string, string> | null | undefined;
        constructor(model: monaco.editor.ITextModel);
        select(selector: string): boolean;
        setRule(property: string, value: string): void;
        setRule_old(property: string, value: string): void;
        addSelector(selector: string, rules?: Record<string, string>): void;
        removeSelector(selector: string): void;
        getRules(selector: string): Record<string, string>;
        exportSelectorGroupStrict(baseSelector: string): string;
        private reparse;
        private ensureSelectorPath;
        private stripComments;
        private escape;
    }
}
declare module "_100554_/l2/pluginEditStyleL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginEditStyleAST" {
    type Block = {
        start: number;
        end: number;
    };
    export class LessAST {
        private model;
        selected: string | null;
        blocks: Map<string, Block>;
        rules: Record<string, string> | null | undefined;
        constructor(model: monaco.editor.ITextModel);
        select(selector: string): boolean;
        setRule(property: string, value: string): void;
        setRule_old(property: string, value: string): void;
        addSelector(selector: string, rules?: Record<string, string>): void;
        removeSelector(selector: string): void;
        getRules(selector: string): Record<string, string>;
        exportSelectorGroupStrict(baseSelector: string): string;
        private reparse;
        private ensureSelectorPath;
        private stripComments;
        private escape;
    }
}
declare module "_100554_/l2/pluginEditStyleL3" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { LessAST } from "_100554_/l2/pluginEditStyleAST";
    import "_102027_/l2/collabMonacoEditor";
    export class PluginEditStyleL3 extends PluginBaseModule {
        private editorEl;
        msize: string;
        error: string;
        private static inEdit;
        private static inSetValue;
        private _ed1;
        private _ed2;
        private initalSelectors;
        private msg;
        private model;
        private modelDest;
        modelBase: mls.editor.IModels | undefined;
        lessAst: LessAST | undefined;
        lessAstDest: LessAST | undefined;
        private keysResolve;
        get getKeyEditor(): string;
        get confE(): string;
        constructor();
        private setEvents;
        private onL3EditEvents;
        private onlevelChange;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: any): void;
        render(): any;
        forceUpdate(): Promise<void>;
        private init;
        private initMonaco_Editor;
        private openFile;
        private setContentDest;
        private setContent;
        private createModel;
        private _onModelChange;
        private timeOnChangeLessOrigin;
        private changeLessOrigin;
        private changeLessOrigin2;
        private mergeCssDeclarations;
        private getMatchingRulesForElement;
        private updatedMSizeEditor;
        private resolveSelector;
    }
}
declare module "_100554_/l2/pluginExamplesIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginExamplesIndex" {
    import { PluginBaseIndex } from '_100554_/l2/pluginBaseIndex';
    export class PluginExamplesIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_4: PluginExamplesIndex;
    export default _default_4;
}
declare module "_100554_/l2/pluginExploreList.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libHistoriesRecents" {
    export function addInHistory(file: mls.stor.IFileInfo): void;
    export function getHistory(): HistoryList;
    export function removeFromHistory(target: HistoryItem): void;
    export function renameHistoryItem(target: HistoryItem, newShortName: string): void;
    export function loadProjectHistory(): IHistoryProject[];
    export function saveProjectHistory(history: IHistoryProject[]): void;
    export function removeProjectFromHistory(projectId: number): void;
    export function renameProjectInHistory(projectId: number, newName: string): void;
    interface IHistoryProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export interface HistoryItem {
        project: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    type HistoryList = HistoryItem[];
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "../l2/collabInputSearch" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabInputSearch extends CollabLitElement {
        private msg;
        placeholder: string;
        value: string;
        private focused;
        firstUpdated(): void;
        render(): any;
        private _onInput;
        private _onFocus;
        private _onBlur;
        private _clear;
        private _onKeyDown;
    }
}
declare module "../l2/mlsFileTree" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    interface FileInfo {
        project: number;
        level: number;
        shortName: string;
        folder: string;
        extension: string;
    }
    interface TreeNode {
        name: string;
        fullPath: string;
        isFolder: boolean;
        children: TreeNode[];
        fileKey?: string;
        extension?: string;
        file: mls.stor.IFileInfo;
    }
    export class MlsFileTree extends CollabLitElement {
        position: string | undefined;
        project: string | undefined;
        filter: string;
        files: Record<string, FileInfo>;
        private expanded;
        private selected;
        private _loading;
        private _loadingMsg;
        firstUpdated(): void;
        render(): any;
        private _renderOverlay;
        private renderFiltered;
        private highlightText;
        private renderNode;
        renderItem(node: TreeNode, depth: number): any;
        private deleteFile;
        private undoFile;
        private getTitleInLocalStorage;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private buildTree;
        private toggleFolder;
        private selectFile;
        private clickGroupHidden;
        private collectFilesFromNode;
        private delAllByFolders;
        private undoAllByFolders;
        private getLevel;
        private clearPath;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
    }
}
declare module "../l2/serviceBase" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "../l2/pluginExploreListAddL1" {
    import { ServiceBase } from '_100554_/l2/serviceBase';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class ServiceListFilesAdd100554 extends CollabLitElement {
        private baseProject;
        private msg;
        service: ServiceBase | undefined;
        father: HTMLElement | undefined;
        level: number;
        error: string;
        position: string;
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        private handleInputInput;
        private clickCancel;
        private getNewNameAndValid;
        private showLoad;
        private createFile;
        private setHistory;
        private showError;
        private fireEvents;
    }
}
declare module "../l2/pluginExploreListAddL2" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    export class ServiceListFilesAdd100554 extends CollabLitElement {
        private baseProject;
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        plugins: IPlugins[];
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        renderTemplates(): any;
        private goBack;
        private handleInputInput;
        private handleClickTemplate;
        private clickCancel;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private getPlugins;
        private getPluginsInfo;
    }
    interface IPlugins extends IDetails {
        widget: string;
        category: string | null;
    }
}
declare module "../l2/pluginExploreListAddL3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL3 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "../l2/pluginExploreListAddL4" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL4 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptPage: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private verifyModuleConfig;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100554_/l2/pluginExploreList" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import '/_100554_/l2/collabInputSearch.js';
    import '/_100554_/l2/mlsFileTree.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreList extends PluginBaseModule {
        createModels(stor: mls.stor.IFileInfo): Promise<void>;
        private resizeObserver;
        private myDep;
        private msg;
        service: ServiceBase | undefined;
        private filterByLevel;
        autoPrepare: boolean;
        mode: TModeExploreList;
        refresh: string;
        position: string;
        levelFiles: number;
        project: number;
        projectLabel: string;
        filterProject: number;
        modeView: number;
        hiddenFiles: boolean;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        history: mls.stor.IFileInfo[];
        modeFilter: string | undefined;
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        private showAdd;
        private filesInLocal;
        private setEvents;
        private onlevelChange;
        private onMLSEvents;
        connectedCallback(): void;
        disconnectedCallback(): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        renderModeList(): any;
        renderHeader(): any;
        renderHistory(): any;
        renderList(): any;
        renderFolder(): any;
        renderFolder2(files: mls.stor.IFileInfo[]): any;
        getTitleInLocalStorage(ts: mls.stor.IFileInfo, html: mls.stor.IFileInfo, less: mls.stor.IFileInfo, test: mls.stor.IFileInfo, defs: mls.stor.IFileInfo): string;
        renderLiItem(file: mls.stor.IFileInfo, index: number, inHistory: boolean): any;
        renderAddL1(): any;
        renderAddL2(): any;
        renderAddL3(): any;
        renderAddL4(): any;
        private getAllName;
        private showLoading;
        private showError;
        private closeAllMenus;
        private clickOptUndo;
        private clickOptDel;
        private clickOptOpen;
        private clickOptOpenSecurity;
        private clickOptRename;
        private clickOptClone;
        private cloneFile;
        private renameFile;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
        private fireEventThisProject;
        private fireEventLoadProject;
        private changeListTimeout;
        changeList(time?: number): void;
        private extensionLevel;
        private levelByLevel;
        private init;
        private setLastFilter;
        private getMyFileInElement;
        private clickGroupHidden;
        private changeSelectProject;
        private changeHiddenFiles;
        private changeModeOrder;
        private inFilter;
        private timeFilterChange;
        private searchTerm;
        private filterLiChange;
        private getFiles;
        private filterArrayHistory;
        private validFileByLevel;
        private getFilesProject;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private getFileHistory;
        private isValidNewName;
        private initObserverResize;
        private saveLocalStorageLastOpen;
        private delAllByFolders;
        private loadLastPreference;
        private getLastModeFilter;
        private setLastPreference;
    }
    type TModeExploreList = 'list' | 'addL1' | 'addL2' | 'addL3' | 'addL4';
}
declare module "_100554_/l2/pluginExploreListAddL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginExploreListAddL1" {
    import { ServiceBase } from '_100554_/l2/serviceBase';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class ServiceListFilesAdd100554 extends CollabLitElement {
        private baseProject;
        private msg;
        service: ServiceBase | undefined;
        father: HTMLElement | undefined;
        level: number;
        error: string;
        position: string;
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        private handleInputInput;
        private clickCancel;
        private getNewNameAndValid;
        private showLoad;
        private createFile;
        private setHistory;
        private showError;
        private fireEvents;
    }
}
declare module "_100554_/l2/pluginExploreListAddL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginExploreListAddL2" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    export class ServiceListFilesAdd100554 extends CollabLitElement {
        private baseProject;
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        plugins: IPlugins[];
        loading: boolean;
        shortName: string | undefined;
        inputShortName: HTMLInputElement | undefined;
        connectedCallback(): Promise<void>;
        private init;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderHeader(): any;
        renderAdd(project: number): any;
        renderTemplates(): any;
        private goBack;
        private handleInputInput;
        private handleClickTemplate;
        private clickCancel;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private getPlugins;
        private getPluginsInfo;
    }
    interface IPlugins extends IDetails {
        widget: string;
        category: string | null;
    }
}
declare module "_100554_/l2/pluginExploreListAddL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginExploreListAddL3" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL3 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100554_/l2/pluginExploreListAddL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginExploreListAddL4" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginExploreListAddL4 extends PluginBaseModule {
        modules: string[];
        father: HTMLElement | undefined;
        service: ServiceBase | undefined;
        autoPrepare: boolean;
        iptModule: HTMLSelectElement | undefined;
        iptPage: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        firstUpdated(): void;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        private prepare;
        private init;
        private goBack;
        private verifyModuleConfig;
        private createFile;
        private fireImprove;
        private setHistory;
        private getNewNameAndValid;
        private hasInvalidCharacter;
        private isValidNewName;
        private showLoad;
        private showError;
    }
}
declare module "_100554_/l2/pluginExploreStories.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginExploreStories" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreStories extends PluginBaseModule {
        private msg;
        private project;
        position: 'left' | 'right';
        level: number;
        autoPrepare: boolean;
        files: IItensFiles[];
        activeTab: ITabType;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderContent(): any;
        renderDraft(): any;
        renderPublished(): any;
        renderList(): any;
        renderLiItem(file: IItensFiles, index: number, inHistory: boolean): any;
        private init;
        private getFiles;
        private getFilesProject;
        private clickLi;
        private clickMenu;
        private timeBlur;
        private blurMenu;
        private overMenu;
        private clickOptOpen;
        private clickOptDel;
        private fireEvents;
    }
    type ITabType = 'icDraft' | 'icPublished';
    interface IItensFiles {
        file: mls.stor.IFileInfo;
        name: string;
        desc: string;
    }
}
declare module "_100554_/l2/pluginFindTask" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class PluginFindTask extends StateLitElement {
        private msg;
        threadId?: string;
        taskId?: string;
        error?: string;
        actualTask: msg.TaskData | undefined;
        actualMessage: msg.Message | undefined;
        isLoading: boolean;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderSearch;
        private handleThreadChange;
        private handleTaskChange;
        private findThread;
    }
}
declare module "_100554_/l2/pluginGenerateDist" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginGenerateDist extends PluginBaseModule {
        private msg;
        error: string;
        tag: string;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderTag(): any;
        renderDefault(): TemplateResult;
        renderHeader(): TemplateResult;
        private init;
        private hasExtension;
        private getBuildByProject;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginGithubL4Issues.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/libGithubIo" {
    export function addIssueInProject(req: IReq, idProject: string, idIssue: string): Promise<string | undefined>;
    export function removeIssueInProject(req: IReq, idProject: string, idIssueProject: string): Promise<boolean>;
    export function updateFieldSelectProjects(req: IReq, idProject: string, idItem: string, idField: string, idOption: string): Promise<boolean>;
    export function getIssuesInProjects(req: IReq, idProject: string): Promise<IItemProject[]>;
    export function getProjectFields(req: IReq, idProject: string): Promise<IFieldsProject[]>;
    export function getProjects(req: IReq): Promise<IProject[]>;
    export function addNewIssueIO(req: IReq, user: IInfo, repositoryId: string, labelsId: string[], title: string, desc: string): Promise<IIssues | undefined>;
    export function removeReact(req: IReq, issueid: string, reactid: string): Promise<boolean>;
    export function addReact(req: IReq, issueid: string): Promise<string>;
    export function getIssues(req: IReq, state?: string): Promise<IIssues[]>;
    export function getIssue(req: IReq, id: string): Promise<IIssues | undefined>;
    export function addComment(req: IReq, issue: IIssues, comment: string): Promise<IComments | undefined>;
    export function getIssueComments(req: IReq, issue: IIssues): Promise<IComments[]>;
    export function getRepositoryId(req: IReq): Promise<string>;
    export function addMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function addLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<ILabel | undefined>;
    export function removeMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function removeLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<boolean>;
    export function getLabels(req: IReq): Promise<ILabel[]>;
    export function getUsers(req: IReq): Promise<IAssignees[]>;
    export function getLabelIdOrAdd(req: IReq, repositoryId: string): Promise<ILabelsCollab | undefined>;
    export function createLabelIO(req: IReq, repositoryId: string, label: string, color: string): Promise<ILabel | undefined>;
    export function getUserInfoIO(req: IReq): Promise<IInfo>;
    export interface IItemProject {
        id: string;
        issue: IIssues;
        fieldValues: IItemProjectValues[];
    }
    export interface IAssignees {
        id: string;
        login: string;
        avatarUrl: string;
    }
    export interface IItemProjectValues {
        value: string;
        valueText: string;
        fieldName: string;
        fieldId: string;
    }
    export interface IProject {
        id: string;
        number: number;
        title: string;
        createdAt: string;
        author: string;
        avatarUrl: string;
        url: string;
        fields: IFieldsProject[];
    }
    export interface IFieldsProject {
        id: string;
        name: string;
        dataType: string;
        options: {
            id: string;
            name: string;
        }[];
    }
    export interface IReq {
        owner: string;
        repo: string;
        branch: string;
    }
    export interface IIssues {
        id: string;
        numberIssues: number;
        createdAt: string;
        title: string;
        bodyText: string;
        state: string;
        url: string;
        author: string;
        avatarUrl: string;
        labels: ILabel[];
        reactionsTU: number;
        reactions: IReactions[];
        comments: IComments[];
        assignees: IAssignees[];
        project: IProjectMain;
    }
    export interface IProjectMain {
        number: number;
        title: string;
        id: string;
    }
    export interface IReactions {
        id: string;
        user: string;
    }
    export interface ILabel {
        id: string;
        color: string;
        name: string;
    }
    export interface IComments {
        createdAt: string;
        id: string;
        bodyText: string;
        author: string;
        avatarUrl: string;
    }
    export interface IInfo {
        name: string;
        login: string;
        avatarUrl: string;
    }
    export interface ILabelsCollab {
        feature: string;
        low: string;
        medium: string;
        high: string;
    }
}
declare module "_100554_/l2/pluginGithubL4Issues" {
    import { TemplateResult } from 'lit';
    import * as gitIO from '_100554_/l2/libGithubIo';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginGithubL4Issues extends CollabLitElement {
        private repositoryId;
        private userInfo;
        private labelId;
        private req;
        private viewIssue;
        private comments;
        error: string;
        scenary: string;
        myIssues: gitIO.IIssues[];
        isLoader: boolean;
        labelfilter: string;
        contentlistissues: HTMLElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderLoader(): TemplateResult;
        renderError(): TemplateResult;
        renderList(): TemplateResult;
        renderListFilter(): any;
        renderListItem(item: gitIO.IIssues, idx: number): any;
        renderNewIssue(): any;
        renderShow(): any;
        renderCogs(): any;
        renderThumbsUp(): any;
        renderComments(item: gitIO.IComments): any;
        private setInfos;
        private clickCogs;
        private changeLabelPrioriti;
        private filterMyIssues;
        private clickScenaryNew;
        private removeVote;
        private addVote;
        private backButton;
        private clickIssues;
        private addNewIssue;
        private timeFilter;
        private filter;
        private clickNewComment;
        private initInfoProject;
    }
}
declare module "_100554_/l2/pluginGithubL4Project.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginGithubL4Project" {
    import { TemplateResult } from 'lit';
    import * as gitIO from '_100554_/l2/libGithubIo';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginGithubL4Project extends CollabLitElement {
        private repositoryId;
        private userInfo;
        private req;
        private myLabels;
        private myUsers;
        private myProjcts;
        private viewProject;
        private itensShowProject;
        private idFieldStatus;
        private sort;
        error: string;
        scenary: string;
        isLoader: boolean;
        autoClick: string;
        viewIssue: gitIO.IItemProject | undefined;
        addInStatus: string | undefined;
        listIssues: gitIO.IIssues[] | undefined;
        contentstatus: HTMLElement | undefined;
        contentviewissue: HTMLElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderLoader(): TemplateResult;
        renderError(): TemplateResult;
        renderList(): TemplateResult;
        renderListFilter(): any;
        renderListItem(item: gitIO.IProject, idx: number): any;
        renderHeader(): any;
        renderShow(): TemplateResult;
        renderTab(): TemplateResult;
        renderTaksTab(array: gitIO.IItemProject[] | undefined): TemplateResult;
        renderTaskTab(p: gitIO.IItemProject): TemplateResult;
        renderViewIssue(): TemplateResult;
        renderViewMain(): TemplateResult;
        renderViewOptions(): TemplateResult;
        renderOptionsLabels(l: gitIO.ILabel): TemplateResult;
        renderOptionsMembers(l: gitIO.IAssignees): TemplateResult;
        renderComentsInTask(c: gitIO.IComments): TemplateResult;
        renderLabelsInTask(l: gitIO.ILabel): TemplateResult;
        renderAddIssue(): TemplateResult;
        renderListIssues(): TemplateResult;
        renderListItemIssues(item: gitIO.IIssues, idx: number): any;
        private setInfos;
        private initInfoProject;
        private backButton;
        private clickChangeView;
        private addIssuesin;
        private addIssueInProject;
        private clickSaveComment;
        private clickItemProject;
        private listAllIssues;
        private addIssue;
        private changeLabel;
        private changeMembers;
        private removeIssueInProject;
        private isAutoClick;
        private organizeItens;
        private showViewIssue;
        private clickCloseIssue;
        private openMyChild;
        private setDragAndDrop;
        private myIcons;
    }
}
declare module "_100554_/l2/pluginLessPseudo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginLessPseudo" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginLessPseudo extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/pluginNavigationRenderOrganism.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabPreviewL3" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabL3EditText.js';
    export class CollabPreviewL3 extends CollabLitElement {
        constructor();
        private elOverlayHover;
        private elOverlaySelected;
        setHover(el: HTMLElement | undefined, active: boolean): void;
        selectElement(el: HTMLElement): void;
        render(): any;
        private init;
        private setEventsMouse;
        private createOverlay;
        private createOverlaySelected;
        private _setHover;
        private _selectElement;
        private addEdit;
    }
}
declare module "_100554_/l2/pluginNavigationRenderOrganism" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginNavigationRenderOrganism extends PluginBaseModule {
        private msg;
        private atributeBase;
        private elPreviewL3;
        service: ServiceBase | undefined;
        scenary: TScenary;
        els: IInfoElChildren[];
        iptModule: HTMLSelectElement | undefined;
        iptOrganism: HTMLInputElement | undefined;
        iptPrompt: HTMLInputElement | undefined;
        constructor();
        private setEvents;
        private onL3EditEvents;
        private fineshPreview;
        private onSelect;
        private onNavigation;
        private onlevelChange;
        activeId: string;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        renderHeader(txt: string, btn: TemplateResult<1>, pos: string): any;
        renderDetails(): any;
        renderNav(): any;
        renderNav2(): any;
        createNavigation(array: IInfoElChildren[]): any;
        renderItemTree(item: IInfoElChildren, idx: string): any;
        forceUpdate(): void;
        private init;
        private goToScenary;
        private openCollabMessage;
        private dispatchEventAdd;
        private dispatchEventProperty;
        private dispatchEventGlobalStyle;
        private dispatchEventStyle;
        private setElPreview;
        private getComponents;
        private mockup;
        private selectItem;
        private clickGroupHidden;
        private delEl;
        private onMouseover;
        private onMouseout;
        private highlightElement;
        private unhighlightElement;
        private goToL2;
    }
    type TScenary = 'list' | 'details';
    interface IInfoElChildren {
        el: HTMLElement;
        id: string;
        children: IInfoElChildren[];
        isFather: boolean;
    }
}
declare module "_100554_/l2/pluginNewFileAgent" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    import '/_100554_/l2/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileBlank extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        templateType: AgentTemplateType;
        private service;
        private enhancement;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
    type AgentTemplateType = 'agent' | 'agentParallel' | 'agentWithClarification';
}
declare module "_100554_/l2/pluginNewFileBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewFileBase" {
    export interface IDetails {
        title: string;
        description: string;
        tags: string[];
    }
    export function changeClassName(source: string, project: number, shortname: string): string;
    export function changeWidget(source: string, project: number, shortname: string): string;
    export function changeShortName(source: string, shortname: string): string;
    export function changeTagName(source: string, tagName: string): string;
    export function changeProject(source: string, project: number): string;
    export function changeFolder(source: string, folder: string): string;
    export function changeStateName(source: string, stateName: string): string;
    export function getTemplateImport(projectBase: number, shortName: string, folder: string): string;
    export interface IRequestNewFile {
        project: number;
        position: 'left' | 'right';
        shortName: string;
        folder?: string;
        enhancement: string;
        sourceTS: string;
        sourceHTML?: string;
        sourceLess?: string;
        sourceTest?: string;
        sourceDefs?: string;
        openPreview: boolean;
    }
    export function createNewFile(args: IRequestNewFile): Promise<void>;
}
declare module "_100554_/l2/pluginNewFileBlank.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewFileBlank" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    import '/_100554_/l2/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileBlank extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100554_/l2/pluginNewFileMd" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    import '/_100554_/l2/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileMd extends StateLitElement {
        shortName: string | undefined;
        folder: string | undefined;
        project: number | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100554_/l2/pluginNewFilePage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewFilePage" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    import '/_100554_/l2/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFilePage extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplateTS;
        private getTemplateHTML;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100554_/l2/pluginNewFileService.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewFileService" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    import '/_100554_/l2/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileService extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100554_/l2/pluginNewFileWebComponent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewFileWebComponent" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { IDetails } from "_100554_/l2/pluginNewFileBase";
    import '/_100554_/l2/widgetTextCode.js';
    export const details: IDetails;
    export class PluginNewFileWebComponent extends StateLitElement {
        shortName: string | undefined;
        project: number | undefined;
        folder: string | undefined;
        position: 'left' | 'right';
        loading: boolean;
        private service;
        private template;
        private enhancement;
        private groupName;
        private getTemplate;
        private handleAddFile;
        render(): any;
    }
}
declare module "_100554_/l2/pluginNewProjectLog.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewProjectLog" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from '/_102029_/l2/collabLitElement';
    export class CollabLogLine100554 extends CollabLitElement {
        text: string;
        status: ILogStatus;
        private iconsByStatus;
        render(): any;
    }
    export type ILogStatus = 'waiting' | 'inprogress' | 'finish' | 'error';
    export type IIconsByStatus = {
        [key in ILogStatus]: TemplateResult<2>;
    };
}
declare module "_100554_/l2/pluginNewProjectTemplate.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewProjectTemplate" {
    export const template_tsconfig: {
        ext: string;
        template: string;
    };
    export const template_l5Project: {
        ext: string;
        template: string;
    };
    export const template_package: {
        ext: string;
        template: string;
    };
    export const template_build: {
        ext: string;
        template: string;
    };
    export const template_l2Project: {
        ext: string;
        template: string;
    };
    export const template_coreIndex: {
        ext: string;
        template: string;
    };
    export const template_ds: {
        ext: string;
        template: string;
    };
}
declare module "_100554_/l2/pluginPageAIVerify.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPageAIVerify" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginPageAIVerify extends PluginBaseModule {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/pluginPageNavigation.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabPreviewL4" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabL3EditText.js';
    export class CollabPreviewL4 extends CollabLitElement {
        constructor();
        private elOverlayHover;
        private elOverlaySelected;
        private elMenuOverlay;
        disconnectedCallback(): void;
        render(): any;
        setHover(elId: string, active: boolean): void;
        selectElement(elId: string): void;
        private init;
        private setEventsMouse;
        private createOverlay;
        private createOverlaySelected;
        private observer;
        private _setElement;
        private _setHover;
        private caculetePosSelected;
        private _selectElement;
        private editEl;
    }
}
declare module "_100554_/l2/pluginPageNavigation" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginNavigationRenderOrganism extends PluginBaseModule {
        private msg;
        private atributeBase;
        private elPreviewL4;
        nodes: IInfoElChildren[];
        constructor();
        private domNavigator?;
        private setEvents;
        private onL4EditEvents;
        private onSelect;
        private onNavigation;
        private onlevelChange;
        activeId: string;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        createNavigation(array: IInfoElChildren[]): any;
        renderItemTree(item: IInfoElChildren, idx: string, parentArray?: IInfoElChildren[]): any;
        forceUpdate(): void;
        private openCollabMessage;
        private getActualFileL4;
        private getComponents;
        private getComponents2;
        private selectItem;
        private clickGroupHidden;
        private delEl;
        private goToImprove;
        private dispatchEventGlobalStyle;
        private editEl;
        private onMouseover;
        private onMouseout;
        private setElPreview;
        private slugToTitle;
        private dragItem?;
        private dragParentArray?;
        private dropPosition;
        private dragOverTarget?;
        private onDragStart;
        private onTouchStart;
        private onTouchEnd;
        private findParentArray;
        private onTouchMove;
        private onDragOver;
        private configOverEvent;
        private onDragLeave;
        private onDrop;
        private onDragEnd;
        private isDescendant;
        private prepareHTMLAndSync;
        private goToL2;
    }
    interface IInfoElChildren {
        el: HTMLElement | null;
        elDomNavigator: HTMLElement | null;
        id: string;
        isOrganism: boolean;
        tagName: string;
        children: IInfoElChildren[];
    }
}
declare module "_100554_/l2/pluginPageProperties.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPageProperties" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import { ServiceBase } from "_102027_/l2/serviceBase";
    export class PluginPageProperties extends PluginBaseModule {
        private msg;
        service: ServiceBase | undefined;
        elementAttributes: {
            key: string;
            value: string;
        }[];
        shouldUpdate(changedProperties: Map<string | number | symbol, unknown>): boolean;
        createRenderRoot(): this;
        render(): any;
        createItens(): any;
        renderItem(item: {
            key: string;
            value: string;
        }, idx: string): any;
        forceUpdate(): void;
        private servicePreview;
        private setServicePreview;
        private getMyAttributes;
    }
}
declare module "_100554_/l2/pluginPresenterRecorder.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPresenterRecorder" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginPresenterRecorder extends PluginBaseModule {
        private screenStream;
        private cameraStream;
        private mediaRecorder;
        private chunks;
        private downloadUrl;
        avatarShape: 'square' | 'round';
        avatarZoom: number;
        isRecording: boolean;
        isCountdown: boolean;
        countdownValue: number;
        private countdownTimer?;
        render(): TemplateResult;
        handleZoomChange(e: Event): void;
        updated(): void;
        startRecording(): Promise<void>;
        private _doStartRecording;
        stopRecording(): void;
        saveRecording(): void;
        showPipPreview(): void;
        hidePipPreview(): void;
    }
}
declare module "_100554_/l2/pluginPreviewResultJs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPreviewResultJs" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100554_/l2/pluginPreviewResultTestJs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPreviewResultTestJs" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdTestJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100554_/l2/pluginProjectConfig.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginProjectConfig" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectConfig extends PluginBaseModule {
        static modelCount: number;
        private msg;
        autoPrepare: boolean;
        msize: string;
        c2: HTMLElement | undefined;
        body: HTMLDivElement | undefined;
        private _ed1;
        private model;
        private lastProject;
        private template;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        setEvents(): Promise<void>;
        private _clearChanges;
        private refreshIfNeeded;
        private createEditor;
        private loadProjectConfigs;
        private setInitialConfig;
        private createOrGetModel;
        private timeoutChangesEditorStyle;
        private setEventsModel;
        private onEditorChange;
        private getUri;
    }
}
declare module "_100554_/l2/pluginProjectDeleteFiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginProjectDeleteFiles" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginProjectDeleteFiles extends PluginBaseModule {
        private msg;
        groupName: string;
        filesToDelete: mls.stor.IFileInfo[];
        selectedFiles: Map<string, mls.stor.IFileInfo>;
        logs: string[];
        render(): TemplateResult;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private getFileKey;
        private clear;
        onSearch(): Promise<void>;
        onDelete(): Promise<void>;
        private removeThemeFromDesignSystem;
        private removeModuleFromProjectFile;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginProjectDetail.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginProjectInfo" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectInfo extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        project: number | undefined;
        projectName: string | undefined;
        projectDriver: "local" | "mls" | "GitHub" | "GitLab";
        projectOrg: string | undefined;
        projectOwner: string | undefined;
        projectCreatedAt: string | undefined;
        projectURL: string | undefined;
        projectDescription: string | undefined;
        forks: mls.stor.others.IFork[] | undefined;
        branches: mls.stor.others.IBranch[] | undefined;
        deps: IDependenciesInfo[];
        isSavingDeps: boolean;
        labelOk: string;
        labelError: string;
        labelErrorDeps: string;
        isAddingDep: boolean;
        newDepId: number | null;
        isEditingDeps: boolean;
        originalDeps: IDependenciesInfo[];
        isEditingInfo: boolean;
        isSavingInfo: boolean;
        labelOkInfo: string;
        labelErrorInfo: string;
        editName: string;
        editProjectURL: string;
        editProjectDriver: string;
        editProjectDescription: string;
        body: HTMLDivElement | undefined;
        private projectDetails;
        private projectSettings;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderBody(): TemplateResult;
        renderInfo(): TemplateResult;
        renderInfoViewMode(): TemplateResult;
        renderInfoEditMode(): TemplateResult;
        renderDependencies(): TemplateResult;
        renderDepsViewMode(): TemplateResult;
        renderDepsEditMode(): TemplateResult;
        private startEditingDeps;
        private cancelEditingDeps;
        private startEditingInfo;
        private cancelEditingInfo;
        private handleSaveInfo;
        private saveInfo;
        private moveDepUp;
        private moveDepDown;
        toggleAddDep(): void;
        private addDependency;
        private handleSaveDeps;
        private saveDeps;
        private init;
        private getDependencies;
        private setInfos;
    }
    interface IDependenciesInfo {
        id: number;
        name: string;
        auth: string;
        unknown?: boolean;
    }
}
declare module "_100554_/l2/pluginProjectDetail" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import "/_100554_/l2/pluginProjectInfo.js";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectDetail extends PluginBaseModule {
        contentproject: HTMLElement | undefined;
        contentprojectinfo: HTMLElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        private loadProject;
        static styles: any;
    }
}
declare module "_100554_/l2/pluginProjectFindFiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/utilsLit" {
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
}
declare module "../l2/widgetMindMapL4" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { MindMapSelected, MindMapData, MindMapNodeStyles, MindMapNode } from "_102027_/l2/libMindMap";
    export class WidgetMindMapL4100554 extends StateLitElement {
        private contentHeight;
        private offsetY;
        private isListMode;
        private LIST_THRESHOLD;
        private _canvasDirtyWhileHidden;
        menuOpen: boolean;
        activeDescription: string | undefined;
        currentpage: string | undefined;
        showbreadcrumb: string | undefined;
        mindMapSelected: MindMapSelected | undefined;
        mapState: MindMapData | undefined;
        nodeRadius: number;
        nodeStyles: MindMapNodeStyles;
        initialNode: string | undefined;
        breadcrumb: MindMapNode[];
        private _nodePositions;
        private _animationDelay;
        private get visibleBreadcrumb();
        render(): any;
        renderBreadcrumb(): any;
        renderMenu(): any;
        firstUpdated(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private configureMindMap;
        private _redrawCanvas;
        private _addCanvasListeners;
        private _removeCanvasListeners;
        private _animating;
        private _animatedPositions?;
        private _onCanvasClick;
        private getNodeStyle;
        /**
         * Returns the node id under the given mouse position, or undefined if none.
         */
        private getNodeIdAtPosition;
        private getRelatedNodes;
        private _hoveredNodeId?;
        private handleCanvasMouseMove;
        private toWorldCoords;
        private computeAutoZoom;
        private zoom;
        private MIN_ZOOM;
        private MAX_ZOOM;
        private drawMindMap;
        private _onWheel;
        private drawListLayout;
        private drawLabel;
        private drawIconButton;
        private openDefs;
        private _toggleMenu;
        private fromMenu;
        private _openScenario;
        private _closeDescription;
        private _brightenColor;
        /**
     * Returns a map { nodeId: {x, y} } for each node,
     * given a center nodeId and its related nodes.
     */
        private getNodePositions;
        /**
         * Returns an array of { id, from, to } for all nodes appearing in either state.
         * - from: start position (or undefined if node is new)
         * - to:   end position (or undefined if node disappears)
         */
        private prepareAnimationMap;
        /**
         * Animates all nodes from their 'from' position to 'to' in 500ms.
         * Calls a callback on each frame with current positions.
         */
        private animateTransition;
        private onSelected;
        private _pushBreadcrumb;
        private _syncBreadcrumbWithCurrent;
        private _popToBreadcrumb;
        private openFileAndNavigate;
        private _navigateInsideCurrentFile;
        private openFile;
        private pluginsMenu;
    }
}
declare module "_100554_/l2/pluginProjectFindFiles" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { MindMapData } from "_102027_/l2/libMindMap";
    import '/_100554_/l2/widgetMindMapL4.js';
    export class PluginProjectFindFiles extends PluginBaseModule {
        private msg;
        private matchedFiles;
        private usingRegex;
        private progressValue;
        mode: 'list' | 'map';
        dataJson: MindMapData | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        renderList(): any;
        renderMap(): any;
        onSearch(): Promise<void>;
        searchFiles(files: string[], searchText: string): Promise<void>;
        changeMode(e: MouseEvent): void;
        configMode(): void;
        openFile(e: MouseEvent): void;
        fireEvents(action: string, file: mls.stor.IFileInfo, timeout?: number): Promise<void>;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginProjectIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginProjectIndex" {
    import { PluginBaseIndex } from '_100554_/l2/pluginBaseIndex';
    export class PluginProjectIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_5: PluginProjectIndex;
    export default _default_5;
}
declare module "_100554_/l2/pluginProjectInfo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginProjectInfo" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectInfo extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        project: number | undefined;
        projectName: string | undefined;
        projectDriver: "local" | "mls" | "GitHub" | "GitLab";
        projectOrg: string | undefined;
        projectOwner: string | undefined;
        projectCreatedAt: string | undefined;
        projectURL: string | undefined;
        projectDescription: string | undefined;
        forks: mls.stor.others.IFork[] | undefined;
        branches: mls.stor.others.IBranch[] | undefined;
        deps: IDependenciesInfo[];
        isSavingDeps: boolean;
        labelOk: string;
        labelError: string;
        labelErrorDeps: string;
        isAddingDep: boolean;
        newDepId: number | null;
        isEditingDeps: boolean;
        originalDeps: IDependenciesInfo[];
        isEditingInfo: boolean;
        isSavingInfo: boolean;
        labelOkInfo: string;
        labelErrorInfo: string;
        editName: string;
        editProjectURL: string;
        editProjectDriver: string;
        editProjectDescription: string;
        body: HTMLDivElement | undefined;
        private projectDetails;
        private projectSettings;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderBody(): TemplateResult;
        renderInfo(): TemplateResult;
        renderInfoViewMode(): TemplateResult;
        renderInfoEditMode(): TemplateResult;
        renderDependencies(): TemplateResult;
        renderDepsViewMode(): TemplateResult;
        renderDepsEditMode(): TemplateResult;
        private startEditingDeps;
        private cancelEditingDeps;
        private startEditingInfo;
        private cancelEditingInfo;
        private handleSaveInfo;
        private saveInfo;
        private moveDepUp;
        private moveDepDown;
        toggleAddDep(): void;
        private addDependency;
        private handleSaveDeps;
        private saveDeps;
        private init;
        private getDependencies;
        private setInfos;
    }
    interface IDependenciesInfo {
        id: number;
        name: string;
        auth: string;
        unknown?: boolean;
    }
}
declare module "_100554_/l2/pluginProjectReadMe.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabEditMd" {
    import { LitElement } from 'lit';
    export function initEditorQuillMD(): boolean;
    export class CollabEditMd extends LitElement {
        private value;
        private opened;
        containerEditor: HTMLElement | undefined;
        containerQuillEditor: HTMLTextAreaElement | undefined;
        iconFinish: HTMLElement | undefined;
        iconEdit: HTMLElement | undefined;
        set cbFinishEdit(fc: Function);
        get text(): any;
        firstUpdated(changedProperties: any): void;
        private cbFinishFc;
        private openedToolbar;
        id: string;
        easyMDE: any;
        editor: any;
        private initEditor;
        private onOpenedChanged;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private _initEditor;
        private onEditClick;
        private onFinishClick;
        render(): any;
        static styles: any;
    }
}
declare module "_100554_/l2/pluginProjectReadMe" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { CollabEditMd } from '_100554_/l2/collabEditMd';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectReadMe extends PluginBaseModule {
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        mkEditor: CollabEditMd | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderReadme;
        private setReadme;
        private onChangeMd;
        private createFile;
        _getValueInfo(file: mls.stor.IFileInfo, originalShortName?: string, originalFolder?: string, originalProject?: number, originalCRC?: string): Promise<mls.stor.IFileInfoValue>;
        static styles: any;
    }
}
declare module "_100554_/l2/pluginProjectRunTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabPageElement" {
    import { PropertyValueMap, LitElement } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export const PREFIX_ICA_ID = "ica_";
    export function toPascalCase(str: string): string;
    export abstract class CollabPageElement extends StateLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        initPageComplete: boolean;
        level: string;
        overlay: any | undefined;
        isPage: boolean;
        recreateOverlay(): void;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        private setupIds;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
    }
    export interface LitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        baseName: string;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
    }
    interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | 'p-title-top' | '';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
}
declare module "../l2/collabResultTest" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabConsole100554 extends StateLitElement {
        testName: string;
        status: 'pending' | 'running' | 'finished';
        resultStatus: 'pass' | 'failed';
        result: string;
        timeResult: number;
        timeStart: number;
        timeEnd: number;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private renderRunning;
        private renderFinished;
        render(): any;
    }
}
declare module "_100554_/l2/pluginProjectRunTest" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import '/_100554_/l2/collabResultTest.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectRunTest extends PluginBaseModule {
        private msg;
        collabResultContainer: HTMLElement | undefined;
        progress: number;
        totalTest: number;
        totalTestPass: number;
        totalTestFailed: number;
        startTime: number;
        endTime: number;
        actualAllPagesTests: number;
        filesWithTest: string[];
        render(): TemplateResult;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private init;
        private exec;
        private clear;
        private countTotalTests;
        private calcProgress;
        private createModelsIfNeeded;
        private getTestsByFile;
        private getStorFilesWithTest;
        private addTestResultItem;
        private createPageContainer;
        private runTest;
        private delay;
        private runAllTests;
        private createResume;
        private createResumeFinal;
        private waitForPreviewLoaded;
        private waitForLitComponentsInIframe;
        private fireEvents;
        private onFinishTest;
    }
}
declare module "_100554_/l2/pluginProjectUsage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginProjectUsage" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectUsage extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        designSystems: number | undefined;
        projectLastModified: string | undefined;
        files: number | undefined;
        chartData: {};
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderResume;
        static styles: any;
    }
}
declare module "_100554_/l2/pluginPullrequest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPullrequest" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginPullrequest extends PluginBaseModule {
        private msg;
        private itens;
        private owner;
        private repo;
        private branch;
        error: string;
        autoPrepare: boolean;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderHeader(): any;
        renderNoItens(): any;
        renderListPull(): any;
        renderItemListPull(i: mls.stor.others.IPullRequest, index: number): any;
        prepare(): Promise<void>;
        loadListPullRequest(): Promise<void>;
        initInfoProject(): Promise<void>;
    }
}
declare module "_100554_/l2/pluginQuestionArchitecture" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginQuestionArchitecture extends PluginBaseModule {
        private msg;
        private question;
        private loading;
        private result?;
        private error;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        private askAgent;
        private _callAgent;
        private findFlexibleNodes;
        private openFile;
        fireEvents(action: string, file: mls.stor.IFileInfo, timeout?: number): Promise<void>;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginSiteMonitorDashboardActiveUsers.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/widgetCollabChart" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WcEchartsPie100554 extends StateLitElement {
        data: any | undefined;
        chartTitle: string;
        framework: 'echarts';
        renderer: 'canvas' | 'svg';
        main: HTMLDivElement | undefined;
        private myChart;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        initChart(): void;
        firstUpdated(): void;
        render(): any;
    }
}
declare module "_100554_/l2/pluginSiteMonitorDashboardActiveUsers" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_/l2/pluginSiteMonitorDashboardErrors.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorDashboardErrors" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_/l2/pluginSiteMonitorDashboardExpenses.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorDashboardExpenses" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_/l2/pluginSiteMonitorDashboardRegionalLatency.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorDashboardRegionalLatency" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_/l2/pluginSiteMonitorDashboardResponseTime.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorDashboardResponseTime" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_/l2/pluginSiteMonitorDashboardSales.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorDashboardSales" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_/l2/pluginSiteMonitorDashboardSpikes.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorDashboardSpikes" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_/l2/pluginSiteMonitorIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorIndex" {
    import { PluginBaseIndex } from '_100554_/l2/pluginBaseIndex';
    export class PluginSiteMonitorIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_6: PluginSiteMonitorIndex;
    export default _default_6;
}
declare module "_100554_/l2/pluginStyleBackground.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabDsInputSelectColor" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export function initCollabDsInputSelectColor(): void;
    export class CollabDsInputSelectColor extends CollabLitElement {
        get value(): string;
        set value(str: string);
        get valueInput(): string;
        set valueInput(str: string);
        get valueSelect(): string;
        set valueSelect(str: string);
        get valueColor(): string;
        set valueColor(str: string);
        arrayInputSelect: string[];
        arraySelect: string[];
        _valueInput: string;
        _valueSelect: string;
        _valueColor: string;
        prop: string;
        useInput: string;
        useSelect: string;
        useColor: string;
        render(): any;
        renderInput(): any;
        renderSelect(): any;
        renderColor(): any;
        updated(): void;
        private configGetValue;
        private configSetValue;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private allChange;
        private fireEvents;
    }
}
declare module "../l2/collabDsInputRange" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export function initCollabDSInputRange(): void;
    export class CollabDSInputRange extends StateLitElement {
        arraySelect: string[];
        useSelect: string;
        value: string;
        valueInput: string;
        prop: string;
        min: number;
        max: number;
        render(): any;
        renderSelect(): any;
        updated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private cursorPosition;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private changeSelect;
        private allChange;
        private fireEvents;
    }
}
declare module "_100554_/l2/pluginStyleBackground" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginCssTokens extends StateLitElement {
        private msg;
        showFull: string;
        position: 'left' | 'right';
        info: IMyInfoBackground;
        css: string;
        state: ICSSState | undefined;
        private actualKey;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private setValues;
        private findCSSRuleInIframe;
        render(): any;
        renderBody2(): any;
        renderBody(): any;
        renderConfig(): any;
        renderAux(): any;
        renderItens(): any;
        renderGallery(): any;
        private clickGallery;
        private onlyNumber;
        private changeType;
        private add;
        private del;
        private configString;
        private rgbaToHex;
        private hexToRgba;
        private changeStr;
        private timeonChangeProp;
        private onChangeProp;
        private onChangeAux;
        private changeValues;
        private mountMyValue;
        private setState;
        private arrayGallery;
    }
    interface IMyInfoBackground {
        tp: string;
        aux: string;
        itens: {
            value: string;
            transp: string;
            stop: string;
        }[];
    }
}
declare module "_100554_/l2/pluginStyleBorder.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleBorder" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { CollabDsInputSelectColor } from '_100554_/l2/collabDsInputSelectColor';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleBorder extends StateLitElement {
        private msg;
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        borderLocked: boolean;
        borderRadiusLocked: boolean;
        borderLeft: string | undefined;
        borderRight: string | undefined;
        borderTop: string | undefined;
        borderBottom: string | undefined;
        borderLeftWidth: string | undefined;
        borderRightWidth: string | undefined;
        borderTopWidth: string | undefined;
        borderBottomWidth: string | undefined;
        borderLeftStyle: string | undefined;
        borderRightStyle: string | undefined;
        borderTopStyle: string | undefined;
        borderBottomStyle: string | undefined;
        borderLeftColor: string | undefined;
        borderRightColor: string | undefined;
        borderTopColor: string | undefined;
        borderBottomColor: string | undefined;
        borderTopLeftRadius: string | undefined;
        borderTopRightRadius: string | undefined;
        borderBottomLeftRadius: string | undefined;
        borderBottomRightRadius: string | undefined;
        inputLockRadius: HTMLInputElement | undefined;
        inputLock: HTMLInputElement | undefined;
        borderInputs: CollabDsInputSelectColor[] | undefined;
        borderRadiusInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        private tpBorder;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderBorder(): any;
        renderBorderRadius(): any;
        renderBorderGallery(): any;
        private timeonChangeBorder;
        private handleChangeBorder;
        private timeonChangeBorderRadius;
        private handleChangeBorderRadius;
        private handleChangeLockBorderRadius;
        private handleChangeLockBorder;
        private _onIcaStateChange;
        private setBorderValues;
        private setState;
        private updateBorderRadius;
        private updateBorder;
        private setValues;
        private checkBorderEquals;
        private checkBorderRadiusEquals;
        private replaceTokens;
        private findCSSRuleInIframe;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginStyleBoxShadow.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleBoxShadow" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleBoxShadow extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        boxShadow: string | undefined;
        color: string | undefined;
        spread: string | undefined;
        boxBlur: string | undefined;
        offsetY: string | undefined;
        offsetX: string | undefined;
        shadowMode: 'inset' | 'outset';
        private tpMeasures;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues2;
        private setValues;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        render(): any;
        renderBoxShadow(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginStyleClippath.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleClippath" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleClipath extends StateLitElement {
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        clipPath: string | undefined;
        svgOverlay: HTMLElement | undefined;
        output: HTMLTextAreaElement | undefined;
        image: HTMLImageElement | undefined;
        pointsContainer: HTMLDivElement | undefined;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues;
        render(): any;
        renderGallery(): any;
        renderPreviewEditable(): any;
        private points;
        private parameters;
        private currentTemplate;
        private shapeType;
        private outputRes;
        private renderClipPath;
        private applyChanges;
        private timeonChange;
        private handleChangeCss;
        private setState;
        private initClipPathMaker;
        private setParameters;
        private identifyShapeType;
        private arrayGallery;
    }
}
declare module "_100554_/l2/pluginStyleColumn.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleColumn" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { CollabDsInputSelectColor } from '_100554_/l2/collabDsInputSelectColor';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleColumn extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        columnCount: string | undefined;
        columnWidth: string | undefined;
        columnGap: string | undefined;
        columnSpan: string | undefined;
        columnRule: string | undefined;
        columnRuleColor: string | undefined;
        columnRuleStyle: string | undefined;
        columnRuleWidth: string | undefined;
        breakInside: string | undefined;
        columnRuleInputs: CollabDsInputSelectColor[] | undefined;
        private msg;
        private tpMeasures;
        private tpBorder;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private setValues;
        private findCSSRuleInIframe;
        private setColumnRuleValues;
        private setState;
        private timeonChange;
        private handleChange;
        render(): any;
        renderColumn(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginStyleCursor.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleCursor" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleClipath extends StateLitElement {
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        render(): any;
        renderGallery(): any;
        private timeonChange;
        private handleChangeCss;
        private setState;
        private arrayGallery;
    }
}
declare module "_100554_/l2/pluginStyleFilter.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleFilter" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleFilter extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        filter: string | undefined;
        grayscale: string | undefined;
        filterBlur: string | undefined;
        sepia: string | undefined;
        saturate: string | undefined;
        opacity: string | undefined;
        brightness: string | undefined;
        contrast: string | undefined;
        huerotate: string | undefined;
        invert: string | undefined;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues;
        private setValues2;
        render(): any;
        renderFilter(): any;
        renderGallery(): any;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginStyleFlex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleFlex" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleFlex extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderFlex(): any;
        renderFlexItem(): any;
        renderGallery(): any;
        private _onIcaStateChange;
        private setValues;
        private timeonChange;
        private handleChangeCss;
        private handleChangeGalleryCss;
        private setState;
        private arrayGallery;
    }
}
declare module "_100554_/l2/pluginStyleIndexItem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleIndexItem" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { IHelpers } from '_100554_/l2/cssHelperIndexBase';
    export class PluginStyleIndexItem extends CollabLitElement {
        help: IHelpers | undefined;
        position: 'left' | 'right';
        mode: 'collapsed' | 'expanded' | 'full';
        pluginLoaded: boolean;
        firstUpdated(): void;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private pluginEl;
        private openPlugin;
        handleOpenPlugin(e: MouseEvent, help: IHelpers, close?: boolean): Promise<void>;
        handleExpandedClick(e: MouseEvent): Promise<void>;
        handleFullClick(e: MouseEvent): void;
        handleLikeClick(e: MouseEvent): Promise<void>;
        handleInfoClick(e: MouseEvent): Promise<void>;
    }
}
declare module "_100554_/l2/pluginStyleMargin.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleMargin" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleSpacing extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        marginLocked: boolean;
        marginLeft: string | undefined;
        marginRight: string | undefined;
        marginTop: string | undefined;
        marginBottom: string | undefined;
        inputLockM: HTMLInputElement | undefined;
        marginInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderMargin(): any;
        renderGallery(): any;
        private _onIcaStateChange;
        private timeonChangeMargin;
        private handleChangeMargin;
        private handleChangeLockMargin;
        private setState;
        updateMargins(margin: string | {
            [key: string]: string;
        }): void;
        private setValues;
        private checkMarginsEquals;
        private findCSSRuleInIframe;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginStylePadding.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStylePadding" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStylePadding extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        paddingLocked: boolean;
        paddingLeft: string | undefined;
        paddingRight: string | undefined;
        paddingTop: string | undefined;
        paddingBottom: string | undefined;
        inputLockP: HTMLInputElement | undefined;
        paddingInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        render(): any;
        renderPadding(): any;
        renderGallery(): any;
        private _onIcaStateChange;
        private timeonChangePadding;
        private handleChangePadding;
        private handleChangeLockPadding;
        private setState;
        updatePadding(padding: string | {
            [key: string]: string;
        }): void;
        private setValues;
        private checkPaddingEquals;
        private findCSSRuleInIframe;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginStyleTextShadow.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleTextShadow" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleTextShadow extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        textShadow: string | undefined;
        offSetX: string | undefined;
        offSetY: string | undefined;
        textBlur: string | undefined;
        color: string | undefined;
        private msg;
        private tpMeasures;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues;
        private setValues2;
        private arrayGallery;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        render(): any;
        renderColumn(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginStyleTokens.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleTokens" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginCssTokens extends StateLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        level: number;
        prop: string;
        value: string;
        theme: string;
        tokens: Record<string, Record<string, Record<string, string>>>;
        private needOrder;
        private getTokensColor;
        private groupColorsByState;
        handleColorClick(key: string, value: string): void;
        setTooltip(): void;
        getTokens(): Promise<void>;
        updated(changedProperties: any): void;
        firstUpdated(a: any): Promise<void>;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        render(): any;
    }
}
declare module "_100554_/l2/pluginStyleTransform.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginStyleTransform" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { ICSSState } from '_100554_/l2/lessCSS';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    import '/_100554_/l2/collabDsInputSelectColor.js';
    import '/_100554_/l2/collabDsInputRange.js';
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleTransform extends StateLitElement {
        showFull: string;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        transform: string | undefined;
        scaleX: string | undefined;
        scaleY: string | undefined;
        rotate: string | undefined;
        translateX: string | undefined;
        translateY: string | undefined;
        skewX: string | undefined;
        skewY: string | undefined;
        columnRuleInputs: HTMLInputElement[] | undefined;
        private msg;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        private clear;
        private _onIcaStateChange;
        private findCSSRuleInIframe;
        private setValues2;
        private setValues;
        private mountValue;
        private setState;
        private timeonChangeProp;
        private handleChange;
        render(): any;
        renderTransform(): any;
        renderGallery(): any;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_/l2/pluginSystemLanguage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSystemLanguage" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSystemLanguage100554 extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        actualLanguage: ILanguage;
        selectLanguage: HTMLSelectElement | undefined;
        firstUpdated(): void;
        prepare(): Promise<void>;
        private init;
        render(): TemplateResult;
        private getUserLanguage;
        private handleChangeLanguageClick;
        private setUserLanguage;
        private getUserDefault;
        private getNavigatorLanguage;
    }
    type ILanguage = 'pt-BR' | 'en-US' | 'default';
}
declare module "_100554_/l2/pluginSystemTheme.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSystemTheme" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSystemTheme100554 extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        actualTheme: string;
        selectTheme: HTMLSelectElement | undefined;
        firstUpdated(): void;
        prepare(): Promise<void>;
        private init;
        render(): TemplateResult;
        private handleChangeThemeClick;
        private getUserSettings;
        private setUserTheme;
        private getUserTheme;
        private getUserThemeOS;
    }
}
declare module "_100554_/l2/pluginSystemUser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSystemUser" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSystemLanguage100554 extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        consoleEnabled: boolean;
        inputConsole: HTMLInputElement | undefined;
        firstUpdated(): void;
        prepare(): Promise<void>;
        private init;
        private onChangeConsoleEnabled;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/pluginVerifyError.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabInit" {
    import { LitElement } from 'lit';
    export function initCompileMonaco(project: number): Promise<boolean>;
    export class CollabInit extends LitElement {
        private actualProject;
        /**
         * Indicates if the user is anonymous based on the cookie loginUser
         * @returns `true` if the user is anonymous; otherwise, `false`.
         */
        get isAnonymous(): boolean;
        /**
         * Retrieves the avatar URL from the `avatarUrl` attribute.
         * @returns The URL of the avatar, or an empty string if not defined.
         */
        get avatarUrl(): string;
        /**
         * Retrieves the base Project from the `baseProject` attribute.
         * @returns The URL of the avatar, or an empty string if not defined.
         */
        get baseProject(): number;
        /**
         * Lit lifecycle method called after the component is first updated.
         * Initializes the component's configuration.
         */
        firstUpdated(): void;
        render(): any;
        /**
         * Initializes the system life cycle.
         * To show logs using: https://collab.codes/?traceLifeCycle=true
         */
        private init;
        private setEventsModel;
        private setEvents;
        private onLevelChanged;
        private firstAccessLevels;
        private levelHandlers;
        private onLevelChangedToL2;
        /**
         * Loads and sets up collaboration drivers asynchronously.
         */
        private setDrivers;
        /**
         * Instantiates and registers the GitHub collaboration driver asynchronously.
         */
        private instanceDriverGitHub;
        /**
         * Instantiates and registers the GitLab collaboration driver asynchronously.
         */
        private instanceDriverGitLab;
        /**
         * Sets the base URL for the project and retrieves the user's language.
         * @returns The user's language (e.g., 'en-US', 'pt-BR').
         */
        private setAndGetBaseUrl;
        /**
         * Retrieves the user's preferred language or defaults to 'en-US'.
         * @returns The user's language.
         */
        private getUserLanguageOrDefault;
        /**
         * Retrieves the browser's language setting.
         * @returns The browser's language.
         */
        private getNavigatorLanguage;
        /**
         * Sets the `lang` attribute of the HTML `<html>` element.
         * @param lang The language code to set (e.g., 'en-US').
         */
        private setHTMLLang;
        private initCoachMark;
        /**
         * Sets the theme for the application based on user settings or OS preferences.
         */
        private setTheme;
        /**
         * Retrieves the theme from user settings or defaults to the OS preference.
         * @returns The theme ('dark' or 'light').
         */
        private getTheme;
        /**
         * Retrieves the user's OS theme preference.
         * @returns The OS theme preference ('dark' or 'light').
         */
        private getUserThemeOS;
        /**
         * Sets CSS tokens for light and dark themes by retrieving data from a cache.
         */
        private setTokensCss;
        /**
         * Configures navigation settings, including avatar and status, for the collaboration interface.
         * @param avatarUrl The URL of the avatar.
         * @param language The user's language.
         * @param isAnonymous Indicates whether the user is anonymous.
         */
        private enableNav;
        private flags;
        /**
         * Retrieves the last selected project ID from localStorage.
         * @returns The last selected project ID as a number, or `undefined` if not found.
         */
        private getLastProjectSelected;
        /**
         * Sets the actual project in the `mls` structure based on the last selected project.
         * @returns The last selected project ID as a number, or `undefined` if not found.
         */
        private setProjectActual;
        /**
         * Sets the current organization in the `mls` structure based on the provided project ID.
         * @param project The project ID to determine the organization index.
         */
        private setOrgActual;
        /**
         * Asynchronously loads the base project information if it is not already loaded.
         * Utilizes the `mls.stor.server.loadProjectInfoIfNeeded` method with the base project ID.
         * @returns A promise that resolves when the base project information is loaded.
         */
        private loadProjectBase;
        /**
         * Loads the information of the last accessed project if it exists.
         * If the `actualProject` is defined, it attempts to load the project's information
         * from the server using the `loadProjectInfoIfNeeded` method.
         *
         * Optionally logs the lifecycle trace if the global `traceLifeCycle` is enabled.
         *
         * @returns A promise that resolves when the project information has been loaded.
         */
        private loadLastProject;
        private setLastOpenedFiles;
        private FILEL6;
        private FILEL5;
        private setDefaultFiles;
        private restoreSideFile;
        private getPath;
        private setLastModule;
        /**
         * Checks for the presence of a `<collab-sticky-notification>` element on the page.
         * If found, it invokes the `show()` method on the element to display notifications.
         */
        private showMessagesIfNeeded;
        private anonymousServices;
        /**
         * Retrieves a list of services for the current project, either for anonymous users or regular users.
         * If the user is anonymous, it returns the `anonymousServices`. Otherwise, it loads project-specific
         * services by fetching and sorting the available menu actions for different levels and positions (Left/Right).
         *
         * @returns A promise that resolves to an object containing an array of services, sorted by priority.
         * The services are categorized by levels and positions (Left/Right) and are returned as a semicolon-separated
         * string for each level.
         */
        private getServices;
    }
}
declare module "_100554_/l2/pluginVerifyError" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginVerifyError extends PluginBaseModule {
        private msg;
        private continueVerify;
        find: string[];
        current: string;
        tot: string;
        error: string;
        autoPrepare: boolean;
        isLoad: boolean;
        listErrors: string[];
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderLoad(): any;
        renderHeader(): any;
        renderErros(): any;
        renderItem(i: string): any;
        prepare(): Promise<void>;
        private setFilesErros;
        private cancelVerify;
        private progressCallback;
        private fireEvent;
    }
}
declare module "_100554_/l2/pluginVerifyErrorDesignSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginVerifyErrorDesignSystem" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginVerifyErrorDesignSystem extends PluginBaseModule {
        private msg;
        private continueVerify;
        find: string[];
        current: string;
        tot: string;
        error: string;
        autoPrepare: boolean;
        isLoad: boolean;
        listErrors: string[];
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderLoad(): any;
        renderHeader(): any;
        renderErros(): any;
        renderItem(i: string): any;
        prepare(): Promise<void>;
        private compileAll;
        private setFilesErros;
        private cancelVerify;
        private progressCallback;
        private fireEvent;
    }
}
declare module "_100554_/l2/pluginViewFile" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import "_102027_/l2/collabMonacoEditor";
    export class PluginViewFile extends PluginBaseModule {
        private msg;
        nameFile: string;
        current: number;
        file: mls.stor.IFileInfo | undefined;
        contentText: string;
        contentUrl: string;
        extension: string;
        msize: string;
        private editor;
        elEditor: IHTMLEditorElement | undefined;
        private _ed1;
        get confE(): string;
        firstUpdated(): void;
        updated(changedProps: Map<string, any>): void;
        private updateEditorContent;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderViewMode(): TemplateResult;
        renderInfoMode(): TemplateResult;
        private createModel;
        private createEditor;
        private init;
        private isImage;
        private isAudio;
        private isVideo;
        private isReadableText;
        private conf;
    }
    export const pluginData: mls.plugin.IPluginData;
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100554_/l2/pluginViewMindMap" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import { MindMapData } from "_102027_/l2/libMindMap";
    import '/_100554_/l2/widgetMindMapL4.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginViewMindMap extends PluginBaseModule {
        autoPrepare: boolean;
        page: string;
        initialNode: string | undefined;
        dataJson: MindMapData | undefined;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        prepare(): Promise<void>;
        private init;
        private getJson;
    }
}
declare module "_100554_/l2/previewModeMinimum.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewModeMinimum" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export class PreviewModeMinimum {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        private mountJS;
    }
}
declare module "_100554_/l2/previewModeSinglePage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewModeSinglePage" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export class PreviewModeSinglePage {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        private esbuild;
        private needAwait;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        buildJS(other: string[]): Promise<any>;
        private configIframe;
        private _buildJS;
        private parseImportsMap;
        private findWidgets;
        private loadEsbuild;
        private initializeEsBuild;
        private loadCache;
    }
}
declare module "_100554_/l2/previewModeUtil.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewModeUtil" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export function mountJSImporMap(info: IJSONDependence, ifr: HTMLIFrameElement): void;
    export function mountCSS(ifr: HTMLIFrameElement): void;
    export function mountLinks(info: IJSONDependence, ifr: HTMLIFrameElement): void;
    export function mountTokens(tokens: string, file: mls.stor.IFileInfo): void;
    export function removeOlderTokens(ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): void;
    export function getIdTokens(file: mls.stor.IFileInfo): string;
    export function simulateService(info: IJSONDependence, ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): Promise<void>;
    export function addFA(ifr: HTMLIFrameElement): void;
    export function addTooltip(ifr: HTMLIFrameElement): void;
    export function addStyleMls(ifr: HTMLIFrameElement): void;
    export function addNav3(ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): void;
    export function waitForComponents(context: Window, componentNames: string[]): Promise<CustomElementConstructor[]>;
    export function addJsReference(ifr: HTMLIFrameElement, level: string): void;
}
declare module "_100554_/l2/previewState.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewState" {
    global {
        interface Window {
            preview: {
                editor: monaco.editor.IStandaloneCodeEditor | undefined;
                iframe: HTMLIFrameElement | undefined;
            };
        }
    }
}
declare module "_100554_/l2/project.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_100554_/l2/projectAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/projectAST" {
    export function addModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message?: undefined;
    } | {
        ok: boolean;
        message: string;
    }>;
    export function configureMasterFrontEnd(project: number, start: string, build: string, liveView: string): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
    export function removeModule(project: number, moduleName: string, forceCreateModel?: boolean): Promise<{
        ok: boolean;
        message: string;
    } | {
        ok: boolean;
        message?: undefined;
    }>;
}
declare module "_100554_/l2/projects.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginCreateProject" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class PluginCreateProject extends CollabLitElement {
        private msg;
        currentScenario: IScenaries;
        projectName: string;
        projectType: 'blank' | 'prompt';
        projectPrompt: string;
        selectedProjectTypeId: string;
        errorName: string;
        errorPrompt: string;
        alreadyHasProjectLocal: boolean;
        isLoading: boolean;
        projectCreatedSucessfully: boolean;
        private projectNumber;
        private get selectedProjectType();
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private renderScenario;
        private renderSelect;
        private renderProjectCreatedOk;
        private handleCancel;
        private handleProjectTypeChange;
        private validateForm;
        private handleCreate;
        private setProjectActual;
        private createFiles;
        private createInitialProject;
        private createInitialConfigL5File;
        private createInitialDSFile;
        private createNewFileL2;
    }
    type IScenaries = 'select';
}
declare module "_100554_/l2/projects" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_100554_/l2/pluginCreateProject.js';
    export class Projects102009 extends StateLitElement {
        currentView: 'list' | 'details' | 'add';
        archiveConfirmationText: string;
        selectedProjectDetails: IMyProject | undefined;
        selectedProject: IMyProject | undefined;
        comunityProjects: IMyProject[];
        myProjects: IMyProject[];
        firstUpdated(): void;
        render(): any;
        renderHeader(): any;
        renderProjectList(): any;
        renderCurrentProject(): any;
        renderListUser(): any;
        renderListComunity(): any;
        renderProjectDetails_old(): any;
        renderProjectDetails(): any;
        renderAdd(): any;
        private backScenaryList;
        private onAddNewProjectClick;
        private timeFilterChange;
        private filterLiChange;
        private getOrgsAndProjects;
        private createPrjLocalItem;
        private openDetails;
        private goBack;
        private confirmArchive;
        private onProjectClick;
        private setProjectActual;
        private setOrgActual;
        private mockProjects;
    }
    interface IMyProject {
        title: string;
        type: string;
        remixes: number;
        thumbnail: string;
        project: number;
    }
}
declare module "_100554_/l2/saveAddBranch.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/saveAddBranch" {
    import { LitElement } from 'lit';
    export const initServiceSaveaddBranch: () => void;
    export class ServiceSaveAddBRanch extends LitElement {
        hint: string | undefined;
        callBack: Function | undefined;
        private owner;
        private repo;
        private branch;
        private branchMain;
        private listForks;
        private error;
        private driver;
        private mode;
        connectedCallback(): void;
        render(): any;
        renderModeList(): any;
        renderModeAdd(): any;
        renderBranchs(): any;
        renderForks(): any;
        renderItem(obj: {
            name: string;
        }, index: number): any;
        renderItemFork(obj: mls.stor.others.IFork, index: number): any;
        private init;
        private cancel;
        private addClick;
        private addBranch;
        private addNewBranch;
        private getInfosRepo;
        private setItem;
        private setItemFork;
        static styles: any;
    }
}
declare module "_100554_/l2/serviceBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceBase" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_100554_/l2/serviceCollabFileSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabFileSystemAccess" {
    type CollabFsPermissionMode = 'read' | 'readwrite';
    type CollabFsPermissionDescriptor = {
        mode: CollabFsPermissionMode;
    };
    type CollabFsWritable = {
        write(data: string | Blob | BufferSource): Promise<void>;
        close(): Promise<void>;
    };
    export type CollabFsFileHandle = {
        kind: 'file';
        name: string;
        getFile(): Promise<File>;
        createWritable(): Promise<CollabFsWritable>;
    };
    export type CollabFsDirectoryHandle = {
        kind: 'directory';
        name: string;
        entries(): AsyncIterableIterator<[string, CollabFsDirectoryHandle | CollabFsFileHandle]>;
        getDirectoryHandle(name: string, options?: {
            create?: boolean;
        }): Promise<CollabFsDirectoryHandle>;
        getFileHandle(name: string, options?: {
            create?: boolean;
        }): Promise<CollabFsFileHandle>;
        removeEntry(name: string, options?: {
            recursive?: boolean;
        }): Promise<void>;
        queryPermission?(descriptor: CollabFsPermissionDescriptor): Promise<PermissionState>;
        requestPermission?(descriptor: CollabFsPermissionDescriptor): Promise<PermissionState>;
    };
    global {
        interface Window {
            showDirectoryPicker?: (options?: {
                mode?: CollabFsPermissionMode;
            }) => Promise<CollabFsDirectoryHandle>;
        }
    }
    export interface CollabFsLocalFile {
        path: string;
        content?: string | Blob;
        size: number;
        lastModified: number;
    }
    export interface CollabFsAccessProgress {
        current: number;
        path: string;
    }
    export interface CollabFsListOptions {
        readContent?: boolean;
    }
    export interface CollabFsAccessAdapter {
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
    }
    export class FileSystemAccessAdapter implements CollabFsAccessAdapter {
        isSupported(): boolean;
        showDirectoryPicker(): Promise<CollabFsDirectoryHandle>;
        ensurePermission(handle: CollabFsDirectoryHandle, mode?: CollabFsPermissionMode): Promise<boolean>;
        saveHandle(project: number, handle: CollabFsDirectoryHandle): Promise<void>;
        saveBaseHandle(handle: CollabFsDirectoryHandle): Promise<void>;
        getBaseHandle(): Promise<CollabFsDirectoryHandle | null>;
        removeHandle(project: number): Promise<void>;
        getHandle(project: number): Promise<CollabFsDirectoryHandle | null>;
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
        walkTextFiles(directory: CollabFsDirectoryHandle, prefix: string, files: CollabFsLocalFile[], onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<void>;
        getFileHandleByPath(directory: CollabFsDirectoryHandle, path: string, create: boolean): Promise<CollabFsFileHandle | null>;
        assertSafePath(path: string): void;
        shouldIgnoreDirectory(name: string): boolean;
        shouldIgnoreFile(path: string): boolean;
        shouldReadAsText(path: string): boolean;
        getProjectKey(project: number): string;
        openDB(): Promise<IDBDatabase>;
        requestToPromise<T>(request: IDBRequest<T>): Promise<T>;
        transactionDone(tx: IDBTransaction): Promise<void>;
    }
}
declare module "../l2/collabFileSystemSync" {
    export type CollabFsChangeKind = 'browserOnly' | 'localOnly' | 'modified' | 'unsupported' | 'browserModified' | 'diskModified' | 'bothModified' | 'diskOnly' | 'diskDeleted' | 'browserDeleted';
    interface CollabFsFileHandleLike {
        kind: 'file';
        name: string;
        getFile(): Promise<File>;
    }
    interface CollabFsDirectoryHandle {
        kind: 'directory';
        name: string;
        entries(): AsyncIterableIterator<[string, CollabFsDirectoryHandle | CollabFsFileHandleLike]>;
    }
    interface CollabFsLocalFile {
        path: string;
        content?: string | Blob;
        size: number;
        lastModified: number;
    }
    interface CollabFsAccessProgress {
        current: number;
        path: string;
    }
    export interface CollabFsManifest {
        schemaVersion: 1;
        project: number;
        selectedAt: string;
        lastSyncAt: string;
        syncMode: 'manual';
        files: Record<string, CollabFsManifestFile>;
    }
    export interface CollabFsManifestFile {
        path: string;
        versionRef: string;
        browserHash?: string;
        diskHash?: string;
        diskSize?: number;
        diskLastModified?: number;
        lastDirection: CollabFsManifestDirection;
    }
    export interface CollabFsBrowserEntry {
        path: string;
        key: string;
        file: mls.stor.IFileInfo;
        content?: string | Blob;
        hash?: string;
        versionRef: string;
        unsupported: boolean;
    }
    export interface CollabFsLocalEntry {
        path: string;
        content?: string | Blob;
        hash?: string;
        size: number;
        lastModified: number;
    }
    export interface CollabFsChange {
        path: string;
        kind: CollabFsChangeKind;
        file?: mls.stor.IFileInfo;
        browserContent?: string | Blob;
        localContent?: string | Blob;
        browserHash?: string;
        localHash?: string;
        message?: string;
    }
    export interface CollabFsScanResult {
        project: number;
        browserCount: number;
        localCount: number;
        unsupportedCount: number;
        changes: CollabFsChange[];
        scannedAt: string;
    }
    export interface CollabFsPullResult {
        written: number;
        deleted: number;
        skipped: number;
        manifest: CollabFsManifest;
    }
    export interface CollabFsPushResult {
        created: number;
        updated: number;
        deleted: number;
        skipped: number;
        manifest: CollabFsManifest;
    }
    export interface CollabFsFirstSyncValidation {
        empty: boolean;
    }
    export interface CollabFsPullPlan {
        write: string[];
        delete: string[];
        conflict: string[];
        keepLocal: string[];
    }
    export interface CollabFsPushPlan {
        create: string[];
        update: string[];
        delete: string[];
        blocked: string[];
    }
    export interface CollabFsDiffLine {
        type: 'context' | 'added' | 'removed';
        text: string;
    }
    export interface CollabFsProgress {
        phase: 'browser' | 'local' | 'compare' | 'write' | 'delete' | 'push' | 'manifest';
        current: number;
        total?: number;
        path?: string;
    }
    type CollabFsManifestDirection = 'browser-to-fs' | 'fs-to-browser' | 'linked';
    interface CollabFsSyncAdapter {
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: {
            readContent?: boolean;
        }): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
    }
    export class CollabFileSystemSync {
        private adapter;
        constructor(adapter: CollabFsSyncAdapter);
        validateFirstSync(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsFirstSyncValidation>;
        ensureManifest(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsManifest>;
        scan(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsScanResult>;
        planPull(changes: CollabFsChange[]): CollabFsPullPlan;
        planPush(changes: CollabFsChange[]): CollabFsPushPlan;
        pullToFs(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsPullResult>;
        pushToBrowser(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsPushResult>;
        resolveConflict(project: number, handle: CollabFsDirectoryHandle, path: string, keep: 'browser' | 'disk', onProgress?: (progress: CollabFsProgress) => void): Promise<void>;
        private upsertManifestEntry;
        private removeManifestEntry;
        readManifest(handle: CollabFsDirectoryHandle): Promise<CollabFsManifest | null>;
        buildDiff(localContent: string, browserContent: string, maxLines?: number): CollabFsDiffLine[];
        private buildSimpleDiff;
        private hasBrowserChangedSinceManifest;
        private hasLocalChangedSinceManifest;
        private getModifiedKind;
        private isBrowserSideChange;
        private isDiskSideChange;
        private applyManifestHashesToLocalMap;
        private shouldSkipPullWrite;
        private withManifestBrowserHash;
        private createBrowserFile;
        private updateBrowserFile;
        private shouldCreateModel;
        private fireBrowserFileChanged;
        private getBrowserEntries;
        private getBrowserContent;
        private getLocalEntries;
        private getLocalEntriesFromFiles;
        private hydrateBrowserEntry;
        private hydrateLocalEntry;
        private writeManifest;
        private isBrowserFileMappable;
        private isIgnoredRootFile;
        private isProjectLayoutPath;
        private formatPathExamples;
        private isUnchangedByManifest;
        private getBrowserPath;
        private parseLocalPath;
        private isSafeRelativePath;
        private mapByPath;
        private buildTrashStamp;
        private hashContent;
    }
}
declare module "_100554_/l2/serviceCollabFileSystem" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceCollabFileSystem100554 extends ServiceBase {
        private supported;
        private busy;
        private project;
        private folderName;
        private statusMessage;
        private progressMessage;
        private changes;
        private selectedPath;
        private scanResult;
        private scanned;
        private detailsOpen;
        private pendingConfirm;
        private lastSyncAt;
        private linkedFileCount;
        private msg;
        private adapter;
        private sync;
        private handle;
        private lastProgressAt;
        details: IService;
        menu: IServiceMenu;
        constructor();
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        onClickMain(op: string): void;
        render(): any;
        private renderBody;
        private renderFirstRun;
        private renderConnection;
        private renderDetails;
        private renderScanCta;
        private renderScanned;
        private renderGroup;
        private renderConfirmPanel;
        private pullConfirmLines;
        private pushConfirmLines;
        private renderHeaderStatus;
        private renderNotice;
        private getBadgeClass;
        private getBadgeLabel;
        private openChangeDetails;
        private openMonacoDiffRight;
        private isResolvable;
        private appendConflictResolution;
        private resolveConflict;
        private isDiskSideChange;
        private getExtensionFromPath;
        private getLanguageFromPath;
        private openDetailsRight;
        private createDetailStyle;
        private appendMuted;
        private getDetailText;
        private selectFolder;
        private disconnect;
        private scan;
        private requestPull;
        private requestPush;
        private confirmCancel;
        private confirmExecute;
        private runPull;
        private runPush;
        private scanCurrent;
        private loadProjectHandle;
        private resetScanState;
        private refreshManifestInfo;
        private formatLastSync;
        private resolveSelectedProjectHandle;
        private getStoredProjectHandle;
        private getProject;
        private savePreferences;
        private readPreferences;
        private runExclusive;
        private reportProgress;
        private formatProgress;
        private setEvents;
        private showAboutThis;
    }
}
declare module "../l2/collabMessagesEnvironment" {
    import { CollabMessagesEnvironment } from '_102036_/l2/environmentContract';
    export const collabEnvironment: CollabMessagesEnvironment;
}
declare module "_102025_/l2/collabMessagesInputTag" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesAdd" {
    import { CollabMessagesInputTag } from "_102025_/l2/collabMessagesInputTag";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabMessagesInputTag";
    export class CollabMessagesAdd extends StateLitElement {
        private msg;
        private threadType;
        private threadName;
        private visibility;
        private group;
        private languages;
        private isLoading;
        private dmUser;
        private users;
        agentsBots: IAgentsBots[];
        _selectedAgent: string;
        _initialMessage: string;
        _topics: string[];
        _agentConfig: string;
        _promptToAvatar: string;
        labelOk: string;
        labelError: string;
        userId: string | undefined;
        languageInput?: CollabMessagesInputTag;
        onAddSuccess: Function | undefined;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private loadUsersAvaliables;
        private loadAgentsBotsAvaliables;
        private _renderAdd;
        private _handleChange;
        private renderBotsConfig;
        private renderInitialMessageConfig;
        private renderIconConfig;
        private validateForm;
        private addNewThread;
        private addBot;
        private generateAvatar;
        private extractSvgFromContext;
    }
    interface IAgentsBots {
        id: string;
        name: string;
        description: string;
        avatar_url: string;
        info?: {
            project: number;
            shortName: string;
            folder: string;
        };
    }
}
declare module "_102025_/l2/collabMessagesTask" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTask extends StateLitElement {
        private msg;
        taskid: string;
        threadId: string;
        userId: string;
        messageid: string;
        lastChanged: string;
        status: string;
        notificationPending: boolean;
        task: msg.TaskData | undefined;
        context: msg.ExecutionContext | undefined;
        private secondsPassed;
        private lastStep;
        private timerId;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderIconTask(): any;
        private resetTimer;
        private resetTimerState;
        private formatTime;
        private getTaskLocal;
        private onCardClick;
        private normalizeMessageId;
        private getAllSteps;
        private getNextPendentStep;
        private getTotalCost;
    }
}
declare module "_102025_/l2/collabMessagesTopics" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTopics extends StateLitElement {
        messages: IMessage[];
        topics: string[];
        expanded: boolean;
        selectedTopic: string | null;
        threadTopics: string[];
        render(): any;
        private emitTopic;
        private extractTopics;
        private groupTopics;
        private getHeadersTopicsFromMessages;
        private getTopicsFromMessagesOrdered;
    }
    interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
    }
}
declare module "_102025_/l2/collabMessagesAddParticipant" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesAddParticipant extends StateLitElement {
        private msg;
        userId: string | undefined;
        labelOkAddParticipant: string;
        labelErrorAddParticipant: string;
        userIdOrName: string;
        auth: msg.UserAuth;
        isAddParticipant: boolean;
        actualThread: IThreadActual | undefined;
        highlightedIndex: number;
        suggestions: string[];
        allUsers: string[];
        private users;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private onInput;
        private onBlur;
        private selectSuggestion;
        private onKeyDown;
        private onFocus;
        private onSubmitAddParticipant;
        private loadUsersAvaliables;
    }
    interface IThreadActual {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesChangeAvatar" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabChangeAvatar extends StateLitElement {
        private msg;
        value?: string;
        nameValue?: string;
        userId: string;
        threadId: string;
        private avatarPrompt;
        private avatarFile?;
        private isOpen;
        private generating;
        private preview?;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private onFileSelect;
        private triggerFileInput;
        private generateAvatarFromPrompt;
        private emitValueChanged;
        private safeSvg;
    }
}
declare module "_102025_/l2/collabMessagesThreadDetails" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabMessagesInputTag";
    import "_102025_/l2/collabMessagesAddParticipant";
    import "_102025_/l2/collabMessagesChangeAvatar";
    export class CollabMessagesThreadDetails extends StateLitElement {
        private msg;
        userId: string | undefined;
        threadDetails?: IThreadDetails;
        avatarEl?: HTMLElement;
        labelOk: string;
        labelError: string;
        labelErrorRemoveUser: string;
        labelErrorRemoveBoot: string;
        labelErrorAgent: string;
        labelOkAgent: string;
        private isLoading;
        private editedThreadDetails?;
        private isDirectMessage?;
        private isChannel?;
        private isFileChannel?;
        private isEditingDetails;
        private showAgentForm;
        private integrations;
        private selectedIntegrationId;
        private selectedAgentId;
        private isLoadingAgents;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private loadIntegrations;
        updated(changedProperties: Map<string, any>): Promise<void>;
        private getAddedAgentIds;
        private getAvailableAgents;
        private getVisibilityLabel;
        private getCurrentUserNotification;
        private setCurrentUserNotification;
        private getStatusLabel;
        private getCurrentUserThreadAuth;
        private canManageThread;
        private canModerateThread;
        private isLastAdmin;
        private enterEditMode;
        private cancelEditMode;
        render(): any;
        private renderDetailsViewMode;
        private renderDetailsEditMode;
        private renderUsers;
        private renderAvatar;
        private isUrl;
        private renderAgents;
        private renderAgentFormContent;
        private findAgentInfo;
        private openAgentForm;
        private closeAgentForm;
        private addAgentOpenClawInThread;
        private addIntegrationOpenClawInThread;
        private saveAgentOpenClaw;
        private removeAgentOpenClaw;
        private updateStatusAgent;
        private renderBots;
        private removeUser;
        private removeBot;
        private disableBot;
        private getChangedFields;
        private onAddParticipant;
        private saveChanges;
        private removeUserFromThread;
        private getThreadInfo;
    }
    interface IThreadDetails {
        thread: msg.ThreadPerformanceCache;
        users: msg.User[];
    }
}
declare module "_102025_/l2/collabMessagesUserModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesUserModal extends StateLitElement {
        private msg;
        open: boolean;
        user?: msg.User;
        actualUserId?: string;
        isDirectMessage: boolean;
        private isLoading;
        private errorMessage;
        private close;
        private handleGlobalClick;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickUserAction;
    }
}
declare module "_102025_/l2/collabMessagesThreadModal" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabMessagesAvatar";
    export class CollabMessagesThreadModal extends StateLitElement {
        private msg;
        open: boolean;
        thread?: msg.ThreadPerformanceCache;
        private isLoading;
        private errorMessage;
        private handleGlobalMouseMove;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        disconnectedCallback(): void;
        private destroy;
        render(): any;
        private onClickThreadAction;
    }
}
declare module "_102025_/l2/collabMessagesFilter" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesFilter extends StateLitElement {
        private expanded;
        private query;
        placeholder: string;
        private toggleExpand;
        private handleKey;
        private handleInput;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTextCode" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesTextCode extends StateLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        private _resolveRendered;
        private markRendered;
        whenRendered: Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        private getHighlightLanguage;
        private markRenderedAfterPaint;
        setCode(): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichPreviewText" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabMessagesTextCode";
    export class CollabMessagesRichPreviewText102025 extends StateLitElement {
        private msg;
        allHelpers: string[];
        allCommands: string[];
        allThreads: msg.Thread[];
        allUsers: msg.User[];
        text: string;
        showMarkers: boolean;
        private expandedCodeBlocks;
        render(): any;
        private renderTokens;
        private renderMarker;
        private renderToken;
        private renderText;
        private renderBold;
        private renderItalic;
        private renderStrike;
        private renderInlineCode;
        private renderCodeBlock;
        private toggleCodeBlock;
        private renderAgent;
        private renderMention;
        private renderChannel;
        private renderCommand;
        private renderHelp;
        private renderLink;
        private renderRawLink;
        private renderHeading;
        private renderBlockquote;
        private renderList;
        private normalizeLinkHref;
        private copyToClipboard;
    }
}
declare module "_102025_/l2/collabMessagesChat" {
    import "_102025_/l2/collabMessagesTask";
    import "_102025_/l2/collabMessagesTaskInfo";
    import "_102025_/l2/collabMessagesTopics";
    import "_102025_/l2/collabMessagesPrompt";
    import "_102025_/l2/collabMessagesAvatar";
    import "_102025_/l2/collabMessagesThreadDetails";
    import "_102025_/l2/collabMessagesUserModal";
    import "_102025_/l2/collabMessagesThreadModal";
    import "_102025_/l2/collabMessagesFilter";
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChatMessage";
    import "_102025_/l2/collabMessagesRichPreviewText";
    import * as msg from "_102025_/l2/shared/interfaces";
    import { IMessage, IThreadInfo } from "_102025_/l2/collabMessagesHelper";
    import { CollabMessagesPrompt } from "_102025_/l2/collabMessagesPrompt";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesChat extends StateLitElement {
        private msg;
        collabMessagesPrompt: CollabMessagesPrompt | undefined;
        private unreadEl;
        private messageContainer;
        private isLoadingThread;
        private filteredThreads;
        private isThreadError;
        private threadErrorMsg;
        private lastTopicFilter;
        private welcomeMessage;
        private usersAvaliables;
        private elementTaskDetails;
        private taskNotificationNavDirection;
        private toolbarView;
        group: 'CONNECT' | 'APPS' | 'DOCS' | 'CRM';
        userId: string | undefined;
        threadToOpen: string | undefined;
        taskToOpen: string | undefined;
        userDeviceId: string | undefined;
        activeScenerie: IScenery;
        actualThread: IThreadInfo | undefined;
        actualTask: msg.TaskData | undefined;
        actualMessage: IMessage | undefined;
        actualMessages: IMessage[];
        actualMessagesParsed: IMessageGrouped;
        isLoadingMessages: boolean;
        searchTerm: string;
        userThreads: IThread;
        allThreads: msg.Thread[];
        lastMessageReaded: string | undefined;
        unreadCountInSelectedThread: number;
        private forwardMessageSource?;
        private forwardDestinationQuery;
        private forwardDestinationThreadId;
        private forwardError;
        private isForwardingMessage;
        private highlightedMessageId;
        private toolbarHelpKind?;
        private toolbarNavigationKind?;
        private toolbarNavigationFailedKind?;
        private toolbarNavigationError;
        private cachedToolbarMessages;
        private isSystemChangeScroll;
        private savedScrollTop;
        private hasMoreMessagesLocalDB;
        private hasMoreMessagesBefore;
        private messagesLimit;
        private isLoadingMoreMessages;
        private isChangeTopics;
        private wasMessagesAtBottom;
        private ignoreToolbarScrollClearUntil;
        private isToolbarAutoScroll;
        private toolbarAutoScrollTimer?;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderHeader;
        private renderContent;
        private renderChatMessages;
        private renderTaskNotificationNav;
        private renderForwardMessage;
        private renderForwardDestination;
        private renderToolbarHelp;
        private getToolbarHelpContent;
        private closeToolbarHelp;
        private renderTaskNotificationNavIcon;
        private renderWelcomeMessage;
        private renderTopics;
        private renderThreadToolbar;
        private renderToolbarCounter;
        private navigateToolbarItem;
        private getToolbarTitle;
        private clearToolbarSelection;
        private getNextToolbarIndex;
        private getAttachmentMessages;
        private getAgentMessages;
        private getMessagesKnownToToolbar;
        private openToolbarHelp;
        private getFavoriteMessageIdsForThread;
        private getReadConfirmationMessageIdsForThread;
        private hasPendingReadConfirmationsForThread;
        private getLoadedMessageById;
        private getReadConfirmationMessageIdsFromLoadedMessages;
        private isReadConfirmationRelevantForCurrentUser;
        private isReadConfirmationPendingForCurrentUser;
        private isReadConfirmationRequestedByCurrentUser;
        private getReadConfirmationKind;
        private getFollowupReactionForUser;
        private getCurrentUser;
        private navigateToMessageId;
        private normalizeToolbarMessageId;
        private getLocalMessageById;
        private renderMessageWindowFromLocalCache;
        private renderMessageWindowFromServer;
        private buildMessageWindowFromTarget;
        private applyToolbarMessageWindow;
        private parseMessageId;
        private getMessageCacheKey;
        private isSameMessageId;
        private scrollToMessageId;
        private deferToolbarAutoScrollEnd;
        private isMessageHighlightedByToolbar;
        private onTopicClick;
        private removeAllModal;
        private renderPrompt;
        private getCurrentThreadUserAuth;
        private canWriteCurrentThread;
        private showReadOnlyThreadError;
        private renderListThreads;
        private getThreadAvatar;
        private getThreadName;
        private isDirectMessage;
        private renderThreadsByStatus2;
        private renderThreadItemLi;
        private renderTaskPendingsCount;
        private formatMessageDate;
        private renderArchivedThreads;
        private renderDeletingThreads;
        private renderDeletedThreads;
        private renderThreadSearch;
        private renderTaskDetails;
        private renderThreadDetails;
        private renderThreadAdd;
        private onSearchInput;
        private getScrollAnchor;
        private restoreScrollAnchor;
        private updateMessagesAfterScrollMore;
        private getBeforeMessagesInServer;
        private getBeforeMessagesInLocalDb;
        private onCopyChat;
        private onChatScroll;
        private getFirstPendingTaskNotificationInView;
        private getTaskNotificationElement;
        private updateTaskNotificationNavDirection;
        private scrollToTaskNotification;
        private groupThreadsByPrefix;
        private getOrdenedThreadsByStatus;
        private getFilteredThreads;
        private getMessagesAfter;
        private getMessagesBefore;
        private parseMessages;
        private groupMessages;
        private parseLocalDate;
        private mergeMessages;
        private onThreadClick;
        private updateThreadPendingsInBackground;
        private markActualThreadRead;
        private clearUnreadMarkerForActualThread;
        private getLastKnownMessageCreateAt;
        private openTask;
        private checkWelcomeMessage;
        private refreshCachedToolbarMessages;
        private checkNotificationsUnreadMessages;
        private alreadyCheckForRegisterToken;
        private checkForRegisterNotification;
        private loadAllMessages;
        private updateMessagesOnDb;
        private clearUnreadMessageFromThread;
        private shouldPreserveUnreadMarker;
        private getFirstUnreadMessageCreateAt;
        private getUnreadMessagesCount;
        private updateLastMessage;
        private onTitleClick;
        private onThreadDetailsClick;
        private onThreadAddClick;
        private handleSend;
        private handlePromptResize;
        private scrollMessagesToBottom;
        private addMessage;
        private addAttachmentMessage;
        private addMessageIA;
        private updateMessageAI;
        private createTempMessage;
        private updateMessage2;
        private onTaskClick;
        private hasStudioTaskDetailHost;
        private createLocalTaskDetails;
        private onReplyPreviewClick;
        private onReplyMessageClick;
        private onPinMessageClick;
        private onFavoriteMessageClick;
        private onReadConfirmationMessageClick;
        private onMessageActionMessageClick;
        private onEditMessageClick;
        private applyMessageUpdateResponse;
        private onMarkUnreadMessageClick;
        private onForwardMessageClick;
        private onForwardDestinationInput;
        private selectForwardDestination;
        private cancelForwardMessage;
        private confirmForwardMessage;
        private getForwardDestinationSuggestions;
        private isForwardDestinationAllowed;
        private getForwardThreadSortTime;
        private isDirectMessageThread;
        private getForwardThreadName;
        private renderForwardDestinationAvatar;
        private createTaskTitleFromMessage;
        private createMessageLink;
        private onDeleteAttachmentMessage;
        private updateCurrentUser;
        private updateUsersInState;
        private replaceUser;
        private getTaskUpdate;
        private clearMissingTaskReference;
        private normalizeTaskMessageId;
        private normalizeMessageId;
        private getThreadInfo;
        private saveScrollPosition;
        private restoreScrollPosition;
        private onTaskChange;
        private onThreadChange;
        private onMessageChange;
        private onMessageSend;
        private onVisibilityChange;
        private onDocumentClick;
        private scrollLock;
        private verifyChatScroll;
        private delay;
        private nextFrame;
        private waitingForRenderCodesWebComponents;
    }
    type IMessageGrouped = {
        [key: string]: IMessage[];
    };
    type IThread = {
        [key: string]: IThreadInfo[];
    };
    type IScenery = 'list' | 'details' | 'loading' | 'task' | 'threadDetails' | 'threadAdd' | 'forwardMessage' | 'toolbarHelp';
}
declare module "_102025_/l2/collabTasksSidebar" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    type ScreenId = 'board' | 'mytasks' | 'workflows' | 'simulator' | 'approvals' | 'analytics' | 'settings';
    export class CollabTasksSidebar extends StateLitElement {
        activeScreen: ScreenId;
        private _emit;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksTheme" {
    /**
     * Shared theme utilities for the Tasks tab.
     * Board and My Tasks share the same localStorage key so theme changes
     * are reflected everywhere immediately.
     */
    import { TemplateResult } from 'lit';
    export type TasksTheme = 'clean' | 'amber' | 'forest' | 'trello' | 'clickup';
    export const TASKS_THEME_KEY = "collab-board-theme";
    export const TASKS_BG_KEY_PREFIX = "collab-tasks-bg-";
    export const TASKS_VALID_THEMES: TasksTheme[];
    export const THEME_BG_OPTIONS: Partial<Record<TasksTheme, {
        url: string;
        thumbUrl: string;
        label: string;
    }[]>>;
    export function loadTasksTheme(): TasksTheme;
    export function loadThemeBgUrl(theme: TasksTheme): string | null;
    export function saveThemeBgUrl(theme: TasksTheme, url: string): void;
    export function applyThemeToHost(theme: TasksTheme, host: HTMLElement): void;
    /**
     * Persist the theme, apply it to the given host, and broadcast the change
     * to any other open tasks screen so the picker / board / my-tasks stay in
     * sync without a reload. Listeners can re-apply the theme to their own host
     * with applyThemeToHost(theme, this).
     */
    export function saveTasksTheme(theme: TasksTheme, host: HTMLElement): void;
    export interface ThemeMeta {
        id: TasksTheme;
        labelPt: string;
        labelEn: string;
        descPt: string;
        descEn: string;
        hasImage: boolean;
    }
    export const THEME_LIST: ThemeMeta[];
    export function getThemeMeta(id: TasksTheme, lang: string): {
        label: string;
        desc: string;
    };
    export function themePreview(id: TasksTheme): TemplateResult;
    export function renderThemeCards(currentTheme: TasksTheme, lang: string, onSelect: (t: TasksTheme) => void): TemplateResult;
    export function renderImagePicker(theme: TasksTheme, currentUrl: string | null, lang: string, onSelect: (url: string) => void): TemplateResult;
}
declare module "_102025_/l2/collabTasksCard" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import * as msg from "_102025_/l2/shared/interfaces";
    export class CollabTasksCard extends StateLitElement {
        task: msg.TaskData | undefined;
        tagVocabulary: msg.TagVocabularyEntry[];
        boardStatus: string;
        connectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _applyStatusClass;
        render(): any;
        private _onClick;
        private _onKeyDown;
    }
}
declare module "_102025_/l2/collabTasksEmptyState" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabTasksEmptyState extends StateLitElement {
        title: string;
        subtitle: string;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksDesignTokens" {
    /**
     * Tasks design tokens.
     *
     * This is a TypeScript barrel for the companion `collabTasksDesignTokens.less`
     * file, which exposes a shared set of CSS variables (`--ct-*`) consumed by all
     * tasks components: board, my-tasks, card, settings, theme picker, etc.
     *
     * The tokens are declared at `:root` so they cascade everywhere — making them
     * available to other mls-102025 components that wish to adopt them later
     * without forcing a refactor today.
     *
     * Import this module from any tasks component to ensure the stylesheet is
     * pulled in by the enhancement loader.
     */
    export const CT_STATUS_ACCENT: {
        readonly todo: "#185fa5";
        readonly 'in progress': "#854f0b";
        readonly paused: "#6b7280";
        readonly done: "#3b6d11";
        readonly failed: "#a32d2d";
    };
    export const CT_TAG_ACCENT: {
        readonly bug: "#a32d2d";
        readonly feature: "#185fa5";
        readonly business: "#854f0b";
        readonly process: "#085041";
        readonly neutral: "#5f5e5a";
    };
    export type CtStatusKey = keyof typeof CT_STATUS_ACCENT;
    export type CtTagKey = keyof typeof CT_TAG_ACCENT;
}
declare module "_102025_/l2/collabTasksThemePicker" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksThemePicker extends StateLitElement {
        /** Visual density. 'compact' for inline popovers, 'panel' for standalone screens. */
        variant: 'compact' | 'panel';
        /** Hide the section title when the host already provides one. */
        hideTitle: boolean;
        private _theme;
        private _bgUrl;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _onSelectTheme;
        private _onSelectBg;
        render(): any;
    }
}
declare module "_102025_/l2/collabTasksBoard" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabTasksCard";
    import "_102025_/l2/collabTasksEmptyState";
    import "_102025_/l2/collabTasksThemePicker";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksBoard extends StateLitElement {
        reloadKey: number;
        userId: string;
        organizationId: string;
        initialPmaFilter: string;
        private activeTasks;
        private closedTasks;
        private tagVocabulary;
        private loadingActive;
        private loadingClosed;
        private error;
        private _theme;
        private _showSettings;
        private _filterTags;
        private _filterPmaIds;
        private _initialFetchDone;
        private _refetchTimer;
        private _onTaskChange;
        private _onThreadChange;
        private _onTaskMetaChanged;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        private _applyThemeClass;
        private _getFilterOptions;
        private _applyFilters;
        private _toggleTag;
        private _togglePmaId;
        private _clearFilters;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private _fetchAll;
        private _fetchClosed;
        private _filterWorkflow;
        private _scheduleRefetch;
        private _handleTaskChange;
        private _handleThreadChange;
        private _handleTaskMetaChanged;
        private _bucket;
        render(): any;
        private _renderFilterBar;
        private _renderSettings;
        private _renderColumn;
        private _renderCard;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksMyTasks" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabTasksThemePicker";
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksMyTasks extends StateLitElement {
        userId: string;
        private activeTasks;
        private closedTasks;
        private loadingActive;
        private loadingClosed;
        private error;
        private showClosed;
        private _theme;
        private _showSettings;
        private _refetchTimer;
        private _onTaskChange;
        private _onTaskMetaChanged;
        private _onThemeChanged;
        private _onBgChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _applyThemeClass;
        private _fetchAll;
        private _fetchClosed;
        private _scheduleRefetch;
        private _handleTaskChange;
        private _handleTaskMetaChanged;
        private _openTask;
        render(): any;
        private _renderHeader;
        private _renderSettings;
        private _renderBody;
        private _renderTaskRow;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksWorkflows" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabTasksWorkflows extends StateLitElement {
        userId: string;
        private groups;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        render(): any;
        private _openInBoard;
        private _renderGroup;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksApprovals" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabTasksApprovals extends StateLitElement {
        userId: string;
        private pending;
        private paused;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        private _openTask;
        render(): any;
        private _renderRow;
        private _renderSkeletons;
    }
}
declare module "_102025_/l2/collabTasksAnalytics" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabTasksAnalytics extends StateLitElement {
        userId: string;
        private analytics;
        private loading;
        private error;
        connectedCallback(): void;
        private _fetchAll;
        render(): any;
        private _renderDashboard;
        private _tile;
        private _renderLoadingTiles;
    }
}
declare module "_102025_/l2/collabTasksSettings" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabTasksDesignTokens";
    export class CollabTasksSettings extends StateLitElement {
        userId: string;
        organizationId: string;
        private tagVocabulary;
        private loadingTags;
        private errorTags;
        private _onThemeChanged;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _loadTags;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesTasks" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabTasksSidebar";
    export class CollabMessagesTasks extends StateLitElement {
        private screen;
        private _onBoardFilter;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _openBoardWithFilter;
        render(): any;
        private _onScreenChange;
        private _openScreen;
    }
}
declare module "_102025_/l2/collabMessagesAppsMenu" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export interface IMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: IMenuItem[];
    }
    export interface IMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: IMenuItem[];
    }
    export class CollabMessagesAppsMenu extends StateLitElement {
        keyFavoritesLocalStorage: string;
        identifier: string;
        menuTitle: string;
        menuModules: IMenu[];
        favorites: string[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private loadFavorites;
        private getItemPath;
        private toggleFavorite;
        private isFavorite;
        private handleMenuClick;
        private renderMenuItem;
        render(): any;
        private findItemByPath;
    }
}
declare module "_102025_/l2/collabMessagesApps" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import { type CollabProgramMenu } from '_102036_/l2/environmentContract';
    import "_102025_/l2/collabMessagesAppsMenu";
    export class CollabMessagesApps extends CollabLitElement {
        menuModules: CollabProgramMenu[];
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private handleMenuClick;
    }
}
declare module "_102025_/l2/collabMessagesMoments" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesMoments102025 extends StateLitElement {
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesSettingsOpenClaw" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'main' | 'connectorDetails' | 'editAgent';
    interface IOpenClawConnectorLocal extends msg.OpenClawConnector {
        isNew?: boolean;
        gatewayTokenChanged?: boolean;
        inboundTokenChanged?: boolean;
    }
    export class CollabMessagesSettingsOpenClaw extends StateLitElement {
        private msg;
        userId: string;
        actualIntegration: msg.IOpenClawIntegration | undefined;
        integrations: msg.IOpenClawIntegration[];
        connectors: IOpenClawConnectorLocal[];
        viewMode: ViewMode;
        currentConnectorId: string;
        editingConnector: IOpenClawConnectorLocal | null;
        isTestingConnection: boolean;
        connectionTestResult: 'none' | 'success' | 'error' | 'warning';
        connectionTestMessage: string;
        connectionTestLatency: number;
        showGatewayToken: boolean;
        showInboundToken: boolean;
        copiedToken: 'gateway' | 'inbound' | null;
        showDeleteConfirmation: boolean;
        deleteConfirmationInput: string;
        newAgentName: string;
        newAgentAvatarUrl: string;
        editingAgent: msg.IOpenClawAgent | null;
        isNewAgent: boolean;
        newAgentWorkspace: string;
        newAgentEmoji: string;
        newAgentSoulMd: string;
        newAgentIdentityMd: string;
        showDeleteAgentConfirmation: boolean;
        agentToDelete: msg.IOpenClawAgent | null;
        deleteAgentFiles: boolean;
        isDeletingAgent: boolean;
        labelOkConnector: string;
        labelErrorConnector: string;
        labelOkAgent: string;
        labelErrorAgent: string;
        isSavingConnector: boolean;
        isSavingAgent: boolean;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderOpenClawConnectors;
        private renderConnectorCard;
        private renderToggleIcon;
        private renderConnectorDetailsView;
        private renderConfigurationSection;
        private renderTestConnectionSection;
        private renderAgentSection;
        private renderDeleteSection;
        private renderDeleteConfirmation;
        private renderAgentCard;
        private renderDeleteAgentModal;
        private renderAvatar;
        private isUrl;
        private renderEditAgentView;
        private navigateTo;
        private handleAddConnector;
        private clearErrors;
        private clearStates;
        private getIntegration;
        private handleOpenConnectorDetails;
        private handleBackToMain;
        private handleCancelConnector;
        private handleConnectorNameChange;
        private handleConnectorUrlChange;
        private handleGatewayTokenChange;
        private handleInboundTokenChange;
        private handleChangeToken;
        private handleTimeoutChange;
        private handleOutputModeChange;
        private handleConnectorEnabledToggle;
        private handleGenerateToken;
        private handleSaveConnector;
        private saveIntegration;
        private removeIntegration;
        private saveOrUpdateOpenClawConnector;
        private handleTestConnection;
        private checkDomainExists;
        private handleToggleDeleteConfirmation;
        private handleDeleteConfirmationInput;
        private handleCancelDelete;
        private handleConfirmDelete;
        private handleOpenAddAgent;
        private handleOpenEditAgent;
        private handleBackToConnectorDetails;
        private handleNewAgentNameInput;
        private handleNewAgentAvatarInput;
        private handleNewAgentWorkspaceInput;
        private handleNewAgentEmojiInput;
        private handleNewAgentSoulMdInput;
        private handleNewAgentIdentityMdInput;
        private handleGenerateAgentAvatar;
        private handleSaveAgent;
        private handleOpenDeleteAgentConfirmation;
        private handleCloseDeleteAgentConfirmation;
        private handleDeleteAgentFilesChange;
        private handleConfirmDeleteAgent;
        private handleDisableAgent;
        private handleToggleTokenVisibility;
        private handleCopyToken;
    }
}
declare module "_102025_/l2/collabMessagesSettingsChatPreferences" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesSettingsChatPreferences extends StateLitElement {
        private msg;
        private chatPreferences;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private handleTranslationModeChange;
        private handleLanguageInput;
        private handleSave;
    }
}
declare module "_102025_/l2/collabMessagesSettingsUser" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesSettingsUser extends StateLitElement {
        private msg;
        private userPerfil;
        private viewMode;
        private isSaving;
        private labelOk;
        private labelError;
        private tempAvatarUrl;
        private avatarUrlValid;
        private avatarLoading;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderUserSection;
        private renderEditAvatarView;
        private getUserPerfil;
        private handleNameInput;
        private handleSave;
        private handleOpenEditAvatar;
        private handleCancelEditAvatar;
        private handleAvatarUrlInput;
        private handleAvatarError;
        private handleSaveAvatar;
    }
}
declare module "_102025_/l2/collabMessagesSettingsNotificationPreferences" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabMessagesSettingsNotificationPreferences extends StateLitElement {
        private msg;
        private notificationPreferences;
        private audioEnabled;
        private isSaving;
        private labelOk;
        private labelError;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderEnabled;
        private renderDisabled;
        private renderReadMore;
        private getNotificationStatus;
        private handleAudioToggle;
        private handleEnableNotifications;
    }
}
declare module "_102025_/l2/collabMessagesSettingsGeral" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102025_/l2/collabMessagesSettingsOpenClaw";
    import "_102025_/l2/collabMessagesSettingsChatPreferences";
    import "_102025_/l2/collabMessagesSettingsUser";
    import "_102025_/l2/collabMessagesSettingsNotificationPreferences";
    import * as msg from "_102025_/l2/shared/interfaces";
    type ViewMode = 'all' | 'user' | 'chat' | 'notification' | 'openclaw';
    export class CollabMessagesSettingsGeral102025 extends StateLitElement {
        private msg;
        viewMode: ViewMode;
        userPerfil: msg.User | undefined;
        private scrollPositions;
        private show;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderUser;
        private renderChatPreferences;
        private renderPreferencesNotifications;
        private renderOpenClawConnectors;
        private onSettingsChange;
        private getUserPerfil;
        private saveScrollPosition;
        private restoreScrollPosition;
        private navigateTo;
    }
}
declare module "_102025_/l2/collabMessagesTabMenu" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export interface TabMenuItem {
        id: string;
        icon: TemplateResult;
        label: string;
        activeColor?: string;
        type: 'tab' | 'button';
    }
    export class CollabMessagesTabMenu extends StateLitElement {
        items: TabMenuItem[];
        activeId: string;
        private get _tabs();
        private get _buttons();
        private _handleItemClick;
        private _renderItem;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessages" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "_102025_/l2/collabMessagesAdd";
    import "_102025_/l2/collabMessagesChat";
    import "_102025_/l2/collabMessagesTasks";
    import "_102025_/l2/collabMessagesApps";
    import "_102025_/l2/collabMessagesMoments";
    import "_102025_/l2/collabMessagesSettingsGeral";
    import "_102025_/l2/collabMessagesTabMenu";
    export class CollabMessages extends CollabLitElement {
        private msg;
        dataLocal: IDataLocal;
        activeTab: ITabType;
        activeScenerie: IScenery;
        isLoadingThread: boolean;
        userPerfil: msg.User | undefined;
        userThreads: IThreadData;
        showNotificationAlert: boolean;
        threadToOpen: string;
        taskToOpen: string;
        lastLevel: number;
        modeMenu: string;
        private groupSelected;
        private menuItems;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private checkNotificationPermission;
        private startPendentsPoolingsIfNeeded;
        private onThreadChange;
        private onThreadOpen;
        private setEvents;
        private removeEvents;
        renderHeader(): any;
        renderTabs(): any;
        renderAlert(): any;
        private onAlertClose;
        renderCRM(): any;
        renderTasks(): any;
        renderMoments(): any;
        renderApps(): any;
        renderSettings(): any;
        renderConnect(): any;
        private getUser;
        private updateThreads;
        private searchForDeletedThreadsPending;
        private updateUsersThread;
        private getThreadFromLocalDB;
        private getThreadInfo;
        private onThreadCreate;
        private checkNotificationPending;
        private onTabChange;
        private onButtonClick;
    }
    interface IDataLocal {
        lastTab: ITabType;
    }
    type IThreadData = {
        [key: string]: IThreadInfo;
    };
    interface IThreadInfo {
        thread: msg.Thread;
        users: msg.User[];
    }
    type ITabType = 'CRM' | 'TASK' | 'MOMENTS' | 'CONNECT' | 'APPS' | 'SETTINGS' | 'Add' | 'Loading';
    type IScenery = 'tabs' | 'settings' | 'findTask';
}
declare module "../l2/pluginFindTask" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class PluginFindTask extends StateLitElement {
        private msg;
        threadId?: string;
        taskId?: string;
        error?: string;
        actualTask: msg.TaskData | undefined;
        actualMessage: msg.Message | undefined;
        isLoading: boolean;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        private renderSearch;
        private handleThreadChange;
        private handleTaskChange;
        private findThread;
    }
}
declare module "_100554_/l2/serviceCollabMessages" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from '_100554_/l2/serviceBase';
    import "_102025_/l2/collabMessages";
    import "_102025_/l2/collabMessagesSettingsGeral";
    import '/_100554_/l2/pluginFindTask.js';
    export class ServiceCollabMessages extends ServiceBase {
        private msg;
        activeTab: string;
        msize: string;
        threadToOpen: string;
        taskToOpen: string;
        lastLevel: number;
        collabMessagesEl?: HTMLElement;
        details: IService;
        onClickTabs(index: number): void;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        connectedCallback(): Promise<void>;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<string | number | symbol, unknown>): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
        private bootstrapCollabMessages;
        private initNotificationIfEnabled;
        private setEvents;
        private removeEvents;
        private checkNotificationPending;
        private onThreadReceivedNotification;
        private openSettings2;
        private openFindTask;
        private changeDisplayMenu;
        private isFirstEnter;
        private configureByLevel;
        private onCollabEventsCollabMessages;
        private showAboutThis;
    }
}
declare module "_100554_/l2/serviceDashboard.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabTiles" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/collabTilesItem.js';
    import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js';
    export class CollabTiles extends CollabLitElement {
        config: string;
        tilesItens: ITilesItem[];
        text: string;
        example: string;
        collabTiles: HTMLElement | undefined;
        private oldJson;
        createRenderRoot(): this;
        render(): any;
        renderItem(item: ITilesItem, idx: number): any;
        renderConfigItens(): any;
        renderConfigItensOpen(): any;
        renderConfigItensClose(): any;
        renderItemConfig(item: ITilesItem, index: number): any;
        private sort;
        private setDragAndDrop;
        private open;
        private close;
        private onlyclose;
        private verifyNeedSaveAndSave;
        private changeConfig;
        private setInfoPlugin;
        private fireChange;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_/l2/serviceDashboard" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import '/_100554_/l2/collabTiles.js';
    export class ServiceDashboard100554 extends ServiceBase {
        msize: string;
        cssBreakPoint: string;
        activeTab: string;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private showAboutThis;
        createRenderRoot(): this;
        firstUpdated(): void;
        private refreshTimeOut;
        updated(changedProperties: any): void;
        render(): any;
        renderContent(): any;
        renderIcon1(): any;
        renderIcon2(): any;
        private pluginsDash1;
        private pluginsDash2;
        private baseProject;
        private loadAndSetPlugins;
        private getInfoPlugin;
    }
}
declare module "_100554_/l2/serviceDetail.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceDetail" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceDetail100554 extends ServiceBase {
        msize: string;
        widget: string;
        typeRender: 'default';
        contentPlugin: HTMLDivElement | undefined;
        private plugin;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        updateContentPluginWithElement(element: HTMLElement): void;
        clear(): void;
        private showAboutThis;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderDefault(): any;
        private setEvents;
        private onMonacoEvents;
        private onFileActionReceived;
        private onPluginDetails;
        private onWidgetChanged;
        private showPluginContent;
        private getHtmlFromPlugin;
        private updateContentPluginWithScripts;
        private _updateContentPluginWithElement;
        private setContentElement;
        private setContentinEl;
        private fireEvents;
    }
}
declare module "_100554_/l2/serviceExploreProjects.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceExploreProjects" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceExploreProjects100554 extends ServiceBase {
        private msg;
        scenary: string;
        inFilter: boolean;
        projectCreated: boolean;
        state: IServiceList;
        lastPrjId: string | null | undefined;
        list: NodeListOf<HTMLElement> | undefined;
        titleList: NodeListOf<HTMLElement> | undefined;
        historieEl: HTMLElement | undefined;
        activeTab: string;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private setEvents;
        connectedCallback(): void;
        createRenderRoot(): this;
        render(): any;
        renderContent(): any;
        renderExplore(): any;
        renderSelectProject(): any;
        renderHistory(): any;
        renderList(): any;
        renderTotsOrgs(): any;
        renderScenaryOrg(): any;
        renderListOrgs(): any;
        private firedetail;
        private getLastProject;
        private getOrgsAndProjects;
        private clearState;
        private filterTimeout;
        private _filterProjects;
        private onHistoryClick;
        private onProjectClick;
        private setProjectActual;
        private setOrgActual;
        private addOnHistory;
        private onOrgClick;
        private goToOrgs;
        private _filterOrgs;
        private fireDetails;
    }
    interface IStateOrg {
        key: string;
        name: string;
        created_at: string;
        description: string;
        projects: IInfoPrj[];
        selected: boolean;
    }
    interface IInfoPrj {
        project: number;
        name: string;
        doSelect: boolean;
    }
    interface IServiceList {
        history: IHistory[];
        orgs: IStateOrg[];
        projectSelected: number | undefined;
    }
    interface IHistory {
        project: number;
        name: string;
        doSelect: boolean;
    }
}
declare module "_100554_/l2/serviceHistories.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceHistories" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_102027_/l2/collabMonacoEditor";
    export class ServiceHistories100554 extends ServiceBase {
        private msg;
        constructor();
        msize: string;
        lastModeEditor: TEditorMode;
        createRenderRoot(): this;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        private c2;
        static modelCount: number;
        private _ed1;
        private fileInfo;
        private hashOriginal;
        private hashModified;
        private histories;
        get confE(): string;
        private showStart;
        private onToolbarSelected;
        private onSelectHistories;
        private changeEditorMode;
        private getHistories;
        private setInitialHistories;
        private createOrGetModel;
        private getUri;
        private createEditor;
        private updateEditor;
        private setMsizeEditor;
        private _onServiceClick;
        updated(changedProperties: any): void;
        render(): any;
    }
    type TEditorMode = 'sideBySide' | 'inline';
}
declare module "_100554_/l2/serviceLiveView.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabNav4Menu" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    interface TabItem {
        text: string;
        icon?: string;
        allowClose?: boolean;
    }
    export class CollabNav4Menu extends StateLitElement {
        selectedIndex: number;
        mode: 'full' | 'onlyicon' | 'fixed';
        options: TabItem[];
        private isDropdownOpen;
        private toggleDropdown;
        private handleSelect;
        private handleClose;
        render(): any;
        private renderNav;
    }
}
declare module "_100554_/l2/serviceLiveView" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import '/_100554_/l2/collabNav4Menu.js';
    export class ServiceLiveView100554 extends ServiceBase {
        private msg;
        private get liveView();
        private startInstance;
        private startServerInstance;
        private buildInstance;
        private liveViewTag?;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        connectedCallback(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
    }
}
declare module "_100554_/l2/serviceMindMap" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import { MindMapData } from "_102027_/l2/libMindMap";
    import '/_100554_/l2/widgetMindMapL4.js';
    export class ServiceMindMap100554 extends ServiceBase {
        dataJson: MindMapData | undefined;
        private actualFile;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        private showAboutThis;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private setEvents;
        private onMLSFileActionMindmap;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderDefault(): any;
        private configure;
    }
}
declare module "_100554_/l2/servicePage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/pluginExploreList" {
    import { ServiceBase } from "_102027_/l2/serviceBase";
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import '/_100554_/l2/collabInputSearch.js';
    import '/_100554_/l2/mlsFileTree.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreList extends PluginBaseModule {
        createModels(stor: mls.stor.IFileInfo): Promise<void>;
        private resizeObserver;
        private myDep;
        private msg;
        service: ServiceBase | undefined;
        private filterByLevel;
        autoPrepare: boolean;
        mode: TModeExploreList;
        refresh: string;
        position: string;
        levelFiles: number;
        project: number;
        projectLabel: string;
        filterProject: number;
        modeView: number;
        hiddenFiles: boolean;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        history: mls.stor.IFileInfo[];
        modeFilter: string | undefined;
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        private showAdd;
        private filesInLocal;
        private setEvents;
        private onlevelChange;
        private onMLSEvents;
        connectedCallback(): void;
        disconnectedCallback(): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        renderModeList(): any;
        renderHeader(): any;
        renderHistory(): any;
        renderList(): any;
        renderFolder(): any;
        renderFolder2(files: mls.stor.IFileInfo[]): any;
        getTitleInLocalStorage(ts: mls.stor.IFileInfo, html: mls.stor.IFileInfo, less: mls.stor.IFileInfo, test: mls.stor.IFileInfo, defs: mls.stor.IFileInfo): string;
        renderLiItem(file: mls.stor.IFileInfo, index: number, inHistory: boolean): any;
        renderAddL1(): any;
        renderAddL2(): any;
        renderAddL3(): any;
        renderAddL4(): any;
        private getAllName;
        private showLoading;
        private showError;
        private closeAllMenus;
        private clickOptUndo;
        private clickOptDel;
        private clickOptOpen;
        private clickOptOpenSecurity;
        private clickOptRename;
        private clickOptClone;
        private cloneFile;
        private renameFile;
        private fireEventsDetails;
        private fireEvents;
        private createModel;
        private fireEventThisProject;
        private fireEventLoadProject;
        private changeListTimeout;
        changeList(time?: number): void;
        private extensionLevel;
        private levelByLevel;
        private init;
        private setLastFilter;
        private getMyFileInElement;
        private clickGroupHidden;
        private changeSelectProject;
        private changeHiddenFiles;
        private changeModeOrder;
        private inFilter;
        private timeFilterChange;
        private searchTerm;
        private filterLiChange;
        private getFiles;
        private filterArrayHistory;
        private validFileByLevel;
        private getFilesProject;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private getFileHistory;
        private isValidNewName;
        private initObserverResize;
        private saveLocalStorageLastOpen;
        private delAllByFolders;
        private loadLastPreference;
        private getLastModeFilter;
        private setLastPreference;
    }
    type TModeExploreList = 'list' | 'addL1' | 'addL2' | 'addL3' | 'addL4';
}
declare module "../l2/pluginPageNavigation" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    export class PluginNavigationRenderOrganism extends PluginBaseModule {
        private msg;
        private atributeBase;
        private elPreviewL4;
        nodes: IInfoElChildren[];
        constructor();
        private domNavigator?;
        private setEvents;
        private onL4EditEvents;
        private onSelect;
        private onNavigation;
        private onlevelChange;
        activeId: string;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        createNavigation(array: IInfoElChildren[]): any;
        renderItemTree(item: IInfoElChildren, idx: string, parentArray?: IInfoElChildren[]): any;
        forceUpdate(): void;
        private openCollabMessage;
        private getActualFileL4;
        private getComponents;
        private getComponents2;
        private selectItem;
        private clickGroupHidden;
        private delEl;
        private goToImprove;
        private dispatchEventGlobalStyle;
        private editEl;
        private onMouseover;
        private onMouseout;
        private setElPreview;
        private slugToTitle;
        private dragItem?;
        private dragParentArray?;
        private dropPosition;
        private dragOverTarget?;
        private onDragStart;
        private onTouchStart;
        private onTouchEnd;
        private findParentArray;
        private onTouchMove;
        private onDragOver;
        private configOverEvent;
        private onDragLeave;
        private onDrop;
        private onDragEnd;
        private isDescendant;
        private prepareHTMLAndSync;
        private goToL2;
    }
    interface IInfoElChildren {
        el: HTMLElement | null;
        elDomNavigator: HTMLElement | null;
        id: string;
        isOrganism: boolean;
        tagName: string;
        children: IInfoElChildren[];
    }
}
declare module "_100554_/l2/servicePage" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "/_100554_/l2/pluginPrototypeImprove.js";
    import "/_100554_/l2/pluginExploreList.js";
    import "/_100554_/l2/pluginPageNavigation.js";
    export class ServicePage100554 extends ServiceBase {
        constructor();
        private msg;
        activeTab: ITabType;
        previousTabIndex: number;
        path: string;
        details: IService;
        onClickMain(op: string): void;
        onClickTabsNavigation(index: number, oldEl: HTMLElement, newEl: HTMLElement): void;
        onClickTabs(index: number): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private showAboutThis;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private previousTab;
        renderContent(): any;
        renderNavigation(): any;
        renderExplorer(): any;
        renderImprove(): any;
        private onFileAction;
        private onSelectItemNavigation;
        private onL4EditEvents;
        private onOpenL3;
    }
    export interface IWCDParams {
        level: number;
        position: 'left' | 'right';
        wdcPath: string;
        op: ITabType;
    }
    export type ITabType = 'icExplorer' | 'icNavigation' | 'icImprove';
}
declare module "_100554_/l2/servicePreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabConsole" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class CollabConsole100554 extends StateLitElement {
        logs: Array<{
            type: string;
            message: string;
        }>;
        height: string;
        mode: 'enabled' | 'disabled';
        scope: Window & typeof globalThis;
        private oldLog?;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private changeMode;
        private interceptConsole;
        addLog(type: string, args: any): void;
        render(): any;
    }
}
declare module "../l2/previewModeMinimum" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export class PreviewModeMinimum {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        private mountJS;
    }
}
declare module "_102027_/l2/previewBase" {
    export abstract class PreviewModeBase {
        protected level: string | undefined;
        protected iFrame: HTMLIFrameElement | undefined;
        protected isService: boolean;
        protected storFile: mls.stor.IFileInfo | undefined;
        constructor(_iFrame: HTMLIFrameElement, _level: string, _isService: boolean, _storFile: mls.stor.IFileInfo);
        abstract init(): Promise<void>;
    }
}
declare module "../l2/servicePreviewView" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class ServicePreviewView extends StateLitElement {
        infoIca: any;
        private msg;
        private file;
        private models;
        father: any;
        page: string;
        mode: string;
        lang: string;
        level: string;
        isDsComponent: boolean;
        watch: boolean;
        stylechanged: string;
        actualtheme: string;
        error: string;
        lastCompiledUrl: string;
        widthP: string;
        heightP: string;
        private setEventsCollab;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        render(): any;
        renderError(): any;
        renderPreview(): any;
        updated(changedProperties: any): void;
        private onWidgetActionEvents;
        private selectIdinPreview;
        private findElementsStartingWithIca;
        private fireChangeICA;
        private changeLevelIca;
        private addStyles;
        private injected;
        private load;
        private init;
        private pending;
        private setMessage;
        private setTheme;
        private setDevice;
        private setMyFile;
        private createModel;
        private lastHTML;
        private isService;
        private checkIfIsService;
        private setHtml;
        private setHtml2;
        private getPreviewConfigByProject;
        private setHtmlByLevel;
        private getFileContent;
        private modeSinglePage;
        private modeMinimum;
        private modeByProjectConfig;
        private addGlobalCss;
        private mountTokens;
        private removeOlderTokens;
        private getIdTokens;
        private changeWidthP;
        private changeHeightP;
        private timeShow;
        private showLoader;
        cleanTree(): string;
        private cleanTree2;
        private cleanTree3;
        private fireTesting;
        private getTesting;
        private setTesting;
        private removerTesting;
    }
}
declare module "../l2/pluginPreviewResultJs" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "../l2/pluginPreviewResultTestJs" {
    import { PluginBaseModule } from '_100554_/l2/pluginBaseModule';
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdTestJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100554_/l2/servicePreview" {
    import { ServiceBase, IService, IServiceMenu } from "_102027_/l2/serviceBase";
    import '/_100554_/l2/collabConsole.js';
    import '/_100554_/l2/collabResultTest.js';
    import '/_100554_/l2/servicePreviewView.js';
    import "_102025_/l2/collabMessagesPrompt";
    import '/_100554_/l2/collabSpliterVerticalVarFixed.js';
    import '/_100554_/l2/collabSpliterHorizontalVarFixed.js';
    export class ServicePreview100554 extends ServiceBase {
        itens: any;
        msize: string;
        error: string;
        watch: boolean;
        enabledConsole: boolean;
        enabledTest: boolean;
        light: boolean;
        lang: string;
        page: string;
        previewContent: HTMLElement | undefined;
        private msg;
        private threadCache;
        private tasksInProgress;
        private themesByModule;
        private lastMode;
        private lastModePreview;
        private lastLevel;
        private elPreview;
        private themes;
        private actualTheme;
        private _ed1;
        private monacoeditor;
        private languages;
        private timeEvent;
        get confE(): string;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        onClickTools(op: string): void;
        actButton(op: string): Promise<boolean>;
        onClickTitle: () => void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private changeTools;
        private changeToolsLevel3;
        private elEditL3;
        private toogleEditTextL3;
        private setEvents;
        private onL3EditEvents;
        private onActiveModeEdit;
        private onReloader;
        private lastStatusHasError;
        private onStyleChanged;
        private onLevelChange;
        private onTsTestChanged;
        private actualFile;
        private onMLSFileAction;
        private onOpenLink;
        handleSend(value: string, opt: {
            isSpecialMention: boolean;
            agentName: string;
        }): Promise<void>;
        private onTaskChange;
        private updateLoadingToFalseIfNoTasksRunning;
        private fireCollab;
        private cancelEditL3;
        private configureButtonsRight;
        private showEditorHTML;
        private showEditorHTML2;
        private pluginResultJS;
        private showResultJS;
        private pluginResultTestJS;
        private showResultTestJS;
        private showAboutThis;
        private getIframePreviewHTML;
        private actualTestList;
        private astTSTest;
        private setTest;
        private onBtTestClick;
        private fireEventsDetails;
        private addTestResultItem;
        private runTest;
        private runAllTests;
        private onBtTestListClick;
        private deleteTest;
        private refreshAST;
        private onBtLanguageClick;
        private onBtDarkLightClick;
        private onBtThemeClick;
        private toogleWatch;
        private toogleConsole;
        private openTestResults;
        private closeTestResults;
        private onHelpClick;
        private createEditor;
        private createModelIfNeeded;
        private setModel;
        private getDarkLight;
        private setLanguages;
        private getFileModuleThemeName;
        private getModuleNameByFile;
        private setThemeByModule;
        private setTheme;
        private createTestElement;
        private fireWcdChanges;
        private getScriptTest;
        private getParam;
        private processValue;
        private preview;
        private previewL2;
        private previewByLevel;
        private clearPreview;
        private createPreview;
        private _onClickTitle;
        private setTitleByLevel;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
    }
}
declare module "_100554_/l2/servicePreviewL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabConsoleL1" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabConsoleL1100554 extends CollabLitElement {
        output: HTMLElement | undefined;
        inputBox: HTMLInputElement | undefined;
        file: string | undefined;
        firstUpdated(): void;
        render(): any;
        private onKeyDown;
        private execute;
        private configLog;
    }
}
declare module "../l2/servicePreviewL1ListServer" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "/_100554_/l2/collabConsoleL1.js";
    export class ServicePreviewL1ListServer extends CollabLitElement {
        private esbuild;
        private cacheBuild;
        iframes: Record<string, HTMLIFrameElement>;
        servers: Record<string, HTMLIFrameElement>;
        listItens: IListItem[];
        viewServer: HTMLElement | undefined;
        iframesContent: HTMLElement | undefined;
        constructor();
        render(): any;
        renderHeader(): any;
        renderList(): any;
        renderItem(item: IListItem, idx: number): any;
        private init;
        private loadEsbuild;
        private initializeEsBuild;
        private handleClickPower;
        private handleClickRestart;
        private handleClickView;
        private handleCloseView;
        private refreshRow;
        private onServer;
        private offServer;
        private restartServer;
        private createServer;
        private setHTml;
        private compileWithEsbuild;
        private getVirtualFiles;
        private getVirtualFilesPlugin;
        private mountJSImporMap;
        private mountJSBundle;
    }
    interface IListItem {
        name: string;
        server: string;
        icon: string | undefined;
    }
}
declare module "_100554_/l2/servicePreviewL1" {
    import { IService, IServiceMenu, IToolbarContent, ServiceBase } from "_102027_/l2/serviceBase";
    import "/_100554_/l2/servicePreviewL1ListServer.js";
    export class ServicePreviewL1100554 extends ServiceBase {
        private msg;
        private get liveServerView();
        private liveViewTag?;
        elContent: HTMLElement | undefined;
        error: string;
        watch: boolean;
        startServer: boolean;
        private timeEvent;
        private actualFile;
        private actualFileKey;
        private actualTheme;
        private startInstance;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        onClickTools(op: string): void;
        connectedCallback(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
    }
}
declare module "_100554_/l2/servicePreviewL1ListServer.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/servicePreviewL1ListServer" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import "/_100554_/l2/collabConsoleL1.js";
    export class ServicePreviewL1ListServer extends CollabLitElement {
        private esbuild;
        private cacheBuild;
        iframes: Record<string, HTMLIFrameElement>;
        servers: Record<string, HTMLIFrameElement>;
        listItens: IListItem[];
        viewServer: HTMLElement | undefined;
        iframesContent: HTMLElement | undefined;
        constructor();
        render(): any;
        renderHeader(): any;
        renderList(): any;
        renderItem(item: IListItem, idx: number): any;
        private init;
        private loadEsbuild;
        private initializeEsBuild;
        private handleClickPower;
        private handleClickRestart;
        private handleClickView;
        private handleCloseView;
        private refreshRow;
        private onServer;
        private offServer;
        private restartServer;
        private createServer;
        private setHTml;
        private compileWithEsbuild;
        private getVirtualFiles;
        private getVirtualFilesPlugin;
        private mountJSImporMap;
        private mountJSBundle;
    }
    interface IListItem {
        name: string;
        server: string;
        icon: string | undefined;
    }
}
declare module "_100554_/l2/servicePreviewView.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/servicePreviewView" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class ServicePreviewView extends StateLitElement {
        infoIca: any;
        private msg;
        private file;
        private models;
        father: any;
        page: string;
        mode: string;
        lang: string;
        level: string;
        isDsComponent: boolean;
        watch: boolean;
        stylechanged: string;
        actualtheme: string;
        error: string;
        lastCompiledUrl: string;
        widthP: string;
        heightP: string;
        private setEventsCollab;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        render(): any;
        renderError(): any;
        renderPreview(): any;
        updated(changedProperties: any): void;
        private onWidgetActionEvents;
        private selectIdinPreview;
        private findElementsStartingWithIca;
        private fireChangeICA;
        private changeLevelIca;
        private addStyles;
        private injected;
        private load;
        private init;
        private pending;
        private setMessage;
        private setTheme;
        private setDevice;
        private setMyFile;
        private createModel;
        private lastHTML;
        private isService;
        private checkIfIsService;
        private setHtml;
        private setHtml2;
        private getPreviewConfigByProject;
        private setHtmlByLevel;
        private getFileContent;
        private modeSinglePage;
        private modeMinimum;
        private modeByProjectConfig;
        private addGlobalCss;
        private mountTokens;
        private removeOlderTokens;
        private getIdTokens;
        private changeWidthP;
        private changeHeightP;
        private timeShow;
        private showLoader;
        cleanTree(): string;
        private cleanTree2;
        private cleanTree3;
        private fireTesting;
        private getTesting;
        private setTesting;
        private removerTesting;
    }
}
declare module "_100554_/l2/serviceProduct.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceProduct" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceProduct extends ServiceBase {
        private resizeObserver;
        service: ServiceBase | undefined;
        refresh: string;
        private msg;
        levelFiles: number;
        project: number;
        filterProject: number;
        projectLabel: string;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        activeTab: string;
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        menu: IServiceMenu;
        private showAboutThis;
        private onlevelChange;
        connectedCallback(): void;
        disconnectedCallback(): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderModeList(): any;
        renderHeader(): any;
        renderList(): any;
        renderLiItem(file: mls.stor.IFileInfo, index: number): any;
        private getAllName;
        private showLoading;
        private showError;
        private clickOptOpen;
        private fireEvents;
        private changeListTimeout;
        changeList(time?: number): void;
        private init;
        private getMyFileInElement;
        private inFilter;
        private timeFilterChange;
        private filterLiChange;
        private getFiles;
        private validFileByLevel;
        private getFilesProject;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private initObserverResize;
    }
}
declare module "_100554_/l2/serviceProject.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/collabPanel" {
    import '/_100554_/l2/collabPanelItem.js';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class CollabPanel extends CollabLitElement {
        detail: HTMLDetailsElement | undefined;
        open: boolean;
        icon?: any;
        myData: IPluginMenuAction[];
        createRenderRoot(): this;
        render(): any;
        renderItem(item: IPluginMenuAction, index: number): any;
        private changeSummary;
        private minus;
        private plus;
    }
    interface IPluginMenuAction extends mls.plugin.MenuAction {
        mode: 'html' | 'tag';
    }
}
declare module "_100554_/l2/serviceProject" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceProject100554 extends ServiceBase {
        private baseProject;
        private msg;
        activeTab: IScenery;
        explories: mls.plugin.MenuAction[];
        projectDiv: HTMLDivElement | undefined;
        firstDetails: HTMLDetailsExplore | undefined;
        allContainers: HTMLDivElement[] | undefined;
        private myData;
        private lastActiveTabByLevel;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        private getMenuTabsByLevel;
        menu: IServiceMenu;
        private lastLevel;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private showAboutThis;
        firstUpdated(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        private renderContent;
        private renderExplore;
        private renderShowCase;
        private renderAdmin;
        private renderPlugin;
        private renderPanel;
        private refreshPlugins;
        private updateIconsByLevel;
        private fireEventClose;
        private handleDetailExplorieClick;
        private getExploreData;
        private handleAddNewPlugin;
        private pluginsList;
        private groupPluginsByCategory;
        private loadHelpPage;
        private setMyData;
    }
    type IScenery = 'Explore' | 'ShowCase' | 'Admin' | 'Plugins';
    interface HTMLDetailsExplore extends HTMLDetailsElement {
        data: mls.plugin.MenuAction;
    }
}
declare module "_100554_/l2/serviceSave.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/saveAddBranch" {
    import { LitElement } from 'lit';
    export const initServiceSaveaddBranch: () => void;
    export class ServiceSaveAddBRanch extends LitElement {
        hint: string | undefined;
        callBack: Function | undefined;
        private owner;
        private repo;
        private branch;
        private branchMain;
        private listForks;
        private error;
        private driver;
        private mode;
        connectedCallback(): void;
        render(): any;
        renderModeList(): any;
        renderModeAdd(): any;
        renderBranchs(): any;
        renderForks(): any;
        renderItem(obj: {
            name: string;
        }, index: number): any;
        renderItemFork(obj: mls.stor.others.IFork, index: number): any;
        private init;
        private cancel;
        private addClick;
        private addBranch;
        private addNewBranch;
        private getInfosRepo;
        private setItem;
        private setItemFork;
        static styles: any;
    }
}
declare module "../l2/pluginCreateProjectLocalToDriver" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    import '/_100554_/l2/pluginNewProjectLog.js';
    export class PluginCreateProject extends CollabLitElement {
        private msg;
        private selectedProvider?;
        private githubConnected;
        private gitlabConnected;
        private errorMessage;
        actualOrgs: mls.stor.others.IOrg[];
        actualTeams: string[];
        orgSelected: boolean;
        isLoadingOrgs: boolean;
        activeScenerie: IScenerie;
        logs: ILogs[];
        errorName: string;
        errorOrg: string;
        logsContainer: HTMLDivElement | undefined;
        progress: HTMLDivElement | undefined;
        form: HTMLFormElement | undefined;
        private instanceDriver;
        private login;
        private secret;
        private orgName;
        private projectLocalNumber;
        private newProjectName;
        private newProjectNumber;
        private newProjectTeam;
        private newProjectVisibility;
        private NEWREPONAME;
        private VALIDADEFILE;
        private drivers;
        private urls;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private handleSelect;
        private handleConnect;
        private handleContinue;
        private loadOrgsByDriver;
        private getOrgsByUser;
        private onOrgChanged;
        private onRefreshOrgsClick;
        private loadTeamByOrg;
        private getLoginUser;
        private addLog;
        private setProgress;
        private setProgressError;
        private setProgressFinished;
        private changeStatusLastLog;
        private getUniquePassword;
        private toogleForm;
        private sleep;
        private onCancelStep2;
        private tryItem;
        private setPermissionAction;
        private setVariableAction;
        private createInitialReadMe;
        private createInitialBuildFile;
        private createInitialPackageFile;
        private createInitialTSConfigFile;
        private createPrjInfo;
        private addTempObject;
        private addFileInfoItem;
        private migrateAllFiles;
        private migrateFile;
        private prepareToAddFileInfo;
        private deleteOldFiles;
        private migrateLocalFiles;
        private replaceSpecificProjectId;
        private createProjecInCollab;
        private validateForm;
        private onCreateProjectClickTest;
        private onCreateProjectClick;
        private setProjectActual;
        private setOrgActual;
        private deleteLastOpenedFileOnLocalStorage;
        private renderSelectProvider;
        private renderCreateProject;
        private renderLogs;
        render(): any;
        renderScenaries(): any;
    }
    interface ILogs {
        pre: string;
        log: string;
        status: string;
    }
    type IScenerie = 'select' | 'form';
}
declare module "_100554_/l2/serviceSave" {
    import { ServiceBase, IService, IServiceMenu } from "_102027_/l2/serviceBase";
    import '/_100554_/l2/pluginCreateProjectLocalToDriver.js';
    export class ServiceSave extends ServiceBase {
        private myMessage;
        private mainowner;
        private mainrepo;
        private mainbranch;
        private owner;
        private repo;
        private branch;
        private scenery;
        private exceededLimit;
        freeToSave: {
            ts: boolean;
            less: boolean;
            hasDS: boolean;
        };
        isFreeToSave: boolean;
        itens: IDefItem | undefined;
        otherProjects: Record<string, Record<string, string[]>>;
        error: string;
        totFileSize: string;
        createRenderRoot(): this;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onLevelchange;
        private onMLSEvents;
        private onFreeToSave;
        private isServiceVisible;
        private verifyExitFileChanged;
        connectedCallback(): void;
        render(): any;
        renderBlockScenery(): any;
        renderHeader(): any;
        renderNoItens(): any;
        renderOthersProjects(): any;
        renderOthersProjectsItens(project: number): any;
        renderItensOtherProjects(project: number, path: string): any;
        renderItens(): any;
        renderProject(project: string, index: number): any;
        renderLevels(level: string, project: string, indexP: number, index: number): any;
        renderFilesDefault(file: string, level: string, project: string, indexPP: number, indexP: number, index: number): any;
        renderItem(item: Iitem, indexP: number, indexL: number, indexM: number, index: number, forceError: boolean): any;
        renderAuxActionsItem(item: Iitem): any;
        private clickHistory;
        private init;
        private initInfoProject;
        private showLoader;
        private showBranche;
        private setInfos;
        private getOtherProjects;
        private setProjectLevelShortName;
        private oIcon;
        private fromToExtension;
        private configItem;
        private openMeList;
        private clickSetValueAllChilds;
        private setValueAllChilds;
        private timeSumTotal;
        private clickVerifyStatusFather;
        private sumTotalSize;
        private verifyStatusFather;
        private updateList;
        private fireOnPullrequest;
        private createFork;
        private forceSaveL5ProjectFile;
        private arrayRollback;
        private inSaving;
        private onSave;
        private verifyNeedSelectDS;
        private afterSave;
        private onSavenewPullrequest;
        private isRemovedFork;
        private fireCreateForkOrUpdate;
        private removeFork;
        private fireCreateNewBranch;
        private firePullrequest;
        private onSave_withOutPullRequest;
        private backChecked;
        private veriFyPermission;
        private clearLocalHIstoryCurrentInfoDriver;
        private setLocalHIstoryCurrentInfoDriver;
        private getLocalHIstoryCurrentInfoDriver;
        private getAllFileToSave;
        private onSave_old;
        private afterUpdate;
        private uppVersionAfterSave;
        private deleteFile;
        private fireEvents;
        private fireEventsDetails;
        private freeToSaveProjectAndDs;
        private undoFile;
        private removeFileByInfoImmutable;
        private forceSync;
        private STORAGE_KEY;
        private getAllUserOpenedFiles;
    }
    interface IDefItem {
        [key: number]: IDefItemLevel;
    }
    interface IDefItemLevel {
        [key: number]: Ifile;
    }
    interface Ifile {
        [key: string]: Iitem[];
    }
    interface Iitem {
        file: mls.stor.IFileInfo;
        text: string;
        span: string;
        onlyFather: boolean;
        disabled: boolean;
        errorLocal: boolean;
        modelIsDispose: boolean;
    }
}
declare module "_100554_/l2/serviceSource.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceSource" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import { LessCSS } from "_100554_/l2/lessCSS";
    import '/_100554_/l2/collabSpliterVerticalVarFixed.js';
    import '/_100554_/l2/collabSpliterHorizontalVarFixed.js';
    import '/_100554_/l2/cssHelperIndex.js';
    import "_102027_/l2/collabMonacoEditor";
    export class ServiceSource100554 extends ServiceBase {
        constructor();
        private baseProject;
        msize: string;
        panelRightOpened: boolean;
        activeModels: mls.editor.IModels | undefined;
        isModeHistory: boolean;
        mode: IModes;
        textOverlayLoading: string;
        currentHistorySourceWithoutSave: string | undefined;
        previousHistorySourceWithoutSave: string | undefined;
        currentHistorySource: string | undefined;
        previousHistorySource: string | undefined;
        historyLanguage: 'typescript' | 'html' | 'less' | 'defs';
        selectedMode: 'icTs' | 'icStyle' | 'icHTML' | 'icTest' | 'icDefs' | 'History' | undefined;
        lockMap: Map<string, boolean>;
        private MINWIDTHTPANELRIGHT;
        lessCSS: LessCSS | undefined;
        private viewState;
        private msg;
        private modeToExt;
        onClickMain(op: string): void;
        onClickTabs: (op: number) => void;
        private readonly tabConfig;
        private readonly opModelMap;
        private ensureAndActivateModel;
        private ensureStorFileExists;
        private refreshActiveModels;
        private activateModelForOp;
        private createModelIfNeedWithOutActiveModel;
        onClickTitle: () => void;
        onClickTools(op: string): void;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        private openActualL2;
        inCreate: Record<string, Promise<void> | undefined>;
        getEditorValue(): string;
        setEditorValue(val: string): boolean;
        setEditorValueByLineTs(val: string, line: number): boolean;
        setEditorValueByLineHtml(val: string, line: number): boolean;
        replaceEditorLineHTML(val: string, line: number): boolean;
        searchLineByStringTs(search: string): number | undefined;
        goToLine(line: number): void;
        setEditorHTMLValue(val: string): boolean;
        getEditorHTMLValue(): string;
        setValueInModeKeepingUndo(model: monaco.editor.ITextModel, val: string, checkFirstLine: boolean): void;
        private setValueInModelInSpecificLine;
        private replaceLineValueInModelInSpecificLine;
        formatMonaco(): void;
        private editorEl;
        private editorHistoryEl;
        overlayLoading: HTMLElement | undefined;
        private verticalSpliter;
        private horizontalSpliter;
        last: mls.IActual | undefined;
        _ed1: monaco.editor.IStandaloneCodeEditor | undefined;
        private _edDiff;
        private mConfEditor;
        private confE2;
        get confE(): string;
        get confETS(): string;
        get confEJS(): string;
        private saveViewState;
        private restaureViewState;
        private toogleHistory;
        private getHistories;
        private openRepo;
        private showHistory;
        private showHistorie2;
        private showPageTheme;
        private showMonacoReset;
        private showConfEditor;
        private onMonacoEvents;
        private goToPosition;
        private mapExt;
        private onMLSEvents;
        private lessChangedEditor;
        private fireEditorEvents;
        private openFiles;
        private activeThisService;
        private closeMenu;
        delay(ms: number): Promise<void>;
        private showThisModel;
        private initProviders;
        private initModelStyle;
        private showActiveModel;
        private initMonaco;
        private monacoGlobalInitialized;
        private initMonaco_GlobalEditor;
        private timeHtmlChangeCursor;
        private lastIdSelected;
        private lastLineNumber;
        private initMonaco_Editor;
        private actionAgentFix;
        private addFixAction;
        private lockEditorForFile;
        private isEditorLocked;
        private unlockEditorForFile;
        private removeFixAction;
        private updateActionBasedOnError;
        private getActualL2File;
        private fireAgentFix;
        private toogleOverlayLoading;
        private initMonaco_EditorDiff;
        private setHistories;
        private createOrGetModelHistory;
        private extractIdValue;
        private loadMonacoConfigurations;
        private getUri;
        private setModelConfEditor;
        private createModelConf;
        timeout_compileConfEditor: number;
        private compileSrcEditor;
        private loadConfEditorFromLocalStorage;
        private saveConfEditorToLocalStorage;
        private getActualTheme;
        private loadMonacoThemeFromLocalStorage;
        private saveMonacoGlobalThemeToLS;
        private getConfEditorToTypescript;
        private setConfEditorFromJavascript;
        private updateMonacoConfigutarions;
        private updateMonacoGlobalTheme;
        private getGlobalPageSetTHeme;
        private _formatIfNeeded;
        private getPosition;
        private getLocalStorageInfo;
        private saveLocalStorageInfo;
        private isReadOnlyArea;
        private getIntervalLinesReadOnly;
        private updatedMSizeEditor;
        private toogleIconsError;
        private currentReviewDecorationIds;
        private highlightReviewLines;
        private changeMode;
        private saveLocalStorageLastOpen;
        private openLastFile;
        getActualRef(): string;
        private lastOrigin;
        private onWidgetActionEvents;
        private selectLineinHTML;
        private registerProviderHTML;
        private isHTMLSystemChange;
        private syncDom;
        handleIcaStateChange(_key: string, _value: any): void;
        updated(changedProperties: any): void;
        connectedCallback(): void;
        firstUpdated(changedProperties: any): void;
        render(): any;
    }
    export type FormattableModel = monaco.editor.ITextModel & {
        needFormat: boolean;
    };
    type IModes = 'icTs' | 'icStyle' | 'icHTML' | 'icTest' | 'icDefs';
}
declare module "_100554_/l2/serviceSourceL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/agentFix" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateFiles(context: mls.msg.ExecutionContext, result: IDataResult): Promise<void>;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
}
declare module "_100554_/l2/serviceSourceL1" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import '/_100554_/l2/collabSpliterVerticalVarFixed.js';
    import '/_100554_/l2/collabSpliterHorizontalVarFixed.js';
    import '/_100554_/l2/cssHelperIndex.js';
    import "_102027_/l2/collabMonacoEditor";
    export class ServiceSource100554 extends ServiceBase {
        constructor();
        private baseProject;
        msize: string;
        activeModels: mls.editor.IModels | undefined;
        isModeHistory: boolean;
        mode: IModes;
        textOverlayLoading: string;
        currentHistorySourceWithoutSave: string | undefined;
        previousHistorySourceWithoutSave: string | undefined;
        currentHistorySource: string | undefined;
        previousHistorySource: string | undefined;
        historyLanguage: 'typescript' | 'html' | 'less' | 'defs';
        selectedMode: 'icTs' | 'icDefs' | 'History' | undefined;
        lockMap: Map<string, boolean>;
        private viewState;
        private msg;
        private modeToExt;
        onClickMain(op: string): void;
        onClickTabs: (op: number) => void;
        private createModelIfNeed;
        onClickTitle: () => void;
        onClickTools(op: string): void;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        private openActualL2;
        inCreate: Record<string, Promise<void> | undefined>;
        getEditorValue(): string;
        formatMonaco(): void;
        private editorEl;
        private editorHistoryEl;
        overlayLoading: HTMLElement | undefined;
        private verticalSpliter;
        private horizontalSpliter;
        last: mls.IActual | undefined;
        _ed1: monaco.editor.IStandaloneCodeEditor | undefined;
        private _edDiff;
        private mConfEditor;
        private confE2;
        get confE(): string;
        get confETS(): string;
        get confEJS(): string;
        private saveViewState;
        private restaureViewState;
        private toogleHistory;
        private getHistories;
        private openRepo;
        private showHistory;
        private showHistorie2;
        private mapExt;
        private onMLSEvents;
        private fireEditorEvents;
        private openFiles;
        private activeThisService;
        private closeMenu;
        delay(ms: number): Promise<void>;
        private showThisModel;
        private showActiveModel;
        private initMonaco;
        private monacoGlobalInitialized;
        private initMonaco_GlobalEditor;
        private initMonaco_Editor;
        private actionAgentFix;
        private addFixAction;
        private lockEditorForFile;
        private isEditorLocked;
        private unlockEditorForFile;
        private removeFixAction;
        private updateActionBasedOnError;
        private getActualL1File;
        private fireAgentFix;
        private toogleOverlayLoading;
        private initMonaco_EditorDiff;
        private setHistories;
        private createOrGetModelHistory;
        private loadMonacoConfigurations;
        private getUri;
        private createModel;
        private createModelConf;
        timeout_compileConfEditor: number;
        private compileSrcEditor;
        private loadConfEditorFromLocalStorage;
        private saveConfEditorToLocalStorage;
        private setConfEditorFromJavascript;
        private updateMonacoConfigutarions;
        private updateMonacoGlobalTheme;
        private _formatIfNeeded;
        private getPosition;
        private getLocalStorageInfo;
        private saveLocalStorageInfo;
        private updatedMSizeEditor;
        private toogleIconsError;
        private currentReviewDecorationIds;
        private highlightReviewLines;
        private changeMode;
        private saveLocalStorageLastOpen;
        private openLastFile;
        getActualRef(): string;
        updated(changedProperties: any): void;
        connectedCallback(): void;
        firstUpdated(changedProperties: any): void;
        render(): any;
    }
    export type FormattableModel = monaco.editor.ITextModel & {
        needFormat: boolean;
    };
    type IModes = 'icTs' | 'icDefs';
}
declare module "_100554_/l2/serviceUnit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceUnit" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceUnit extends ServiceBase {
        private baseProject;
        private msg;
        activeTab: IScenery;
        explories: mls.plugin.MenuAction[];
        projectDiv: HTMLDivElement | undefined;
        firstDetails: HTMLDetailsExplore | undefined;
        allContainers: HTMLDivElement[] | undefined;
        private myData;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        menu: IServiceMenu;
        private lastLevel;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private showAboutThis;
        firstUpdated(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        private renderContent;
        private renderExplore;
        private renderShowCase;
        private refreshPlugins;
        private fireEventClose;
        private handleDetailExplorieClick;
        private getExploreData;
        private loadHelpPage;
        private setMyData;
    }
    type IScenery = 'Explore' | 'ShowCase';
    interface HTMLDetailsExplore extends HTMLDetailsElement {
        data: mls.plugin.MenuAction;
    }
}
declare module "_100554_/l2/serviceUser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceUser" {
    import { LitElement } from 'lit';
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import '/_100554_/l2/collabPanel.js';
    import '/_100554_/l2/collabPanelItem.js';
    export class ServiceUser100554 extends ServiceBase {
        private msg;
        private data;
        activeTab: IScenery;
        plugin: string;
        collabPanel: LitElement | undefined;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(op: number): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        updated(changedP: any): Promise<void>;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderContent;
        private renderSettings;
        private renderPanel;
        private baseProject;
        private setMyData;
    }
    type IScenery = 'Settings';
}
declare module "_100554_/l2/testCoachMarks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testCoachMarks" {
    import { CollabPageElement } from '_100554_/l2/collabPageElement';
    export class TestCoachMarks100554 extends CollabPageElement {
        initPage(): void;
        private setCoach;
    }
}
declare module "_100554_/l2/testMindMap.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testMindMap" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class TestMindMap100554 extends StateLitElement {
        result: any;
        firstUpdated(): Promise<void>;
        render(): any;
    }
}
declare module "_100554_/l2/testScenario1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testScenario1" {
    import { IScenaryDetails } from '_102029_/l2/collabLitElement';
    export function _100554_testScenario1_getScenaryDetails(): IScenaryDetails;
}
declare module "_100554_/l2/testScenario2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testScenario2" {
    import { IScenaryDetails } from '_102029_/l2/collabLitElement';
    export function _100554_testScenario2_getScenaryDetails(): IScenaryDetails;
}
declare module "_100554_/l2/testState.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testState" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class TestState100554 extends StateLitElement {
        name: string;
        render(): any;
    }
}
declare module "_100554_/l2/toolFilterFilesL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/toolFilterFilesL2" {
    import { ITool } from "_102027_/l2/aiAgentBase";
    export function createTool(): ITool;
}
declare module "_100554_/l2/toolMortgageCalculator.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/toolMortgageCalculator" {
    import { ITool } from "_102027_/l2/aiAgentBase";
    export function createTool(): ITool;
}
declare module "_100554_/l2/tsTestAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/tsTestAST" {
    import { MonacoDriver } from "_100554_/l2/tsTestMonaco";
    /**
     * Represents an AST node.
     * @typedef {Object} ASTNode
     * @property {string} type - The type of the AST node (e.g., 'Program', 'FunctionDeclaration').
     * @property {string} [name] - The name of the node (e.g., function name).
     * @property {any} [value] - The value associated with the node (e.g., function body or array content).
     * @property {ASTNode[]} [children] - An array of child nodes.
     * @property {number} [startLine] - The start line of the node in the source code.
     * @property {number} [endLine] - The end line of the node in the source code.
     */
    type ASTNode = {
        type: string;
        name?: string;
        value?: any;
        children?: ASTNode[];
        startLine: number;
        endLine: number;
    };
    /**
     * Class to parse a TypeScript test file and generate an AST.
     */
    export class TsTestAst {
        ast: ASTNode | undefined;
        modelTest: mls.editor.IModelTest | undefined;
        monacoDriver: MonacoDriver;
        editor: monaco.editor.IStandaloneCodeEditor;
        /**
         * Creates an instance of TsTestAst.
         * @param {mls.editor.IModelTest} modelTest - The Monaco editor model test instance.
         */
        constructor(modelTest: mls.editor.IModelTest, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * Parses the TypeScript code from the model test and returns the AST.
         * @returns {ASTNode | undefined} The generated AST, or undefined if parsing fails.
         */
        parse: () => ASTNode | undefined;
        /**
         * Gets the integrations from the parsed AST.
         * @returns {any[]} The integrations parsed from the AST.
         */
        getIntegrations(): ICANIntegration[];
        /**
         * Gets the tests from the parsed AST.
         * @returns {any[]} The tests parsed from the AST.
         */
        getTests(): ICANTest[];
        /**
         * Adds a new test to the AST and inserts it into the test array in the Monaco editor.
         * @param {ICANTest} test - The test object to be added.
         * @param {Function} fcTest - The test function to be associated with the test.
         * @returns {boolean} True if the test was added successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        addTest(test: ICANTest, fcTest: Function | string): boolean;
        /**
         * Deletes a test from the AST and updates the Monaco editor.
         * @param {String} testName - The test name to be removed.
         * @returns {boolean} True if the test was removed successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        deleteTest(testName: string, index?: number): boolean;
        /**
         * Navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        goToTest(testName: string): boolean;
        /**
         * Retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        getTestInfo(functionName: string, paramsIndex?: number): ITestInfo;
        /**
        * Executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        runTest(testName: string, paramsIndex?: number): Promise<string>;
        /**
         * Adds a new integration to the test file.
         * @param {ICANIntegration} integration - The integration to be added.
         * @param {Function} fc - The function associated with the integration.
         * @returns {boolean} Returns true if the integration was successfully added.
         */
        addIntegration(integration: ICANIntegration, fc: Function | string): boolean;
        /**
         * Parses TypeScript code into an AST.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode} The generated AST from the code.
         */
        private parseTypeScript;
        /**
         * Parses imports from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the imports in the code.
         */
        private parseImports;
        /**
         * Parses arrays from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the arrays in the code.
         */
        private parseArrays;
        /**
         * Parses function names from TypeScript code and returns an array of function declarations as AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing function declarations in the code.
         */
        private parseFunctionNames;
        /**
         * Parses and retrieves the integrations from the AST's children.
         * @returns {ICANIntegration[]} The parsed integrations.
         * @throws {Error} Throws an error if parsing the integrations fails.
         */
        private _getIntegrations;
        /**
         * Parses and retrieves the tests from the AST's children.
         * @returns {ICANTest[]} The parsed tests.
         * @throws {Error} Throws an error if parsing the tests fails.
         */
        private _getTests;
        /**
         * Internal method to add a test to the AST and update the Monaco editor.
         * @param {ICANTest} test - The test object to add.
         * @param {Function} fcTest - The test function to add.
         * @returns {boolean} True if the test was successfully added.
         * @throws {Error} Throws an error if the test already exists or AST information is missing.
         */
        private _addTest;
        /**
         * Internal method to deletes a test from the AST and updates the Monaco editor.
         * @param {string} testName - The name of the test to delete.
         * @throws {Error} Throws an error if the test does not exist or deletion fails.
         */
        private _deleteTest2;
        /**
     * Internal method to delete a test from the AST and update the Monaco editor.
     * @param {string} functionName - The name of the test to delete.
     * @param {number} [index] - (Optional) The index of the parameter to remove.
     * @throws {Error} Throws an error if the test does not exist or deletion fails.
     */
        private _deleteTest;
        /**
        * Internal method to executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        private _runTest;
        /**
         * Internal method to retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        private _getTestInfo;
        /**
         * Internal method to navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        private _goToTest;
        /**
         * Intenal method to delete a function on the AST and updates the Monaco editor.
         * @param {String} fcName - The function name to be deleted.
         * @returns {boolean} True if the function was successfully deleted.
         * @throws {Error} Throws an error if the test model is invalid.
         */
        private _deleteFunction;
        /**
         * Adds a new integration to the AST and updates the Monaco editor.
         * @param {ICANIntegrations} integration - The integration object to add.
         * @param {Function} fcIntegration - The integration function to add.
         * @throws {Error} Throws an error if the integration already exists or if AST information is missing.
         */
        private _addIntegration;
        /**
         * Deletes an integration from the AST and updates the Monaco editor.
         * @param {string} integrationName - The name of the integration to delete.
         * @throws {Error} Throws an error if the integration does not exist or deletion fails.
         */
        private _deleteIntegration;
        /**
         * Adds a new function to the AST and updates the Monaco editor.
         * @param {Function} fc - The function to add.
         * @returns {boolean} True if the function was successfully added.
         * @throws {Error} Throws an error if AST information is missing or the test model is invalid.
         */
        private _addFunction;
        private checkImports;
        /**
         * Adds an import statement to the TypeScript code.
         * If an interval is provided, it replaces the existing import.
         * Otherwise, it inserts the import after the root startLine.
         *
         * @param {string} value - The import statement to add.
         * @param {Object} [interval] - The optional start and end line to replace.
         */
        private _addImport;
        private _formatEditor;
    }
    export interface ITestInfo {
        fileName: string;
        functionName: string;
        params: Record<string, any>;
    }
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_100554_/l2/tsTestASTTeste.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "../l2/libManagementCan" {
    /**
     * Inicializa ou atualiza o estado global em um caminho específico.
     */
    export function initState(path?: string, value?: string | object | unknown[]): void;
    /**
     * Atualiza o estado em um caminho.
     */
    export function setState(path: string, value: any): boolean;
    /**
     * Espera até que o estado em `path` seja igual a `value`.
     * Se `timeout` for 0 ou undefined, espera indefinidamente.
     */
    export function waitingState(path: string, value: any, options?: IVerifyOptions): Promise<void>;
    export function waitForNonEmptyState(path: string, options?: {
        retryInterval?: number;
        timeout?: number;
    }): Promise<string>;
    /**
     * Vigia continuamente um estado. Se ele mudar de valor, lança erro.
     * Fica rodando até chamar `unwatchState` ou `clearWatchers`.
     */
    export function watchState(path: string, expectedValue: any, options?: IVerifyOptions): void;
    /** Cancela observação de um path específico */
    export function unwatchState(path: string): void;
    /** Cancela todos os watchers ativos */
    export function clearWatchers(): void;
    /**
     * Verifica estado com timeout opcional, retornando boolean em vez de erro.
     */
    export function verifyState(path: string, value: any, options?: IVerifyOptions): Promise<boolean>;
    interface IVerifyOptions {
        timeout?: number;
        retryInterval?: number;
    }
}
declare module "_100554_/l2/tsTestASTTeste.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_100554_/l2/tsTestASTTeste" {
    import { LitElement } from 'lit';
    import { TsTestAst } from "_100554_/l2/tsTestAST";
    export class LessASTTest100554 extends LitElement {
        fileName: string;
        model1: mls.editor.IModelTest;
        fileToTest: string;
        result: string;
        render(): any;
        exeTest: () => "No find editor" | "undefined;";
        test1: (testAST: TsTestAst) => string;
        test2: (testAST: TsTestAst) => string;
        test3: (testAST: TsTestAst) => string;
        test4: (testAST: TsTestAst, title: string) => string;
        test5: (testAST: TsTestAst, description: string) => string;
        test6: (testAST: TsTestAst, name: string) => string;
    }
}
declare module "_100554_/l2/tsTestMonaco.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/tsTestMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines(model: monaco.editor.ITextModel): string[];
        replaceLines(model: monaco.editor.ITextModel, lineNrInit: number, lineNrInitEnd: number, newContent: string): boolean;
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine(model: monaco.editor.ITextModel, lineNr: number, line: string): boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine(model: monaco.editor.ITextModel, lineNr: number): boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines(model: monaco.editor.ITextModel, startLine: number, countLines: number): boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine(model: monaco.editor.ITextModel, lineNr: number, columnNr: number, newText: string): boolean;
        /**
         * Moves the editor's cursor to the specified lines, selects the text between them,
         * and scrolls the editor to bring the selection into view.
         *
         * @param {monaco.editor.ITextModel} model - The text model associated with the editor.
         * @param {number} start - The starting line number for the selection.
         * @param {number} end - The ending line number for the selection.
         *
         * @returns {void}
         */
        goTo(model: monaco.editor.ITextModel, start: number, end: number): void;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (model: monaco.editor.ITextModel) => void;
    }
}
declare module "_100554_/l2/utilsLit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/utilsLit" {
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
}
declare module "_100554_/l2/wcAuxCommand.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/wcAuxCommand" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WcAuxCommand100554 extends StateLitElement {
        private elView;
        private boundFireKeydown;
        idElView: string | undefined;
        caracter: string | undefined;
        itens: IAuxCommand[];
        createRenderRoot(): this;
        connectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
        renderGroup(item: IAuxCommand, idx: number): any;
        renderItem(item: IAuxCommandItens, idx: number): any;
        private setDefinition;
        private mouseLeave;
        private fireKeydown;
        private getElementPosition;
        private clickItem;
    }
    export interface IAuxCommand {
        group: string;
        itens: IAuxCommandItens[];
    }
    export interface IAuxCommandItens {
        label: string;
        value: string;
        icon: string;
    }
}
declare module "_100554_/l2/widgetClarificationNewWidget.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetClarificationNewWidget" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WcClarificationPlannerNewWidget100554 extends StateLitElement {
        private ICABASEPROJECT;
        data?: ClarificationData;
        error?: string;
        develpoment?: boolean;
        mode: 'readonly' | 'write';
        inputTag?: HTMLInputElement;
        widgetNameError?: HTMLInputElement;
        render(): any;
        private renderResume;
        private renderParentClass;
        private renderWidgetName;
        private renderProperties;
        private renderRequirements;
        private createTagName;
        private removeTrailingPattern;
        private createParentName;
        private handleWidgetNameInput;
        private handleTagNameChange;
        private handleParentInput;
        private handleRqVisualInput;
        private handleRqFunctionalInput;
        private handleCancel;
        private handleOk;
        private handleAction;
        private setDevelpoment;
    }
    interface ClarificationData {
        json: Clarification[] | undefined;
        taskId: string;
        stepId: number;
        clarificationMessage: string;
    }
    type Clarification = ClarificationResume | ClarificationWidgetName | ClarificationParentName | ClarificationProperties | ClarificationRequirements;
    interface ClarificationBase {
        sectionName: string;
        description: string;
    }
    interface ClarificationResume extends ClarificationBase {
    }
    interface ClarificationWidgetName extends ClarificationBase {
        widgetName: string;
        tagName: string;
    }
    interface ClarificationParentName extends ClarificationBase {
        widgetName: string;
    }
    interface ClarificationProperties extends ClarificationBase {
        properties: {
            propertyName: string;
            description: string;
            isEssencial: string;
        }[];
    }
    interface ClarificationRequirements extends ClarificationBase {
        functionalRequirements: string[];
        visualRequirements?: string[];
    }
}
declare module "_100554_/l2/widgetCollabChart.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetCollabChart" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WcEchartsPie100554 extends StateLitElement {
        data: any | undefined;
        chartTitle: string;
        framework: 'echarts';
        renderer: 'canvas' | 'svg';
        main: HTMLDivElement | undefined;
        private myChart;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        initChart(): void;
        firstUpdated(): void;
        render(): any;
    }
}
declare module "_100554_/l2/widgetDivider.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetDivider" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WcDivider100554 extends StateLitElement {
        createRenderRoot(): this;
        text: string | undefined;
        render(): any;
    }
}
declare module "_100554_/l2/widgetDividerLine.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetDividerLine" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WidgetDivider100554 extends StateLitElement {
        createRenderRoot(): this;
        text: string | undefined;
        render(): any;
    }
}
declare module "_100554_/l2/widgetEmbedsSocialMedia.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetEmbedsSocialMedia" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WcEmbedsSocialMedia100554 extends StateLitElement {
        datasource: string | undefined;
        description: string | undefined;
        url: string | undefined;
        render(): any;
        generateYouTubeEmbed(url: string): any;
        generateTwitterEmbed(url: string): any;
        loadExternalScripts(): void;
    }
}
declare module "_100554_/l2/widgetImage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetImage" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class WcImage100554 extends StateLitElement {
        src: string | undefined;
        alt: string | undefined;
        width: string | undefined;
        height: string | undefined;
        render(): any;
    }
}
declare module "_100554_/l2/widgetInputText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetInputText" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class WcInputText100554 extends CollabLitElement {
        autocapitalize: any;
        validationmessage: string | undefined;
        debounce: string | undefined;
        value: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        autocorrect: any;
        autoCapitalize: 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters' | undefined;
        input: HTMLInputElement | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_100554_/l2/widgetMindMapL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetMindMapL4" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import { MindMapSelected, MindMapData, MindMapNodeStyles, MindMapNode } from "_102027_/l2/libMindMap";
    export class WidgetMindMapL4100554 extends StateLitElement {
        private contentHeight;
        private offsetY;
        private isListMode;
        private LIST_THRESHOLD;
        private _canvasDirtyWhileHidden;
        menuOpen: boolean;
        activeDescription: string | undefined;
        currentpage: string | undefined;
        showbreadcrumb: string | undefined;
        mindMapSelected: MindMapSelected | undefined;
        mapState: MindMapData | undefined;
        nodeRadius: number;
        nodeStyles: MindMapNodeStyles;
        initialNode: string | undefined;
        breadcrumb: MindMapNode[];
        private _nodePositions;
        private _animationDelay;
        private get visibleBreadcrumb();
        render(): any;
        renderBreadcrumb(): any;
        renderMenu(): any;
        firstUpdated(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private configureMindMap;
        private _redrawCanvas;
        private _addCanvasListeners;
        private _removeCanvasListeners;
        private _animating;
        private _animatedPositions?;
        private _onCanvasClick;
        private getNodeStyle;
        /**
         * Returns the node id under the given mouse position, or undefined if none.
         */
        private getNodeIdAtPosition;
        private getRelatedNodes;
        private _hoveredNodeId?;
        private handleCanvasMouseMove;
        private toWorldCoords;
        private computeAutoZoom;
        private zoom;
        private MIN_ZOOM;
        private MAX_ZOOM;
        private drawMindMap;
        private _onWheel;
        private drawListLayout;
        private drawLabel;
        private drawIconButton;
        private openDefs;
        private _toggleMenu;
        private fromMenu;
        private _openScenario;
        private _closeDescription;
        private _brightenColor;
        /**
     * Returns a map { nodeId: {x, y} } for each node,
     * given a center nodeId and its related nodes.
     */
        private getNodePositions;
        /**
         * Returns an array of { id, from, to } for all nodes appearing in either state.
         * - from: start position (or undefined if node is new)
         * - to:   end position (or undefined if node disappears)
         */
        private prepareAnimationMap;
        /**
         * Animates all nodes from their 'from' position to 'to' in 500ms.
         * Calls a callback on each frame with current positions.
         */
        private animateTransition;
        private onSelected;
        private _pushBreadcrumb;
        private _syncBreadcrumbWithCurrent;
        private _popToBreadcrumb;
        private openFileAndNavigate;
        private _navigateInsideCurrentFile;
        private openFile;
        private pluginsMenu;
    }
}
declare module "_100554_/l2/widgetPlaygroundState.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetPlaygroundState" {
    import { LitElement } from 'lit';
    export class WidgetPlaygroundState extends LitElement {
        state: string;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private initStatePlayground;
    }
}
declare module "_100554_/l2/widgetSelect" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class WcInputText100554 extends CollabLitElement {
        autocapitalize: any;
        validationmessage: string | undefined;
        debounce: string | undefined;
        value: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        options: string | undefined;
        get _options(): any;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_100554_/l2/widgetTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetTextCode" {
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    export class WidgetTextCode extends CollabLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        firstUpdated(): void;
        render(): any;
        private onChangeText;
    }
}
declare module "_100554_/l2/agentTest/agent1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: string[];
    };
}
declare module "_100554_/l2/agentTest/agent2" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Info[];
    };
    export type Info = {
        country: string;
        briefDescription: string;
    };
}
declare module "_100554_/l2/agents/agentBackendMaterializationPlan.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agents/agentBackendMaterializationPlan" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: BackendMaterializationPlan;
    };
    export interface BackendMaterializationPlan {
        domains: Record<string, BackendMaterializationResult>;
        decisions?: MaterializationDecision[];
        warnings?: string[];
    }
    export interface BackendMaterializationResult {
        domainId: string;
        entities: MaterializedEntity[];
        commands: MaterializedCommand[];
        events: MaterializedEvent[];
        readModels?: MaterializedReadModel[];
        warnings?: string[];
        decisions?: MaterializationDecision[];
    }
    export interface MaterializedEntity {
        entityId: string;
        persistence: {
            kind: "derived" | "event-log" | string;
            storageShape: "aggregate" | "flat";
        };
        source: "existing" | "extended" | "new";
        schema: Record<string, string>;
        embedded?: string[];
    }
    export interface MaterializedCommand {
        commandId: string;
        entityId: string;
        input: Record<string, string>;
        output?: Record<string, string>;
        validatesStates?: string[];
        emitsEvents?: string[];
        rules: string[];
        actions: string[];
        execution: "sync" | "async";
    }
    export interface MaterializedEvent {
        eventId: string;
        entityId: string;
        persistence: "append-only" | "derived-only";
        payloadSchema?: Record<string, string>;
    }
    export interface MaterializedReadModel {
        modelId: string;
        sourceEvents: string[];
        fields: Record<string, string>;
        purpose: ("BI" | "llm-query")[];
        updateStrategy: "event-driven" | "scheduled";
    }
    export interface MaterializationDecision {
        type: "reuse-existing-module" | "extend-existing-module" | "override-tobe-definition" | "constraint-adjustment";
        moduleName: string;
        target: string;
        reason: string;
    }
}
declare module "_100554_/l2/agents/agentDefs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/defsAST" {
    export function parseDefsFile(source: string): {
        asis: mls.defs.AsIs;
        history: mls.defs.ChangeHistoryItem[];
        skill: string;
    };
    export function getAsis(source: string): mls.defs.AsIs;
    export function updateAsis(source: string, patch: DeepPartial<mls.defs.AsIs>): string;
    export function replaceAsis(source: string, value: mls.defs.AsIs): string;
    export function getHistory(source: string): mls.defs.ChangeHistoryItem[];
    export function addHistoryItem(source: string, item: mls.defs.ChangeHistoryItem): string;
    export function updateHistoryItem(source: string, version: number, patch: Partial<mls.defs.ChangeHistoryItem>): string;
    export function replaceHistory(source: string, value: mls.defs.ChangeHistoryItem[]): string;
    export function getSkill(source: string): string;
    export function updateSkill(source: string, value: string): string;
    type DeepPartial<T> = {
        [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
    };
    export function getMaterializeIndex(source: string): mls.defs.MaterializeIndex;
    export function replaceMaterializeIndex(source: string, value: mls.defs.MaterializeIndex): string;
    export function addMaterializeItem(source: string, item: mls.defs.MaterializeEntry): string;
    export function updateMaterializeItem(source: string, id: string, patch: Partial<mls.defs.MaterializeEntry>): string;
    export function removeMaterializeItem(source: string, id: string): string;
    export function getVariableText(source: string, varName: string): string;
    export function updateVariableText(source: string, varName: string, value: string): string;
    export function getVariableJson<T = unknown>(source: string, varName: string): T;
    export function updateVariableJson(source: string, varName: string, value: unknown): string;
}
declare module "_100554_/l2/agents/agentDefs" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getSource(file: mls.stor.IFileInfo): Promise<string>;
    export function updateDefs(defs: AsIs): Promise<void>;
    export const system1 = "\n<!-- modelType: code -->\n<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) ou nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10-->\n\nYou are a Senior Software Engineer at Collab.codes.\n\nYou will receive a user message containing:\nFILE, LANG, and a code block delimited by BEGIN_CODE and END_CODE.\n\nTask:\nGenerate an AsIsFactual JSON object that strictly follows the provided JSON schema.\n\n## Details\n[[SudoLang]]\n\n## Output format\nYou must return the object strictly as JSON\n[[OutputSection]]\n\n[[Defs1]]\n[[Defs2]]\n[[Defs3]]\n";
    export type Output = {
        type: "flexible";
        result: AsIs;
    };
    export interface AsIs {
        meta: {
            fileReference: string;
            componentType: ComponentType;
            componentScope: ComponentScope;
            executionRegions?: string[];
            languages?: string[];
            group?: string;
            /**
             * Development fidelity level, indicating the stage of development.
             * - 'draft': Initial concept, not functional.
             * - 'wireframe': Basic layout, no functionality.
             * - 'scaffold': Functional skeleton, minimal features.
             * - 'final': Fully functional, ready for production.
             */
            devFidelity?: 'draft' | 'wireframe' | 'scaffold' | 'final';
        };
        references?: {
            webComponents?: string[];
            imports?: DefsImports[];
            statesRO?: string[];
            statesRW?: string[];
            statesWO?: string[];
        };
        codeInsights?: {
            todos?: string[];
            securityWarnings?: string[];
            unusedImports?: string[];
            deadCodeBlocks?: string[];
            accessibilityIssues?: string[];
            i18nWarnings?: string[];
            performanceHints?: string[];
        };
        auth?: {
            view?: UserRole[];
            edit?: UserRole[];
            use?: UserRole[];
            restrictReason?: string;
        };
        asIs: {
            semantic: {
                generalDescription: string;
                businessCapabilities: string[];
                technicalCapabilities: string[];
                implementedFeatures: string[];
                constraints?: string[];
            };
        };
    }
    export type ComponentScope = 'appFrontEnd' | // shipped to customer application
    'appBackEnd' | // shipped to customer application
    'editor';
    export type ComponentType = 'page' | // (appFrontEnd) Full-screen view with its own route (e.g. /petshop/dashboard). Contains front-end business logic and calls back-end services.
    'organism' | // (appFrontEnd) Sections inside page. Contains front-end business logic and calls back-end services.
    'molecule' | // (appFrontEnd) reusable web component. Used inside organisms.
    'miniapp' | // (appFrontEnd) Self-contained application with its own navigation, usually one page, e.g., temperature converter, calculator.
    'pluginUI' | // (appFrontEnd) Front-end part of a plugin (buttons, widgets, config pages visible to the customer)
    'pluginSettings' | // (editor) Editor panel to configure a plugin (icon in toolbar, never shipped)
    'entity' | // (appBackEnd) data model (DB schema, ORM entity). Defines tables, fields, relations.
    'controller' | // (appBackEnd) Handles API endpoint requests: validates input and authorization, then executes the appropriate use case.
    'useCase' | // (appBackEnd) business logic unit. Encapsulates specific operations, called by controllers.
    'repository' | // (appBackEnd) data access layer. Interfaces with the database, performs CRUD operations.
    'hook' | // (appBackEnd) event handler or middleware (e.g., webhooks, auth guards).
    'editorService' | // (editor) Editor-only panel or toolbar.
    'agent' | // (editor) Specialized LLM orchestrator (prepares prompts, chains tools, etc.).
    'tool' | // (editor) Reusable function or module (e.g., data processing, integrations).
    'service' | // (editor) tool UI
    'other';
    export interface DefsImports {
        ref: string;
        dependencies?: {
            name: string;
            type?: "function" | "service" | "constant" | "interface" | "type" | "class" | "hook" | "component" | "?";
            purpose?: string;
        }[];
    }
    export type UserRole = string;
}
declare module "_100554_/l2/agents/agentGenerateAvatarSvg" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getPayload(context: mls.msg.ExecutionContext): string;
    export type Output = {
        type: "flexible";
        result: string;
    };
}
declare module "_100554_/l2/agents/agentMaterializePlugin" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getDefs(info: mls.stor.IFileInfoBase): Promise<string>;
    export function extractJSON(str: string): Record<string, any>;
    export type Output = {
        type: "flexible";
        result: MaterializationPlugin;
    };
    export interface MaterializationPlugin {
        project: number;
        shortName: string;
        folder: string;
        ts: string;
        less: string;
    }
    export function processTemplate(input: string): Promise<string>;
}
declare module "_100554_/l2/agents/collabAuraPageCommon.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agents/collabAuraPageCommon" {
    /**
     * =============================================================================
     * BACKEND BRIDGE (REAL + MOCK)
     * =============================================================================
     */
    export interface BeInvoke {
        invoke(routine: string, params: any): Promise<any>;
    }
    export function beInvoke(routine: string, requestId: number, params: any): Promise<any>;
    export function readLocal(routine: string, params: any): Promise<any>;
    export function savelocal(routine: string, params: any, result: any): Promise<void>;
    export function pluginInvoke(pluginRef: string, params: any): Promise<any>;
    export function generateId(): number;
}
