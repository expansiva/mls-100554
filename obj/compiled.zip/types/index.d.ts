declare module "_102027_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
        /**
         * Optional: render a re-openable view for one of the agent's steps (e.g. a summary/management
         * screen). When an agent implements this, the step list shows an "open" link next to "details",
         * and clicking it mounts the returned element. Unlike beforeClarificationStep, this is read/view
         * oriented and can be invoked any time (including after the step/task completed), so the screen
         * must rebuild its state from persisted artifacts rather than the live step payload.
         */
        openStepView?(agent: IAgentMeta, context: mls.msg.ExecutionContext, step: mls.msg.AIAgentStep): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102029_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102029_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libMindMap" {
    export * from "_102029_/l2/libMindMap";
}
declare module "_100554_/l2/agentArchitectMind" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getDefs(): Promise<string>;
    export type Output = {
        type: "flexible";
        result: IResult[];
    };
    interface IResult {
        files: [
            {
                file: string;
                description: string;
            }
        ];
    }
}
declare module "_100554_/l2/agentBotInstall.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        NOT_IMPLEMENTED = 501
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        task?: TaskData;
        taskRoomThread?: Thread;
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        notificationToken?: string;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export interface TagVocabularyEntry {
        tag: string;
        label?: {
            pt: string;
            en: string;
        };
        color: 'bug' | 'feature' | 'business' | 'process' | 'neutral';
    }
    export interface RequestListTasks extends RequestBase {
        action: "listTasks";
        userId: string;
        view: 'active' | 'closed';
        cursor?: string;
        pageSize?: number;
    }
    export interface ResponseListTasks extends ResponseBase {
        tasks: TaskData[];
        nextCursor?: string;
    }
    export interface RequestGetOrgPreferences extends RequestBase {
        action: "getOrgPreferences";
        userId: string;
        organizationId: string;
    }
    export interface ResponseGetOrgPreferences extends ResponseBase {
        tagVocabulary: TagVocabularyEntry[];
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        kind?: UserKind;
        metadata?: UserMetadata;
        threads: string[];
        notifications?: UserNotifications[];
    }
    export interface UserNotifications {
        deviceId: string;
        notificationToken: string;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export interface ProviderConfig {
        provider: string;
        alternateProvider: string;
        model: string;
        json: boolean;
        onlyImage?: boolean;
        inputValue: number;
        outputValue: number;
        extrabody?: Record<string, string>;
    }
    export interface Providers {
        [provider: string]: Record<string, ProviderConfig>;
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        prompt?: string;
        rags: string[] | null;
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: string;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        icon: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getFCMTokenForBackend?(): Promise<string | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getFCMTokenForBackend: () => Promise<string>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "default" | "custom";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export function msgListTasks(args: Omit<msg.RequestListTasks, "action">): Promise<ApiResult<msg.ResponseListTasks>>;
    export function msgGetOrgPreferences(args: Omit<msg.RequestGetOrgPreferences, "action">): Promise<ApiResult<msg.ResponseGetOrgPreferences>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102027_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function appendLongTermMemory(context: mls.msg.ExecutionContext, longTermMemory: Record<string, string>): Promise<mls.msg.TaskData>;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
    export function findPreviousAgentStep(data: mls.msg.TaskData, baseStep: number): mls.msg.AIAgentStep | null;
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102027_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from "_102027_/l2/aiAgentBase";
    export type OrchestrationEvent = {
        type: 'task-created';
        taskId: string;
        task: mls.msg.TaskData;
        message?: mls.msg.Message;
    } | {
        type: 'intents-applied';
        task: mls.msg.TaskData;
        message: mls.msg.Message;
    } | {
        type: 'hook-start';
        hookType: string;
        stepId: number;
    } | {
        type: 'hook-done';
        hookType: string;
        intents: mls.msg.AgentIntent[];
    } | {
        type: 'pooling-start';
        taskId: string;
    } | {
        type: 'pooling-end';
        taskId: string;
    } | {
        type: 'cycle-done';
        remaining: number;
    } | {
        type: 'error';
        error: string;
        stepId?: number;
    } | {
        type: 'done';
    };
    export function executeBeforePromptStream(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): AsyncGenerator<OrchestrationEvent, void, unknown>;
    /**
     * Backward-compatible wrapper: consome o generator inteiro e retorna void.
     * Quem não precisa de streaming continua usando essa.
     */
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function restartStep(context: mls.msg.ExecutionContext, stepId: number, cleaner?: 'input' | 'input_output'): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102025_/l2/shared/api" {
    export * from "_102036_/l2/shared/api";
}
declare module "_102025_/l2/shared/interfaces" {
    import type * as base from "_102036_/l2/shared/interfaces";
    export * from "_102036_/l2/shared/interfaces";
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface RequestCreateAttachmentUpload extends base.RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends base.ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends base.RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestDeleteAttachment extends base.RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends base.ResponseBase {
        message: base.Message;
    }
    export interface RequestGetAttachmentUrl extends base.RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends base.ResponseBase {
        url: string;
        expiresAt: string;
    }
    module "_102036_/l2/shared/interfaces" {
        interface RequestUpdateMessage {
            pin?: boolean;
            favorite?: boolean;
            readConfirmation?: 'request' | 'confirm' | 'cancel' | 'requestExecution' | 'reviewExecution';
            messageAction?: 'delete' | 'moderate' | 'createTask';
            editContent?: string;
            taskTitle?: string;
        }
        interface ResponseUpdateMessage {
            thread?: Thread;
            messages?: Message[];
            user?: User;
            users?: User[];
            task?: TaskData;
            taskRoomThread?: Thread;
        }
        interface RequestRemoveUserInThread {
            eventVisibility?: "all" | "admin";
        }
        interface ResponseRemoveUserInThread {
            messages?: Message[];
        }
        interface User {
            favorites?: string[];
            readConfirmations?: UserReadConfirmations;
        }
        interface UserReadConfirmations {
            pending?: string[];
            requested?: string[];
        }
        interface Message {
            readConfirmations?: MessageReadConfirmation[];
            attachments?: MessageAttachment[];
            moderation?: MessageModeration;
            edits?: MessageEditVersion[];
            editedAt?: string;
            editedBy?: string;
        }
        interface MessageModeration {
            status: "deleted" | "moderated";
            by: string;
            at: string;
        }
        interface MessageEditVersion {
            content: string;
            editedBy: string;
            editedAt: string;
        }
        interface MessageReadConfirmation {
            kind?: 'read' | 'execution';
            requestedBy: string;
            requestedAt: string;
            targetUserIds: string[];
            confirmedBy?: Record<string, string>;
            canceledAt?: string;
            canceledBy?: string;
            followupHistory?: MessageFollowupHistoryEntry[];
        }
        interface MessageFollowupHistoryEntry {
            userId: string;
            reaction: string;
            at: string;
        }
        interface Thread {
            pinnedMessages?: PinnedMessage[];
        }
        interface PinnedMessage {
            messageId: string;
            pinnedBy: string;
            pinnedAt: string;
            excerpt?: string;
        }
    }
}
declare module "_102025_/l2/collabMessagesEvents" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export function notifyMessageSendChange(context: msg.ExecutionContext): void;
    export function notifyTaskChange(context: msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: msg.Thread): void;
    export function notifyMessageChange(message: msg.Message): void;
    export function notifyThreadNotification(show: boolean): void;
    export function notifyThreadCreate(thread: msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function dispatchDetailsTaskClick(messageId: string, taskId: string, task: msg.TaskData, message: msg.MessagePerformanceCache): void;
    export function dispatchThreadOpen(threadId: string, taskId?: string): void;
    export function notifyTaskMetaChanged(payload: {
        taskId: string;
        taskTitle: string;
        threadId: string;
    }): void;
    export interface ICollabMessageEvent {
        threadId: string;
        taskId?: string;
    }
}
declare module "_102025_/l2/collabMessagesIndexedDB" {
    export * from "_102036_/l2/collabMessagesIndexedDB";
}
declare module "_102025_/l2/collabMessagesHelper" {
    import * as msg from "_102025_/l2/shared/interfaces";
    export const AGENTDEFAULT = "agentPlanner1";
    export function registerToken(): Promise<string>;
    export function addMessage(threadId: string, messageContent: string, contextToBot?: msg.ToolsBeforeSendMessage): Promise<msg.ExecutionContext>;
    export function getArgsToBots(): Promise<Record<string, any>>;
    export function getBotsContext(thread: msg.Thread, prompt: string, context: msg.ExecutionContext): Promise<Record<string, any>>;
    export function saveNotificationDeviceId(deviceId: string): void;
    export function loadNotificationDeviceId(): string | null;
    export function saveNotificationToken(tokenFCM: string): void;
    export function loadNotificationToken(): string | null;
    export function saveNotificationPreferences(notificationPreference: NotificationPermission): void;
    export function loadNotificationPreferences(): NotificationPermission | null;
    export function saveNotificationPreferencesAudio(enable: boolean): void;
    export function loadNotificationPreferencesAudio(): boolean;
    export function saveLastAlertTime(time: number): void;
    export function loadLastAlertTime(): number | undefined;
    export function saveLastTab(lastTab: string): void;
    export function loadLastTab(): string;
    export function saveUserId(userId: string): void;
    export function getUserId(): string | null;
    export function loadChatPreferences(): IChatPreferences;
    export function saveChatPreferences(chatPreferences: IChatPreferences): void;
    export function loadOpenClawIntegrations(): Promise<msg.IOpenClawIntegration[]>;
    export function saveOpenClawIntegrations(integrations: msg.IOpenClawIntegration[]): Promise<void>;
    export function checkThreadAlreadyExist(threadName: string): Promise<void>;
    export function getDmThreadByUsers(userId1: string, userId2: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThread(threadName: string, languages: string[], visibility: msg.ThreadVisibility, avatar_url?: string): Promise<msg.ThreadPerformanceCache | undefined>;
    export function createThreadDM(threadName: string, dmUser: string, group: msg.ThreadGroup): Promise<msg.Thread>;
    export function formatTimestamp(timestamp: string): {
        dateFull: string;
        date: string;
        time: string;
        timeShort: string;
    };
    export function getDateFormated(dt: string): string;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => msg.ExecutionContext;
    export function findAgentInIntegrationsByUserId(collabUserId: string): Promise<{
        name: string;
        agentId: string;
        connectorId: string;
    }>;
    export function generateUUIDv7(): string;
    export function generateAgentAvatar(name: string): string;
    export function changeFavIcon(notification: boolean): Promise<void>;
    export type TranslateMode = "none" | "icon" | "text" | "iconText" | "trace";
    export interface IChatPreferences {
        translationMode: TranslateMode;
        language: string;
        threadMaintenance: string;
    }
    export interface CollabMessagesLS {
        lastTab?: string;
        chatPreferences?: IChatPreferences;
        userId?: string;
        tokenFCM?: string;
        deviceId?: string;
        notificationPreference?: NotificationPermission;
        notificationAudio?: boolean;
        lastNotificationAlertTime?: number;
    }
    export interface IMessage extends msg.MessagePerformanceCache {
        context?: msg.ExecutionContext;
        lastChanged?: number;
        isSame?: boolean;
        isLoading?: boolean;
        isFailed?: boolean;
        isFailedError?: string;
    }
    export interface IThreadInfo {
        thread: msg.ThreadPerformanceCache;
        threadsPending?: string[];
        users: msg.User[];
        hasMore?: boolean | undefined;
        messages?: msg.Message[] | undefined;
    }
}
declare module "_100554_/l2/agentBotInstall" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function disableBot(context: mls.msg.ExecutionContext, projectId: number, shortName: string, folder: string): Promise<boolean>;
}
declare module "_100554_/l2/agentBotWeddingGifts.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentBotWeddingGifts" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: WeddingGifts;
    } | {
        type: "result";
        result: string[];
    };
    interface WeddingGifts {
        gifts: GiftItem[];
    }
    export interface GiftItem {
        name: string;
        originalNames: string[];
        status: "available" | "reserved" | "purchased" | "declined";
        reservedBy?: string;
        date?: string;
        message?: string;
        purchaseUrl?: string;
    }
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_100554_/l2/agentCompareAgentsClarification" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class AgentToBeConceptual2Clarification extends CollabLitElement {
        entitiesCount: number;
        rulesCount: number;
        capabilitiesCount: number;
        suggestions: string[];
        firstUpdated(changed: Map<string, any>): void;
        updated(changed: Map<string, any>): void;
        render(): any;
        private renderContentSuggestions;
        private onAction;
    }
}
declare module "_100554_/l2/agentCompareAgents" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Result;
    };
    export type Result = {
        agentNames: string[];
        promptUser: string;
        promptCompare: string;
    };
    export type Output3 = {
        type: "clarification";
        json: Suggestions;
    };
    export interface Suggestions {
        suggestions: [
            "Please provide the names of the agents for analysis, separated by commas.",
            "Please provide the user prompt.",
            "Do you want me to analyze something specific?"
        ];
    }
}
declare module "_100554_/l2/agentCompareAgents2" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: any;
    };
}
declare module "_100554_/l2/agentCompareAgents3" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Assessment;
    };
    export type Assessment = {
        correctness: number;
        completeness: number;
        quality: number;
        efficiency: number;
        robustness: number;
        finalScore: number;
        summary: string;
    };
}
declare module "_100554_/l2/agentDesignRef2Image.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentDesignRef2Image" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getPayload1(context: mls.msg.ExecutionContext): PayLoad1;
    export type Output1 = {
        type: "flexible";
        result: string;
    };
    export interface PayLoad1 {
        prompt: string;
    }
}
declare module "_100554_/l2/agentDesignRef2Image2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentDesignRef2Image2" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
}
declare module "_100554_/l2/agentFix.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102029_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    /** A custom @font-face entry (self-hosted / arbitrary URL). */
    export interface DsFontFace {
        weight?: number;
        style?: string;
        src: string;
    }
    /**
     * One font ROLE. `name` is the role (display, body, mono, …).
     * `source` decides how the family is LOADED:
     *   - system: already installed (no load)
     *   - google: loaded via `@import` from Google Fonts (URL derived from family + weights)
     *   - custom: loaded from `url` (a stylesheet @import) or `faces` (@font-face blocks)
     */
    export interface DsFont {
        name: string;
        source?: 'system' | 'google' | 'custom';
        family: string;
        weights?: number[];
        fallback?: string;
        url?: string;
        faces?: DsFontFace[];
    }
    /**
     * Molecule-token reconciliation for a DS entry: the `--ml-*` vocabulary of the used
     * molecule groups mapped to `--ds-*` expressions. Lives on the entry (same home as the
     * tokens) and is applied by the render into `:root` (see {@link tokensCssFromTheme}).
     *
     * Runtime-clean core interface — the reconciliation agent (`_102020_/l2/dsMatch`)
     * re-exports it so both sides share one shape.
     */
    export interface DsTokenReconciliation {
        version: string;
        usedGroups?: string[];
        map: Record<string, string | null>;
        pinned?: Record<string, string>;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
        /** Font roles that need LOADING (@import/@font-face). The family value itself still lives as a regular token (e.g. `typography['font-family-primary']`). */
        fonts?: DsFont[];
        /** Correlates this entry with the generation config bucket `designSystems[dsIndex]` in l5/project.json (and the `page<layout><ds>` folders). Falls back to the array position + 1 when absent. */
        dsIndex?: string;
        /** Molecule-token reconciliation (`--ml-*` → `--ds-*`), applied by the render into `:root`. */
        tokenReconciliation?: DsTokenReconciliation;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
    /**
     * Loads the project design system and compiles its tokens into ready-to-inject CSS:
     * font-loading rules (`@import`/`@font-face`, when the theme declares `fonts`) followed by
     * a `:root { --token: value; }` block and a `[data-theme="dark"], :root.dark` override block.
     *
     * Runs both in dev (editor/preview) and at app bootstrap in production.
     *
     * @param theme - Which theme to compile: a numeric index into the `tokens` array, or a string matched against `themeName`. Falls back to the first theme when omitted or not found.
     * @param path - Module path of the design system file, forwarded to {@link getTokens}. Defaults to the production convention `/designSystem.js`; dev callers should pass the preview path (e.g. `/_102048_/l2/designSystem.js`).
     * @returns The compiled CSS string, or an empty string when the project has no design system.
     * @throws When the design system exists but its tokens fail to compile.
     */
    export function getTokensCss(nameOrIndex?: number | string, path?: string): Promise<string>;
    /**
     * Compile ONE theme entry into ready-to-inject CSS: font-loading rules (`@import`/`@font-face`)
     * followed by the `:root` / `[data-theme="dark"], :root.dark` custom-property blocks. Pure
     * (no I/O) — the shared core of both the runtime {@link getTokensCss} and the editor variant
     * (`_102027_/l2/designSystemBase.getTokensCss`).
     *
     * @param tokenInfo - The theme entry (color + typography + global maps; dark via `_dark-` prefix; optional `fonts`; optional `tokenReconciliation`).
     * @returns The compiled CSS string.
     */
    export function tokensCssFromTheme(tokenInfo: IDesignSystemTokens): string;
    /**
     * Molecule-token reconciliation as a `:root` block: each `--ml-*` mapped to its `--ds-*`
     * expression (`map`, then `pinned` overrides which win). `null`/empty values are skipped —
     * the molecule keeps its own default. Theme-agnostic: the values point at `var(--ds-*)`,
     * which already switch in the dark block, so a single `:root` block covers both themes.
     *
     * @param reconciliation - The entry's `tokenReconciliation`; absent/empty yields an empty string.
     * @returns The `:root { --ml-*: …; }` block, or an empty string when nothing is mapped.
     */
    export function getMlTokensCss(reconciliation?: DsTokenReconciliation): string;
    /**
     * Font-loading CSS for one theme: `@import` lines (google + custom URLs) and
     * `@font-face` blocks (custom self-hosted sources). Must come before every other
     * rule in the final stylesheet — `@import` is only valid at the top.
     *
     * @param fonts - The theme's `fonts` declarations; absent/empty yields an empty string.
     * @returns The font-loading CSS, or an empty string when there is nothing to load.
     */
    export function getFontLoadsCss(fonts?: DsFont[]): string;
    /**
     * Dynamically imports the design system module and returns its raw token themes.
     *
     * Note: `import()` caches by URL — in dev, append a cache-busting query
     * (e.g. `?v=${Date.now()}`) to the path to reload after the design system changes.
     *
     * @param path - Module path of the design system file. Defaults to `/designSystem.js`, the path where the built app serves it in production.
     * @returns The design system's `tokens` array (one entry per theme), or an empty array when the module exports none.
     * @throws When the module cannot be imported or resolves to nothing.
     */
    export function getTokens(path?: string): Promise<IDesignSystemTokens[]>;
    /**
     * Strips every `//Start Less Tokens ... //End Less Tokens` block from a Less source,
     * so token definitions injected by the editor are not duplicated when recompiling.
     *
     * @param src - Less source that may contain injected token blocks.
     * @returns The source without the token blocks.
     */
    export function removeTokensFromSource(src: string): string;
    /**
     * Splits a flat token map into theme groups by key prefix: keys starting with
     * `_dark-` go to the `dark` group, everything else goes to `root` (light/default).
     *
     * @param allTokens - Flat map with all tokens of a theme (color + typography + global merged).
     * @returns Tokens grouped by theme name (`root`, `dark`), keeping the original keys.
     */
    export function getDarkAndLight(allTokens: IKeyValueToken): IDarkLight;
    /**
     * Renders theme groups as CSS custom-property blocks: the `root` group becomes
     * `:root { --token: value; }` and any other group becomes a
     * `[data-theme="dark"], :root.dark { ... }` block (both dark conventions — legacy
     * attribute and Aura class) with the theme prefix stripped from the keys.
     *
     * @param themes - Tokens grouped by theme, as produced by {@link getDarkAndLight}.
     * @returns The CSS blocks joined into a single string (values may still contain Less expressions — see {@link convertLessTokensToCss}).
     */
    export function getCssVars(themes: IDarkLight): string;
    /**
     * Rewrites Less token references (`@token`) as CSS variable reads (`var(--token)`),
     * so the output can be served straight to the browser without a Less compile step.
     *
     * A reference is only rewritten when the token exists in `tokens`; occurrences
     * inside `@media (...)` conditions or inside Less-only function calls (see
     * `lessOnlyFunctions`) are left untouched, since `var()` is invalid there.
     *
     * @param less - Less source containing `@token` references.
     * @param tokens - Map of known token names used to validate each reference.
     * @returns The source with valid token references converted to `var(--token)`.
     */
    export function convertLessTokensToCss(less: string, tokens: IKeyValueToken): string;
    /** The 11 color families (base key = `<family>-color`). `grey` has a distinct variant shape. */
    export const MANDATORY_COLOR_FAMILIES: readonly ["text-primary", "text-secondary", "bg-primary", "bg-secondary", "grey", "error", "success", "warning", "info", "active", "link"];
    export type MandatoryColorFamily = typeof MANDATORY_COLOR_FAMILIES[number];
    /** Complete default DS tokens (light + `_dark-` pairs). The canonical mandatory baseline. */
    export const DEFAULT_TOKENS_TEMPLATE: {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
    /** The mandatory token names per section (derived from the template — the lock/completeness list). */
    export const MANDATORY_TOKEN_KEYS: {
        color: string[];
        global: string[];
        typography: string[];
    };
    /** True when `key` is a mandatory (non-deletable) token of `section`. */
    export function isMandatoryToken(section: 'color' | 'global' | 'typography', key: string): boolean;
    /** A fresh deep copy of the default template (never hand out the shared constant for mutation). */
    export function defaultTokensTemplate(): {
        color: IKeyValueToken;
        global: IKeyValueToken;
        typography: IKeyValueToken;
    };
}
declare module "_102029_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102029_/l2/designSystemEditorBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102029_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102029_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libCommom" {
    export * from "_102029_/l2/libCommom";
}
declare module "_102027_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_100554_/l2/collabDOMSync" {
    export function sync(): void;
    export function updateHTML(html: string, format?: boolean): void;
    export function setValueInModeKeepingUndo(model: monaco.editor.ITextModel, newContent: string): void;
    export function formatHtml(html: string): string;
}
declare module "_100554_/l2/lessMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines: (url: string) => string[];
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine: (url: string, lineNr: number, line: string) => boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine: (url: string, lineNr: number) => boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines: (url: string, startLine: number, countLines: number) => boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine: (url: string, lineNr: number, columnNr: number, newText: string) => boolean;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (url: string) => void;
    }
}
declare module "_100554_/l2/lessAST" {
    import { MonacoDriver } from "_100554_/l2/lessMonaco";
    interface ILessAST {
        root: {
            [token: string]: {
                value: string;
                line: number;
                column: number;
            };
        };
        [selector: string]: {
            _startLine?: number;
            _endLine?: number;
            [property: string]: {
                value: string;
                line: number;
                column: number;
            } | number | undefined;
        };
    }
    /**
     * @class LessAst
     *
     * This class parses a LESS model, building an AST and converting LESS selectors
     * into a CSS-compatible format. Note that this implementation supports only a subset
     * of LESS functionalities. Advanced features, such as variable interpolation within selectors,
     * parameterized mixins, and color manipulation functions, are not supported.
     *
     * ### Supported Features
     * - **Basic Selector Nesting**: Supports nesting selectors with `&`, converting them to a CSS-compatible format.
     * - **Simple Variables**: Allows the use of variables within properties (e.g., `@color-primary: #333;`).
     * - **Basic LESS Structure**: Parses basic selectors, properties, and tokens, ignoring advanced logic.
     *
     * ### Unsupported Features
     * - **Variable Interpolation within Selectors**: Selectors like `@{variable}-name` are not expanded in the AST.
     * - **Parameterized Mixins**: Mixins with parameters are not evaluated or expanded.
     * - **Mathematical and Color Functions**: Functions like `darken`, `lighten`, or `add` are not processed.
     * - **Looping and Iteration**: Constructs such as `each` or `for` are ignored, as they are not supported in CSS.
     * - **Global Scope Management**: Selectors with `:global` will not retain global scoping behavior.
     *
     * ### Usage Example
     * ```typescript
     * const lessAst = new LessAst("your-url");
     * lessAst.parse();
     * const cssSelector = lessAst.selectorLESS2CSS("less-a-s-t-100554 &:hover");
     * console.log(cssSelector); // Output: less-a-s-t-100554:hover
     * ```
     *
     * ### Limitations
     * Since this class does not handle dynamic processing features of LESS, it is recommended
     * only for static LESS-to-CSS conversions that do not require runtime evaluation.
     */
    export class LessAst {
        ast: ILessAST;
        url: string;
        monacoDriver: MonacoDriver;
        stack: string[];
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * parse a full LESS model (monaco editor)
         */
        parse: () => void;
        /**
         * Parses a single line and updates the AST accordingly.
         */
        private parseLine;
        /**
         * Finds the column index where the given `value` starts in the provided `line`.
         *
         * This method calculates the precise position of the `value` in the string `line`
         * after the first occurrence of a colon (`:`), considering any leading spaces.
         * If the `value` is not found or the colon is absent, it returns undefined.
         *
         * @param {string} line - The line of text to be searched.
         * @param {string} value - The target string to locate within the `line`.
         * @returns {number} - The zero-based index of the starting position of `value` in `line`,
         *                     or undefined if the colon or value is not found.
         *
         * @example
         * // Example 1:
         * const line = "        text-shadow: 3em -8em 3em;";
         * const value = "3em -8em 3em";
         * findColumn(line, value); // Returns: 23
         *
         * // Example 2:
         * const line = "        flex-wrap: wrap;";
         * const value = "wrap";
         * findColumn(line, value); // Returns: 21
         *
         * // Example 3:
         * const line = "invalid line without colon";
         * const value = "anything";
         * findColumn(line, value); // Returns: undefined
         */
        private findColumn;
        /**
         * Lists all themes available in the AST.
         * Each theme is identified by its selector. If the selector has a `.`, the part after the dot is the theme name.
         * If no dot is present, the theme is named "default".
         *
         * @returns An object where each key is a theme name (e.g., "default", "theme2") and each value is the corresponding selector.
         */
        listThemes(): {
            [themeName: string]: string;
        };
        /**
         * Adds a new theme to the specified component variation.
         *
         * @param variation The name of the new theme variation (e.g., "theme3").
         * @returns `true` if the theme was added successfully, `false` otherwise.
         */
        addTheme(variation: string): boolean;
        /**
         * Deletes a theme from the specified component variation.
         *
         * @param variation The name of the theme variation to delete (e.g., "theme2").
         * If `null`, deletes the "default" theme (the main component selector).
         * @returns `true` if the theme was deleted successfully, `false` otherwise.
         */
        deleteTheme(variation: string | null): boolean;
        /**
         * Retrieves the description comments for a specified theme.
         *
         * @param variation The name of the theme variation (e.g., "theme2").
         *                  If `null`, retrieves the "default" theme.
         * @returns An array of comment lines that describe the theme, or an empty array if no comments are found.
         */
        getThemeDescription(variation: string | null): string[];
        private getThemeRangeLines;
        /**
         * Converts a full CSS selector back to the LESS format using "&" where appropriate.
         * - If the selector parts match a parent selector, it replaces the match with "&".
         *
         * @param selector The CSS selector to convert to LESS format.
         * @returns The converted LESS format selector with "&" where possible.
         */
        selectorCSS2LESS: (selector: string) => string;
        selectorLESS2CSS: (selector: string) => string;
        /**
         * Converts a kebab-case property name to camelCase, e.g., background-color to backgroundColor.
         * This ensures property names align with JavaScript/TypeScript conventions.
         */
        toCamelCaseProperty(property: string): string;
        /**
         * Converts a camelCase property name to kebab-case, e.g., backgroundColor to background-color.
         * This ensures property names align with CSS/LESS conventions.
         */
        toKebabCaseProperty(property: string): string;
        getProperty(selector: string, property: string): string | undefined;
        private updateASTAfterInsertLine;
        saveProperty(selector: string, property: string, newValue: string | undefined): boolean;
        /**
         * Returns the last line number within a selector block. aka "}"
         */
        findLastLineInSelector(selectorLESS: string): number;
        findInfoByLine(selectorLESS: string, lineNumber: number): {
            key: string;
            value: string;
        } | undefined;
        /**
         * Finds the most specific LESS selector path for a given line number in the source.
         * - This method searches the AST to determine the most specific selector block containing the specified line.
         * - It returns the full path of the most deeply nested selector in LESS format (e.g., `.cl1 .cl2 &:hover`).
         *
         * ### Usage
         * This method is useful for identifying the exact selector block a line belongs to, especially
         * in scenarios where nested selectors exist in the LESS structure.
         *
         * @param lineNr The line number to check for a corresponding selector.
         * @returns The most specific LESS selector path as a string if found; otherwise, `undefined`.
         */
        findSelectorByLine(lineNr: number): string | undefined;
        /**
         * Finds the start line of the first selector after the root in a JSON representation of a stylesheet.
         *
         * @param json - A JSON object representing a stylesheet, where keys are selectors and values contain metadata.
         * @param tagName - The tag name to exclude from the search.
         * @returns The start line of the first selector after the root, or `null` if no such selector exists.
         */
        findFirstSelectorAfterRoot(ast: Record<string, any>): number | null;
        /**
         * Inserts a new selector into the AST and the Monaco model if it does not exist.
         * - Example: If the AST only contains ".cl1" and `newSelectorLESS` is ".cl1 .cl2 &:hover",
         *   the function will:
         *   1. Check if ".cl1 .cl2" exists in the AST.
         *   2. If not, insert ".cl2" as a nested block within ".cl1".
         *   3. Then insert "&:hover" as a nested selector inside ".cl1 .cl2".
         *
         * This function supports nested selectors by iteratively checking each level
         * and inserting any missing selectors in sequence.
         *
         * @param newSelectorLESS The LESS selector to add to the AST and source code.
         * @result start line of the block
         */
        insertSelector(newSelectorLESS: string): number;
    }
}
declare module "_100554_/l2/lessCSS" {
    import { LessAst } from "_100554_/l2/lessAST";
    /**
     * A unique symbol used as a key for properties that should be ignored during JSON serialization.
     *
     * Properties defined with this symbol as a key will not appear in the output of `JSON.stringify`,
     * ensuring that the property is excluded from serialization while avoiding key collisions.
     *
     * @const {symbol} ignoredProperty - A unique symbol for marking non-serializable properties.
     */
    const _editor: unique symbol;
    export class LessCSS {
        lessAST: LessAst;
        selector: string;
        position: "left" | "right";
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        _url: string;
        styles: CSSStyleDeclaration;
        constructor(url: string, editor: monaco.editor.IStandaloneCodeEditor, position?: "left" | "right");
        setEditor(editor: monaco.editor.IStandaloneCodeEditor): void;
        /**
         * Sets the current selector for which properties will be applied.
         */
        setSelector(selector: string): void;
        /**
         * Retrieves a specific CSS property value for the current selector from the AST.
         * @param property The CSS property to retrieve
         */
        getProperty(property: string): string | undefined;
        /**
         * Sets or updates a CSS property in the AST and source model.
         * @param property The CSS property to set
         * @param value The new value for the property
         */
        setProperty(property: string, value: string): void;
        refresh(): void;
        setStateByLine(lineNumber: number, lineContent: string, emitter: 'editor' | 'helper' | 'preview'): void;
        private clearState;
        private updateState;
        private initStateIfNeeded;
    }
    export interface ICSSState {
        uri: string;
        selector: string | undefined;
        lineNumber: number | undefined;
        lineContent: string | undefined;
        key: string | undefined;
        value: string | undefined;
        lessCSS: LessCSS | undefined;
        emitter: 'editor' | 'helper' | 'preview';
    }
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_100554_/l2/collabIcons" {
    export const collab_terminal: any;
    export const collab_home: any;
    export const collab_bars: any;
    export const collab_magnifying_glass: any;
    export const collab_file_half_dashed: any;
    export const collab_book_skull: any;
    export const collab_rectangle_list: any;
    export const collab_lightbulb: any;
    export const collab_translate: any;
    export const collab_file_fragment: any;
    export const collab_file_code: any;
    export const collab_dot: any;
    export const collab_minus: any;
    export const collab_user_plus: any;
    export const collab_bell: any;
    export const collab_bell_slash: any;
    export const collab_message: any;
    export const collab_money: any;
    export const collab_clock: any;
    export const collab_clock_static: any;
    export const collab_test: any;
    export const collab_html: any;
    export const collab_typescript: any;
    export const collab_less: any;
    export const collab_fileTest: any;
    export const collab_record: any;
    export const collab_stop: any;
    export const collab_copy: any;
    export const collab_check: any;
    export const collab_double_check: any;
    export const collab_file: any;
    export const collab_location_dot: any;
    export const collab_rotate_left: any;
    export const collab_bug: any;
    export const collab_bug_x12: any;
    export const collab_unbalanced: any;
    export const collab_info: any;
    export const collab_info_circle: any;
    export const collab_question: any;
    export const collab_heart: any;
    export const collab_heart_o: any;
    export const collab_angles_right: any;
    export const collab_chevron_right: any;
    export const collab_chevron_left: any;
    export const collab_chevron_down: any;
    export const collab_undo: any;
    export const collab_clone: any;
    export const collab_file_pen: any;
    export const collab_trash: any;
    export const collab_ellipsis_vertical: any;
    export const collab_ban: any;
    export const collab_file_signature: any;
    export const collab_calendar_days: any;
    export const collab_user: any;
    export const collab_users: any;
    export const collab_book: any;
    export const collab_list_check: any;
    export const collab_folder_tree: any;
    export const collab_cube: any;
    export const collab_pen_nib: any;
    export const collab_plus: any;
    export const collab_bolt: any;
    export const collab_pencil: any;
    export const collab_cubes: any;
    export const collab_floppy_disk: any;
    export const collab_xmark: any;
    export const collab_arrow_up_long: any;
    export const collab_arrow_down_long: any;
    export const collab_arrows_up_down_left_right: any;
    export const collab_caret_righttv: any;
    export const collab_repeat: any;
    export const collab_thumbs_down_solid: any;
    export const collab_thumbs_down: any;
    export const collab_thumbs_up_solid: any;
    export const collab_thumbs_up: any;
    export const collab_edit_style: any;
    export const collab_play: any;
    export const collab_pause: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
    export const collab_commit: any;
    export const collab_branch: any;
    export const collab_pull_request: any;
    export const collab_arrows_rotate: any;
    export const collab_circle_notch: any;
    export const collab_triangle_exclamation: any;
    export const collab_circle_exclamation: any;
    export const collab_gear: any;
    export const collab_spinner_clock: any;
    export const collab_lock: any;
    export const collab_lock_open: any;
    export const collab_image: any;
    export const collab_unsplash: any;
    export const collab_video: any;
    export const collab_code: any;
    export const collab_ellipsis: any;
    export const collab_link: any;
    export const collab_border_top: any;
    export const collab_border_left: any;
    export const collab_border_bottom: any;
    export const collab_border_right: any;
    export const collab_border_topLeft: any;
    export const collab_border_bottomLeft: any;
    export const collab_border_bottomRight: any;
    export const collab_border_topRight: any;
    export const collab_margin_top: any;
    export const collab_margin_left: any;
    export const collab_margin_bottom: any;
    export const collab_margin_right: any;
    export const collab_padding_top: any;
    export const collab_padding_left: any;
    export const collab_padding_bottom: any;
    export const collab_padding_right: any;
}
declare module "_102027_/l2/collabImport" {
    export * from "_102029_/l2/collabImport";
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102027_/l2/utils" {
    export * from "_102029_/l2/utils";
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/libStor" {
    export function createStorFile(req: IReqCreateStorFile, needCreateModel: boolean, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function createAllFiles(req: IReqCreateAllFiles, needCreateModel?: boolean, awaitCompile?: boolean): Promise<IRetAllFiles>;
    export function deleteFile(storFile: mls.stor.IFileInfo): Promise<void>;
    export function deleteAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function removeNewStorFilesWithTemplateDefault(): Promise<mls.stor.IFileInfo[]>;
    export function renameFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<mls.stor.IFileInfo>;
    export function renameAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, needCompile?: boolean): Promise<IRetAllFiles>;
    export function cloneFile(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<mls.stor.IFileInfo>;
    export function cloneAllFiles(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string): Promise<IRetAllFiles>;
    export function undoFile(storFile: mls.stor.IFileInfo, removeProject?: boolean): Promise<void>;
    export function undoAllFiles(storFile: mls.stor.IFileInfo): Promise<void>;
    export function replaceTripleslashAndTag(storFile: mls.stor.IFileInfo, newProject: number, newShortName: string, newFolder: string, src: string): string;
    export interface IReqCreateAllFiles {
        shortName: string;
        project: number;
        folder: string;
        enhancement: string;
        level: number;
        tsSource?: string;
        htmlSource?: string;
        lessSource?: string;
        testSource?: string;
        defsSource?: string;
    }
    export interface IReqCreateStorFile {
        shortName: string;
        project: number;
        folder: string;
        level: number;
        source: string;
        extension: string;
        status?: mls.stor.IFileInfoStatus;
        fileInfo?: {
            originalFolder: string;
            originalProject: number;
            originalShortName: string;
        };
    }
    export interface IRetAllFiles {
        ts?: mls.stor.IFileInfo | undefined | Error;
        html?: mls.stor.IFileInfo | undefined | Error;
        less?: mls.stor.IFileInfo | undefined | Error;
        def?: mls.stor.IFileInfo | undefined | Error;
        test?: mls.stor.IFileInfo | undefined | Error;
    }
}
declare module "_100554_/l2/collabSpliterVerticalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterVerticalVarFixed100554 extends LitElement {
        fixedheight: string;
        complementcolor: string;
        spliterHeight: number;
        withresize: string;
        actualfixedheight: string;
        msize: string;
        isBottomPaneOpen: boolean;
        slotTop: HTMLElement | undefined;
        slotBottom: HTMLElement | undefined;
        private resizeObserver?;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        private getMSize;
        private getMSizeTop;
        private getMSizeBottom;
        updatePanelsMSize(): void;
        private forceRefreshMsize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        timeoutResize: number | undefined;
        _distributeContent(): void;
        render(): any;
        private styles;
    }
}
declare module "_100554_/l2/collabSpliterHorizontalVarFixed" {
    import { LitElement } from 'lit';
    export class CollabSpliterHorizontalVarFixed100554 extends LitElement {
        fixedwidth: string;
        complementcolor: string;
        fixedvisible: 'hidden' | 'visible' | 'closed';
        spliterWidth: number;
        actualfixedwidth: string;
        msize: string;
        open: boolean;
        openUser: boolean | undefined;
        slotLeft: HTMLElement[] | undefined;
        slotRight: HTMLElement[] | undefined;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private setFixedValueInPx;
        private getMSize;
        private getMSizeLeft;
        private getMSizeRight;
        private updateMyHeight;
        delay(): Promise<void>;
        private updatePanelsMSize;
        resizeItens(): void;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        firstUpdated(): void;
        render(): any;
        private styles;
    }
}
declare module "_100554_/l2/cssHelperIndexBase" {
    export type IMode = 'collapsed' | 'expanded' | 'full';
    export interface IHelpers {
        name: string;
        priority: number;
        widget: string;
        tags: string[];
        description: string;
        mode: IMode;
        liked: boolean;
        likedAnimation: boolean;
        showInfo: boolean;
    }
}
declare module "_100554_/l2/pluginStyleIndexItem" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import { IHelpers } from "_100554_/l2/cssHelperIndexBase";
    export class PluginStyleIndexItem extends CollabLitElement {
        help: IHelpers | undefined;
        position: 'left' | 'right';
        mode: 'collapsed' | 'expanded' | 'full';
        pluginLoaded: boolean;
        firstUpdated(): void;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private pluginEl;
        private openPlugin;
        handleOpenPlugin(e: MouseEvent, help: IHelpers, close?: boolean): Promise<void>;
        handleExpandedClick(e: MouseEvent): Promise<void>;
        handleFullClick(e: MouseEvent): void;
        handleLikeClick(e: MouseEvent): Promise<void>;
        handleInfoClick(e: MouseEvent): Promise<void>;
    }
}
declare module "_100554_/l2/cssHelperIndex" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { PluginStyleIndexItem } from "_100554_/l2/pluginStyleIndexItem";
    import { IHelpers } from "_100554_/l2/cssHelperIndexBase";
    import { ICSSState } from "_100554_/l2/lessCSS";
    import "_100554_/l2/pluginStyleIndexItem";
    export class CssHelperIndex extends StateLitElement {
        private msg;
        private minValueToOpen;
        helpers: IHelpers[];
        avaliablePlugins: IHelpers[];
        position: 'right' | 'left';
        actualProp: string | undefined;
        actualValue: string | undefined;
        actualSelector: string | undefined;
        actualLineContent: string | undefined;
        actualLineNumber: number | undefined;
        private isFirtsLoading;
        state: ICSSState | undefined;
        allPluginsEls: PluginStyleIndexItem[];
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        updated(changedProperties: any): Promise<void>;
        private mergeHelpersArrays;
        firstUpdated(a: any): Promise<void>;
        private baseProject;
        private getAvaliablesPlugins;
        private filterByProp;
        render(): any;
        renderHelper(help: IHelpers, index: number): any;
    }
}
declare module "_102027_/l2/collabMonacoEditor" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMonacoEditor extends StateLitElement {
        msize: string;
        mlsEditor: any;
        get isMls2(): boolean;
        render(): any;
        updated(changed: Map<PropertyKey, unknown>): void;
        private _onMsizeChange;
    }
}
declare module "_102029_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102029_/l2/processCssLit" {
    export function injectStyle(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function injectStyleAction(sourceJS: string, sourceTS: string, sourceLess: string, sourceTokens: string, theme: string, enhancementName: string): Promise<string>;
    export function injectStyleWithoutShadowRoot(modelTS: mls.editor.IModelTS, theme: string, enhancementName: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_102027_/l2/processCssLit" {
    export * from "_102029_/l2/processCssLit";
}
declare module "_102027_/l2/libCompileStyle" {
    export function compileStyleUsingStorFile(shortName: string, project: number, folder: string, theme?: string): Promise<string>;
    export function compileStyleUsingMFile(modelStyle: mls.editor.IModelStyle, theme?: string): Promise<string>;
    export function compileStyleUsingSourceString(sourceLess: string, tokens: string, theme?: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function isCommentLine(line: string): boolean;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_100554_/l2/enhancementStyle" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const onAfterChange: (models: mls.editor.IModels) => string;
    export const onAfterMarkersChange: (models: mls.editor.IModels) => string;
    export const onAfterCompile: (modelStyle: mls.editor.IModelStyle) => Promise<void>;
    export const getDesignDetails: (modelStyle: mls.editor.IModelStyle) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export function verifyMarkersError(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function validateStyle(modelStyle: mls.editor.IModelStyle): Promise<void>;
    export function getLineByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getLineSelectorByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function getRootSelectors(lessContent: string): string[];
    export function isCommentLine(line: string): boolean;
    export function setStylesProcessed(newCss: string, el: HTMLElement, tag: string): Promise<void>;
}
declare module "_100554_/l2/serviceSource" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import { LessCSS } from "_100554_/l2/lessCSS";
    import "_100554_/l2/collabSpliterVerticalVarFixed";
    import "_100554_/l2/collabSpliterHorizontalVarFixed";
    import "_100554_/l2/cssHelperIndex";
    import "_102027_/l2/collabMonacoEditor";
    export class ServiceSource100554 extends ServiceBase {
        constructor();
        private baseProject;
        msize: string;
        panelRightOpened: boolean;
        activeModels: mls.editor.IModels | undefined;
        isModeHistory: boolean;
        mode: IModes;
        textOverlayLoading: string;
        currentHistorySourceWithoutSave: string | undefined;
        previousHistorySourceWithoutSave: string | undefined;
        currentHistorySource: string | undefined;
        previousHistorySource: string | undefined;
        historyLanguage: 'typescript' | 'html' | 'less' | 'defs';
        selectedMode: 'icTs' | 'icStyle' | 'icHTML' | 'icTest' | 'icDefs' | 'History' | undefined;
        lockMap: Map<string, boolean>;
        private MINWIDTHTPANELRIGHT;
        lessCSS: LessCSS | undefined;
        private viewState;
        private msg;
        private modeToExt;
        onClickMain(op: string): void;
        onClickTabs: (op: number) => void;
        private readonly tabConfig;
        private readonly opModelMap;
        private ensureAndActivateModel;
        private ensureStorFileExists;
        private refreshActiveModels;
        private activateModelForOp;
        private createModelIfNeedWithOutActiveModel;
        onClickTitle: () => void;
        onClickTools(op: string): void;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        private openActualL2;
        inCreate: Record<string, Promise<void> | undefined>;
        getEditorValue(): string;
        setEditorValue(val: string): boolean;
        setEditorValueByLineTs(val: string, line: number): boolean;
        setEditorValueByLineHtml(val: string, line: number): boolean;
        replaceEditorLineHTML(val: string, line: number): boolean;
        searchLineByStringTs(search: string): number | undefined;
        goToLine(line: number): void;
        setEditorHTMLValue(val: string): boolean;
        getEditorHTMLValue(): string;
        setValueInModeKeepingUndo(model: monaco.editor.ITextModel, val: string, checkFirstLine: boolean): void;
        private setValueInModelInSpecificLine;
        private replaceLineValueInModelInSpecificLine;
        formatMonaco(): void;
        private editorEl;
        private editorHistoryEl;
        overlayLoading: HTMLElement | undefined;
        private verticalSpliter;
        private horizontalSpliter;
        last: mls.IActual | undefined;
        _ed1: monaco.editor.IStandaloneCodeEditor | undefined;
        private _edDiff;
        private mConfEditor;
        private confE2;
        get confE(): string;
        get confETS(): string;
        get confEJS(): string;
        private saveViewState;
        private restaureViewState;
        private toogleHistory;
        private getHistories;
        private openRepo;
        private showHistory;
        private showHistorie2;
        private showPageTheme;
        private showMonacoReset;
        private showConfEditor;
        private onMonacoEvents;
        private goToPosition;
        private mapExt;
        private onMLSEvents;
        private lessChangedEditor;
        private fireEditorEvents;
        private openFiles;
        private activeThisService;
        private closeMenu;
        delay(ms: number): Promise<void>;
        private showThisModel;
        private initProviders;
        private initModelStyle;
        private showActiveModel;
        private initMonaco;
        private monacoGlobalInitialized;
        private initMonaco_GlobalEditor;
        private timeHtmlChangeCursor;
        private lastIdSelected;
        private lastLineNumber;
        private initMonaco_Editor;
        private actionAgentFix;
        private addFixAction;
        private lockEditorForFile;
        private isEditorLocked;
        private unlockEditorForFile;
        private removeFixAction;
        private updateActionBasedOnError;
        private getActualL2File;
        private fireAgentFix;
        private toogleOverlayLoading;
        private initMonaco_EditorDiff;
        private setHistories;
        private createOrGetModelHistory;
        private extractIdValue;
        private loadMonacoConfigurations;
        private getUri;
        private setModelConfEditor;
        private createModelConf;
        timeout_compileConfEditor: number;
        private compileSrcEditor;
        private loadConfEditorFromLocalStorage;
        private saveConfEditorToLocalStorage;
        private getActualTheme;
        private loadMonacoThemeFromLocalStorage;
        private saveMonacoGlobalThemeToLS;
        private getConfEditorToTypescript;
        private setConfEditorFromJavascript;
        private updateMonacoConfigutarions;
        private updateMonacoGlobalTheme;
        private getGlobalPageSetTHeme;
        private _formatIfNeeded;
        private getPosition;
        private getLocalStorageInfo;
        private saveLocalStorageInfo;
        private isReadOnlyArea;
        private getIntervalLinesReadOnly;
        private updatedMSizeEditor;
        private toogleIconsError;
        private currentReviewDecorationIds;
        private highlightReviewLines;
        private changeMode;
        private saveLocalStorageLastOpen;
        private openLastFile;
        getActualRef(): string;
        private lastOrigin;
        private onWidgetActionEvents;
        private selectLineinHTML;
        private registerProviderHTML;
        private isHTMLSystemChange;
        private syncDom;
        handleIcaStateChange(_key: string, _value: any): void;
        updated(changedProperties: any): void;
        connectedCallback(): void;
        firstUpdated(changedProperties: any): void;
        render(): any;
    }
    export type FormattableModel = monaco.editor.ITextModel & {
        needFormat: boolean;
    };
    type IModes = 'icTs' | 'icStyle' | 'icHTML' | 'icTest' | 'icDefs';
}
declare module "_100554_/l2/agentFix" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateFiles(context: mls.msg.ExecutionContext, result: IDataResult): Promise<void>;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
}
declare module "_100554_/l2/agentFullScan.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentFullScan" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output1 = {
        type: "flexible";
        result: INextsTools;
    } | {
        type: "flexible";
        result: INextsAgents[];
    };
    interface INextsTools {
        type: "tool";
        title: string;
        toolName: "toolFilterFilesL2";
        args: string;
    }
    interface INextsAgents {
        id: string;
        type: "agent";
        agentName: string;
        title: string;
        prompt: string;
        page: string;
        position: string;
        mode: "typescript" | "less" | "html";
    }
}
declare module "_100554_/l2/agentImprove.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentImprove" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateFiles(context: mls.msg.ExecutionContext, result: IDataResult): Promise<void>;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
}
declare module "_100554_/l2/agentJudge.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentJudge" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent2(): IAgentAsync;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        title: "A";
        points: 10;
        desc: string;
    }
}
declare module "_100554_/l2/agentPlanner1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/aiPrompts" {
    export function systemAgentsAvailable(): mls.msg.IAMessageInputType;
    export function systemRagsAvailable(): mls.msg.IAMessageInputType;
    export function addRAGAdditionalInformation(rags: string[] | null, prompts: mls.msg.IAMessageInputType[]): void;
    export function systemReturnJsonFormat(): mls.msg.IAMessageInputType;
    export function getAgentsList(): IAgentList[];
    export function getToolsList(): Promise<IToolList[]>;
    export function getRagsList(): string;
    export function systemToolsAvailable(): Promise<mls.msg.IAMessageInputType>;
    export function getListFilesStart(start: 'widget' | 'tool' | 'agent'): Promise<string[]>;
    export function systemTokensLessInstruction(): Promise<mls.msg.IAMessageInputType>;
    export function getPromptByHtml(dt: {
        project: number;
        shortName: string;
        folder: string;
        data?: any;
    }): Promise<mls.msg.IAMessageInputType[]>;
    export function getSource(dt: mls.stor.IFileInfo): Promise<string | null>;
    interface IAgentList {
        agent: string;
        description: string;
    }
    interface IToolList {
        tool: string;
        description: string;
    }
}
declare module "_100554_/l2/agentPlanner1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output1 = {
        type: "result";
        result: string;
    } | {
        type: "agent";
        agentName: string;
        title: string;
        prompt: string;
        rags: string[] | null;
    } | {
        type: "agent";
        agentName: string;
        title: string;
        prompt: string;
        rags: string[] | null;
    };
}
declare module "_100554_/l2/agentReview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentReview" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function updateFiles(context: mls.msg.ExecutionContext, result: IDataResult): Promise<void>;
    export type Output1 = {
        type: "flexible";
        result: IDataResult;
    };
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
    interface IDataResult {
        html: string;
        ts: string;
        less: string;
    }
}
declare module "_100554_/l2/aiAgentDefaultFeedback.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class AiAgentDefaultFeedback100554 extends StateLitElement {
        father: HTMLElement | undefined;
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private getChildren;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private clickDetails;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
    }
}
declare module "_100554_/l2/aiPrompts.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/ateste.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/ateste" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class SimpleGreeting extends CollabLitElement {
        teste: HTMLTextAreaElement | undefined;
        list: string[];
        current: number;
        tot: number;
        render(): any;
        clickBusca(): Promise<void>;
        changeSource(file: mls.stor.IFileInfo): Promise<string>;
        private parseXMLTripleSlash;
        private parseXML;
    }
    export interface ITripleSlashVariables {
        [key: string]: string;
    }
    export interface ITripleSlash {
        tagName: string;
        variables: ITripleSlashVariables;
    }
}
declare module "_100554_/l2/coachMarks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/coachMarks" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export function addCoachMark(json: ICoachMarks): void;
    export class CoachMarks100554 extends CollabLitElement {
        info: ICoachMarks | undefined;
        error: string;
        firstUpdated(): void;
        render(): any;
        renderError(): any;
        private setInfo;
        private setCoachMarks;
        private clearMe;
        private close;
        private setKey;
        private inLocalStorage;
        private timeInterval;
        private setGlobalDefinitions;
        private createSteps;
        private addAnimation;
        private addTextWithArrow;
        private positionStep;
        private transparency;
        private arrow;
    }
    export interface ICoachMarks {
        key: string;
        transparency: ITransparency;
        fontSize: string;
        timeClose: number;
        steps: ICoachMarkStep[];
    }
    interface ICoachMarkStep {
        elementRef?: string;
        text: string;
        position?: IPosition;
        positionNoRef?: IPositionNoRef;
        marginH?: number;
        marginV?: number;
        arrow?: IArrown;
        duration?: number;
        animation?: IAnimation;
        timeAnimation?: number;
        loopAni?: boolean;
        autoClose: boolean;
    }
    type ITransparency = 'light' | 'normal' | 'strong';
    type IPosition = 'bottom' | 'top' | 'left' | 'right';
    type IPositionNoRef = 'top-start' | 'top-center' | 'top-end' | 'center-start' | 'center-center' | 'center-end' | 'bottom-start' | 'bottom-center' | 'bottom-end';
    type IArrown = 'down' | 'up' | 'left' | 'right' | '';
    type IAnimation = 'flip' | 'pulse' | 'shake';
}
declare module "_100554_/l2/collabActionHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabActionHelper" {
    export const ambient: "RPC" | "";
    export function callBackend<Req = any, Res = any>(config: ActionRef, req: Req): Promise<Res>;
    export interface CollabTrace {
        traceId: string;
        correlationId: string;
        parentId?: string;
        layer: "organism" | "usecase" | "table" | "backend";
        module: string;
        action: string;
        origem: string;
        status?: "ok" | "warn" | "error";
        userId?: string;
        timestamp: string;
        durationMs?: number;
        params?: any;
        result?: string;
        details?: Record<string, string>;
    }
    export interface UserInfo {
        userId: string;
        name: string;
        rules: string[];
    }
    export interface ExecutionContext {
        user: UserInfo;
        authority: string[];
        tenantId: string;
        io: Record<string, string>;
        correlationId: string;
    }
    export function getExecutionContext(): ExecutionContext;
    export function addOrganismTrace(trace: CollabTrace): void;
    export function getOrganismTraces(): CollabTrace[];
    export function traceOrganismAction<Req, Res>(config: {
        module: string;
        organism: string;
        action: string;
    }, req: Req, exec: (ctx: ExecutionContext) => Promise<Res>): Promise<Res>;
    export interface ActionRef {
        module: string;
        organism: string;
        action: string;
    }
    export function withInstrumentation<Req, Res>(meta: ActionRef, handler: (req: Req, ctx: ExecutionContext) => Promise<Res>): (req: Req) => Promise<Res>;
    export function CollabAction<Req, Res>(meta: ActionRef, handler: (req: Req) => Promise<Res>): (req: Req) => Promise<Res>;
}
declare module "_100554_/l2/collabConsole.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabConsole" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabConsole100554 extends StateLitElement {
        logs: Array<{
            type: string;
            message: string;
        }>;
        height: string;
        mode: 'enabled' | 'disabled';
        scope: Window & typeof globalThis;
        private oldLog?;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private changeMode;
        private interceptConsole;
        addLog(type: string, args: any): void;
        render(): any;
    }
}
declare module "_100554_/l2/collabConsoleL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabConsoleL1" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabConsoleL1100554 extends CollabLitElement {
        output: HTMLElement | undefined;
        inputBox: HTMLInputElement | undefined;
        file: string | undefined;
        firstUpdated(): void;
        render(): any;
        private onKeyDown;
        private execute;
        private configLog;
    }
}
declare module "_100554_/l2/collabDOMSync.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabDsInputRange.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabDsInputRange" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export function initCollabDSInputRange(): void;
    export class CollabDSInputRange extends StateLitElement {
        arraySelect: string[];
        useSelect: string;
        value: string;
        valueInput: string;
        prop: string;
        min: number;
        max: number;
        render(): any;
        renderSelect(): any;
        updated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private cursorPosition;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private changeSelect;
        private allChange;
        private fireEvents;
    }
}
declare module "_100554_/l2/collabDsInputSelectColor.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabDsInputSelectColor" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export function initCollabDsInputSelectColor(): void;
    export class CollabDsInputSelectColor extends CollabLitElement {
        get value(): string;
        set value(str: string);
        get valueInput(): string;
        set valueInput(str: string);
        get valueSelect(): string;
        set valueSelect(str: string);
        get valueColor(): string;
        set valueColor(str: string);
        arrayInputSelect: string[];
        arraySelect: string[];
        _valueInput: string;
        _valueSelect: string;
        _valueColor: string;
        prop: string;
        useInput: string;
        useSelect: string;
        useColor: string;
        render(): any;
        renderInput(): any;
        renderSelect(): any;
        renderColor(): any;
        updated(): void;
        private configGetValue;
        private configSetValue;
        private onlyNumber;
        private onlyTxt;
        private handleWhell;
        private changeInput;
        private allChange;
        private fireEvents;
    }
}
declare module "_100554_/l2/collabEditMd.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabEditMd" {
    import { LitElement } from 'lit';
    export function initEditorQuillMD(): boolean;
    export class CollabEditMd extends LitElement {
        private value;
        private opened;
        containerEditor: HTMLElement | undefined;
        containerQuillEditor: HTMLTextAreaElement | undefined;
        iconFinish: HTMLElement | undefined;
        iconEdit: HTMLElement | undefined;
        set cbFinishEdit(fc: Function);
        get text(): any;
        firstUpdated(changedProperties: any): void;
        private cbFinishFc;
        private openedToolbar;
        id: string;
        easyMDE: any;
        editor: any;
        private initEditor;
        private onOpenedChanged;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private _initEditor;
        private onEditClick;
        private onFinishClick;
        render(): any;
        static styles: any;
    }
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_100554_/l2/collabEditorPreviewMd" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class PageMdPreview extends CollabLitElement {
        private _tree;
        private _error;
        _html: string;
        private _rawMd;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private configHTML;
        private parseAttrs;
        private parseAttrs_old;
        private parseFieldProps;
        private parseMd;
        private attrsStr;
        private renderNode;
        private colsToGrid;
        private renderChildren;
    }
}
declare module "_100554_/l2/collabFileSystemAccess.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabFileSystemAccess" {
    type CollabFsPermissionMode = 'read' | 'readwrite';
    type CollabFsPermissionDescriptor = {
        mode: CollabFsPermissionMode;
    };
    type CollabFsWritable = {
        write(data: string | Blob | BufferSource): Promise<void>;
        close(): Promise<void>;
    };
    export type CollabFsFileHandle = {
        kind: 'file';
        name: string;
        getFile(): Promise<File>;
        createWritable(): Promise<CollabFsWritable>;
    };
    export type CollabFsDirectoryHandle = {
        kind: 'directory';
        name: string;
        entries(): AsyncIterableIterator<[string, CollabFsDirectoryHandle | CollabFsFileHandle]>;
        getDirectoryHandle(name: string, options?: {
            create?: boolean;
        }): Promise<CollabFsDirectoryHandle>;
        getFileHandle(name: string, options?: {
            create?: boolean;
        }): Promise<CollabFsFileHandle>;
        removeEntry(name: string, options?: {
            recursive?: boolean;
        }): Promise<void>;
        queryPermission?(descriptor: CollabFsPermissionDescriptor): Promise<PermissionState>;
        requestPermission?(descriptor: CollabFsPermissionDescriptor): Promise<PermissionState>;
    };
    global {
        interface Window {
            showDirectoryPicker?: (options?: {
                mode?: CollabFsPermissionMode;
            }) => Promise<CollabFsDirectoryHandle>;
        }
    }
    export interface CollabFsLocalFile {
        path: string;
        content?: string | Blob;
        size: number;
        lastModified: number;
    }
    export interface CollabFsAccessProgress {
        current: number;
        path: string;
    }
    export interface CollabFsListOptions {
        readContent?: boolean;
    }
    export interface CollabFsAccessAdapter {
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
    }
    export class FileSystemAccessAdapter implements CollabFsAccessAdapter {
        isSupported(): boolean;
        showDirectoryPicker(): Promise<CollabFsDirectoryHandle>;
        ensurePermission(handle: CollabFsDirectoryHandle, mode?: CollabFsPermissionMode): Promise<boolean>;
        saveHandle(project: number, handle: CollabFsDirectoryHandle): Promise<void>;
        saveBaseHandle(handle: CollabFsDirectoryHandle): Promise<void>;
        getBaseHandle(): Promise<CollabFsDirectoryHandle | null>;
        removeHandle(project: number): Promise<void>;
        getHandle(project: number): Promise<CollabFsDirectoryHandle | null>;
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
        walkTextFiles(directory: CollabFsDirectoryHandle, prefix: string, files: CollabFsLocalFile[], onProgress?: (progress: CollabFsAccessProgress) => void, options?: CollabFsListOptions): Promise<void>;
        getFileHandleByPath(directory: CollabFsDirectoryHandle, path: string, create: boolean): Promise<CollabFsFileHandle | null>;
        private removeEmptyParentDirectories;
        private getDirectoryHandleByParts;
        private getDirectoryHandle;
        private isDirectoryEmpty;
        assertSafePath(path: string): void;
        shouldIgnoreDirectory(name: string): boolean;
        shouldIgnoreFile(path: string): boolean;
        shouldReadAsText(path: string): boolean;
        getProjectKey(project: number): string;
        openDB(): Promise<IDBDatabase>;
        requestToPromise<T>(request: IDBRequest<T>): Promise<T>;
        transactionDone(tx: IDBTransaction): Promise<void>;
    }
}
declare module "_100554_/l2/collabFileSystemSync.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabFileSystemSync" {
    export type CollabFsChangeKind = 'browserOnly' | 'localOnly' | 'modified' | 'unsupported' | 'browserModified' | 'diskModified' | 'bothModified' | 'diskOnly' | 'diskDeleted' | 'browserDeleted';
    interface CollabFsFileHandleLike {
        kind: 'file';
        name: string;
        getFile(): Promise<File>;
    }
    interface CollabFsDirectoryHandle {
        kind: 'directory';
        name: string;
        entries(): AsyncIterableIterator<[string, CollabFsDirectoryHandle | CollabFsFileHandleLike]>;
    }
    interface CollabFsLocalFile {
        path: string;
        content?: string | Blob;
        size: number;
        lastModified: number;
    }
    interface CollabFsAccessProgress {
        current: number;
        path: string;
    }
    export interface CollabFsManifest {
        schemaVersion: 1;
        project: number;
        selectedAt: string;
        lastSyncAt: string;
        syncMode: 'manual';
        files: Record<string, CollabFsManifestFile>;
    }
    export interface CollabFsManifestFile {
        path: string;
        versionRef: string;
        browserHash?: string;
        diskHash?: string;
        diskSize?: number;
        diskLastModified?: number;
        lastDirection: CollabFsManifestDirection;
    }
    export interface CollabFsBrowserEntry {
        path: string;
        key: string;
        file: mls.stor.IFileInfo;
        content?: string | Blob;
        hash?: string;
        versionRef: string;
        unsupported: boolean;
    }
    export interface CollabFsLocalEntry {
        path: string;
        content?: string | Blob;
        hash?: string;
        size: number;
        lastModified: number;
    }
    export interface CollabFsChange {
        path: string;
        kind: CollabFsChangeKind;
        file?: mls.stor.IFileInfo;
        browserContent?: string | Blob;
        localContent?: string | Blob;
        browserHash?: string;
        localHash?: string;
        message?: string;
    }
    export interface CollabFsScanResult {
        project: number;
        browserCount: number;
        localCount: number;
        unsupportedCount: number;
        changes: CollabFsChange[];
        scannedAt: string;
    }
    export interface CollabFsPullResult {
        written: number;
        deleted: number;
        skipped: number;
        manifest: CollabFsManifest;
    }
    export interface CollabFsPushResult {
        created: number;
        updated: number;
        deleted: number;
        skipped: number;
        manifest: CollabFsManifest;
    }
    export interface CollabFsFirstSyncValidation {
        empty: boolean;
    }
    export interface CollabFsPullPlan {
        write: string[];
        delete: string[];
        conflict: string[];
        keepLocal: string[];
    }
    export interface CollabFsPushPlan {
        create: string[];
        update: string[];
        delete: string[];
        blocked: string[];
    }
    export interface CollabFsDiffLine {
        type: 'context' | 'added' | 'removed';
        text: string;
    }
    export interface CollabFsProgress {
        phase: 'browser' | 'local' | 'compare' | 'write' | 'delete' | 'push' | 'manifest';
        current: number;
        total?: number;
        path?: string;
    }
    type CollabFsManifestDirection = 'browser-to-fs' | 'fs-to-browser' | 'linked';
    interface CollabFsSyncAdapter {
        listTextFiles(directory: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsAccessProgress) => void, options?: {
            readContent?: boolean;
        }): Promise<CollabFsLocalFile[]>;
        readTextFile(directory: CollabFsDirectoryHandle, path: string): Promise<string | null>;
        readFileContent(directory: CollabFsDirectoryHandle, path: string): Promise<string | Blob | null>;
        writeFile(directory: CollabFsDirectoryHandle, path: string, content: string | Blob): Promise<CollabFsLocalFile>;
        writeTextFile(directory: CollabFsDirectoryHandle, path: string, content: string): Promise<void>;
        removeFile(directory: CollabFsDirectoryHandle, path: string): Promise<void>;
        trashFile(directory: CollabFsDirectoryHandle, path: string, trashFolder: string): Promise<void>;
    }
    export class CollabFileSystemSync {
        private adapter;
        constructor(adapter: CollabFsSyncAdapter);
        validateFirstSync(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsFirstSyncValidation>;
        ensureManifest(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsManifest>;
        scan(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsScanResult>;
        planPull(changes: CollabFsChange[]): CollabFsPullPlan;
        planPush(changes: CollabFsChange[]): CollabFsPushPlan;
        pullToFs(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsPullResult>;
        pushToBrowser(project: number, handle: CollabFsDirectoryHandle, onProgress?: (progress: CollabFsProgress) => void): Promise<CollabFsPushResult>;
        resolveConflict(project: number, handle: CollabFsDirectoryHandle, path: string, keep: 'browser' | 'disk', onProgress?: (progress: CollabFsProgress) => void): Promise<void>;
        private upsertManifestEntry;
        private removeManifestEntry;
        readManifest(handle: CollabFsDirectoryHandle): Promise<CollabFsManifest | null>;
        buildDiff(localContent: string, browserContent: string, maxLines?: number): CollabFsDiffLine[];
        private buildSimpleDiff;
        private hasBrowserChangedSinceManifest;
        private hasLocalChangedSinceManifest;
        private getModifiedKind;
        private isBrowserSideChange;
        private isDiskSideChange;
        private applyManifestHashesToLocalMap;
        private shouldSkipPullWrite;
        private withManifestBrowserHash;
        private createBrowserFile;
        private updateBrowserFile;
        private shouldCreateModel;
        private compileModelIfNeeded;
        private logTsPushCompileResult;
        private fireBrowserFileChanged;
        private getBrowserEntries;
        private getBrowserContent;
        private getLocalEntries;
        private getLocalEntriesFromFiles;
        private hydrateBrowserEntry;
        private hydrateLocalEntry;
        private writeManifest;
        private getManifestDiskHash;
        private isBrowserFileMappable;
        private isIgnoredRootFile;
        private isProjectLayoutPath;
        private formatPathExamples;
        private isUnchangedByManifest;
        private getBrowserPath;
        private parseLocalPath;
        private isSafeRelativePath;
        private isIgnoredPath;
        private mapByPath;
        private buildTrashStamp;
        private hashContent;
    }
}
declare module "_100554_/l2/collabIcons.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabInit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverLib" {
    export function myFetchQL(info: IFetchQl): Promise<{
        status: number;
        ret: any;
    }>;
    export function getMyKeysBranch(project: number, needVerifyBranch?: boolean): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function base64ToBlob(content: string, tp: string, name: string): Promise<string | Blob>;
    export function fileToBase64(file: Blob | File): Promise<string>;
    export function base64EncodeUnicode(str: string): string;
    export function base64DecodeUnicode(str: string): string;
    interface IFetchQl {
        query: string;
        variables: any;
        url: string;
        method: string;
        headers: any;
    }
}
declare module "_100554_/l2/driverGithub" {
    export function init(initString: string): void;
    export class DriverGitHub extends mls.stor.others.DriverIOBase {
        shortName: mls.cbe.Provider;
        project: number;
        driverVersion: string;
        lastSaveInfo: {
            commits: number;
            skippedDeletions: string[];
        };
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        getHistory(fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(fileInfo: mls.stor.IFileInfo, ref: string): Promise<string | null>;
        getUrl(file: mls.stor.IFileInfo): string;
        getVersionFromFiles(project: number, options: {
            owner: string;
            repo: string;
            branchName: string;
            files: mls.stor.IFileInfo[];
        }): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(owner: string, repo: string, branchName: string): Promise<boolean>;
        createNewBranch(option: {
            owner: string;
            repo: string;
            branch: string;
            newBranch: string;
        }): Promise<boolean>;
        createPullRequest(project: number, options: {
            owner: string;
            repo: string;
            title: string;
            branch: string;
            description: string;
        }): Promise<boolean>;
        reviewPullRequest(options: {
            owner: string;
            repo: string;
            branch: string;
            idRequest: string;
            isApproved: boolean;
        }): Promise<boolean>;
        listPullRequests(owner: string, repo: string): Promise<mls.stor.others.IPullRequest[]>;
        listForks(owner: string, repo: string): Promise<mls.stor.others.IFork[]>;
        listBranches(owner: string, repo: string): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(login: string): Promise<mls.stor.others.IOrg[]>;
        createRepository(login: string, repo: string, organization: string, description: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        deleteRepository(repo: string, organization: string): Promise<boolean>;
        createFork(login: string, repoOri: string, orgOri: string, orgDest: string): Promise<boolean>;
        renameRepository(owner: string, repo: string, newName: string): Promise<boolean>;
        createFileInRepo(owner: string, repo: string, path: string, content: string | Uint8Array): Promise<boolean>;
        deleteFileInRepo(owner: string, repo: string, path: string): Promise<boolean>;
        changeVisibility(owner: string, repo: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        verifyRepositoryNew(owner: string, repo: string, user: string): Promise<"free" | "reuse" | "wait" | "error">;
        verifyPermission(owner: string, repo: string, login: string): Promise<mls.stor.others.IPermission>;
        setPermissionAction(owner: string, repo: string, login: string): Promise<boolean>;
        addVariable2(owner: string, repo: string, name: string, value: string): Promise<boolean>;
        addVariable(project: number, name: string, value: string): Promise<boolean>;
        updateVariable(project: number, name: string, value: string): Promise<boolean>;
        listVariables(project: number): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(project: number, name: string): Promise<boolean>;
        checkFork(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        syncFork(project: number, options: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        private _getUrl;
        private _getContents;
        private getContents2;
        private getContent3;
        private _setContents;
        private _setContentsOld;
        private setContents2;
        private afterSave;
        private setContentAddFile;
        private verifyAndGetContent;
        private _loadFilesInfo;
        private getFilesRepo;
        private auxLoadFilesInfo2Reenter;
        private _getHistory;
        private _getHistoryContent;
        private fecthQl;
        private filterExistingPaths;
        buildFileGroups(files: mls.stor.IFileInfo[], maxSizeBytes?: number): Promise<{
            type: 'single' | 'group';
            files: mls.stor.IFileInfo[];
        }[]>;
        private processFiles;
        private githubRequest;
        private getSha;
        private saveFile;
        private deleteFile;
        private processFilesOld;
        syncForkIO(opt: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        checkForkIO(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        private delVariableIO;
        private listVariablesIO;
        private updateVariableIO;
        private addVariableIO;
        private setPermissionActionIO;
        private verifyPermissionIO;
        private verifyRepositoryNewIO;
        private changeVisibilityIO;
        private createFileInRepoIO;
        private renameRepositoryIO;
        private createForkIO;
        private deleteRepositoryIO;
        private createRepositoryIO;
        private getOrganizationsIO;
        private getUserInfoIO;
        private listBranchesIO;
        private listForksIO;
        private listPullRequestsIO;
        private reviewPullRequestIO;
        private createPullRequestIO;
        private sleep;
        private createNewBranchIO;
        private checkBranchExistenceIO;
        private getHistoryContentIO;
        private getFilesIO;
        private getFilesRestIO;
        private verifyMKey;
        private saveMultipleFilesIO;
        private getFilesRepoIO;
        private getHistoryIO;
        private getVersionFromFilesIO;
        private getOidLastCommitFromInfoIO;
        private getIdProjectIO;
        private getOidLastCommitIO;
        private convertToBase64;
    }
}
declare module "_100554_/l2/driverGitlab" {
    export function init(initString: string): void;
    export class DriverGitLab extends mls.stor.others.DriverIOBase {
        shortName: mls.cbe.Provider;
        project: number;
        driverVersion: string;
        constructor();
        getContents: (project: number, fileInfos: mls.stor.IFileInfo[]) => Promise<mls.stor.IRegGetContents[]>;
        setContents: (project: number, fileInfos: mls.stor.IFileInfo[], comments: string | null) => Promise<boolean>;
        loadFilesInfo(project: number): Promise<mls.cbe.IPrjSourcesFiles[]>;
        getHistory(fileInfo: mls.stor.IFileInfo): Promise<mls.stor.IHistory[] | null>;
        getHistoryContent(fileInfo: mls.stor.IFileInfo, ref: string): Promise<string | null>;
        getUrl(file: mls.stor.IFileInfo): string;
        getVersionFromFiles(project: number, options: {
            owner: string;
            repo: string;
            branchName: string;
            files: mls.stor.IFileInfo[];
        }): Promise<{
            [key: string]: string;
        } | undefined>;
        checkBranchExistence(owner: string, repo: string, branchName: string): Promise<boolean>;
        createNewBranch(option: {
            owner: string;
            repo: string;
            branch: string;
            newBranch: string;
        }): Promise<boolean>;
        createPullRequest(project: number, options: {
            owner: string;
            repo: string;
            title: string;
            branch: string;
            description: string;
        }): Promise<boolean>;
        reviewPullRequest(options: {
            owner: string;
            repo: string;
            branch: string;
            idRequest: string;
            isApproved: boolean;
        }): Promise<boolean>;
        listPullRequests(owner: string, repo: string): Promise<mls.stor.others.IPullRequest[]>;
        listForks(owner: string, repo: string): Promise<mls.stor.others.IFork[]>;
        listBranches(owner: string, repo: string): Promise<mls.stor.others.IBranch[]>;
        getUserInfo(): Promise<mls.stor.others.IInfo>;
        getOrganizations(login: string): Promise<mls.stor.others.IOrg[]>;
        createRepository(login: string, repo: string, organization: string, description: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        deleteRepository(repo: string, organization: string): Promise<boolean>;
        createFork(login: string, repoOri: string, orgOri: string, orgDest: string): Promise<boolean>;
        renameRepository(owner: string, repo: string, newName: string): Promise<boolean>;
        createFileInRepo(owner: string, repo: string, path: string, content: string | Uint8Array): Promise<boolean>;
        changeVisibility(owner: string, repo: string, visibility: "PUBLIC" | "PRIVATE" | "INTERNAL"): Promise<boolean>;
        verifyRepositoryNew(owner: string, repo: string, user: string): Promise<"free" | "reuse" | "wait" | "error">;
        verifyPermission(owner: string, repo: string, login: string): Promise<mls.stor.others.IPermission>;
        addVariable(project: number, name: string, value: string): Promise<boolean>;
        updateVariable(project: number, name: string, value: string): Promise<boolean>;
        listVariables(): Promise<{
            variables: {
                name: string;
                value: string;
                created_at: string;
                updated_at: string;
            }[];
            total_count: number;
        }>;
        delVariable(project: number, name: string): Promise<boolean>;
        checkFork(ownerOrigin: string, repoOrigin: string, login: string): Promise<boolean>;
        syncFork(project: number, options: {
            repoOrigin: string;
            ownerOrigin: string;
            branchOrigin: string;
            repoDest: string;
            ownerDest: string;
            branchDest: string;
        }): Promise<boolean>;
        private _getUrl;
        private _getContents;
        private getContents2;
        private getContent;
        private _setContents;
        private setContentsnew;
        private verifyAndGetContent;
        private _loadFilesInfo;
        private getFilesRepo;
        private fecthQl;
        private myFetchGet;
        private _getHistoryContentIO;
        private _getHistoryIO;
        private getFilesRepoIO;
        private saveMultipleFilesIO;
        private getFilesIO;
        private syncForkIO;
        private checkForkIO;
        private delVariableIO;
        private listVariablesIO;
        private updateVariableIO;
        private addVariableIO;
        private verifyPermissionIO;
        private verifyRepositoryNewIO;
        private changeVisibilityIO;
        private getVersionFromFilesIO;
        private createFileInRepoIO;
        private renameRepositoryIO;
        private createForkIO;
        private deleteRepositoryIO;
        private createRepositoryIO;
        private getOrganizationsIO;
        private getUserInfoIO;
        private listBranchesIO;
        private listForksIO;
        private listPullRequestsIO;
        private reviewPullRequestIO;
        private createPullRequestIO;
        private createNewBranchIO;
        private checkBranchExistenceIO;
        private getLastCommitFromInfo;
        private getIDProject;
    }
}
declare module "_100554_/l2/collabManagerCoachMarks" {
    export function initManagerCoachMark(): void;
}
declare module "_100554_/l2/collabInit" {
    import { LitElement } from 'lit';
    export function initCompileMonaco(project: number): Promise<boolean>;
    export class CollabInit extends LitElement {
        private actualProject;
        /**
         * Indicates if the user is anonymous based on the cookie loginUser
         * @returns `true` if the user is anonymous; otherwise, `false`.
         */
        get isAnonymous(): boolean;
        /**
         * Retrieves the avatar URL from the `avatarUrl` attribute.
         * @returns The URL of the avatar, or an empty string if not defined.
         */
        get avatarUrl(): string;
        /**
         * Retrieves the base Project from the `baseProject` attribute.
         * @returns The URL of the avatar, or an empty string if not defined.
         */
        get baseProject(): number;
        /**
         * Lit lifecycle method called after the component is first updated.
         * Initializes the component's configuration.
         */
        firstUpdated(): void;
        render(): any;
        /**
         * Initializes the system life cycle.
         * To show logs using: https://collab.codes/?traceLifeCycle=true
         */
        private init;
        private setEventsModel;
        private setEvents;
        private onLevelChanged;
        private firstAccessLevels;
        private levelHandlers;
        private onLevelChangedToL2;
        /**
         * Loads and sets up collaboration drivers asynchronously.
         */
        private setDrivers;
        /**
         * Instantiates and registers the GitHub collaboration driver asynchronously.
         */
        private instanceDriverGitHub;
        /**
         * Instantiates and registers the GitLab collaboration driver asynchronously.
         */
        private instanceDriverGitLab;
        /**
         * Sets the base URL for the project and retrieves the user's language.
         * @returns The user's language (e.g., 'en-US', 'pt-BR').
         */
        private setAndGetBaseUrl;
        /**
         * Retrieves the user's preferred language or defaults to 'en-US'.
         * @returns The user's language.
         */
        private getUserLanguageOrDefault;
        /**
         * Retrieves the browser's language setting.
         * @returns The browser's language.
         */
        private getNavigatorLanguage;
        /**
         * Sets the `lang` attribute of the HTML `<html>` element.
         * @param lang The language code to set (e.g., 'en-US').
         */
        private setHTMLLang;
        private initCoachMark;
        /**
         * Sets the theme for the application based on user settings or OS preferences.
         */
        private setTheme;
        /**
         * Retrieves the theme from user settings or defaults to the OS preference.
         * @returns The theme ('dark' or 'light').
         */
        private getTheme;
        /**
         * Retrieves the user's OS theme preference.
         * @returns The OS theme preference ('dark' or 'light').
         */
        private getUserThemeOS;
        /**
         * Sets CSS tokens for light and dark themes by retrieving data from a cache.
         */
        private setTokensCss;
        /**
         * Configures navigation settings, including avatar and status, for the collaboration interface.
         * @param avatarUrl The URL of the avatar.
         * @param language The user's language.
         * @param isAnonymous Indicates whether the user is anonymous.
         */
        private enableNav;
        private flags;
        /**
         * Retrieves the last selected project ID from localStorage.
         * @returns The last selected project ID as a number, or `undefined` if not found.
         */
        private getLastProjectSelected;
        /**
         * Sets the actual project in the `mls` structure based on the last selected project.
         * @returns The last selected project ID as a number, or `undefined` if not found.
         */
        private setProjectActual;
        /**
         * Sets the current organization in the `mls` structure based on the provided project ID.
         * @param project The project ID to determine the organization index.
         */
        private setOrgActual;
        /**
         * Asynchronously loads the base project information if it is not already loaded.
         * Utilizes the `mls.stor.server.loadProjectInfoIfNeeded` method with the base project ID.
         * @returns A promise that resolves when the base project information is loaded.
         */
        private loadProjectBase;
        /**
         * Loads the information of the last accessed project if it exists.
         * If the `actualProject` is defined, it attempts to load the project's information
         * from the server using the `loadProjectInfoIfNeeded` method.
         *
         * Optionally logs the lifecycle trace if the global `traceLifeCycle` is enabled.
         *
         * @returns A promise that resolves when the project information has been loaded.
         */
        private loadLastProject;
        private setLastOpenedFiles;
        private FILEL6;
        private FILEL5;
        private setDefaultFiles;
        private restoreSideFile;
        private getPath;
        private setLastModule;
        /**
         * Checks for the presence of a `<collab-sticky-notification>` element on the page.
         * If found, it invokes the `show()` method on the element to display notifications.
         */
        private showMessagesIfNeeded;
        private anonymousServices;
        /**
         * Retrieves a list of services for the current project, either for anonymous users or regular users.
         * If the user is anonymous, it returns the `anonymousServices`. Otherwise, it loads project-specific
         * services by fetching and sorting the available menu actions for different levels and positions (Left/Right).
         *
         * @returns A promise that resolves to an object containing an array of services, sorted by priority.
         * The services are categorized by levels and positions (Left/Right) and are returned as a semicolon-separated
         * string for each level.
         */
        private getServices;
    }
}
declare module "_100554_/l2/collabInputTag.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabInputTag" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export function initCollabInputTag(): boolean;
    export class CollabInputTag extends StateLitElement {
        tags: string[];
        input: HTMLInputElement | undefined;
        pattern: string | null;
        placeholder: string | null;
        allowDelete: boolean;
        hasError: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputLeave;
        private onInputKeyDown;
        private isValidTag;
        render(): any;
    }
}
declare module "_100554_/l2/collabL3EditText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabL3PreviewText" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabL3PreviewText extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "_100554_/l2/collabL3PreviewTextAttr" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabL3PreviewText extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "_100554_/l2/collabL3PreviewTextI18n" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabL3PreviewTextI18n extends StateLitElement {
        findby: string;
        value: string | undefined;
        render(): any;
        handleChange(event: Event): void;
        handleClick(event: Event): void;
        private timeFireEvent;
        private fireEvent;
        private onSelect;
    }
}
declare module "_100554_/l2/collabL3EditText" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabL3PreviewText";
    import "_100554_/l2/collabL3PreviewTextAttr";
    import "_100554_/l2/collabL3PreviewTextI18n";
    export class CollabL3EditText extends CollabLitElement {
        dev: boolean;
        target: HTMLElement | null;
        private json;
        private baseTexti18n;
        private baseSearch;
        constructor();
        firstUpdated(): void;
        render(): any;
        private getBaseI18n;
        private process;
        private initState;
        private addEls;
        save(): Promise<boolean>;
        private replaceValueAfterKeyWithUndo;
        private replaceAttributeValueWithUndo;
        private replaceI18nValueWithUndo;
    }
}
declare module "_100554_/l2/collabL3PreviewText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabL3PreviewTextAttr.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabL3PreviewTextI18n.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabLanguages.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabLanguages" {
    export const languages: ICollabLanguage[];
    export interface ICollabLanguage {
        code: string;
        name: string;
    }
}
declare module "_100554_/l2/collabManagerCoachMarks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabNav4Menu.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabNav4Menu" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    interface TabItem {
        text: string;
        icon?: string;
        allowClose?: boolean;
    }
    export class CollabNav4Menu extends StateLitElement {
        selectedIndex: number;
        mode: 'full' | 'onlyicon' | 'fixed';
        options: TabItem[];
        private isDropdownOpen;
        private toggleDropdown;
        private handleSelect;
        private handleClose;
        render(): any;
        private renderNav;
    }
}
declare module "_100554_/l2/collabOrgHome.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-home-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-home-100554\n  file: _100554_/l2/collabOrgHome.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays an organization overview card with name, description and\n    counters for projects, users and teams. Data is read from mls.stor\n    on connectedCallback.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during initial fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed in the error state\n    - name: _data\n      type: OrgData | null\n      default: null\n      description: Organization data fetched from mls.stor\n\n  interfaces:\n    OrgData:\n      name: string\n      description: string\n      totalProjects: number\n      totalUsers: number\n      totalTeams: number\n\n  lifecycle:\n    connectedCallback: calls _fetchOrg()\n\n  methods:\n    _fetchOrg:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', _data = null, call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - populate _data from lastOrg.sett\n        - on catch: set _error from err.message or msg.error\n        - finally: set _loading = false, call requestUpdate()\n      field_mapping:\n        name: orgName\n        description: lastOrg.sett.description\n        totalProjects: lastOrg.sett.projects.length\n        totalUsers: lastOrg.sett.users.length\n        totalTeams: lastOrg.sett.teams.length\n\n  events: []\n\n  render:\n    priority_order:\n      - if _loading \u2192 _renderLoading()\n      - if _error   \u2192 _renderError()\n      - if _data    \u2192 _renderData(_data)\n      - fallback    \u2192 empty template\n\n    loading_state:\n      element: div.state-loading\n      children:\n        - span.spinner\n        - span \u2192 msg.loading\n\n    error_state:\n      element: div.state-error\n      children:\n        - span.error-icon \u2192 \u26A0 (static)\n        - span \u2192 this._error\n        - button @click \u2192 _fetchOrg() \u2192 msg.again\n\n    data_state:\n      element: div.org-card\n      children:\n        - div.org-header:\n            children:\n              - h1.org-name \u2192 data.name\n              - p.org-description \u2192 data.description or 'no description' if empty\n        - div.org-counters:\n            children:\n              - div.counter:\n                  - span.counter-value \u2192 data.totalProjects\n                  - span.counter-label \u2192 msg.projects\n              - div.counter:\n                  - span.counter-value \u2192 data.totalUsers\n                  - span.counter-label \u2192 msg.users\n              - div.counter:\n                  - span.counter-value \u2192 data.totalTeams\n                  - span.counter-label \u2192 msg.teams\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgHome" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabOrgHome extends CollabLitElement {
        private msg;
        project: number;
        private _loading;
        private _error;
        private _data;
        connectedCallback(): void;
        private _fetchOrg;
        private _renderLoading;
        private _renderError;
        private _renderData;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgInviteUser.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-invite-user-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-invite-user-100554\n  file: _100554_/l2/collabOrgInviteUser.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Form for inviting a user to an organization. Receives teams list and\n    loading/status state from the parent via props. Dispatches invite-submit\n    with form data, leaving submission logic to the parent.\n\n  props:\n    - name: teams\n      type: string[]\n      default: []\n      description: List of team names used to populate the team select options\n    - name: loading\n      type: boolean\n      default: false\n      description: Disables all fields and submit button when true\n    - name: status\n      type: InviteStatus\n      default: idle\n      description: Controls which feedback message is displayed\n\n  internal_state:\n    - name: _usernameOrEmail\n      type: string\n      default: \"\"\n      description: Current value of the username or email input\n    - name: _initialTeam\n      type: string\n      default: \"\"\n      description: Current value of the team select\n    - name: _complementaryText\n      type: string\n      default: \"\"\n      description: Current value of the complementary text textarea\n\n  interfaces:\n    InviteStatus: \"'idle' | 'success' | 'error'\"\n\n  methods:\n    _handleInput:\n      returns: void\n      params:\n        - field: \"'username' | 'team' | 'text'\"\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement\n        - if field === 'username': set _usernameOrEmail = target.value\n        - if field === 'team': set _initialTeam = target.value\n        - if field === 'text': set _complementaryText = target.value\n        - call requestUpdate()\n\n    _handleSubmit:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - call e.preventDefault()\n        - dispatch CustomEvent('invite-submit') with detail below, bubbles true, composed true\n        - detail: { username_or_email: _usernameOrEmail, initial_team: _initialTeam, complementary_text: _complementaryText }\n\n    _renderFeedback:\n      returns: TemplateResult\n      steps:\n        - if status === 'success' \u2192 div.feedback.success with msg.feedbackSuccess\n        - if status === 'error'   \u2192 div.feedback.error with msg.feedbackError\n        - otherwise \u2192 empty template\n\n  events:\n    - name: invite-submit\n      when: form is submitted\n      detail:\n        username_or_email: string\n        initial_team: string\n        complementary_text: string\n      options: { bubbles: true, composed: true }\n\n  render:\n    root:\n      element: form.invite-form\n      event: \"@submit \u2192 _handleSubmit(e)\"\n      fields:\n        - id: invite-username\n          label_key: fieldUsername\n          element: input\n          type: text\n          value_binding: _usernameOrEmail\n          disabled_when: loading\n          event: \"@input \u2192 _handleInput('username', e)\"\n\n        - id: invite-team\n          label_key: fieldTeam\n          element: select\n          value_binding: _initialTeam\n          disabled_when: loading\n          event: \"@change \u2192 _handleInput('team', e)\"\n          options:\n            - value: \"\" \u2192 msg.fieldTeamPlaceholder (default option)\n            - map this.teams to option[value=t] with t as label\n\n        - id: invite-text\n          label_key: fieldCompText\n          element: textarea\n          rows: 3\n          value_binding: _complementaryText\n          disabled_when: loading\n          event: \"@input \u2192 _handleInput('text', e)\"\n\n      footer:\n        - _renderFeedback()\n        - div.form-actions:\n            - button.btn-primary type=submit ?disabled=loading\n                label: if loading then msg.btnSubmitting else msg.btnSubmit\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgInviteUser" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    type InviteStatus = 'idle' | 'success' | 'error';
    export class CollabOrgInviteUser extends CollabLitElement {
        teams: string[];
        loading: boolean;
        status: InviteStatus;
        private msg;
        private _usernameOrEmail;
        private _initialTeam;
        private _complementaryText;
        private _handleInput;
        private _handleSubmit;
        private _renderFeedback;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgManager.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-manager-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-manager-100554\n  file: _100554_/l2/collabOrgManager.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Shell component that renders a sidebar navigation and dynamically displays\n    the active section component. Acts as the layout manager for all\n    organization sub-pages.\n\n  imports:\n    - /_100554_/l2/collabOrgHome.js\n    - /_100554_/l2/collabOrgSettings.js\n    - /_100554_/l2/collabOrgProjects.js\n    - /_100554_/l2/collabOrgUsers.js\n    - /_100554_/l2/collabOrgTeams.js\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index passed down to every section component\n    - name: activeSection\n      type: string\n      default: home\n      description: Key of the currently active section\n\n  internal_state:\n    - name: _menuItems\n      type: Array<{ section: string; label: string }>\n      description: Static list of visible menu entries\n      value:\n        - { section: home,     label: Home }\n        - { section: settings, label: Settings }\n        - { section: projects, label: Projects }\n        - { section: users,    label: Users }\n        - { section: teams,    label: Teams }\n      commented_out:\n        - { section: trash,    label: Trash }\n        - { section: explorer, label: Explorer }\n        - { section: verify,   label: Verify }\n\n  methods:\n    _handleSectionClick:\n      returns: void\n      params:\n        - section: string\n      steps:\n        - set this.activeSection = section\n        - dispatch CustomEvent('section-changed') with detail { section }, bubbles true, composed true\n\n    _renderIcon:\n      returns: TemplateResult\n      params:\n        - section: string\n      steps:\n        - define a Record<string, TemplateResult> map with inline SVG for each key\n        - return icons[section] or html`` if not found\n      icon_keys:\n        - home\n        - settings\n        - projects\n        - trash\n        - users\n        - teams\n        - explorer\n        - verify\n\n    _renderSection:\n      returns: TemplateResult\n      steps:\n        - define a Record<string, TemplateResult> sectionMap with one child element per key\n        - each child receives prop project=\"${this.project}\"\n        - return sectionMap[this.activeSection] or div.fallback if not found\n      section_map:\n        home:     collab-org-home-100554\n        settings: collab-org-settings-100554\n        projects: collab-org-projects-100554\n        trash:    collab-org-trash-100554\n        users:    collab-org-users-100554\n        teams:    collab-org-teams-100554\n        explorer: collab-org-explorer-100554\n        verify:   collab-org-verify-100554\n\n  events:\n    - name: section-changed\n      when: when a menu item is clicked\n      detail: { section: string }\n      options: { bubbles: true, composed: true }\n\n  render:\n    root:\n      element: div.layout\n      children:\n        - nav.sidebar:\n            content: >\n              maps _menuItems to div.menu-item elements.\n              active item receives class \"active\" when section === activeSection.\n              each item has @click \u2192 _handleSectionClick(item.section).\n              each item has @keydown \u2192 calls _handleSectionClick on Enter or Space.\n              each item has tabindex=\"0\".\n            children_per_item:\n              - span.menu-icon \u2192 _renderIcon(item.section)\n              - span.menu-label \u2192 this.msg[item.section] (cast as any)\n              - span.menu-arrow \u2192 \u203A (static)\n        - main.content:\n            content: _renderSection()\n\n  i18n:\n    languages: [en, pt]\n    default: en\n\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgSettings" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabOrgSettings extends CollabLitElement {
        project: number;
        private msg;
        private _loading;
        private _saving;
        private _error;
        private _successMessage;
        private _form;
        connectedCallback(): void;
        private _fetchSettings;
        private _handleSave;
        private _handleInput;
        private _handleArchive;
        private _handleDelete;
        private _renderLoading;
        private _renderFeedback;
        private _renderForm;
        private _renderDangerZone;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgProjects" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabOrgProjects extends CollabLitElement {
        project: number;
        private msg;
        private projects;
        private searchQuery;
        private _loading;
        private _error;
        connectedCallback(): void;
        private fetchProjects;
        private handleSearch;
        private handleViewProject;
        private getFiltered;
        private renderProjectList;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgUsers" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabOrgInviteUser";
    export class CollabOrgUsers extends CollabLitElement {
        project: number;
        private msg;
        private _members;
        private _accessMap;
        private _loading;
        private _error;
        private _inviteOpen;
        connectedCallback(): void;
        private _fetchMembers;
        private configUsers;
        private _fetchAllAccess;
        private _fetchRepoAccess;
        private _toggleInvite;
        private _handleInviteSuccess;
        private _renderAccessBadge;
        private _renderAccessCell;
        private _renderTable;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgTeamCard" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    interface Member {
        idx: number;
        name: string;
        avatar: string;
    }
    export class CollabOrgTeamCard extends CollabLitElement {
        private team;
        project: number;
        members: Member[];
        users: Member[];
        loading: boolean;
        private msg;
        private _addOpen;
        private _addUsername;
        private _confirmingRemove;
        firstUpdated(): void;
        private _toggleAdd;
        private _handleAddInput;
        private _handleAdd;
        private _requestRemove;
        private _cancelRemove;
        private _confirmRemove;
        private _renderMember;
        private _renderAddForm;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgTeams" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabOrgTeamCard";
    export class CollabOrgTeams extends CollabLitElement {
        project: number;
        private msg;
        private _teams;
        private _loading;
        private _error;
        private _expandedTeam;
        private _newTeamOpen;
        private _newTeamName;
        private _formStatus;
        private _formError;
        connectedCallback(): void;
        private _fetchTeams;
        private configTeams;
        private _handleCreate;
        private _toggleExpand;
        private _toggleNewTeam;
        private _handleNameInput;
        private _emitViewProjects;
        private _emitViewUsers;
        private _renderNewTeamForm;
        private _renderTable;
        private _renderRow;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgManager" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabOrgHome";
    import "_100554_/l2/collabOrgSettings";
    import "_100554_/l2/collabOrgProjects";
    import "_100554_/l2/collabOrgUsers";
    import "_100554_/l2/collabOrgTeams";
    export class CollabOrgManager extends CollabLitElement {
        private msg;
        project: number;
        activeSection: string;
        private _handleSectionClick;
        private _renderIcon;
        private _renderSection;
        private _menuItems;
        render(): TemplateResult;
    }
}
declare module "_100554_/l2/collabOrgProjects.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-projects-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-projects-100554\n  file: _100554_/l2/collabOrgProjects.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays active and archived projects of an organization, with a search\n    filter. Each project has a \"View project\" button that switches the active\n    project and reloads the page.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: projects\n      type: mls.cbe.IPrj_settings[]\n      default: []\n      description: Full list of projects fetched from mls.stor\n    - name: searchQuery\n      type: string\n      default: \"\"\n      description: Current value of the search input\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed when fetch fails\n\n  lifecycle:\n    connectedCallback: calls fetchProjects()\n\n  methods:\n    fetchProjects:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - set this.projects = lastOrg.sett.projects\n        - on catch: set _error from err.message or 'Unknown error'\n        - finally: set _loading = false, call requestUpdate()\n\n    handleSearch:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement\n        - set this.searchQuery = input.value\n        - call requestUpdate()\n\n    handleViewProject:\n      returns: void\n      params:\n        - project: mls.cbe.IPrj_settings\n      steps:\n        - call mls.setActualProject(project.id)\n        - call mls.l5.getProjectOrgIndex(project.id) to get orgIndex\n        - call mls.l5.setActualOrg(orgIndex)\n        - call window.location.reload()\n\n    getFiltered:\n      returns: mls.cbe.IPrj_settings[]\n      params:\n        - archived: boolean\n      steps:\n        - lowercase this.searchQuery into query\n        - filter this.projects where p.name includes query\n        - when archived=true also require p.archived_at !== ''\n        - when archived=false no archived_at restriction\n\n    renderProjectList:\n      returns: TemplateResult\n      params:\n        - items: mls.cbe.IPrj_settings[]\n      steps:\n        - if items.length === 0 return p.no-results with msg.noResults\n        - otherwise return ul.project-list\n        - each item is li.project-item with span.project-name and button.btn-view\n        - span.project-name shows p.name(p.id)\n        - button.btn-view @click \u2192 handleViewProject(p) \u2192 msg.viewProject\n\n  events: []\n\n  render:\n    priority_order:\n      - if _loading \u2192 div.state-loading with span.spinner and span msg.loading\n      - if _error   \u2192 div.feedback.error with msg.error\n      - default     \u2192 full layout\n\n    default_layout:\n      element: div.container\n      children:\n        - input.search-input:\n            type: text\n            placeholder: msg.searchPlaceholder\n            value binding: this.searchQuery\n            event: \"@input \u2192 handleSearch\"\n        - section.section:\n            title: h2.section-title \u2192 msg.activeProjects\n            content: renderProjectList(getFiltered(false))\n        - section.section:\n            title: h2.section-title \u2192 msg.archivedProjects\n            content: renderProjectList(getFiltered(true))\n  \n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgSettings.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-settings-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-settings-100554\n  file: _100554_/l2/collabOrgSettings.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Form for editing an organization's registration data, with data reading\n    via mls.stor, save with feedback, and a danger zone section with\n    destructive actions.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during initial fetch\n    - name: _saving\n      type: boolean\n      default: false\n      description: Disables Save button and shows \"Saving\u2026\" during submit\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed below the form\n    - name: _successMessage\n      type: string\n      default: \"\"\n      description: Success message displayed below the form\n    - name: _form\n      type: OrgSettings\n      default: { url: \"\", company: \"\", location: \"\", email: \"\", logo: \"\", description: \"\" }\n      description: Form data being edited\n\n  interfaces:\n    OrgSettings:\n      url: string\n      company: string\n      location: string\n      email: string\n      logo: string\n      description: string\n\n  lifecycle:\n    connectedCallback: calls _fetchSettings()\n\n  methods:\n    _fetchSettings:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName].value and JSON.parse it\n        - extract l5_actionOrgSettings from parsed object\n        - map fields to _form\n        - if org not found: set _error = \"Not found organization\"\n        - on catch: set _error from err.message\n        - finally: set _loading = false, call requestUpdate()\n      field_mapping:\n        html_url: url\n        company: company\n        location: location\n        email: email\n        logo: logo\n        description: description\n\n    _handleSave:\n      returns: Promise<void>\n      steps:\n        - call e.preventDefault()\n        - set _saving = true, clear _error and _successMessage, call requestUpdate()\n        - build payload { l5_actionOrgSettings: { ...this._form } } typed as any\n        - call mls.l5.setProjectSettings() \u2014 pending, keep commented\n        - simulate 600ms delay via Promise + setTimeout\n        - set _successMessage = this.msg.feedbackSuccess\n        - dispatch org-updated event\n        - on catch: set _error from err.message\n        - finally: set _saving = false, call requestUpdate()\n\n    _handleInput:\n      returns: void\n      params:\n        - field: keyof OrgSettings\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement | HTMLTextAreaElement\n        - update _form immutably with new field value\n        - clear _successMessage\n\n    _handleArchive:\n      returns: void\n      steps:\n        - empty body, future implementation\n\n    _handleDelete:\n      returns: void\n      steps:\n        - dispatch org-deleted event\n\n  events:\n    - name: org-updated\n      when: after saving successfully\n      options: { bubbles: true, composed: true }\n    - name: org-deleted\n      when: when Delete button is clicked\n      options: { bubbles: true, composed: true }\n\n  render:\n    loading_state:\n      element: div.state-loading\n      children:\n        - span.spinner\n        - span with msg.loadingSettings\n\n    feedback:\n      - condition: _successMessage truthy\n        element: div.feedback.success\n      - condition: _error truthy\n        element: div.feedback.error\n      - condition: neither\n        element: empty template\n\n    form:\n      element: form.settings-form\n      event: submit \u2192 _handleSave\n      fields:\n        - label_key: fieldUrl\n          element: input\n          type: url\n          field: url\n        - label_key: fieldCompany\n          element: input\n          type: text\n          field: company\n        - label_key: fieldLocation\n          element: input\n          type: text\n          field: location\n        - label_key: fieldEmail\n          element: input\n          type: email\n          field: email\n        - label_key: fieldLogo\n          element: input\n          type: url\n          field: logo\n        - label_key: fieldDescription\n          element: textarea\n          rows: 6\n          field: description\n          label_hint: fieldDescriptionHint\n      footer:\n        - feedback block\n        - button.btn-primary type=submit\n          disabled_when: _saving\n          label_key_default: btnSave\n          label_key_saving: btnSaving\n\n    danger_zone:\n      element: section.danger-zone\n      title: h2.danger-title \u2192 msg.dangerTitle\n      items:\n        - title_key: archiveTitle\n          desc_key: archiveDesc\n          button_class: btn-warning\n          action: _handleArchive()\n        - title_key: deleteTitle\n          desc_key: deleteDesc\n          button_class: btn-danger\n          action: _handleDelete()\n\n    root:\n      condition: not _loading\n      element: div.settings-root\n      children:\n        - h1.page-title \u2192 msg.pageTitle\n        - _renderForm()\n        - _renderDangerZone()\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgTeamCard.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-settings-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-team-card-100554\n  file: _100554_/l2/collabOrgTeamCard.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays the member list of a single team. Allows adding a new member\n    via a select dropdown and removing existing members with an inline\n    confirmation step. Data is read from mls.stor on firstUpdated.\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n    - name: members\n      type: Member[]\n      default: []\n      description: Current list of members in this team, populated on firstUpdated\n    - name: users\n      type: Member[]\n      default: []\n      description: Full list of org users used to populate the add select, populated on firstUpdated\n    - name: loading\n      type: boolean\n      default: false\n      description: Disables action buttons when true\n\n  internal_state:\n    - name: team\n      type: Team | undefined\n      default: undefined\n      description: >\n        Team object passed via property binding (.team) from parent.\n        Not decorated with @property \u2014 received as a direct property set.\n    - name: _addOpen\n      type: boolean\n      default: false\n      description: Controls visibility of the add user form\n    - name: _addUsername\n      type: string\n      default: \"\"\n      description: Current value of the add user select\n    - name: _confirmingRemove\n      type: string | null\n      default: null\n      description: Username currently pending removal confirmation, null if none\n\n  interfaces:\n    Member:\n      idx: number\n      name: string\n      avatar: string\n\n    Team:\n      name: string\n      auth: string\n      projectCount: number\n      userCount: number\n      users: Member[]\n\n  lifecycle:\n    firstUpdated:\n      steps:\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: return early\n        - if this.team is defined: set this.members = this.team.users\n        - iterate lastOrg.sett.users and build Member[] with idx, name, avatar placeholder\n        - assign result to this.users\n\n  methods:\n    _toggleAdd:\n      returns: void\n      steps:\n        - toggle _addOpen\n        - reset _addUsername = ''\n        - call requestUpdate()\n\n    _handleAddInput:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement\n        - set _addUsername = target.value\n\n    _handleAdd:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - call e.preventDefault()\n        - if _addUsername.trim() is empty: return\n        - set _addOpen = false, _addUsername = ''\n        - call requestUpdate()\n      note: actual add logic is not yet implemented, body is a placeholder\n\n    _requestRemove:\n      returns: void\n      params:\n        - username: string\n      steps:\n        - set _confirmingRemove = username\n        - call requestUpdate()\n\n    _cancelRemove:\n      returns: void\n      steps:\n        - set _confirmingRemove = null\n        - call requestUpdate()\n\n    _confirmRemove:\n      returns: void\n      params:\n        - username: string\n      steps:\n        - set _confirmingRemove = null\n        - call requestUpdate()\n      note: actual remove logic is not yet implemented, body is a placeholder\n\n    _renderMember:\n      returns: TemplateResult\n      params:\n        - m: Member\n      steps:\n        - derive confirming = _confirmingRemove === m.name\n        - render li.member-item with div.member-info (img.avatar + span.member-name)\n        - if confirming: render div.confirm-inline with\n            span.confirm-label \u2192 msg.confirmMessage\n            button.btn-danger ?disabled=loading @click \u2192 _confirmRemove(m.name) \u2192 msg.confirmRemove\n            button.btn-secondary @click \u2192 _cancelRemove() \u2192 msg.cancelRemove\n        - otherwise: render button.btn-remove ?disabled=loading @click \u2192 _requestRemove(m.name) with \uD83D\uDDD1 icon\n\n    _renderAddForm:\n      returns: TemplateResult\n      steps:\n        - render form.add-form @submit \u2192 _handleAdd(e)\n        - select.add-input with placeholder=msg.addUserPlaceholder, .value=_addUsername, ?disabled=loading, @input \u2192 _handleAddInput\n          options:\n            - option value=\"-1\" empty label (default)\n            - map this.users to option[value=u.idx] with u.name as label\n        - button.btn-primary type=submit ?disabled=loading \u2192 msg.btnAdd\n        - button.btn-secondary type=button @click \u2192 _toggleAdd() \u2192 msg.btnCancel\n\n  events: []\n\n  render:\n    root:\n      element: div.team-card\n      children:\n        - ul.member-list:\n            if members.length > 0: map members to _renderMember(m)\n            otherwise: li.no-members \u2192 msg.noMembers\n        - div.add-section:\n            if _addOpen: _renderAddForm()\n            otherwise: button.btn-add-toggle ?disabled=loading @click \u2192 _toggleAdd()\n                        label: \"+ \" + msg.addUser\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n\n";
}
declare module "_100554_/l2/collabOrgTeams.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-teams-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-teams-100554\n  file: _100554_/l2/collabOrgTeams.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays a table of organization teams with name, auth, project count\n    and user count. Supports expanding a row to show a team card, and\n    includes a togglable form to create new teams.\n\n  imports:\n    - /_100554_/l2/collabOrgTeamCard.js\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _teams\n      type: Team[]\n      default: []\n      description: List of teams fetched from mls.stor\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed when fetch fails\n    - name: _expandedTeam\n      type: Team | null\n      default: null\n      description: Currently expanded team row, null if none\n    - name: _newTeamOpen\n      type: boolean\n      default: false\n      description: Controls visibility of the new team form\n    - name: _newTeamName\n      type: string\n      default: \"\"\n      description: Current value of the new team name input\n    - name: _formStatus\n      type: FormStatus\n      default: idle\n      description: Current status of the create form\n    - name: _formError\n      type: string\n      default: \"\"\n      description: Error message shown inside the create form\n\n  interfaces:\n    Team:\n      name: string\n      auth: string\n      projectCount: number\n      userCount: number\n      users: \"{ idx: number; name: string; avatar: string }[]\"\n\n    FormStatus: \"'idle' | 'saving' | 'success' | 'error'\"\n\n  lifecycle:\n    connectedCallback: calls _fetchTeams()\n\n  methods:\n    _fetchTeams:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - call configTeams(lastOrg) and assign to _teams\n        - on catch: set _error from err.message or 'Unknown error'\n        - finally: set _loading = false, call requestUpdate()\n\n    configTeams:\n      returns: Team[]\n      params:\n        - info: mls.cbe.IOrgInfo\n      steps:\n        - iterate info.sett.teams with forEach\n        - for each team build Team with name, auth, projectCount=0, userCount=t.usrIndex.length, users=[]\n        - iterate info.sett.users and push { idx, name, avatar placeholder } if usrIndex includes idx\n        - return teams array\n\n    _handleCreate:\n      returns: Promise<void>\n      params:\n        - e: Event\n      steps:\n        - call e.preventDefault()\n        - set _formStatus = 'saving', _formError = '', call requestUpdate()\n        - simulate 600ms delay (real fetch commented out, keep as comment)\n        - dispatch CustomEvent('team-created') with detail { name: _newTeamName }, bubbles true, composed true\n        - set _formStatus = 'success', clear _newTeamName\n        - call _fetchTeams()\n        - set _newTeamOpen = false, _formStatus = 'idle'\n        - on catch: set _formStatus = 'error', _formError from err.message or 'Unknown error'\n        - finally: call requestUpdate()\n\n    _toggleExpand:\n      returns: void\n      params:\n        - team: Team\n      steps:\n        - if _expandedTeam === team set _expandedTeam = null, otherwise set _expandedTeam = team\n        - call requestUpdate()\n\n    _toggleNewTeam:\n      returns: void\n      steps:\n        - toggle _newTeamOpen\n        - reset _newTeamName = '', _formStatus = 'idle', _formError = ''\n        - call requestUpdate()\n\n    _handleNameInput:\n      returns: void\n      params:\n        - e: Event\n      steps:\n        - cast e.target to HTMLInputElement\n        - set _newTeamName = target.value\n\n    _emitViewProjects:\n      returns: void\n      params:\n        - teamName: string\n      steps:\n        - dispatch CustomEvent('view-team-projects') with detail { team_name: teamName }, bubbles true, composed true\n\n    _emitViewUsers:\n      returns: void\n      params:\n        - teamName: string\n      steps:\n        - dispatch CustomEvent('view-team-users') with detail { team_name: teamName }, bubbles true, composed true\n\n    _renderNewTeamForm:\n      returns: TemplateResult\n      steps:\n        - derive saving = _formStatus === 'saving'\n        - render div.new-team-form-wrapper containing form.new-team-form\n        - form @submit \u2192 _handleCreate(e)\n        - div.form-group with label and input#new-team-name\n          input: type text, .value=_newTeamName, ?disabled=saving, @input \u2192 _handleNameInput\n        - if _formStatus === 'error': div.feedback.error with _formError or msg.feedbackError\n        - div.form-actions with two buttons:\n            - button.btn-secondary type=button ?disabled=saving @click \u2192 _toggleNewTeam() \u2192 msg.btnCancel\n            - button.btn-primary type=submit ?disabled=saving \u2192 msg.btnCreating if saving else msg.btnCreate\n\n    _renderTable:\n      returns: TemplateResult\n      steps:\n        - if _teams.length === 0 \u2192 p.no-teams with msg.noTeams\n        - otherwise \u2192 div.table-wrapper with table.teams-table\n      table_structure:\n        thead:\n          columns: [colTeam, colAuth, colProjects, colUsers]\n        tbody:\n          row_per_team: _renderRow(t)\n\n    _renderRow:\n      returns: TemplateResult\n      params:\n        - t: Team\n      steps:\n        - derive expanded = _expandedTeam?.name === t.name\n        - render tr.team-row with class 'expanded' if expanded\n          cells:\n            - td.td-name \u2192 t.name\n            - td.td-auth \u2192 span.badge.auth-{t.auth} with t.auth\n            - td.td-link \u2192 \"{t.projectCount} projects\" (static text)\n            - td.td-link \u2192 button.btn-link @click \u2192 _toggleExpand(t) showing \"{t.userCount} {msg.viewUsers}\"\n        - if expanded: render tr.expand-row with td colspan=5 containing\n            collab-org-team-card-100554 with .team=${t} and project=\"${this.project}\"\n\n  events:\n    - name: team-created\n      when: after team is created successfully\n      detail: { name: string }\n      options: { bubbles: true, composed: true }\n    - name: view-team-projects\n      when: _emitViewProjects is called\n      detail: { team_name: string }\n      options: { bubbles: true, composed: true }\n    - name: view-team-users\n      when: _emitViewUsers is called\n      detail: { team_name: string }\n      options: { bubbles: true, composed: true }\n\n  render:\n    priority_order:\n      - if _loading \u2192 div.state-loading with span.spinner and span msg.loading\n      - if _error   \u2192 div.feedback.error with this._error\n      - default     \u2192 full layout\n\n    default_layout:\n      element: div.teams-root\n      children:\n        - div.header:\n            children:\n              - h1.page-title \u2192 msg.title\n              - button.btn-primary @click \u2192 _toggleNewTeam()\n                  label: if _newTeamOpen then msg.btnCancel else msg.btnNewTeam\n        - new team form (conditional on _newTeamOpen):\n            content: _renderNewTeamForm()\n        - _renderTable()\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n";
}
declare module "_100554_/l2/collabOrgUsers.defs" {
    export const skill = "\n## COMP \u2013 `collab-org-users-100554`\n\n# Definition\n\n```YAML\ncomponent:\n  tag: collab-org-users-100554\n  file: _100554_/l2/collabOrgUsers.ts\n  type: common\n  extends: CollabLitElement\n  description: >\n    Displays a table of organization members with their avatar, username,\n    teams and repository access status (GitHub and GitLab). Includes a\n    togglable invite panel powered by collab-org-invite-user-100554.\n\n  imports:\n    - /_100554_/l2/collabOrgInviteUser.js\n\n  external:\n    mls:\n      description: Global variable injected by the host environment at runtime\n      usage: use directly without any import, declare or type annotation\n      forbidden:\n        - declare const mls\n        - declare var mls\n        - import mls\n        - window.mls\n\n  props:\n    - name: project\n      type: number\n      default: 0\n      description: Project index used to locate the organization via mls\n\n  internal_state:\n    - name: _members\n      type: Member[]\n      default: []\n      description: List of organization members\n    - name: _accessMap\n      type: AccessMap\n      default: {}\n      description: Map of username to RepoAccess fetched in parallel\n    - name: _loading\n      type: boolean\n      default: false\n      description: Shows loading screen during fetch\n    - name: _error\n      type: string\n      default: \"\"\n      description: Error message displayed when fetch fails\n    - name: _inviteOpen\n      type: boolean\n      default: false\n      description: Controls visibility of the invite panel\n\n  interfaces:\n    Member:\n      id: number\n      username: string\n      avatarUrl: string\n      teams: string[]\n\n    RepoAccess:\n      github: boolean | null\n      gitlab: boolean | null\n\n    AccessMap: \"{ [username: string]: RepoAccess }\"\n\n  lifecycle:\n    connectedCallback: calls _fetchMembers()\n\n  methods:\n    _fetchMembers:\n      returns: Promise<void>\n      steps:\n        - set _loading = true, _error = '', call requestUpdate()\n        - resolve org via mls.l5.getProjectOrgIndex(this.project)\n        - get org name via mls.l5.getOrgsName()[idx]\n        - read mls.stor.orgs[orgName]\n        - if org not found: set _error = 'Not found organization' and return\n        - call this.configUsers(lastOrg) and assign to _members\n        - call _fetchAllAccess()\n        - on catch: set _error from err.message or 'Unknown error'\n        - finally: set _loading = false, call requestUpdate()\n\n    configUsers:\n      returns: Member[]\n      params:\n        - info: mls.cbe.IOrgInfo\n      steps:\n        - iterate info.sett.users with forEach((u, idx))\n        - for each user build Member with id=idx, username=u, avatarUrl fixed placeholder, teams=[]\n        - iterate info.sett.teams and push team.name to user.teams if team.usrIndex includes idx\n        - return users array\n\n    _fetchAllAccess:\n      returns: Promise<void>\n      steps:\n        - map _members with Promise.all calling _fetchRepoAccess(m.username) for each\n        - each promise resolves to [username, RepoAccess] tuple\n        - assign Object.fromEntries(entries) to _accessMap\n\n    _fetchRepoAccess:\n      returns: Promise<RepoAccess>\n      params:\n        - username: string\n      steps:\n        - simulate 300ms delay via Promise + setTimeout\n        - return { github: false, gitlab: false }\n\n    _toggleInvite:\n      returns: void\n      steps:\n        - toggle _inviteOpen\n        - call requestUpdate()\n\n    _handleInviteSuccess:\n      returns: void\n      steps:\n        - set _inviteOpen = false\n        - call _fetchMembers()\n\n    _renderAccessBadge:\n      returns: TemplateResult\n      params:\n        - value: boolean | null\n        - platform: string\n      steps:\n        - if value === null \u2192 span.badge.badge-neutral with \"{platform} \u2013\"\n        - if value === true \u2192 span.badge.badge-ok with \"{platform} \u2713\"\n        - if value === false \u2192 span.badge.badge-fail with \"{platform} \u2717\"\n\n    _renderAccessCell:\n      returns: TemplateResult\n      params:\n        - username: string\n      steps:\n        - look up _accessMap[username]\n        - if not found \u2192 span.access-loading with msg.loadingAccess\n        - otherwise \u2192 div.access-badges with _renderAccessBadge for github and gitlab\n\n    _renderTable:\n      returns: TemplateResult\n      steps:\n        - if _members.length === 0 \u2192 p.no-members with msg.noMembers\n        - otherwise \u2192 div.table-wrapper with table.members-table\n      table_structure:\n        thead:\n          columns: [colAvatar, colUser, colTeams, colAccess]\n        tbody:\n          row_per_member:\n            - td.td-avatar \u2192 img.avatar with src=m.avatarUrl and alt=m.username\n            - td.td-user \u2192 m.username\n            - td.td-teams \u2192 div.tags-wrapper\n                if teams > 0: map to span.team-tag\n                otherwise: span.no-teams with \"\u2014\"\n            - td.td-access \u2192 _renderAccessCell(m.username)\n\n  events: []\n\n  render:\n    priority_order:\n      - if _loading \u2192 div.state-loading with span.spinner and span msg.loading\n      - if _error   \u2192 div.feedback.error with this._error\n      - default     \u2192 full layout\n\n    default_layout:\n      element: div.users-root\n      children:\n        - div.header:\n            children:\n              - h1.page-title \u2192 msg.title\n              - button.btn-invite @click \u2192 _toggleInvite()\n                  label: if _inviteOpen then '\u2715' else '+ ' + msg.inviteToggle\n        - invite panel (conditional on _inviteOpen):\n            element: div.invite-wrapper\n            children:\n              - collab-org-invite-user-100554\n                  prop: project=\"${this.project}\"\n                  event: \"@invite-success \u2192 _handleInviteSuccess()\"\n        - _renderTable()\n\n  i18n:\n    languages: [en, pt]\n    default: en\n```\n\n\n# Required skills\n\n## Lit Skill\n[[(_100554_/l2/skills/lit.ts).skill]]\n\n## Less Skill\n[[(_100554_/l2/skills/less.ts).getSkillWithTokens()]]\n\n";
}
declare module "_100554_/l2/collabPageElement.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPageElement" {
    import { PropertyValueMap, LitElement } from 'lit';
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export const PREFIX_ICA_ID = "ica_";
    export function toPascalCase(str: string): string;
    export abstract class CollabPageElement extends StateLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        initPageComplete: boolean;
        level: string;
        overlay: any | undefined;
        isPage: boolean;
        recreateOverlay(): void;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): Promise<void>;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        private setupIds;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
    }
    export interface LitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        baseName: string;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
    }
    interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | 'p-title-top' | '';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
}
declare module "_100554_/l2/collabPanel.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPanelItem" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabPanelItem extends CollabLitElement {
        widget: string;
        badge: string;
        loading: string;
        mode: 'html' | 'tag';
        private myInfo;
        firstUpdated(): void;
        render(): any;
        private clickItem;
        private setMyInfo;
    }
}
declare module "_100554_/l2/collabPanel" {
    import "_100554_/l2/collabPanelItem";
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabPanel extends CollabLitElement {
        detail: HTMLDetailsElement | undefined;
        open: boolean;
        icon?: any;
        myData: IPluginMenuAction[];
        createRenderRoot(): this;
        render(): any;
        renderItem(item: IPluginMenuAction, index: number): any;
        private changeSummary;
        private minus;
        private plus;
    }
    interface IPluginMenuAction extends mls.plugin.MenuAction {
        mode: 'html' | 'tag';
    }
}
declare module "_100554_/l2/collabPanelHelper.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPanelHelper" {
    import { LitElement, PropertyValueMap } from 'lit';
    export class CollabPanelHelper100554 extends LitElement {
        plugin: string;
        isHelperContainerOpen: boolean;
        containerHelpers: HTMLDivElement | undefined;
        private handleOpenHelperClick;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): any;
        static styles: any;
    }
}
declare module "_100554_/l2/collabPanelItem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPreviewL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPreviewL3" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabL3EditText";
    export class CollabPreviewL3 extends CollabLitElement {
        constructor();
        private elOverlayHover;
        private elOverlaySelected;
        setHover(el: HTMLElement | undefined, active: boolean): void;
        selectElement(el: HTMLElement): void;
        render(): any;
        private init;
        private setEventsMouse;
        private createOverlay;
        private createOverlaySelected;
        private _setHover;
        private _selectElement;
        private addEdit;
    }
}
declare module "_100554_/l2/collabPreviewL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabPreviewL4" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabL3EditText";
    export class CollabPreviewL4 extends CollabLitElement {
        constructor();
        private elOverlayHover;
        private elOverlaySelected;
        private elMenuOverlay;
        disconnectedCallback(): void;
        render(): any;
        setHover(elId: string, active: boolean): void;
        selectElement(elId: string): void;
        private init;
        private setEventsMouse;
        private createOverlay;
        private createOverlaySelected;
        private observer;
        private _setElement;
        private _setHover;
        private caculetePosSelected;
        private _selectElement;
        private editEl;
    }
}
declare module "_100554_/l2/collabProcessTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/tsTestMonaco" {
    const _editor: unique symbol;
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        [_editor]: monaco.editor.IStandaloneCodeEditor | undefined;
        constructor(editor: monaco.editor.IStandaloneCodeEditor);
        getLines(model: monaco.editor.ITextModel): string[];
        replaceLines(model: monaco.editor.ITextModel, lineNrInit: number, lineNrInitEnd: number, newContent: string): boolean;
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine(model: monaco.editor.ITextModel, lineNr: number, line: string): boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine(model: monaco.editor.ITextModel, lineNr: number): boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines(model: monaco.editor.ITextModel, startLine: number, countLines: number): boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine(model: monaco.editor.ITextModel, lineNr: number, columnNr: number, newText: string): boolean;
        /**
         * Moves the editor's cursor to the specified lines, selects the text between them,
         * and scrolls the editor to bring the selection into view.
         *
         * @param {monaco.editor.ITextModel} model - The text model associated with the editor.
         * @param {number} start - The starting line number for the selection.
         * @param {number} end - The ending line number for the selection.
         *
         * @returns {void}
         */
        goTo(model: monaco.editor.ITextModel, start: number, end: number): void;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (model: monaco.editor.ITextModel) => void;
    }
}
declare module "_100554_/l2/tsTestAST" {
    import { MonacoDriver } from "_100554_/l2/tsTestMonaco";
    /**
     * Represents an AST node.
     * @typedef {Object} ASTNode
     * @property {string} type - The type of the AST node (e.g., 'Program', 'FunctionDeclaration').
     * @property {string} [name] - The name of the node (e.g., function name).
     * @property {any} [value] - The value associated with the node (e.g., function body or array content).
     * @property {ASTNode[]} [children] - An array of child nodes.
     * @property {number} [startLine] - The start line of the node in the source code.
     * @property {number} [endLine] - The end line of the node in the source code.
     */
    type ASTNode = {
        type: string;
        name?: string;
        value?: any;
        children?: ASTNode[];
        startLine: number;
        endLine: number;
    };
    /**
     * Class to parse a TypeScript test file and generate an AST.
     */
    export class TsTestAst {
        ast: ASTNode | undefined;
        modelTest: mls.editor.IModelTest | undefined;
        monacoDriver: MonacoDriver;
        editor: monaco.editor.IStandaloneCodeEditor;
        /**
         * Creates an instance of TsTestAst.
         * @param {mls.editor.IModelTest} modelTest - The Monaco editor model test instance.
         */
        constructor(modelTest: mls.editor.IModelTest, editor: monaco.editor.IStandaloneCodeEditor);
        /**
         * Parses the TypeScript code from the model test and returns the AST.
         * @returns {ASTNode | undefined} The generated AST, or undefined if parsing fails.
         */
        parse: () => ASTNode | undefined;
        /**
         * Gets the integrations from the parsed AST.
         * @returns {any[]} The integrations parsed from the AST.
         */
        getIntegrations(): ICANIntegration[];
        /**
         * Gets the tests from the parsed AST.
         * @returns {any[]} The tests parsed from the AST.
         */
        getTests(): ICANTest[];
        /**
         * Adds a new test to the AST and inserts it into the test array in the Monaco editor.
         * @param {ICANTest} test - The test object to be added.
         * @param {Function} fcTest - The test function to be associated with the test.
         * @returns {boolean} True if the test was added successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        addTest(test: ICANTest, fcTest: Function | string): boolean;
        /**
         * Deletes a test from the AST and updates the Monaco editor.
         * @param {String} testName - The test name to be removed.
         * @returns {boolean} True if the test was removed successfully, false otherwise.
         * @throws {Error} Throws an error if the test already exists or if there are issues with the AST.
         */
        deleteTest(testName: string, index?: number): boolean;
        /**
         * Navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        goToTest(testName: string): boolean;
        /**
         * Retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        getTestInfo(functionName: string, paramsIndex?: number): ITestInfo;
        /**
        * Executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        runTest(testName: string, paramsIndex?: number): Promise<string>;
        /**
         * Adds a new integration to the test file.
         * @param {ICANIntegration} integration - The integration to be added.
         * @param {Function} fc - The function associated with the integration.
         * @returns {boolean} Returns true if the integration was successfully added.
         */
        addIntegration(integration: ICANIntegration, fc: Function | string): boolean;
        /**
         * Parses TypeScript code into an AST.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode} The generated AST from the code.
         */
        private parseTypeScript;
        /**
         * Parses imports from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the imports in the code.
         */
        private parseImports;
        /**
         * Parses arrays from TypeScript code and returns an array of AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing the arrays in the code.
         */
        private parseArrays;
        /**
         * Parses function names from TypeScript code and returns an array of function declarations as AST nodes.
         * @param {string} code - The TypeScript code to parse.
         * @returns {ASTNode[]} An array of AST nodes representing function declarations in the code.
         */
        private parseFunctionNames;
        /**
         * Parses and retrieves the integrations from the AST's children.
         * @returns {ICANIntegration[]} The parsed integrations.
         * @throws {Error} Throws an error if parsing the integrations fails.
         */
        private _getIntegrations;
        /**
         * Parses and retrieves the tests from the AST's children.
         * @returns {ICANTest[]} The parsed tests.
         * @throws {Error} Throws an error if parsing the tests fails.
         */
        private _getTests;
        /**
         * Internal method to add a test to the AST and update the Monaco editor.
         * @param {ICANTest} test - The test object to add.
         * @param {Function} fcTest - The test function to add.
         * @returns {boolean} True if the test was successfully added.
         * @throws {Error} Throws an error if the test already exists or AST information is missing.
         */
        private _addTest;
        /**
         * Internal method to deletes a test from the AST and updates the Monaco editor.
         * @param {string} testName - The name of the test to delete.
         * @throws {Error} Throws an error if the test does not exist or deletion fails.
         */
        private _deleteTest2;
        /**
     * Internal method to delete a test from the AST and update the Monaco editor.
     * @param {string} functionName - The name of the test to delete.
     * @param {number} [index] - (Optional) The index of the parameter to remove.
     * @throws {Error} Throws an error if the test does not exist or deletion fails.
     */
        private _deleteTest;
        /**
        * Internal method to executes a test function dynamically imported from a test file.
        *
        * This function locates the test in the AST, retrieves its parameters, and dynamically
        * imports the corresponding test file. The specified function is then executed with
        * the given parameters.
        *
        * @param {string} functionName - The name of the test function to execute.
        * @param {number} [paramsIndex=0] - The index of the parameters set to use when executing the function.
        * @throws {Error} Throws an error if the test model is invalid, the function is not found, or the import fails.
        * @returns {Promise<string>} Resolves with the result of the executed function.
        */
        private _runTest;
        /**
         * Internal method to retrieves test function information without executing it.
         *
         * This function searches for the specified test function in the AST, extracts
         * its name, parameters, and associated test file name, and returns this information.
         *
         * @param {string} functionName - The name of the test function.
         * @param {number} paramsIndex - The index of the parameters set to retrieve.
         * @throws {Error} Throws an error if the test model is invalid.
         * @returns {ITestInfo | undefined} An object containing test metadata, or `undefined` if the test is not found.
         */
        private _getTestInfo;
        /**
         * Internal method to navigate to the specified test function within the Monaco Editor.
         *
         * This function parses the AST to locate the test function declaration and moves
         * the cursor to its position in the Monaco Editor.
         *
         * @param {string} functionName - The name of the test function to navigate to.
         * @throws {Error} Throws an error if the test model is invalid or if the specified test does not exist.
         * @returns {boolean} Returns `true` if the test function was found and navigation was successful, otherwise `false`.
         */
        private _goToTest;
        /**
         * Intenal method to delete a function on the AST and updates the Monaco editor.
         * @param {String} fcName - The function name to be deleted.
         * @returns {boolean} True if the function was successfully deleted.
         * @throws {Error} Throws an error if the test model is invalid.
         */
        private _deleteFunction;
        /**
         * Adds a new integration to the AST and updates the Monaco editor.
         * @param {ICANIntegrations} integration - The integration object to add.
         * @param {Function} fcIntegration - The integration function to add.
         * @throws {Error} Throws an error if the integration already exists or if AST information is missing.
         */
        private _addIntegration;
        /**
         * Deletes an integration from the AST and updates the Monaco editor.
         * @param {string} integrationName - The name of the integration to delete.
         * @throws {Error} Throws an error if the integration does not exist or deletion fails.
         */
        private _deleteIntegration;
        /**
         * Adds a new function to the AST and updates the Monaco editor.
         * @param {Function} fc - The function to add.
         * @returns {boolean} True if the function was successfully added.
         * @throws {Error} Throws an error if AST information is missing or the test model is invalid.
         */
        private _addFunction;
        private checkImports;
        /**
         * Adds an import statement to the TypeScript code.
         * If an interval is provided, it replaces the existing import.
         * Otherwise, it inserts the import after the root startLine.
         *
         * @param {string} value - The import statement to add.
         * @param {Object} [interval] - The optional start and end line to replace.
         */
        private _addImport;
        private _formatEditor;
    }
    export interface ITestInfo {
        fileName: string;
        functionName: string;
        params: Record<string, any>;
    }
    export interface ICANTest {
        functionName: string;
        params: Record<string, any>[];
    }
    export interface ICANIntegration {
        enabled: boolean;
        description: string;
        page: string;
        functionName: string;
        schema: Record<string, ICANSchema>;
    }
    export interface ICANSchema {
        type: string;
        optional?: boolean;
        description?: string;
    }
}
declare module "_100554_/l2/collabProcessTest" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabProcessTest extends CollabLitElement {
        script: string;
        labelError: string;
        labelOk: string;
        txtScript: HTMLTextAreaElement | undefined;
        iptnamefunc: HTMLInputElement | undefined;
        checkintegration: HTMLInputElement | undefined;
        render(): any;
        private decodeHtmlEntities;
        private changeNameFunc;
        private onSave;
        private createObjeTest;
        private addInEditor;
    }
}
declare module "_100554_/l2/collabResultTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabResultTest" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabConsole100554 extends StateLitElement {
        testName: string;
        status: 'pending' | 'running' | 'finished';
        resultStatus: 'pass' | 'failed';
        result: string;
        timeResult: number;
        timeStart: number;
        timeEnd: number;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private renderRunning;
        private renderFinished;
        render(): any;
    }
}
declare module "_100554_/l2/collabSelectOneWithDescription.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabSelectOneWithDescription" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export const initCollabSelectOneWithDescription = "";
    export class CollabSelectOneWithDescription100554 extends StateLitElement {
        private msg;
        hint: string | undefined;
        required: boolean;
        disabled: boolean;
        label: string | undefined;
        options: IOptionItem[] | undefined;
        selectedvalue: string | undefined;
        select_container: HTMLDivElement | undefined;
        select_toogle: HTMLDivElement | undefined;
        desc_container: HTMLDivElement | undefined;
        optionItems: HTMLElement[] | undefined;
        render(): any;
        firstUpdated(): void;
        private defaultMsg;
        private currentIndex;
        private onIconClick;
        private onBlur;
        renderOpt(): any;
        handleHover(ev: MouseEvent): void;
        handleOut(): void;
        handleFocus(ev: MouseEvent, index: number): void;
        handleChange(value: string): void;
        handleKeyDown(event: KeyboardEvent): void;
        toogle(): void;
        calculatePopupPosition(): void;
    }
    export interface IOptionItem {
        key: string;
        value: string;
        description: string;
    }
}
declare module "_100554_/l2/collabShowCodeDiff.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabShowCodeDiff" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_102027_/l2/collabMonacoEditor";
    export function initCollabShowCodeDiff100554(): boolean;
    export class CollabShowCodeDiff extends CollabLitElement {
        private msg;
        static monaco_css: string;
        static inLoadingCss: boolean;
        static loadingPromise: Promise<string>;
        msize: string;
        language: string;
        withCopy: boolean;
        withAccept: boolean;
        withReject: boolean;
        withTryAgain: boolean;
        withDiff: boolean;
        coping: boolean;
        onAccept: Function | undefined;
        onReject: Function | undefined;
        onTryAgain: Function | undefined;
        private _ed1Diff;
        private _ed1Result;
        private modelResult;
        private modelDiffOriginal;
        private modelDiffModified;
        private actualEditor;
        actualTextDiffOriginal: string;
        actualTextDiffModified: string;
        actualTextResult: string;
        private c1;
        private inputDiff;
        init(): void;
        private createEditorDiff;
        private createEditorResult;
        private createModelDiff;
        private createModelResult;
        private setDiffValue;
        private setResultValue;
        private setMsizeEditor;
        private onCopyClick;
        private onAcceptClick;
        private onRejectClick;
        private onTryAgainClick;
        private getCssMonaco;
        private styleElement;
        loadCSS(): Promise<void>;
        private renderWithCopy;
        private renderWithAccept;
        private renderTryAgain;
        private renderReject;
        private handleChangeDiff;
        private renderShowDiff;
        firstUpdated(): void;
        render(): any;
        static styles: any;
    }
}
declare module "_100554_/l2/collabSpliterHorizontalVarFixed.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabSpliterVerticalVarFixed.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL0.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL0" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabStartL0100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL1" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabStartL1100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL2" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabStartL2100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL3.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL3" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabStartL3100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL4" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabStartL4100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL5.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL5" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabStartL5100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStartL6.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStartL6" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabStartL6100554 extends StateLitElement {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/collabStore.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabStore" {
    /**
     * use this state to set and increment count
     * each access on page, increment this
     */
    export const COUNTHITSPAGES = "CountHitsPages";
}
declare module "_100554_/l2/collabTabSlider.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTabSlider" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class PluginCreateProject extends StateLitElement {
        activeIndex: number;
        animationTimer: number;
        private previousIndex;
        updated(changedProps: Map<string, any>): void;
        private switchTab;
        render(): any;
    }
}
declare module "_100554_/l2/collabTasks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTasks" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabTasks100554 extends StateLitElement {
        private view;
        private selectedTask;
        private _backToList;
        render(): any;
        private _renderTaskDetails;
        _renderTaskList(): any;
        private _openTaskDetails;
    }
}
declare module "_100554_/l2/collabTiles.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_100554_/l2/collabTilesItem" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabTilesItem extends CollabLitElement {
        private startX;
        private startY;
        private startWidth;
        private startHeight;
        myinfo: ITilesItem | undefined;
        position: string;
        plugin: string;
        index: string;
        edit: string;
        mode: string;
        collabtileitemresize: HTMLElement | undefined;
        private elPlugin;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): any;
        renderResize(): any;
        private setEnabled;
        private loadingPlugin;
        private setPlugin;
        private clickPlugin;
        private initDragging;
        private doDragging;
        private stopDragging;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_/l2/collabTiles" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabTilesItem";
    import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js';
    export class CollabTiles extends CollabLitElement {
        config: string;
        tilesItens: ITilesItem[];
        text: string;
        example: string;
        collabTiles: HTMLElement | undefined;
        private oldJson;
        createRenderRoot(): this;
        render(): any;
        renderItem(item: ITilesItem, idx: number): any;
        renderConfigItens(): any;
        renderConfigItensOpen(): any;
        renderConfigItensClose(): any;
        renderItemConfig(item: ITilesItem, index: number): any;
        private sort;
        private setDragAndDrop;
        private open;
        private close;
        private onlyclose;
        private verifyNeedSaveAndSave;
        private changeConfig;
        private setInfoPlugin;
        private fireChange;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_/l2/collabTilesItem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTokensVisualization.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/collabTokensVisualization" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export class CollabTokensVisuzalization100554 extends StateLitElement {
        tokens: IDesignSystemTokens[];
        project: number;
        firstUpdated(prop: any): Promise<void>;
        render(): any;
        getTokens(): Promise<IDesignSystemTokens[]>;
    }
}
declare module "_100554_/l2/contentAccordion.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/contentAccordion" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ContentAccordion extends CollabLitElement {
        private navItems;
        private contentItems;
        selectedIndex: number;
        connectedCallback(): void;
        render(): any;
        private toggle;
    }
}
declare module "_100554_/l2/contentCarousel.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/contentCarousel" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ContentTabs extends CollabLitElement {
        private navItems;
        private contentItems;
        selectedIndex: number;
        connectedCallback(): void;
        render(): any;
        renderNav(): any;
        renderContent(): any;
        private handleSelect;
        private handleClickPrevius;
        private handleClickNext;
    }
}
declare module "_100554_/l2/contentTabs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/contentTabs" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class ContentTabs extends CollabLitElement {
        private navItems;
        private contentItems;
        selectedIndex: number;
        connectedCallback(): void;
        render(): any;
        renderNav(): any;
        renderContent(): any;
        private handleSelect;
    }
}
declare module "_100554_/l2/cssHelperIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/cssHelperIndexBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/designSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_100554_/l2/docMd" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class DocMd extends CollabLitElement {
        private _html;
        private _marked;
        private oriHtml;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private _importMarked;
        private _parse;
        private init;
    }
}
declare module "_100554_/l2/driverGithub.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverGitlab.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverLib.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/driverTest" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class DriverTest extends CollabLitElement {
        drivername: string;
        private instance;
        iptDriver: HTMLInputElement | undefined;
        iptClass: HTMLInputElement | undefined;
        selFc: HTMLSelectElement | undefined;
        showParam: HTMLElement | undefined;
        textlog: HTMLElement | undefined;
        createRenderRoot(): this;
        render(): any;
        private changeDriver;
        private load;
        private separeteLine;
        private run;
        private setValueFromEl;
        private diffTime;
        private dateToTime;
        private changeFunction;
        private createItem;
        private createElItem;
        private functions;
    }
}
declare module "_100554_/l2/enhancementAgent.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102029_/l2/propiertiesLit" {
    export function getPropierties(model: mls.editor.IModelTS): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_102027_/l2/propiertiesLit" {
    export * from "_102029_/l2/propiertiesLit";
}
declare module "_100554_/l2/enhancementAgent" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string) => Promise<string>;
}
declare module "_100554_/l2/enhancementLit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102029_/l2/validateLit" {
    export function validateTagName(modelTS: mls.editor.IModelTS): boolean;
    export function validateRender(modelTS: mls.editor.IModelTS): boolean;
}
declare module "_102027_/l2/validateLit" {
    export * from "_102029_/l2/validateLit";
}
declare module "_102029_/l2/codeLensLit" {
    export function setCodeLens(model1: mls.editor.IModelTS): void;
}
declare module "_102027_/l2/codeLensLit" {
    export * from "_102029_/l2/codeLensLit";
}
declare module "_100554_/l2/enhancementLit" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_100554_/l2/enhancementLitService.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/enhancementLitService" {
    export const requires: mls.l2.enhancement.IRequire[];
    export const getDefaultHtmlExamplePreview: (modelTS: mls.editor.IModelTS) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const onAfterCompileAction: (sourceJS: string, sourceTS: string, css?: {
        sourceLess: string;
        sourceTokens: string;
    }) => Promise<string>;
}
declare module "_100554_/l2/enhancementPage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/enhancementPage" {
    export const description = "Use this enhancement for pages";
    export const example = "";
    export const requires: mls.l2.enhancement.IRequire[];
    export const getExample: (project: number, shortname: string) => string;
    export const getDesignDetails: (modelTS: mls.editor.IModelTS) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const prepareAdd: (prompt: string) => {
        sourceTS: string;
        aiHeader: string;
        aiBody: string;
        aiDelimiter: string;
    };
    export const onAfterChange: (modelTS: mls.editor.IModelTS) => Promise<void>;
    export const getPromptDefault: () => string;
    export const onAfterCompile: (modelTS: mls.editor.IModelTS) => Promise<void>;
}
declare module "_100554_/l2/enhancementStyle.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessASTTest.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessASTTest" {
    import { LitElement } from 'lit';
    import { LessCSS } from "_100554_/l2/lessCSS";
    export class LessASTTest100554 extends LitElement {
        rootSelector: string;
        fileToTest: string;
        url1: monaco.editor.ITextModel;
        render(): any;
        exeTest: () => string;
        test1: (lessCSS: LessCSS, rootSelector: string) => string;
        test2: (lessCSS: LessCSS, rootSelector: string) => string;
        test3: (lessCSS: LessCSS, rootSelector: string) => string;
        testt1: (lessCSS: LessCSS, rootSelector: string) => string;
        testt2: (lessCSS: LessCSS, rootSelector: string) => string;
    }
}
declare module "_100554_/l2/lessCSS.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/lessMonaco.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/libGithubIo.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/libGithubIo" {
    export function addIssueInProject(req: IReq, idProject: string, idIssue: string): Promise<string | undefined>;
    export function removeIssueInProject(req: IReq, idProject: string, idIssueProject: string): Promise<boolean>;
    export function updateFieldSelectProjects(req: IReq, idProject: string, idItem: string, idField: string, idOption: string): Promise<boolean>;
    export function getIssuesInProjects(req: IReq, idProject: string): Promise<IItemProject[]>;
    export function getProjectFields(req: IReq, idProject: string): Promise<IFieldsProject[]>;
    export function getProjects(req: IReq): Promise<IProject[]>;
    export function addNewIssueIO(req: IReq, user: IInfo, repositoryId: string, labelsId: string[], title: string, desc: string): Promise<IIssues | undefined>;
    export function removeReact(req: IReq, issueid: string, reactid: string): Promise<boolean>;
    export function addReact(req: IReq, issueid: string): Promise<string>;
    export function getIssues(req: IReq, state?: string): Promise<IIssues[]>;
    export function getIssue(req: IReq, id: string): Promise<IIssues | undefined>;
    export function addComment(req: IReq, issue: IIssues, comment: string): Promise<IComments | undefined>;
    export function getIssueComments(req: IReq, issue: IIssues): Promise<IComments[]>;
    export function getRepositoryId(req: IReq): Promise<string>;
    export function addMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function addLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<ILabel | undefined>;
    export function removeMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function removeLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<boolean>;
    export function getLabels(req: IReq): Promise<ILabel[]>;
    export function getUsers(req: IReq): Promise<IAssignees[]>;
    export function getLabelIdOrAdd(req: IReq, repositoryId: string): Promise<ILabelsCollab | undefined>;
    export function createLabelIO(req: IReq, repositoryId: string, label: string, color: string): Promise<ILabel | undefined>;
    export function getUserInfoIO(req: IReq): Promise<IInfo>;
    export interface IItemProject {
        id: string;
        issue: IIssues;
        fieldValues: IItemProjectValues[];
    }
    export interface IAssignees {
        id: string;
        login: string;
        avatarUrl: string;
    }
    export interface IItemProjectValues {
        value: string;
        valueText: string;
        fieldName: string;
        fieldId: string;
    }
    export interface IProject {
        id: string;
        number: number;
        title: string;
        createdAt: string;
        author: string;
        avatarUrl: string;
        url: string;
        fields: IFieldsProject[];
    }
    export interface IFieldsProject {
        id: string;
        name: string;
        dataType: string;
        options: {
            id: string;
            name: string;
        }[];
    }
    export interface IReq {
        owner: string;
        repo: string;
        branch: string;
    }
    export interface IIssues {
        id: string;
        numberIssues: number;
        createdAt: string;
        title: string;
        bodyText: string;
        state: string;
        url: string;
        author: string;
        avatarUrl: string;
        labels: ILabel[];
        reactionsTU: number;
        reactions: IReactions[];
        comments: IComments[];
        assignees: IAssignees[];
        project: IProjectMain;
    }
    export interface IProjectMain {
        number: number;
        title: string;
        id: string;
    }
    export interface IReactions {
        id: string;
        user: string;
    }
    export interface ILabel {
        id: string;
        color: string;
        name: string;
    }
    export interface IComments {
        createdAt: string;
        id: string;
        bodyText: string;
        author: string;
        avatarUrl: string;
    }
    export interface IInfo {
        name: string;
        login: string;
        avatarUrl: string;
    }
    export interface ILabelsCollab {
        feature: string;
        low: string;
        medium: string;
        high: string;
    }
}
declare module "_100554_/l2/libManagementCan.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/libManagementCan" {
    /**
     * Inicializa ou atualiza o estado global em um caminho específico.
     */
    export function initState(path?: string, value?: string | object | unknown[]): void;
    /**
     * Atualiza o estado em um caminho.
     */
    export function setState(path: string, value: any): boolean;
    /**
     * Espera até que o estado em `path` seja igual a `value`.
     * Se `timeout` for 0 ou undefined, espera indefinidamente.
     */
    export function waitingState(path: string, value: any, options?: IVerifyOptions): Promise<void>;
    export function waitForNonEmptyState(path: string, options?: {
        retryInterval?: number;
        timeout?: number;
    }): Promise<string>;
    /**
     * Vigia continuamente um estado. Se ele mudar de valor, lança erro.
     * Fica rodando até chamar `unwatchState` ou `clearWatchers`.
     */
    export function watchState(path: string, expectedValue: any, options?: IVerifyOptions): void;
    /** Cancela observação de um path específico */
    export function unwatchState(path: string): void;
    /** Cancela todos os watchers ativos */
    export function clearWatchers(): void;
    /**
     * Verifica estado com timeout opcional, retornando boolean em vez de erro.
     */
    export function verifyState(path: string, value: any, options?: IVerifyOptions): Promise<boolean>;
    interface IVerifyOptions {
        timeout?: number;
        retryInterval?: number;
    }
}
declare module "_100554_/l2/libProviders.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/libProviders" {
    export function gitHubLogin(): void;
    export function gitLabLogin(): void;
    export function googleLogin(): void;
    export function isProviderConnected(provider: mls.cbe.Provider): boolean;
    export function googleIcon(): any;
    export function githubIcon(): any;
    export function gitlabIcon(): any;
}
declare module "_100554_/l2/mlsHistoryList.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/mlsHistoryList" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class MlsHistoryList extends CollabLitElement {
        project: number;
        shortName: string;
        position: 'left' | 'right';
        folder: string;
        level: number;
        extension: string;
        loading: boolean;
        private error;
        private data;
        connectedCallback(): Promise<void>;
        getListHistory(): Promise<void>;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        private createJson;
        private createJson2;
        private filters;
        private findFirstInFilters;
        private getWeekOffet;
        private formatDate;
        handleClick(a: PointerEvent): void;
        render(): any;
    }
    export interface IHistoryItem {
        author: string;
        time: string;
        dateAm: string;
        hash: string;
        subject?: string;
        linesInserted: number | undefined;
        linesDeleted: number | undefined;
        authorUrl: string;
        type: 'item' | 'title';
    }
}
declare module "_100554_/l2/moduleToBeAST" {
    export function getModuleToBeInfo(project: number, moduleName: string): Promise<{
        ok: boolean;
        message: string;
        toBe?: undefined;
        toBePages?: undefined;
    } | {
        ok: boolean;
        toBe: any;
        toBePages: any;
        message?: undefined;
    }>;
    export function saveModuleToBe(project: number, moduleName: string, toBe: Object | undefined, toBePage: Object | undefined): Promise<{
        ok: boolean;
        message?: undefined;
    } | {
        ok: boolean;
        message: string;
    }>;
}
declare module "_100554_/l2/modules.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/modules" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class Modules extends CollabLitElement {
        private msg;
        private viewMode;
        private modules;
        loading: boolean;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        private fetchModules;
        private getLocal;
        private loadModule;
        private getModulesByActualProject;
        private moveActualToFirst;
        private handleAddClick;
        private handleBackClick;
        private selectThis;
        private setLocal;
        private goToL4;
        private renderListView;
        private renderAddView;
        render(): any;
    }
}
declare module "_100554_/l2/pluginAgentPlayground.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginAgentPlayground" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/docMd";
    export class AgentTester extends CollabLitElement {
        private _agent;
        private inError;
        agent: string;
        containerdraganddrop: HTMLElement | undefined;
        selCompare: HTMLSelectElement | undefined;
        private activeJudge;
        private msgSelectGroup;
        private activeGroup;
        private combinations;
        private groups;
        private actualGrup;
        private loading;
        private mode;
        private result;
        private prompts;
        private list;
        private chatPreferences;
        actualTaskInDetails?: mls.msg.TaskData;
        actualDetails?: HTMLElement;
        private inEdit;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
        renderHead(): any;
        renderMode(): any;
        renderInputs(): any;
        renderGroups(): any;
        renderGroupSelector(): any;
        renderButonAdd(): any;
        renderPrompt(prompt: Iprompts, idx: number): any;
        renderMove(idx: number): any;
        renderSelect(prompt: Iprompts): any;
        renderResult(): any;
        renderCompare(): any;
        renderSettings(): any;
        renderListThread(): any;
        private init;
        private verifyProp;
        private selectTabResult;
        private selectTabInput;
        private selectTabSettings;
        private updateSelect;
        private handleDetails;
        private addPrompt;
        private trashClick;
        private promptEvent;
        private getCleanPreContent;
        private handlePlay;
        private timeSave;
        private handleSave;
        private getPrompts;
        private handleThreadChange;
        private _callAgent;
        private escapeAngleBrackets;
        private escape;
        private draggedItem;
        private dropTarget;
        private dropPosition;
        private handleDragStart;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private moveItemInArray;
        private handlePaste;
        private addGroup;
        private changeGrups;
        private sortGroup;
        private setDefaultGroup;
        private removeGroup;
        private handleSelectChange;
        private getPar;
        private _onCheckboxChange;
        private _onCheckboxChangeJudge;
        private openInDetails;
        private extractJsonString;
        private openInMessage;
    }
    interface Iprompts {
        type: string;
        content: string;
        openDetail: boolean;
        group: string;
    }
}
declare module "_100554_/l2/pluginBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginBase" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export abstract class PluginBase extends CollabLitElement {
        scope: string;
        abstract description: string;
        abstract getSvg(): TemplateResult;
    }
}
declare module "_100554_/l2/pluginBaseIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_100554_/l2/pluginBaseModule.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginBaseModule" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_100554_/l2/pluginCodeInsights" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_100554_/l2/pluginBaseModule";
    import { IdefModule } from "_102027_/l2/libMindMap";
    export class pluginCodeInsights extends PluginBaseModule {
        private error;
        allItens: Record<string, IdefModule> | undefined;
        element: Required<CodeInsights> | undefined;
        private activeCategory;
        private selectedFile;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderDetails(): TemplateResult;
        private formatCategory;
        loadDefs(): Promise<void>;
        private getWithCodeInsights;
        private groupCodeInsightsByCategory;
        private onClickItem;
        private closeDetails;
        fireEvents(action: string, file: mls.stor.IFileInfo, timeout?: number): Promise<void>;
    }
    type CodeInsights = {
        todos?: Record<string, IdefModule>;
        securityWarnings?: Record<string, IdefModule>;
        unusedImports?: Record<string, IdefModule>;
        deadCodeBlocks?: Record<string, IdefModule>;
        accessibilityIssues?: Record<string, IdefModule>;
        i18nWarnings?: Record<string, IdefModule>;
        performanceHints?: Record<string, IdefModule>;
    };
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_/l2/pluginCodelensCustomElement.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetTextCode" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class WidgetTextCode extends CollabLitElement {
        config: string | undefined;
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        private unescapeHtml;
        setCode(): void;
        firstUpdated(): void;
        render(): any;
        private onChangeText;
    }
}
declare module "_100554_/l2/pluginCodelensCustomElement" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/widgetTextCode";
    export class PluginCodelensCustomElement extends CollabLitElement {
        private msg;
        textCode2: string;
        render(): any;
    }
}
declare module "_100554_/l2/pluginCodelensFileReferences.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCodelensFileReferences" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class PluginCodelensFileReferences extends CollabLitElement {
        private msg;
        references: mls.editor.IModelTS[];
        project: number;
        shortName: string;
        position: string;
        firstUpdated(): Promise<void>;
        render(): any;
        private handleClick;
        private getReferences;
    }
}
declare module "_100554_/l2/pluginCodelensServiceDetails.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCodelensServiceDetails" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class PluginCodelensServiceDetails extends CollabLitElement {
        private msg;
        render(): any;
        textExampleIcon: string;
        textExampleNormal: string;
        textExampleCustom: string;
        textExampleCustomLevel: string;
    }
}
declare module "_100554_/l2/pluginCollabCoreIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCollabCoreIndex" {
    import { PluginBaseIndex } from "_100554_/l2/pluginBaseIndex";
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_1: PluginCollabCoreIndex;
    export default _default_1;
}
declare module "_100554_/l2/pluginCollabLogin.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCollabLogin" {
    import { TemplateResult } from 'lit';
    import { PluginBaseModule } from "_100554_/l2/pluginBaseModule";
    export class PluginCollabLogin100554 extends PluginBaseModule {
        private msg;
        private googleState;
        private origin;
        render(): any;
        renderBackButton(): any;
        renderTitle(): any;
        renderDivider(text: string): any;
        renderButton(provider: mls.cbe.Provider, icon: TemplateResult, clickHandler: () => void): any;
        renderLogOff(text: string, icon: TemplateResult, clickHandler: () => void): any;
        renderFooter(): any;
        logoff(): Promise<void>;
        getState(provider: mls.cbe.Provider): StateProvider;
        isProviderConnected(provider: mls.cbe.Provider): boolean;
        getRedirectLink(): string;
        googleLogin(): void;
        gitHubLogin(): void;
        gitLabLogin(): void;
        verifyDisconnect(provider: mls.cbe.Provider): boolean;
        generateRandomState(): string;
        onBackButtonClick(): void;
        LogoffIcon(): any;
        googleIcon(): any;
        githubIcon(): any;
        gitlabIcon(): any;
    }
    export const pluginData: mls.plugin.IPluginData;
    type StateProvider = 'connected' | 'canSignIn' | 'canDisconnect' | 'canAdd';
}
declare module "_100554_/l2/pluginCollabWidgetIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginCollabWidgetIndex" {
    import { PluginBaseIndex } from "_100554_/l2/pluginBaseIndex";
    export class PluginCollabWidgetIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_2: PluginCollabWidgetIndex;
    export default _default_2;
}
declare module "_100554_/l2/pluginCreateProject.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libNewProject" {
    export interface IProjectType {
        id: string;
        name: string;
        dependencies: number[];
        agent?: string;
    }
    export const projectTypes: IProjectType[];
    export const template_tsconfig: {
        ext: string;
        template: string;
    };
    export const template_l5Project: {
        ext: string;
        template: string;
    };
    export const template_package: {
        ext: string;
        template: string;
    };
    export const template_build_old: {
        ext: string;
        template: string;
    };
    export const template_build: {
        ext: string;
        template: string;
    };
    export const template_l2Project: {
        ext: string;
        template: string;
    };
    export const template_deps: {
        ext: string;
        template: string;
    };
    export const template_coreIndex: {
        ext: string;
        template: string;
    };
    export const template_ds: {
        ext: string;
        template: string;
    };
}
declare module "_100554_/l2/pluginCreateProject" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class PluginCreateProject extends CollabLitElement {
        private msg;
        currentScenario: IScenaries;
        projectName: string;
        projectType: 'blank' | 'prompt';
        projectPrompt: string;
        selectedProjectTypeId: string;
        errorName: string;
        errorPrompt: string;
        alreadyHasProjectLocal: boolean;
        isLoading: boolean;
        projectCreatedSucessfully: boolean;
        private projectNumber;
        private get selectedProjectType();
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        private renderScenario;
        private renderSelect;
        private renderProjectCreatedOk;
        private handleCancel;
        private handleProjectTypeChange;
        private validateForm;
        private handleCreate;
        private setProjectActual;
        private createFiles;
        private createInitialProject;
        private createInitialConfigL5File;
        private createInitialDSFile;
        private createNewFileL2;
    }
    type IScenaries = 'select';
}
declare module "_100554_/l2/pluginCreateProjectLocalToDriver.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginNewProjectLog" {
    import { TemplateResult } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class CollabLogLine100554 extends CollabLitElement {
        text: string;
        status: ILogStatus;
        private iconsByStatus;
        render(): any;
    }
    export type ILogStatus = 'waiting' | 'inprogress' | 'finish' | 'error';
    export type IIconsByStatus = {
        [key in ILogStatus]: TemplateResult<2>;
    };
}
declare module "_100554_/l2/pluginCreateProjectLocalToDriver" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/pluginNewProjectLog";
    export class PluginCreateProject extends CollabLitElement {
        private msg;
        private selectedProvider?;
        private githubConnected;
        private gitlabConnected;
        private errorMessage;
        actualOrgs: mls.stor.others.IOrg[];
        actualTeams: string[];
        orgSelected: boolean;
        isLoadingOrgs: boolean;
        activeScenerie: IScenerie;
        logs: ILogs[];
        errorName: string;
        errorOrg: string;
        logsContainer: HTMLDivElement | undefined;
        progress: HTMLDivElement | undefined;
        form: HTMLFormElement | undefined;
        private instanceDriver;
        private login;
        private secret;
        private orgName;
        private projectLocalNumber;
        private newProjectName;
        private newProjectNumber;
        private newProjectTeam;
        private newProjectVisibility;
        private NEWREPONAME;
        private VALIDADEFILE;
        private drivers;
        private urls;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private handleSelect;
        private handleConnect;
        private handleContinue;
        private loadOrgsByDriver;
        private getOrgsByUser;
        private onOrgChanged;
        private onRefreshOrgsClick;
        private loadTeamByOrg;
        private getLoginUser;
        private addLog;
        private setProgress;
        private setProgressError;
        private setProgressFinished;
        private changeStatusLastLog;
        private getUniquePassword;
        private toogleForm;
        private sleep;
        private onCancelStep2;
        private tryItem;
        private setPermissionAction;
        private setVariableAction;
        private createInitialReadMe;
        private createInitialBuildFile;
        private createInitialPackageFile;
        private createInitialTSConfigFile;
        private createPrjInfo;
        private addTempObject;
        private addFileInfoItem;
        private migrateAllFiles;
        private migrateFile;
        private prepareToAddFileInfo;
        private deleteOldFiles;
        private migrateLocalFiles;
        private replaceSpecificProjectId;
        private createProjecInCollab;
        private validateForm;
        private onCreateProjectClickTest;
        private onCreateProjectClick;
        private setProjectActual;
        private setOrgActual;
        private deleteLastOpenedFileOnLocalStorage;
        private renderSelectProvider;
        private renderCreateProject;
        private renderLogs;
        render(): any;
        renderScenaries(): any;
    }
    interface ILogs {
        pre: string;
        log: string;
        status: string;
    }
    type IScenerie = 'select' | 'form';
}
declare module "_100554_/l2/pluginExamplesIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginExamplesIndex" {
    import { PluginBaseIndex } from "_100554_/l2/pluginBaseIndex";
    export class PluginExamplesIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_3: PluginExamplesIndex;
    export default _default_3;
}
declare module "_100554_/l2/pluginNewProjectLog.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPageAIVerify.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginPageAIVerify" {
    import { PluginBaseModule } from "_100554_/l2/pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginPageAIVerify extends PluginBaseModule {
        private msg;
        render(): any;
    }
}
declare module "_100554_/l2/pluginSiteMonitorIndex.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/pluginSiteMonitorIndex" {
    import { PluginBaseIndex } from "_100554_/l2/pluginBaseIndex";
    export class PluginSiteMonitorIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_4: PluginSiteMonitorIndex;
    export default _default_4;
}
declare module "_100554_/l2/pluginStyleIndexItem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewModeMinimum.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewModeUtil" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export function mountJSImporMap(info: IJSONDependence, ifr: HTMLIFrameElement): void;
    export function mountCSS(ifr: HTMLIFrameElement): void;
    export function mountLinks(info: IJSONDependence, ifr: HTMLIFrameElement): void;
    export function mountTokens(tokens: string, file: mls.stor.IFileInfo): void;
    export function removeOlderTokens(ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): void;
    export function getIdTokens(file: mls.stor.IFileInfo): string;
    export function simulateService(info: IJSONDependence, ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): Promise<void>;
    export function addFA(ifr: HTMLIFrameElement): void;
    export function addTooltip(ifr: HTMLIFrameElement): void;
    export function addStyleMls(ifr: HTMLIFrameElement): void;
    export function addNav3(ifr: HTMLIFrameElement, file: mls.stor.IFileInfo): void;
    export function waitForComponents(context: Window, componentNames: string[]): Promise<CustomElementConstructor[]>;
    export function addJsReference(ifr: HTMLIFrameElement, level: string): void;
}
declare module "_100554_/l2/previewModeMinimum" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export class PreviewModeMinimum {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        private mountJS;
    }
}
declare module "_100554_/l2/previewModeSinglePage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewModeSinglePage" {
    import { IJSONDependence } from "_102027_/l2/libCompile";
    export class PreviewModeSinglePage {
        private level;
        private json;
        private ifr;
        private isService;
        private models;
        private file;
        private esbuild;
        private needAwait;
        constructor(_j: IJSONDependence, _i: HTMLIFrameElement, _l: string, _s: boolean, _f: mls.stor.IFileInfo, _m: mls.editor.IModels | undefined);
        init(): Promise<void>;
        buildJS(other: string[]): Promise<any>;
        private configIframe;
        private _buildJS;
        private parseImportsMap;
        private findWidgets;
        private loadEsbuild;
        private initializeEsBuild;
        private loadCache;
    }
}
declare module "_100554_/l2/previewModeUtil.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewState.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/previewState" {
    global {
        interface Window {
            preview: {
                editor: monaco.editor.IStandaloneCodeEditor | undefined;
                iframe: HTMLIFrameElement | undefined;
            };
        }
    }
}
declare module "_100554_/l2/project.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/project" {
    export const projectConfig: {
        modules: any[];
    };
}
declare module "_100554_/l2/projects.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/projects" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_100554_/l2/pluginCreateProject";
    export class Projects102009 extends StateLitElement {
        currentView: 'list' | 'details' | 'add';
        archiveConfirmationText: string;
        selectedProjectDetails: IMyProject | undefined;
        selectedProject: IMyProject | undefined;
        comunityProjects: IMyProject[];
        myProjects: IMyProject[];
        firstUpdated(): void;
        render(): any;
        renderHeader(): any;
        renderProjectList(): any;
        renderCurrentProject(): any;
        renderListUser(): any;
        renderListComunity(): any;
        renderProjectDetails_old(): any;
        renderProjectDetails(): any;
        renderAdd(): any;
        private backScenaryList;
        private onAddNewProjectClick;
        private timeFilterChange;
        private filterLiChange;
        private getOrgsAndProjects;
        private createPrjLocalItem;
        private openDetails;
        private goBack;
        private confirmArchive;
        private onProjectClick;
        private setProjectActual;
        private setOrgActual;
        private mockProjects;
    }
    interface IMyProject {
        title: string;
        type: string;
        remixes: number;
        thumbnail: string;
        project: number;
    }
}
declare module "_100554_/l2/saveAddBranch.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/saveAddBranch" {
    import { LitElement } from 'lit';
    export const initServiceSaveaddBranch: () => void;
    export class ServiceSaveAddBRanch extends LitElement {
        hint: string | undefined;
        callBack: Function | undefined;
        private owner;
        private repo;
        private branch;
        private branchMain;
        private listForks;
        private error;
        private driver;
        private mode;
        connectedCallback(): void;
        render(): any;
        renderModeList(): any;
        renderModeAdd(): any;
        renderBranchs(): any;
        renderForks(): any;
        renderItem(obj: {
            name: string;
        }, index: number): any;
        renderItemFork(obj: mls.stor.others.IFork, index: number): any;
        private init;
        private cancel;
        private addClick;
        private addBranch;
        private addNewBranch;
        private getInfosRepo;
        private setItem;
        private setItemFork;
        static styles: any;
    }
}
declare module "_100554_/l2/serviceBase.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceBase" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class ServiceBase extends StateLitElement {
        get level(): mls.Level;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        loadingFeedBack: string;
        private _nav3Service;
        private _serviceContent;
        private _serviceItemNav;
        private _tooltipEl;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get nav3Menu(): HTMLElement;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IServiceMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string, saveState?: boolean): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string, saveState?: boolean) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
    export type ITitleClickCallBack = (title: string) => void | undefined;
    export type IMainClickCallBack = (value: string) => void | undefined;
    export type IToolsClickCallBack = (value: string) => void | undefined;
    export type ITabsClickCallBack = (index: number) => void | undefined;
    export type ITabsNavigationClickCallBack = (index: number, oldTab: HTMLElement, newTab: HTMLElement) => void | undefined;
    export type TSetMode = (mode: TMode | null, page?: HTMLElement) => void;
    export type TGetLastMode = () => TMode;
    export type TMode = 'initial' | 'page' | 'editor';
    export interface IOptions {
        text: string;
        icon?: string;
        class?: string;
    }
    export interface IOptionsSubMenu {
        text: string;
        icon?: string;
        class?: string;
        options: IOptions[];
    }
    export interface ITools {
        [key: string]: IToolsData;
    }
    export interface IMain {
        [key: string]: IOptions | string;
    }
    interface ITabs {
        type: 'full' | 'onlyicon';
        effect?: 'slide' | 'none';
        mode?: 'normal' | 'compact';
        group: string;
        selected?: number;
        previous?: number;
        options: IOptions[];
    }
    export interface IBaseToolsData {
        icon?: string;
        class?: string;
    }
    export interface IToolsData1 extends IBaseToolsData {
        type: 'dropdown' | 'cycle' | 'link';
        selected?: number;
        onlyMenu?: boolean;
        options: IOptions[];
    }
    export interface IToolsData2 extends IBaseToolsData {
        type: 'tree-dropdown';
        selected?: number[];
        onlyMenu?: boolean;
        options: IOptionsSubMenu[];
    }
    type IToolsData = IToolsData1 | IToolsData2;
    export interface IServiceMenu {
        enabled?: boolean;
        title: IOptions | string;
        main: IMain;
        tabs: ITabs | undefined;
        tools: ITools;
        onClickTitle?: ITitleClickCallBack;
        onClickMain?: IMainClickCallBack;
        onClickTools?: IToolsClickCallBack;
        onClickTabs?: ITabsClickCallBack;
        onClickTabsNavigation?: ITabsNavigationClickCallBack;
        setMenuActive?: (op: string) => void;
        setTabActive?: (index: number) => void;
        tabNavigate?: (index: number, oldTab: HTMLElement | undefined, newTab: HTMLElement) => void;
        tabBack?: () => void;
        toggleErrorTab?: (index: number, show: boolean) => void;
        selectTool?: (op: string) => void;
        mainDefault?: string;
        lastMain?: string;
        setMode?: TSetMode;
        refresh?: (mode?: 'full' | 'tabs' | 'tools') => void;
        closeMenu?: Function;
        getLastMode?: TGetLastMode;
        updateTitle?: Function;
    }
}
declare module "_100554_/l2/serviceCollabFileSystem.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceCollabFileSystem" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceCollabFileSystem100554 extends ServiceBase {
        private supported;
        private busy;
        private project;
        private projectOptions;
        private folderName;
        private statusMessage;
        private progressMessage;
        private changes;
        private selectedPath;
        private scanResult;
        private scanned;
        private detailsOpen;
        private pendingConfirm;
        private lastSyncAt;
        private linkedFileCount;
        private msg;
        private adapter;
        private sync;
        private handle;
        private lastProgressAt;
        details: IService;
        menu: IServiceMenu;
        constructor();
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        onClickMain(op: string): void;
        render(): any;
        private renderBody;
        private renderFirstRun;
        private renderConnection;
        private renderDetails;
        private renderScanCta;
        private renderScanned;
        private renderGroup;
        private renderConfirmPanel;
        private pullConfirmLines;
        private pushConfirmLines;
        private renderHeaderStatus;
        private renderNotice;
        private getBadgeClass;
        private getBadgeLabel;
        private openChangeDetails;
        private openMonacoDiffRight;
        private isResolvable;
        private appendConflictResolution;
        private resolveConflict;
        private getNextChangeAfterResolution;
        private pickNextChange;
        private getResolutionMessage;
        private openResolutionSummary;
        private isDiskSideChange;
        private getExtensionFromPath;
        private getLanguageFromPath;
        private openDetailsRight;
        private createDetailStyle;
        private appendMuted;
        private getDetailText;
        private selectFolder;
        private disconnect;
        private scan;
        private requestPull;
        private requestPush;
        private confirmCancel;
        private confirmExecute;
        private runPull;
        private runPush;
        private scanCurrent;
        private loadProjectHandle;
        private onProjectChange;
        private resetScanState;
        private refreshManifestInfo;
        private formatLastSync;
        private resolveSelectedProjectHandle;
        private getStoredProjectHandle;
        private getProject;
        private resolveSelectedProject;
        private getProjectOptions;
        private savePreferences;
        private readPreferences;
        private runExclusive;
        private reportProgress;
        private formatProgress;
        private setEvents;
        private showAboutThis;
    }
}
declare module "_100554_/l2/serviceDashboard.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceDashboard" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_100554_/l2/collabTiles";
    export class ServiceDashboard100554 extends ServiceBase {
        msize: string;
        cssBreakPoint: string;
        activeTab: string;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private showAboutThis;
        createRenderRoot(): this;
        firstUpdated(): void;
        private refreshTimeOut;
        updated(changedProperties: any): void;
        render(): any;
        renderContent(): any;
        renderIcon1(): any;
        renderIcon2(): any;
        private pluginsDash1;
        private pluginsDash2;
        private baseProject;
        private loadAndSetPlugins;
        private getInfoPlugin;
    }
}
declare module "_100554_/l2/serviceDetail.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceDetail" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceDetail100554 extends ServiceBase {
        msize: string;
        widget: string;
        typeRender: 'default';
        contentPlugin: HTMLDivElement | undefined;
        private plugin;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        updateContentPluginWithElement(element: HTMLElement): void;
        clear(): void;
        private showAboutThis;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderDefault(): any;
        private setEvents;
        private onMonacoEvents;
        private onFileActionReceived;
        private onPluginDetails;
        private onWidgetChanged;
        private showPluginContent;
        private getHtmlFromPlugin;
        private updateContentPluginWithScripts;
        private _updateContentPluginWithElement;
        private setContentElement;
        private setContentinEl;
        private fireEvents;
    }
}
declare module "_100554_/l2/serviceExploreProjects.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/libHistoriesRecents" {
    export function addInHistory(file: mls.stor.IFileInfo): void;
    export function getHistory(): HistoryList;
    export function removeFromHistory(target: HistoryItem): void;
    export function renameHistoryItem(target: HistoryItem, newShortName: string): void;
    export function loadProjectHistory(): IHistoryProject[];
    export function saveProjectHistory(history: IHistoryProject[]): void;
    export function removeProjectFromHistory(projectId: number): void;
    export function renameProjectInHistory(projectId: number, newName: string): void;
    interface IHistoryProject {
        project: number;
        name: string;
        doSelect: boolean;
    }
    export interface HistoryItem {
        project: number;
        shortName: string;
        extension: string;
        folder: string;
    }
    type HistoryList = HistoryItem[];
}
declare module "_100554_/l2/serviceExploreProjects" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceExploreProjects100554 extends ServiceBase {
        private msg;
        scenary: string;
        inFilter: boolean;
        projectCreated: boolean;
        state: IServiceList;
        lastPrjId: string | null | undefined;
        list: NodeListOf<HTMLElement> | undefined;
        titleList: NodeListOf<HTMLElement> | undefined;
        historieEl: HTMLElement | undefined;
        activeTab: string;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private setEvents;
        connectedCallback(): void;
        createRenderRoot(): this;
        render(): any;
        renderContent(): any;
        renderExplore(): any;
        renderSelectProject(): any;
        renderHistory(): any;
        renderList(): any;
        renderTotsOrgs(): any;
        renderScenaryOrg(): any;
        renderListOrgs(): any;
        private firedetail;
        private getLastProject;
        private getOrgsAndProjects;
        private clearState;
        private filterTimeout;
        private _filterProjects;
        private onHistoryClick;
        private onProjectClick;
        private setProjectActual;
        private setOrgActual;
        private addOnHistory;
        private onOrgClick;
        private goToOrgs;
        private _filterOrgs;
        private fireDetails;
    }
    interface IStateOrg {
        key: string;
        name: string;
        created_at: string;
        description: string;
        projects: IInfoPrj[];
        selected: boolean;
    }
    interface IInfoPrj {
        project: number;
        name: string;
        doSelect: boolean;
    }
    interface IServiceList {
        history: IHistory[];
        orgs: IStateOrg[];
        projectSelected: number | undefined;
    }
    interface IHistory {
        project: number;
        name: string;
        doSelect: boolean;
    }
}
declare module "_100554_/l2/serviceHistories.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceHistories" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_102027_/l2/collabMonacoEditor";
    export class ServiceHistories100554 extends ServiceBase {
        private msg;
        constructor();
        msize: string;
        lastModeEditor: TEditorMode;
        createRenderRoot(): this;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        private c2;
        static modelCount: number;
        private _ed1;
        private fileInfo;
        private hashOriginal;
        private hashModified;
        private histories;
        get confE(): string;
        private showStart;
        private onToolbarSelected;
        private onSelectHistories;
        private changeEditorMode;
        private getHistories;
        private setInitialHistories;
        private createOrGetModel;
        private getUri;
        private createEditor;
        private updateEditor;
        private setMsizeEditor;
        private _onServiceClick;
        updated(changedProperties: any): void;
        render(): any;
    }
    type TEditorMode = 'sideBySide' | 'inline';
}
declare module "_100554_/l2/serviceLiveView.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceLiveView" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_100554_/l2/collabNav4Menu";
    export class ServiceLiveView100554 extends ServiceBase {
        private msg;
        private get liveView();
        private startInstance;
        private startServerInstance;
        private buildInstance;
        private liveViewTag?;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        connectedCallback(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        render(): any;
    }
}
declare module "_100554_/l2/utilsLit" {
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
}
declare module "_100554_/l2/widgetMindMapL4" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import { MindMapSelected, MindMapData, MindMapNodeStyles, MindMapNode } from "_102027_/l2/libMindMap";
    export class WidgetMindMapL4100554 extends StateLitElement {
        private contentHeight;
        private offsetY;
        private isListMode;
        private LIST_THRESHOLD;
        private _canvasDirtyWhileHidden;
        menuOpen: boolean;
        activeDescription: string | undefined;
        currentpage: string | undefined;
        showbreadcrumb: string | undefined;
        mindMapSelected: MindMapSelected | undefined;
        mapState: MindMapData | undefined;
        nodeRadius: number;
        nodeStyles: MindMapNodeStyles;
        initialNode: string | undefined;
        breadcrumb: MindMapNode[];
        private _nodePositions;
        private _animationDelay;
        private get visibleBreadcrumb();
        render(): any;
        renderBreadcrumb(): any;
        renderMenu(): any;
        firstUpdated(): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private configureMindMap;
        private _redrawCanvas;
        private _addCanvasListeners;
        private _removeCanvasListeners;
        private _animating;
        private _animatedPositions?;
        private _onCanvasClick;
        private getNodeStyle;
        /**
         * Returns the node id under the given mouse position, or undefined if none.
         */
        private getNodeIdAtPosition;
        private getRelatedNodes;
        private _hoveredNodeId?;
        private handleCanvasMouseMove;
        private toWorldCoords;
        private computeAutoZoom;
        private zoom;
        private MIN_ZOOM;
        private MAX_ZOOM;
        private drawMindMap;
        private _onWheel;
        private drawListLayout;
        private drawLabel;
        private drawIconButton;
        private openDefs;
        private _toggleMenu;
        private fromMenu;
        private _openScenario;
        private _closeDescription;
        private _brightenColor;
        /**
     * Returns a map { nodeId: {x, y} } for each node,
     * given a center nodeId and its related nodes.
     */
        private getNodePositions;
        /**
         * Returns an array of { id, from, to } for all nodes appearing in either state.
         * - from: start position (or undefined if node is new)
         * - to:   end position (or undefined if node disappears)
         */
        private prepareAnimationMap;
        /**
         * Animates all nodes from their 'from' position to 'to' in 500ms.
         * Calls a callback on each frame with current positions.
         */
        private animateTransition;
        private onSelected;
        private _pushBreadcrumb;
        private _syncBreadcrumbWithCurrent;
        private _popToBreadcrumb;
        private openFileAndNavigate;
        private _navigateInsideCurrentFile;
        private openFile;
        private pluginsMenu;
    }
}
declare module "_100554_/l2/serviceMindMap" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import { MindMapData } from "_102027_/l2/libMindMap";
    import "_100554_/l2/widgetMindMapL4";
    export class ServiceMindMap100554 extends ServiceBase {
        dataJson: MindMapData | undefined;
        private actualFile;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        private showAboutThis;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private setEvents;
        private onMLSFileActionMindmap;
        firstUpdated(_changedProperties: Map<PropertyKey, unknown>): void;
        render(): any;
        renderDefault(): any;
        private configure;
    }
}
declare module "_100554_/l2/servicePreview.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/previewBase" {
    export abstract class PreviewModeBase {
        protected level: string | undefined;
        protected iFrame: HTMLIFrameElement | undefined;
        protected isService: boolean;
        protected storFile: mls.stor.IFileInfo | undefined;
        constructor(_iFrame: HTMLIFrameElement, _level: string, _isService: boolean, _storFile: mls.stor.IFileInfo);
        abstract init(): Promise<void>;
    }
}
declare module "_100554_/l2/servicePreviewView" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class ServicePreviewView extends StateLitElement {
        infoIca: any;
        private msg;
        private file;
        private models;
        father: any;
        page: string;
        mode: string;
        lang: string;
        level: string;
        isDsComponent: boolean;
        watch: boolean;
        stylechanged: string;
        actualtheme: string;
        error: string;
        lastCompiledUrl: string;
        widthP: string;
        heightP: string;
        private setEventsCollab;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        render(): any;
        renderError(): any;
        renderPreview(): any;
        updated(changedProperties: any): void;
        private onWidgetActionEvents;
        private selectIdinPreview;
        private findElementsStartingWithIca;
        private fireChangeICA;
        private changeLevelIca;
        private addStyles;
        private injected;
        private load;
        private init;
        private pending;
        private setMessage;
        private setTheme;
        private setDevice;
        private setMyFile;
        private createModel;
        private lastHTML;
        private isService;
        private checkIfIsService;
        private setHtml;
        private setHtml2;
        private getPreviewConfigByProject;
        private setHtmlByLevel;
        private getFileContent;
        private modeSinglePage;
        private modeMinimum;
        private modeByProjectConfig;
        private addGlobalCss;
        private mountTokens;
        private removeOlderTokens;
        private getIdTokens;
        private changeWidthP;
        private changeHeightP;
        private timeShow;
        private showLoader;
        cleanTree(): string;
        private cleanTree2;
        private cleanTree3;
        private fireTesting;
        private getTesting;
        private setTesting;
        private removerTesting;
    }
}
declare module "_102025_/l2/collabMessagesIcons" {
    export const collab_message: any;
    export const collab_reply: any;
    export const collab_copy: any;
    export const collab_pin: any;
    export const collab_star: any;
    export const collab_paperclip: any;
    export const collab_edit: any;
    export const collab_delete: any;
    export const collab_smile: any;
    export const collab_chevron_down: any;
    export const collab_chevron_right: any;
    export const collab_clock_static: any;
    export const collab_users: any;
    export const collab_user: any;
    export const collab_magnifying_glass: any;
    export const collab_arrow_up_long: any;
    export const collab_minus: any;
    export const collab_ban: any;
    export const collab_dot: any;
    export const collab_bell: any;
    export const collab_money: any;
    export const collab_pause: any;
    export const collab_clock: any;
    export const collab_check: any;
    export const collab_bug_x12: any;
    export const collab_play: any;
    export const collab_bug: any;
    export const collab_chevron_left: any;
    export const collab_gear: any;
    export const collab_translate: any;
    export const collab_circle_exclamation: any;
    export const collab_circle_check: any;
    export const collab_plus: any;
    export const collab_folder_tree: any;
    export const collab_triangle_exclamation: any;
    export const collab_bell_slash: any;
    export const collab_xmark: any;
    export const collab_spinner_clock: any;
    export const collab_trash: any;
    export const collab_link: any;
    export const collab_plug: any;
    export const collab_robot: any;
    export const collab_refresh: any;
    export const collab_floppy_disk: any;
    export const collab_crm: any;
    export const collab_tasks: any;
    export const collab_connect: any;
    export const collab_moments: any;
    export const collab_apps: any;
    export const collab_warning: any;
    export const collab_signal: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
}
declare module "_102025_/l2/collabMessagesEmojis" {
    export interface IEmoji {
        unicode: string;
        shortname: string;
        aliases: string[];
    }
    export const emojiList: {
        text: string;
        value: string;
        description: string;
        alias: string[];
    }[];
}
declare module "_102025_/l2/collabMessagesAvatar" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class CollabMessagesAvatar extends StateLitElement {
        avatar: string;
        alt: string;
        width: string;
        height: string;
        updated(changedProperties: Map<string, any>): void;
        render(): any;
    }
}
declare module "_102025_/l2/collabMessagesRichTextParser" {
    export type RichToken = {
        type: 'text';
        value: string;
    } | {
        type: 'bold';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'italic';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'strike';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'inline-code';
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'code-block';
        language: string;
        value: string;
        markerStart: string;
        markerEnd: string;
    } | {
        type: 'mention';
        value: string;
        userId: string;
    } | {
        type: 'agent';
        value: string;
    } | {
        type: 'channel';
        value: string;
    } | {
        type: 'command';
        value: string;
    } | {
        type: 'help';
        value: string;
    } | {
        type: 'link';
        text: string;
        url: string;
    } | {
        type: 'raw-link';
        url: string;
    } | {
        type: 'heading';
        level: number;
        children: RichToken[];
    } | {
        type: 'horizontal-rule';
    } | {
        type: 'blockquote';
        children: RichToken[];
        lines: RichToken[][];
    } | {
        type: 'list';
        ordered: boolean;
        items: RichListItem[];
    };
    export interface RichListItem {
        marker: string;
        children: RichToken[];
    }
    export function parseRichText(input: string): RichToken[];
    export function parseInlineRichText(input: string, skipCodeBlock?: boolean): RichToken[];
}
declare module "_102025_/l2/collabMessagesPromptEditing" {
    export interface EditResult {
        text: string;
        selectionStart: number;
        selectionEnd: number;
    }
    interface LineInfo {
        start: number;
        end: number;
        text: string;
    }
    interface ListMarker {
        indent: string;
        marker: string;
        spacing: string;
        content: string;
        ordered: boolean;
    }
    export function getLineInfo(text: string, cursor: number): LineInfo;
    export function replaceRange(text: string, start: number, end: number, value: string, cursorOffset?: number): EditResult;
    export function insertText(text: string, selectionStart: number, selectionEnd: number, value: string, cursorOffset?: number): EditResult;
    export function getListMarker(line: string): ListMarker | undefined;
    export function getNextListPrefix(marker: ListMarker): string;
    export function applySmartNewline(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function indentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function outdentSelection(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function wrapSelection(text: string, selectionStart: number, selectionEnd: number, before: string, after: string, placeholder?: string): EditResult;
    export function makeCodeBlock(text: string, selectionStart: number, selectionEnd: number): EditResult;
    export function makeLinePrefix(text: string, selectionStart: number, selectionEnd: number, prefix: string): EditResult;
}
declare module "_102025_/l2/collabMessagesPrompt" {
    import * as msg from "_102025_/l2/shared/interfaces";
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    import "_102025_/l2/collabMessagesAvatar";
    export function serializeUserMentions(text: string, users: msg.User[]): string;
    export function deserializeUserMentions(text: string, users?: msg.User[]): string;
    export class CollabMessagesPrompt extends StateLitElement {
        private msg;
        textArea: HTMLTextAreaElement | undefined;
        overlayElement?: HTMLElement;
        mentionSuggestionsElement?: HTMLElement;
        wrapper?: HTMLElement;
        text: string;
        actualMention?: IMentions;
        mentionActive: boolean;
        mentionQuery: string;
        mentionSuggestions: IMentions[];
        mentionIndex: number;
        allUsers: msg.User[];
        allUsersValids: msg.User[];
        hasSelection: boolean;
        selectedFiles: File[];
        sendError: string;
        isSending: boolean;
        allAgents: IMentionAgent[];
        alreadyLoadingAgents: boolean;
        lastScopeLoaded: string | undefined;
        replyingTo?: {
            messageId: string;
            senderId: string;
            preview: string;
        };
        onSend: Function | undefined;
        threadId?: string;
        placeholder?: string;
        scope?: string;
        allowAttachments: boolean;
        showSubmitButton: boolean;
        submitOnEnter: boolean;
        acceptAutoCompleteUser?: boolean;
        acceptAutoCompleteAgents?: boolean;
        enableRichPreview?: boolean;
        connectedCallback(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): void;
        updated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        setReply(message: {
            messageId: string;
            senderId: string;
            preview: string;
        }): void;
        clearReply(): void;
        private getUsers;
        private getAgents;
        private getCaretCoordinates;
        private calculatePosition;
        private adjustTextAreaHeight;
        private handleScroll;
        private renderRichToken;
        private renderRichOverlay;
        render(): any;
        private renderToolbar;
        private renderReply;
        private renderSelectedAttachments;
        handleFocus(): Promise<void>;
        handleInput(e: MouseEvent): Promise<void>;
        private preventToolbarFocus;
        private updateSelectionState;
        private clearSelectionState;
        private applyEditResult;
        private syncTextAreaEdit;
        private applyInlineFormat;
        private applyCodeBlock;
        private applyLinePrefix;
        private applyLink;
        private openAttachmentPicker;
        private handleAttachmentInput;
        private removeSelectedAttachment;
        private emitTextChange;
        private formatFileSize;
        private getUserSuggestions;
        private getAgentSuggestions;
        private getEmojiSuggestions;
        private handleKeyDown;
        private handlePaste;
        private scrollToActiveMention;
        private selectMention;
        private extractAgentName;
        handleSend(): Promise<void>;
    }
    interface IMentionAgent {
        name: string;
        description: string;
        alias: string;
        avatar_url?: string;
    }
    interface IMentions {
        text: string;
        value: string;
        description: string;
        avatar_url?: string | undefined;
        type: 'user' | 'agent' | 'emoji';
    }
}
declare module "_102027_/l2/pluginBaseModule" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export abstract class PluginBaseModule extends StateLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultJs" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100555_/l2/pluginPreview/pluginPreviewResultTestJs" {
    import { PluginBaseModule } from "_102027_/l2/pluginBaseModule";
    import "_102027_/l2/collabMonacoEditor";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): any;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdTestJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100554_/l2/servicePreview" {
    import { ServiceBase, IService, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_100554_/l2/collabConsole";
    import "_100554_/l2/collabResultTest";
    import "_100554_/l2/servicePreviewView";
    import "_102025_/l2/collabMessagesPrompt";
    import "_100554_/l2/collabSpliterVerticalVarFixed";
    import "_100554_/l2/collabSpliterHorizontalVarFixed";
    export class ServicePreview100554 extends ServiceBase {
        itens: any;
        msize: string;
        error: string;
        watch: boolean;
        enabledConsole: boolean;
        enabledTest: boolean;
        light: boolean;
        lang: string;
        page: string;
        previewContent: HTMLElement | undefined;
        private msg;
        private threadCache;
        private tasksInProgress;
        private themesByModule;
        private lastMode;
        private lastModePreview;
        private lastLevel;
        private elPreview;
        private themes;
        private actualTheme;
        private _ed1;
        private monacoeditor;
        private languages;
        private timeEvent;
        get confE(): string;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        onClickTools(op: string): void;
        actButton(op: string): Promise<boolean>;
        onClickTitle: () => void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private changeTools;
        private changeToolsLevel3;
        private elEditL3;
        private toogleEditTextL3;
        private setEvents;
        private onL3EditEvents;
        private onActiveModeEdit;
        private onReloader;
        private lastStatusHasError;
        private onStyleChanged;
        private onLevelChange;
        private onTsTestChanged;
        private actualFile;
        private onMLSFileAction;
        private onOpenLink;
        handleSend(value: string, opt: {
            isSpecialMention: boolean;
            agentName: string;
        }): Promise<void>;
        private onTaskChange;
        private updateLoadingToFalseIfNoTasksRunning;
        private fireCollab;
        private cancelEditL3;
        private configureButtonsRight;
        private showEditorHTML;
        private showEditorHTML2;
        private pluginResultJS;
        private showResultJS;
        private pluginResultTestJS;
        private showResultTestJS;
        private showAboutThis;
        private getIframePreviewHTML;
        private actualTestList;
        private astTSTest;
        private setTest;
        private onBtTestClick;
        private fireEventsDetails;
        private addTestResultItem;
        private runTest;
        private runAllTests;
        private onBtTestListClick;
        private deleteTest;
        private refreshAST;
        private onBtLanguageClick;
        private onBtDarkLightClick;
        private onBtThemeClick;
        private toogleWatch;
        private toogleConsole;
        private openTestResults;
        private closeTestResults;
        private onHelpClick;
        private createEditor;
        private createModelIfNeeded;
        private setModel;
        private getDarkLight;
        private setLanguages;
        private getFileModuleThemeName;
        private getModuleNameByFile;
        private setThemeByModule;
        private setTheme;
        private createTestElement;
        private fireWcdChanges;
        private getScriptTest;
        private getParam;
        private processValue;
        private preview;
        private previewL2;
        private previewByLevel;
        private clearPreview;
        private createPreview;
        private _onClickTitle;
        private setTitleByLevel;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
    }
}
declare module "_100554_/l2/servicePreviewL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/servicePreviewL1ListServer" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    import "_100554_/l2/collabConsoleL1";
    export class ServicePreviewL1ListServer extends CollabLitElement {
        private esbuild;
        private cacheBuild;
        iframes: Record<string, HTMLIFrameElement>;
        servers: Record<string, HTMLIFrameElement>;
        listItens: IListItem[];
        viewServer: HTMLElement | undefined;
        iframesContent: HTMLElement | undefined;
        constructor();
        render(): any;
        renderHeader(): any;
        renderList(): any;
        renderItem(item: IListItem, idx: number): any;
        private init;
        private loadEsbuild;
        private initializeEsBuild;
        private handleClickPower;
        private handleClickRestart;
        private handleClickView;
        private handleCloseView;
        private refreshRow;
        private onServer;
        private offServer;
        private restartServer;
        private createServer;
        private setHTml;
        private compileWithEsbuild;
        private getVirtualFiles;
        private getVirtualFilesPlugin;
        private mountJSImporMap;
        private mountJSBundle;
    }
    interface IListItem {
        name: string;
        server: string;
        icon: string | undefined;
    }
}
declare module "_100554_/l2/servicePreviewL1" {
    import { IService, IServiceMenu, IToolbarContent, ServiceBase } from "_102027_/l2/serviceBase";
    import "_100554_/l2/servicePreviewL1ListServer";
    export class ServicePreviewL1100554 extends ServiceBase {
        private msg;
        private get liveServerView();
        private liveViewTag?;
        elContent: HTMLElement | undefined;
        error: string;
        watch: boolean;
        startServer: boolean;
        private timeEvent;
        private actualFile;
        private actualFileKey;
        private actualTheme;
        private startInstance;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        onClickTools(op: string): void;
        connectedCallback(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
    }
}
declare module "_100554_/l2/servicePreviewL1ListServer.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/servicePreviewView.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceProduct.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceProduct" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceProduct extends ServiceBase {
        private resizeObserver;
        service: ServiceBase | undefined;
        refresh: string;
        private msg;
        levelFiles: number;
        project: number;
        filterProject: number;
        projectLabel: string;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        activeTab: string;
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        menu: IServiceMenu;
        private showAboutThis;
        private onlevelChange;
        connectedCallback(): void;
        disconnectedCallback(): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        renderModeList(): any;
        renderHeader(): any;
        renderList(): any;
        renderLiItem(file: mls.stor.IFileInfo, index: number): any;
        private getAllName;
        private showLoading;
        private showError;
        private clickOptOpen;
        private fireEvents;
        private changeListTimeout;
        changeList(time?: number): void;
        private init;
        private getMyFileInElement;
        private inFilter;
        private timeFilterChange;
        private filterLiChange;
        private getFiles;
        private validFileByLevel;
        private getFilesProject;
        private dataDifBaseTemplate;
        private verifyDifBaseTemplate;
        private initObserverResize;
    }
}
declare module "_100554_/l2/serviceProject.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceProject" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceProject100554 extends ServiceBase {
        private baseProject;
        private msg;
        activeTab: IScenery;
        explories: mls.plugin.MenuAction[];
        projectDiv: HTMLDivElement | undefined;
        firstDetails: HTMLDetailsExplore | undefined;
        allContainers: HTMLDivElement[] | undefined;
        private myData;
        private lastActiveTabByLevel;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        private getMenuTabsByLevel;
        menu: IServiceMenu;
        private lastLevel;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private showAboutThis;
        firstUpdated(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        private renderContent;
        private renderExplore;
        private renderShowCase;
        private renderAdmin;
        private renderPlugin;
        private renderPanel;
        private refreshPlugins;
        private updateIconsByLevel;
        private fireEventClose;
        private handleDetailExplorieClick;
        private getExploreData;
        private handleAddNewPlugin;
        private pluginsList;
        private groupPluginsByCategory;
        private loadHelpPage;
        private setMyData;
    }
    type IScenery = 'Explore' | 'ShowCase' | 'Admin' | 'Plugins';
    interface HTMLDetailsExplore extends HTMLDetailsElement {
        data: mls.plugin.MenuAction;
    }
}
declare module "_100554_/l2/serviceReportBug" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceReportBug100554 extends ServiceBase {
        private msg;
        private snapshot;
        private description;
        private sent;
        private sending;
        private sendError;
        private destinations;
        private selectedThreadId;
        private destinationFilter;
        private showSuggestions;
        private highlightedIndex;
        private viewData;
        private viewError;
        constructor();
        details: IService;
        menu: IServiceMenu;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        refreshSnapshot(): void;
        openView(json: string): void;
        private closeView;
        private loadDestinations;
        private get filteredDestinations();
        private selectDestination;
        private onFilterInput;
        private onFilterBlur;
        private onFilterKeyDown;
        private buildPayload;
        private buildMessageContent;
        private onSend;
        private renderEmpty;
        private renderMlsContext;
        private renderNetwork;
        private renderConsole;
        private renderDataSections;
        private renderView;
        private renderSnapshot;
        render(): any;
    }
}
declare module "_100554_/l2/serviceSave.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceSave" {
    import { ServiceBase, IService, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_100554_/l2/pluginCreateProjectLocalToDriver";
    export class ServiceSave extends ServiceBase {
        private myMessage;
        private mainowner;
        private mainrepo;
        private mainbranch;
        private owner;
        private repo;
        private branch;
        private scenery;
        private exceededLimit;
        freeToSave: {
            ts: boolean;
            less: boolean;
            hasDS: boolean;
        };
        isFreeToSave: boolean;
        selectedProject: number | undefined;
        itens: IDefItem | undefined;
        otherProjects: Record<string, Record<string, string[]>>;
        error: string;
        totFileSize: string;
        createRenderRoot(): this;
        get currentProject(): number | undefined;
        constructor();
        details: IService;
        onClickMain(op: string): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onLevelchange;
        private onMLSEvents;
        private onFreeToSave;
        private isServiceVisible;
        private verifyExitFileChanged;
        connectedCallback(): void;
        render(): any;
        renderBlockScenery(): any;
        renderHeader(): any;
        renderNoItens(): any;
        renderOthersProjects(): any;
        renderOthersProjectsItens(project: number): any;
        renderItensOtherProjects(project: number, path: string): any;
        renderItens(): any;
        renderProject(project: string, index: number): any;
        renderLevels(level: string, project: string, indexP: number, index: number): any;
        renderFilesDefault(file: string, level: string, project: string, indexPP: number, indexP: number, index: number): any;
        renderItem(item: Iitem, indexP: number, indexL: number, indexM: number, index: number, forceError: boolean): any;
        renderAuxActionsItem(item: Iitem): any;
        private clickHistory;
        private init;
        private initInfoProject;
        private showLoader;
        private showBranche;
        private setInfos;
        private getActualProjectDependencies;
        private selectProject;
        private getOtherProjects;
        private setProjectLevelShortName;
        private oIcon;
        private fromToExtension;
        private configItem;
        private openMeList;
        private clickSetValueAllChilds;
        private setValueAllChilds;
        private timeSumTotal;
        private clickVerifyStatusFather;
        private sumTotalSize;
        private verifyStatusFather;
        private updateList;
        private fireOnPullrequest;
        private createFork;
        private forceSaveL5ProjectFile;
        private arrayRollback;
        private inSaving;
        private onSave;
        private verifyNeedSelectDS;
        private afterSave;
        private onSavenewPullrequest;
        private isRemovedFork;
        private fireCreateForkOrUpdate;
        private removeFork;
        private fireCreateNewBranch;
        private firePullrequest;
        private onSave_withOutPullRequest;
        private backChecked;
        private veriFyPermission;
        private clearLocalHIstoryCurrentInfoDriver;
        private setLocalHIstoryCurrentInfoDriver;
        private getLocalHIstoryCurrentInfoDriver;
        private getAllFileToSave;
        private onSave_old;
        private afterUpdate;
        private uppVersionAfterSave;
        private deleteFile;
        private fireEvents;
        private fireEventsDetails;
        private freeToSaveProjectAndDs;
        private undoFile;
        private removeFileByInfoImmutable;
        private forceSync;
        private STORAGE_KEY;
        private getAllUserOpenedFiles;
    }
    interface IDefItem {
        [key: number]: IDefItemLevel;
    }
    interface IDefItemLevel {
        [key: number]: Ifile;
    }
    interface Ifile {
        [key: string]: Iitem[];
    }
    interface Iitem {
        file: mls.stor.IFileInfo;
        text: string;
        span: string;
        onlyFather: boolean;
        disabled: boolean;
        errorLocal: boolean;
        modelIsDispose: boolean;
    }
}
declare module "_100554_/l2/serviceSource.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceSourceL1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceSourceL1" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_100554_/l2/collabSpliterVerticalVarFixed";
    import "_100554_/l2/collabSpliterHorizontalVarFixed";
    import "_100554_/l2/cssHelperIndex";
    import "_102027_/l2/collabMonacoEditor";
    export class ServiceSource100554 extends ServiceBase {
        constructor();
        private baseProject;
        msize: string;
        activeModels: mls.editor.IModels | undefined;
        isModeHistory: boolean;
        mode: IModes;
        textOverlayLoading: string;
        currentHistorySourceWithoutSave: string | undefined;
        previousHistorySourceWithoutSave: string | undefined;
        currentHistorySource: string | undefined;
        previousHistorySource: string | undefined;
        historyLanguage: 'typescript' | 'html' | 'less' | 'defs';
        selectedMode: 'icTs' | 'icDefs' | 'History' | undefined;
        lockMap: Map<string, boolean>;
        private viewState;
        private msg;
        private modeToExt;
        onClickMain(op: string): void;
        onClickTabs: (op: number) => void;
        private createModelIfNeed;
        onClickTitle: () => void;
        onClickTools(op: string): void;
        details: IService;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        private openActualL2;
        inCreate: Record<string, Promise<void> | undefined>;
        getEditorValue(): string;
        formatMonaco(): void;
        private editorEl;
        private editorHistoryEl;
        overlayLoading: HTMLElement | undefined;
        private verticalSpliter;
        private horizontalSpliter;
        last: mls.IActual | undefined;
        _ed1: monaco.editor.IStandaloneCodeEditor | undefined;
        private _edDiff;
        private mConfEditor;
        private confE2;
        get confE(): string;
        get confETS(): string;
        get confEJS(): string;
        private saveViewState;
        private restaureViewState;
        private toogleHistory;
        private getHistories;
        private openRepo;
        private showHistory;
        private showHistorie2;
        private mapExt;
        private onMLSEvents;
        private fireEditorEvents;
        private openFiles;
        private activeThisService;
        private closeMenu;
        delay(ms: number): Promise<void>;
        private showThisModel;
        private showActiveModel;
        private initMonaco;
        private monacoGlobalInitialized;
        private initMonaco_GlobalEditor;
        private initMonaco_Editor;
        private actionAgentFix;
        private addFixAction;
        private lockEditorForFile;
        private isEditorLocked;
        private unlockEditorForFile;
        private removeFixAction;
        private updateActionBasedOnError;
        private getActualL1File;
        private fireAgentFix;
        private toogleOverlayLoading;
        private initMonaco_EditorDiff;
        private setHistories;
        private createOrGetModelHistory;
        private loadMonacoConfigurations;
        private getUri;
        private createModel;
        private createModelConf;
        timeout_compileConfEditor: number;
        private compileSrcEditor;
        private loadConfEditorFromLocalStorage;
        private saveConfEditorToLocalStorage;
        private setConfEditorFromJavascript;
        private updateMonacoConfigutarions;
        private updateMonacoGlobalTheme;
        private _formatIfNeeded;
        private getPosition;
        private getLocalStorageInfo;
        private saveLocalStorageInfo;
        private updatedMSizeEditor;
        private toogleIconsError;
        private currentReviewDecorationIds;
        private highlightReviewLines;
        private changeMode;
        private saveLocalStorageLastOpen;
        private openLastFile;
        getActualRef(): string;
        updated(changedProperties: any): void;
        connectedCallback(): void;
        firstUpdated(changedProperties: any): void;
        render(): any;
    }
    export type FormattableModel = monaco.editor.ITextModel & {
        needFormat: boolean;
    };
    type IModes = 'icTs' | 'icDefs';
}
declare module "_100554_/l2/serviceUnit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceUnit" {
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    export class ServiceUnit extends ServiceBase {
        private baseProject;
        private msg;
        activeTab: IScenery;
        explories: mls.plugin.MenuAction[];
        projectDiv: HTMLDivElement | undefined;
        firstDetails: HTMLDetailsExplore | undefined;
        allContainers: HTMLDivElement[] | undefined;
        private myData;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(index: number): void;
        menu: IServiceMenu;
        private lastLevel;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private showAboutThis;
        firstUpdated(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        render(): any;
        private renderContent;
        private renderExplore;
        private renderShowCase;
        private refreshPlugins;
        private fireEventClose;
        private handleDetailExplorieClick;
        private getExploreData;
        private loadHelpPage;
        private setMyData;
    }
    type IScenery = 'Explore' | 'ShowCase';
    interface HTMLDetailsExplore extends HTMLDetailsElement {
        data: mls.plugin.MenuAction;
    }
}
declare module "_100554_/l2/serviceUser.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/serviceUser" {
    import { LitElement } from 'lit';
    import { ServiceBase, IService, IToolbarContent, IServiceMenu } from "_102027_/l2/serviceBase";
    import "_100554_/l2/collabPanel";
    import "_100554_/l2/collabPanelItem";
    export class ServiceUser100554 extends ServiceBase {
        private msg;
        private data;
        activeTab: IScenery;
        plugin: string;
        collabPanel: LitElement | undefined;
        details: IService;
        onClickMain(op: string): void;
        onClickTabs(op: number): void;
        menu: IServiceMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        updated(changedP: any): Promise<void>;
        firstUpdated(): Promise<void>;
        render(): any;
        private renderContent;
        private renderSettings;
        private renderPanel;
        private baseProject;
        private setMyData;
    }
    type IScenery = 'Settings';
}
declare module "_100554_/l2/testCoachMarks.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testCoachMarks" {
    import { CollabPageElement } from "_100554_/l2/collabPageElement";
    export class TestCoachMarks100554 extends CollabPageElement {
        initPage(): void;
        private setCoach;
    }
}
declare module "_100554_/l2/testMindMap.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testMindMap" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class TestMindMap100554 extends StateLitElement {
        result: any;
        firstUpdated(): Promise<void>;
        render(): any;
    }
}
declare module "_100554_/l2/testScenario1.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testScenario1" {
    import { IScenaryDetails } from "_102029_/l2/collabLitElement";
    export function _100554_testScenario1_getScenaryDetails(): IScenaryDetails;
}
declare module "_100554_/l2/testScenario2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testScenario2" {
    import { IScenaryDetails } from "_102029_/l2/collabLitElement";
    export function _100554_testScenario2_getScenaryDetails(): IScenaryDetails;
}
declare module "_100554_/l2/testState.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/testState" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class TestState100554 extends StateLitElement {
        name: string;
        render(): any;
    }
}
declare module "_100554_/l2/toolFilterFilesL2.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/toolFilterFilesL2" {
    import { ITool } from "_102027_/l2/aiAgentBase";
    export function createTool(): ITool;
}
declare module "_100554_/l2/toolMortgageCalculator.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/toolMortgageCalculator" {
    import { ITool } from "_102027_/l2/aiAgentBase";
    export function createTool(): ITool;
}
declare module "_100554_/l2/tsTestAST.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/tsTestASTTeste.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/tsTestASTTeste.test" {
    import { ICANTest, ICANIntegration } from "_100554_/l2/tsTestAST";
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_100554_/l2/tsTestASTTeste" {
    import { LitElement } from 'lit';
    import { TsTestAst } from "_100554_/l2/tsTestAST";
    export class LessASTTest100554 extends LitElement {
        fileName: string;
        model1: mls.editor.IModelTest;
        fileToTest: string;
        result: string;
        render(): any;
        exeTest: () => "No find editor" | "undefined;";
        test1: (testAST: TsTestAst) => string;
        test2: (testAST: TsTestAst) => string;
        test3: (testAST: TsTestAst) => string;
        test4: (testAST: TsTestAst, title: string) => string;
        test5: (testAST: TsTestAst, description: string) => string;
        test6: (testAST: TsTestAst, name: string) => string;
    }
}
declare module "_100554_/l2/tsTestMonaco.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/utilsLit.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/wcAuxCommand.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/wcAuxCommand" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class WcAuxCommand100554 extends StateLitElement {
        private elView;
        private boundFireKeydown;
        idElView: string | undefined;
        caracter: string | undefined;
        itens: IAuxCommand[];
        createRenderRoot(): this;
        connectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): any;
        renderGroup(item: IAuxCommand, idx: number): any;
        renderItem(item: IAuxCommandItens, idx: number): any;
        private setDefinition;
        private mouseLeave;
        private fireKeydown;
        private getElementPosition;
        private clickItem;
    }
    export interface IAuxCommand {
        group: string;
        itens: IAuxCommandItens[];
    }
    export interface IAuxCommandItens {
        label: string;
        value: string;
        icon: string;
    }
}
declare module "_100554_/l2/widgetClarificationNewWidget.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetClarificationNewWidget" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class WcClarificationPlannerNewWidget100554 extends StateLitElement {
        private ICABASEPROJECT;
        data?: ClarificationData;
        error?: string;
        develpoment?: boolean;
        mode: 'readonly' | 'write';
        inputTag?: HTMLInputElement;
        widgetNameError?: HTMLInputElement;
        render(): any;
        private renderResume;
        private renderParentClass;
        private renderWidgetName;
        private renderProperties;
        private renderRequirements;
        private createTagName;
        private removeTrailingPattern;
        private createParentName;
        private handleWidgetNameInput;
        private handleTagNameChange;
        private handleParentInput;
        private handleRqVisualInput;
        private handleRqFunctionalInput;
        private handleCancel;
        private handleOk;
        private handleAction;
        private setDevelpoment;
    }
    interface ClarificationData {
        json: Clarification[] | undefined;
        taskId: string;
        stepId: number;
        clarificationMessage: string;
    }
    type Clarification = ClarificationResume | ClarificationWidgetName | ClarificationParentName | ClarificationProperties | ClarificationRequirements;
    interface ClarificationBase {
        sectionName: string;
        description: string;
    }
    interface ClarificationResume extends ClarificationBase {
    }
    interface ClarificationWidgetName extends ClarificationBase {
        widgetName: string;
        tagName: string;
    }
    interface ClarificationParentName extends ClarificationBase {
        widgetName: string;
    }
    interface ClarificationProperties extends ClarificationBase {
        properties: {
            propertyName: string;
            description: string;
            isEssencial: string;
        }[];
    }
    interface ClarificationRequirements extends ClarificationBase {
        functionalRequirements: string[];
        visualRequirements?: string[];
    }
}
declare module "_100554_/l2/widgetCollabChart.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetCollabChart" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class WcEchartsPie100554 extends StateLitElement {
        data: any | undefined;
        chartTitle: string;
        framework: 'echarts';
        renderer: 'canvas' | 'svg';
        main: HTMLDivElement | undefined;
        private myChart;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        initChart(): void;
        firstUpdated(): void;
        render(): any;
    }
}
declare module "_100554_/l2/widgetDivider.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetDivider" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class WcDivider100554 extends StateLitElement {
        createRenderRoot(): this;
        text: string | undefined;
        render(): any;
    }
}
declare module "_100554_/l2/widgetDividerLine.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetDividerLine" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class WidgetDivider100554 extends StateLitElement {
        createRenderRoot(): this;
        text: string | undefined;
        render(): any;
    }
}
declare module "_100554_/l2/widgetEmbedsSocialMedia.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetEmbedsSocialMedia" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class WcEmbedsSocialMedia100554 extends StateLitElement {
        datasource: string | undefined;
        description: string | undefined;
        url: string | undefined;
        render(): any;
        generateYouTubeEmbed(url: string): any;
        generateTwitterEmbed(url: string): any;
        loadExternalScripts(): void;
    }
}
declare module "_100554_/l2/widgetImage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetImage" {
    import { StateLitElement } from "_102029_/l2/stateLitElement";
    export class WcImage100554 extends StateLitElement {
        src: string | undefined;
        alt: string | undefined;
        width: string | undefined;
        height: string | undefined;
        render(): any;
    }
}
declare module "_100554_/l2/widgetInputText.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetInputText" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class WcInputText100554 extends CollabLitElement {
        autocapitalize: any;
        validationmessage: string | undefined;
        debounce: string | undefined;
        value: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        autocorrect: any;
        autoCapitalize: 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters' | undefined;
        input: HTMLInputElement | undefined;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_100554_/l2/widgetMindMapL4.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetPlaygroundState.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/widgetPlaygroundState" {
    import { LitElement } from 'lit';
    export class WidgetPlaygroundState extends LitElement {
        state: string;
        connectedCallback(): void;
        firstUpdated(): void;
        render(): any;
        private initStatePlayground;
    }
}
declare module "_100554_/l2/widgetSelect" {
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    export class WcInputText100554 extends CollabLitElement {
        autocapitalize: any;
        validationmessage: string | undefined;
        debounce: string | undefined;
        value: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        options: string | undefined;
        get _options(): any;
        error: string;
        render(): any;
        handleChange(event: Event): void;
    }
}
declare module "_100554_/l2/widgetTextCode.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agentTest/agent1" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: string[];
    };
}
declare module "_100554_/l2/agentTest/agent2" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: Info[];
    };
    export type Info = {
        country: string;
        briefDescription: string;
    };
}
declare module "_100554_/l2/agents/agentBackendMaterializationPlan.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agents/agentBackendMaterializationPlan" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export type Output = {
        type: "flexible";
        result: BackendMaterializationPlan;
    };
    export interface BackendMaterializationPlan {
        domains: Record<string, BackendMaterializationResult>;
        decisions?: MaterializationDecision[];
        warnings?: string[];
    }
    export interface BackendMaterializationResult {
        domainId: string;
        entities: MaterializedEntity[];
        commands: MaterializedCommand[];
        events: MaterializedEvent[];
        readModels?: MaterializedReadModel[];
        warnings?: string[];
        decisions?: MaterializationDecision[];
    }
    export interface MaterializedEntity {
        entityId: string;
        persistence: {
            kind: "derived" | "event-log" | string;
            storageShape: "aggregate" | "flat";
        };
        source: "existing" | "extended" | "new";
        schema: Record<string, string>;
        embedded?: string[];
    }
    export interface MaterializedCommand {
        commandId: string;
        entityId: string;
        input: Record<string, string>;
        output?: Record<string, string>;
        validatesStates?: string[];
        emitsEvents?: string[];
        rules: string[];
        actions: string[];
        execution: "sync" | "async";
    }
    export interface MaterializedEvent {
        eventId: string;
        entityId: string;
        persistence: "append-only" | "derived-only";
        payloadSchema?: Record<string, string>;
    }
    export interface MaterializedReadModel {
        modelId: string;
        sourceEvents: string[];
        fields: Record<string, string>;
        purpose: ("BI" | "llm-query")[];
        updateStrategy: "event-driven" | "scheduled";
    }
    export interface MaterializationDecision {
        type: "reuse-existing-module" | "extend-existing-module" | "override-tobe-definition" | "constraint-adjustment";
        moduleName: string;
        target: string;
        reason: string;
    }
}
declare module "_100554_/l2/agents/agentDefs.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102027_/l2/defsAST" {
    export function parseDefsFile(source: string): {
        asis: mls.defs.AsIs;
        history: mls.defs.ChangeHistoryItem[];
        skill: string;
    };
    export function getAsis(source: string): mls.defs.AsIs;
    export function updateAsis(source: string, patch: DeepPartial<mls.defs.AsIs>): string;
    export function replaceAsis(source: string, value: mls.defs.AsIs): string;
    export function getHistory(source: string): mls.defs.ChangeHistoryItem[];
    export function addHistoryItem(source: string, item: mls.defs.ChangeHistoryItem): string;
    export function updateHistoryItem(source: string, version: number, patch: Partial<mls.defs.ChangeHistoryItem>): string;
    export function replaceHistory(source: string, value: mls.defs.ChangeHistoryItem[]): string;
    export function getSkill(source: string): string;
    export function updateSkill(source: string, value: string): string;
    type DeepPartial<T> = {
        [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
    };
    export function getMaterializeIndex(source: string): mls.defs.MaterializeIndex;
    export function replaceMaterializeIndex(source: string, value: mls.defs.MaterializeIndex): string;
    export function addMaterializeItem(source: string, item: mls.defs.MaterializeEntry): string;
    export function updateMaterializeItem(source: string, id: string, patch: Partial<mls.defs.MaterializeEntry>): string;
    export function removeMaterializeItem(source: string, id: string): string;
    export function getVariableText(source: string, varName: string): string;
    export function updateVariableText(source: string, varName: string, value: string): string;
    export function getVariableJson<T = unknown>(source: string, varName: string): T;
    export function updateVariableJson(source: string, varName: string, value: unknown): string;
}
declare module "_100554_/l2/agents/agentDefs" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getSource(file: mls.stor.IFileInfo): Promise<string>;
    export function updateDefs(defs: AsIs): Promise<void>;
    export const system1 = "\n<!-- modelType: code -->\n<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) ou nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10-->\n\nYou are a Senior Software Engineer at Collab.codes.\n\nYou will receive a user message containing:\nFILE, LANG, and a code block delimited by BEGIN_CODE and END_CODE.\n\nTask:\nGenerate an AsIsFactual JSON object that strictly follows the provided JSON schema.\n\n## Details\n[[SudoLang]]\n\n## Output format\nYou must return the object strictly as JSON\n[[OutputSection]]\n\n[[Defs1]]\n[[Defs2]]\n[[Defs3]]\n";
    export type Output = {
        type: "flexible";
        result: AsIs;
    };
    export interface AsIs {
        meta: {
            fileReference: string;
            componentType: ComponentType;
            componentScope: ComponentScope;
            executionRegions?: string[];
            languages?: string[];
            group?: string;
            /**
             * Development fidelity level, indicating the stage of development.
             * - 'draft': Initial concept, not functional.
             * - 'wireframe': Basic layout, no functionality.
             * - 'scaffold': Functional skeleton, minimal features.
             * - 'final': Fully functional, ready for production.
             */
            devFidelity?: 'draft' | 'wireframe' | 'scaffold' | 'final';
        };
        references?: {
            webComponents?: string[];
            imports?: DefsImports[];
            statesRO?: string[];
            statesRW?: string[];
            statesWO?: string[];
        };
        codeInsights?: {
            todos?: string[];
            securityWarnings?: string[];
            unusedImports?: string[];
            deadCodeBlocks?: string[];
            accessibilityIssues?: string[];
            i18nWarnings?: string[];
            performanceHints?: string[];
        };
        auth?: {
            view?: UserRole[];
            edit?: UserRole[];
            use?: UserRole[];
            restrictReason?: string;
        };
        asIs: {
            semantic: {
                generalDescription: string;
                businessCapabilities: string[];
                technicalCapabilities: string[];
                implementedFeatures: string[];
                constraints?: string[];
            };
        };
    }
    export type ComponentScope = 'appFrontEnd' | // shipped to customer application
    'appBackEnd' | // shipped to customer application
    'editor';
    export type ComponentType = 'page' | // (appFrontEnd) Full-screen view with its own route (e.g. /petshop/dashboard). Contains front-end business logic and calls back-end services.
    'organism' | // (appFrontEnd) Sections inside page. Contains front-end business logic and calls back-end services.
    'molecule' | // (appFrontEnd) reusable web component. Used inside organisms.
    'miniapp' | // (appFrontEnd) Self-contained application with its own navigation, usually one page, e.g., temperature converter, calculator.
    'pluginUI' | // (appFrontEnd) Front-end part of a plugin (buttons, widgets, config pages visible to the customer)
    'pluginSettings' | // (editor) Editor panel to configure a plugin (icon in toolbar, never shipped)
    'entity' | // (appBackEnd) data model (DB schema, ORM entity). Defines tables, fields, relations.
    'controller' | // (appBackEnd) Handles API endpoint requests: validates input and authorization, then executes the appropriate use case.
    'useCase' | // (appBackEnd) business logic unit. Encapsulates specific operations, called by controllers.
    'repository' | // (appBackEnd) data access layer. Interfaces with the database, performs CRUD operations.
    'hook' | // (appBackEnd) event handler or middleware (e.g., webhooks, auth guards).
    'editorService' | // (editor) Editor-only panel or toolbar.
    'agent' | // (editor) Specialized LLM orchestrator (prepares prompts, chains tools, etc.).
    'tool' | // (editor) Reusable function or module (e.g., data processing, integrations).
    'service' | // (editor) tool UI
    'other';
    export interface DefsImports {
        ref: string;
        dependencies?: {
            name: string;
            type?: "function" | "service" | "constant" | "interface" | "type" | "class" | "hook" | "component" | "?";
            purpose?: string;
        }[];
    }
    export type UserRole = string;
}
declare module "_100554_/l2/agents/agentMaterializePlugin" {
    import { IAgentAsync } from "_102027_/l2/aiAgentBase";
    export function createAgent(): IAgentAsync;
    export function getDefs(info: mls.stor.IFileInfoBase): Promise<string>;
    export function extractJSON(str: string): Record<string, any>;
    export type Output = {
        type: "flexible";
        result: MaterializationPlugin;
    };
    export interface MaterializationPlugin {
        project: number;
        shortName: string;
        folder: string;
        ts: string;
        less: string;
    }
    export function processTemplate(input: string): Promise<string>;
}
declare module "_100554_/l2/agents/collabAuraPageCommon.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_100554_/l2/agents/collabAuraPageCommon" {
    /**
     * =============================================================================
     * BACKEND BRIDGE (REAL + MOCK)
     * =============================================================================
     */
    export interface BeInvoke {
        invoke(routine: string, params: any): Promise<any>;
    }
    export function beInvoke(routine: string, requestId: number, params: any): Promise<any>;
    export function readLocal(routine: string, params: any): Promise<any>;
    export function savelocal(routine: string, params: any, result: any): Promise<void>;
    export function pluginInvoke(pluginRef: string, params: any): Promise<any>;
    export function generateId(): number;
}
