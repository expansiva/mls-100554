declare module "_100554_litCssTag" {
    /**
     * Whether the current browser supports `adoptedStyleSheets`.
     */
    export const supportsAdoptingStyleSheets: boolean;
    /**
     * A CSSResult or native CSSStyleSheet.
     *
     * In browsers that support constructible CSS style sheets, CSSStyleSheet
     * object can be used for styling along side CSSResult from the `css`
     * template tag.
     */
    export type CSSResultOrNative = CSSResult | CSSStyleSheet;
    export type CSSResultArray = Array<CSSResultOrNative | CSSResultArray>;
    /**
     * A single CSSResult, CSSStyleSheet, or an array or nested arrays of those.
     */
    export type CSSResultGroup = CSSResultOrNative | CSSResultArray;
    /**
     * A container for a string of CSS text, that may be used to create a CSSStyleSheet.
     *
     * CSSResult is the return value of `css`-tagged template literals and
     * `unsafeCSS()`. In order to ensure that CSSResults are only created via the
     * `css` tag and `unsafeCSS()`, CSSResult cannot be constructed directly.
     */
    export class CSSResult {
        ['_$cssResult$']: boolean;
        readonly cssText: string;
        private _styleSheet?;
        private _strings;
        private constructor();
        get styleSheet(): CSSStyleSheet | undefined;
        toString(): string;
    }
    /**
     * Wrap a value for interpolation in a {@linkcode css} tagged template literal.
     *
     * This is unsafe because untrusted CSS text can be used to phone home
     * or exfiltrate data to an attacker controlled site. Take care to only use
     * this with trusted input.
     */
    export const unsafeCSS: (value: unknown) => CSSResult;
    /**
     * A template literal tag which can be used with LitElement's
     * {@linkcode LitElement.styles} property to set element styles.
     *
     * For security reasons, only literal string values and number may be used in
     * embedded expressions. To incorporate non-literal values {@linkcode unsafeCSS}
     * may be used inside an expression.
     */
    export const css: (strings: TemplateStringsArray, ...values: (CSSResultGroup | number)[]) => CSSResult;
    /**
     * Applies the given styles to a `shadowRoot`. When Shadow DOM is
     * available but `adoptedStyleSheets` is not, styles are appended to the
     * `shadowRoot` to [mimic spec behavior](https://wicg.github.io/construct-stylesheets/#using-constructed-stylesheets).
     * Note, when shimming is used, any styles that are subsequently placed into
     * the shadowRoot should be placed *before* any shimmed adopted styles. This
     * will match spec behavior that gives adopted sheets precedence over styles in
     * shadowRoot.
     */
    export const adoptStyles: (renderRoot: ShadowRoot, styles: Array<CSSResultOrNative>) => void;
    export const getCompatibleStyle: (s: CSSResultOrNative) => CSSResultOrNative;
}
declare module "_100554_litReactiveController" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * An object that can host Reactive Controllers and call their lifecycle
     * callbacks.
     */
    export interface ReactiveControllerHost {
        /**
         * Adds a controller to the host, which sets up the controller's lifecycle
         * methods to be called with the host's lifecycle.
         */
        addController(controller: ReactiveController): void;
        /**
         * Removes a controller from the host.
         */
        removeController(controller: ReactiveController): void;
        /**
         * Requests a host update which is processed asynchronously. The update can
         * be waited on via the `updateComplete` property.
         */
        requestUpdate(): void;
        /**
         * Returns a Promise that resolves when the host has completed updating.
         * The Promise value is a boolean that is `true` if the element completed the
         * update without triggering another update. The Promise result is `false` if
         * a property was set inside `updated()`. If the Promise is rejected, an
         * exception was thrown during the update.
         *
         * @return A promise of a boolean that indicates if the update resolved
         *     without triggering another update.
         */
        readonly updateComplete: Promise<boolean>;
    }
    /**
     * A Reactive Controller is an object that enables sub-component code
     * organization and reuse by aggregating the state, behavior, and lifecycle
     * hooks related to a single feature.
     *
     * Controllers are added to a host component, or other object that implements
     * the `ReactiveControllerHost` interface, via the `addController()` method.
     * They can hook their host components's lifecycle by implementing one or more
     * of the lifecycle callbacks, or initiate an update of the host component by
     * calling `requestUpdate()` on the host.
     */
    export interface ReactiveController {
        /**
         * Called when the host is connected to the component tree. For custom
         * element hosts, this corresponds to the `connectedCallback()` lifecycle,
         * which is only called when the component is connected to the document.
         */
        hostConnected?(): void;
        /**
         * Called when the host is disconnected from the component tree. For custom
         * element hosts, this corresponds to the `disconnectedCallback()` lifecycle,
         * which is called the host or an ancestor component is disconnected from the
         * document.
         */
        hostDisconnected?(): void;
        /**
         * Called during the client-side host update, just before the host calls
         * its own update.
         *
         * Code in `update()` can depend on the DOM as it is not called in
         * server-side rendering.
         */
        hostUpdate?(): void;
        /**
         * Called after a host update, just before the host calls firstUpdated and
         * updated. It is not called in server-side rendering.
         *
         */
        hostUpdated?(): void;
    }
}
declare module "_100554_litReactiveElement" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * Use this module if you want to create your own base class extending
     * {@link ReactiveElement}.
     * @packageDocumentation
     */
    import { CSSResultGroup, CSSResultOrNative } from "_100554_litCssTag";
    import type { ReactiveController, ReactiveControllerHost } from "_100554_litReactiveController";
    export * from "_100554_litCssTag";
    export type { ReactiveController, ReactiveControllerHost, } from "_100554_litReactiveController";
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace ReactiveUnstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = Update;
            interface Update {
                kind: 'update';
            }
        }
    }
    /**
     * Converts property values to and from attribute values.
     */
    export interface ComplexAttributeConverter<Type = unknown, TypeHint = unknown> {
        /**
         * Called to convert an attribute value to a property
         * value.
         */
        fromAttribute?(value: string | null, type?: TypeHint): Type;
        /**
         * Called to convert a property value to an attribute
         * value.
         *
         * It returns unknown instead of string, to be compatible with
         * https://github.com/WICG/trusted-types (and similar efforts).
         */
        toAttribute?(value: Type, type?: TypeHint): unknown;
    }
    type AttributeConverter<Type = unknown, TypeHint = unknown> = ComplexAttributeConverter<Type> | ((value: string | null, type?: TypeHint) => Type);
    /**
     * Defines options for a property accessor.
     */
    export interface PropertyDeclaration<Type = unknown, TypeHint = unknown> {
        /**
         * When set to `true`, indicates the property is internal private state. The
         * property should not be set by users. When using TypeScript, this property
         * should be marked as `private` or `protected`, and it is also a common
         * practice to use a leading `_` in the name. The property is not added to
         * `observedAttributes`.
         */
        readonly state?: boolean;
        /**
         * Indicates how and whether the property becomes an observed attribute.
         * If the value is `false`, the property is not added to `observedAttributes`.
         * If true or absent, the lowercased property name is observed (e.g. `fooBar`
         * becomes `foobar`). If a string, the string value is observed (e.g
         * `attribute: 'foo-bar'`).
         */
        readonly attribute?: boolean | string;
        /**
         * Indicates the type of the property. This is used only as a hint for the
         * `converter` to determine how to convert the attribute
         * to/from a property.
         */
        readonly type?: TypeHint;
        /**
         * Indicates how to convert the attribute to/from a property. If this value
         * is a function, it is used to convert the attribute value a the property
         * value. If it's an object, it can have keys for `fromAttribute` and
         * `toAttribute`. If no `toAttribute` function is provided and
         * `reflect` is set to `true`, the property value is set directly to the
         * attribute. A default `converter` is used if none is provided; it supports
         * `Boolean`, `String`, `Number`, `Object`, and `Array`. Note,
         * when a property changes and the converter is used to update the attribute,
         * the property is never updated again as a result of the attribute changing,
         * and vice versa.
         */
        readonly converter?: AttributeConverter<Type, TypeHint>;
        /**
         * Indicates if the property should reflect to an attribute.
         * If `true`, when the property is set, the attribute is set using the
         * attribute name determined according to the rules for the `attribute`
         * property option and the value of the property converted using the rules
         * from the `converter` property option.
         */
        readonly reflect?: boolean;
        /**
         * A function that indicates if a property should be considered changed when
         * it is set. The function should take the `newValue` and `oldValue` and
         * return `true` if an update should be requested.
         */
        hasChanged?(value: Type, oldValue: Type): boolean;
        /**
         * Indicates whether an accessor will be created for this property. By
         * default, an accessor will be generated for this property that requests an
         * update when set. If this flag is `true`, no accessor will be created, and
         * it will be the user's responsibility to call
         * `this.requestUpdate(propertyName, oldValue)` to request an update when
         * the property changes.
         */
        readonly noAccessor?: boolean;
    }
    /**
     * Map of properties to PropertyDeclaration options. For each property an
     * accessor is made, and the property is processed according to the
     * PropertyDeclaration options.
     */
    export interface PropertyDeclarations {
        readonly [key: string]: PropertyDeclaration;
    }
    type PropertyDeclarationMap = Map<PropertyKey, PropertyDeclaration>;
    /**
     * A Map of property keys to values.
     *
     * Takes an optional type parameter T, which when specified as a non-any,
     * non-unknown type, will make the Map more strongly-typed, associating the map
     * keys with their corresponding value type on T.
     *
     * Use `PropertyValues<this>` when overriding ReactiveElement.update() and
     * other lifecycle methods in order to get stronger type-checking on keys
     * and values.
     */
    export type PropertyValues<T = any> = T extends object ? PropertyValueMap<T> : Map<PropertyKey, unknown>;
    /**
     * Do not use, instead prefer {@linkcode PropertyValues}.
     */
    export interface PropertyValueMap<T> extends Map<PropertyKey, unknown> {
        get<K extends keyof T>(k: K): T[K];
        set<K extends keyof T>(key: K, value: T[K]): this;
        has<K extends keyof T>(k: K): boolean;
        delete<K extends keyof T>(k: K): boolean;
    }
    export const defaultConverter: ComplexAttributeConverter;
    export interface HasChanged {
        (value: unknown, old: unknown): boolean;
    }
    /**
     * Change function that returns true if `value` is different from `oldValue`.
     * This method is used as the default for a property's `hasChanged` function.
     */
    export const notEqual: HasChanged;
    /**
     * The Closure JS Compiler doesn't currently have good support for static
     * property semantics where "this" is dynamic (e.g.
     * https://github.com/google/closure-compiler/issues/3177 and others) so we use
     * this hack to bypass any rewriting by the compiler.
     */
    const finalized = "finalized";
    /**
     * A string representing one of the supported dev mode warning categories.
     */
    export type WarningKind = 'change-in-update' | 'migration';
    export type Initializer = (element: ReactiveElement) => void;
    /**
     * Base element class which manages element properties and attributes. When
     * properties change, the `update` method is asynchronously called. This method
     * should be supplied by subclassers to render updates as desired.
     * @noInheritDoc
     */
    export abstract class ReactiveElement extends HTMLElement implements ReactiveControllerHost {
        /**
         * Read or set all the enabled warning categories for this class.
         *
         * This property is only used in development builds.
         *
         * @nocollapse
         * @category dev-mode
         */
        static enabledWarnings?: WarningKind[];
        /**
         * Enable the given warning category for this class.
         *
         * This method only exists in development builds, so it should be accessed
         * with a guard like:
         *
         * ```ts
         * // Enable for all ReactiveElement subclasses
         * ReactiveElement.enableWarning?.('migration');
         *
         * // Enable for only MyElement and subclasses
         * MyElement.enableWarning?.('migration');
         * ```
         *
         * @nocollapse
         * @category dev-mode
         */
        static enableWarning?: (warningKind: WarningKind) => void;
        /**
         * Disable the given warning category for this class.
         *
         * This method only exists in development builds, so it should be accessed
         * with a guard like:
         *
         * ```ts
         * // Disable for all ReactiveElement subclasses
         * ReactiveElement.disableWarning?.('migration');
         *
         * // Disable for only MyElement and subclasses
         * MyElement.disableWarning?.('migration');
         * ```
         *
         * @nocollapse
         * @category dev-mode
         */
        static disableWarning?: (warningKind: WarningKind) => void;
        /**
         * Adds an initializer function to the class that is called during instance
         * construction.
         *
         * This is useful for code that runs against a `ReactiveElement`
         * subclass, such as a decorator, that needs to do work for each
         * instance, such as setting up a `ReactiveController`.
         *
         * ```ts
         * const myDecorator = (target: typeof ReactiveElement, key: string) => {
         *   target.addInitializer((instance: ReactiveElement) => {
         *     // This is run during construction of the element
         *     new MyController(instance);
         *   });
         * }
         * ```
         *
         * Decorating a field will then cause each instance to run an initializer
         * that adds a controller:
         *
         * ```ts
         * class MyElement extends LitElement {
         *   @myDecorator foo;
         * }
         * ```
         *
         * Initializers are stored per-constructor. Adding an initializer to a
         * subclass does not add it to a superclass. Since initializers are run in
         * constructors, initializers will run in order of the class hierarchy,
         * starting with superclasses and progressing to the instance's class.
         *
         * @nocollapse
         */
        static addInitializer(initializer: Initializer): void;
        static _initializers?: Initializer[];
        /**
         * Maps attribute names to properties; for example `foobar` attribute to
         * `fooBar` property. Created lazily on user subclasses when finalizing the
         * class.
         * @nocollapse
         */
        private static __attributeToPropertyMap;
        /**
         * Marks class as having finished creating properties.
         */
        protected static [finalized]: boolean;
        /**
         * Memoized list of all element properties, including any superclass properties.
         * Created lazily on user subclasses when finalizing the class.
         * @nocollapse
         * @category properties
         */
        static elementProperties: PropertyDeclarationMap;
        /**
         * User-supplied object that maps property names to `PropertyDeclaration`
         * objects containing options for configuring reactive properties. When
         * a reactive property is set the element will update and render.
         *
         * By default properties are public fields, and as such, they should be
         * considered as primarily settable by element users, either via attribute or
         * the property itself.
         *
         * Generally, properties that are changed by the element should be private or
         * protected fields and should use the `state: true` option. Properties
         * marked as `state` do not reflect from the corresponding attribute
         *
         * However, sometimes element code does need to set a public property. This
         * should typically only be done in response to user interaction, and an event
         * should be fired informing the user; for example, a checkbox sets its
         * `checked` property when clicked and fires a `changed` event. Mutating
         * public properties should typically not be done for non-primitive (object or
         * array) properties. In other cases when an element needs to manage state, a
         * private property set with the `state: true` option should be used. When
         * needed, state properties can be initialized via public properties to
         * facilitate complex interactions.
         * @nocollapse
         * @category properties
         */
        static properties: PropertyDeclarations;
        /**
         * Memoized list of all element styles.
         * Created lazily on user subclasses when finalizing the class.
         * @nocollapse
         * @category styles
         */
        static elementStyles: Array<CSSResultOrNative>;
        /**
         * Array of styles to apply to the element. The styles should be defined
         * using the {@linkcode css} tag function, via constructible stylesheets, or
         * imported from native CSS module scripts.
         *
         * Note on Content Security Policy:
         *
         * Element styles are implemented with `<style>` tags when the browser doesn't
         * support adopted StyleSheets. To use such `<style>` tags with the style-src
         * CSP directive, the style-src value must either include 'unsafe-inline' or
         * `nonce-<base64-value>` with `<base64-value>` replaced be a server-generated
         * nonce.
         *
         * To provide a nonce to use on generated `<style>` elements, set
         * `window.litNonce` to a server-generated nonce in your page's HTML, before
         * loading application code:
         *
         * ```html
         * <script>
         *   // Generated and unique per request:
         *   window.litNonce = 'a1b2c3d4';
         * </script>
         * ```
         * @nocollapse
         * @category styles
         */
        static styles?: CSSResultGroup;
        /**
         * The set of properties defined by this class that caused an accessor to be
         * added during `createProperty`.
         * @nocollapse
         */
        private static __reactivePropertyKeys?;
        /**
         * Returns a list of attributes corresponding to the registered properties.
         * @nocollapse
         * @category attributes
         */
        static get observedAttributes(): string[];
        /**
         * Creates a property accessor on the element prototype if one does not exist
         * and stores a {@linkcode PropertyDeclaration} for the property with the
         * given options. The property setter calls the property's `hasChanged`
         * property option or uses a strict identity check to determine whether or not
         * to request an update.
         *
         * This method may be overridden to customize properties; however,
         * when doing so, it's important to call `super.createProperty` to ensure
         * the property is setup correctly. This method calls
         * `getPropertyDescriptor` internally to get a descriptor to install.
         * To customize what properties do when they are get or set, override
         * `getPropertyDescriptor`. To customize the options for a property,
         * implement `createProperty` like this:
         *
         * ```ts
         * static createProperty(name, options) {
         *   options = Object.assign(options, {myOption: true});
         *   super.createProperty(name, options);
         * }
         * ```
         *
         * @nocollapse
         * @category properties
         */
        static createProperty(name: PropertyKey, options?: PropertyDeclaration): void;
        /**
         * Returns a property descriptor to be defined on the given named property.
         * If no descriptor is returned, the property will not become an accessor.
         * For example,
         *
         * ```ts
         * class MyElement extends LitElement {
         *   static getPropertyDescriptor(name, key, options) {
         *     const defaultDescriptor =
         *         super.getPropertyDescriptor(name, key, options);
         *     const setter = defaultDescriptor.set;
         *     return {
         *       get: defaultDescriptor.get,
         *       set(value) {
         *         setter.call(this, value);
         *         // custom action.
         *       },
         *       configurable: true,
         *       enumerable: true
         *     }
         *   }
         * }
         * ```
         *
         * @nocollapse
         * @category properties
         */
        protected static getPropertyDescriptor(name: PropertyKey, key: string | symbol, options: PropertyDeclaration): PropertyDescriptor | undefined;
        /**
         * Returns the property options associated with the given property.
         * These options are defined with a `PropertyDeclaration` via the `properties`
         * object or the `@property` decorator and are registered in
         * `createProperty(...)`.
         *
         * Note, this method should be considered "final" and not overridden. To
         * customize the options for a given property, override
         * {@linkcode createProperty}.
         *
         * @nocollapse
         * @final
         * @category properties
         */
        static getPropertyOptions(name: PropertyKey): PropertyDeclaration<unknown, unknown>;
        /**
         * Creates property accessors for registered properties, sets up element
         * styling, and ensures any superclasses are also finalized. Returns true if
         * the element was finalized.
         * @nocollapse
         */
        protected static finalize(): boolean;
        /**
         * Options used when calling `attachShadow`. Set this property to customize
         * the options for the shadowRoot; for example, to create a closed
         * shadowRoot: `{mode: 'closed'}`.
         *
         * Note, these options are used in `createRenderRoot`. If this method
         * is customized, options should be respected if possible.
         * @nocollapse
         * @category rendering
         */
        static shadowRootOptions: ShadowRootInit;
        /**
         * Takes the styles the user supplied via the `static styles` property and
         * returns the array of styles to apply to the element.
         * Override this method to integrate into a style management system.
         *
         * Styles are deduplicated preserving the _last_ instance in the list. This
         * is a performance optimization to avoid duplicated styles that can occur
         * especially when composing via subclassing. The last item is kept to try
         * to preserve the cascade order with the assumption that it's most important
         * that last added styles override previous styles.
         *
         * @nocollapse
         * @category styles
         */
        protected static finalizeStyles(styles?: CSSResultGroup): Array<CSSResultOrNative>;
        /**
         * Node or ShadowRoot into which element DOM should be rendered. Defaults
         * to an open shadowRoot.
         * @category rendering
         */
        readonly renderRoot: HTMLElement | ShadowRoot;
        /**
         * Returns the property name for the given attribute `name`.
         * @nocollapse
         */
        private static __attributeNameForProperty;
        private __instanceProperties?;
        private __updatePromise;
        /**
         * True if there is a pending update as a result of calling `requestUpdate()`.
         * Should only be read.
         * @category updates
         */
        isUpdatePending: boolean;
        /**
         * Is set to `true` after the first update. The element code cannot assume
         * that `renderRoot` exists before the element `hasUpdated`.
         * @category updates
         */
        hasUpdated: boolean;
        /**
         * Map with keys for any properties that have changed since the last
         * update cycle with previous values.
         *
         * @internal
         */
        _$changedProperties: PropertyValues;
        /**
         * Map with keys of properties that should be reflected when updated.
         */
        private __reflectingProperties?;
        /**
         * Name of currently reflecting property
         */
        private __reflectingProperty;
        /**
         * Set of controllers.
         */
        private __controllers?;
        constructor();
        /**
         * Internal only override point for customizing work done when elements
         * are constructed.
         *
         * @internal
         */
        _initialize(): void;
        /**
         * Registers a `ReactiveController` to participate in the element's reactive
         * update cycle. The element automatically calls into any registered
         * controllers during its lifecycle callbacks.
         *
         * If the element is connected when `addController()` is called, the
         * controller's `hostConnected()` callback will be immediately called.
         * @category controllers
         */
        addController(controller: ReactiveController): void;
        /**
         * Removes a `ReactiveController` from the element.
         * @category controllers
         */
        removeController(controller: ReactiveController): void;
        /**
         * Fixes any properties set on the instance before upgrade time.
         * Otherwise these would shadow the accessor and break these properties.
         * The properties are stored in a Map which is played back after the
         * constructor runs. Note, on very old versions of Safari (<=9) or Chrome
         * (<=54), properties created for native platform properties like (`id` or
         * `name`) may not have default values set in the element constructor. On
         * these browsers native properties appear on instances and therefore their
         * default value will overwrite any element default (e.g. if the element sets
         * this.id = 'id' in the constructor, the 'id' will become '' since this is
         * the native platform default).
         */
        private __saveInstanceProperties;
        /**
         * Returns the node into which the element should render and by default
         * creates and returns an open shadowRoot. Implement to customize where the
         * element's DOM is rendered. For example, to render into the element's
         * childNodes, return `this`.
         *
         * @return Returns a node into which to render.
         * @category rendering
         */
        protected createRenderRoot(): Element | ShadowRoot;
        /**
         * On first connection, creates the element's renderRoot, sets up
         * element styling, and enables updating.
         * @category lifecycle
         */
        connectedCallback(): void;
        /**
         * Note, this method should be considered final and not overridden. It is
         * overridden on the element instance with a function that triggers the first
         * update.
         * @category updates
         */
        protected enableUpdating(_requestedUpdate: boolean): void;
        /**
         * Allows for `super.disconnectedCallback()` in extensions while
         * reserving the possibility of making non-breaking feature additions
         * when disconnecting at some point in the future.
         * @category lifecycle
         */
        disconnectedCallback(): void;
        /**
         * Synchronizes property values when attributes change.
         *
         * Specifically, when an attribute is set, the corresponding property is set.
         * You should rarely need to implement this callback. If this method is
         * overridden, `super.attributeChangedCallback(name, _old, value)` must be
         * called.
         *
         * See [using the lifecycle callbacks](https://developer.mozilla.org/en-US/docs/Web/Web_Components/Using_custom_elements#using_the_lifecycle_callbacks)
         * on MDN for more information about the `attributeChangedCallback`.
         * @category attributes
         */
        attributeChangedCallback(name: string, _old: string | null, value: string | null): void;
        private __propertyToAttribute;
        /** @internal */
        _$attributeToProperty(name: string, value: string | null): void;
        /**
         * Requests an update which is processed asynchronously. This should be called
         * when an element should update based on some state not triggered by setting
         * a reactive property. In this case, pass no arguments. It should also be
         * called when manually implementing a property setter. In this case, pass the
         * property `name` and `oldValue` to ensure that any configured property
         * options are honored.
         *
         * @param name name of requesting property
         * @param oldValue old value of requesting property
         * @param options property options to use instead of the previously
         *     configured options
         * @category updates
         */
        requestUpdate(name?: PropertyKey, oldValue?: unknown, options?: PropertyDeclaration): void;
        /**
         * Sets up the element to asynchronously update.
         */
        private __enqueueUpdate;
        /**
         * Schedules an element update. You can override this method to change the
         * timing of updates by returning a Promise. The update will await the
         * returned Promise, and you should resolve the Promise to allow the update
         * to proceed. If this method is overridden, `super.scheduleUpdate()`
         * must be called.
         *
         * For instance, to schedule updates to occur just before the next frame:
         *
         * ```ts
         * override protected async scheduleUpdate(): Promise<unknown> {
         *   await new Promise((resolve) => requestAnimationFrame(() => resolve()));
         *   super.scheduleUpdate();
         * }
         * ```
         * @category updates
         */
        protected scheduleUpdate(): void | Promise<unknown>;
        /**
         * Performs an element update. Note, if an exception is thrown during the
         * update, `firstUpdated` and `updated` will not be called.
         *
         * Call `performUpdate()` to immediately process a pending update. This should
         * generally not be needed, but it can be done in rare cases when you need to
         * update synchronously.
         *
         * Note: To ensure `performUpdate()` synchronously completes a pending update,
         * it should not be overridden. In LitElement 2.x it was suggested to override
         * `performUpdate()` to also customizing update scheduling. Instead, you should now
         * override `scheduleUpdate()`. For backwards compatibility with LitElement 2.x,
         * scheduling updates via `performUpdate()` continues to work, but will make
         * also calling `performUpdate()` to synchronously process updates difficult.
         *
         * @category updates
         */
        protected performUpdate(): void | Promise<unknown>;
        /**
         * Invoked before `update()` to compute values needed during the update.
         *
         * Implement `willUpdate` to compute property values that depend on other
         * properties and are used in the rest of the update process.
         *
         * ```ts
         * willUpdate(changedProperties) {
         *   // only need to check changed properties for an expensive computation.
         *   if (changedProperties.has('firstName') || changedProperties.has('lastName')) {
         *     this.sha = computeSHA(`${this.firstName} ${this.lastName}`);
         *   }
         * }
         *
         * render() {
         *   return html`SHA: ${this.sha}`;
         * }
         * ```
         *
         * @category updates
         */
        protected willUpdate(_changedProperties: PropertyValues): void;
        _$didUpdate(changedProperties: PropertyValues): void;
        private __markUpdated;
        /**
         * Returns a Promise that resolves when the element has completed updating.
         * The Promise value is a boolean that is `true` if the element completed the
         * update without triggering another update. The Promise result is `false` if
         * a property was set inside `updated()`. If the Promise is rejected, an
         * exception was thrown during the update.
         *
         * To await additional asynchronous work, override the `getUpdateComplete`
         * method. For example, it is sometimes useful to await a rendered element
         * before fulfilling this Promise. To do this, first await
         * `super.getUpdateComplete()`, then any subsequent state.
         *
         * @return A promise of a boolean that resolves to true if the update completed
         *     without triggering another update.
         * @category updates
         */
        get updateComplete(): Promise<boolean>;
        /**
         * Override point for the `updateComplete` promise.
         *
         * It is not safe to override the `updateComplete` getter directly due to a
         * limitation in TypeScript which means it is not possible to call a
         * superclass getter (e.g. `super.updateComplete.then(...)`) when the target
         * language is ES5 (https://github.com/microsoft/TypeScript/issues/338).
         * This method should be overridden instead. For example:
         *
         * ```ts
         * class MyElement extends LitElement {
         *   override async getUpdateComplete() {
         *     const result = await super.getUpdateComplete();
         *     await this._myChild.updateComplete;
         *     return result;
         *   }
         * }
         * ```
         *
         * @return A promise of a boolean that resolves to true if the update completed
         *     without triggering another update.
         * @category updates
         */
        protected getUpdateComplete(): Promise<boolean>;
        /**
         * Controls whether or not `update()` should be called when the element requests
         * an update. By default, this method always returns `true`, but this can be
         * customized to control when to update.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected shouldUpdate(_changedProperties: PropertyValues): boolean;
        /**
         * Updates the element. This method reflects property values to attributes.
         * It can be overridden to render and keep updated element DOM.
         * Setting properties inside this method will *not* trigger
         * another update.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected update(_changedProperties: PropertyValues): void;
        /**
         * Invoked whenever the element is updated. Implement to perform
         * post-updating tasks via DOM APIs, for example, focusing an element.
         *
         * Setting properties inside this method will trigger the element to update
         * again after this update cycle completes.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected updated(_changedProperties: PropertyValues): void;
        /**
         * Invoked when the element is first updated. Implement to perform one time
         * work on the element after update.
         *
         * ```ts
         * firstUpdated() {
         *   this.renderRoot.getElementById('my-text-area').focus();
         * }
         * ```
         *
         * Setting properties inside this method will trigger the element to update
         * again after this update cycle completes.
         *
         * @param _changedProperties Map of changed properties with old values
         * @category updates
         */
        protected firstUpdated(_changedProperties: PropertyValues): void;
    }
}
declare module "_100554_litHtml" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
    export const PartType: {
        readonly ATTRIBUTE: 1;
        readonly CHILD: 2;
        readonly PROPERTY: 3;
        readonly BOOLEAN_ATTRIBUTE: 4;
        readonly EVENT: 5;
        readonly ELEMENT: 6;
    };
    export type PartType = (typeof PartType)[keyof typeof PartType];
    export interface ChildPartInfo {
        readonly type: typeof PartType.CHILD;
    }
    export interface AttributePartInfo {
        readonly type: typeof PartType.ATTRIBUTE | typeof PartType.PROPERTY | typeof PartType.BOOLEAN_ATTRIBUTE | typeof PartType.EVENT;
        readonly strings?: ReadonlyArray<string>;
        readonly name: string;
        readonly tagName: string;
    }
    export interface ElementPartInfo {
        readonly type: typeof PartType.ELEMENT;
    }
    export type PartInfo = ChildPartInfo | AttributePartInfo | ElementPartInfo;
    export type DirectiveParameters<C extends Directive> = Parameters<C['render']>;
    export interface DirectiveClass {
        new (part: PartInfo): Directive;
    }
    export interface DirectiveResult<C extends DirectiveClass = DirectiveClass> {
        /**
         * This property needs to remain unminified.
         * @internal */
        ['_$litDirective$']: C;
        /** @internal */
        values: DirectiveParameters<InstanceType<C>>;
    }
    export abstract class Directive implements Disconnectable {
        __part: Part;
        __attributeIndex: number | undefined;
        __directive?: Directive;
        _$parent: Disconnectable;
        _$disconnectableChildren?: Set<Disconnectable>;
        ['_$notifyDirectiveConnectionChanged']?(isConnected: boolean): void;
        constructor(_partInfo: PartInfo);
        get _$isConnected(): boolean;
        /** @internal */
        _$initialize(part: Part, parent: Disconnectable, attributeIndex: number | undefined): void;
        /** @internal */
        _$resolve(part: Part, props: Array<unknown>): unknown;
        abstract render(...props: Array<unknown>): unknown;
        update(_part: Part, props: Array<unknown>): unknown;
    }
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace LitUnstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = TemplatePrep | TemplateInstantiated | TemplateInstantiatedAndUpdated | TemplateUpdating | BeginRender | EndRender | CommitPartEntry | SetPartValue;
            interface TemplatePrep {
                kind: 'template prep';
                template: Template;
                strings: TemplateStringsArray;
                clonableTemplate: HTMLTemplateElement;
                parts: TemplatePart[];
            }
            interface BeginRender {
                kind: 'begin render';
                id: number;
                value: unknown;
                container: HTMLElement | DocumentFragment;
                options: RenderOptions | undefined;
                part: ChildPart | undefined;
            }
            interface EndRender {
                kind: 'end render';
                id: number;
                value: unknown;
                container: HTMLElement | DocumentFragment;
                options: RenderOptions | undefined;
                part: ChildPart;
            }
            interface TemplateInstantiated {
                kind: 'template instantiated';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                fragment: Node;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface TemplateInstantiatedAndUpdated {
                kind: 'template instantiated and updated';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                fragment: Node;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface TemplateUpdating {
                kind: 'template updating';
                template: Template | CompiledTemplate;
                instance: TemplateInstance;
                options: RenderOptions | undefined;
                parts: Array<Part | undefined>;
                values: unknown[];
            }
            interface SetPartValue {
                kind: 'set part';
                part: Part;
                value: unknown;
                valueIndex: number;
                values: unknown[];
                templateInstance: TemplateInstance;
            }
            type CommitPartEntry = CommitNothingToChildEntry | CommitText | CommitNode | CommitAttribute | CommitProperty | CommitBooleanAttribute | CommitEventListener | CommitToElementBinding;
            interface CommitNothingToChildEntry {
                kind: 'commit nothing to child';
                start: ChildNode;
                end: ChildNode | null;
                parent: Disconnectable | undefined;
                options: RenderOptions | undefined;
            }
            interface CommitText {
                kind: 'commit text';
                node: Text;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitNode {
                kind: 'commit node';
                start: Node;
                parent: Disconnectable | undefined;
                value: Node;
                options: RenderOptions | undefined;
            }
            interface CommitAttribute {
                kind: 'commit attribute';
                element: Element;
                name: string;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitProperty {
                kind: 'commit property';
                element: Element;
                name: string;
                value: unknown;
                options: RenderOptions | undefined;
            }
            interface CommitBooleanAttribute {
                kind: 'commit boolean attribute';
                element: Element;
                name: string;
                value: boolean;
                options: RenderOptions | undefined;
            }
            interface CommitEventListener {
                kind: 'commit event listener';
                element: Element;
                name: string;
                value: unknown;
                oldListener: unknown;
                options: RenderOptions | undefined;
                removeListener: boolean;
                addListener: boolean;
            }
            interface CommitToElementBinding {
                kind: 'commit to element binding';
                element: Element;
                value: unknown;
                options: RenderOptions | undefined;
            }
        }
    }
    /**
     * Used to sanitize any value before it is written into the DOM. This can be
     * used to implement a security policy of allowed and disallowed values in
     * order to prevent XSS attacks.
     *
     * One way of using this callback would be to check attributes and properties
     * against a list of high risk fields, and require that values written to such
     * fields be instances of a class which is safe by construction. Closure's Safe
     * HTML Types is one implementation of this technique (
     * https://github.com/google/safe-html-types/blob/master/doc/safehtml-types.md).
     * The TrustedTypes polyfill in API-only mode could also be used as a basis
     * for this technique (https://github.com/WICG/trusted-types).
     *
     * @param node The HTML node (usually either a #text node or an Element) that
     *     is being written to. Note that this is just an exemplar node, the write
     *     may take place against another instance of the same class of node.
     * @param name The name of an attribute or property (for example, 'href').
     * @param type Indicates whether the write that's about to be performed will
     *     be to a property or a node.
     * @return A function that will sanitize this class of writes.
     */
    export type SanitizerFactory = (node: Node, name: string, type: 'property' | 'attribute') => ValueSanitizer;
    /**
     * A function which can sanitize values that will be written to a specific kind
     * of DOM sink.
     *
     * See SanitizerFactory.
     *
     * @param value The value to sanitize. Will be the actual value passed into
     *     the lit-html template literal, so this could be of any type.
     * @return The value to write to the DOM. Usually the same as the input value,
     *     unless sanitization is needed.
     */
    export type ValueSanitizer = (value: unknown) => unknown;
    /** TemplateResult types */
    const HTML_RESULT = 1;
    const SVG_RESULT = 2;
    type ResultType = typeof HTML_RESULT | typeof SVG_RESULT;
    const ATTRIBUTE_PART = 1;
    const CHILD_PART = 2;
    const PROPERTY_PART = 3;
    const BOOLEAN_ATTRIBUTE_PART = 4;
    const EVENT_PART = 5;
    const ELEMENT_PART = 6;
    const COMMENT_PART = 7;
    /**
     * The return type of the template tag functions, {@linkcode html} and
     * {@linkcode svg}.
     *
     * A `TemplateResult` object holds all the information about a template
     * expression required to render it: the template strings, expression values,
     * and type of template (html or svg).
     *
     * `TemplateResult` objects do not create any DOM on their own. To create or
     * update DOM you need to render the `TemplateResult`. See
     * [Rendering](https://lit.dev/docs/components/rendering) for more information.
     *
     */
    export type TemplateResult<T extends ResultType = ResultType> = {
        ['_$litType$']: T;
        strings: TemplateStringsArray;
        values: unknown[];
    };
    export type HTMLTemplateResult = TemplateResult<typeof HTML_RESULT>;
    export type SVGTemplateResult = TemplateResult<typeof SVG_RESULT>;
    export interface CompiledTemplateResult {
        ['_$litType$']: CompiledTemplate;
        values: unknown[];
    }
    export interface CompiledTemplate extends Omit<Template, 'el'> {
        el?: HTMLTemplateElement;
        h: any;
    }
    /**
     * Interprets a template literal as an HTML template that can efficiently
     * render to and update a container.
     *
     * ```ts
     * const header = (title: string) => html`<h1>${title}</h1>`;
     * ```
     *
     * The `html` tag returns a description of the DOM to render as a value. It is
     * lazy, meaning no work is done until the template is rendered. When rendering,
     * if a template comes from the same expression as a previously rendered result,
     * it's efficiently updated instead of replaced.
     */
    export const html: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<1>;
    /**
     * Interprets a template literal as an SVG fragment that can efficiently
     * render to and update a container.
     *
     * ```ts
     * const rect = svg`<rect width="10" height="10"></rect>`;
     *
     * const myImage = html`
     *   <svg viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg">
     *     ${rect}
     *   </svg>`;
     * ```
     *
     * The `svg` *tag function* should only be used for SVG fragments, or elements
     * that would be contained **inside** an `<svg>` HTML element. A common error is
     * placing an `<svg>` *element* in a template tagged with the `svg` tag
     * function. The `<svg>` element is an HTML element and should be used within a
     * template tagged with the {@linkcode html} tag function.
     *
     * In LitElement usage, it's invalid to return an SVG fragment from the
     * `render()` method, as the SVG fragment will be contained within the element's
     * shadow root and thus cannot be used within an `<svg>` HTML element.
     */
    export const svg: (strings: TemplateStringsArray, ...values: unknown[]) => TemplateResult<2>;
    /**
     * A sentinel value that signals that a value was handled by a directive and
     * should not be written to the DOM.
     */
    export const noChange: unique symbol;
    /**
     * A sentinel value that signals a ChildPart to fully clear its content.
     *
     * ```ts
     * const button = html`${
     *  user.isAdmin
     *    ? html`<button>DELETE</button>`
     *    : nothing
     * }`;
     * ```
     *
     * Prefer using `nothing` over other falsy values as it provides a consistent
     * behavior between various expression binding contexts.
     *
     * In child expressions, `undefined`, `null`, `''`, and `nothing` all behave the
     * same and render no nodes. In attribute expressions, `nothing` _removes_ the
     * attribute, while `undefined` and `null` will render an empty string. In
     * property expressions `nothing` becomes `undefined`.
     */
    export const nothing: unique symbol;
    /**
     * Object specifying options for controlling lit-html rendering. Note that
     * while `render` may be called multiple times on the same `container` (and
     * `renderBefore` reference node) to efficiently update the rendered content,
     * only the options passed in during the first render are respected during
     * the lifetime of renders to that unique `container` + `renderBefore`
     * combination.
     */
    export interface RenderOptions {
        /**
         * An object to use as the `this` value for event listeners. It's often
         * useful to set this to the host component rendering a template.
         */
        host?: object;
        /**
         * A DOM node before which to render content in the container.
         */
        renderBefore?: ChildNode | null;
        /**
         * Node used for cloning the template (`importNode` will be called on this
         * node). This controls the `ownerDocument` of the rendered DOM, along with
         * any inherited context. Defaults to the global `document`.
         */
        creationScope?: {
            importNode(node: Node, deep?: boolean): Node;
        };
        /**
         * The initial connected state for the top-level part being rendered. If no
         * `isConnected` option is set, `AsyncDirective`s will be connected by
         * default. Set to `false` if the initial render occurs in a disconnected tree
         * and `AsyncDirective`s should see `isConnected === false` for their initial
         * render. The `part.setConnected()` method must be used subsequent to initial
         * render to change the connected state of the part.
         */
        isConnected?: boolean;
    }
    export interface DirectiveParent {
        _$parent?: DirectiveParent;
        _$isConnected: boolean;
        __directive?: Directive;
        __directives?: Array<Directive | undefined>;
    }
    /**
     * Returns an HTML string for the given TemplateStringsArray and result type
     * (HTML or SVG), along with the case-sensitive bound attribute names in
     * template order. The HTML contains comment markers denoting the `ChildPart`s
     * and suffixes on bound attributes denoting the `AttributeParts`.
     *
     * @param strings template strings array
     * @param type HTML or SVG
     * @return Array containing `[html, attrNames]` (array returned for terseness,
     *     to avoid object fields since this code is shared with non-minified SSR
     *     code)
     */
    export const unsafeHTML: (strings: string) => any;
    /** @internal */
    export type { Template };
    class Template {
        /** @internal */
        el: HTMLTemplateElement;
        parts: Array<TemplatePart>;
        constructor({ strings, ['_$litType$']: type }: TemplateResult, options?: RenderOptions);
        /** @nocollapse */
        static createElement(html: any, _options?: RenderOptions): HTMLTemplateElement;
    }
    export interface Disconnectable {
        _$parent?: Disconnectable;
        _$disconnectableChildren?: Set<Disconnectable>;
        _$isConnected: boolean;
    }
    function resolveDirective(part: ChildPart | AttributePart | ElementPart, value: unknown, parent?: DirectiveParent, attributeIndex?: number): unknown;
    export type { TemplateInstance };
    /**
     * An updateable instance of a Template. Holds references to the Parts used to
     * update the template instance.
     */
    class TemplateInstance implements Disconnectable {
        _$template: Template;
        _$parts: Array<Part | undefined>;
        /** @internal */
        _$parent: ChildPart;
        /** @internal */
        _$disconnectableChildren?: Set<Disconnectable>;
        constructor(template: Template, parent: ChildPart);
        get parentNode(): Node;
        get _$isConnected(): boolean;
        _clone(options: RenderOptions | undefined): Node;
        _update(values: Array<unknown>): void;
    }
    type AttributeTemplatePart = {
        readonly type: typeof ATTRIBUTE_PART;
        readonly index: number;
        readonly name: string;
        readonly ctor: typeof AttributePart;
        readonly strings: ReadonlyArray<string>;
    };
    type NodeTemplatePart = {
        readonly type: typeof CHILD_PART;
        readonly index: number;
    };
    type ElementTemplatePart = {
        readonly type: typeof ELEMENT_PART;
        readonly index: number;
    };
    type CommentTemplatePart = {
        readonly type: typeof COMMENT_PART;
        readonly index: number;
    };
    /**
     * A TemplatePart represents a dynamic part in a template, before the template
     * is instantiated. When a template is instantiated Parts are created from
     * TemplateParts.
     */
    type TemplatePart = NodeTemplatePart | AttributeTemplatePart | ElementTemplatePart | CommentTemplatePart;
    export type Part = ChildPart | AttributePart | PropertyPart | BooleanAttributePart | ElementPart | EventPart;
    export type { ChildPart };
    class ChildPart implements Disconnectable {
        readonly type = 2;
        readonly options: RenderOptions | undefined;
        _$committedValue: unknown;
        /** @internal */
        __directive?: Directive;
        /** @internal */
        _$startNode: ChildNode;
        /** @internal */
        _$endNode: ChildNode | null;
        private _textSanitizer;
        /** @internal */
        _$parent: Disconnectable | undefined;
        /**
         * Connection state for RootParts only (i.e. ChildPart without _$parent
         * returned from top-level `render`). This field is unsed otherwise. The
         * intention would clearer if we made `RootPart` a subclass of `ChildPart`
         * with this field (and a different _$isConnected getter), but the subclass
         * caused a perf regression, possibly due to making call sites polymorphic.
         * @internal
         */
        __isConnected: boolean;
        get _$isConnected(): boolean;
        /** @internal */
        _$disconnectableChildren?: Set<Disconnectable>;
        /** @internal */
        _$notifyConnectionChanged?(isConnected: boolean, removeFromParent?: boolean, from?: number): void;
        /** @internal */
        _$reparentDisconnectables?(parent: Disconnectable): void;
        constructor(startNode: ChildNode, endNode: ChildNode | null, parent: TemplateInstance | ChildPart | undefined, options: RenderOptions | undefined);
        /**
         * The parent node into which the part renders its content.
         *
         * A ChildPart's content consists of a range of adjacent child nodes of
         * `.parentNode`, possibly bordered by 'marker nodes' (`.startNode` and
         * `.endNode`).
         *
         * - If both `.startNode` and `.endNode` are non-null, then the part's content
         * consists of all siblings between `.startNode` and `.endNode`, exclusively.
         *
         * - If `.startNode` is non-null but `.endNode` is null, then the part's
         * content consists of all siblings following `.startNode`, up to and
         * including the last child of `.parentNode`. If `.endNode` is non-null, then
         * `.startNode` will always be non-null.
         *
         * - If both `.endNode` and `.startNode` are null, then the part's content
         * consists of all child nodes of `.parentNode`.
         */
        get parentNode(): Node;
        /**
         * The part's leading marker node, if any. See `.parentNode` for more
         * information.
         */
        get startNode(): Node | null;
        /**
         * The part's trailing marker node, if any. See `.parentNode` for more
         * information.
         */
        get endNode(): Node | null;
        _$setValue(value: unknown, directiveParent?: DirectiveParent): void;
        private _insert;
        private _commitNode;
        private _commitText;
        private _commitTemplateResult;
        /** @internal */
        _$getTemplate(result: TemplateResult): Template;
        private _commitIterable;
        /**
         * Removes the nodes contained within this Part from the DOM.
         *
         * @param start Start node to clear from, for clearing a subset of the part's
         *     DOM (used when truncating iterables)
         * @param from  When `start` is specified, the index within the iterable from
         *     which ChildParts are being removed, used for disconnecting directives in
         *     those Parts.
         *
         * @internal
         */
        _$clear(start?: ChildNode | null, from?: number): void;
        /**
         * Implementation of RootPart's `isConnected`. Note that this metod
         * should only be called on `RootPart`s (the `ChildPart` returned from a
         * top-level `render()` call). It has no effect on non-root ChildParts.
         * @param isConnected Whether to set
         * @internal
         */
        setConnected(isConnected: boolean): void;
    }
    /**
     * A top-level `ChildPart` returned from `render` that manages the connected
     * state of `AsyncDirective`s created throughout the tree below it.
     */
    export interface RootPart extends ChildPart {
        /**
         * Sets the connection state for `AsyncDirective`s contained within this root
         * ChildPart.
         *
         * lit-html does not automatically monitor the connectedness of DOM rendered;
         * as such, it is the responsibility of the caller to `render` to ensure that
         * `part.setConnected(false)` is called before the part object is potentially
         * discarded, to ensure that `AsyncDirective`s have a chance to dispose of
         * any resources being held. If a `RootPart` that was previously
         * disconnected is subsequently re-connected (and its `AsyncDirective`s should
         * re-connect), `setConnected(true)` should be called.
         *
         * @param isConnected Whether directives within this tree should be connected
         * or not
         */
        setConnected(isConnected: boolean): void;
    }
    export type { AttributePart };
    class AttributePart implements Disconnectable {
        readonly type: typeof ATTRIBUTE_PART | typeof PROPERTY_PART | typeof BOOLEAN_ATTRIBUTE_PART | typeof EVENT_PART;
        readonly element: HTMLElement;
        readonly name: string;
        readonly options: RenderOptions | undefined;
        /**
         * If this attribute part represents an interpolation, this contains the
         * static strings of the interpolation. For single-value, complete bindings,
         * this is undefined.
         */
        readonly strings?: ReadonlyArray<string>;
        /** @internal */
        _$committedValue: unknown | Array<unknown>;
        /** @internal */
        __directives?: Array<Directive | undefined>;
        /** @internal */
        _$parent: Disconnectable;
        /** @internal */
        _$disconnectableChildren?: Set<Disconnectable>;
        protected _sanitizer: ValueSanitizer | undefined;
        get tagName(): string;
        get _$isConnected(): boolean;
        constructor(element: HTMLElement, name: string, strings: ReadonlyArray<string>, parent: Disconnectable, options: RenderOptions | undefined);
        /**
         * Sets the value of this part by resolving the value from possibly multiple
         * values and static strings and committing it to the DOM.
         * If this part is single-valued, `this._strings` will be undefined, and the
         * method will be called with a single value argument. If this part is
         * multi-value, `this._strings` will be defined, and the method is called
         * with the value array of the part's owning TemplateInstance, and an offset
         * into the value array from which the values should be read.
         * This method is overloaded this way to eliminate short-lived array slices
         * of the template instance values, and allow a fast-path for single-valued
         * parts.
         *
         * @param value The part value, or an array of values for multi-valued parts
         * @param valueIndex the index to start reading values from. `undefined` for
         *   single-valued parts
         * @param noCommit causes the part to not commit its value to the DOM. Used
         *   in hydration to prime attribute parts with their first-rendered value,
         *   but not set the attribute, and in SSR to no-op the DOM operation and
         *   capture the value for serialization.
         *
         * @internal
         */
        _$setValue(value: unknown | Array<unknown>, directiveParent?: DirectiveParent, valueIndex?: number, noCommit?: boolean): void;
        /** @internal */
        _commitValue(value: unknown): void;
    }
    export type { PropertyPart };
    class PropertyPart extends AttributePart {
        readonly type = 3;
        /** @internal */
        _commitValue(value: unknown): void;
    }
    export type { BooleanAttributePart };
    class BooleanAttributePart extends AttributePart {
        readonly type = 4;
        /** @internal */
        _commitValue(value: unknown): void;
    }
    /**
     * An AttributePart that manages an event listener via add/removeEventListener.
     *
     * This part works by adding itself as the event listener on an element, then
     * delegating to the value passed to it. This reduces the number of calls to
     * add/removeEventListener if the listener changes frequently, such as when an
     * inline function is used as a listener.
     *
     * Because event options are passed when adding listeners, we must take case
     * to add and remove the part as a listener when the event options change.
     */
    export type { EventPart };
    class EventPart extends AttributePart {
        readonly type = 5;
        constructor(element: HTMLElement, name: string, strings: ReadonlyArray<string>, parent: Disconnectable, options: RenderOptions | undefined);
        /** @internal */
        _$setValue(newListener: unknown, directiveParent?: DirectiveParent): void;
        handleEvent(event: Event): void;
    }
    export type { ElementPart };
    class ElementPart implements Disconnectable {
        element: Element;
        readonly type = 6;
        /** @internal */
        __directive?: Directive;
        _$committedValue: undefined;
        /** @internal */
        _$parent: Disconnectable;
        /** @internal */
        _$disconnectableChildren?: Set<Disconnectable>;
        options: RenderOptions | undefined;
        constructor(element: Element, parent: Disconnectable, options: RenderOptions | undefined);
        get _$isConnected(): boolean;
        _$setValue(value: unknown): void;
    }
    /**
     * END USERS SHOULD NOT RELY ON THIS OBJECT.
     *
     * Private exports for use by other Lit packages, not intended for use by
     * external users.
     *
     * We currently do not make a mangled rollup build of the lit-ssr code. In order
     * to keep a number of (otherwise private) top-level exports  mangled in the
     * client side code, we export a _$LH object containing those members (or
     * helper methods for accessing private fields of those members), and then
     * re-export them for use in lit-ssr. This keeps lit-ssr agnostic to whether the
     * client-side code is being used in `dev` mode or `prod` mode.
     *
     * This has a unique name, to disambiguate it from private exports in
     * lit-element, which re-exports all of lit-html.
     *
     * @private
     */
    export const _$LH: {
        _boundAttributeSuffix: string;
        _marker: string;
        _markerMatch: string;
        _HTML_RESULT: number;
        _getTemplateHtml: (strings: TemplateStringsArray, type: ResultType) => [any, Array<string | undefined>];
        _TemplateInstance: typeof TemplateInstance;
        _isIterable: (value: unknown) => value is Iterable<unknown>;
        _resolveDirective: typeof resolveDirective;
        _ChildPart: typeof ChildPart;
        _AttributePart: typeof AttributePart;
        _BooleanAttributePart: typeof BooleanAttributePart;
        _EventPart: typeof EventPart;
        _PropertyPart: typeof PropertyPart;
        _ElementPart: typeof ElementPart;
    };
    /**
     * Renders a value, usually a lit-html TemplateResult, to the container.
     *
     * This example renders the text "Hello, Zoe!" inside a paragraph tag, appending
     * it to the container `document.body`.
     *
     * ```js
     * import {html, render} from 'lit';
     *
     * const name = "Zoe";
     * render(html`<p>Hello, ${name}!</p>`, document.body);
     * ```
     *
     * @param value Any [renderable
     *   value](https://lit.dev/docs/templates/expressions/#child-expressions),
     *   typically a {@linkcode TemplateResult} created by evaluating a template tag
     *   like {@linkcode html} or {@linkcode svg}.
     * @param container A DOM container to render to. The first render will append
     *   the rendered value to the container, and subsequent renders will
     *   efficiently update the rendered value if the same result type was
     *   previously rendered there.
     * @param options See {@linkcode RenderOptions} for options documentation.
     * @see
     * {@link https://lit.dev/docs/libraries/standalone-templates/#rendering-lit-html-templates| Rendering Lit HTML Templates}
     */
    export const render: {
        (value: unknown, container: HTMLElement | DocumentFragment, options?: RenderOptions): RootPart;
        setSanitizer: (newSanitizer: SanitizerFactory) => void;
        createSanitizer: SanitizerFactory;
        _testOnlyClearSanitizerFactoryDoNotCallOrElse: () => void;
    };
}
declare module "_100554_litDirectives" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Disconnectable, Part } from "_100554_litHtml";
    export { AttributePart, BooleanAttributePart, ChildPart, ElementPart, EventPart, Part, PropertyPart, } from "_100554_litHtml";
    export interface DirectiveClass {
        new (part: PartInfo): Directive;
    }
    /**
     * This utility type extracts the signature of a directive class's render()
     * method so we can use it for the type of the generated directive function.
     */
    export type DirectiveParameters<C extends Directive> = Parameters<C['render']>;
    /**
     * A generated directive function doesn't evaluate the directive, but just
     * returns a DirectiveResult object that captures the arguments.
     */
    export interface DirectiveResult<C extends DirectiveClass = DirectiveClass> {
        /**
         * This property needs to remain unminified.
         * @internal */
        ['_$litDirective$']: C;
        /** @internal */
        values: DirectiveParameters<InstanceType<C>>;
    }
    export const PartType: {
        readonly ATTRIBUTE: 1;
        readonly CHILD: 2;
        readonly PROPERTY: 3;
        readonly BOOLEAN_ATTRIBUTE: 4;
        readonly EVENT: 5;
        readonly ELEMENT: 6;
    };
    export type PartType = (typeof PartType)[keyof typeof PartType];
    export interface ChildPartInfo {
        readonly type: typeof PartType.CHILD;
    }
    export interface AttributePartInfo {
        readonly type: typeof PartType.ATTRIBUTE | typeof PartType.PROPERTY | typeof PartType.BOOLEAN_ATTRIBUTE | typeof PartType.EVENT;
        readonly strings?: ReadonlyArray<string>;
        readonly name: string;
        readonly tagName: string;
    }
    export interface ElementPartInfo {
        readonly type: typeof PartType.ELEMENT;
    }
    /**
     * Information about the part a directive is bound to.
     *
     * This is useful for checking that a directive is attached to a valid part,
     * such as with directive that can only be used on attribute bindings.
     */
    export type PartInfo = ChildPartInfo | AttributePartInfo | ElementPartInfo;
    /**
     * Creates a user-facing directive function from a Directive class. This
     * function has the same parameters as the directive's render() method.
     */
    export const directive: <C extends DirectiveClass>(c: C) => (...values: DirectiveParameters<InstanceType<C>>) => DirectiveResult<C>;
    /**
     * Base class for creating custom directives. Users should extend this class,
     * implement `render` and/or `update`, and then pass their subclass to
     * `directive`.
     */
    export abstract class Directive implements Disconnectable {
        __part: Part;
        __attributeIndex: number | undefined;
        __directive?: Directive;
        _$parent: Disconnectable;
        _$disconnectableChildren?: Set<Disconnectable>;
        ['_$notifyDirectiveConnectionChanged']?(isConnected: boolean): void;
        constructor(_partInfo: PartInfo);
        get _$isConnected(): boolean;
        /** @internal */
        _$initialize(part: Part, parent: Disconnectable, attributeIndex: number | undefined): void;
        /** @internal */
        _$resolve(part: Part, props: Array<unknown>): unknown;
        abstract render(...props: Array<unknown>): unknown;
        update(_part: Part, props: Array<unknown>): unknown;
    }
}
declare module "_100554_litClassMap" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart, noChange } from "_100554_litHtml";
    import { Directive, DirectiveParameters, PartInfo } from "_100554_litDirectives";
    /**
     * A key-value set of class names to truthy values.
     */
    export interface ClassInfo {
        readonly [name: string]: string | boolean | number;
    }
    class ClassMapDirective extends Directive {
        /**
         * Stores the ClassInfo object applied to a given AttributePart.
         * Used to unset existing values when a new ClassInfo object is applied.
         */
        private _previousClasses?;
        private _staticClasses?;
        constructor(partInfo: PartInfo);
        render(classInfo: ClassInfo): string;
        update(part: AttributePart, [classInfo]: DirectiveParameters<this>): string | typeof noChange;
    }
    /**
     * A directive that applies dynamic CSS classes.
     *
     * This must be used in the `class` attribute and must be the only part used in
     * the attribute. It takes each property in the `classInfo` argument and adds
     * the property name to the element's `classList` if the property value is
     * truthy; if the property value is falsey, the property name is removed from
     * the element's `class`.
     *
     * For example `{foo: bar}` applies the class `foo` if the value of `bar` is
     * truthy.
     *
     * @param classInfo
     */
    export const classMap: (classInfo: ClassInfo) => import("_100554_litDirectives").DirectiveResult<typeof ClassMapDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { ClassMapDirective };
}
declare module "_100554_litIfDefined" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { nothing } from "_100554_litHtml";
    /**
     * For AttributeParts, sets the attribute if the value is defined and removes
     * the attribute if the value is undefined.
     *
     * For other part types, this directive is a no-op.
     */
    export const ifDefined: <T>(value: T) => typeof nothing | T;
}
declare module "_100554_litDirectivesHelper" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { Part, DirectiveParent, TemplateResult, CompiledTemplateResult } from "_100554_litHtml";
    import { DirectiveResult, DirectiveClass, PartInfo } from "_100554_litDirectives";
    type Primitive = null | undefined | boolean | number | string | symbol | bigint;
    const ChildPart: typeof import("_100554_litHtml").ChildPart;
    type ChildPart = InstanceType<typeof ChildPart>;
    /**
     * Tests if a value is a primitive value.
     *
     * See https://tc39.github.io/ecma262/#sec-typeof-operator
     */
    export const isPrimitive: (value: unknown) => value is Primitive;
    export const TemplateResultType: {
        readonly HTML: 1;
        readonly SVG: 2;
    };
    export type TemplateResultType = (typeof TemplateResultType)[keyof typeof TemplateResultType];
    type IsTemplateResult = {
        (val: unknown): val is TemplateResult | CompiledTemplateResult;
        <T extends TemplateResultType>(val: unknown, type: T): val is TemplateResult<T>;
    };
    /**
     * Tests if a value is a TemplateResult or a CompiledTemplateResult.
     */
    export const isTemplateResult: IsTemplateResult;
    /**
     * Tests if a value is a CompiledTemplateResult.
     */
    export const isCompiledTemplateResult: (value: unknown) => value is CompiledTemplateResult;
    /**
     * Tests if a value is a DirectiveResult.
     */
    export const isDirectiveResult: (value: unknown) => value is DirectiveResult;
    /**
     * Retrieves the Directive class for a DirectiveResult
     */
    export const getDirectiveClass: (value: unknown) => DirectiveClass | undefined;
    /**
     * Tests whether a part has only a single-expression with no strings to
     * interpolate between.
     *
     * Only AttributePart and PropertyPart can have multiple expressions.
     * Multi-expression parts have a `strings` property and single-expression
     * parts do not.
     */
    export const isSingleExpression: (part: PartInfo) => boolean;
    /**
     * Inserts a ChildPart into the given container ChildPart's DOM, either at the
     * end of the container ChildPart, or before the optional `refPart`.
     *
     * This does not add the part to the containerPart's committed value. That must
     * be done by callers.
     *
     * @param containerPart Part within which to add the new ChildPart
     * @param refPart Part before which to add the new ChildPart; when omitted the
     *     part added to the end of the `containerPart`
     * @param part Part to insert, or undefined to create a new part
     */
    export const insertPart: (containerPart: ChildPart, refPart?: ChildPart, part?: ChildPart) => ChildPart;
    /**
     * Sets the value of a Part.
     *
     * Note that this should only be used to set/update the value of user-created
     * parts (i.e. those created using `insertPart`); it should not be used
     * by directives to set the value of the directive's container part. Directives
     * should return a value from `update`/`render` to update their part state.
     *
     * For directives that require setting their part value asynchronously, they
     * should extend `AsyncDirective` and call `this.setValue()`.
     *
     * @param part Part to set
     * @param value Value to set
     * @param index For `AttributePart`s, the index to set
     * @param directiveParent Used internally; should not be set by user
     */
    export const setChildPartValue: <T extends ChildPart>(part: T, value: unknown, directiveParent?: DirectiveParent) => T;
    /**
     * Sets the committed value of a ChildPart directly without triggering the
     * commit stage of the part.
     *
     * This is useful in cases where a directive needs to update the part such
     * that the next update detects a value change or not. When value is omitted,
     * the next update will be guaranteed to be detected as a change.
     *
     * @param part
     * @param value
     */
    export const setCommittedValue: (part: Part, value?: unknown) => unknown;
    /**
     * Returns the committed value of a ChildPart.
     *
     * The committed value is used for change detection and efficient updates of
     * the part. It can differ from the value set by the template or directive in
     * cases where the template value is transformed before being committed.
     *
     * - `TemplateResult`s are committed as a `TemplateInstance`
     * - Iterables are committed as `Array<ChildPart>`
     * - All other types are committed as the template value or value returned or
     *   set by a directive.
     *
     * @param part
     */
    export const getCommittedValue: (part: ChildPart) => unknown;
    /**
     * Removes a ChildPart from the DOM, including any of its content.
     *
     * @param part The Part to remove
     */
    export const removePart: (part: ChildPart) => void;
    export const clearPart: (part: ChildPart) => void;
}
declare module "_100554_litLive" {
    /**
     * @license
     * Copyright 2020 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart } from "_100554_litHtml";
    import { Directive, DirectiveParameters, PartInfo } from "_100554_litDirectives";
    class LiveDirective extends Directive {
        constructor(partInfo: PartInfo);
        render(value: unknown): unknown;
        update(part: AttributePart, [value]: DirectiveParameters<this>): unknown;
    }
    /**
     * Checks binding values against live DOM values, instead of previously bound
     * values, when determining whether to update the value.
     *
     * This is useful for cases where the DOM value may change from outside of
     * lit-html, such as with a binding to an `<input>` element's `value` property,
     * a content editable elements text, or to a custom element that changes it's
     * own properties or attributes.
     *
     * In these cases if the DOM value changes, but the value set through lit-html
     * bindings hasn't, lit-html won't know to update the DOM value and will leave
     * it alone. If this is not what you want--if you want to overwrite the DOM
     * value with the bound value no matter what--use the `live()` directive:
     *
     * ```js
     * html`<input .value=${live(x)}>`
     * ```
     *
     * `live()` performs a strict equality check against the live DOM value, and if
     * the new value is equal to the live value, does nothing. This means that
     * `live()` should not be used when the binding will cause a type conversion. If
     * you use `live()` with an attribute binding, make sure that only strings are
     * passed in, or the binding will update every render.
     */
    export const live: (value: unknown) => import("_100554_litDirectives").DirectiveResult<typeof LiveDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { LiveDirective };
}
declare module "_100554_litStyleMap" {
    /**
     * @license
     * Copyright 2018 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { AttributePart, noChange } from "_100554_litHtml";
    import { Directive, DirectiveParameters, PartInfo } from "_100554_litDirectives";
    /**
     * A key-value set of CSS properties and values.
     *
     * The key should be either a valid CSS property name string, like
     * `'background-color'`, or a valid JavaScript camel case property name
     * for CSSStyleDeclaration like `backgroundColor`.
     */
    export interface StyleInfo {
        [name: string]: string | number | undefined | null;
    }
    class StyleMapDirective extends Directive {
        _previousStyleProperties?: Set<string>;
        constructor(partInfo: PartInfo);
        render(styleInfo: Readonly<StyleInfo>): string;
        update(part: AttributePart, [styleInfo]: DirectiveParameters<this>): string | typeof noChange;
    }
    /**
     * A directive that applies CSS properties to an element.
     *
     * `styleMap` can only be used in the `style` attribute and must be the only
     * expression in the attribute. It takes the property names in the
     * {@link StyleInfo styleInfo} object and adds the properties to the inline
     * style of the element.
     *
     * Property names with dashes (`-`) are assumed to be valid CSS
     * property names and set on the element's style object using `setProperty()`.
     * Names without dashes are assumed to be camelCased JavaScript property names
     * and set on the element's style object using property assignment, allowing the
     * style object to translate JavaScript-style names to CSS property names.
     *
     * For example `styleMap({backgroundColor: 'red', 'border-top': '5px', '--size':
     * '0'})` sets the `background-color`, `border-top` and `--size` properties.
     *
     * @param styleInfo
     * @see {@link https://lit.dev/docs/templates/directives/#stylemap styleMap code samples on Lit.dev}
     */
    export const styleMap: (styleInfo: Readonly<StyleInfo>) => import("_100554_litDirectives").DirectiveResult<typeof StyleMapDirective>;
    /**
     * The type of the class that powers this directive. Necessary for naming the
     * directive's return type.
     */
    export type { StyleMapDirective };
}
declare module "_100554_litWhen" {
    /**
     * @license
     * Copyright 2021 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * When `condition` is true, returns the result of calling `trueCase()`, else
     * returns the result of calling `falseCase()` if `falseCase` is defined.
     *
     * This is a convenience wrapper around a ternary expression that makes it a
     * little nicer to write an inline conditional without an else.
     *
     * @example
     *
     * ```ts
     * render() {
     *   return html`
     *     ${when(this.user, () => html`User: ${this.user.username}`, () => html`Sign In...`)}
     *   `;
     * }
     * ```
     */
    export function when<T, F>(condition: true, trueCase: () => T, falseCase?: () => F): T;
    export function when<T, F = undefined>(condition: false, trueCase: () => T, falseCase?: () => F): F;
    export function when<T, F = undefined>(condition: unknown, trueCase: () => T, falseCase?: () => F): T | F;
}
declare module "_100554_litElement" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    /**
     * The main LitElement module, which defines the {@linkcode LitElement} base
     * class and related APIs.
     *
     *  LitElement components can define a template and a set of observed
     * properties. Changing an observed property triggers a re-render of the
     * element.
     *
     *  Import {@linkcode LitElement} and {@linkcode html} from this module to
     * create a component:
     *
     *  ```js
     * import {LitElement, html} from 'lit-element';
     *
     * class MyElement extends LitElement {
     *
     *   // Declare observed properties
     *   static get properties() {
     *     return {
     *       adjective: {}
     *     }
     *   }
     *
     *   constructor() {
     *     this.adjective = 'awesome';
     *   }
     *
     *   // Define the element's template
     *   render() {
     *     return html`<p>your ${adjective} template here</p>`;
     *   }
     * }
     *
     * customElements.define('my-element', MyElement);
     * ```
     *
     * `LitElement` extends {@linkcode ReactiveElement} and adds lit-html
     * templating. The `ReactiveElement` class is provided for users that want to
     * build their own custom element base classes that don't use lit-html.
     *
     * @packageDocumentation
     */
    import { PropertyValues, ReactiveElement } from "_100554_litReactiveElement";
    import { RenderOptions } from "_100554_litHtml";
    export * from "_100554_litReactiveElement";
    export * from "_100554_litHtml";
    import { LitUnstable } from "_100554_litHtml";
    import { ReactiveUnstable } from "_100554_litReactiveElement";
    export * from "_100554_litClassMap";
    export * from "_100554_litIfDefined";
    export * from "_100554_litLive";
    export * from "_100554_litStyleMap";
    export { ChildPart, IsTemplateResult, Primitive, TemplateResultType, clearPart, getCommittedValue, getDirectiveClass, insertPart, isCompiledTemplateResult, isDirectiveResult, isPrimitive, isSingleExpression, isTemplateResult, removePart, setChildPartValue, setCommittedValue } from "_100554_litDirectivesHelper";
    export * from "_100554_litWhen";
    type RepeatFunction = () => void;
    export const repeat: (array: unknown[], func?: RepeatFunction, func2?: RepeatFunction) => void;
    /**
     * Contains types that are part of the unstable debug API.
     *
     * Everything in this API is not stable and may change or be removed in the future,
     * even on patch releases.
     */
    export namespace Unstable {
        /**
         * When Lit is running in dev mode and `window.emitLitDebugLogEvents` is true,
         * we will emit 'lit-debug' events to window, with live details about the update and render
         * lifecycle. These can be useful for writing debug tooling and visualizations.
         *
         * Please be aware that running with window.emitLitDebugLogEvents has performance overhead,
         * making certain operations that are normally very cheap (like a no-op render) much slower,
         * because we must copy data and dispatch events.
         */
        namespace DebugLog {
            type Entry = LitUnstable.DebugLog.Entry | ReactiveUnstable.DebugLog.Entry;
        }
    }
    export const UpdatingElement: typeof ReactiveElement;
    /**
     * Base element class that manages element properties and attributes, and
     * renders a lit-html template.
     *
     * To define a component, subclass `LitElement` and implement a
     * `render` method to provide the component's template. Define properties
     * using the {@linkcode LitElement.properties properties} property or the
     * {@linkcode property} decorator.
     */
    export class LitElement extends ReactiveElement {
        /**
         * Ensure this class is marked as `finalized` as an optimization ensuring
         * it will not needlessly try to `finalize`.
         *
         * Note this property name is a string to prevent breaking Closure JS Compiler
         * optimizations. See @lit/reactive-element for more information.
         */
        protected static ['finalized']: boolean;
        static ['_$litElement$']: boolean;
        /**
         * @category rendering
         */
        readonly renderOptions: RenderOptions;
        private __childPart;
        /**
         * @category rendering
         */
        protected createRenderRoot(): Element | ShadowRoot;
        /**
         * Updates the element. This method reflects property values to attributes
         * and calls `render` to render DOM via lit-html. Setting properties inside
         * this method will *not* trigger another update.
         * @param changedProperties Map of changed properties with old values
         * @category updates
         */
        protected update(changedProperties: PropertyValues): void;
        /**
         * Invoked when the component is added to the document's DOM.
         *
         * In `connectedCallback()` you should setup tasks that should only occur when
         * the element is connected to the document. The most common of these is
         * adding event listeners to nodes external to the element, like a keydown
         * event handler added to the window.
         *
         * ```ts
         * connectedCallback() {
         *   super.connectedCallback();
         *   addEventListener('keydown', this._handleKeydown);
         * }
         * ```
         *
         * Typically, anything done in `connectedCallback()` should be undone when the
         * element is disconnected, in `disconnectedCallback()`.
         *
         * @category lifecycle
         */
        connectedCallback(): void;
        /**
         * Invoked when the component is removed from the document's DOM.
         *
         * This callback is the main signal to the element that it may no longer be
         * used. `disconnectedCallback()` should ensure that nothing is holding a
         * reference to the element (such as event listeners added to nodes external
         * to the element), so that it is free to be garbage collected.
         *
         * ```ts
         * disconnectedCallback() {
         *   super.disconnectedCallback();
         *   window.removeEventListener('keydown', this._handleKeydown);
         * }
         * ```
         *
         * An element may be re-connected after being disconnected.
         *
         * @category lifecycle
         */
        disconnectedCallback(): void;
        /**
         * Invoked on each update to perform rendering tasks. This method may return
         * any value renderable by lit-html's `ChildPart` - typically a
         * `TemplateResult`. Setting properties inside this method will *not* trigger
         * the element to update.
         * @category rendering
         */
        protected render(): unknown;
    }
    /**
     * END USERS SHOULD NOT RELY ON THIS OBJECT.
     *
     * Private exports for use by other Lit packages, not intended for use by
     * external users.
     *
     * We currently do not make a mangled rollup build of the lit-ssr code. In order
     * to keep a number of (otherwise private) top-level exports  mangled in the
     * client side code, we export a _$LE object containing those members (or
     * helper methods for accessing private fields of those members), and then
     * re-export them for use in lit-ssr. This keeps lit-ssr agnostic to whether the
     * client-side code is being used in `dev` mode or `prod` mode.
     *
     * This has a unique name, to disambiguate it from private exports in
     * lit-html, since this module re-exports all of lit-html.
     *
     * @private
     */
    export const _$LE: {
        _$attributeToProperty: (el: LitElement, name: string, value: string | null) => void;
        _$changedProperties: (el: LitElement) => any;
    };
}
declare module "_100554_litDecorators" {
    /**
     * @license
     * Copyright 2017 Google LLC
     * SPDX-License-Identifier: BSD-3-Clause
     */
    import { ReactiveElement, PropertyDeclaration } from "_100554_litReactiveElement";
    type Omit<T, K extends keyof any> = Pick<T, Exclude<keyof T, K>>;
    export type Constructor<T> = {
        new (...args: any[]): T;
    };
    export interface ClassDescriptor {
        kind: 'class';
        elements: ClassElement[];
        finisher?: <T>(clazz: Constructor<T>) => void | Constructor<T>;
    }
    export interface ClassElement {
        kind: 'field' | 'method';
        key: PropertyKey;
        placement: 'static' | 'prototype' | 'own';
        initializer?: Function;
        extras?: ClassElement[];
        finisher?: <T>(clazz: Constructor<T>) => void | Constructor<T>;
        descriptor?: PropertyDescriptor;
    }
    export const legacyPrototypeMethod: (descriptor: PropertyDescriptor, proto: Object, name: PropertyKey) => void;
    export const standardPrototypeMethod: (descriptor: PropertyDescriptor, element: ClassElement) => {
        kind: string;
        placement: string;
        key: PropertyKey;
        descriptor: PropertyDescriptor;
    };
    /**
     * Helper for decorating a property that is compatible with both TypeScript
     * and Babel decorators. The optional `finisher` can be used to perform work on
     * the class. The optional `descriptor` should return a PropertyDescriptor
     * to install for the given property.
     *
     * @param finisher {function} Optional finisher method; receives the element
     * constructor and property key as arguments and has no return value.
     * @param descriptor {function} Optional descriptor method; receives the
     * property key as an argument and returns a property descriptor to define for
     * the given property.
     * @returns {ClassElement|void}
     */
    export const decorateProperty: ({ finisher, descriptor, }: {
        finisher?: ((ctor: typeof ReactiveElement, property: PropertyKey) => void) | null;
        descriptor?: (property: PropertyKey) => PropertyDescriptor;
    }) => (protoOrDescriptor: ReactiveElement | ClassElement, name?: PropertyKey) => void | any;
    /**
     * Allow for custom element classes with private constructors
     */
    type CustomElementClass = Omit<typeof HTMLElement, 'new'>;
    /**
     * Class decorator factory that defines the decorated class as a custom element.
     *
     * ```js
     * @customElement('my-element')
     * class MyElement extends LitElement {
     *   render() {
     *     return html``;
     *   }
     * }
     * ```
     * @category Decorator
     * @param tagName The tag name of the custom element to define.
     */
    export const customElement: (tagName: string) => (classOrDescriptor: CustomElementClass | ClassDescriptor) => any;
    /**
     * Adds event listener options to a method used as an event listener in a
     * lit-html template.
     *
     * @param options An object that specifies event listener options as accepted by
     * `EventTarget#addEventListener` and `EventTarget#removeEventListener`.
     *
     * Current browsers support the `capture`, `passive`, and `once` options. See:
     * https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#Parameters
     *
     * ```ts
     * class MyElement {
     *   clicked = false;
     *
     *   render() {
     *     return html`
     *       <div @click=${this._onClick}>
     *         <button></button>
     *       </div>
     *     `;
     *   }
     *
     *   @eventOptions({capture: true})
     *   _onClick(e) {
     *     this.clicked = true;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function eventOptions(options: AddEventListenerOptions): (protoOrDescriptor: ReactiveElement | ClassElement, name?: PropertyKey) => void | any;
    /**
     * A property decorator which creates a reactive property that reflects a
     * corresponding attribute value. When a decorated property is set
     * the element will update and render. A {@linkcode PropertyDeclaration} may
     * optionally be supplied to configure property features.
     *
     * This decorator should only be used for public fields. As public fields,
     * properties should be considered as primarily settable by element users,
     * either via attribute or the property itself.
     *
     * Generally, properties that are changed by the element should be private or
     * protected fields and should use the {@linkcode state} decorator.
     *
     * However, sometimes element code does need to set a public property. This
     * should typically only be done in response to user interaction, and an event
     * should be fired informing the user; for example, a checkbox sets its
     * `checked` property when clicked and fires a `changed` event. Mutating public
     * properties should typically not be done for non-primitive (object or array)
     * properties. In other cases when an element needs to manage state, a private
     * property decorated via the {@linkcode state} decorator should be used. When
     * needed, state properties can be initialized via public properties to
     * facilitate complex interactions.
     *
     * ```ts
     * class MyElement {
     *   @property({ type: Boolean })
     *   clicked = false;
     * }
     * ```
     * @category Decorator
     * @ExportDecoratedItems
     */
    export function property(options?: PropertyDeclaration): (protoOrDescriptor: Object | ClassElement, name?: PropertyKey) => any;
    /**
     * A property decorator that converts a class property into a getter
     * that executes a querySelectorAll on the element's renderRoot.
     *
     * @param selector A DOMString containing one or more selectors to match.
     *
     * See:
     * https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelectorAll
     *
     * ```ts
     * class MyElement {
     *   @queryAll('div')
     *   divs: NodeListOf<HTMLDivElement>;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function queryAll(selector: string): (protoOrDescriptor: ReactiveElement | ClassElement, name?: PropertyKey) => void | any;
    /**
     * A property decorator that converts a class property into a getter that
     * returns a promise that resolves to the result of a querySelector on the
     * element's renderRoot done after the element's `updateComplete` promise
     * resolves. When the queried property may change with element state, this
     * decorator can be used instead of requiring users to await the
     * `updateComplete` before accessing the property.
     *
     * @param selector A DOMString containing one or more selectors to match.
     *
     * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
     *
     * ```ts
     * class MyElement {
     *   @queryAsync('#first')
     *   first: Promise<HTMLDivElement>;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     *
     * // external usage
     * async doSomethingWithFirst() {
     *  (await aMyElement.first).doSomething();
     * }
     * ```
     * @category Decorator
     */
    export function queryAsync(selector: string): (protoOrDescriptor: ReactiveElement | ClassElement, name?: PropertyKey) => void | any;
    /**
     * A property decorator that converts a class property into a getter that
     * executes a querySelector on the element's renderRoot.
     *
     * @param selector A DOMString containing one or more selectors to match.
     * @param cache An optional boolean which when true performs the DOM query only
     *     once and caches the result.
     *
     * See: https://developer.mozilla.org/en-US/docs/Web/API/Document/querySelector
     *
     * ```ts
     * class MyElement {
     *   @query('#first')
     *   first: HTMLDivElement;
     *
     *   render() {
     *     return html`
     *       <div id="first"></div>
     *       <div id="second"></div>
     *     `;
     *   }
     * }
     * ```
     * @category Decorator
     */
    export function query(selector: string, cache?: boolean): (protoOrDescriptor: ReactiveElement | ClassElement, name?: PropertyKey) => void | any;
    export interface InternalPropertyDeclaration<Type = unknown> {
        /**
         * A function that indicates if a property should be considered changed when
         * it is set. The function should take the `newValue` and `oldValue` and
         * return `true` if an update should be requested.
         */
        hasChanged?(value: Type, oldValue: Type): boolean;
    }
    /**
     * Declares a private or protected reactive property that still triggers
     * updates to the element when it changes. It does not reflect from the
     * corresponding attribute.
     *
     * Properties declared this way must not be used from HTML or HTML templating
     * systems, they're solely for properties internal to the element. These
     * properties may be renamed by optimization tools like closure compiler.
     * @category Decorator
     */
    export function state(options?: InternalPropertyDeclaration): (protoOrDescriptor: Object | ClassElement, name?: PropertyKey) => any;
}
declare module "_100554_aimHelper" {
    export let tasks: mls.cbe.ITaskRoot[];
    export let tasksProject: number;
    /**
     * return the result of the prompt
     */
    export function executePrompt(taskIndex: number): Promise<mls.cbe.ITaskRoot>;
    export function updateTaskOnServer(taskIndex: number): Promise<mls.cbe.ITaskRoot>;
    export function readTasks(): Promise<void>;
    export function getInfoMyService(elBase: HTMLElement): {
        level: number;
        position: string;
        actServiceOp: any;
    } | undefined;
    export function getUserConfigs(): IAimColums;
    export function saveUserConfigs(obj: IAimColums): void;
    export function extractScript(src: string, regex: RegExp): string;
    export interface IAimColums {
        status: boolean;
        cost: boolean;
        sequencial: boolean;
        countChild: boolean;
        title: boolean;
        prompt: boolean;
        user: boolean;
        reference: boolean;
        lastUpdateDate: boolean;
    }
    export interface ITaskFinish {
        status: 'ok' | 'error' | 'rejected' | 'userEvent';
        taskIndex: number;
        childIndex: number;
        result: string;
        newPrompt?: string;
        taskRoot: mls.cbe.ITaskRoot;
        taskChild: mls.cbe.ITaskChild;
    }
}
declare module "_100554_utilsLit" {
    export function convertTagToFileName(tag: string): string;
    export function convertFileNameToTag(widget: string): string;
}
declare module "_100554_collabLitElement" {
    import { LitElement } from "_100554_litElement";
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_100554_aimBase" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    export class AimBase extends CollabLitElement {
        mode: mls.cbe.IMode;
        taskIndex: number;
        createRenderRoot(): this;
        renderToolbar(): TemplateResult;
        renderToolBarInProgress(): TemplateResult;
        renderToolBarWaiting(): TemplateResult;
        renderToolBarReady(): TemplateResult;
        renderToolBarError(): TemplateResult;
        renderToolBarProcessed(): TemplateResult;
        renderToolBarCanceled(): TemplateResult;
        onIconClick(action: string): void;
        iconPlay: TemplateResult<1>;
        iconStop: TemplateResult<1>;
        iconRunAll: TemplateResult<1>;
        iconError: TemplateResult<1>;
        iconCheckAll: TemplateResult<1>;
        iconCanceled: TemplateResult<1>;
        iconClock: TemplateResult<1>;
        iconRunAllCoverage: TemplateResult<1>;
        iconUser: TemplateResult<1>;
        iconMoney: TemplateResult<1>;
        iconPrompt: TemplateResult<1>;
        iconHash: TemplateResult<1>;
        iconDate: TemplateResult<1>;
        iconRef: TemplateResult<1>;
    }
}
declare module "_100554_aimActionBase" {
    import { TemplateResult } from "_100554_litElement";
    import { AimBase } from "_100554_aimBase";
    export abstract class AimActionBase extends AimBase {
        constructor();
        abstract getRules(): AimActionRules[];
        abstract assistant: string;
        abstract title: string; /** ex: "Spell Check" */
        abstract renderAdd(): TemplateResult;
        childThis: any;
        render(): TemplateResult;
        onTaskFinishedEvent(e: any): void;
        addTaskAndWaitForCompletion: (taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild) => void;
        prepareNextStep: (child: mls.cbe.ITaskChild) => void;
        getPromptUser(task: mls.cbe.ITaskRoot): string;
        getRef(taskRoot: mls.cbe.ITaskRoot): string;
        getLastUpdateDate(taskRoot: mls.cbe.ITaskRoot): string;
        private getLocateDateTimeInTrace;
        renderTaskRoot(): TemplateResult;
        loadDynamicWidget(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild, widget: string): Promise<void>;
    }
    /**
     * Rules to active this action
     * @param levels levels this Action is active, ex: [{level:2, tags: ["*serviceXYZ*"]}]
     * @param tags tags this Action is active, ex: "typescript"
     */
    export interface AimActionRules {
        level: number;
        tags: string[];
    }
    export interface ResponseFindActions {
        project: number;
        shortName: string;
        title: string;
        levelsValid: boolean;
        tagsValid: boolean;
    }
    /**
     * find all Actions cf rules
     */
    export const findActions: (levelToVerify: number, tagsToVerify: string[]) => Promise<ResponseFindActions[]>;
}
declare module "_100554_icaTypes" {
    import { LitElement } from "_100554_litElement";
    export type FormComponent = {
        group: string;
        description: string;
        prompt?: string;
        attributes?: string;
        events?: string;
    };
    export type AttributeDefinition = {
        path: string;
        lit: string;
        variations?: boolean;
    };
    export type EventsDefinition = {
        name: string;
        desc: string;
        group?: string[];
    };
    export interface IActionsToolbox {
        position: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-l5' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title' | '';
        tp: 'menu' | 'button' | 'back-button' | 'action' | 'event';
        format: 'square' | 'circle' | '';
        title: string | undefined;
        iconSvg: string | undefined;
        onclick: Function | undefined;
        menuItens: IActionsToolboxMenu[];
        menuSubItens: IActionsToolboxMenu[];
        widget: string | undefined;
        cursor: string | undefined;
        attrs: IAttr[] | undefined;
        isDblClick: boolean;
    }
    export interface IAttr {
        attr: string;
        value: string;
    }
    export interface IActionsToolboxMenu {
        iconSvg: string;
        text: string;
        onclick: Function;
    }
    export interface IActionLevels {
        '1': IActionsToolbox[];
        '2': IActionsToolbox[];
        '3': IActionsToolbox[];
        '4': IActionsToolbox[];
        '5': IActionsToolbox[];
        '6': IActionsToolbox[];
        '7': IActionsToolbox[];
    }
    export interface ActionTag {
        name: string;
        position?: 'p-l0' | 'p-l1' | 'p-l2' | 'p-l3' | 'p-l4' | 'p-m0' | 'p-m1' | 'p-m2' | 'p-m3' | 'p-m4' | 'p-r0' | 'p-r1' | 'p-r2' | 'p-r3' | 'p-r4' | 'p-title';
        args?: string;
        level?: number[];
        toolboxOptions?: IToolboxOptions;
    }
    export interface IToolboxOptions {
        background?: string;
        border?: string;
    }
    export interface IcaLitElementBaseMethods extends LitElement {
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        globalVariation: number | undefined;
        widget: string | undefined;
        overlayRef: HTMLElement | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateStyle(info: {}): void;
        changeStateHtml(info: string): void;
        allowCommand(cmd: 'move' | '', scope: HTMLElement, target: HTMLElement): IAllowCommand;
        getICAComponents(scope: HTMLElement): IcaLitElementBaseMethods[];
        getMyScope(): IcaLitElementBaseMethods | HTMLElement | undefined;
        getIcaParent(target: HTMLElement): IcaLitElementBaseMethods | undefined;
        getMyInfos(): {
            root: string;
            subGroup: string;
            finalGroup: string;
        };
        getMyEvents(): string;
        getDefinitionFromEvent(event: string): string;
        getAtributtes(): string[];
    }
    export interface IICADepths {
        element: IcaLitElementBaseMethods;
        depth: number;
        x: number;
        y: number;
        height: number;
        width: number;
        opacity: string;
    }
    export interface IAllowCommand {
        inside: boolean;
        before: boolean;
        after: boolean;
    }
}
declare module "_100554_icaBaseDescription" {
    export function getDescriptionsRootGroup(): string[];
    export function getDescriptionsSubGroup(root: string): string[];
    export function getDescriptionsFinalGroup(root: string, subGroup: string): string[];
    export function getFormComponentsDescription(root: string, subGroup: string | null, finalGroup: string | null): string;
    export function getFormComponentsPrompt(root: string, subGroup: string, finalGroup: string): string;
    export function getFormComponentsAttributes(root: string, subGroup: string, finalGroup: string): string;
    export function getAttributeDefinitions(root: string, subGroup: string, finalGroup: string): string[];
    export function getAttributeDefinitionsLit(root: string, subGroup: string, finalGroup: string): string[];
    export function checkAttributteHasVariation(attribute: string): boolean;
    export function getFormComponentsEvents(root: string, subGroup: string, finalGroup: string): string;
    export function getEventDescription(root: string, subGroup: string, finalGroup: string, event: string): string;
    export function getAtributtes(root: string, subGroup: string, finalGroup: string): string[];
}
declare module "_100554_icaSelectGroup" {
    import { LitElement } from "_100554_litElement";
    export function initIcaSelectGroup(): boolean;
    export class IcaSelectGroup extends LitElement {
        private rootBread;
        actualGroups: string[];
        actualBreadCrumb: string[];
        actualMode: IActualModeGroup;
        connectedCallback(): void;
        _handleInternalAction(): void;
        clear(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private renderGroups;
        private renderBreadCrumb;
        private renderGroupsRoot;
        private renderSubGroups;
        private renderFinalGruops;
        private onClickRootGroup;
        private onClickSubGroup;
        private onClickFinalGroup;
        private onBreadClick;
        messages: {
            selectICA: string;
        };
        static styles: import("_100554_litCssTag").CSSResult;
    }
    type IActualModeGroup = 'root' | 'subgroup' | 'finalgroup' | 'empty';
}
declare module "_100554_libProjectConfig" {
    export const projectConfig: IProjectConfigCache;
    export function clearLocalChanges(project: number): Promise<void>;
    export function getConfigProject(project: number, ignoreLocalChanges?: boolean): Promise<mls.l5_common.ProjectConfig | undefined>;
    export function updateConfigProject(project: number, newConfig: mls.l5_common.ProjectConfig): Promise<void>;
    export function updateConfigProjectPlugins(project: number, newPlugins: {
        [key: string]: mls.l5_common.IPlugin;
    }): Promise<void>;
    export function createConfigFile(project: number): Promise<mls.l5_common.ProjectConfig>;
    interface IProjectConfigCache {
        [key: number]: {
            versionRef: string;
            config: mls.l5_common.ProjectConfig;
        };
    }
}
declare module "_100554_libDesignSystem" {
    export function list(project: number): Promise<mls.l5_common.DesignSystem[]>;
    export function getDSInstance(project: number, dsindex: number): Promise<DesignSystemIO>;
    export function getOrCreateDSInstanceIO(project: number, dsindex: number, widgetIOName: string): Promise<DesignSystemIO>;
    export interface DesignSystemIO {
        project: number;
        dsindex: number;
        dsname: string;
        createdBy: string;
        lastUpdated: string;
        lastUpdatedBy: string;
        docs: DocIO | undefined;
        tokens: TokenIO | undefined;
        css: CssIO | undefined;
        assets: AssetIO | undefined;
        components: ComponentIO | undefined;
        init: () => Promise<void>;
        remove: () => Promise<void>;
        create: (project: number, dsindex: number, createdAt: string, reference?: IDSRef) => Promise<void>;
        dispose: () => Promise<void>;
        getDesignSystemCss: (theme: string) => Promise<string>;
    }
    export interface TokenIO {
        _ds: DesignSystemIO;
        list: ITokenInfo;
        add: (key: string, value: string, theme: string, category: TokensCategories) => Promise<void>;
        getTokensLess: (theme: string) => Promise<string>;
        getTokensCss: (theme: string) => Promise<string>;
        update: (key: string, newValue: string, theme: string) => Promise<void>;
        remove: (key: string, theme: string) => Promise<void>;
        addTheme: (theme: string, description: string) => Promise<void>;
        removeTheme: (theme: string) => Promise<void>;
        setTokens: (theme: string, tokensColor: IToken, tokensTypography: IToken, tokensGlobal: IToken) => Promise<void>;
    }
    export interface DocIO {
        _ds: DesignSystemIO;
        list: IDocInfos;
        find: (id: number) => IDocInfo | null;
        add: (parentID: number, title: string, content: string) => Promise<number>;
        update: (id: number, parentID: number, title: string, content: string) => Promise<void>;
        remove: (id: number) => Promise<void>;
    }
    export interface AssetIO {
        _ds: DesignSystemIO;
        list: IAssetInfos;
        add: (path: string, shortname: string, tags: string[], description: string, assetType: mls.l3.AssetsGroupType, content: File, reference?: mls.l3.IDSRef) => Promise<void>;
        remove: (path: string, shortname: string) => Promise<void>;
        update: (path: string, shortname: string, tags: string[], description: string, assetType: mls.l3.AssetsGroupType) => Promise<void>;
        find: (path: string, shortname: string) => IAssetsInfo | null;
    }
    export interface CssIO {
        _ds: DesignSystemIO;
        list: ICssInfos;
        getStylesInLess: (theme: string) => Promise<string>;
        add: (name: string, content: string) => Promise<void>;
    }
    export interface ComponentIO {
        _ds: DesignSystemIO;
        list: IComponentInfos;
        examples: ExampleIO;
        styles: StyleIO;
        add: (widget: IComponentInfo) => Promise<void>;
        remove: (componentName: string) => Promise<void>;
        getCSS: (componentName: string, theme: string) => Promise<string>;
        getStylesLess: (componentName: string, theme: string) => Promise<string | null>;
        find: (componentName: string) => IComponentInfo | null;
    }
    export interface ExampleIO {
        _ds: DesignSystemIO;
        list: IComponentsExampleInfos;
        add: (componentName: string, exampleName: string, description: string, exampleJsonP: string, reference?: mls.l3.IDSRef) => Promise<void>;
        rename: (componentName: string, exampleName: string, newExampleName: string) => Promise<void>;
        remove: (componentName: string, exampleName: string) => Promise<void>;
        find: (componentName: string, exampleName: string) => IComponentsExample | null;
    }
    export interface StyleIO {
        _ds: DesignSystemIO;
        list: IComponentsStyleInfos;
        add: (componentName: string, classname: string, less: string, reference?: mls.l3.IDSRef) => Promise<void>;
        rename: (componentName: string, styleName: string, newName: string) => Promise<void>;
        remove: (componentName: string, styleName: string) => Promise<void>;
        find: (componentName: string, styleName: string) => IComponentsStyle | null;
    }
    export interface IDSRef {
        project: number;
        dsindex: number;
        referenceAt?: Date;
        index?: number;
    }
    export type ITokenInfo = {
        [key: string]: ITokenInfo2;
    };
    export type ITokenInfo2 = {
        color: IToken;
        typography: IToken;
        global: IToken;
        description: string;
    };
    export type IToken = {
        [key: string]: string;
    };
    export type TokensCategories = 'color' | 'typography' | 'global';
    export interface ITokens {
        themeName: string;
        description: string;
        color: IToken;
        typography: IToken;
        global: IToken;
    }
    export interface IDocInfos {
        [id: number]: IDocInfo;
    }
    export interface IDocInfo {
        id: number;
        parentID: number;
        title: string;
        getContent: (this: IDocInfo) => Promise<string>;
        setContent: (this: IDocInfo, content: string | null) => Promise<boolean>;
    }
    export interface IAssetInfos {
        [fullpath: string]: IAssetsInfo;
    }
    export interface IAssetsInfo {
        path: string;
        shortname: string;
        type: AssetsGroupType;
        src: string;
        description: string;
        tags: string[];
        content: string;
        reference: IDSRef;
    }
    export interface ICssInfos {
        [name: string]: ICssInfo;
    }
    export interface ICssInfo {
        name: string;
        getContent: (this: ICssInfo) => Promise<string>;
        setContent: (this: ICssInfo, content: string | null) => Promise<boolean>;
    }
    export interface IComponentsStyleInfos {
        [stylename: string]: IComponentsStyle;
    }
    export interface IComponentsStyle {
        stylename: string;
        reference?: IDSRef;
        getStyleLessIO: (this: IComponentsStyle) => Promise<string>;
        setStyleLessIO: (this: IComponentsStyle, content: string) => Promise<boolean>;
    }
    export interface IComponentInfos {
        [name: string]: IComponentInfo;
    }
    export interface IComponentInfo {
        name: string;
        l4MarketingRef: string;
        widgetExampleRef: IWCGeneratorExampleInfo;
        docPath: string;
        group: ComponentsGroups;
        tags: string[];
        reference: IDSRef;
        examples: IComponentsExample[];
        styles: IComponentsStyle[];
    }
    export interface IWCGeneratorExampleInfo {
        tagname: string;
        path: string;
    }
    export interface IComponentsExampleInfos {
        [exampleName: string]: IComponentsExample;
    }
    export interface IComponentsExample {
        exampleName: string;
        description: string;
        reference: IDSRef;
        getEl: (this: IComponentsExample) => Promise<HTMLElement>;
        getJsonPExampleIO: (this: IComponentsExample) => Promise<string>;
        setJsonPExampleIO: (this: IComponentsExample, content: string) => Promise<boolean>;
    }
    export type AssetsGroupType = 'image' | 'video' | 'icon' | 'lib' | 'other';
    export type ComponentsGroups = 'selectOne' | 'selectMultiple' | 'action' | 'layout' | 'midia' | 'navigation';
}
declare module "_100554_libCompile" {
    export const getDependenciesByHtml: (mfile: mls.l2.editor.IMFile, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (mfile: mls.l2.editor.IMFile, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        css: string[];
        globalCss: string | undefined;
        tokens: string[];
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_100554_libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function getDateFormated(dt: string): string;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function compileLess(): Promise<void>;
}
declare module "_100554_serviceBase" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export abstract class ServiceBase extends CollabLitElement {
        get level(): number;
        position: 'left' | 'right';
        visible: string;
        msize: string;
        loading: boolean;
        get serviceContent(): IToolbarContent;
        get nav3Service(): IMlsNav3;
        get serviceItemNav(): IMlsNav2Item;
        get tooltipEl(): ITooltipElement;
        abstract details: IService;
        abstract menu: IMenu;
        abstract onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        getActualRef(): string;
        setError(error: string): void;
        toogleBadge(show: boolean, serviceName: string): void;
        openMe(): void;
        showNav2Item(show: boolean): void;
        openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): void;
        setFullScreen(level: number, position: 'right' | 'left' | 'default'): void;
        selectLevel(level: number): void;
        addScenario(page: string, fullscreen?: boolean): void;
        removeScenario(page: string, fullscreen?: boolean): void;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private checkFocus;
        private setActualServicePosition;
        private getMlsNav2;
        private getNav3ServiceContent;
        private getNav3Service;
        private getNav3ServiceMenu;
        private getTooltip;
        private getSplitter;
        private getServiceItemNav;
    }
    export interface IMenuKeyValue {
        [key: string]: string;
    }
    export interface IIconsKeyValue {
        [key: string]: string;
    }
    export interface IButtonsKeyValue {
        [key: string]: string;
    }
    export type IClickLinkCallBack = (op: string) => boolean | undefined;
    export type IClickIconCallBack = (op: string) => void | undefined;
    export type IClickTitleCallBack = (title: string) => void | undefined;
    export type IClickButtonCallBack = (op: string, opMenu?: string) => boolean;
    export type ISetMode = (mode: IMode | null, page?: HTMLElement) => void;
    export type IGetLastMode = () => IMode;
    export type IMode = 'initial' | 'page' | 'editor';
    export interface IMenu {
        title: IMenuTitle | string;
        actions: IMenuKeyValue;
        icons: IIconsKeyValue;
        buttons?: IButtonsKeyValue;
        actionDefault?: string;
        iconDefault?: string;
        onClickTitle?: IClickTitleCallBack;
        onClickLink?: IClickLinkCallBack;
        onClickIcon?: IClickIconCallBack;
        onClickButton?: IClickButtonCallBack;
        setMode?: ISetMode;
        setIconActive?: (op: string) => void;
        setMenuActive?: (op: string) => void;
        selectButton?: (op: string) => void;
        closeMenu?: Function;
        refresh?: Function;
        getLastMode?: IGetLastMode;
        lastIcon?: string;
        updateTitle?: Function;
        iconMenuType?: 'full' | 'onlyicon';
    }
    export interface IMenuTitle {
        text: string;
        icon: string;
    }
    export interface IToolbarContent extends HTMLElement {
        layout: Function;
    }
    export interface ITooltipElement extends HTMLElement {
        tooltip: (el: HTMLElement) => void;
    }
    export interface ISpliterElement extends HTMLElement {
        setFullScreen: (level: number, position: 'right' | 'left' | 'default') => void;
    }
    export interface IMlsNav2 extends HTMLElement {
        toogleBadge: (show: boolean, serviceName: string) => void;
    }
    export interface IMlsNav3 extends HTMLElement {
        getActiveInstance: (position: 'left' | 'right') => ServiceBase | undefined;
    }
    export interface IMlsNav2Item extends HTMLElement {
        show: (show: boolean) => void;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: ICollabServicePosition;
        level: number[];
        tags?: string[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
        customConfiguration?: IServiceCustom;
    }
    export type IServiceCustom = {
        [key: number]: IServiceCustomByPosition | IServiceCustomPlace;
    };
    export type IServiceCustomByPosition = {
        right?: IServiceCustomPlace;
        left?: IServiceCustomPlace;
    };
    export interface IServiceCustomPlace {
        tooltip?: string;
        visible?: boolean;
        state?: ICollabServiceState;
        classname?: ICollabServiceClass;
        show?: boolean;
    }
    export interface IToolbarChangeEvent {
        level: number;
        position: 'left' | 'right';
        from: string;
        to: string;
    }
    export type ICollabServicePosition = "left" | "right" | "all";
    export type ICollabServiceState = "foreground" | "background";
    export type ICollabServiceClass = "separator-left" | "separator-right";
}
declare module "_100554_icaState" {
    export interface GlobalState {
        [key: string]: any;
    }
    global {
        export interface Window {
            globalState: GlobalState;
            globalStateManagment: IcaState;
            globalVariation: number;
        }
    }
    /**
     * Class responsible for managing shared state.
     */
    export class IcaState {
        private stateMap;
        private componentMap;
        /**
         * Update state for a given key.
         * @param key - The state key.
         * @param value - The new state value.
         */
        setState(key: string, value: any): void;
        /**
         * Retrieve state for a given key.
         * @param key - The state key.
         */
        getState(key: string): any;
        /**
         * Subscribe a component to a state key or keys.
         * @param keyOrKeys - The state key or keys.
         * @param component - The subscribing component.
         */
        subscribe(keyOrKeys: string | string[], component: Object): void;
        /**
         * Unsubscribe a component from a state key or keys.
         * @param keyOrKeys - The state key or keys.
         * @param component - The unsubscribing component.
         */
        unsubscribe(keyOrKeys: string | string[], component: Object): void;
        /**
         * Notify subscribed components about a state change.
         * @param key - The state key that changed.
         */
        notify(key: string): void;
        /**
         * Get statistics about current state keys and their subscribers.
         */
        getStateStatistics(): Map<string, number>;
    }
}
declare module "_100554_icaDecorators" {
    import { PropertyDeclaration } from "_100554_litElement";
    import { IcaState } from "_100554_icaState";
    export const state1: IcaState;
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options including type and default value.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options including type and default value.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_100554_icaLitElement" {
    import { CollabLitElement } from "_100554_collabLitElement";
    import { PropertyValueMap } from "_100554_litElement";
    export * from "_100554_icaDecorators";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class IcaLitElement extends CollabLitElement {
        stateKeys: Set<string>;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed.
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
    }
}
declare module "_100554_icaGlobal" {
    import * as tps from "_100554_icaTypes";
    export const PREFIX = "ica";
    export const PREFIXWCD = "wcd";
    export const ATTRGROUP = "isicagroup";
    export const ICAPAGE = "ica-page-100554";
    export const CHANGESTATE = "changeState";
    export function getPosition(icaInfo: tps.IICADepths, boundingPage: DOMRect): {
        left: string;
        top: string;
        width: string;
        height: string;
    };
}
declare module "_100554_icaLitElementBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    import * as tps from "_100554_icaTypes";
    export abstract class IcaLitElementBase extends IcaLitElement implements tps.IcaLitElementBaseMethods {
        abstract mySymbol: string;
        abstract changeStateHtml(info: string): void;
        abstract allowCommand(cmd: 'move' | '', scope: HTMLElement, target: HTMLElement): tps.IAllowCommand;
        abstract getActionsTags(): tps.ActionTag[];
        overlayRef: HTMLElement | undefined;
        widget: string | undefined;
        id: string;
        isICAGroup: boolean | undefined;
        renderType: 'preview' | 'edit' | 'editactive' | undefined;
        level: '1' | '2' | '3' | '4' | '5' | '6' | '7' | undefined;
        styleel: string | undefined;
        internalInnerHTML: string;
        private lastWidget;
        private styleElMain;
        private excludesProps;
        createRenderRoot(): this;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
        firstUpdated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        changeStateStyle(style: {}): void;
        private updateStyleEl;
        private updateLevelIcas;
        private updateAttrInWc;
        private updateStyleDisplay;
        private doChangeState;
        getICAComponents(scope: HTMLElement): tps.IcaLitElementBaseMethods[];
        getMyScope(): IcaLitElementBase | HTMLElement | undefined;
        getIcaParent(target: HTMLElement): tps.IcaLitElementBaseMethods | undefined;
        performPreSlotAllocationOperations(): Promise<void>;
        private setInitialConfigs;
        private getAttributes;
        private filterAttributes;
        private myInfos;
        getMyInfos(): {
            root: string;
            subGroup: string;
            finalGroup: string;
        };
        getMyEvents(): string;
        getDefinitionFromEvent(event: string): string;
        getAtributtes(): string[];
    }
}
declare module "_100554_wcdTypes" {
    import * as tps from "_100554_icaTypes";
    export interface WCDToolboxMethodos extends HTMLElement {
        lastHelper: string;
        widget: string | undefined;
        level: string;
        elMain: HTMLElement | undefined;
        elICA: tps.IcaLitElementBaseMethods | undefined;
        fcBeforeBackButton: Function | undefined;
        updateSize(elBase: HTMLElement, elChange: HTMLElement, changePosition: boolean): void;
        getAndSetScenaryOutDoor(op: string): Promise<HTMLElement | undefined>;
        backNavigationScenaryOutdoor(): void;
        setIconsWcdToolbox(act: tps.ActionTag[], useSelf: boolean, updataSize: 'false' | 'size' | 'padding'): void;
        updateBaseNoPadding(elBase: HTMLElement, elChange: HTMLElement): void;
        updateBackgroundAuxSize(tp: 'show' | 'hide'): void;
    }
    export interface WCDToolboxItemMethodos extends HTMLElement {
        myParent: WCDToolboxMethodos | undefined;
        elMain: HTMLElement | undefined;
        elICA: tps.IcaLitElementBaseMethods | undefined;
        args: string | undefined;
    }
    export interface WCDOverlayMethods extends HTMLElement {
        myKeyEvents: {
            [key: string]: Function;
        };
        changeOverlayItemsLevel(): void;
        createOverlayItems(): void;
        selectItem(ica: tps.IcaLitElementBaseMethods): void;
        getActionsTagsDefault(): {
            [key: string]: tps.ActionTag;
        };
        refreshOverlay(): void;
        myItens: tps.IICADepths[];
    }
    export interface WCDOverlayItensMethods extends HTMLElement {
        info: tps.IICADepths | undefined;
        widget: string | undefined;
        level: string | undefined;
        boundingPage: DOMRect | undefined;
        overlay: WCDOverlayMethods | undefined;
    }
    export interface WCDPopupMethodos extends HTMLElement {
        myParent: WCDToolboxItemEditTextMethodos | undefined;
        changeType: (tp: string) => void;
    }
    export interface WCDToolboxItemEditTextMethodos extends HTMLElement {
        changeType: (tp: string) => void;
    }
    export interface IWCDCommand {
        overlay: WCDOverlayMethods;
        selectedIca: tps.IcaLitElementBaseMethods | undefined;
        args: Record<string, any>;
    }
}
declare module "_100554_collabPageElement" {
    import { PropertyValueMap } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    import { WCDOverlayMethods } from "_100554_wcdTypes";
    export const PREFIX_ICA_ID = "ica_";
    export abstract class CollabPageElement extends CollabLitElement {
        abstract initPage(): void;
        modeoverlay: string;
        level: string;
        overlay: WCDOverlayMethods | undefined;
        isPage: boolean;
        refreshOverlay(): void;
        constructor();
        createRenderRoot(): this;
        firstUpdated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private getVariationDevice;
        private setupIds;
        private setupEvents;
        private checkToAddOverlay;
        private createOverlay;
        private hasImport;
        private importWCDOverlay;
        private findAllElementsIca;
        private getAllWebComponents;
    }
    export function getEventName(eventName: string, elementId?: string, device?: IDevice): string;
    export type IDevice = 'desktop' | 'mobile' | 'others';
}
declare module "_100554_collabDOMSync" {
    export function sync(): void;
    export function formatHtml(html: string): string;
}
declare module "_100554_processCssLit" {
    export const MLS_GETDEFAULTDESIGNSYSTEM = "[[mls_getDefaultDesignSystem]]";
    export function injectStyle(mfile: mls.l2.editor.IMFile, theme: string): Promise<void>;
    export function injectStyleShadowRoot(mfile: mls.l2.editor.IMFile, theme: string): Promise<void>;
    export function injectStyleWithoutShadowRoot(mfile: mls.l2.editor.IMFile, theme: string): Promise<void>;
    export function getCssWithoutTag(css: string, tag: string): string;
}
declare module "_100554_enhancementStyle" {
    import { ITokenInfo } from "_100554_libDesignSystem";
    export const getAddNewFileDetails: () => {
        title: string;
        description: string;
        tags: string[];
        example: string;
    }[];
    export const requires: mls.l2.editor.IRequire[];
    export const onAfterChange: (mfile: mls.l2.editor.IMFile) => string;
    export const onAfterCompile: (mfile: mls.l2.editor.IMFile) => Promise<void>;
    export const getDesignDetails: (model: mls.l2.editor.IMFile) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export function validateStyle(mfile: mls.l2.editor.IMFile): void;
    export function getLineByText(model: monaco.editor.ITextModel, searchText: string): monaco.Position;
    export function removeTokensFromSource(src: string): string;
    export function removeCommentLines(text: string): string;
    export function getRootSelectors(lessContent: string): string[];
    export function isCommentLine(line: string): boolean;
    export function initDsInstance(): Promise<void>;
    export function getTokensLess(theme: string): Promise<string>;
    export function getTokensList(): Promise<ITokenInfo>;
    export function compileStyleUsingMFile(mfile: mls.l2.editor.IMFile, prefix: ':host' | ':root', theme?: string): Promise<string>;
    export function compileStyleUsingStorFile(shortName: string, project: number, theme?: string): Promise<string>;
    export function setStylesProcessed(newCss: string, el: HTMLElement, tag: string): Promise<void>;
    export function setModelAPI(editor: monaco.editor.IStandaloneCodeEditor, model: monaco.editor.ITextModel | IMonacoModelStyle | undefined): void;
    export interface IMonacoModelStyle extends monaco.editor.ITextModel {
        add(cssLine: string, line: number, refLine?: number): void;
        changeBlock(key: string, value: string, comment: string): void;
        removeLine(line: number): void;
        removeBlankLines(range: monaco.IRange): void;
        getHelperNameByLine(line: number): string;
        isCursorInBlockValid(): boolean;
        haveStartBlock(lines: string[], lineNumber: number): {
            haveStartBlock: boolean;
            line: number;
        };
        haveEndBlock(lines: string[], lineNumber: number): {
            haveEndBlock: boolean;
            line: number;
        };
        isInCommentBlock(lines: string[], lineNumber: number): boolean;
        getBlockInfo(): IBlockInfo;
        getBlockInfoByLine(line: number): IBlockInfo;
        getLessBlock(): IBlockLess | undefined;
        convertRuleToKeyValue(content: string): IBlockLessLine | undefined;
        getLineIndentColumn(line: number): number;
    }
    export interface IBlockLess {
        selector: string;
        lines: IBlockLessLine[];
    }
    export interface IBlockLessLine {
        key: string;
        value: string;
        line: number;
    }
    export interface IBlockInfo {
        selector: string;
        hasStartBlock: boolean;
        startLine: number;
        endLine: number;
        hasEndBlock: boolean;
        isValidBlock: boolean;
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_100554_lessMonaco" {
    /**
     * class to interface with monaco models
     */
    export class MonacoDriver {
        getLines: (url: string) => string[];
        /**
         * Inserts a new line at a specified line number.
         * Returns true if the operation is successful.
         */
        insertLine: (url: string, lineNr: number, line: string) => boolean;
        /**
         * Deletes a specified line number.
         * Returns true if the operation is successful.
         */
        deleteLine: (url: string, lineNr: number) => boolean;
        /**
         * Deletes a specified line numbers.
         * Returns true if the operation is successful.
         */
        deleteLines: (url: string, startLine: number, countLines: number) => boolean;
        /**
         * Updates a specified line at a particular column.
         * Returns true if the operation is successful.
         */
        updateLine: (url: string, lineNr: number, columnNr: number, newText: string) => boolean;
        /**
         * Finalizes the current edit operation group, allowing all previous
         * changes to be undone as a single action.
         */
        finishEdit: (url: string) => void;
    }
}
declare module "_100554_lessAST" {
    import { MonacoDriver } from "_100554_lessMonaco";
    interface ILessAST {
        root: {
            [token: string]: {
                value: string;
                line: number;
                column: number;
            };
        };
        [selector: string]: {
            _startLine?: number;
            _endLine?: number;
            [property: string]: {
                value: string;
                line: number;
                column: number;
            } | number | undefined;
        };
    }
    /**
     * @class LessAst
     *
     * This class parses a LESS model, building an AST and converting LESS selectors
     * into a CSS-compatible format. Note that this implementation supports only a subset
     * of LESS functionalities. Advanced features, such as variable interpolation within selectors,
     * parameterized mixins, and color manipulation functions, are not supported.
     *
     * ### Supported Features
     * - **Basic Selector Nesting**: Supports nesting selectors with `&`, converting them to a CSS-compatible format.
     * - **Simple Variables**: Allows the use of variables within properties (e.g., `@color-primary: #333;`).
     * - **Basic LESS Structure**: Parses basic selectors, properties, and tokens, ignoring advanced logic.
     *
     * ### Unsupported Features
     * - **Variable Interpolation within Selectors**: Selectors like `@{variable}-name` are not expanded in the AST.
     * - **Parameterized Mixins**: Mixins with parameters are not evaluated or expanded.
     * - **Mathematical and Color Functions**: Functions like `darken`, `lighten`, or `add` are not processed.
     * - **Looping and Iteration**: Constructs such as `each` or `for` are ignored, as they are not supported in CSS.
     * - **Global Scope Management**: Selectors with `:global` will not retain global scoping behavior.
     *
     * ### Usage Example
     * ```typescript
     * const lessAst = new LessAst("your-url");
     * lessAst.parse();
     * const cssSelector = lessAst.selectorLESS2CSS("less-a-s-t-100554 &:hover");
     * console.log(cssSelector); // Output: less-a-s-t-100554:hover
     * ```
     *
     * ### Limitations
     * Since this class does not handle dynamic processing features of LESS, it is recommended
     * only for static LESS-to-CSS conversions that do not require runtime evaluation.
     */
    export class LessAst {
        ast: ILessAST;
        url: string;
        monacoDriver: MonacoDriver;
        stack: string[];
        constructor(url: string);
        /**
         * parse a full LESS model (monaco editor)
         */
        parse: () => void;
        /**
         * Parses a single line and updates the AST accordingly.
         */
        private parseLine;
        /**
         * Lists all themes available in the AST.
         * Each theme is identified by its selector. If the selector has a `.`, the part after the dot is the theme name.
         * If no dot is present, the theme is named "default".
         *
         * @returns An object where each key is a theme name (e.g., "default", "theme2") and each value is the corresponding selector.
         */
        listThemes(): {
            [themeName: string]: string;
        };
        /**
         * Adds a new theme to the specified component variation.
         *
         * @param variation The name of the new theme variation (e.g., "theme3").
         * @returns `true` if the theme was added successfully, `false` otherwise.
         */
        addTheme(variation: string): boolean;
        /**
         * Deletes a theme from the specified component variation.
         *
         * @param variation The name of the theme variation to delete (e.g., "theme2").
         * If `null`, deletes the "default" theme (the main component selector).
         * @returns `true` if the theme was deleted successfully, `false` otherwise.
         */
        deleteTheme(variation: string | null): boolean;
        /**
         * Retrieves the description comments for a specified theme.
         *
         * @param variation The name of the theme variation (e.g., "theme2").
         *                  If `null`, retrieves the "default" theme.
         * @returns An array of comment lines that describe the theme, or an empty array if no comments are found.
         */
        getThemeDescription(variation: string | null): string[];
        private getThemeRangeLines;
        /**
         * Converts a full CSS selector back to the LESS format using "&" where appropriate.
         * - If the selector parts match a parent selector, it replaces the match with "&".
         *
         * @param selector The CSS selector to convert to LESS format.
         * @returns The converted LESS format selector with "&" where possible.
         */
        selectorCSS2LESS: (selector: string) => string;
        selectorLESS2CSS: (selector: string) => string;
        /**
         * Converts a kebab-case property name to camelCase, e.g., background-color to backgroundColor.
         * This ensures property names align with JavaScript/TypeScript conventions.
         */
        toCamelCaseProperty(property: string): string;
        /**
         * Converts a camelCase property name to kebab-case, e.g., backgroundColor to background-color.
         * This ensures property names align with CSS/LESS conventions.
         */
        toKebabCaseProperty(property: string): string;
        getProperty(selector: string, property: string): string | undefined;
        private updateASTAfterInsertLine;
        saveProperty(selector: string, property: string, newValue: string | undefined): boolean;
        /**
         * Returns the last line number within a selector block. aka "}"
         */
        findLastLineInSelector(selectorLESS: string): number;
        findInfoByLine(selectorLESS: string, lineNumber: number): {
            key: string;
            value: string;
        } | undefined;
        /**
         * Finds the most specific LESS selector path for a given line number in the source.
         * - This method searches the AST to determine the most specific selector block containing the specified line.
         * - It returns the full path of the most deeply nested selector in LESS format (e.g., `.cl1 .cl2 &:hover`).
         *
         * ### Usage
         * This method is useful for identifying the exact selector block a line belongs to, especially
         * in scenarios where nested selectors exist in the LESS structure.
         *
         * @param lineNr The line number to check for a corresponding selector.
         * @returns The most specific LESS selector path as a string if found; otherwise, `undefined`.
         */
        findSelectorByLine(lineNr: number): string | undefined;
        /**
         * Inserts a new selector into the AST and the Monaco model if it does not exist.
         * - Example: If the AST only contains ".cl1" and `newSelectorLESS` is ".cl1 .cl2 &:hover",
         *   the function will:
         *   1. Check if ".cl1 .cl2" exists in the AST.
         *   2. If not, insert ".cl2" as a nested block within ".cl1".
         *   3. Then insert "&:hover" as a nested selector inside ".cl1 .cl2".
         *
         * This function supports nested selectors by iteratively checking each level
         * and inserting any missing selectors in sequence.
         *
         * @param newSelectorLESS The LESS selector to add to the AST and source code.
         * @result start line of the block
         */
        insertSelector(newSelectorLESS: string): number;
    }
}
declare module "_100554_lessCSS" {
    import { LessAst } from "_100554_lessAST";
    export class LessCSS {
        lessAST: LessAst;
        selector: string;
        position: "left" | "right";
        _url: string;
        private _styles;
        styles: CSSStyleDeclaration;
        constructor(url: string, position?: "left" | "right");
        /**
         * Sets the current selector for which properties will be applied.
         */
        setSelector(selector: string): void;
        /**
         * Retrieves a specific CSS property value for the current selector from the AST.
         * @param property The CSS property to retrieve
         */
        getProperty(property: string): string | undefined;
        /**
         * Sets or updates a CSS property in the AST and source model.
         * @param property The CSS property to set
         * @param value The new value for the property
         */
        setProperty(property: string, value: string): void;
        refresh(): void;
        setStateByLine(lineNumber: number, emitter: 'editor' | 'helper' | 'preview'): void;
        private clearState;
        private updateState;
        private initStateIfNeeded;
    }
    export interface ICSSState {
        uri: string;
        selector: string | undefined;
        lineNumber: number | undefined;
        key: string | undefined;
        value: string | undefined;
        lessCSS: LessCSS | undefined;
        emitter: 'editor' | 'helper' | 'preview';
    }
}
declare module "_100554_serviceSource" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceSource100554 extends ServiceBase {
        constructor();
        msize: string;
        panelRightOpened: boolean;
        mode: IModes;
        private MINWIDTHTPANELRIGHT;
        private lessCSS;
        private viewsState;
        createRenderRoot(): this;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        onClickTitle: () => void;
        details: IService;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        getEditorValue(): string;
        setEditorValue(val: string): boolean;
        setEditorValueByLineTs(val: string, line: number): boolean;
        setEditorValueByLineHtml(val: string, line: number): boolean;
        replaceEditorLineHTML(val: string, line: number): boolean;
        searchLineByStringTs(search: string): number | undefined;
        goToLine(line: number): void;
        setEditorHTMLValue(val: string): boolean;
        getEditorHTMLValue(): string;
        private setValueInModeKeepingUndo;
        private setValueInModelInSpecificLine;
        private replaceLineValueInModelInSpecificLine;
        private formatMonaco;
        private c2;
        private verticalSpliter;
        private horizontalSpliter;
        last: mls.IActual | undefined;
        private _ed1;
        private mConfEditor;
        private confE2;
        get confE(): string;
        get confETS(): string;
        get confEJS(): string;
        private saveViewState;
        private restaureViewState;
        private openRepo;
        private showHistory;
        private showHistorie2;
        private showPageTheme;
        private showMonacoReset;
        private showConfEditor;
        private static projectsLoaded;
        private readProjectTypescriptAndCompile;
        private createProjectModel;
        private deleteFile;
        private afterUpdate;
        private addEventsModelTS;
        private removeEventsStorFile;
        private _onChangedContent;
        private onModelChange;
        private getValueInfo;
        private onMonacoEvents;
        private goToPosition;
        private onProjectLoadedEvents;
        private isNewFile;
        private onMLSEvents;
        private deleteFiles;
        private cloneFiles;
        private newFiles;
        private openFiles;
        private renameFiles;
        private updatedOnServer;
        private undoFiles;
        private activeThisService;
        private closeMenu;
        private updateModelStatus;
        private changeStatusFile;
        private renameAllFiles;
        private isNewNameValid;
        private showActiveModel;
        private initMonaco;
        private monacoGlobalInitialized;
        private initMonaco_GlobalEditor;
        private timeHtmlChangeCursor;
        private lastIdSelected;
        private initMonaco_Editor;
        private extractIdValue;
        private loadMonacoConfigurations;
        private getUri;
        private createModelTS_testFile;
        onFirtModel: boolean;
        private createModelTS_loading;
        private createModelTS_clone;
        private changeClassName;
        private createModelTS1;
        private createModelTS2;
        private createModel;
        private setModelConfEditor;
        private createModelConf;
        timeout_compileConfEditor: number;
        private compileSrcEditor;
        private loadConfEditorFromLocalStorage;
        private saveConfEditorToLocalStorage;
        private loadMonacoThemeFromLocalStorage;
        private saveMonacoGlobalThemeToLS;
        private getConfEditorToTypescript;
        private setConfEditorFromJavascript;
        private updateMonacoConfigutarions;
        private updateMonacoGlobalTheme;
        private getGlobalPageSetTHeme;
        private createOrShowModelHtmlOrCss;
        private prepareInitialLess;
        private createHtmlOrCssFile;
        private getOrCreateModelHtmlOrCss;
        private setEventsModelHTMLOrCss;
        private afterUpdateHtmlOrCss;
        private getValueInfoHtmlOrCss;
        private _onChangedContentHtmlOrCss;
        private onModelHtmlOrCssChange;
        private renameHTMLOrCssFile;
        private tripleslashChangeVariable;
        private isReadOnlyArea;
        private getIntervalLinesReadOnly;
        private updatedMSizeEditor;
        updated(changedProperties: any): void;
        connectedCallback(): void;
        firstUpdated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderPrompt(): import("_100554_litHtml").TemplateResult<1>;
        private saveLocalStorageLastOpen;
        private openLastFile;
        getActualRef(): string;
        private lastScenario;
        private lastOrigin;
        private onWidgetActionEvents;
        private selectLineinHTML;
        private openScenario;
        private closeScenario;
        private createOrSetEvent;
        private createOrSetEventPR;
        private isEventExist;
        private setEventInHTml;
        private registerProviderHTML;
        private isHTMLSystemChange;
        private syncDom;
        private checkToCreateModelHTML;
    }
    type IModes = 'icTs' | 'icStyle' | 'icHTML';
}
declare module "_100554_aimActionAddIca" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    import { IcaSelectGroup } from "_100554_icaSelectGroup";
    import { ServiceSource100554 } from "_100554_serviceSource";
    export class AimActionAddIca extends AimActionBase {
        private msg;
        constructor();
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        textarea: HTMLTextAreaElement | undefined;
        selectGroup: IcaSelectGroup | undefined;
        showPrompt: boolean;
        actualSuggest: string;
        validPrompt: boolean;
        actualAttributes: string[];
        actualGroups: string[];
        language: string;
        private taskRoot;
        private handleCancel;
        private handleAdd;
        private onGroupChanged;
        private clear;
        renderAdd(): TemplateResult;
        prepareCheckTask1(taskRoot: mls.cbe.ITaskRoot): void;
        prepareCheckTask2(taskFinishResult: ITaskFinish): void;
        prepareTask1(taskFinishResult: ITaskFinish): void;
        prepareTask2(taskFinishResult: ITaskFinish): void;
        prepareTask3(taskFinishResult: ITaskFinish): void;
        prepareTask4(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
        private setResultInEditor;
        private extractHTML;
        private extractTS;
        private getPrompt;
        private getPrompt2;
        private getPromptHTML;
        private getPromptCheckPrompt;
    }
    export function isValidRef(taskRoot: mls.cbe.ITaskRoot, activeOpService: ServiceSource100554): boolean;
    export function getActiveOpServiceIfIsValid(el: HTMLElement): ServiceSource100554;
    export interface IArgsAddIca {
        prompt: string;
        group: string[];
        attr: string[];
    }
}
declare module "_100554_collabIcons" {
    export const collab_copy: any;
    export const collab_check: any;
    export const collab_double_check: any;
    export const collab_file: any;
    export const collab_location_dot: any;
    export const collab_rotate_left: any;
    export const collab_bug: any;
    export const collab_bug_x12: any;
    export const collab_unbalanced: any;
    export const collab_info: any;
    export const collab_info_circle: any;
    export const collab_question: any;
    export const collab_heart: any;
    export const collab_heart_o: any;
    export const collab_angles_right: any;
    export const collab_chevron_right: any;
    export const collab_chevron_left: any;
    export const collab_chevron_down: any;
    export const collab_undo: any;
    export const collab_clone: any;
    export const collab_file_pen: any;
    export const collab_trash: any;
    export const collab_ellipsis_vertical: any;
    export const collab_ban: any;
    export const collab_file_signature: any;
    export const collab_calendar_days: any;
    export const collab_user: any;
    export const collab_book: any;
    export const collab_list_check: any;
    export const collab_folder_tree: any;
    export const collab_cube: any;
    export const collab_pen_nib: any;
    export const collab_plus: any;
    export const collab_pencil: any;
    export const collab_cubes: any;
    export const collab_floppy_disk: any;
    export const collab_xmark: any;
    export const collab_arrow_up_long: any;
    export const collab_arrow_down_long: any;
    export const collab_caret_righttv: any;
    export const collab_repeat: any;
    export const collab_thumbs_down_solid: any;
    export const collab_thumbs_down: any;
    export const collab_thumbs_up_solid: any;
    export const collab_thumbs_up: any;
    export const collab_edit_style: any;
    export const collab_play: any;
    export const collab_pause: any;
    export const collab_eye: any;
    export const collab_eye_slash: any;
    export const collab_commit: any;
    export const collab_branch: any;
    export const collab_pull_request: any;
    export const collab_arrows_rotate: any;
    export const collab_circle_notch: any;
    export const collab_triangle_exclamation: any;
    export const collab_gear: any;
    export const collab_spinner_clock: any;
    export const collab_lock: any;
    export const collab_lock_open: any;
    export const collab_image: any;
    export const collab_unsplash: any;
    export const collab_video: any;
    export const collab_code: any;
    export const collab_ellipsis: any;
    export const collab_link: any;
    export const collab_border_top: any;
    export const collab_border_left: any;
    export const collab_border_bottom: any;
    export const collab_border_right: any;
    export const collab_border_topLeft: any;
    export const collab_border_bottomLeft: any;
    export const collab_border_bottomRight: any;
    export const collab_border_topRight: any;
    export const collab_margin_top: any;
    export const collab_margin_left: any;
    export const collab_margin_bottom: any;
    export const collab_margin_right: any;
    export const collab_padding_top: any;
    export const collab_padding_left: any;
    export const collab_padding_bottom: any;
    export const collab_padding_right: any;
}
declare module "_100554_aimSelectWidget" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export function initAimSelectWidget100554(): boolean;
    export class AimSelectWidget100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        get value(): string[];
        height: number;
        defaultValue: string[];
        listcontainer: HTMLElement | undefined;
        inpSearch: HTMLInputElement | undefined;
        gridItems: HTMLElement[] | undefined;
        getFilesNames(): string[];
        private handleSearch;
        private handleSelectAll;
        private handleClearAll;
        private handleConfirm;
        private handleCancel;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_collabLanguages" {
    export const languages: ICollabLanguage[];
    export interface ICollabLanguage {
        code: string;
        name: string;
    }
}
declare module "_100554_aimSelectLanguage" {
    import { CollabLitElement } from "_100554_collabLitElement";
    import { ICollabLanguage } from "_100554_collabLanguages";
    export function initAimSelectLanguage100554(): boolean;
    export class AimSelectLanguage100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        get value(): string[];
        height: number;
        defaultValue: ICollabLanguage[];
        listcontainer: HTMLElement | undefined;
        inpSearch: HTMLInputElement | undefined;
        gridItems: HTMLElement[] | undefined;
        getLanguages(): ICollabLanguage[];
        private handleSearch;
        private handleSelectAll;
        private handleClearAll;
        private handleConfirm;
        private handleCancel;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_aimTaskBase" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimBase } from "_100554_aimBase";
    export abstract class AimTaskBase extends AimBase {
        childIndex: number;
        taskRoot: mls.cbe.ITaskRoot;
        taskChild: mls.cbe.ITaskChild;
        createRenderRoot(): this;
        abstract onInitializing(): void;
        render(): TemplateResult<1>;
        renderTaskStatus(): TemplateResult<1>;
        initTaskRootAndTaskChild(): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): TemplateResult<1>;
        renderDetails(title: string, body: string): TemplateResult;
        renderTraceList(title: string, child: mls.cbe.ITaskChild): TemplateResult<1>;
        locateDateTimeInTrace(line: string): string;
        sendFinishedNotification(detail: ITaskFinish): void;
        notifyCompleteByStatus(status: 'ok' | 'error' | 'rejected' | 'userEvent', result: string, prompt?: string): void;
    }
}
declare module "_100554_aimActionVerifyInternationalization" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    export class AimActionVerifyInternationalization extends AimActionBase {
        constructor();
        private msg;
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        private info;
        render(): TemplateResult;
        language: string;
        private handleCancel;
        private handleAddL5;
        private handleAdd;
        addTask(project: number, shortName: string): void;
        renderAdd(): TemplateResult;
        getPrompt(source: string): string;
        prepareTask1(taskRoot: mls.cbe.ITaskRoot, ref: string): void;
        prepareTask2(taskFinishResult: ITaskFinish): void;
        prepareTask3(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
    }
    export interface ITaskRootArgs {
        fileName: string;
    }
}
declare module "_100554_aimTaskGetSourceLanguageTypescript" {
    export function getDataInternationalization(sourceComplete: string): {
        internationalization: IInternationalizationsDetails;
        source: string;
        sourceComplete: string;
    };
    export interface IInternationalizationsDetails {
        startLine: number;
        endLine: number;
        source: string;
        languages: string[];
    }
    export interface ISourceTypescriptData {
        source: string;
        internationalization: IInternationalizationsDetails | undefined;
        sourceComplete: string;
    }
}
declare module "_100554_aimAddLanguageBase" {
    import { ICollabLanguage } from "_100554_collabLanguages";
    import { IInternationalizationsDetails } from "_100554_aimTaskGetSourceLanguageTypescript";
    export interface ITaskRootArgsInitial {
        project: number;
        fileName: string;
        languages: ICollabLanguage[];
        onlyLanguageDontConfigured: boolean;
    }
    export interface ITaskFileInfo {
        fileName: string;
        checkHtml: boolean;
        checkTs: boolean;
        detailsi18n: IInternationalizationsDetails | undefined;
        html: string;
        attributesHTML: string[];
        htmlTags: string[];
        attributesHTMLWithLanguages: string[];
        languages: ICollabLanguage[];
        onlyLanguageDontConfigured: boolean;
    }
}
declare module "_100554_aimActionAddLanguage" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    import { ICollabLanguage } from "_100554_collabLanguages";
    export class AimActionAddLanguage extends AimActionBase {
        constructor();
        currentScenario: IScenaries;
        level: number;
        height: number;
        widgets: string[];
        languages: ICollabLanguage[];
        onlyLanguageDontConfigured: boolean;
        private msg;
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        private info;
        render(): TemplateResult;
        language: string;
        private handleCancel;
        private changeScenario;
        private handleSelectLanguageConfirm;
        private handleSelectWidgetConfirm;
        private handleCancel2;
        private handleCheckConfig;
        private handleAdd;
        addTask(project: number, fileName: string): void;
        renderAdd(): TemplateResult;
        getPromptTs(source: string, languages: ICollabLanguage[]): string;
        getPromptHTML(source: string, attributesHTMLWithLanguages: string[], languages: ICollabLanguage[]): string;
        prepareTask1(taskRoot: mls.cbe.ITaskRoot, fileName: string, project: number): void;
        prepareTaskPromptTs(taskFinishResult: ITaskFinish): void;
        prepareTaskResultTs(taskFinishResult: ITaskFinish): void;
        prepareTaskPromptHTML(taskFinishResult: ITaskFinish): void;
        prepareTaskResultHTML(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
    }
    type IScenaries = 'main' | 'selectLanguage' | 'selectWidget';
}
declare module "_100554_serviceDsStyles" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyles extends ServiceBase {
        private msg;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        setEditorSource(less: string): Promise<void>;
        getEditorSource(): string;
        getEditorComponentSource(): string;
        getActualRef(): string;
        static modelCount: number;
        msize: string;
        isComponent: boolean;
        private stylesComponent;
        private modeComponent;
        private firstStyleIndex;
        private actionsMode;
        private c2;
        private selectStyles;
        private inputAddStyles;
        private containerHelpers;
        private helperDiv;
        _ed1: monaco.editor.IStandaloneCodeEditor | undefined;
        private timeoutChangesEditorStyle;
        private timeoutCursorChangesEditorStyle;
        private componentName;
        private isStyleRename;
        private isSetStyle;
        private oldStyleName;
        private rightServiceOpened;
        private dsInstance;
        private lastEditorInfo;
        private models;
        private defaultServices;
        createRenderRoot(): this;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        private start1;
        private reinit;
        private init;
        private setEvents;
        private checkComponentOpenInL2;
        private showStyle;
        private openRepo;
        private showResultCss;
        private delay;
        private createEditor;
        private getUri;
        private isEventAdd;
        private setModelAPI;
        private getModelOrCreate;
        private getModelComponentKey;
        private getActualModel;
        private setStyle;
        private getIntervalLinesReadOnly;
        private changeEditor;
        private getParamsServices;
        private showStyle2;
        private onEditorChange;
        private removeTokensForSource;
        private onAfterAdd;
        private onChangeEditorIfComponent;
        private saveStyleLess;
        private renameStyleComponent;
        private checkIfValidComponentStyle;
        private checkIfFirtsLineCorrect;
        private extractErrorDetails;
        private clearErrors;
        private setErrorOnEditor;
        private getServiceRightOpened;
        private onCursorChange;
        private isReadOnlyArea;
        private isReadOnlyAreaIfIsComponent;
        private initDsInstance;
        private getStyle;
        private actualTheme;
        private getTokens;
        private openServiceHelper;
        private onDSStyleChanged;
        private onChangeWidgetStyle;
        private onAddWidgetStyle;
        private onDeleteWidgetStyle;
        private onRenameWidgetStyle;
        private loadStylesComponent;
        private handleChangeSelectStyles;
        private showConfirmMode;
        private showActionsMode;
        private showDefaultMode;
        private handleAddStylesClick;
        private handleRenameStylesClick;
        private handleDeleteStylesClick;
        private handleCancelStylesClick;
        private handleConfirmStylesClick;
        private getWidgetTagName;
        updated(changedProperties: any): void;
        private setMsizeEditor;
        isHelperContainerOpen: boolean;
        private helpers;
        private handleOpenHelperClick;
        private onDetailsHelperClick;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private myStyle;
    }
}
declare module "_100554_aimActionStyleNew" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    import { ServiceDsStyles } from "_100554_serviceDsStyles";
    export class AimActionStyleNew extends AimActionBase {
        private msg;
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        textarea: HTMLTextAreaElement | undefined;
        language: string;
        private handleCancel;
        private taskRoot;
        private handleAdd;
        private setResultInEditor;
        private onSuggestClick;
        private prompts;
        renderAdd(): TemplateResult;
        private getPrompt;
        prepareTask1(taskRoot: mls.cbe.ITaskRoot): void;
        prepareTask2(taskFinishResult: ITaskFinish): void;
        prepareTask3(taskFinishResult: ITaskFinish): void;
        prepareTask4(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
    }
    export function isValidRef(taskRoot: mls.cbe.ITaskRoot, activeOpService: ServiceDsStyles): boolean;
    export function getActiveOpServiceIfIsValid(el: HTMLElement): ServiceDsStyles;
}
declare module "_100554_aimActionTokensNew" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    export class AimActionTokensNew extends AimActionBase {
        private msg;
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        textarea: HTMLTextAreaElement | undefined;
        language: string;
        render(): TemplateResult;
        private handleCancel;
        private handleAdd;
        private onSuggestClick;
        private prompts;
        renderAdd(): TemplateResult;
        getPrompt(source: string, user: string): string;
        prepareTask1(taskRoot: mls.cbe.ITaskRoot): void;
        prepareTask2(taskFinishResult: ITaskFinish): void;
        prepareTask3(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
    }
}
declare module "_100554_aimActionTypescriptSpell" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    export class AimActionTypescriptSpell extends AimActionBase {
        private msg;
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        language: string;
        private handleCancel;
        private handleAdd;
        renderAdd(): TemplateResult;
        getPrompt2(source: string): string;
        getPrompt(source: string): string;
        prepareTask1(taskRoot: mls.cbe.ITaskRoot): void;
        prepareTask2(taskFinishResult: ITaskFinish): void;
        prepareTask3(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
    }
}
declare module "_100554_aimActionUpdateLit" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    export class AimActionUpdateLit extends AimActionBase {
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        language: string;
        private handleCancel;
        renderAdd(): TemplateResult;
        add(args: IAdd): number;
        prepareTaskExe(args: IAdd, taskRoot: mls.cbe.ITaskRoot): void;
        prepareTaskResult(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
        updateModelTS(newContent: string, fileRef: string, key: string, modelType: mls.editor.ModelType): Promise<void>;
        loadModelTS(fileRef: string): Promise<void>;
    }
    export interface IAdd {
        title: string;
        prompt: string;
        error: string;
        modelType: mls.editor.ModelType;
        fileRef: string;
    }
    export const add: (args: IAdd) => number;
}
declare module "_100554_aimActionUserPrompt" {
    import { TemplateResult } from "_100554_litElement";
    import { ITaskFinish } from "_100554_aimHelper";
    import { AimActionBase, AimActionRules } from "_100554_aimActionBase";
    export class AimActionUserPrompt extends AimActionBase {
        private msg;
        getRules(): AimActionRules[];
        assistant: string;
        title: string;
        private taskRoot;
        textareaAdd: HTMLTextAreaElement | undefined;
        textareaPrompt: HTMLTextAreaElement | undefined;
        modeInternal: mls.cbe.IMode | undefined;
        isLoading: boolean;
        render(): TemplateResult;
        renderTaskRoot(): TemplateResult;
        private renderResult;
        private prepareChat;
        private formatText;
        private handleConfirm;
        private handleOk;
        private handleCancel;
        private handleAdd;
        private openMe;
        prepareTask1(taskRoot: mls.cbe.ITaskRoot): void;
        prepareTaskWaitUser(taskFinishResult: ITaskFinish): void;
        endTasks(taskFinishResult: ITaskFinish): void;
        renderAdd(): TemplateResult;
    }
    export interface IArgsAddIca {
        prompt: string;
    }
}
declare module "_100554_aimList" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class AimActionList extends CollabLitElement {
        static styles: import("_100554_litCssTag").CSSResult;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_aimPromptExample" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class AimPromptExample extends CollabLitElement {
        text: string;
        for: string;
        static styles: import("_100554_litCssTag").CSSResult;
        handleClick(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_aimPrompt" {
    import "_100554_aimPromptExample";
    import { IcaLitElement } from "_100554_icaLitElement";
    export class AimPrompt extends IcaLitElement {
        static styles: import("_100554_litCssTag").CSSResult;
        private msg;
        text: string;
        dataForDetails: mls.events.IPluginDetail | any;
        render(): import("_100554_litHtml").TemplateResult<1>;
        EVENTPROMPTNAME: string;
        private handleClick;
        firstUpdated(): void;
        private listenPromptChange;
        private exePrompt;
        private isInIframe;
        private isInDetail;
        private handleFocus;
        private handleInput;
        handleCollabStateChange(changedKey: string, value: any): void;
        private setLastPromptDetails;
        private getModelFromLastPromptDetails;
    }
}
declare module "_100554_aimPromptTypescript" {
    import { TemplateResult } from "_100554_litElement";
    import "_100554_aimPromptExample";
    import "_100554_aimActionUpdateLit";
    import "_100554_aimList";
    import { IcaLitElement } from "_100554_icaLitElement";
    export class aimPromptTypeScript extends IcaLitElement {
        private msg;
        /**
         * This widget can be used in 3 contexts:
         * - in the editor -> renderMode = 'editor'
         * - in service detail -> renderMode = 'detail'
         * - in preview (default) -> renderMode = 'desenv'
         */
        renderMode: 'editor' | 'detail' | 'desenv';
        /**
         * Model key used to find the file and model.
         * Example: _100111_file1 (without extension).
         * If modelKey === "", show input.
         */
        modelKey: string;
        /**
         * Text being edited.
         */
        text: string;
        isLoaded: boolean;
        connectedCallback(): Promise<void>;
        render(): TemplateResult;
        renderChoiceModelKey(isError: boolean): TemplateResult;
        renderTask(): TemplateResult;
        validateModelKey(): boolean;
        private handleFocus;
        private handleInput;
        taskid: number;
        private handleClick;
        private isInIframe;
        private isInDetail;
        private getPrompt;
    }
}
declare module "_100554_aimTaskDsStyles" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskDsStyles extends AimTaskBase {
        onInitializing(): void;
        getSource(): void;
        getStyle(): Promise<string>;
    }
}
declare module "_100554_serviceDsTokens" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsTokens100554 extends ServiceBase {
        private msg;
        constructor();
        msize: string;
        actualTheme: string;
        currentScenario: IScenaries;
        themes: IThemes[];
        inpName: HTMLInputElement | undefined;
        inpDesc: HTMLTextAreaElement | undefined;
        createRenderRoot(): this;
        details: IService;
        onClickIcon: (op: string) => void;
        onClickTitle: () => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        getActualRef(): string;
        setEditorSource(tokens: string, tokensType: string): Promise<void>;
        getEditorSource(): string;
        static modelCount: number;
        private _ed1;
        private timeoutChangesEditorColor;
        private timeoutChangesEditorTypography;
        private timeoutChangesEditorGlobal;
        private c2;
        private models;
        private dsInstance;
        private setTokens;
        private tokensColors;
        private tokensTypo;
        private tokensGlobal;
        private actualTypeTokens;
        private getTokens;
        private createEditor;
        private getUri;
        private setInitialModels;
        private showGlobal;
        private showTypography;
        private showColors;
        private fireEvent;
        private onEditorColorChange;
        private onEditorTypoChange;
        private onEditorGlobalChange;
        private getEditorsTokens;
        private getEditorJsonKeyValue;
        private convertTokenLineEditorToKeyValue;
        private setMsizeEditor;
        private _onClickTitle;
        private getThemes;
        private clearInputs;
        private onSaveThemeClick;
        private onSelectTheme;
        private deleteTheme;
        updated(changedProperties: any): void;
        firstUpdated(changedProperties: any): void;
        renderEditor(): import("_100554_litHtml").TemplateResult<1>;
        renderSelect(): import("_100554_litHtml").TemplateResult<1>;
        renderScenario(): import("_100554_litHtml").TemplateResult<1>;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private styles;
    }
    type IScenaries = 'editor' | 'select';
    interface IThemes {
        themeName: string;
        description: string;
        pallete: string[];
    }
}
declare module "_100554_aimTaskDsTokens" { }
declare module "_100554_aimTaskExecLLM" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskExecLLM extends AimTaskBase {
        onInitializing(): void;
        senderToServer(taskRoot: mls.cbe.ITaskRoot): void;
        onIconClick(action: string): void;
    }
}
declare module "_100554_aimTaskGetSourceLanguages" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskGetSourceLanguages extends AimTaskBase {
        onInitializing(): void;
        getSource(): void;
        private prepareInfoFile;
        private prepareHTMLInfo;
        private allElementsPresent;
        private analyzeHTML;
        private parseHtmlString;
    }
}
declare module "_100554_aimTaskPrepareIcaSource" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskPrepareIcaSource extends AimTaskBase {
        onInitializing(): void;
        getSource(): void;
        private _getSource;
    }
}
declare module "_100554_collabShowCodeDiff" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export function initCollabShowCodeDiff100554(): boolean;
    export class CollabShowCodeDiff extends CollabLitElement {
        private msg;
        static monaco_css: string;
        static inLoadingCss: boolean;
        static loadingPromise: Promise<string>;
        msize: string;
        language: string;
        withCopy: boolean;
        withAccept: boolean;
        withReject: boolean;
        withTryAgain: boolean;
        withDiff: boolean;
        coping: boolean;
        onAccept: Function | undefined;
        onReject: Function | undefined;
        onTryAgain: Function | undefined;
        private _ed1Diff;
        private _ed1Result;
        private modelResult;
        private modelDiffOriginal;
        private modelDiffModified;
        private actualEditor;
        actualTextDiffOriginal: string;
        actualTextDiffModified: string;
        actualTextResult: string;
        private c1;
        private inputDiff;
        init(): void;
        private createEditorDiff;
        private createEditorResult;
        private createModelDiff;
        private createModelResult;
        private setDiffValue;
        private setResultValue;
        private setMsizeEditor;
        private onCopyClick;
        private onAcceptClick;
        private onRejectClick;
        private onTryAgainClick;
        private getCssMonaco;
        private styleElement;
        loadCSS(): Promise<void>;
        private renderWithCopy;
        private renderWithAccept;
        private renderTryAgain;
        private renderReject;
        private handleChangeDiff;
        private renderShowDiff;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_aimTaskResultAddIca" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    import { CollabShowCodeDiff } from "_100554_collabShowCodeDiff";
    export class AimTaskResulAddIca extends AimTaskBase {
        private msg;
        constructor();
        codeDiff: CollabShowCodeDiff | undefined;
        detailsResult: HTMLDetailsElement | undefined;
        textarea: HTMLTextAreaElement | undefined;
        withDiff: boolean;
        isTryAgain: boolean;
        isAccept: boolean;
        modeInternal: mls.cbe.IMode | undefined;
        private result;
        onInitializing(): void;
        private setValues;
        private alreadyInit;
        handleClick(e: Event): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
        private renderAccept;
        private renderTryAgain;
        private onSuggestClick;
        private getFcToImplements;
        private closeMe;
        private openMe;
        private handleCancelTryAgain;
        private handleConfirmTryAgain;
        private handleCancelAcceptHTML;
        private handleConfirmAcceptHTML;
        private onAccept;
        private onReject;
        private onTryAgain;
        private extractBlocks;
    }
}
declare module "_100554_aimTaskResultAddIcaPrompt" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskResulAddIcaPrompt extends AimTaskBase {
        private msg;
        private result;
        modeInternal: mls.cbe.IMode | undefined;
        hasError: boolean;
        textarea: HTMLTextAreaElement | undefined;
        onInitializing(): void;
        private getResult;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
        private renderListSuggestions;
        private closeMe;
        private openMe;
        private handleCancelTryAgain;
        private handleConfirmTryAgain;
    }
}
declare module "_100554_aimTaskResultCode" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    import { CollabShowCodeDiff } from "_100554_collabShowCodeDiff";
    export class AimTaskResultCode extends AimTaskBase {
        codeDif: CollabShowCodeDiff | undefined;
        private result;
        constructor();
        onInitializing(): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
        private onAccept;
        firstUpdated(a: any): void;
    }
}
declare module "_100554_aimTaskResultLanguageHtml" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    import { CollabShowCodeDiff } from "_100554_collabShowCodeDiff";
    export class AimTaskResultLanguageTypescript extends AimTaskBase {
        constructor();
        codeDiff: CollabShowCodeDiff | undefined;
        onInitializing(): void;
        changeFile(taskRoot: mls.cbe.ITaskRoot): void;
        private extractHtml;
        private result;
        private original;
        private alreadyInit;
        handleClick(taskRoot: mls.cbe.ITaskRoot): void;
        private setValues;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
        onIconClick(action: string): void;
    }
}
declare module "_100554_aimTaskResultLanguageTypescript" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskResultLanguageTypescript extends AimTaskBase {
        onInitializing(): void;
        changeFile(taskRoot: mls.cbe.ITaskRoot): void;
        private extractScript;
        onIconClick(action: string): void;
    }
}
declare module "_100554_aimTaskResultLess" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    import { CollabShowCodeDiff } from "_100554_collabShowCodeDiff";
    export class AimTaskResultLess extends AimTaskBase {
        private msg;
        constructor();
        codeDiff: CollabShowCodeDiff | undefined;
        detailsResult: HTMLDetailsElement | undefined;
        textarea: HTMLTextAreaElement | undefined;
        withDiff: boolean;
        isTryAgain: boolean;
        modeInternal: mls.cbe.IMode | undefined;
        private result;
        onInitializing(): void;
        private setValues;
        private alreadyInit;
        handleClick(e: Event): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
        private closeMe;
        private openMe;
        private handleCancelTryAgain;
        private handleConfirmTryAgain;
        private onAccept;
        private onReject;
        private onTryAgain;
        private extractBlocks;
    }
}
declare module "_100554_aimTaskResultTable" {
    import { TemplateResult } from "_100554_litElement";
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskResultTable extends AimTaskBase {
        onInitializing(): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): TemplateResult<1>;
        parseTable(body: string): string[][];
        parseTable2(body: string): string[][];
        renderTable2(tab1: string[][]): TemplateResult<1>;
    }
}
declare module "_100554_aimTaskResultText" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskResultText extends AimTaskBase {
        onInitializing(): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_aimTaskResultTokens" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    import { CollabShowCodeDiff } from "_100554_collabShowCodeDiff";
    export class AimTaskResultTokens extends AimTaskBase {
        constructor();
        codeDiff: CollabShowCodeDiff | undefined;
        private result;
        onInitializing(): void;
        firstUpdated(a: any): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
        private onToogleDetails;
        private setTokensDiff;
        private getActiveOpServiceIfIsValid;
        private onAccept;
        private extractBlocks;
    }
}
declare module "_100554_aimTaskResultUserPrompt" {
    import { AimTaskBase } from "_100554_aimTaskBase";
    export class AimTaskResulUserPrompt extends AimTaskBase {
        constructor();
        private msg;
        textarea: HTMLTextAreaElement | undefined;
        modeInternal: mls.cbe.IMode | undefined;
        private result;
        onInitializing(): void;
        renderBody(taskRoot: mls.cbe.ITaskRoot, child: mls.cbe.ITaskChild): import("_100554_litHtml").TemplateResult<1>;
        private prepareChat;
        private formatText;
        private openMe;
        private closeMe;
        private handleCancel;
        private handleConfirm;
    }
}
declare module "_100554_aimTaskTSSource" { }
declare module "_100554_ateste" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class SimpleGreeting extends CollabLitElement {
        createRenderRoot(): this;
        name: string;
        handleConfirm(e: CustomEvent): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_propiertiesLit" {
    export function getPropierties(model: mls.l2.editor.IMFile): mls.l2.enhancement.IProperties[];
    export interface IMember {
        name: string;
        pos: number;
        type: string;
        comment: string;
        modifiers: string[];
        tags: ITag[];
        parameters?: IParameter[];
        initializerText: string;
        initializerType: string;
    }
    export interface ITag {
        name: string;
        pos: number;
        tagName: string;
        comment: string;
    }
    export interface IParameter {
        name: string;
        comment: string;
        type: string;
        modifiers: string[];
    }
    export interface IJSDoc {
        name: string;
        pos: number;
        type: string;
        comment: string;
        members: IMember[];
        tags: ITag[];
    }
    export interface IDecoratorClassInfo {
        decoratorName: string;
        tagName: string;
    }
    export interface IDecoratorItem {
        line: number;
        character: number;
        text: string;
    }
    export interface IDecoratorDetails {
        parentName: string;
        type: string;
        pos: number;
        decorators: IDecoratorItem[];
    }
    export interface IDecoratorDictionary {
        [key: number]: IDecoratorDetails;
    }
}
declare module "_100554_validateLit" {
    export function validateTagName(mfile: mls.l2.editor.IMFile): boolean;
    export function validateRender(mfile: mls.l2.editor.IMFile): boolean;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_100554_codeLensLit" {
    export function setCodeLens(mfile: mls.l2.editor.IMFile): void;
}
declare module "_100554_collabConfigService" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class CollabConfig100554 extends CollabLitElement {
        private msg;
        currentScenario: 'list' | 'add';
        error: string;
        positionToolbar: ICollabServicePosition;
        actualLevel: number;
        userServices: ICollabService3[];
        avaliableServices: ICollabService3[];
        static styles: import("_100554_litCssTag").CSSResult;
        render(): import("_100554_litHtml").TemplateResult<1>;
        connectedCallback(): Promise<void>;
        private renderHeader;
        private onclickPositionLeft;
        private onclickPositionRight;
        private renderListAddServices;
        private renderListServices;
        private infos;
        private setInfos;
        private goToScenaryAdd;
        private goToScenaryList;
        private openHiddenConfigs;
        private changeClassName;
        private desactiveService;
        private activeService;
        private moveElement;
        private getServices;
        private getAvaliableServices;
        private getUserServices;
        private fireChangeClassName;
        private fireAddService;
        private fireRemoveService;
        private fireMoveService;
    }
    interface ICollabService3 {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        classname?: ICollabServiceClass;
        isStatic?: boolean;
    }
    export interface IService {
        widget: string;
        state: ICollabServiceState;
        icon: string;
        tooltip: string;
        visible: boolean;
        position: "left" | "right" | "all";
        level: number[];
        classname?: ICollabServiceClass;
        isStatic?: boolean;
    }
    type ICollabServicePosition = "left" | "right";
    type ICollabServiceState = "foreground" | "background";
    type ICollabServiceClass = "separator-left" | "separator-right";
}
declare module "_100554_collabDsInputRange" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export function initCollabDSInputRange(): void;
    export class CollabDSInputRange extends IcaLitElement {
        arraySelect: string[];
        useSelect: string;
        value: string;
        prop: string;
        min: number;
        max: number;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderSelect(): import("_100554_litHtml").TemplateResult<1>;
        updated(): void;
        private onlyNumber;
        private onlyTxt;
        private changeInput;
        private changeSelect;
        private allChange;
        private fireEvents;
    }
}
declare module "_100554_collabDsInputSelectColor" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export function initCollabDsInputSelectColor(): void;
    export class CollabDsInputSelectColor extends CollabLitElement {
        get value(): string;
        set value(str: string);
        arrayInputSelect: string[];
        arraySelect: string[];
        valueInput: string;
        valueSelect: string;
        valueColor: string;
        prop: string;
        useInput: string;
        useSelect: string;
        useColor: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderInput(): import("_100554_litHtml").TemplateResult<1>;
        renderSelect(): import("_100554_litHtml").TemplateResult<1>;
        renderColor(): import("_100554_litHtml").TemplateResult<1>;
        updated(): void;
        private configGetValue;
        private configSetValue;
        private onlyNumber;
        private onlyTxt;
        private allChange;
        private fireEvents;
    }
}
declare module "_100554_collabEditMd" {
    import { LitElement } from "_100554_litElement";
    export function initEditorQuillMD(): boolean;
    export class CollabEditMd extends LitElement {
        private value;
        private opened;
        containerEditor: HTMLElement | undefined;
        containerQuillEditor: HTMLTextAreaElement | undefined;
        iconFinish: HTMLElement | undefined;
        iconEdit: HTMLElement | undefined;
        set cbFinishEdit(fc: Function);
        get text(): any;
        firstUpdated(changedProperties: any): void;
        private cbFinishFc;
        private openedToolbar;
        id: string;
        easyMDE: any;
        editor: any;
        private initEditor;
        private onOpenedChanged;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private _initEditor;
        private onEditClick;
        private onFinishClick;
        render(): import("_100554_litHtml").TemplateResult<1>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_collabIcaConfigAttributes" {
    import { ServiceBase } from "_100554_serviceBase";
    import { CollabLitElement } from "_100554_collabLitElement";
    export const initCollabICATree = "";
    export class CollabICAAttributes extends CollabLitElement {
        private msg;
        myParent: ServiceBase | undefined;
        myAttributes: {
            key: string;
            value: string;
        }[];
        constructor();
        createRenderRoot(): this;
        shouldUpdate(changedProperties: Map<string | number | symbol, unknown>): boolean;
        render(): import("_100554_litHtml").TemplateResult<1>;
        createItens(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(item: {
            key: string;
            value: string;
        }, idx: string): import("_100554_litHtml").TemplateResult<1>;
        forceUpdate(): void;
        private servicePreview;
        private setServicePreview;
        private getMyAttributes;
        private myCss;
    }
}
declare module "_100554_collabIcaTree" {
    import { ServiceBase } from "_100554_serviceBase";
    import { CollabLitElement } from "_100554_collabLitElement";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export const initCollabICATree = "";
    export class CollabFCATree extends CollabLitElement {
        private msg;
        myParent: ServiceBase | undefined;
        constructor();
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        createNavigation(array: IInfoElCholdren[]): import("_100554_litHtml").TemplateResult<1>;
        renderItemTree(item: IInfoElCholdren, idx: string): import("_100554_litHtml").TemplateResult<1>;
        forceUpdate(): void;
        private servicePreview;
        private setServicePreview;
        private getICAComponents;
        private idLastClick;
        private selectItem;
        private clickGroupHidden;
        private setLock;
        private delEl;
        private activeMove;
        private setDragDrop;
        private mouseOver;
        private mouseLeave;
        private myCss;
    }
    interface IInfoElCholdren {
        el: IcaLitElementBase;
        children: IInfoElCholdren[];
    }
}
declare module "_100554_collabInputTag" {
    import { LitElement } from "_100554_litElement";
    export function initCollabInputTag(): boolean;
    export class CollabInputTag extends LitElement {
        static styles: import("_100554_litCssTag").CSSResult;
        tags: string[];
        input: HTMLInputElement | undefined;
        allowDelete: boolean;
        get value(): string;
        set value(val: string);
        onValueChanged: Function | undefined;
        addTag(tag: string): void;
        deleteTag(index: number): void;
        empty(): void;
        private _addTag;
        private _deleteTag;
        private _empty;
        private onInputKeyDown;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_collabJsonType" {
    import { LitElement } from "_100554_litElement";
    export class CollabFCATree extends LitElement {
        json: any;
        jsonInfo: any;
        connectedCallback(): void;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderJson(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(item: any, idx: number): import("_100554_litHtml").TemplateResult<1>;
        private init;
        private generateJsonFromInterface;
        private exemploUsuario;
    }
}
declare module "_100554_collabLogLine" {
    import { LitElement } from "_100554_litElement";
    export class CollabLogLine100554 extends LitElement {
        static styles: import("_100554_litCssTag").CSSResult;
        text: string;
        status: ILogStatus;
        private iconsByStatus;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    export type ILogStatus = 'waiting' | 'inprogress' | 'finish' | 'error';
    export type IIconsByStatus = {
        [key in ILogStatus]: string;
    };
}
declare module "_100554_templatesNewProject" {
    export const template_tsconfig: {
        ext: string;
        template: string;
    };
    export const template_package: {
        ext: string;
        template: string;
    };
    export const template_build: {
        ext: string;
        template: string;
    };
}
declare module "_100554_collabNewProject" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class CollabNewProject extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        NEWREPONAME: string;
        VALIDADEFILE: string;
        driverSelected: boolean;
        orgSelected: boolean;
        loadingAdd1Msg: string;
        orgsLoaded: boolean;
        actualOrgs: mls.stor.others.IOrg[];
        actualTeams: string[];
        isValidProjectName: boolean;
        errorDriver: string;
        logs: ILogs[];
        inputProjectName: HTMLInputElement | undefined;
        form: HTMLFormElement | undefined;
        logsContainer: HTMLDivElement | undefined;
        step1: HTMLDivElement | undefined;
        step2: HTMLDivElement | undefined;
        step3: HTMLDivElement | undefined;
        progress: HTMLDivElement | undefined;
        newProjectName: string;
        newProjectNumber: number;
        newProjectTeam: string;
        newProjectVisibility: string;
        newProjectUpdateMode: string;
        driverName: string;
        orgName: string;
        instanceDriver: mls.stor.others.DriverIOBase | undefined;
        login: string;
        private drivers;
        private urls;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private toogleForm;
        private onSelectDriverChange;
        private onOrgChanged;
        private loadOrgsByDriver;
        private getOrgsByUser;
        private loadTeamByOrg;
        private addLog;
        private changeStatusLastLog;
        private tryItem;
        private setProgress;
        private setProgressError;
        private setProgressFinished;
        private checkIsValidProjectName;
        private onCreateProjectClick;
        private createConfigFile;
        private createInitialReadMe;
        private createInitialBuildFile;
        private createInitialConfigFile;
        private createInitialPackageFile;
        private onCardClick;
        private onRefreshOrgsClick;
        private getLoginUser;
    }
    interface ILogs {
        pre: string;
        log: string;
        status: string;
    }
}
declare module "_100554_collabPanelItem" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class CollabPanelItem extends CollabLitElement {
        widget: string;
        badge: string;
        loading: string;
        private myInfo;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private clickItem;
        private setMyInfo;
    }
}
declare module "_100554_collabPanel" {
    import "_100554_collabPanelItem";
    import { CollabLitElement } from "_100554_collabLitElement";
    export class CollabPanel extends CollabLitElement {
        detail: HTMLDetailsElement | undefined;
        open: boolean;
        icon: string;
        myData: mls.plugin.MenuAction[];
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(item: mls.plugin.MenuAction, index: number): import("_100554_litHtml").TemplateResult<1>;
        private changeSummary;
        private minus;
        private plus;
    }
}
declare module "_100554_collabPanelHelper" {
    import { LitElement, PropertyValueMap } from "_100554_litElement";
    export class CollabPanelHelper100554 extends LitElement {
        plugin: string;
        isHelperContainerOpen: boolean;
        containerHelpers: HTMLDivElement | undefined;
        private handleOpenHelperClick;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_collabSelectOneWithDescription" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export const initCollabSelectOneWithDescription = "";
    export class CollabSelectOneWithDescription100554 extends IcaLitElement {
        static styles: import("_100554_litCssTag").CSSResult;
        private msg;
        hint: string | undefined;
        required: boolean;
        disabled: boolean;
        label: string | undefined;
        options: IOptionItem[] | undefined;
        selectedvalue: string | undefined;
        select_container: HTMLDivElement | undefined;
        select_toogle: HTMLDivElement | undefined;
        desc_container: HTMLDivElement | undefined;
        optionItems: HTMLElement[] | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
        firstUpdated(): void;
        private defaultMsg;
        private currentIndex;
        private onIconClick;
        private onBlur;
        renderOpt(): import("_100554_litHtml").TemplateResult<1>;
        handleHover(ev: MouseEvent): void;
        handleOut(): void;
        handleFocus(ev: MouseEvent, index: number): void;
        handleChange(value: string): void;
        handleKeyDown(event: KeyboardEvent): void;
        toogle(): void;
        calculatePopupPosition(): void;
    }
    export interface IOptionItem {
        key: string;
        value: string;
        description: string;
    }
}
declare module "_100554_collabSpliterHorizontalVarFixed" {
    import { LitElement } from "_100554_litElement";
    export class CollabSpliterHorizontalVarFixed100554 extends LitElement {
        fixedwidth: string;
        complementcolor: string;
        fixedvisible: 'hidden' | 'visible' | 'closed';
        spliterWidth: number;
        actualfixedwidth: string;
        msize: string;
        open: boolean;
        openUser: boolean | undefined;
        slotLeft: HTMLElement | undefined;
        slotRight: HTMLElement | undefined;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private setFixedValueInPx;
        private getMSize;
        private getMSizeLeft;
        private getMSizeRight;
        private updateMyHeight;
        delay(): Promise<void>;
        private updatePanelsMSize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private styles;
    }
}
declare module "_100554_collabSpliterVerticalVarFixed" {
    import { LitElement } from "_100554_litElement";
    export class CollabSpliterVerticalVarFixed100554 extends LitElement {
        fixedheight: string;
        complementcolor: string;
        spliterHeight: number;
        withresize: string;
        actualfixedheight: string;
        msize: string;
        isBottomPaneOpen: boolean;
        slotTop: HTMLElement | undefined;
        slotBottom: HTMLElement | undefined;
        private resizeObserver?;
        createRenderRoot(): this;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        firstUpdated(): void;
        private getMSize;
        private getMSizeTop;
        private getMSizeBottom;
        private updatePanelsMSize;
        _applyMSize(): void;
        _onSpliterClick(event: MouseEvent): void;
        _distributeContent(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private styles;
    }
}
declare module "_100554_collabState" {
    /**
     * Class responsible for managing shared state.
     */
    export class CollabState {
        private stateMap;
        private componentMap;
        /**
         * Update state for a given key.
         * @param key - The state key.
         * @param value - The new state value.
         */
        setState(key: string, value: any): void;
        /**
         * Retrieve state for a given key.
         * @param key - The state key.
         */
        getState(key: string): any;
        /**
         * Subscribe a component to a state key or keys.
         * @param keyOrKeys - The state key or keys.
         * @param component - The subscribing component.
         */
        subscribe(keyOrKeys: string | string[], component: Object): void;
        /**
         * Unsubscribe a component from a state key or keys.
         * @param keyOrKeys - The state key or keys.
         * @param component - The unsubscribing component.
         */
        unsubscribe(keyOrKeys: string | string[], component: Object): void;
        /**
         * Notify subscribed components about a state change.
         * @param key - The state key that changed.
         */
        private notify;
        /**
         * Get statistics about current state keys and their subscribers.
         */
        getStateStatistics(): Map<string, number>;
    }
}
declare module "_100554_collabStore" {
    /**
     * use this state to set and increment count
     * each access on page, increment this
     */
    export const COUNTHITSPAGES = "CountHitsPages";
}
declare module "_100554_collabStateTestCount" { }
declare module "_100554_collabTilesItem" {
    import { LitElement } from "_100554_litElement";
    export class CollabTilesItem extends LitElement {
        private startX;
        private startY;
        private startWidth;
        private startHeight;
        myinfo: ITilesItem | undefined;
        position: string;
        plugin: string;
        index: string;
        edit: string;
        mode: string;
        collabtileitemresize: HTMLElement | undefined;
        private elPlugin;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderResize(): import("_100554_litHtml").TemplateResult<1>;
        private setEnabled;
        private loadingPlugin;
        private setPlugin;
        private clickPlugin;
        private initDragging;
        private doDragging;
        private stopDragging;
        private myCss;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_collabTiles" {
    import { LitElement } from "_100554_litElement";
    import "_100554_collabTilesItem";
    import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js';
    export class CollabTiles extends LitElement {
        config: string;
        tilesItens: ITilesItem[];
        text: string;
        example: string;
        collabTiles: HTMLElement | undefined;
        private oldJson;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(item: ITilesItem, idx: number): import("_100554_litHtml").TemplateResult<1>;
        renderConfigItens(): import("_100554_litHtml").TemplateResult<1>;
        renderConfigItensOpen(): import("_100554_litHtml").TemplateResult<1>;
        renderConfigItensClose(): import("_100554_litHtml").TemplateResult<1>;
        renderItemConfig(item: ITilesItem, index: number): import("_100554_litHtml").TemplateResult<1>;
        private sort;
        private setDragAndDrop;
        private open;
        private close;
        private onlyclose;
        private verifyNeedSaveAndSave;
        private changeConfig;
        private setInfoPlugin;
        private fireChange;
        private myCss;
    }
    interface ITilesItem {
        title: string;
        plugin: string;
        position: string;
        index: string;
        enabled: string;
        widgetConfig: string;
    }
}
declare module "_100554_configDsDefaultCommon" {
    import { DesignSystemIO, ITokens } from "_100554_libDesignSystem";
    export class Common {
        constructor(ds: IDS | undefined, dsIO: DesignSystemIO);
        private ds;
        private dsIO;
        getUser(): string;
        getDateNow(): string;
        getDsMlsFilePath(): string;
        getDocsMlsFilePath(): string;
        getDsCssFilePath(): string;
        getDsComponentFilePath(componentName: string): string;
        getDsComponentExampleFilePath(componentName: string): string;
        getDsComponentStyleFilePath(componentName: string): string;
        getStorFileName(shortName: string, folder: string, extension: string): string;
        updateLastModified(): void;
        createNewFile(shortName: string, folder: string, extension: string, content: string | Blob | null): Promise<void>;
        setContentFileDsMain(): Promise<boolean>;
        private mergeJSON;
        setContentFile(shortName: string, extension: string, fullpath: string, content: string | Blob | null): Promise<boolean>;
        renameContentFile(shortName: string, extension: string, fullpath: string, newName: string): Promise<boolean>;
        getFileWithNewStatus(shortName: string, folder: string, extension: string, newStatus: mls.stor.IFileInfoStatus, content: string | Blob | null, newName?: string): Promise<mls.stor.IFileInfo>;
        onChangeStatusToNew(shortName: string, extension: string, folder: string, content: string | Blob | null): Promise<mls.stor.IFileInfo>;
        onChangeStatusNewToDeleted(file: mls.stor.IFileInfo): Promise<mls.stor.IFileInfo>;
        onChangeStatusNewToChanged(file: mls.stor.IFileInfo, content: string | Blob | null): Promise<mls.stor.IFileInfo>;
        onChangeStatusRenamedToRenamed(file: mls.stor.IFileInfo, newName: string, folder: string, extension: string): Promise<mls.stor.IFileInfo>;
        onChangeStatusRenamedToChanged(file: mls.stor.IFileInfo, content: string | Blob | null): Promise<mls.stor.IFileInfo>;
        onChangeStatusNewToRenamed(file: mls.stor.IFileInfo, newName: string, folder: string, extension: string): Promise<mls.stor.IFileInfo>;
        onChangeStatusToRenamed(file: mls.stor.IFileInfo, newName: string, newFolder: string): Promise<mls.stor.IFileInfo>;
        onChangeStatusToDeleted(file: mls.stor.IFileInfo): Promise<mls.stor.IFileInfo>;
        _getValueInfo(file: mls.stor.IFileInfo, originalShortName?: string, originalFolder?: string, originalProject?: number, originalCRC?: string): Promise<mls.stor.IFileInfoValue>;
        _onAction(action: mls.stor.IFileInfoAction, storFile: mls.stor.IFileInfo): Promise<void>;
        getContentFile(shortName: string, extension: string, fullpath: string, forceOriginal?: boolean): Promise<string | Blob | null>;
        setFileError(shortName: string, fullpath: string, extension: string, error: boolean): void;
        cssInitial: string;
        docInitial: string;
        tokensInitial: mls.l3.ITokenInfo[];
    }
    export const initialTokensColor: {
        "text-primary-color-lighter": string;
        "text-primary-color": string;
        "text-primary-color-darker": string;
        "text-secondary-color-lighter": string;
        "text-secondary-color": string;
        "text-secondary-color-darker": string;
        "bg-primary-color-lighter": string;
        "bg-primary-color": string;
        "bg-primary-color-darker": string;
        "bg-secondary-color-lighter": string;
        "bg-secondary-color": string;
        "bg-secondary-color-darker": string;
        "grey-color-lighter": string;
        "grey-color-light": string;
        "grey-color": string;
        "grey-color-dark": string;
        "grey-color-darker": string;
        "error-color": string;
        "success-color": string;
        "warning-color": string;
        "info-color": string;
        "active-color": string;
        "link-color": string;
        "link-hover-color": string;
        "_dark-text-primary-color-lighter": string;
        "_dark-text-primary-color": string;
        "_dark-text-primary-color-darker": string;
        "_dark-text-secondary-color-lighter": string;
        "_dark-text-secondary-color": string;
        "_dark-text-secondary-color-darker": string;
        "_dark-bg-primary-color-lighter": string;
        "_dark-bg-primary-color": string;
        "_dark-bg-primary-color-darker": string;
        "_dark-bg-secondary-color-lighter": string;
        "_dark-bg-secondary-color": string;
        "_dark-bg-secondary-color-darker": string;
        "_dark-grey-color-lighter": string;
        "_dark-grey-color-light": string;
        "_dark-grey-color": string;
        "_dark-grey-color-dark": string;
        "_dark-grey-color-darker": string;
        "_dark-error-color": string;
        "_dark-success-color": string;
        "_dark-warning-color": string;
        "_dark-info-color": string;
        "_dark-active-color": string;
        "_dark-link-color": string;
        "_dark-link-hover-color": string;
    };
    export const initialTokensGlobal: {
        "breakpoint-small": string;
        "breakpoint-medium": string;
        "breakpoint-large": string;
        "transition-slow": string;
        "transition-normal": string;
        "transition-fast": string;
        "space-base-unit": string;
        "space-8": string;
        "space-16": string;
        "space-24": string;
        "space-32": string;
        "space-40": string;
        "space-48": string;
        "space-64": string;
    };
    export const initialtokensTypography: {
        "font-base-unit": string;
        "font-family-primary": string;
        "font-family-secondary": string;
        "font-size-12": string;
        "font-size-16": string;
        "font-size-20": string;
        "font-size-24": string;
        "font-size-40": string;
        "font-size-48": string;
        "font-size-64": string;
        "line-height-base-unit": string;
        "line-height-small": string;
        "line-height-medium": string;
        "line-height-large": string;
        "font-weight-lighter": string;
        "font-weight-light": string;
        "font-weight-normal": string;
        "font-weight-bold": string;
        "font-weight-bolder": string;
    };
    export interface IDS {
        name: string;
        last_updated_by: string;
        last_updated: string;
        created_by: string;
        reference: mls.l3.IDSRef | undefined;
        docs: {
            items: mls.l3.IDocInfo[];
        };
        tokens: {
            items: ITokens[];
        };
        assets: {
            items: mls.l3.IAssetsInfo[];
        };
        components: {
            items: mls.l3.IComponentInfo[];
        };
        css: {
            items: mls.l3.ICssInfo[];
        };
    }
}
declare module "_100554_configDsDefaultDocs" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { DesignSystemIO, DocIO, IDocInfos, IDocInfo } from "_100554_libDesignSystem";
    export class Doc implements DocIO {
        constructor(dsIO: DesignSystemIO, ds: IDS);
        private ds;
        private methods;
        _ds: DesignSystemIO;
        add: (parentId: number, title: string, content: string) => Promise<number>;
        update: (id: number, parentId: number, title: string, content: string) => Promise<void>;
        remove: (id: number) => Promise<void>;
        find: (id: number) => IDocInfo;
        list: IDocInfos;
        private prepareDocs;
        private _find;
        private getLastDocIndex;
        private _addDoc;
        private _addDoc2;
        private _removeDoc;
        private _updateDoc;
        private getDocContent;
        private setDocContent;
    }
}
declare module "_100554_configDsDefaultPreCompileLess" {
    import { ITokens } from "_100554_libDesignSystem";
    export class PreCompileLess {
        execute(less: string, tokensLess: string, theme: string, tokens: ITokens[], prefix: ':host' | ':root', includeTokens?: boolean): Promise<string>;
        compileLess(str: string): Promise<string>;
        private preCompileLess;
        private getDarkAndLight;
        private getCssVars;
        private replaceTokens;
        private getEscapedVariable;
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_100554_configDsDefaultTokens2" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { DesignSystemIO, TokenIO, IToken, ITokenInfo, TokensCategories } from "_100554_libDesignSystem";
    export class Token implements TokenIO {
        constructor(dsIO: DesignSystemIO, ds: IDS);
        private ds;
        private methods;
        _ds: DesignSystemIO;
        add: (key: string, value: string, theme: string, category: TokensCategories) => Promise<void>;
        update: (key: string, newValue: string, theme: string) => Promise<void>;
        remove: (key: string, theme: string) => Promise<void>;
        find: (key: string, theme: string) => IFindToken;
        addTheme: (theme: string, description: string) => Promise<void>;
        removeTheme: (theme: string) => Promise<void>;
        list: ITokenInfo;
        getTokensLess: (theme: string) => Promise<string>;
        getTokensCss: (theme: string) => Promise<string>;
        setTokens: (theme: string, tokensColor: IToken, tokensTypography: IToken, tokensGlobal: IToken) => Promise<void>;
        private prepareTokens;
        private _find;
        private _getTokensLess;
        private _getTokensCss;
        private _addToken;
        private _updateToken;
        private _removeToken;
        private _addTheme;
        private _removeTheme;
        private _setTokens;
    }
    interface IFindToken {
        categorie: TokensCategories;
        value: string;
    }
}
declare module "_100554_configDsDefaultAssets" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { DesignSystemIO, AssetIO, IAssetInfos, IAssetsInfo, AssetsGroupType, IDSRef } from "_100554_libDesignSystem";
    export class Asset implements AssetIO {
        constructor(dsIO: DesignSystemIO, ds: IDS);
        private ds;
        private methods;
        _ds: DesignSystemIO;
        add: (path: string, shortname: string, tags: string[], description: string, assetType: AssetsGroupType, content: File, reference?: IDSRef) => Promise<void>;
        update: (path: string, shortname: string, tags: string[], description: string, assetType: AssetsGroupType) => Promise<void>;
        remove: (path: string, shortname: string) => Promise<void>;
        find: (path: string, shortname: string) => IAssetsInfo;
        list: IAssetInfos;
        private prepareAssets;
        private _find;
        private getKeyAsset;
        private _addAssets;
        private _updateAsset;
        private _removeAssets;
    }
}
declare module "_100554_configDsDefaultCss" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { DesignSystemIO, CssIO, ICssInfos, ICssInfo } from "_100554_libDesignSystem";
    export class Css implements CssIO {
        constructor(dsIO: DesignSystemIO, ds: IDS);
        private ds;
        private methods;
        private tokens;
        _ds: DesignSystemIO;
        list: ICssInfos;
        add: (name: string, content: string) => Promise<void>;
        setHTMLPreview: (content: string) => Promise<void>;
        getHTMLPreview: () => Promise<string>;
        find: (name: string) => ICssInfo;
        getStylesInLess: (theme: string) => Promise<string>;
        private prepareCss;
        private _find;
        private getExtension;
        private _addCss;
        private _addCss2;
        private cacheCss;
        private getCssContent;
        private setCssContent;
        private _getCssGlobalLess;
        private _setHTMLPreview;
        private _getHTMLPreview;
    }
}
declare module "_100554_configDsDefaultExample" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { ExampleIO, ComponentIO, DesignSystemIO, IComponentsExampleInfos, IComponentsExample } from "_100554_libDesignSystem";
    export class Example implements ExampleIO {
        constructor(dsIO: DesignSystemIO, ds: IDS, component: ComponentIO);
        private ds;
        private methods;
        private component;
        _ds: DesignSystemIO;
        list: IComponentsExampleInfos;
        add: (componentName: string, exampleName: string, description: string, exampleJsonP: string, reference?: mls.l3.IDSRef) => Promise<void>;
        update: (componentName: string, exampleName: string, description: string) => Promise<void>;
        rename: (componentName: string, exampleName: string, newName: string) => Promise<void>;
        remove: (componentName: string, exampleName: string) => Promise<void>;
        find: (componentName: string, exampleName: string) => IComponentsExample;
        private prepareExamples;
        private getKeyComponentExample;
        private _find;
        private _addComponentExample;
        private _addComponentExample2;
        private _updateExample;
        private _renameExample;
        private _removeComponentExample;
        private _getExampleEl;
        private _getJsonPExampleIO;
        private _setJsonPExampleIO;
    }
}
declare module "_100554_configDsDefaultStyle" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { DesignSystemIO, StyleIO, ComponentIO, IComponentsStyleInfos, IComponentsStyle, IDSRef } from "_100554_libDesignSystem";
    export class Style implements StyleIO {
        constructor(dsIO: DesignSystemIO, ds: IDS, component: ComponentIO);
        _ds: DesignSystemIO;
        list: IComponentsStyleInfos;
        add: (componentName: string, stylename: string, less: string, reference?: IDSRef) => Promise<void>;
        rename: (componentName: string, styleName: string, newName: string) => Promise<void>;
        remove: (componentName: string, styleName: string) => Promise<void>;
        find: (componentName: string, styleName: string) => IComponentsStyle;
        private ds;
        private methods;
        private component;
        private token;
        private prepareStyles;
        private getKeyComponentStyle;
        private _find;
        private _addComponentStyle;
        private _addComponentStyle2;
        private _removeComponentStyle;
        private _renameComponentStyle;
        private _getStyleLessIO;
        private _setStyleLessIO;
    }
}
declare module "_100554_configDsDefaultComponent" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { DesignSystemIO, ComponentIO, IComponentInfos, IComponentInfo } from "_100554_libDesignSystem";
    import { Example } from "_100554_configDsDefaultExample";
    import { Style } from "_100554_configDsDefaultStyle";
    export class Component implements ComponentIO {
        constructor(dsIO: DesignSystemIO, ds: IDS);
        private ds;
        private methods;
        private tokens;
        private css;
        _ds: DesignSystemIO;
        list: IComponentInfos;
        add: (widget: IComponentInfo) => Promise<void>;
        update: (name: string, widget: IComponentInfo) => Promise<void>;
        remove: (componentName: string) => Promise<void>;
        getCSS: (componentName: string, theme: string) => Promise<string>;
        getGuidelinesIO: (componentName: string) => Promise<string>;
        setGuidelinesIO: (componentName: string, content: string) => Promise<void>;
        getStylesLess: (componentName: string, theme: string) => Promise<string>;
        find: (componentName: string) => IComponentInfo;
        examples: Example;
        styles: Style;
        private prepareComponents;
        private _find;
        private _addComponent;
        private _updateComponent;
        private _removeComponent;
        private _getComponentStylesLess;
        private _getComponentCSS;
        private _setGuidelinesIO;
        private _getGuidelinesIO;
    }
}
declare module "_100554_configDsDefault" {
    import { IDS } from "_100554_configDsDefaultCommon";
    import { DesignSystemIO, DocIO, CssIO, AssetIO, TokenIO, ComponentIO } from "_100554_libDesignSystem";
    export class _100554_configDsDefault implements DesignSystemIO {
        constructor(project: number, dsindex: number);
        project: number;
        dsindex: number;
        dsname: string;
        createdBy: string;
        lastUpdated: string;
        lastUpdatedBy: string;
        init: () => Promise<void>;
        dispose: () => Promise<void>;
        remove: () => Promise<void>;
        create: (project: number, dsindex: number, createdAt: string, reference: mls.l3.IDSRef | any) => Promise<void>;
        _getOriginalDsJSON: () => Promise<IDS>;
        getDesignSystemCss: (theme: string) => Promise<string>;
        private ds;
        docs: DocIO | undefined;
        components: ComponentIO | undefined;
        tokens: TokenIO | undefined;
        assets: AssetIO | undefined;
        css: CssIO | undefined;
        private methods;
        private _init;
        private _createDs;
        private createDsByTemplate;
        private createEmptyDS;
        private copyAllFilesDs;
        private _dispose;
        private prepareStorFiles;
        private __getOriginalDsJSON;
        private _getDesignSystemCss;
        private _remove;
    }
}
declare module "_100554_cssHelperIndexBase" {
    export type IMode = 'collapsed' | 'expanded' | 'full';
    export interface IHelpers {
        name: string;
        priority: number;
        widget: string;
        tags: string[];
        description: string;
        mode: IMode;
        liked: boolean;
        likedAnimation: boolean;
        showInfo: boolean;
    }
}
declare module "_100554_pluginStyleIndexItem" {
    import { CollabLitElement } from "_100554_collabLitElement";
    import { IHelpers } from "_100554_cssHelperIndexBase";
    export class PluginStyleIndexItem extends CollabLitElement {
        help: IHelpers;
        position: 'left' | 'right';
        open(): Promise<void>;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private openPlugin;
        handleOpenPlugin(e: MouseEvent, help: IHelpers, close?: boolean): Promise<void>;
        handleExpandedClick(e: MouseEvent, help: IHelpers): void;
        handleFullClick(e: MouseEvent, help: IHelpers): void;
        handleLikeClick(e: MouseEvent, help: IHelpers): Promise<void>;
        handleInfoClick(e: MouseEvent, help: IHelpers): Promise<void>;
    }
}
declare module "_100554_cssHelperIndex" {
    import { TemplateResult } from "_100554_litElement";
    import { IcaLitElement } from "_100554_icaLitElement";
    import { PluginStyleIndexItem } from "_100554_pluginStyleIndexItem";
    import { IHelpers } from "_100554_cssHelperIndexBase";
    import { ICSSState } from "_100554_lessCSS";
    export class CssHelperIndex extends IcaLitElement {
        private msg;
        helpers: IHelpers[];
        avaliablePlugins: IHelpers[];
        position: 'right' | 'left';
        actualProp: string | undefined;
        actualValue: string | undefined;
        actualSelector: string | undefined;
        actualLineNumber: number | undefined;
        state: ICSSState | undefined;
        allPluginsEls: PluginStyleIndexItem[];
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        updated(changedProperties: any): Promise<void>;
        firstUpdated(a: any): Promise<void>;
        private getAvaliablesPlugins;
        private filterByProp;
        render(): TemplateResult<1>;
        renderHelper(help: IHelpers, index: number): TemplateResult<1>;
        openIfNeeded(): void;
    }
}
declare module "_100554_dependenciesLit" {
    export function getComponentDependencies(model: mls.l2.editor.IMFile): string[];
}
declare module "_100554_enhancementLit" {
    export const getAddNewFileDetails: () => {
        title: string;
        description: string;
        tags: string[];
        example: string;
        aimActionSuggest: string;
    }[];
    export const requires: mls.l2.editor.IRequire[];
    export const getDefaultHtmlExamplePreview: (model: mls.l2.editor.IMFile) => string;
    export const getDesignDetails: (model: mls.l2.editor.IMFile) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (mfile: mls.l2.editor.IMFile) => Promise<void>;
    export const onAfterCompile: (mfile: mls.l2.editor.IMFile) => Promise<void>;
}
declare module "_100554_enhancementLitService" {
    export const getAddNewFileDetails: () => {
        title: string;
        description: string;
        tags: string[];
        example: string;
        aimActionSuggest: string;
    }[];
    export const requires: mls.l2.editor.IRequire[];
    export const getDefaultHtmlExamplePreview: (model: mls.l2.editor.IMFile) => string;
    export const getDesignDetails: (model: mls.l2.editor.IMFile) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const onAfterChange: (mfile: mls.l2.editor.IMFile) => Promise<void>;
    export const onAfterCompile: (mfile: mls.l2.editor.IMFile) => Promise<void>;
}
declare module "_100554_enhancementPage" {
    export const description = "Use this enhancement for pages";
    export const example = "";
    export const requires: mls.l2.editor.IRequire[];
    export const getExample: (project: number, shortname: string) => string;
    export const getDesignDetails: (model: mls.l2.editor.IMFile) => Promise<mls.l2.enhancement.IDesignDetailsReturn>;
    export const prepareAdd: (prompt: string) => {
        sourceTS: string;
        aiHeader: string;
        aiBody: string;
        aiDelimiter: string;
    };
    export const onAfterChange: (mfile: mls.l2.editor.IMFile) => Promise<void>;
    export const getPromptDefault: () => string;
    export const onAfterCompile: (mfile: mls.l2.editor.IMFile) => Promise<void>;
}
declare module "_100554_icaApresentationCharts2D" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaApresentationCharts2D extends IcaLitElementBase {
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaApresentationCharts2DBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaApresentationCharts2DBase extends IcaLitElement {
        abstract framework: string | undefined;
        abstract datasource: string | undefined;
        abstract renderer: string | undefined;
        abstract chartTitle: string | undefined;
    }
}
declare module "_100554_icaApresentationEmbedsSocialMedia" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaApresentationEmbedsSocialMedia100554 extends IcaLitElementBase {
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaApresentationEmbedsSocialMediaBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaApresentationEmbedsSocialMediaBase100554 extends IcaLitElement {
        abstract description: string | undefined;
        abstract url: string | undefined;
    }
}
declare module "_100554_icaApresentationImagesImages" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaApresentationImagesImages extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaApresentationImagesImagesBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaApresentationImagesImagesBase extends IcaLitElement {
        abstract src: string | undefined;
        abstract alt: string | undefined;
        abstract width: string | undefined;
        abstract height: string | undefined;
        firstUpdated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        private getUrlL3;
    }
}
declare module "_100554_icaApresentationTextCodeBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaApresentationTextCodeBase extends IcaLitElement {
        abstract text: string | undefined;
        abstract language: string | undefined;
        abstract languages: string[] | undefined;
    }
}
declare module "_100554_icaApresentationTextCode" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    import { IcaApresentationTextCodeBase } from "_100554_icaApresentationTextCodeBase";
    export abstract class IcaApresentationTextCode extends IcaLitElementBase implements IcaApresentationTextCodeBase {
        language: string;
        languages: any[];
        text: string;
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaApresentationTextText" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaApresentationTextText extends IcaLitElementBase {
        type: string | undefined;
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaApresentationTextTextBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaApresentationTextTextBase extends IcaLitElement {
        abstract text: string | undefined;
        abstract type: string | undefined;
    }
}
declare module "_100554_icaApresentationVideoEmbeddedVideo" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaApresentationVideoEmbeddedVideo extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
    }
}
declare module "_100554_icaApresentationVideoEmbeddedVideoBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaApresentationVideoEmbeddedVideoBase extends IcaLitElement {
        abstract src: string | undefined;
        abstract autoplay: boolean;
        abstract controls: boolean | undefined;
        abstract loop: boolean | undefined;
        abstract preload: 'auto' | 'metadata' | 'none';
        firstUpdated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        private getUrlL3;
    }
}
declare module "_100554_icaDeepLinking" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export class IcaDeepLinking100554 extends IcaLitElement {
        url: string | undefined;
        params: Set<IUrlParams>;
        trace: string[];
        develpoment: boolean;
        exec(params: Set<IUrlParams>): void;
        private findAndChangeElementsInPage;
        private findParameterReferences;
        private setParamsByUrl;
        private setParamsByPrompt;
        private createPrompt;
        private createDetailsIcon;
        private getAllWebComponentTags;
        private timeoutChangePrompt;
        private handleChange;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        renderOptional(): import("_100554_litHtml").TemplateResult<1>;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    interface IUrlParams {
        key: string;
        value: string;
    }
}
declare module "_100554_icaFormsInputNumber" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaFormsInputNumber extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaFormsInputNumberBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaFormsInputNumberBase extends IcaLitElement {
        abstract hint: string | undefined;
        abstract label: string | undefined;
        abstract datasource: number | undefined;
        abstract required: boolean;
        abstract disabled: boolean;
        abstract maxvalue: number | undefined;
        abstract minvalue: number | undefined;
        abstract step: number | undefined;
        abstract placeholder: string | undefined;
        abstract pattern: string | undefined;
        abstract errormessage: string | undefined;
        abstract autofocus: boolean;
    }
}
declare module "_100554_icaFormsInputSelectOne" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export class IcaFormsInputSelectOne extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaFormsInputSelectOneBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaFormsInputSelectOneBase extends IcaLitElement {
        abstract hint: string | undefined;
        abstract label: string | undefined;
        abstract options: any | undefined;
        abstract selectedvalue: string | undefined;
        abstract required: boolean;
        abstract disabled: boolean;
    }
}
declare module "_100554_icaFormsInputString" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaFormsInputNumber extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaFormsInputStringBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaFormsInputStringBase extends IcaLitElement {
        abstract name: string | undefined;
        abstract hint: string | undefined;
        abstract label: string | undefined;
        abstract required: boolean;
        abstract disabled: boolean;
        abstract maxlength: number | undefined;
        abstract minlength: number | undefined;
        abstract placeholder: string | undefined;
        abstract pattern: string | undefined;
        abstract errormessage: string | undefined;
        abstract autofocus: boolean;
        abstract autoCapitalize: IAutoCapitalize | undefined;
        abstract autocorrect: IAutocorrect | undefined;
        abstract autocomplete: string | undefined;
    }
    export type IAutoCapitalize = 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters';
    export type IAutocorrect = 'off' | 'on';
}
declare module "_100554_icaFormsSubmitSubmit" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaFormsSubmitSubmit extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        changeStateStyle(style: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaFormsSubmitSubmitBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaFormsSubmitSubmitBase extends IcaLitElement {
        abstract name: string | undefined;
        abstract title: string;
        abstract icon: string | undefined;
        abstract text: string | undefined;
        abstract disabled: boolean;
        abstract form: string | undefined;
    }
}
declare module "_100554_icaLayoutFlowColumn" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export class IcaLayoutFlowColumn extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaLayoutFlowColumnBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaLayoutFlowColumnBase extends IcaLitElement {
    }
}
declare module "_100554_icaLayoutFlowDivider" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaLayoutFlowDivider extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaLayoutFlowDividerBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaLayoutFlowDividerBase extends IcaLitElement {
        abstract text: string | undefined;
    }
}
declare module "_100554_icaLayoutFlowRow" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class IcaLayoutFlowRow extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaLayoutFlowRowBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaLayoutFlowRowBase extends IcaLitElement {
        abstract hint: string | undefined;
    }
}
declare module "_100554_icaLayoutFlowSection" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    export abstract class icaLayoutFlowSection extends IcaLitElementBase {
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaLayoutFlowSectionBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaLayoutFlowSectionBase extends IcaLitElement {
    }
}
declare module "_100554_icaLoadPage" {
    import { IcaLitElement } from "_100554_icaLitElement";
    import { IJSONDependence } from "_100554_libCompile";
    export class IcaLoadPage100554 extends IcaLitElement {
        src: string;
        loadPage(): Promise<void>;
        getHTML(): Promise<string>;
        getDeps(html: string): Promise<IJSONDependence>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_icaNavigationContentAccordionBase" {
    import { IcaLitElement } from "_100554_icaLitElement";
    export abstract class IcaNavigationContentAccordionBase extends IcaLitElement {
        abstract text: string | undefined;
        abstract open: boolean;
    }
}
declare module "_100554_icaNavigationContentAccordion" {
    import { ActionTag, IAllowCommand } from "_100554_icaTypes";
    import { IcaLitElementBase } from "_100554_icaLitElementBase";
    import { IcaNavigationContentAccordionBase } from "_100554_icaNavigationContentAccordionBase";
    export abstract class IcaNavigationContentAccordion extends IcaLitElementBase implements IcaNavigationContentAccordionBase {
        text: string;
        open: boolean;
        mySymbol: string;
        getActionsTags(): ActionTag[];
        changeStateHtml(html: string): void;
        allowCommand(cmd: string, scope: HTMLElement, target: HTMLElement): IAllowCommand;
        private commandMove;
    }
}
declare module "_100554_icaPageStory" {
    import { CollabPageElement } from "_100554_collabPageElement";
    export class IcaPageMedium100554 extends CollabPageElement {
        initPage(): void;
        handleClickbuttonSum(): void;
    }
}
declare module "_100554_icaTestPage" {
    import { LitElement } from "_100554_litElement";
    export class IcaTestPage100554 extends LitElement {
        static styles: import("_100554_litCssTag").CSSResult;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_lessASTTest" {
    import { LitElement } from "_100554_litElement";
    import { LessCSS } from "_100554_lessCSS";
    export class LessASTTest100554 extends LitElement {
        rootSelector: string;
        fileToTest: string;
        url1: monaco.editor.ITextModel;
        render(): import("_100554_litHtml").TemplateResult<1>;
        exeTest: () => string;
        test1: (lessCSS: LessCSS, rootSelector: string) => string;
        test2: (lessCSS: LessCSS, rootSelector: string) => string;
        test3: (lessCSS: LessCSS, rootSelector: string) => string;
        testt1: (lessCSS: LessCSS, rootSelector: string) => string;
        testt2: (lessCSS: LessCSS, rootSelector: string) => string;
    }
}
declare module "_100554_libFileManager" {
    export function readAllProjectAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function getStorFile(file: {
        project: number;
        shortName: string;
        enhancement: string;
        extension: string;
        level: number;
        folder: string;
    }): mls.stor.IFileInfo;
    export function createModel(storFile: mls.stor.IFileInfo, compile: boolean): Promise<mls.l2.editor.IMFile>;
    export function createNewFileWithModel(src: string, file: {
        project: number;
        shortName: string;
        enhancement: string;
        extension: string;
    }): Promise<mls.l2.editor.IMFile>;
    export function deleteFileWithModel(file: {
        project: number;
        shortName: string;
        enhancement: string;
        extension: string;
        level: number;
        folder: string;
    }): Promise<void>;
    export function undoFileWithModel(file: {
        project: number;
        shortName: string;
        enhancement: string;
        extension: string;
        level: number;
        folder: string;
    }): Promise<void>;
    export function renameFileWithModel(file: {
        project: number;
        shortName: string;
        enhancement: string;
        extension: string;
        level: number;
        folder: string;
        newProject: number;
        newShortName: string;
    }): Promise<void>;
    export function cloneFileWithModel(file: {
        project: number;
        shortName: string;
        enhancement: string;
        extension: string;
        level: number;
        folder: string;
        newProject: number;
        newShortName: string;
    }): Promise<void>;
}
declare module "_100554_libGithubIo" {
    export function addIssueInProject(req: IReq, idProject: string, idIssue: string): Promise<string | undefined>;
    export function removeIssueInProject(req: IReq, idProject: string, idIssueProject: string): Promise<boolean>;
    export function updateFieldSelectProjects(req: IReq, idProject: string, idItem: string, idField: string, idOption: string): Promise<boolean>;
    export function getIssuesInProjects(req: IReq, idProject: string): Promise<IItemProject[]>;
    export function getProjectFields(req: IReq, idProject: string): Promise<IFieldsProject[]>;
    export function getProjects(req: IReq): Promise<IProject[]>;
    export function addNewIssueIO(req: IReq, user: IInfo, repositoryId: string, labelsId: string[], title: string, desc: string): Promise<IIssues | undefined>;
    export function removeReact(req: IReq, issueid: string, reactid: string): Promise<boolean>;
    export function addReact(req: IReq, issueid: string): Promise<string>;
    export function getIssues(req: IReq, state?: string): Promise<IIssues[]>;
    export function getIssue(req: IReq, id: string): Promise<IIssues | undefined>;
    export function addComment(req: IReq, issue: IIssues, comment: string): Promise<IComments | undefined>;
    export function getIssueComments(req: IReq, issue: IIssues): Promise<IComments[]>;
    export function getRepositoryId(req: IReq): Promise<string>;
    export function addMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function addLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<ILabel | undefined>;
    export function removeMemberInIssue(req: IReq, issueId: string, memberId: string): Promise<boolean>;
    export function removeLabelInIssue(req: IReq, issueId: string, labelId: string): Promise<boolean>;
    export function getLabels(req: IReq): Promise<ILabel[]>;
    export function getUsers(req: IReq): Promise<IAssignees[]>;
    export function getLabelIdOrAdd(req: IReq, repositoryId: string): Promise<ILabelsCollab | undefined>;
    export function createLabelIO(req: IReq, repositoryId: string, label: string, color: string): Promise<ILabel | undefined>;
    export function getUserInfoIO(req: IReq): Promise<IInfo>;
    export interface IItemProject {
        id: string;
        issue: IIssues;
        fieldValues: IItemProjectValues[];
    }
    export interface IAssignees {
        id: string;
        login: string;
        avatarUrl: string;
    }
    export interface IItemProjectValues {
        value: string;
        valueText: string;
        fieldName: string;
        fieldId: string;
    }
    export interface IProject {
        id: string;
        number: number;
        title: string;
        createdAt: string;
        author: string;
        avatarUrl: string;
        url: string;
        fields: IFieldsProject[];
    }
    export interface IFieldsProject {
        id: string;
        name: string;
        dataType: string;
        options: {
            id: string;
            name: string;
        }[];
    }
    export interface IReq {
        mkey: string;
        owner: string;
        repo: string;
        branch: string;
    }
    export interface IIssues {
        id: string;
        numberIssues: number;
        createdAt: string;
        title: string;
        bodyText: string;
        state: string;
        url: string;
        author: string;
        avatarUrl: string;
        labels: ILabel[];
        reactionsTU: number;
        reactions: IReactions[];
        comments: IComments[];
        assignees: IAssignees[];
        project: IProjectMain;
    }
    export interface IProjectMain {
        number: number;
        title: string;
        id: string;
    }
    export interface IReactions {
        id: string;
        user: string;
    }
    export interface ILabel {
        id: string;
        color: string;
        name: string;
    }
    export interface IComments {
        createdAt: string;
        id: string;
        bodyText: string;
        author: string;
        avatarUrl: string;
    }
    export interface IInfo {
        name: string;
        login: string;
        avatarUrl: string;
    }
    export interface ILabelsCollab {
        feature: string;
        low: string;
        medium: string;
        high: string;
    }
}
declare module "_100554_mlsHistoryList" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class MlsHistoryList extends CollabLitElement {
        project: number;
        shortName: string;
        position: 'left' | 'right';
        folder: string;
        level: number;
        extension: string;
        loading: boolean;
        private error;
        private data;
        connectedCallback(): Promise<void>;
        getListHistory(): Promise<void>;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        private createJson;
        private createJson2;
        private filters;
        private findFirstInFilters;
        private getWeekOffet;
        private formatDate;
        handleClick(a: PointerEvent): void;
        render(): any;
    }
    export interface IHistoryItem {
        author: string;
        time: string;
        dateAm: string;
        hash: string;
        subject?: string;
        linesInserted: number | undefined;
        linesDeleted: number | undefined;
        authorUrl: string;
        type: 'item' | 'title';
    }
}
declare module "_100554_pluginBase" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    export abstract class PluginBase extends CollabLitElement {
        scope: string;
        abstract description: string;
        abstract getSvg(): TemplateResult;
    }
}
declare module "_100554_pluginBaseIndex" {
    export abstract class PluginBaseIndex {
        abstract getMenus(): mls.plugin.MenuAction[];
        abstract getHooks(): mls.plugin.HookAction[];
        abstract getServices(): mls.plugin.ServiceAction[];
    }
    const _default: "disabled";
    export default _default;
}
declare module "_100554_pluginBaseModule" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export abstract class PluginBaseModule extends CollabLitElement {
        scope: 'detail' | 'dashboard';
        abstract render(): any;
    }
}
declare module "_100554_wcCode" {
    import { IcaApresentationTextCodeBase } from "_100554_icaApresentationTextCodeBase";
    export class WcCode100554 extends IcaApresentationTextCodeBase {
        language: string;
        languages: any[];
        text: string;
        codeBlock: HTMLElement | undefined;
        select: HTMLSelectElement | undefined;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        setCode(): void;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private onChangeText;
    }
}
declare module "_100554_pluginCodelensCustomElement" {
    import { CollabLitElement } from "_100554_collabLitElement";
    import "_100554_wcCode";
    export class PluginCodelensCustomElement extends CollabLitElement {
        private msg;
        textCode2: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_pluginCodelensFileReferences" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class PluginCodelensFileReferences extends CollabLitElement {
        private msg;
        references: mls.l2.editor.IMFile[];
        project: number;
        shortName: string;
        position: string;
        firstUpdated(): Promise<void>;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleClick;
        private getReferences;
    }
}
declare module "_100554_pluginCodelensServiceDetails" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class PluginCodelensServiceDetails extends CollabLitElement {
        private msg;
        render(): import("_100554_litHtml").TemplateResult<1>;
        textExampleIcon: string;
        textExampleNormal: string;
        textExampleCustom: string;
        textExampleCustomLevel: string;
    }
}
declare module "_100554_pluginCollabCoreIndex" {
    import { PluginBaseIndex } from "_100554_pluginBaseIndex";
    export class PluginCollabCoreIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_1: PluginCollabCoreIndex;
    export default _default_1;
}
declare module "_100554_pluginConfigLinks" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export class PluginConfigLinks extends PluginBaseModule {
        myLinks: ILinks[];
        autoPrepare: boolean;
        private myConfig;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderLink(l: ILinks, idx: number): TemplateResult;
        renderEdit(): TemplateResult;
        private init;
        private addLink;
        private updateConfig;
        private clickDel;
        private removeModeEdit;
        private setModeEdit;
        private test;
    }
    interface ILinks {
        title: string;
        url: string;
        color: string;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_pluginCreateNewProject" {
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export class PluginCreateProject100554 extends PluginBaseModule {
        private msg;
        currentScenario: IScenaries;
        actualSiteSelected: ISites | undefined;
        sitesItems: NodeListOf<HTMLElement> | undefined;
        publishItems: NodeListOf<HTMLElement> | undefined;
        storageItems: NodeListOf<HTMLElement> | undefined;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderScenario(): import("_100554_litHtml").TemplateResult<1>;
        renderSelect(): import("_100554_litHtml").TemplateResult<1>;
        renderCustomize(): import("_100554_litHtml").TemplateResult<1>;
        private changeScenario;
        private onBtnContinueClick;
        private onBtnCreateClick;
        private onTypeSiteClick;
        private onPluginPublishClick;
        private onPluginStorageClick;
        private data;
        private pluginsPublish;
        private pluginsStorage;
    }
    type IScenaries = 'select' | 'customize';
    interface ISites {
        mode: 'site' | 'system';
        title: string;
        description: string;
        more: string;
        web: true;
        mobile: boolean;
        appMobileIOS: boolean;
        appMobileAndroid: boolean;
        backend: boolean;
        multilanguage: boolean;
    }
}
declare module "_100554_pluginExamplesIndex" {
    import { PluginBaseIndex } from "_100554_pluginBaseIndex";
    export class PluginExamplesIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_2: PluginExamplesIndex;
    export default _default_2;
}
declare module "_100554_serviceListFilesAdd" {
    import { ServiceBase } from "_100554_serviceBase";
    import { CollabLitElement } from "_100554_collabLitElement";
    export const initServiceListFilesAdd: () => void;
    export class ServiceListFilesAdd100554 extends CollabLitElement {
        private msg;
        level: number;
        error: string;
        position: string;
        father?: ServiceBase | undefined;
        templates: ITemplateDetails[];
        loading: boolean;
        inputShortName: HTMLInputElement | undefined;
        private enhancementModules;
        connectedCallback(): Promise<void>;
        private init;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderAdd(project: number): import("_100554_litHtml").TemplateResult<1>;
        renderTemplates(): import("_100554_litHtml").TemplateResult<1>;
        private getTemplates;
        private clickCancel;
        private showLoader;
        private add;
        private createContentNewFile;
        private checkIfAsIcaAndCreateIfNeeded;
        private splitStringByUppercase;
        private capitalizeFirstLetter;
        private createTemplateIca;
        private saveLocalHistory;
        private getNewNameAndValid;
        private isValidNewName;
        private changeClassName;
        private changeWidget;
        private changeTagName;
        private getEnhacementsDetails;
        private getAllEnhacementsTemplates;
        private getEnhacementsInstancies;
        private fireComunication;
    }
    interface ITemplateDetails {
        title: string;
        description: string;
        tags: string[];
        example: string;
        aimActionSuggest: string;
        enhancementKey?: string;
    }
}
declare module "_100554_pluginExploreList" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreList extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        mode: string;
        refresh: string;
        position: string;
        levelFiles: number;
        project: number;
        projectLabel: string;
        errorAux: string;
        files: mls.stor.IFileInfo[];
        history: mls.stor.IFileInfo[];
        lis: HTMLElement[] | undefined;
        constructor();
        private info;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        private showAdd;
        private setEvents;
        private onMLSEvents;
        render(): TemplateResult<1>;
        renderHeader(): TemplateResult<1>;
        renderHistory(): TemplateResult<1>;
        renderList(): TemplateResult<1>;
        renderAuxEdit(): TemplateResult<1>;
        renderLiItem(file: mls.stor.IFileInfo, index: number, inHistory: boolean): TemplateResult<1>;
        renderAdd(): TemplateResult<1>;
        private clickOptUndo;
        private clickOptDel;
        private clickOptOpen;
        private clickOptRename;
        private clickOptClone;
        private clickOptRenameClone;
        private fireEvents;
        private fireEventThisProject;
        private fireEventLoadProject;
        private changeListTimeout;
        changeList(time?: number): void;
        private extensionLevel;
        private init;
        private getMyFileInElement;
        private clickGroupHidden;
        private clickHiddenAux;
        private clickOptStop;
        private clickRadioProject0;
        private clickRadioProjectActual;
        private inFilter;
        private timeFilterChange;
        private filterLiChange;
        private verifyChangeInList;
        private verifyChangeInList2;
        private getFiles;
        private getFilesProject;
        private getFileHistory;
        private getHistory;
        private setHistory;
        private validInputsAux;
        private isValidNewName;
    }
}
declare module "_100554_pluginExploreStories" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginExploreStories extends PluginBaseModule {
        private msg;
        private project;
        position: 'left' | 'right';
        level: number;
        autoPrepare: boolean;
        files: IItensFiles[];
        activeTab: ITabType;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult<1>;
        renderContent(): TemplateResult<1>;
        renderDraft(): TemplateResult<1>;
        renderPublished(): TemplateResult<1>;
        renderList(): TemplateResult<1>;
        renderLiItem(file: IItensFiles, index: number, inHistory: boolean): TemplateResult<1>;
        private init;
        private getFiles;
        private getFilesProject;
        private clickLi;
        private clickMenu;
        private timeBlur;
        private blurMenu;
        private overMenu;
        private clickOptOpen;
        private clickOptDel;
        private fireEvents;
    }
    type ITabType = 'icDraft' | 'icPublished';
    interface IItensFiles {
        file: mls.stor.IFileInfo;
        name: string;
        desc: string;
    }
}
declare module "_100554_pluginGithubL4Issues" {
    import { TemplateResult } from "_100554_litElement";
    import * as gitIO from "_100554_libGithubIo";
    import { CollabLitElement } from "_100554_collabLitElement";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginGithubL4Issues extends CollabLitElement {
        private repositoryId;
        private error;
        private userInfo;
        private labelId;
        private req;
        private viewIssue;
        private comments;
        scenary: string;
        myIssues: gitIO.IIssues[];
        isLoader: boolean;
        labelfilter: string;
        contentlistissues: HTMLElement | undefined;
        get mKey(): string;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderLoader(): TemplateResult;
        renderError(): TemplateResult;
        renderList(): TemplateResult;
        renderListFilter(): TemplateResult<1>;
        renderListItem(item: gitIO.IIssues, idx: number): TemplateResult<1>;
        renderNewIssue(): TemplateResult<1>;
        renderShow(): TemplateResult<1>;
        renderCogs(): TemplateResult<1>;
        renderThumbsUp(): TemplateResult<1>;
        renderComments(item: gitIO.IComments): TemplateResult<1>;
        private setInfos;
        private clickCogs;
        private changeLabelPrioriti;
        private filterMyIssues;
        private clickScenaryNew;
        private removeVote;
        private addVote;
        private backButton;
        private clickIssues;
        private addNewIssue;
        private timeFilter;
        private filter;
        private clickNewComment;
        private initInfoProject;
    }
}
declare module "_100554_pluginGithubL4Project" {
    import { TemplateResult } from "_100554_litElement";
    import * as gitIO from "_100554_libGithubIo";
    import { CollabLitElement } from "_100554_collabLitElement";
    import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js';
    export const pluginData: mls.plugin.IPluginData;
    export class PluginGithubL4Project extends CollabLitElement {
        private repositoryId;
        private error;
        private userInfo;
        private req;
        private myLabels;
        private myUsers;
        private myProjcts;
        private viewProject;
        private itensShowProject;
        private idFieldStatus;
        private sort;
        scenary: string;
        isLoader: boolean;
        autoClick: string;
        viewIssue: gitIO.IItemProject | undefined;
        addInStatus: string | undefined;
        listIssues: gitIO.IIssues[] | undefined;
        contentstatus: HTMLElement | undefined;
        contentviewissue: HTMLElement | undefined;
        get mKey(): string;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderLoader(): TemplateResult;
        renderError(): TemplateResult;
        renderList(): TemplateResult;
        renderListFilter(): TemplateResult<1>;
        renderListItem(item: gitIO.IProject, idx: number): TemplateResult<1>;
        renderHeader(): TemplateResult<1>;
        renderShow(): TemplateResult;
        renderTab(): TemplateResult;
        renderTaksTab(array: gitIO.IItemProject[] | undefined): TemplateResult;
        renderTaskTab(p: gitIO.IItemProject): TemplateResult;
        renderViewIssue(): TemplateResult;
        renderViewMain(): TemplateResult;
        renderViewOptions(): TemplateResult;
        renderOptionsLabels(l: gitIO.ILabel): TemplateResult;
        renderOptionsMembers(l: gitIO.IAssignees): TemplateResult;
        renderComentsInTask(c: gitIO.IComments): TemplateResult;
        renderLabelsInTask(l: gitIO.ILabel): TemplateResult;
        renderAddIssue(): TemplateResult;
        renderListIssues(): TemplateResult;
        renderListItemIssues(item: gitIO.IIssues, idx: number): TemplateResult<1>;
        private setInfos;
        private initInfoProject;
        private backButton;
        private clickChangeView;
        private addIssuesin;
        private addIssueInProject;
        private clickSaveComment;
        private clickItemProject;
        private listAllIssues;
        private addIssue;
        private changeLabel;
        private changeMembers;
        private removeIssueInProject;
        private isAutoClick;
        private organizeItens;
        private showViewIssue;
        private clickCloseIssue;
        private openMyChild;
        private setDragAndDrop;
        private myIcons;
    }
}
declare module "_100554_pluginPageAIVerify" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginPageAIVerify extends PluginBaseModule {
        private msg;
        render(): TemplateResult<1>;
    }
}
declare module "_100554_pluginPageNavigation" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    import { IcaLitElementBaseMethods } from "_100554_icaTypes";
    export class PluginPageNavigation extends PluginBaseModule {
        private msg;
        createRenderRoot(): this;
        render(): TemplateResult<1>;
        createNavigation(array: IInfoElCholdren[]): TemplateResult<1>;
        renderItemTree(item: IInfoElCholdren, idx: string): TemplateResult<1>;
        forceUpdate(): void;
        private getICAComponents;
        private idLastClick;
        private selectItem;
        private clickGroupHidden;
        private setLock;
        private delEl;
        private activeMove;
        private setDragDrop;
        private mouseOver;
        private mouseLeave;
        private myCss;
    }
    interface IInfoElCholdren {
        el: IcaLitElementBaseMethods;
        children: IInfoElCholdren[];
    }
}
declare module "_100554_pluginPageProperties" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    import { ServiceBase } from "_100554_serviceBase";
    export class PluginPageProperties extends PluginBaseModule {
        private msg;
        service: ServiceBase | undefined;
        elementAttributes: {
            key: string;
            value: string;
        }[];
        shouldUpdate(changedProperties: Map<string | number | symbol, unknown>): boolean;
        createRenderRoot(): this;
        render(): TemplateResult<1>;
        createItens(): TemplateResult<1>;
        renderItem(item: {
            key: string;
            value: string;
        }, idx: string): TemplateResult<1>;
        forceUpdate(): void;
        private servicePreview;
        private setServicePreview;
        private getMyAttributes;
    }
}
declare module "_100554_pluginPreviewResultJs" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export class PluginPreviewResultJs extends PluginBaseModule {
        private msg;
        private _ed1;
        private hasError;
        private results;
        get confE(): string;
        msize: string;
        editor: IHTMLEditorElement | undefined;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): TemplateResult<1>;
        private createEditor;
        private getCompileResults;
        private setInitialModelProdJS;
        private getUri;
        private createOrGetModel;
    }
    interface IHTMLEditorElement extends HTMLElement {
        mlsEditor: monaco.editor.IStandaloneCodeEditor;
    }
}
declare module "_100554_pluginProjectConfig" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectConfig extends PluginBaseModule {
        static modelCount: number;
        private msg;
        autoPrepare: boolean;
        msize: string;
        c2: HTMLElement | undefined;
        body: HTMLDivElement | undefined;
        private _ed1;
        private model;
        private lastProject;
        private template;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        setEvents(): Promise<void>;
        private _clearChanges;
        private refreshIfNeeded;
        private setMsizeEditor;
        private createEditor;
        private loadProjectConfigs;
        private setInitialConfig;
        private createOrGetModel;
        private timeoutChangesEditorStyle;
        private setEventsModel;
        private onEditorChange;
        private getUri;
        private styles;
    }
}
declare module "_100554_pluginProjectInfo" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectInfo extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        project: string | undefined;
        projectName: string | undefined;
        projectDriver: string | undefined;
        projectOrg: string | undefined;
        projectOwner: string | undefined;
        projectCreatedAt: string | undefined;
        projectURL: string | undefined;
        forks: mls.stor.others.IFork[] | undefined;
        branches: mls.stor.others.IBranch[] | undefined;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        renderInfo(): TemplateResult;
        renderInfoFork(): TemplateResult;
        renderForksItem(): TemplateResult;
        private init;
        private setInfos;
        private getForks;
        private getMyKeysBranch;
    }
}
declare module "_100554_pluginProjectDetail" {
    import { TemplateResult, LitElement } from "_100554_litElement";
    import "_100554_pluginProjectInfo";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectDetail extends LitElement {
        contentproject: HTMLElement | undefined;
        contentprojectinfo: HTMLElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        private loadProject;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_pluginProjectFindFiles" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export class PluginProjectFindFiles extends PluginBaseModule {
        private msg;
        private matchedFiles;
        private progressValue;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        onSearch(): Promise<void>;
        searchFiles(files: string[], searchText: string): Promise<void>;
    }
    export const pluginData: mls.plugin.IPluginData;
}
declare module "_100554_pluginProjectIndex" {
    import { PluginBaseIndex } from "_100554_pluginBaseIndex";
    export class PluginProjectIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_3: PluginProjectIndex;
    export default _default_3;
}
declare module "_100554_pluginProjectReadMe" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    import { CollabEditMd } from "_100554_collabEditMd";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectReadMe extends PluginBaseModule {
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        mkEditor: CollabEditMd | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderReadme;
        private setReadme;
        private onChangeMd;
        private createFile;
        _getValueInfo(file: mls.stor.IFileInfo, originalShortName?: string, originalFolder?: string, originalProject?: number, originalCRC?: string): Promise<mls.stor.IFileInfoValue>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_pluginProjectUsage" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginProjectUsage extends PluginBaseModule {
        private msg;
        autoPrepare: boolean;
        designSystems: number | undefined;
        projectLastModified: string | undefined;
        files: number | undefined;
        chartData: {};
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        private renderResume;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_wcChart" {
    import { IcaApresentationCharts2DBase } from "_100554_icaApresentationCharts2DBase";
    export class WcEchartsPie100554 extends IcaApresentationCharts2DBase {
        createRenderRoot(): this;
        datasource: any | undefined;
        chartTitle: string;
        framework: 'echarts';
        renderer: 'canvas' | 'svg';
        main: HTMLDivElement | undefined;
        private myChart;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private waitForLoadIfNeeded;
        initChart(): void;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_pluginSiteMonitorDashboardActiveUsers" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardActiveUsers extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_pluginSiteMonitorDashboardErrors" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardErrors extends PluginBaseModule {
        filter: string;
        chartData: {};
        autoPrepare: boolean;
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_pluginSiteMonitorDashboardExpenses" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardExpenses extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_pluginSiteMonitorDashboardRegionalLatency" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardRegionalLatency extends PluginBaseModule {
        filter: string;
        chartDataBar: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        bar: HTMLDivElement | undefined;
        map: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_pluginSiteMonitorDashboardResponseTime" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardResponseTime extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_pluginSiteMonitorDashboardSales" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardSales extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_pluginSiteMonitorDashboardSpikes" {
    import { TemplateResult } from "_100554_litElement";
    import { PluginBaseModule } from "_100554_pluginBaseModule";
    export const pluginData: mls.plugin.IPluginData;
    export class PluginSiteMonitorDashboardSpikes extends PluginBaseModule {
        filter: string;
        chartData: any;
        autoPrepare: boolean;
        mode: 'simplified' | 'full';
        body: HTMLDivElement | undefined;
        prepare(): Promise<void>;
        firstUpdated(): void;
        createRenderRoot(): this;
        render(): TemplateResult;
        renderHeader(): TemplateResult;
        renderBody(): TemplateResult;
        handleChange(e: MouseEvent): void;
    }
}
declare module "_100554_pluginSiteMonitorIndex" {
    import { PluginBaseIndex } from "_100554_pluginBaseIndex";
    export class PluginSiteMonitorIndex extends PluginBaseIndex {
        getMenus(): mls.plugin.MenuAction[];
        getHooks(): mls.plugin.HookAction[];
        getServices(): mls.plugin.ServiceAction[];
    }
    const _default_4: PluginSiteMonitorIndex;
    export default _default_4;
}
declare module "_100554_pluginStyleBackground" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginCssTokens extends CollabLitElement {
        private msg;
        showFull: string;
        info: IMyInfoBackground;
        css: string;
        render(): TemplateResult<1>;
        renderBody2(): TemplateResult<1>;
        renderBody(): TemplateResult<1>;
        renderConfig(): TemplateResult<1>;
        renderAux(): TemplateResult<1>;
        renderItens(): TemplateResult<1>;
        renderGallery(): TemplateResult<1>;
        private clickGallery;
        private onlyNumber;
        private changeType;
        private add;
        private del;
        private configString;
        private rgbaToHex;
        private hexToRgba;
        private changeStr;
        private timeonChangeProp;
        private onChangeProp;
        private onChangeAux;
        private changeValues;
        private mountMyValue;
        private myMsg;
        private arrayGallery;
    }
    interface IMyInfoBackground {
        tp: string;
        aux: string;
        itens: {
            value: string;
            transp: string;
            stop: string;
        }[];
    }
}
declare module "_100554_pluginStyleBorder" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    import "_100554_collabDsInputSelectColor";
    import "_100554_collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleBorder extends CollabLitElement {
        private msg;
        showFull: string;
        borderLocked: boolean;
        borderRadiusLocked: boolean;
        inputLockRadius: HTMLInputElement | undefined;
        inputLock: HTMLInputElement | undefined;
        borderInputs: HTMLInputElement[] | undefined;
        borderRadiusInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        private tpBorder;
        render(): TemplateResult<1>;
        renderBorder(): TemplateResult<1>;
        renderBorderRadius(): TemplateResult<1>;
        renderBorderGallery(): TemplateResult<1>;
        private timeonChangeBorder;
        private handleChangeBorder;
        private timeonChangeBorderRadius;
        private handleChangeBorderRadius;
        private handleChangeLockBorderRadius;
        private handleChangeLockBorder;
        private gallery;
    }
}
declare module "_100554_pluginStyleClippath" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleClipath extends CollabLitElement {
        showFull: string;
        render(): TemplateResult<1>;
        renderGallery(): TemplateResult<1>;
        private arrayGallery;
    }
}
declare module "_100554_pluginStyleColumn" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    import "_100554_collabDsInputSelectColor";
    import "_100554_collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleColumn extends CollabLitElement {
        showFull: string;
        private msg;
        private tpMeasures;
        private tpBorder;
        private arrayGallery;
        render(): TemplateResult<1>;
        renderColumn(): TemplateResult<1>;
        renderGallery(): TemplateResult<1>;
    }
}
declare module "_100554_pluginStyleFlex" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    import "_100554_collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleFlex extends CollabLitElement {
        private msg;
        showFull: string;
        render(): TemplateResult<1>;
        renderFlex(): TemplateResult<1>;
        renderFlexItem(): TemplateResult<1>;
        renderGallery(): TemplateResult<1>;
        private arrayGallery;
    }
}
declare module "_100554_pluginStyleSpacing" {
    import { TemplateResult } from "_100554_litElement";
    import { IcaLitElement } from "_100554_icaLitElement";
    import "_100554_collabDsInputSelectColor";
    import "_100554_collabDsInputRange";
    import { ICSSState } from "_100554_lessCSS";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleSpacing extends IcaLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        showFull: string;
        marginLocked: boolean;
        paddingLocked: boolean;
        marginLeft: string | undefined;
        marginRight: string | undefined;
        marginTop: string | undefined;
        marginBottom: string | undefined;
        paddingLeft: string | undefined;
        paddingRight: string | undefined;
        paddingTop: string | undefined;
        paddingBottom: string | undefined;
        inputLockP: HTMLInputElement | undefined;
        inputLockM: HTMLInputElement | undefined;
        marginInputs: HTMLInputElement[] | undefined;
        paddingInputs: HTMLInputElement[] | undefined;
        private tpMeasures;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        render(): TemplateResult<1>;
        renderMargin(): TemplateResult<1>;
        renderPadding(): TemplateResult<1>;
        renderGallery(): TemplateResult<1>;
        private _onIcaStateChange;
        private timeonChangeMargin;
        private handleChangeMargin;
        private timeonChangePadding;
        private handleChangePadding;
        private handleChangeLockPadding;
        private handleChangeLockMargin;
        private setState;
        updateMargins(margin: string | {
            [key: string]: string;
        }): void;
        updatePadding(padding: string | {
            [key: string]: string;
        }): void;
        private setValues;
        private findCSSRuleInIframe;
        private onGalleryClick;
        private gallery;
    }
}
declare module "_100554_pluginStyleTextShadow" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    import "_100554_collabDsInputSelectColor";
    import "_100554_collabDsInputRange";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleTextShadow extends CollabLitElement {
        showFull: string;
        private msg;
        private tpMeasures;
        private arrayGallery;
        render(): TemplateResult<1>;
        renderColumn(): TemplateResult<1>;
        renderGallery(): TemplateResult<1>;
    }
}
declare module "_100554_pluginStyleTokens" {
    import { IcaLitElement } from "_100554_icaLitElement";
    import { ICSSState } from "_100554_lessCSS";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginCssTokens extends IcaLitElement {
        private msg;
        state: ICSSState | undefined;
        position: 'left' | 'right';
        level: number;
        prop: string;
        value: string;
        theme: string;
        tokens: Record<string, Record<string, Record<string, string>>>;
        private dsInstance;
        private initDsInstance;
        private getTokensColor;
        private groupColorsByState;
        handleColorClick(key: string, value: string): void;
        setTooltip(): void;
        getTokens(): Promise<void>;
        updated(changedProperties: any): void;
        firstUpdated(a: any): Promise<void>;
        handleIcaStateChange(_key: string, _value: ICSSState): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_pluginStyleTransform" {
    import { TemplateResult } from "_100554_litElement";
    import { CollabLitElement } from "_100554_collabLitElement";
    export const tags: string[];
    export function getDescription(): string;
    export class PluginStyleTransform extends CollabLitElement {
        showFull: string;
        private msg;
        private arrayGallery;
        render(): TemplateResult<1>;
        renderTransform(): TemplateResult<1>;
        renderGallery(): TemplateResult<1>;
    }
}
declare module "_100554_previewState" {
    global {
        interface Window {
            preview: {
                editor: monaco.editor.IStandaloneCodeEditor | undefined;
                iframe: HTMLIFrameElement | undefined;
            };
        }
    }
}
declare module "_100554_saveAddBranch" {
    import { LitElement } from "_100554_litElement";
    export const initServiceSaveaddBranch: () => void;
    export class ServiceSaveAddBRanch extends LitElement {
        hint: string | undefined;
        callBack: Function | undefined;
        private owner;
        private repo;
        private branch;
        private branchMain;
        private listForks;
        private error;
        private driver;
        private mode;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderModeList(): import("_100554_litHtml").TemplateResult<1>;
        renderModeAdd(): import("_100554_litHtml").TemplateResult<1>;
        renderBranchs(): import("_100554_litHtml").TemplateResult<1>;
        renderForks(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(obj: {
            name: string;
        }, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderItemFork(obj: mls.stor.others.IFork, index: number): import("_100554_litHtml").TemplateResult<1>;
        private init;
        private cancel;
        private addClick;
        private addBranch;
        private addNewBranch;
        private getInfosRepo;
        private setItem;
        private setItemFork;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_scenarioInsertEventOrChange" {
    import { LitElement } from "_100554_litElement";
    import { IScenaryDetails } from "_100554_collabLitElement";
    export function _100554_scenarioInsertEventOrChange_getScenaryDetails(): IScenaryDetails;
    export const initCollabSelectOneWithDescription = "";
    export class ScenarioInsertEventOrChange extends LitElement {
        private msg;
        private myInfos;
        private scenario;
        private devicePR;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderNoSelected(): import("_100554_litHtml").TemplateResult<1>;
        renderScenarioHowDo(): import("_100554_litHtml").TemplateResult<1>;
        renderYourSelfDevice(): import("_100554_litHtml").TemplateResult<1>;
        renderPreReadyDevice(): import("_100554_litHtml").TemplateResult<1>;
        renderPreReady(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(item: any, idx: number): import("_100554_litHtml").TemplateResult<1>;
        private init;
        private setInfos;
        private selectedDesktop;
        private selectedMobile;
        private goToYS;
        private goToInit;
        private goToDevicePR;
        private selDesktopPR;
        private selMobilePR;
        private selectedItemPR;
        static styles: import("_100554_litCssTag").CSSResult;
        private iconsEvents;
        private preRotinas;
    }
}
declare module "_100554_serviceAdminPanel" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import "_100554_collabPanel";
    export class ServiceAdminPanel100554 extends ServiceBase {
        msize: string;
        serviceAdminPanel: HTMLElement | undefined;
        static styles: import("_100554_litCssTag").CSSResult;
        private myData;
        inLoading: string;
        activeTab: string;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        menu: IMenu;
        firstUpdated(): void;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        renderRepository(): import("_100554_litHtml").TemplateResult<1>;
        renderPlugin(): import("_100554_litHtml").TemplateResult<1>;
        renderSite(): import("_100554_litHtml").TemplateResult<1>;
        renderItens(): import("_100554_litHtml").TemplateResult<1>;
        renderFilter(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(key: string, index: number): import("_100554_litHtml").TemplateResult<1>;
        private timeFilter;
        private filter;
        private setMyData;
    }
}
declare module "_100554_serviceAim" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import { ResponseFindActions } from "_100554_aimActionBase";
    export class ServiceAim100554 extends ServiceBase {
        private myMessage;
        constructor();
        activeTab: ITabType;
        useContainerAdd: boolean;
        actionToOpen: string;
        actualServiceOpName: string;
        isloading: boolean;
        actualServiceOpLevel: number;
        render(): import("_100554_litHtml").TemplateResult<1>;
        details: IService;
        get invertedPosition(): "left" | "right";
        static styles: import("_100554_litCssTag").CSSResult;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        setEvents(): void;
        onToolbarSelectChange(ev: mls.events.IEvent): void;
        sortKey(arr: mls.cbe.ITaskRoot[]): mls.cbe.ITaskRoot[];
        renderAll(): import("_100554_litHtml").TemplateResult<1>;
        renderUser(): import("_100554_litHtml").TemplateResult<1>;
        renderRef(): import("_100554_litHtml").TemplateResult<1>;
        actions: ResponseFindActions[];
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        sendRefreshRequest(): void;
        handleRefreshRequest(): void;
        connectedCallback(): Promise<void>;
        attributeChangedCallback(prop: string, oldValue: string, newValue: string): Promise<void>;
        private setActions;
        private getActionsByContext;
        renderAdd(): import("_100554_litHtml").TemplateResult<1>;
        onAddTask(action: ResponseFindActions, index: number): void;
        finishedAddTaskRoot(e: CustomEvent): void;
        loadAndRenderComponent(widget: string, container: HTMLElement | null | undefined): Promise<void>;
        private loadComponentModule;
        private stateColumns;
        renderColums(): import("_100554_litHtml").TemplateResult<1>;
        private handleInputChange;
        private handleCancelColumnClick;
        private handleSaveColumnClick;
        private showConfigColumns;
        private checkIfHasActionToOpen;
    }
    type ITabType = 'All' | 'User' | 'Ref' | 'Add' | 'Loading';
}
declare module "_100554_serviceCreateProject" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceCreateProject100554 extends ServiceBase {
        constructor();
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        currentScenario: IScenaries;
        actualSiteSelected: ISites | undefined;
        sitesItems: NodeListOf<HTMLElement> | undefined;
        publishItems: NodeListOf<HTMLElement> | undefined;
        storageItems: NodeListOf<HTMLElement> | undefined;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickTitle(): void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private changeScenario;
        private onBtnContinueClick;
        private onBtnCreateClick;
        private onTypeSiteClick;
        private onPluginPublishClick;
        private onPluginStorageClick;
        private setEvents;
        private renderSelect;
        private renderCustomize;
        private renderScenario;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private data;
        private pluginsPublish;
        private pluginsStorage;
    }
    type IScenaries = 'select' | 'customize';
    interface ISites {
        mode: 'site' | 'system';
        title: string;
        description: string;
        more: string;
        web: true;
        mobile: boolean;
        appMobileIOS: boolean;
        appMobileAndroid: boolean;
        backend: boolean;
        multilanguage: boolean;
    }
}
declare module "_100554_serviceDashboard" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import "_100554_collabTiles";
    export class ServiceDashboard100554 extends ServiceBase {
        msize: string;
        cssBreakPoint: string;
        activeTab: string;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        createRenderRoot(): this;
        firstUpdated(): void;
        private refreshTimeOut;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        renderIcon1(): import("_100554_litHtml").TemplateResult<1>;
        renderIcon2(): import("_100554_litHtml").TemplateResult<1>;
        private pluginsDash1;
        private pluginsDash2;
        private loadAndSetPlugins;
        private getInfoPlugin;
    }
}
declare module "_100554_serviceDetail" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDetail100554 extends ServiceBase {
        static styles: import("_100554_litCssTag").CSSResult;
        msize: string;
        contentPlugin: HTMLDivElement | undefined;
        private plugin;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        private showAboutThis;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private setEvents;
        private onMonacoEvents;
        private onFileActionReceived;
        private onPluginDetails;
        private showPluginContent;
        private getHtmlFromPlugin;
        private updateContentPluginWithScripts;
        private fireEvents;
    }
}
declare module "_100554_serviceDetailsDs" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDetailsDs100554 extends ServiceBase {
        private myMessage;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        state: IState;
        setEvents(): void;
        private ds;
        showOverview(): boolean;
        private init;
        private setResume;
        private getStyleLines;
        private getAssetsLenght;
        private getLastModifiedFormated;
        private onLinkClick;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    interface IState {
        name: string | undefined;
        createdBy: string | undefined;
        lastUpdated: string | undefined;
        lastUpdatedBy: string | undefined;
        documentation: number | undefined;
        tokens: number | undefined;
        assets: number | undefined;
        components: number | undefined;
        style: number | undefined;
    }
}
declare module "_100554_serviceDsAssets" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import { CollabInputTag } from "_100554_collabInputTag";
    export class ServiceDsAssets100554 extends ServiceBase {
        private msg;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        connectedCallback(): Promise<void>;
        private init;
        tbody: HTMLElement | undefined;
        treeEl: HTMLElement | undefined;
        checkBoxAll: HTMLInputElement | undefined;
        inputTags: CollabInputTag | undefined;
        txtDesc: HTMLTextAreaElement | undefined;
        inputFile: HTMLInputElement | undefined;
        selectType: HTMLInputElement | undefined;
        tree: TreeNode;
        isAddMode: boolean;
        actualFiles: mls.stor.IFileInfo[];
        actualPath: string;
        private treeController;
        private filesController;
        private dsInstance;
        private lastProject;
        private lastDsIndex;
        private files;
        private serviceByExtensions;
        private objIcons;
        private showInitial;
        private initDsInstance;
        private prepareFiles;
        private onDsAssetsChanged;
        private onDelete;
        private handleFolderClick;
        private updateActualFiles;
        private checkIsReadOnlyNode;
        private getFilesInFolder;
        private onCheckAllChange;
        private addSelectedItem;
        private removeSelectedItem;
        private fireEventSelectedsItens;
        private onFileClick;
        private toogleCheckBoxAll;
        private onActionAddConfirm;
        private onActionAddCancel;
        private onAddNewFileClick;
        renderNode(key: string, node: any, folder: string): any;
        private renderTable;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    export interface IFileController {
        totalFiles: number;
        totalFilesSelected: number;
        filesSelected: Set<mls.stor.IFileInfo>;
        filesSelectedArr: mls.stor.IFileInfo[];
        helper: string[];
        readOnly: boolean;
    }
    export interface IAssetsEventChangedParams {
        info: IFileController;
        position: "left" | "right";
        action: "show" | "delete" | "update";
    }
    interface TreeNode {
        [key: string]: ITreeItemFolder | mls.stor.IFileInfo;
    }
    interface ITreeItemFolder {
        shortName: string;
        folder: string;
    }
    export interface IAssetsEventSelectedParams {
        service: string[];
    }
}
declare module "_100554_serviceDsAssetsEditor" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsAssetsEditor100554 extends ServiceBase {
        constructor();
        static modelCount: number;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        createRenderRoot(): this;
        private _ed1;
        private model;
        private data;
        msize: string;
        private c2;
        private editorTypeByExtensions;
        private onDsAssetsUnSelected;
        private onDsAssetsChanged;
        private createEditor;
        private getUri;
        private setInitialModels;
        private setMsizeEditor;
        private showEditor;
        private showEditor2;
        private getValue;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceDsAssetsImage" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsAssetsImage100554 extends ServiceBase {
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        private imageEl;
        private data;
        private onDsAssetsUnSelected;
        private onDsAssetsChanged;
        private showInitial;
        private setImage;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceDsAssetsOverview" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsAssetsOverview100554 extends ServiceBase {
        private msg;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        private data;
        private ds;
        private onDsAssetsUnSelected;
        private onDsAssetsChanged;
        private showInitial;
        private state;
        private setData;
        private initDs;
        private prepareStateFile;
        private handleKeyUp;
        private handleValueChanged;
        private handleDelete;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceDsAssetsVideo" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsAssetsVideo100554 extends ServiceBase {
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        private videoEl;
        private data;
        private showInitial;
        private onDsAssetsUnSelected;
        private onDsAssetsChanged;
        private setVideo;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceDsColors" {
    import { IToolbarContent, IMenu } from "_100554_serviceBase";
    import { CollabLitElement } from "_100554_collabLitElement";
    export class ServiceDsColors100554 extends CollabLitElement {
        private msg;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private showHelper;
        setEvents(): void;
        private actualTokens;
        private themes;
        showAddContainer: boolean;
        private themeList;
        private newDataTokens;
        private defaultThemeList;
        private userThemeList;
        private selectedTheme;
        private ds;
        private keysName;
        service_color_add: HTMLElement | undefined;
        service_color_delete: HTMLElement | undefined;
        service_color_update: HTMLElement | undefined;
        service_color_revert: HTMLElement | undefined;
        service_color_inp_themedesc: HTMLInputElement | undefined;
        service_color_inp_themename: HTMLInputElement | undefined;
        select_theme: HTMLSelectElement | undefined;
        private init;
        connectedCallback(): Promise<void>;
        private getThemes;
        private getAllThemes;
        private getThemesDefault;
        private getUserThemes;
        private mergeThemes;
        private getTokens;
        private onDSColorChanged;
        private scrollToKey;
        private updateActualTokens;
        private getColorsItem;
        private onChangeTokens;
        private onChangeTheme;
        private handleAddThemeClick;
        private onCancelAction;
        private onConfirmAction;
        private updateTheme;
        private deleteTheme;
        private saveTheme;
        private revertTokensColors;
        private toogleIconOnAction;
        handleClickColorItem(el: HTMLElement): void;
        handleInputColorItem(key: string, e: MouseEvent): void;
        private setActive;
        firstUpdated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private mythemes;
    }
}
declare module "_100554_serviceDsComponentsList" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsComponentsList100554 extends ServiceBase {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        itens: IServiceComponents[];
        error: string;
        private selectWidget;
        private ds;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderNoItens(): import("_100554_litHtml").TemplateResult<1>;
        renderItens(): import("_100554_litHtml").TemplateResult<1>;
        renderGroup(item: IServiceComponents, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderComponent(item: mls.l3.IComponentInfo, index: number): import("_100554_litHtml").TemplateResult<1>;
        setEvents(): void;
        private init;
        private setList;
        private onDsWidgetsChanged;
        private openComponent;
        private openMeList;
        private timeShowLoader;
        private showLoader;
        private updateMyMessages;
        private myMsg;
        fireComunication(info: mls.l3.IComponentInfo): void;
    }
    export interface IEventDSWidgetsChangedParams {
        op: 'widgets' | 'update';
        position: string;
        value: mls.l3.IComponentInfo | undefined;
    }
    interface IServiceComponents {
        group: string;
        icon: string;
        components: mls.l3.IComponentInfo[];
    }
}
declare module "_100554_serviceDsComponentDetails" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceDsComponentDetails100554 extends ServiceBase {
        private msg;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private state;
        private group;
        private onDsWidgetsSelected;
        private onDsWidgetsUnSelected;
        private onDsWidgetsChanged;
        private onEditStyleClick;
        private removeComponent;
        private updateComponent;
        private timeoutGroup;
        private handleInputChangeGroup;
        private handleInputChangeTags;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceDsDocList" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import { DesignSystemIO } from "_100554_libDesignSystem";
    export class ServiceDsDocList100554 extends ServiceBase {
        private msg;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        list: IDocNode[];
        docIdSelected: number;
        loading: boolean;
        containerMain: HTMLElement | undefined;
        lastDsIndex: number | undefined;
        lastProject: number | undefined;
        dsInstance: DesignSystemIO | undefined;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        connectedCallback(): Promise<void>;
        setEvents(): void;
        getState(): Promise<void>;
        getListDocs(): Promise<mls.l3.IDocInfo[]>;
        createFolderStructure(arr: mls.l3.IDocInfo[]): IDocNode[];
        private onDocPageChanged;
        private addDoc;
        private changedMe;
        private updateDoc;
        private removeDoc;
        private addNewDoc;
        private selectDoc;
        private onDetailsClick;
        private seeDocumentation;
        renderList(items: IDocNode[]): any;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    export interface IDocData {
        op: 'Open' | 'Add' | 'Update' | 'Change' | 'Delete';
        title: string;
        content: string;
        id: number;
        parentID: number;
        hasChildren: boolean;
    }
    interface IDocNode {
        id: number;
        item: mls.l3.IDocInfo | undefined;
        children: IDocNode[];
    }
}
declare module "_100554_serviceDsDocView" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import { EditorQuillDocs100554 } from './_100554_editorQuillDocs';
    import { IDocData } from "_100554_serviceDsDocList";
    export class ServiceDsDocView100554 extends ServiceBase {
        private msg;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        doc: IDocData | undefined;
        editor: EditorQuillDocs100554 | undefined;
        docTitle: HTMLElement | undefined;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        _onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): Promise<void>;
        private setEvents;
        private onDSDocPageClicked;
        private waitForEditorLoad;
        private fireComunication;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceDsStyleBackground" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleBackground extends ServiceBase {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        css: string;
        helper: string;
        info: IMyInfoBackground;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderBody(): import("_100554_litHtml").TemplateResult<1>;
        renderConfig(): import("_100554_litHtml").TemplateResult<1>;
        renderAux(): import("_100554_litHtml").TemplateResult<1>;
        renderItens(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private clickGallery;
        private onlyNumber;
        private changeType;
        private add;
        private del;
        private configString;
        private rgbaToHex;
        private hexToRgba;
        private changeStr;
        private timeonChangeProp;
        private onChangeProp;
        private onChangeAux;
        private changeValues;
        private mountMyValue;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
        private updateMyMessages;
        private myMsg;
        private arrayGallery;
    }
    interface IMyInfoBackground {
        tp: string;
        aux: string;
        itens: {
            value: string;
            transp: string;
            stop: string;
        }[];
    }
}
declare module "_100554_serviceDsStyleBorder" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class ServiceDsStyleBorder extends CollabLitElement {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        private setEvents;
        private onstylechanged;
        private setValues;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderBorder(): import("_100554_litHtml").TemplateResult<1>;
        renderRadius(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private tpMeasures;
        private tpBorder;
        private timeonChangeProp;
        private onChangeProp;
        private beforeEmitEvent;
        private uppProp;
        private emitEvent;
        private clickGallery;
        private arrayGallery;
    }
}
declare module "_100554_serviceDsStyleClippath" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleClippath extends ServiceBase {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private clickGallery;
        private arrayGallery;
        private timeLoader;
        private showLoader;
    }
}
declare module "_100554_serviceDsStyleColumn" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleColumn extends ServiceBase {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private setValues;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderColumn(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private tpMeasures;
        private tpBorder;
        private timeonChangeProp;
        private onChangeProp;
        private onChangeProp2;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
        private clickGallery;
        private arrayGallery;
    }
}
declare module "_100554_serviceDsStyleFilter" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleFilter extends ServiceBase {
        private msg;
        private filter;
        private myUpp;
        private opened;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderFilter(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private timeonChangeProp;
        private onChangeProp;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
        mountValue(): void;
        private setValues;
        private clickGallery;
        private arrayGallery;
    }
}
declare module "_100554_serviceDsStyleFlex" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleFlex extends ServiceBase {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private setValues;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderFlex(): import("_100554_litHtml").TemplateResult<1>;
        renderFlexItem(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private timeonChangeProp;
        private onChangeProp;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
        private clickGallery;
        private arrayGallery;
    }
}
declare module "_100554_serviceDsStyleSize" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleSize extends ServiceBase {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private setValues;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderBody(): import("_100554_litHtml").TemplateResult<1>;
        renderWidth(): import("_100554_litHtml").TemplateResult<1>;
        renderHeight(): import("_100554_litHtml").TemplateResult<1>;
        renderOverflow(): import("_100554_litHtml").TemplateResult<1>;
        private tpMeasures;
        private onChangeProp2;
        private timeonChangeProp;
        private onChangeProp;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
    }
}
declare module "_100554_serviceDsStyleSpacing" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleSpacing extends ServiceBase {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private setValues;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderMargin(): import("_100554_litHtml").TemplateResult<1>;
        renderPadding(): import("_100554_litHtml").TemplateResult<1>;
        private tpMeasures;
        private timeonChangeProp;
        private onChangeProp;
        private beforeEmitEvent;
        private uppProp;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
    }
}
declare module "_100554_serviceDsStyleTesxtshadow" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleTextShadow extends ServiceBase {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private setValues;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderColumn(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private tpMeasures;
        private timeonChangeProp;
        private onChangeProp;
        private mountValue;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
        private clickGallery;
        private arrayGallery;
    }
}
declare module "_100554_serviceDsStyleTransform" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleTransform extends ServiceBase {
        private msg;
        private filter;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderTransform(): import("_100554_litHtml").TemplateResult<1>;
        renderGallery(): import("_100554_litHtml").TemplateResult<1>;
        private timeonChangeProp;
        private onChangeProp;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
        private mountValue;
        private setValues;
        private clickGallery;
        private arrayGallery;
    }
}
declare module "_100554_serviceDsStyleTypography" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceDsStyleTypography extends ServiceBase {
        private msg;
        private myUpp;
        static styles: import("_100554_litCssTag").CSSResult;
        error: string;
        helper: string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onstylechanged;
        private setValues;
        private onDSStyleSelected;
        private onDSStyleUnSelected;
        private onDSStyleCursorChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private tpMeasures;
        private timeonChangeProp;
        private onChangeProp;
        private onChangeProp2;
        private fireEventAboutMe;
        private emitEvent;
        private timeLoader;
        private showLoader;
    }
}
declare module "_100554_serviceEditProject" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    global {
        interface Window {
            project_config: mls.l5_common.ProjectConfig;
        }
    }
    export class ServiceEditProject100554 extends ServiceBase {
        constructor();
        private msg;
        static modelCount: number;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        setEvents(): Promise<void>;
        msize: string;
        private c2;
        private _ed1;
        private model;
        private lastProject;
        private template;
        private showStart;
        private clearChanges;
        private _clearChanges;
        private refreshIfNeeded;
        private setMsizeEditor;
        private createEditor;
        private loadProjectConfigs;
        private setInitialConfig;
        private createOrGetModel;
        private timeoutChangesEditorStyle;
        private setEventsModel;
        private onEditorChange;
        private getUri;
        firstUpdated(): void;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceExploreProjects" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import "_100554_pluginCreateNewProject";
    export class ServiceExploreProjects100554 extends ServiceBase {
        private msg;
        projectCreated: boolean;
        state: IServiceList;
        lastPrjId: string | null | undefined;
        currentScenario: IScenaries;
        list: NodeListOf<HTMLElement> | undefined;
        titleList: NodeListOf<HTMLElement> | undefined;
        historieEl: HTMLElement | undefined;
        activeTab: string;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private setEvents;
        connectedCallback(): void;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        renderExplore(): import("_100554_litHtml").TemplateResult<1>;
        renderMyProject(): import("_100554_litHtml").TemplateResult<1>;
        renderSelectProject(): import("_100554_litHtml").TemplateResult<1>;
        renderAdd(): import("_100554_litHtml").TemplateResult<1>;
        private firedetail;
        private backScenaryList;
        private getLastProject;
        private getOrgsAndProjects;
        private clearState;
        private loadHistory;
        private filterTimeout;
        private _filterProjects;
        private onAddNewProjectClick;
        private changeScenario;
        private onHistoryClick;
        private onProjectClick;
        private openExplore;
        private setProjectActual;
        private setOrgActual;
        private _fireEventProjectSelected;
        private loadProjectActual;
        private addOnHistory;
        private projectCreatedNumber;
        private onProjectCreated;
    }
    type IScenaries = 'details' | 'select' | 'add';
    export interface IProjectDetails {
    }
    interface IStateOrg {
        key: string;
        name: string;
        created_at: string;
        description: string;
        projects: any[];
    }
    interface IServiceList {
        history: IHistory[];
        orgs: IStateOrg[];
        projectSelected: number | undefined;
    }
    interface IHistory {
        project: number;
        name: string;
    }
}
declare module "_100554_serviceHistories" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceHistories100554 extends ServiceBase {
        private msg;
        constructor();
        msize: string;
        createRenderRoot(): this;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        private c2;
        static modelCount: number;
        private _ed1;
        private fileInfo;
        private hashOriginal;
        private hashModified;
        private histories;
        get confE(): string;
        private showStart;
        private onToolbarSelected;
        private onSelectHistories;
        private getHistories;
        private setInitialHistories;
        private createOrGetModel;
        private getUri;
        private createEditor;
        private setMsizeEditor;
        private _onServiceClick;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceIca" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceFca100554 extends ServiceBase {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        activeTab: ITabType;
        helpDiv: HTMLDivElement | undefined;
        constructor();
        details: IService;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        renderNavigation(): import("_100554_litHtml").TemplateResult<1>;
        renderProperties(): import("_100554_litHtml").TemplateResult<1>;
        renderStyles(): import("_100554_litHtml").TemplateResult<1>;
        renderAnimation(): import("_100554_litHtml").TemplateResult<1>;
        renderAboutICA(): import("_100554_litHtml").TemplateResult<1>;
        private loadHelpPage;
        private setEvents;
        private onWCDEvent;
        private onWCDEventChange;
    }
    export type ITabType = 'Navigation' | 'Properties' | 'Styles' | 'Animation' | 'AboutICA';
    export interface IWCDParams {
        level: number;
        position: 'left' | 'right';
        wdcPath: string;
        op: ITabType;
    }
}
declare module "_100554_serviceNotification" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceNotification100554 extends ServiceBase {
        private msg;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_servicePage" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServicePage100554 extends ServiceBase {
        private msg;
        createRenderRoot(): this;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        activeTab: ITabType;
        pluginNav: string;
        pluginProp: string;
        pluginsIA: {
            [key: string]: mls.plugin.MenuAction[];
        };
        pluginIALoaded: boolean;
        firstUpdated(): Promise<void>;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        renderNavigation(): import("_100554_litHtml").TemplateResult<1>;
        renderProperties(): import("_100554_litHtml").TemplateResult<1>;
        renderDetails(): import("_100554_litHtml").TemplateResult<1>;
        renderIA(): import("_100554_litHtml").TemplateResult<1>;
        private loadPlugins;
        private setPluginIA;
    }
    export type ITabType = 'icDetails' | 'icNavigation' | 'icProperties' | 'icIA';
}
declare module "_100554_servicePanel" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import "_100554_collabPanel";
    export class ServicePanel100554 extends ServiceBase {
        msize: string;
        servicePanel: HTMLElement | undefined;
        static styles: import("_100554_litCssTag").CSSResult;
        private myData;
        inLoading: string;
        activeTab: string;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        menu: IMenu;
        firstUpdated(): void;
        updated(changedProperties: any): void;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        renderHistory(): import("_100554_litHtml").TemplateResult<1>;
        renderSite(): import("_100554_litHtml").TemplateResult<1>;
        renderItens(): import("_100554_litHtml").TemplateResult<1>;
        renderFilter(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(key: string, index: number): import("_100554_litHtml").TemplateResult<1>;
        private timeFilter;
        private filter;
        private setMyData;
    }
}
declare module "_100554_servicePreviewView" {
    import { LitElement } from "_100554_litElement";
    export const initServicePreviewView = "";
    export class ServicePreviewView extends LitElement {
        private msg;
        private file;
        private mfile;
        father: any;
        page: string;
        mode: string;
        lang: string;
        level: string;
        isDsComponent: boolean;
        watch: boolean;
        stylechanged: string;
        actualtheme: string;
        error: string;
        lastCompiledUrl: string;
        widthP: string;
        heightP: string;
        private setEventsCollab;
        connectedCallback(): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderError(): import("_100554_litHtml").TemplateResult<1>;
        renderPreview(): import("_100554_litHtml").TemplateResult<1>;
        updated(changedProperties: any): void;
        private onWidgetActionEvents;
        private selectIdinPreview;
        private findElementsStartingWithIca;
        private fireChangeICA;
        private changeLevelIca;
        private addStyles;
        private getEnhacement;
        private load;
        private init;
        private setTheme;
        private setDevice;
        private setMyFile;
        private lastHTML;
        private setHTml;
        private getFileContent;
        private mountJSImporMap;
        private mountJS;
        private simulateService;
        private addTooltip;
        private addNav3;
        private addFA;
        private removeOlderStyle;
        private removeOlderTokens;
        private removeOlderGlobalStyle;
        private mountCSS;
        private getIdStyle;
        private getIdTokens;
        private mountTokens;
        private addGlobalStyle;
        private changeWidthP;
        private changeHeightP;
        private timeShow;
        private showLoader;
        private infoDS;
        private verifyWC;
        private checkIfIsAWebComponent;
        private getGroup;
        private addComponent;
        cleanTree(): string;
        private cleanTree2;
        private cleanTree3;
        static styles: import("_100554_litCssTag").CSSResult;
        private scrollMobile;
    }
}
declare module "_100554_servicePreview" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServicePreview100554 extends ServiceBase {
        static styles: import("_100554_litCssTag").CSSResult;
        itens: any;
        msize: string;
        error: string;
        watch: boolean;
        light: boolean;
        lang: string;
        private msg;
        private lastMode;
        private lastLevel;
        private elPreview;
        private themes;
        private actualTheme;
        private ds;
        private _ed1;
        private monacoeditor;
        private languages;
        private levels;
        private timeEvent;
        get confE(): string;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        onClickButton: (op: string, opMenu?: string) => boolean;
        actButton(op: string, opMenu?: string): Promise<boolean>;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onReloader;
        private onModelHTMLCreated;
        private onDSStyleOrTokensChanged;
        private onStyleChanged;
        private onDsThemeChanged;
        private onMLSFileAction;
        render(): import("_100554_litHtml").TemplateResult<1>;
        firstUpdated(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        private showEditorHTML;
        private pluginResultJS;
        private showResultJS;
        private getIframePreviewHTML;
        private onBtVariationsClick;
        private onBtThemeClick;
        private onBtTokensClick;
        private toogleWatch;
        private onHelpClick;
        private createEditor;
        private createModelIfNeeded;
        private setModel;
        private getUri;
        private getDarkLight;
        private setLanguages;
        private setTheme;
        private preview;
        private fireWcdChanges;
        private requestUpdateAllIcaComponentsInPage;
        private findAllElementsIca;
    }
}
declare module "_100554_servicePreviewAddStyle" {
    import { LitElement } from "_100554_litElement";
    export const initServicePreviewAddStyle = "";
    export class ServicePreviewAddStyle extends LitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        private dsInstance;
        father: any;
        widget: string;
        level: string;
        tags: string[];
        error: string;
        groupName: string;
        styleAlready: boolean;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderStyleAlreadyr(): import("_100554_litHtml").TemplateResult<1>;
        renderAdd(): import("_100554_litHtml").TemplateResult<1>;
        renderItemTag(vl: string, idx: number): import("_100554_litHtml").TemplateResult<1>;
        private init;
        private verifyAlready;
        private getGroup;
        private initds;
        private addInputTag;
        private addTag;
        private deleteTag;
        private deleteItemTag;
        private setTimeLoader;
        private showLoader;
        private addComponent;
    }
}
declare module "_100554_serviceProduct" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import "_100554_pluginGithubL4Project";
    import "_100554_pluginGithubL4Issues";
    export class ServiceWorkspace100554 extends ServiceBase {
        msize: string;
        static styles: import("_100554_litCssTag").CSSResult;
        activeTab: string;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        menu: IMenu;
        firstUpdated(): void;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        renderRequirements(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceProject" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceProject100554 extends ServiceBase {
        private msg;
        activeTab: IScenery;
        explories: mls.plugin.MenuAction[];
        projectDiv: HTMLDivElement | undefined;
        firstDetails: HTMLDetailsExplore | undefined;
        allContainers: HTMLDivElement[] | undefined;
        createRenderRoot(): this;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        menu: IMenu;
        private myData;
        firstUpdated(): Promise<void>;
        updated(changedProperties: Map<string | number | symbol, unknown>): Promise<void>;
        private lastLevel;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private refreshPlugins;
        private updateIconsByLevel;
        private renderContent;
        private fireEventClose;
        private renderExplore;
        private handleDetailExplorieClick;
        private getExploreData;
        private renderShowCase;
        private renderAdmin;
        private renderPanel;
        private renderPlugin;
        private handleAddNewPlugin;
        private pluginsList;
        private groupPluginsByCategory;
        private loadHelpPage;
        private setMyData;
    }
    type IScenery = 'Explore' | 'ShowCase' | 'Admin' | 'Plugins';
    interface HTMLDetailsExplore extends HTMLDetailsElement {
        data: mls.plugin.MenuAction;
    }
}
declare module "_100554_serviceProjectDetails" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import { CollabEditMd } from "_100554_collabEditMd";
    export class ServiceProjectDetails100554 extends ServiceBase {
        private msg;
        private showKey;
        isUpdateFiles: boolean;
        name: string | undefined;
        projectDriver: string | undefined;
        projectOrg: string | undefined;
        projectOwner: string | undefined;
        projectCreatedAt: string | undefined;
        projectLastModified: string | undefined;
        projectURL: string | undefined;
        designSystems: number | undefined;
        projectCreated: boolean;
        files: number | undefined;
        actualKeyDriver: string | null | undefined;
        state: IServiceList;
        lastPrjId: string | null | undefined;
        currentScenario: IScenaries;
        list: NodeListOf<HTMLElement> | undefined;
        titleList: NodeListOf<HTMLElement> | undefined;
        historieEl: HTMLElement | undefined;
        buttonSeePrj: HTMLButtonElement | undefined;
        mkEditor: CollabEditMd | undefined;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickTitle: () => void;
        menu: IMenu;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderScenario(): import("_100554_litHtml").TemplateResult<1>;
        private renderDetails;
        private renderResume;
        private renderConnections;
        private renderFiles;
        private renderInfo;
        private renderReadme;
        private renderCreateTreeFork;
        renderBranchs(): import("_100554_litHtml").TemplateResult<1>;
        renderItem(obj: {
            name: string;
        }, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderItemForks(obj: mls.stor.others.IFork, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderSelectProject(): import("_100554_litHtml").TemplateResult<1>;
        renderAdd(): import("_100554_litHtml").TemplateResult<1>;
        private keyLocalHistory;
        private listForks;
        branchMain: {
            name: string;
        }[];
        private driver;
        private branch;
        private owner;
        private repo;
        private isFecthBranchs;
        private isTimeout;
        private setInfoInitial;
        private getInfosRepo;
        private changeScenario;
        private getDetailsProject;
        private onProjectSelected;
        private getLastProject;
        private handleChangeKey;
        private handleInputChangeKey;
        private projectCreatedNumber;
        private onProjectCreated;
        private onSeeProjectClick;
        private setReadme;
        private onChangeMd;
        private handleUpdateInitialFiles;
        private changePackageFile;
        private changeTsConfigFile;
        private changeBuildFile;
        private changeREADMEFile;
        private createFile;
        _getValueInfo(file: mls.stor.IFileInfo, originalShortName?: string, originalFolder?: string, originalProject?: number, originalCRC?: string): Promise<mls.stor.IFileInfoValue>;
        private onAddNewProjectClick;
        private onProjectClick;
        private onHistoryClick;
        private loadProjectActual;
        private setOrgActual;
        private setProjectActual;
        private addOnHistory;
        private filterTimeout;
        private _filterProjects;
        private _fireEventProjectSelected;
        private clearState;
        private loadHistory;
        private getOrgsAndProjects;
        private clickShowEye;
        private showString;
        private maskString;
    }
    type IScenaries = 'details' | 'select' | 'add';
    export interface IProjectDetails {
    }
    interface IStateOrg {
        key: string;
        name: string;
        created_at: string;
        description: string;
        projects: any[];
    }
    interface IServiceList {
        history: IHistory[];
        orgs: IStateOrg[];
        projectSelected: number | undefined;
    }
    interface IHistory {
        project: number;
        name: string;
    }
}
declare module "_100554_serviceResults" { }
declare module "_100554_serviceResultsDocs" {
    import { LitElement } from "_100554_litElement";
    export class ServiceResultDocs100554 extends LitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        shortName: string;
        project: number;
        level: number;
        position: 'left' | 'right';
        loading: boolean;
        onlyWithComents: boolean;
        private data;
        connectedCallback(): Promise<void>;
        getJsDoc(): Promise<void>;
        private goToItem;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_serviceSave" {
    import { ServiceBase, IService, IMenu } from "_100554_serviceBase";
    export class ServiceSave extends ServiceBase {
        private myMessage;
        private mainowner;
        private mainrepo;
        private mainbranch;
        private owner;
        private repo;
        private branch;
        private scenery;
        itens: any;
        error: string;
        createRenderRoot(): this;
        constructor();
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        private showInitial;
        onServiceClick(visible: boolean, reinit: boolean): void;
        private setEvents;
        private onMLSEvents;
        private isServiceVisible;
        private verifyExitFileChanged;
        connectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderBlockScenery(): import("_100554_litHtml").TemplateResult<1>;
        renderHeader(): import("_100554_litHtml").TemplateResult<1>;
        renderShowPullrequest(): import("_100554_litHtml").TemplateResult<1>;
        renderNoItens(): import("_100554_litHtml").TemplateResult<1>;
        renderItens(): import("_100554_litHtml").TemplateResult<1>;
        renderProject(project: string, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderLevels(level: string, project: string, indexP: number, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderLevel3(level: string, project: string, indexP: number, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderLevelsDefault(level: string, project: string, indexP: number, index: number): import("_100554_litHtml").TemplateResult<1>;
        renderItem(item: Iitem, indexP: number, indexL: number, index: number): import("_100554_litHtml").TemplateResult<1>;
        private init;
        private initInfoProject;
        private showLoader;
        private showBranche;
        private setInfos;
        private oIcon;
        private configItem;
        private openMeList;
        private clickSetValueAllChilds;
        private setValueAllChilds;
        private clickVerifyStatusFather;
        private verifyStatusFather;
        private updateList;
        private fireOnPullrequest;
        private createFork;
        private forceSaveL5ProjectFile;
        private onSave;
        private veriFyPermission;
        private setLocalHIstoryCurrentInfoDriver;
        private getLocalHIstoryCurrentInfoDriver;
        private getAllFileToSave;
        private onSavenew;
        private afterUpdate;
        private uppVersionAfterSave;
        private deleteFile;
        private fireEvents;
    }
    interface Iitem {
        file: mls.stor.IFileInfo;
        text: string;
        span: string;
        onlyFather: boolean;
        disabled: boolean;
    }
}
declare module "_100554_serviceSelectDsAdd" {
    import { ServiceBase } from "_100554_serviceBase";
    import { CollabLitElement } from "_100554_collabLitElement";
    export const initServiceSelectDsAdd: () => boolean;
    export class ServiceSelectDsAdd100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        state: IState;
        currentScenario: IScenaries;
        mode: IMode;
        inputName: HTMLInputElement | undefined;
        service: ServiceBase | undefined;
        onBtnNext1Click(): void;
        onBtnNext2Click(): void;
        onBtnNext3Click(): void;
        onRadioClick(mode: IMode): void;
        changeScenario(scenario: IScenaries): void;
        validateLettersAndNumbers(str: string): boolean;
        addDs(): Promise<void>;
        getDsAvaliable(): Promise<IDs[]>;
        getProjectsInMemory(): number[];
        fireEvent(index: number): void;
        renderScenario(): import("_100554_litHtml").TemplateResult<1>;
        renderSc1(): import("_100554_litHtml").TemplateResult<1>;
        renderSc2(): import("_100554_litHtml").TemplateResult<1>;
        renderSc3(): import("_100554_litHtml").TemplateResult<1>;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    type IScenaries = 'sc1' | 'sc2' | 'sc3';
    type IMode = 'default' | 'template';
    interface IDs {
        name: string | undefined;
        dsindex: number | undefined;
        project: number | undefined;
        widgetIOName: string | undefined;
    }
    interface IState {
        dsAvaliables: IDs[];
        copyFrom: IDs;
        name: string | undefined;
        project: number | undefined;
    }
}
declare module "_100554_serviceSelectDs" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceSelectDs100554 extends ServiceBase {
        private msg;
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        state: IState;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private _onServiceClick;
        private showHelper;
        private showAdd;
        private setEvents;
        init(): Promise<void>;
        private clearState;
        private setProjectActual;
        private checkIsALocalStorageChanges;
        private initDsSelected;
        private getLastDsSelectedList;
        private getLastDsSelectedByProject;
        setLastDsSelected(dsindex: number, project: number): void;
        private getDs;
        private _fireEventDsSelected;
        openAdd(): void;
        private onItemClick;
        restoreDs(item: any): Promise<void>;
        fireOpenDetails(): void;
        firstUpdated(changedProperties: Map<PropertyKey, unknown>): Promise<void>;
        private restoreFile;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    interface IState {
        history: IHistory;
        ds: IDSInfo[];
        dsSelected: number | undefined;
        actualProject: number | undefined;
    }
    interface IHistory {
        [key: number]: any[];
    }
    interface IDSInfo {
        inLocalStorage: boolean;
        outdated: boolean;
        dsInfo: any;
        files: mls.stor.IFileInfo[];
    }
}
declare module "_100554_serviceUserSettings" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    export class ServiceUserSettings100554 extends ServiceBase {
        private myMessage;
        details: IService;
        onClickLink: (op: string) => boolean;
        menu: IMenu;
        actualLanguage: ILanguage;
        actualTheme: string;
        selectLanguage: HTMLSelectElement | undefined;
        selectTheme: HTMLSelectElement | undefined;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        private getUserSettings;
        private setUserLanguage;
        private getNavigatorLanguage;
        private getUserDefault;
        private handleChangeLanguageClick;
        private handleChangeThemeClick;
        private setUserTheme;
        private getUserTheme;
        private getUserThemeOS;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
    type ILanguage = 'pt-BR' | 'en-US' | 'default';
}
declare module "_100554_serviceWorkspace" {
    import { ServiceBase, IService, IToolbarContent, IMenu } from "_100554_serviceBase";
    import "_100554_pluginGithubL4Project";
    import "_100554_pluginGithubL4Issues";
    import "_100554_pluginConfigLinks";
    export class ServiceWorkspace100554 extends ServiceBase {
        msize: string;
        activeTab: string;
        details: IService;
        onClickLink: (op: string) => boolean;
        onClickIcon: (op: string) => void;
        onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null): void;
        menu: IMenu;
        firstUpdated(): void;
        updated(changedProperties: any): void;
        attributeChangedCallback(name: string, oldVal: string, newVal: string): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): import("_100554_litHtml").TemplateResult<1>;
        createRenderRoot(): this;
        renderLinks(): import("_100554_litHtml").TemplateResult<1>;
        renderTasks(): import("_100554_litHtml").TemplateResult<1>;
        renderBackLog(): import("_100554_litHtml").TemplateResult<1>;
        renderRequirements(): import("_100554_litHtml").TemplateResult<1>;
        renderChat(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_testCharts" {
    import { CollabPageElement } from "_100554_collabPageElement";
    export class TestCharts100554 extends CollabPageElement {
        initPage(): void;
        handleClickbuttonSum(): void;
    }
}
declare module "_100554_testCollabPage" {
    import { CollabPageElement } from "_100554_collabPageElement";
    export class TestCollabPage100554 extends CollabPageElement {
        initPage(): import("_100554_litHtml").TemplateResult<1>;
        handleClickinput2Desktop(): void;
    }
}
declare module "_100554_testCollabPage2" {
    import { CollabPageElement } from "_100554_collabPageElement";
    export class TestCollabPage2100554 extends CollabPageElement {
        initPage(): void;
        handleClickinput2Desktop(): void;
    }
}
declare module "_100554_testPageIcaFull" {
    import { CollabPageElement } from "_100554_collabPageElement";
    export class TestPageICAFull extends CollabPageElement {
        initPage(): void;
        handleClickbtnSomarDesktop(): void;
        handleClickbtnSubtrairDesktop(): void;
    }
}
declare module "_100554_testPageInPage" {
    import { CollabPageElement } from "_100554_collabPageElement";
    export class TestPageICAFull extends CollabPageElement {
        initPage(): void;
        handleClickbtnSomarDesktop(): void;
        handleClickbtnSubtrairDesktop(): void;
    }
}
declare module "_100554_testScenario1" {
    import { IScenaryDetails } from "_100554_collabLitElement";
    export function _100554_testScenario1_getScenaryDetails(): IScenaryDetails;
}
declare module "_100554_testScenario2" {
    import { IScenaryDetails } from "_100554_collabLitElement";
    export function _100554_testScenario2_getScenaryDetails(): IScenaryDetails;
}
declare module "_100554_testePageIca" {
    import { LitElement } from "_100554_litElement";
    export class IcaTestPage100554 extends LitElement {
        static styles: import("_100554_litCssTag").CSSResult;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcAccordionDetails" {
    import { IcaNavigationContentAccordionBase } from "_100554_icaNavigationContentAccordionBase";
    export class WcAccordionDetails100554 extends IcaNavigationContentAccordionBase {
        text: string;
        open: boolean;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcButtonSubmit" {
    import { IcaFormsSubmitSubmitBase } from "_100554_icaFormsSubmitSubmitBase";
    export class WcButtonSubmit extends IcaFormsSubmitSubmitBase {
        name: string | undefined;
        title: string;
        icon: string | undefined;
        text: string | undefined;
        disabled: boolean;
        form: string | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcColumn" {
    import { IcaLayoutFlowColumnBase } from "_100554_icaLayoutFlowColumnBase";
    export class WcColumn extends IcaLayoutFlowColumnBase {
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcDivider" {
    import { IcaLayoutFlowDividerBase } from "_100554_icaLayoutFlowDividerBase";
    export class WcDivider100554 extends IcaLayoutFlowDividerBase {
        text: string | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcEmbedsSocialMedia" {
    import { IcaApresentationEmbedsSocialMediaBase100554 } from "_100554_icaApresentationEmbedsSocialMediaBase";
    export class WcEmbedsSocialMedia100554 extends IcaApresentationEmbedsSocialMediaBase100554 {
        datasource: string | undefined;
        description: string | undefined;
        url: string | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
        generateYouTubeEmbed(url: string): import("_100554_litHtml").TemplateResult<1>;
        generateTwitterEmbed(url: string): import("_100554_litHtml").TemplateResult<1>;
        loadExternalScripts(): void;
    }
}
declare module "_100554_wcImage" {
    import { IcaApresentationImagesImagesBase } from "_100554_icaApresentationImagesImagesBase";
    export class WcImage100554 extends IcaApresentationImagesImagesBase {
        src: string | undefined;
        alt: string | undefined;
        width: string | undefined;
        height: string | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcInputColor" {
    import { LitElement } from "_100554_litElement";
    export class WcInputColor extends LitElement {
        name: string | undefined;
        label: string | undefined;
        widget: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        value: string;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        input: HTMLInputElement | undefined;
        error: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcInputDateRange" {
    import { LitElement } from "_100554_litElement";
    export class WCInputDateRange extends LitElement {
        name: string;
        label: string;
        widget: string;
        pattern: string;
        errormessage: string;
        maxvalue: number | undefined;
        minvalue: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string;
        inputmode: 'none' | 'text' | 'decimal' | 'numeric' | 'tel' | 'search' | 'email' | 'url';
        valueInitial: string;
        valueFinal: string;
        separatorText: string;
        inputInitial: HTMLInputElement | undefined;
        inputFinal: HTMLInputElement | undefined;
        error: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleChange;
    }
}
declare module "_100554_wcInputNumber" {
    import { IcaFormsInputNumberBase } from "_100554_icaFormsInputNumberBase";
    export class WCInputNumber extends IcaFormsInputNumberBase {
        datasource: number | undefined;
        name: string | undefined;
        placeholder: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        maxvalue: number | undefined;
        minvalue: number | undefined;
        step: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string;
        inputmode: 'none' | 'text' | 'decimal' | 'numeric' | 'tel' | 'search' | 'email' | 'url';
        input: HTMLInputElement | undefined;
        error: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleChange;
    }
}
declare module "_100554_wcInputNumberRange" {
    import { IcaFormsInputNumberBase } from "_100554_icaFormsInputNumberBase";
    export class WCInputNumber extends IcaFormsInputNumberBase {
        datasource: number | undefined;
        name: string | undefined;
        placeholder: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        maxvalue: number | undefined;
        minvalue: number | undefined;
        step: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string;
        inputmode: 'none' | 'text' | 'decimal' | 'numeric' | 'tel' | 'search' | 'email' | 'url';
        input: HTMLInputElement | undefined;
        range: HTMLInputElement | undefined;
        error: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleSliderChange;
        private handleChange;
    }
}
declare module "_100554_wcInputNumberWithButtons" {
    import { IcaFormsInputNumberBase } from "_100554_icaFormsInputNumberBase";
    export class WCInputNumber extends IcaFormsInputNumberBase {
        name: string | undefined;
        datasource: number | undefined;
        placeholder: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        maxvalue: number | undefined;
        minvalue: number | undefined;
        step: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string;
        inputmode: 'none' | 'text' | 'decimal' | 'numeric' | 'tel' | 'search' | 'email' | 'url';
        input: HTMLInputElement | undefined;
        error: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleMinusClick;
        private handlePlusClick;
        private handleChange;
        private checkNewVal;
    }
}
declare module "_100554_wcInputText" {
    import { IcaFormsInputStringBase } from "_100554_icaFormsInputStringBase";
    export class WcInputText100554 extends IcaFormsInputStringBase {
        datasource: string | undefined;
        name: string | undefined;
        label: string | undefined;
        pattern: string | undefined;
        errormessage: string | undefined;
        placeholder: string | undefined;
        autocomplete: string | undefined;
        maxlength: number | undefined;
        minlength: number | undefined;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        autofocus: boolean;
        hint: string | undefined;
        autocorrect: 'off' | 'on' | undefined;
        autoCapitalize: 'off' | 'none' | 'on' | 'sentences' | 'words' | 'characters' | undefined;
        input: HTMLInputElement | undefined;
        error: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
        handleChange(event: Event): void;
    }
}
declare module "_100554_wcRow" {
    import { IcaLayoutFlowRowBase } from "_100554_icaLayoutFlowRowBase";
    export class WcRow extends IcaLayoutFlowRowBase {
        hint: string | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcSection" {
    import { IcaLayoutFlowSectionBase } from "_100554_icaLayoutFlowSectionBase";
    export class WcSection100554 extends IcaLayoutFlowSectionBase {
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcSelectOne" {
    import { IcaFormsInputSelectOneBase } from "_100554_icaFormsInputSelectOneBase";
    import { OptionItem } from "_100554_icaLitElement";
    export class WcSelectOne extends IcaFormsInputSelectOneBase {
        hint: string | undefined;
        required: boolean;
        disabled: boolean;
        label: string | undefined;
        options: OptionItem[] | undefined;
        selectedvalue: string | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderOpt(): import("_100554_litHtml").TemplateResult<1>;
        handleChange(event: Event): void;
    }
}
declare module "_100554_wcText" {
    import { IcaApresentationTextTextBase } from "_100554_icaApresentationTextTextBase";
    export class WcInputText100554 extends IcaApresentationTextTextBase {
        datasource: string | undefined;
        text: string | undefined;
        type: string | undefined;
        error: string;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderContent(): any;
    }
}
declare module "_100554_wcVideo" {
    import { IcaApresentationVideoEmbeddedVideoBase } from "_100554_icaApresentationVideoEmbeddedVideoBase";
    export class WcVideo100554 extends IcaApresentationVideoEmbeddedVideoBase {
        src: string;
        autoplay: boolean;
        controls: boolean;
        loop: boolean;
        muted: boolean;
        preload: 'auto' | 'metadata' | 'none';
        video: HTMLVideoElement | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcdToolboxItemBase" {
    import { WCDToolboxMethodos, WCDToolboxItemMethodos } from "_100554_wcdTypes";
    import { IcaLitElementBaseMethods } from "_100554_icaTypes";
    import { CollabLitElement } from "_100554_collabLitElement";
    export abstract class WcdToolboxItemBase extends CollabLitElement implements WCDToolboxItemMethodos {
        myParent: WCDToolboxMethodos | undefined;
        elMain: HTMLElement | undefined;
        elICA: IcaLitElementBaseMethods | undefined;
        abstract args: string | undefined;
        constructor();
        createRenderRoot(): this;
    }
}
declare module "_100554_wcdAddItemImage" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdAddItemImage100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleImageClick;
        private handleKeyDown;
        private showHelper;
    }
}
declare module "_100554_wcdAddItemUnsplash" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdAddItemUnsplash100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleClick;
        private handleKeyDown;
        private showHelper;
    }
}
declare module "_100554_wcdAddItemVideo" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdAddItemVideo100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleClick;
        private handleKeyDown;
        private showHelper;
    }
}
declare module "_100554_wcdCommandBase" {
    export function dispatchEventConciliate(): void;
    export function importFilesIfNeeded(files: string[]): Promise<void>;
}
declare module "_100554_wcdGlobal" {
    /**
     * Finds the closest parent element of a specified element with a specific `tagName`.
     * The function accounts for `shadow roots` and traverses up the DOM tree to find the desired element
     * or until the top of the DOM is reached.
     *
     * @param element - The element from which the search should start. Must be of type `Element`.
     * @param tagName - The tag name that the parent element should have. This should be a string representing the tag name,
     *                   case-insensitive (e.g., 'DIV', 'SPAN').
     * @returns The first parent element that matches the specified `tagName`. If no matching parent element is found
     *          up to the top of the DOM tree, it returns `null`.
     *
     * @example
     * ```typescript
     * const targetElement = document.querySelector('some-element')!;
     * const parentElement = findParentElementWithTagName(targetElement, 'div');
     *
     * if (parentElement) {
     *     console.log('Parent element found:', parentElement);
     * } else {
     *     console.log('No parent element with the specified tag name found.');
     * }
     * ```
     */
    export function findParentElementWithTagName(element: Element, tagName: string): Element | null;
    /**
     * Retrieves all sibling elements that come after a specified element in the DOM.
     *
     * This function collects all siblings of the given element that appear after it in the DOM order.
     * It starts from the immediate next sibling and continues until there are no more siblings.
     *
     * @param element - The HTML element whose siblings after it are to be retrieved. Must be of type `HTMLElement`.
     * @returns An array of `HTMLElement` objects representing the siblings that come after the specified element.
     *
     * @example
     * ```typescript
     * const targetElement = document.querySelector('.target') as HTMLElement;
     * const siblingsAfter = getSiblingsAfter(targetElement);
     *
     * console.log('Siblings after the target element:', siblingsAfter);
     * ```
     */
    export function getSiblingsAfter(element: HTMLElement): HTMLElement[];
    /**
     * Counts the number of elements with a specific tag name starting from a base element,
     * including elements within shadow roots.
     *
     * @param baseElement - The base element from which to start counting. Must be of type `Element`.
     * @param tagName - The tag name of the elements to count. The value should be a string representing the tag name, case-insensitive (e.g., 'DIV', 'SPAN').
     * @returns The number of elements with the specified tag name found starting from the base element.
     */
    export function countElementsWithTagName(baseElement: Element, tagName: string): number;
}
declare module "_100554_wcdCommandAddCodeBlock" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): Promise<void>;
}
declare module "_100554_wcdAddItemCode" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdAddItemCode100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleClick;
        private handleKeyDown;
        private handleCodeClick;
    }
}
declare module "_100554_wcdAddItemEmbed" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdAddItemEmbed100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleClick;
        private handleKeyDown;
        private showHelper;
    }
}
declare module "_100554_wcdCommandAddDivider" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): Promise<void>;
}
declare module "_100554_wcdAddItemPart" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdAddItemPart100554 extends CollabLitElement {
        private msg;
        static styles: import("_100554_litCssTag").CSSResult;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private handleClick;
        private handleNewPartClick;
        private handleKeyDown;
    }
}
declare module "_100554_wcdAdd" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WcdAdd100554 extends WcdToolboxItemBase {
        args: string | undefined;
        buttons: string;
        initialMode: 'close' | 'open';
        containerButtons: HTMLDivElement | undefined;
        containerButtonsContainer: HTMLDivElement | undefined;
        addTooltip: HTMLElement | undefined;
        helperContainer: HTMLElement | undefined;
        createRenderRoot(): this;
        firstUpdated(): Promise<void>;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private loadComponent;
        private tooltipElement;
        private tooltip;
        private destroy;
        private widthMarginOfError;
        private show;
        onButtonClick(e: MouseEvent): void;
        private styles;
    }
}
declare module "_100554_wcdCommandAddEmbedLink" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): Promise<void>;
}
declare module "_100554_wcdCommandAddImage" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): Promise<void>;
}
declare module "_100554_wcdCommandAddVideo" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): Promise<void>;
}
declare module "_100554_wcdCommandChangeSizeImage" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): Promise<void>;
}
declare module "_100554_wcdCommandCopy" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): void;
}
declare module "_100554_wcdCommandDel" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): void;
}
declare module "_100554_wcdCommandEnter" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): void;
}
declare module "_100554_wcdCommandSelectNext" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): Promise<void>;
}
declare module "_100554_wcdCommandUndo" {
    import { IWCDCommand } from "_100554_wcdTypes";
    export function execute(param: IWCDCommand): void;
}
declare module "_100554_wcdDialogEmbedLink" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdDialogEmbedLink100554 extends CollabLitElement {
        private link;
        private msg;
        prompt: HTMLInputElement | undefined;
        private handleKeyDown;
        private handleInput;
        firstUpdated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
}
declare module "_100554_wcdDialogImage" {
    import { LitElement } from "_100554_litElement";
    import { IAssetsInfo } from "_100554_libDesignSystem";
    export class WcdDialogImage100554 extends LitElement {
        private dsInstance;
        images: IImageItem[];
        inputFile: HTMLInputElement | undefined;
        private project;
        private initDsInstance;
        private lastHeight;
        firstUpdated(): Promise<void>;
        private recalculeIcaHeight;
        private getImages;
        private getUrlL3;
        private onUploadClick;
        private onChangeImage;
        private addImage;
        private handleClickGallery;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
    interface IImageItem extends IAssetsInfo {
        src: string;
        srcCache: string;
    }
}
declare module "_100554_wcdDialogImageUnsplash" {
    import { CollabLitElement } from "_100554_collabLitElement";
    export class WcdDialogImageUnsplash100554 extends CollabLitElement {
        private msg;
        prompt: HTMLInputElement | undefined;
        images: IUnsplashImage[];
        totalResults: number;
        private totalPages;
        private actualPage;
        private query;
        private lastQuery;
        private perPage;
        private clientId;
        private lastHeight;
        private getImages;
        private handleKeyDown;
        private handleNext;
        private handleInput;
        private handleGalleryClick;
        private recalculeIcaHeight;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        firstUpdated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
    interface IUnsplashImage {
        alt_description: string;
        alternative_slugs: IUnsplashAlternativeSlugs;
        asset_type: "photo";
        created_at: string;
        description: string;
        height: number;
        width: number;
        id: string;
        liked_by_user: boolean;
        likes: number;
        links: {
            download: string;
            download_location: string;
            html: string;
            self: string;
        };
        promoted_at: string;
        slug: string;
        tags: {};
        updated_at: string;
        urls: {
            full: string;
            raw: string;
            regular: string;
            small: string;
            small_s3: string;
            thumb: string;
        };
        user: IUnsplashUser;
    }
    interface IUnsplashAlternativeSlugs {
        [key: string]: string;
    }
    interface IUnsplashUser {
        bio: string;
        first_name: string;
        id: string;
        last_name: string;
        links: {
            followers: string;
            following: string;
            html: string;
            likes: string;
            photos: string;
            portfolio: string;
            self: string;
        };
        location: string;
        name: string;
        portfolio_url: string;
        profile_image: {
            large: string;
            medium: string;
            small: string;
        };
        total_collections: number;
        total_illustrations: number;
        total_likes: number;
        total_photos: number;
        total_promoted_illustrations: number;
        total_promoted_photos: number;
        twitter_username: string;
        updated_at: string;
        username: string;
    }
}
declare module "_100554_wcdDialogVideo" {
    import { LitElement } from "_100554_litElement";
    import { IAssetsInfo } from "_100554_libDesignSystem";
    export class WcdDialogVideo100554 extends LitElement {
        private dsInstance;
        videos: IVideoItem[];
        inputFile: HTMLInputElement | undefined;
        private project;
        private initDsInstance;
        private lastHeight;
        firstUpdated(): Promise<void>;
        private recalculeIcaHeight;
        private getVideos;
        private getUrlL3;
        private onUploadClick;
        private onChangeImage;
        private addVideo;
        private handleClickGallery;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        disconnectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        static styles: import("_100554_litCssTag").CSSResult;
    }
    interface IVideoItem extends IAssetsInfo {
        src: string;
        srcCache: string;
    }
}
declare module "_100554_wcdMenuItemImage" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WcdAdd100554 extends WcdToolboxItemBase {
        args: string | undefined;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderNormal(): import("_100554_litHtml").TemplateResult<1>;
        renderCenter(): import("_100554_litHtml").TemplateResult<1>;
        renderBig(): import("_100554_litHtml").TemplateResult<1>;
        clickBig(): Promise<void>;
        clickCenter(): Promise<void>;
        clickNormal(): Promise<void>;
    }
}
declare module "_100554_wcdOverlayLitBase" {
    import { CollabLitElement } from "_100554_collabLitElement";
    import { ActionTag, IICADepths, IcaLitElementBaseMethods } from "_100554_icaTypes";
    import { WCDOverlayMethods } from "_100554_wcdTypes";
    export abstract class WcdOverlayLitBase extends CollabLitElement implements WCDOverlayMethods {
        level: string;
        myItens: IICADepths[];
        constructor();
        refreshOverlay(): void;
        createRenderRoot(): this;
        abstract myKeyEvents: {
            [key: string]: Function;
        };
        abstract changeOverlayItemsLevel(): void;
        abstract createOverlayItems(): void;
        abstract selectItem(ica: IcaLitElementBaseMethods): void;
        abstract getActionsTagsDefault(): {
            [key: string]: ActionTag;
        };
        private onkeyDown;
    }
}
declare module "_100554_wcdToolbox" {
    import { CollabLitElement } from "_100554_collabLitElement";
    import { WCDToolboxMethodos } from "_100554_wcdTypes";
    import * as tps from "_100554_icaTypes";
    export function initWCDToolbox(): boolean;
    export class WCDToolbox extends CollabLitElement implements WCDToolboxMethodos {
        level: string;
        widget: string | undefined;
        elMain: HTMLElement | undefined;
        elICA: tps.IcaLitElementBaseMethods | undefined;
        private wcServiceICA;
        fcBeforeBackButton: Function | undefined;
        get lastHelper(): string;
        set lastHelper(helper: string);
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        beforeDelete(): Promise<void>;
        updateSize(elBase: HTMLElement, elChange: HTMLElement, changePosition: boolean): void;
        getAndSetScenaryOutDoor(op: string): Promise<HTMLElement | undefined>;
        backNavigationScenaryOutdoor(): void;
        setIconsWcdToolbox(act: tps.ActionTag[], useSelf?: boolean, updataSize?: 'false' | 'size' | 'padding'): void;
        updateBaseNoPadding(elBase: HTMLElement, elChange: HTMLElement): void;
        updateBackgroundAuxSize(tp?: 'show' | 'hide'): void;
        private _renderAction;
        private setDefaultToolBoxOptions;
        private setToolBoxOptions;
        private hasImport;
        private importWCDActions;
        private _setIconsWcdToolbox;
        private addBackButton;
        private getNav3;
        private isElementVisible;
        private ensureVisibility;
        private _getAndSetScenaryOutDoor;
        private _backNavigationScenaryOutdoor;
        private resizeObserver;
        private timeResize;
        private initObserverResize;
        private adjustPositionIfNecessary;
        private calculateHorizontalOffset;
        private organizeArray;
        private rectsOverlap;
        private _updateSize;
        private _updateBackgroundAuxSize;
        private _updateBaseNoPadding;
        private css;
    }
}
declare module "_100554_wcdOverlayModeStoryItem" {
    import { LitElement, PropertyValueMap } from "_100554_litElement";
    import { WCDOverlayItensMethods, WCDOverlayMethods } from "_100554_wcdTypes";
    import { IICADepths } from "_100554_icaTypes";
    export function initWcdOverlayModeStoryItem(): boolean;
    export class WcdOverlayModeStoryItem extends LitElement implements WCDOverlayItensMethods {
        info: IICADepths | undefined;
        widget: string | undefined;
        level: string | undefined;
        boundingPage: DOMRect | undefined;
        overlay: WCDOverlayMethods | undefined;
        constructor();
        createRenderRoot(): this;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private setEvents;
        private onIcaOverlayItemLeave;
        private onIcaOverlayItemOver;
        private isOverlapping;
        private onIcaOverlayItemClick;
        private findAncestorWithIsicaGroup;
        private addWCDToolbox;
        private selectOnHTML;
        private checkToChangeWCD;
    }
}
declare module "_100554_wcdOverlayModeStory" {
    import { WcdOverlayLitBase } from "_100554_wcdOverlayLitBase";
    import { ActionTag, IcaLitElementBaseMethods } from "_100554_icaTypes";
    import { IWCDCommand } from "_100554_wcdTypes";
    import { execute as excCommandEnter } from "_100554_wcdCommandEnter";
    import { execute as excCommandDel } from "_100554_wcdCommandDel";
    import { execute as excCommandCopy } from "_100554_wcdCommandCopy";
    import { execute as excCommandUndo } from "_100554_wcdCommandUndo";
    export class WcdOverlayModeStory extends WcdOverlayLitBase {
        constructor();
        private resizeObserver;
        private keys;
        myKeyEvents: {
            Enter: typeof excCommandEnter;
            Backspace: typeof excCommandDel;
            Delete: typeof excCommandDel;
            c: typeof excCommandCopy;
            v: typeof excCommandCopy;
            z: typeof excCommandUndo;
            ArrowDown: (e: IWCDCommand) => void;
            ArrowLeft: (e: IWCDCommand) => void;
            ArrowUp: (e: IWCDCommand) => void;
            ArrowRight: (e: IWCDCommand) => void;
        };
        private onkeydownArrow;
        refreshOverlay(): void;
        selectItem(ica: IcaLitElementBaseMethods): void;
        getActionsTagsDefault(): {
            [key: string]: ActionTag;
        };
        firstUpdated(): void;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        changeOverlayItemsLevel(): void;
        createOverlayItems(): void;
        private createOverlayItem;
        private updateSizeOverlayItems;
    }
}
declare module "_100554_wcdOverlayModeStoryHelp" {
    import { CollabPageElement } from "_100554_collabPageElement";
    export class WcdOverlayModeStoryHelp100554 extends CollabPageElement {
        initPage(): void;
    }
}
declare module "_100554_wcdPopupItem" {
    import { LitElement } from "_100554_litElement";
    export class WCDPopupItem extends LitElement {
        constructor();
        static styles: import("_100554_litCssTag").CSSResult;
        handleClick(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcdPopupItemBold" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItem } from "_100554_wcdPopupItem";
    export class WCDPopupItemBold extends WCDPopupItem {
        getSvg(): TemplateResult;
        render(): TemplateResult<1>;
        handleClick(): void;
    }
}
declare module "_100554_wcdPopupItemItalic" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItem } from "_100554_wcdPopupItem";
    export class WCDPopupItemItalic extends WCDPopupItem {
        getSvg(): TemplateResult;
        render(): TemplateResult<1>;
        handleClick(): void;
    }
}
declare module "_100554_wcdPopupItemLink" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItem } from "_100554_wcdPopupItem";
    export class WCDPopupItemLink extends WCDPopupItem {
        getSvg(): TemplateResult;
        render(): TemplateResult<1>;
        handleClick(): void;
    }
}
declare module "_100554_wcdPopupItemSeparator" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItem } from "_100554_wcdPopupItem";
    export class WCDPopupItemSeparator extends WCDPopupItem {
        static styles: import("_100554_litCssTag").CSSResult;
        render(): TemplateResult<1>;
    }
}
declare module "_100554_wcdPopupItemH1" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItem } from "_100554_wcdPopupItem";
    import { WCDPopupMethodos } from "_100554_wcdTypes";
    export class WCDPopupItemH1 extends WCDPopupItem {
        getSvg(): TemplateResult;
        render(): TemplateResult<1>;
        normalText: string;
        headerText: string;
        handleClick(): void;
        getMyParent(): WCDPopupMethodos | undefined;
    }
}
declare module "_100554_wcdPopupItemH2" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItemH1 } from "_100554_wcdPopupItemH1";
    export class WCDPopupItemH2 extends WCDPopupItemH1 {
        constructor();
        getSvg(): TemplateResult;
    }
}
declare module "_100554_wcdPopupItemH3" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItemH1 } from "_100554_wcdPopupItemH1";
    export class WCDPopupItemH3 extends WCDPopupItemH1 {
        constructor();
        getSvg(): TemplateResult;
    }
}
declare module "_100554_wcdPopupItemH4" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItemH1 } from "_100554_wcdPopupItemH1";
    export class WCDPopupItemH2 extends WCDPopupItemH1 {
        constructor();
        getSvg(): TemplateResult;
    }
}
declare module "_100554_wcdPopupItemBlockQuote" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItemH1 } from "_100554_wcdPopupItemH1";
    export class WCDPopupItemBlockQuote extends WCDPopupItemH1 {
        constructor();
        getSvg(): TemplateResult;
    }
}
declare module "_100554_wcdPopupItemDropCap" {
    import { TemplateResult } from "_100554_litElement";
    import { WCDPopupItem } from "_100554_wcdPopupItem";
    export class WCDPopupItemDropCap extends WCDPopupItem {
        getSvg(): TemplateResult;
        render(): TemplateResult<1>;
        handleClick(): void;
    }
}
declare module "_100554_wcdPopup" {
    import { LitElement } from "_100554_litElement";
    import { WCDToolboxItemEditTextMethodos, WCDPopupMethodos } from "_100554_wcdTypes";
    export function initWcdPopup(): boolean;
    export class WCDPopup extends LitElement implements WCDPopupMethodos {
        myParent: WCDToolboxItemEditTextMethodos | undefined;
        x: number;
        y: number;
        buttons: string;
        static styles: import("_100554_litCssTag").CSSResult;
        changeType(tp: string): void;
        private loadComponent;
        firstUpdated(): Promise<void>;
        render(): import("_100554_litHtml").TemplateResult<1>;
        updated(changedProperties: Map<string | number | symbol, unknown>): void;
        isValid(name: string | null): boolean;
        checkIsValidDropCap(): boolean;
        isFirstWordSelected(contentEditableElement: HTMLElement): boolean;
    }
}
declare module "_100554_wcdState" {
    import { WCDToolboxMethodos } from "_100554_wcdTypes";
    import { IcaLitElementBaseMethods } from "_100554_icaTypes";
    global {
        interface Window {
            wcdState: {
                myParent: WCDToolboxMethodos | undefined;
                elMain: HTMLElement | undefined;
                elICA: IcaLitElementBaseMethods | undefined;
            };
        }
    }
}
declare module "_100554_wcdToolboxItemActionCodeLanguage" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    import { IcaLitElementBaseMethods } from "_100554_icaTypes";
    import { WCDToolboxMethodos } from "_100554_wcdTypes";
    export class WcdToolboxItemActionCodeLanguage extends WcdToolboxItemBase {
        myParent: WCDToolboxMethodos | undefined;
        elMain: HTMLElement | undefined;
        elICA: IcaLitElementBaseMethods | undefined;
        args: string | undefined;
        languages: string[];
        actualLanguage: string;
        private getLanguagesAvaliables;
        private handleChange;
        private handleClick;
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
    }
}
declare module "_100554_wcdToolboxItemActionEditCode" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WCDToolboxItemActionEditCode extends WcdToolboxItemBase {
        args: string | undefined;
        private myInfos;
        contentEditables: HTMLElement | undefined;
        createRenderRoot(): this;
        disconnectedCallback(): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderButton(): import("_100554_litHtml").TemplateResult<1>;
        renderClick(): import("_100554_litHtml").TemplateResult<1>;
        renderEdit(): import("_100554_litHtml").TemplateResult<1>;
        private text;
        private onKeyDown;
        private fireChange;
        private clickButton;
        private backButton;
    }
}
declare module "_100554_wcdToolboxItemActionEditText" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WCDToolboxItemActionEditText extends WcdToolboxItemBase {
        args: string | undefined;
        private myInfos;
        constructor();
        createRenderRoot(): this;
        disconnectedCallback(): void;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderButton(): import("_100554_litHtml").TemplateResult<1>;
        renderClick(): import("_100554_litHtml").TemplateResult<1>;
        renderEdit(): import("_100554_litHtml").TemplateResult<1>;
        private firstText;
        private firstTag;
        private myTag;
        private myText;
        private hasDropCap;
        private setCaret;
        private fireChange;
        changeType(tp: string): void;
        private changeInEditor;
        private moveSelectionToElement;
        private onInput;
        private onkeyDown;
        private isCaretInFirstLine;
        private isCaretInLastLine;
        private clickButton;
        private removePopUpIfNeeded;
        private mouseUP;
        private isElementVisible;
        private backButton;
    }
}
declare module "_100554_wcdToolboxItemActionEvents" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    import { CollabSelectOneWithDescription100554 } from "_100554_collabSelectOneWithDescription";
    export class WcdToolboxItemActionEvents extends WcdToolboxItemBase {
        args: string | undefined;
        elEvents: CollabSelectOneWithDescription100554 | undefined;
        private options;
        constructor();
        createRenderRoot(): this;
        firstUpdated(): void;
        render(): any;
        private getEvents;
        private selectItem;
    }
}
declare module "_100554_wcdToolboxItemActionGroup" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WCDToolboxItemActionGroup extends WcdToolboxItemBase {
        args: string | undefined;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        firstUpdated(): void;
        updated(changedProperties: any): void;
        private initClick;
    }
}
declare module "_100554_wcdToolboxItemActionMargin" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WCDToolboxItemActionMargin extends WcdToolboxItemBase {
        private myMsg;
        args: string | undefined;
        private elExternal;
        private startX;
        private startY;
        private startTop;
        private startBottom;
        private startLeft;
        private startRight;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderButton(): import("_100554_litHtml").TemplateResult<1>;
        renderOne(pos: string): import("_100554_litHtml").TemplateResult<1>;
        renderAll(): import("_100554_litHtml").TemplateResult<1>;
        private clickButton;
        private renderOutdoorScenary;
        private renderMargin;
        private timeonChangeProp;
        private onChangeProp;
        private changeEl;
        private initDragging;
        private fireEvent;
    }
}
declare module "_100554_wcdToolboxItemActionMenu" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WcdToolboxItemActionMenu extends WcdToolboxItemBase {
        args: string | undefined;
        myInfos: IWCDMenu100554 | undefined;
        elItens: HTMLElement | undefined;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private setMyArgs;
        private loadItens;
        private isLoad;
        private loadItem;
        private css;
    }
    interface IWCDMenu100554 {
        itens: IWCDMenuItem100554[];
        subItens: IWCDMenuItem100554[];
    }
    interface IWCDMenuItem100554 {
        item: string;
        args: string;
    }
}
declare module "_100554_wcdToolboxItemActionMove" {
    import { LitElement } from "_100554_litElement";
    import { WCDToolboxMethodos } from "_100554_wcdTypes";
    import { IcaLitElementBaseMethods, IActionsToolbox } from "_100554_icaTypes";
    export class WCDToolboxItemActionMove extends LitElement {
        myParent: WCDToolboxMethodos | undefined;
        elMain: HTMLElement | undefined;
        elFCA: IcaLitElementBaseMethods | undefined;
        private myElements;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        updated(changedProperties: any): void;
        beforeRemove(): void;
        private clearDrag;
        private stopDragging;
        private getAux;
        private initClick;
        private onlyNeedAddTag;
        private changeStateDrag;
        private changeStateDrop;
    }
    export const getTemplate: (mode?: string, position?: string) => IActionsToolbox;
}
declare module "_100554_wcdToolboxItemActionPadding" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WCDToolboxItemActionPadding extends WcdToolboxItemBase {
        private myMsg;
        args: string | undefined;
        private elExternal;
        private startX;
        private startY;
        private startTop;
        private startBottom;
        private startLeft;
        private startRight;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderButton(): import("_100554_litHtml").TemplateResult<1>;
        renderOne(pos: string): import("_100554_litHtml").TemplateResult<1>;
        renderAll(): import("_100554_litHtml").TemplateResult<1>;
        private clickButton;
        private renderOutdoorScenary;
        private renderPadding;
        private timeonChangeProp;
        private onChangeProp;
        private changeEl;
        private timeRemoveResize;
        private initDragging;
        private fireEvent;
    }
}
declare module "_100554_wcdToolboxItemActionSize" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WCDToolboxItemActionSize extends WcdToolboxItemBase {
        private myMsg;
        args: string | undefined;
        private elExternal;
        private startX;
        private startY;
        private startWidth;
        private startHeight;
        createRenderRoot(): this;
        updated(changedProperties: any): void;
        render(): import("_100554_litHtml").TemplateResult<1>;
        renderButton(): import("_100554_litHtml").TemplateResult<1>;
        renderOne(pos: string): import("_100554_litHtml").TemplateResult<1>;
        renderAll(): import("_100554_litHtml").TemplateResult<1>;
        private clickButton;
        private renderOutdoorScenary;
        private renderSize;
        private timeonChangeProp;
        private onChangeProp;
        private changeEl;
        private tpMeasures;
        private initDragging;
        private fireEvent;
    }
}
declare module "_100554_wcdToolboxItemActionTitle" {
    import { WcdToolboxItemBase } from "_100554_wcdToolboxItemBase";
    export class WcdToolboxItemActionTitle extends WcdToolboxItemBase {
        args: string | undefined;
        createRenderRoot(): this;
        render(): import("_100554_litHtml").TemplateResult<1>;
        private styles;
    }
}
