/// <mls fileReference="_100554_/l2/collabL3PreviewText.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { propertyDataSource } from '/_100554_/l2/collabDecorators.js';
let CollabL3PreviewText = class CollabL3PreviewText extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-l3-preview-text-100554{outline:none}`);
        this.findby = '';
        this.timeFireEvent = 0;
    }
    render() {
        this.onclick = this.handleClick.bind(this);
        this.onblur = this.handleChange.bind(this);
        this.setAttribute('contenteditable', 'true');
        return html `${this.value}`;
    }
    handleChange(event) {
        this.value = this.innerText;
    }
    handleClick(event) {
        event.stopPropagation();
        event.preventDefault();
        this.onSelect();
        this.fireEvent();
    }
    fireEvent() {
        clearTimeout(this.timeFireEvent);
        this.timeFireEvent = setTimeout(() => {
            const el = this.closest('[id]');
            if (!el)
                return;
            const param = {
                'position': 'right',
                'action': 'select',
                'id': el.id
            };
            mls.events.fire(3, 'L3EditEvents', JSON.stringify(param));
        }, 500);
    }
    onSelect() {
        const elActive = document.querySelector('*[clb_mode]');
        if (elActive && elActive.id === this.findby)
            return;
        const el = document.querySelector('#' + this.findby);
        if (el)
            el.setAttribute('clb_mode', 'edit');
        if (elActive)
            elActive.removeAttribute('clb_mode');
    }
};
__decorate([
    property()
], CollabL3PreviewText.prototype, "findby", void 0);
__decorate([
    propertyDataSource({ type: String })
], CollabL3PreviewText.prototype, "value", void 0);
CollabL3PreviewText = __decorate([
    customElement('collab-l3-preview-text-100554')
], CollabL3PreviewText);
export { CollabL3PreviewText };
