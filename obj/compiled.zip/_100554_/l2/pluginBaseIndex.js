class PluginBaseIndex {
}
var pluginBaseIndex_default = "disabled";
export {
  PluginBaseIndex,
  pluginBaseIndex_default as default
};
