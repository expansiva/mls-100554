/// <mls shortName="pluginBaseIndex" project="100554" enhancement="_blank" />
export class PluginBaseIndex {
}
// this class is a abstract class, so use "disabled"
export default "disabled"; // or: export default new Pluginxxx()
