/// <mls fileReference="_100554_/l2/collabPanelItem.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property } from 'lit/decorators.js';
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let CollabPanelItem = class CollabPanelItem extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.widget = '';
        this.badge = '';
        this.loading = 'loading';
        this.mode = 'html';
    }
    //---------COMPONENT-------------
    firstUpdated() {
        this.setMyInfo();
    }
    render() {
        this.onclick = () => this.clickItem();
        let aux;
        if (this.badge)
            aux = unsafeHTML(`
            <collab-panel-item-badge>
                ${this.badge}
            </collab-panel-item-badge>
        `);
        this.setAttribute('filter', this.myInfo?.title + '');
        return html `
            <collab-panel-item class="${this.loading}">
                ${aux}
                <collab-panel-item-svg>
                    ${this.myInfo?.getSvg()}
                </collab-panel-item-svg>
                <collab-panel-item-info>
                    ${this.myInfo?.title}
                </collab-panel-item-info>
            </collab-panel-item>
        `;
    }
    //---------IMPLEMENT-------------
    clickItem() {
        if (!this.classList.contains('active')) {
            let parent = this.closest('collab-panel-100554');
            if (!parent)
                return;
            parent = parent.parentElement;
            if (!parent)
                return;
            const elActive = parent.querySelector('.active');
            if (elActive)
                elActive.classList.remove('active');
            this.classList.add('active');
        }
        mls.actual[0].setFullName(this.widget);
        const options = {
            shortName: mls.actual[0].path,
            project: mls.actual[0].project,
            htmlText: ''
        };
        if (this.mode === 'tag') {
            const infoPathWidget = mls.actual[0].setFullName(this.widget).getStorFileBase();
            const tag = convertFileNameToTag(infoPathWidget);
            options.htmlText = `<${tag}></${tag}>`;
        }
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
    async setMyInfo() {
        if (!this.widget)
            return;
        const file = mls.actual[0].setFullName(this.widget).getStorFileBase();
        const modulePlugin = await import('/' + `_${file.project}_/l2/${file.folder ? file.folder + '/' : ''}${file.shortName}`);
        this.myInfo = modulePlugin.pluginData;
        this.setAttribute('loading', '');
    }
};
__decorate([
    property({ type: String, reflect: true })
], CollabPanelItem.prototype, "widget", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabPanelItem.prototype, "badge", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabPanelItem.prototype, "loading", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabPanelItem.prototype, "mode", void 0);
CollabPanelItem = __decorate([
    customElement('collab-panel-item-100554')
], CollabPanelItem);
export { CollabPanelItem };
