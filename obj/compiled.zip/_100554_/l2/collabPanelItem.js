/// <mls fileReference="_100554_/l2/collabPanelItem.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html, unsafeHTML } from "lit";
import { customElement, property } from "lit/decorators.js";
import { convertFileNameToTag } from "/_102027_/l2/utils";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
let CollabPanelItem = class extends CollabLitElement {
  constructor() {
    super(...arguments);
    this.widget = "";
    this.badge = "";
    this.loading = "loading";
    this.mode = "html";
  }
  //---------COMPONENT-------------
  createRenderRoot() {
    return this;
  }
  firstUpdated() {
    this.setMyInfo();
  }
  render() {
    this.onclick = () => this.clickItem();
    let aux;
    if (this.badge) aux = unsafeHTML(`
            <collab-panel-item-badge>
                ${this.badge}
            </collab-panel-item-badge>
        `);
    this.setAttribute("filter", this.myInfo?.title + "");
    return html`
            <collab-panel-item class="${this.loading}">
                ${aux}
                <collab-panel-item-svg>
                    ${this.myInfo?.getSvg()}
                </collab-panel-item-svg>
                <collab-panel-item-info>
                    ${this.myInfo?.title}
                </collab-panel-item-info>
            </collab-panel-item>
        `;
  }
  //---------IMPLEMENT-------------
  clickItem() {
    if (!this.classList.contains("active")) {
      let parent = this.closest("collab-panel-100554");
      if (!parent) return;
      parent = parent.parentElement;
      if (!parent) return;
      const elActive = parent.querySelector(".active");
      if (elActive) elActive.classList.remove("active");
      this.classList.add("active");
    }
    mls.actual[0].setFullName(this.widget);
    const options = {
      shortName: mls.actual[0].path,
      project: mls.actual[0].project,
      htmlText: ""
    };
    if (this.mode === "tag") {
      const infoPathWidget = mls.l2.getPath(this.widget);
      const tag = convertFileNameToTag(infoPathWidget);
      options.htmlText = `<${tag}></${tag}>`;
    }
    mls.events.fire(
      mls.actualLevel,
      "PluginDetails",
      JSON.stringify(options),
      0
    );
  }
  async setMyInfo() {
    if (!this.widget) return;
    const file = mls.l2.getPath(this.widget);
    const modulePlugin = await import(`/_${file.project}_/l2/${file.shortName}`);
    this.myInfo = modulePlugin.pluginData;
    this.setAttribute("loading", "");
  }
};
__decorateClass([
  property({ type: String, reflect: true })
], CollabPanelItem.prototype, "widget", 2);
__decorateClass([
  property({ type: String, reflect: true })
], CollabPanelItem.prototype, "badge", 2);
__decorateClass([
  property({ type: String, reflect: true })
], CollabPanelItem.prototype, "loading", 2);
__decorateClass([
  property({ type: String, reflect: true })
], CollabPanelItem.prototype, "mode", 2);
CollabPanelItem = __decorateClass([
  customElement("collab-panel-item-100554")
], CollabPanelItem);
export {
  CollabPanelItem
};
