/// <mls fileReference="_100554_/l2/collabOrgSettings.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    pageTitle: 'Configurações da Organização',
    fieldUrl: 'URL',
    fieldCompany: 'Empresa',
    fieldLocation: 'Localização',
    fieldEmail: 'E-mail',
    fieldLogo: 'URL do Logo',
    fieldDescription: 'Descrição',
    fieldDescriptionHint: '(markdown)',
    btnSave: 'Salvar',
    btnSaving: 'Salvando…',
    feedbackSuccess: 'Configurações salvas com sucesso.',
    loadingSettings: 'Carregando configurações…',
    dangerTitle: 'Zona de Perigo',
    archiveTitle: 'Arquivar esta organização',
    archiveDesc: 'Marcar a organização como arquivada e somente leitura.',
    btnArchive: 'Arquivar',
    deleteTitle: 'Excluir esta organização',
    deleteDesc: 'Remove permanentemente a organização e todos os seus dados. Esta ação não pode ser desfeita.',
    btnDelete: 'Excluir',
};
const message_en = {
    pageTitle: 'Organization Settings',
    fieldUrl: 'URL',
    fieldCompany: 'Company',
    fieldLocation: 'Location',
    fieldEmail: 'Email',
    fieldLogo: 'Logo URL',
    fieldDescription: 'Description',
    fieldDescriptionHint: '(markdown)',
    btnSave: 'Save',
    btnSaving: 'Saving…',
    feedbackSuccess: 'Settings saved successfully.',
    loadingSettings: 'Loading settings…',
    dangerTitle: 'Delete Organization',
    archiveTitle: 'Archive this organization',
    archiveDesc: 'Mark the organization as archived and read-only.',
    btnArchive: 'Archive',
    deleteTitle: 'Delete this organization',
    deleteDesc: 'Permanently remove the organization and all its data. This action cannot be undone.',
    btnDelete: 'Delete',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
const MOCK_SETTINGS = {
    url: 'https://collabcodes.dev',
    company: 'Collab Codes',
    location: 'São Paulo, BR',
    email: 'contact@collabcodes.dev',
    logo: '',
    description: '## About\nPlataforma colaborativa de desenvolvimento low-code.',
};
let CollabOrgSettings = class CollabOrgSettings extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-org-settings-100554 {
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
}
collab-org-settings-100554 .state-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 48px 24px;
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-16);
}
collab-org-settings-100554 .spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid var(--grey-color);
  border-top-color: var(--active-color);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-org-settings-100554 .settings-root {
  display: flex;
  flex-direction: column;
  gap: 40px;
  max-width: 640px;
  margin: 0 auto;
  padding: 40px 24px;
}
collab-org-settings-100554 .page-title {
  margin: 0;
  font-size: var(--font-size-24);
  font-weight: 700;
  color: var(--text-primary-color-darker);
}
collab-org-settings-100554 .settings-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}
collab-org-settings-100554 .form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
collab-org-settings-100554 .form-group label {
  font-size: var(--font-size-16);
  font-weight: 600;
  color: var(--text-primary-color);
}
collab-org-settings-100554 .form-group label .hint {
  font-weight: 400;
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
  margin-left: 4px;
}
collab-org-settings-100554 .form-group input,
collab-org-settings-100554 .form-group textarea {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
  border: 1px solid var(--grey-color-dark);
  border-radius: 4px;
  padding: 8px 12px;
  outline: none;
  transition: border-color 0.15s ease;
  resize: vertical;
}
collab-org-settings-100554 .form-group input:hover,
collab-org-settings-100554 .form-group textarea:hover {
  border-color: var(--grey-color-darker);
}
collab-org-settings-100554 .form-group input:focus,
collab-org-settings-100554 .form-group textarea:focus {
  border-color: var(--active-color);
}
collab-org-settings-100554 .feedback {
  padding: 10px 14px;
  border-radius: 4px;
  font-size: var(--font-size-16);
}
collab-org-settings-100554 .feedback.success {
  background-color: var(--bg-secondary-color-lighter);
  color: var(--success-color);
  border: 1px solid var(--success-color);
}
collab-org-settings-100554 .feedback.error {
  background-color: var(--bg-secondary-color-lighter);
  color: var(--error-color);
  border: 1px solid var(--error-color);
}
collab-org-settings-100554 .form-actions {
  display: flex;
  justify-content: flex-end;
}
collab-org-settings-100554 .btn-primary {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: #ffffff;
  background-color: var(--active-color);
  border: none;
  border-radius: 4px;
  padding: 8px 24px;
  cursor: pointer;
  transition: background-color 0.15s ease;
}
collab-org-settings-100554 .btn-primary:hover:not(:disabled) {
  background-color: var(--active-color-hover);
}
collab-org-settings-100554 .btn-primary:focus:not(:disabled) {
  background-color: var(--active-color-focus);
  outline: none;
}
collab-org-settings-100554 .btn-primary:disabled {
  background-color: var(--active-color-disabled);
  cursor: not-allowed;
}
collab-org-settings-100554 .danger-zone {
  display: flex;
  flex-direction: column;
  gap: 0;
  border: 1px solid var(--error-color);
  border-radius: 6px;
  overflow: hidden;
}
collab-org-settings-100554 .danger-title {
  margin: 0;
  padding: 12px 16px;
  font-size: var(--font-size-16);
  font-weight: 700;
  color: var(--error-color);
  background-color: var(--bg-secondary-color-lighter);
  border-bottom: 1px solid var(--error-color);
}
collab-org-settings-100554 .danger-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 16px;
  border-bottom: 1px solid var(--grey-color);
}
collab-org-settings-100554 .danger-item:last-child {
  border-bottom: none;
}
collab-org-settings-100554 .danger-item-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
collab-org-settings-100554 .danger-item-info strong {
  font-size: var(--font-size-16);
  color: var(--text-primary-color-darker);
}
collab-org-settings-100554 .danger-item-info p {
  margin: 0;
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
}
collab-org-settings-100554 .btn-warning {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: #ffffff;
  background-color: var(--warning-color);
  border: none;
  border-radius: 4px;
  padding: 6px 16px;
  cursor: pointer;
  white-space: nowrap;
  transition: background-color 0.15s ease;
}
collab-org-settings-100554 .btn-warning:hover {
  background-color: var(--warning-color-hover);
}
collab-org-settings-100554 .btn-warning:focus {
  background-color: var(--warning-color-focus);
  outline: none;
}
collab-org-settings-100554 .btn-danger {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: #ffffff;
  background-color: var(--error-color);
  border: none;
  border-radius: 4px;
  padding: 6px 16px;
  cursor: pointer;
  white-space: nowrap;
  transition: background-color 0.15s ease;
}
collab-org-settings-100554 .btn-danger:hover {
  background-color: var(--error-color-hover);
}
collab-org-settings-100554 .btn-danger:focus {
  background-color: var(--error-color-focus);
  outline: none;
}
`);
        this.project = 0;
        this.msg = messages['en'];
        this._loading = false;
        this._saving = false;
        this._error = '';
        this._successMessage = '';
        this._form = { url: '', company: '', location: '', email: '', logo: '', description: '' };
    }
    connectedCallback() {
        super.connectedCallback();
        this._fetchSettings();
    }
    async _fetchSettings() {
        this._loading = true;
        this._error = '';
        this.requestUpdate();
        try {
            const idxOrg = mls.l5.getProjectOrgIndex(this.project) || -1;
            const orgName = mls.l5.getOrgsName()[idxOrg];
            const lastOrg = mls.stor.orgs[orgName];
            if (!lastOrg) {
                this._error = 'Not found organization';
                return;
            }
            const info = JSON.parse(lastOrg.value || '{}');
            const objParse = info.l5_actionOrgSettings ? info.l5_actionOrgSettings : {};
            this._form = {
                url: objParse.html_url ? objParse.html_url : '',
                company: objParse.company ? objParse.company : '',
                location: objParse.location ? objParse.location : '',
                email: objParse.email ? objParse.email : '',
                logo: objParse.logo ? objParse.logo : '',
                description: objParse.description ? objParse.l5_actionOrgSettings.description : '',
            };
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : 'Unknown error';
        }
        finally {
            this._loading = false;
            this.requestUpdate();
        }
    }
    async _handleSave(e) {
        e.preventDefault();
        this._saving = true;
        this._error = '';
        this._successMessage = '';
        this.requestUpdate();
        try {
            // const res = await fetch(`${this.baseUrl}/organizations/${this.orgSlug}/settings`, {
            //     method: 'PATCH',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify(this._form),
            // });
            // if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const orgPreferences = {
                l5_actionOrgSettings: { ...this._form }
            };
            //mls.l5.setProjectSettings()
            await new Promise((resolve) => setTimeout(resolve, 600));
            this._successMessage = this.msg.feedbackSuccess;
            this.dispatchEvent(new CustomEvent('org-updated', { bubbles: true, composed: true }));
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : 'Unknown error';
        }
        finally {
            this._saving = false;
            this.requestUpdate();
        }
    }
    _handleInput(field, e) {
        const target = e.target;
        this._form = { ...this._form, [field]: target.value };
        this._successMessage = '';
    }
    _handleArchive() {
        // Implementação futura
    }
    _handleDelete() {
        this.dispatchEvent(new CustomEvent('org-deleted', { bubbles: true, composed: true }));
    }
    _renderLoading() {
        return html `
            <div class="state-loading">
                <span class="spinner"></span>
                <span>${this.msg.loadingSettings}</span>
            </div>
        `;
    }
    _renderFeedback() {
        if (this._successMessage)
            return html `<div class="feedback success">${this._successMessage}</div>`;
        if (this._error)
            return html `<div class="feedback error">${this._error}</div>`;
        return html ``;
    }
    _renderForm() {
        return html `
            <form class="settings-form" @submit="${(e) => this._handleSave(e)}">

                <div class="form-group">
                    <label for="field-url">${this.msg.fieldUrl}</label>
                    <input
                        id="field-url"
                        type="url"
                        .value="${this._form.url}"
                        @input="${(e) => this._handleInput('url', e)}"
                    />
                </div>

                <div class="form-group">
                    <label for="field-company">${this.msg.fieldCompany}</label>
                    <input
                        id="field-company"
                        type="text"
                        .value="${this._form.company}"
                        @input="${(e) => this._handleInput('company', e)}"
                    />
                </div>

                <div class="form-group">
                    <label for="field-location">${this.msg.fieldLocation}</label>
                    <input
                        id="field-location"
                        type="text"
                        .value="${this._form.location}"
                        @input="${(e) => this._handleInput('location', e)}"
                    />
                </div>

                <div class="form-group">
                    <label for="field-email">${this.msg.fieldEmail}</label>
                    <input
                        id="field-email"
                        type="email"
                        .value="${this._form.email}"
                        @input="${(e) => this._handleInput('email', e)}"
                    />
                </div>

                <div class="form-group">
                    <label for="field-logo">${this.msg.fieldLogo}</label>
                    <input
                        id="field-logo"
                        type="url"
                        .value="${this._form.logo}"
                        @input="${(e) => this._handleInput('logo', e)}"
                    />
                </div>

                <div class="form-group">
                    <label for="field-description">
                        ${this.msg.fieldDescription}
                        <span class="hint">${this.msg.fieldDescriptionHint}</span>
                    </label>
                    <textarea
                        id="field-description"
                        rows="6"
                        .value="${this._form.description}"
                        @input="${(e) => this._handleInput('description', e)}"
                    ></textarea>
                </div>

                ${this._renderFeedback()}

                <div class="form-actions">
                    <button type="submit" class="btn-primary" ?disabled="${this._saving}">
                        ${this._saving ? this.msg.btnSaving : this.msg.btnSave}
                    </button>
                </div>

            </form>
        `;
    }
    _renderDangerZone() {
        return html `
            <section class="danger-zone">
                <h2 class="danger-title">${this.msg.dangerTitle}</h2>

                <div class="danger-item">
                    <div class="danger-item-info">
                        <strong>${this.msg.archiveTitle}</strong>
                        <p>${this.msg.archiveDesc}</p>
                    </div>
                    <button class="btn-warning" @click="${() => this._handleArchive()}">${this.msg.btnArchive}</button>
                </div>

                <div class="danger-item">
                    <div class="danger-item-info">
                        <strong>${this.msg.deleteTitle}</strong>
                        <p>${this.msg.deleteDesc}</p>
                    </div>
                    <button class="btn-danger" @click="${() => this._handleDelete()}">${this.msg.btnDelete}</button>
                </div>
            </section>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this._loading)
            return this._renderLoading();
        return html `
            <div class="settings-root">
                <h1 class="page-title">${this.msg.pageTitle}</h1>
                ${this._renderForm()}
                ${this._renderDangerZone()}
            </div>
        `;
    }
};
__decorate([
    property({ type: Number })
], CollabOrgSettings.prototype, "project", void 0);
CollabOrgSettings = __decorate([
    customElement('collab-org-settings-100554')
], CollabOrgSettings);
export { CollabOrgSettings };
