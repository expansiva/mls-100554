/// <mls fileReference="_100554_/l2/collabStartL1.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
const message_pt = {
  desc: "Descri\xE7\xE3o",
  news: "Novidades",
  inDevelopment: "Em desenvolvimento...",
  details1: "Sobre esse level",
  module1Title: "M\xF3dulo L1 - Back-End: Descri\xE7\xE3o e Funcionalidades",
  module1Text: "O m\xF3dulo L1 \xE9 voltado para o programador back-end e foca na l\xF3gica do servidor, incluindo autoridades, regras de neg\xF3cio e persist\xEAncia de dados. Este m\xF3dulo tamb\xE9m \xE9 respons\xE1vel por testar as rotinas em um ambiente de testes e gerenciar o layout das tabelas no banco de dados.",
  module1List1: "Programar Rotinas no Servidor",
  module1List1_1: "Desenvolvimento de APIs que ser\xE3o utilizadas em v\xE1rias p\xE1ginas para consultas comuns.",
  module1List1_2: "Programa\xE7\xE3o de rotinas que ser\xE3o respons\xE1veis pela valida\xE7\xE3o da p\xE1gina e pela hidrata\xE7\xE3o, ou seja, o envio de dados para a p\xE1gina ap\xF3s um post back.",
  module1List2: "Testar em Ambiente de Testes",
  module1List2_1: "Ferramentas e processos para testar as rotinas programadas em um ambiente isolado antes de serem implementadas no ambiente de produ\xE7\xE3o.",
  module1List3: "Verificar e Implementar Layouts das Tabelas no Banco de Dados",
  module1List3_1: "Processos para verificar e implementar os layouts das tabelas no banco de dados, garantindo que os dados sejam armazenados de forma eficiente e segura.",
  module2Title: "Fluxo de Uso",
  module2List1: "O usu\xE1rio come\xE7a programando as rotinas que ser\xE3o executadas no servidor, focando em autoridades, regras de neg\xF3cio e persist\xEAncia de dados.",
  module2List2: "Desenvolve APIs para consultas comuns que ser\xE3o usadas em v\xE1rias p\xE1ginas do projeto.",
  module2List3: "Programa rotinas espec\xEDficas para valida\xE7\xE3o e hidrata\xE7\xE3o de p\xE1ginas.",
  module2List4: "Testa todas as rotinas em um ambiente de testes para garantir que funcionem como esperado.",
  module2List5: "Verifica e implementa os layouts das tabelas no banco de dados para garantir a efici\xEAncia e seguran\xE7a no armazenamento de dados.",
  moduleExplain: "O m\xF3dulo L1 \xE9 fundamental para o funcionamento correto e seguro do projeto. Ele garante que todas as regras de neg\xF3cio sejam implementadas corretamente e que os dados sejam armazenados de forma segura e eficiente."
};
const message_en = {
  desc: "Description",
  news: "News",
  inDevelopment: "In development...",
  details1: "About this level",
  module1Title: "Module L1 - Back-End: Description and Features",
  module1Text: "The L1 module is aimed at back-end developers and focuses on server logic, including authorities, business rules, and data persistence. This module is also responsible for testing routines in a testing environment and managing database table layouts.",
  module1List1: "Program Server Routines",
  module1List1_1: "Developing APIs to be used across multiple pages for common queries.",
  module1List1_2: "Programming routines responsible for page validation and hydration, i.e., sending data to the page after a post-back.",
  module1List2: "Test in a Testing Environment",
  module1List2_1: "Tools and processes for testing programmed routines in an isolated environment before deployment to production.",
  module1List3: "Verify and Implement Database Table Layouts",
  module1List3_1: "Processes to verify and implement database table layouts, ensuring data is stored efficiently and securely.",
  module2Title: "Usage Flow",
  module2List1: "The user starts by programming routines to be executed on the server, focusing on authorities, business rules, and data persistence.",
  module2List2: "Develops APIs for common queries to be used across multiple pages of the project.",
  module2List3: "Programs specific routines for page validation and hydration.",
  module2List4: "Tests all routines in a testing environment to ensure they work as expected.",
  module2List5: "Verifies and implements database table layouts to ensure efficient and secure data storage.",
  moduleExplain: "The L1 module is essential for the correct and secure operation of the project. It ensures that all business rules are properly implemented and that data is stored securely and efficiently."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let CollabStartL1100554 = class extends StateLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-start-l1-100554 {
  line-height: 1.15;
  position: relative;
  height: 100%;
  overflow: auto;
  font-family: 'Cambria', serif;
  font-size: var(--font-size-16);
  font-weight: 400;
}
collab-start-l1-100554 details > summary {
  cursor: pointer;
  font-size: var(--font-size-20);
}
collab-start-l1-100554 .collab-codes-banner {
  margin-left: auto;
  margin-right: auto;
  display: block;
  width: 100%;
  max-width: 100%;
  position: relative;
}
collab-start-l1-100554 .collab-codes-banner img {
  width: 100% !important;
  height: auto !important;
}
collab-start-l1-100554 .collab-codes-link {
  display: flex;
  justify-content: center;
  gap: 2rem;
  padding: 2rem;
}
collab-start-l1-100554 .collab-codes-link button {
  cursor: pointer;
  background: none;
  border: none;
  text-decoration: underline;
  color: var(--active-color);
}
collab-start-l1-100554 .collab-codes-content {
  padding: 0 0.5rem;
  margin-left: auto;
  margin-right: auto;
  max-width: 800px;
  justify-content: center;
}
collab-start-l1-100554 .collab-codes-content details {
  margin-bottom: 1rem;
}
collab-start-l1-100554 .collab-codes-content details > div {
  padding-left: 1.5rem;
}
collab-start-l1-100554 .collab-codes-contents {
  justify-content: center;
}
collab-start-l1-100554 .collab-codes-contents details {
  margin-bottom: 1rem;
}
collab-start-l1-100554 .collab-codes-contents details > div {
  padding-left: 1.5rem;
}
collab-start-l1-100554 .separator {
  padding-top: 24px;
  padding-bottom: 10px;
  margin-top: 32px;
  margin-bottom: 14px;
  display: flex;
  justify-content: center;
}
collab-start-l1-100554 .separator > span {
  width: 4px;
  height: 4px;
  background-color: var(--text-primary-color);
  border-radius: 50%;
  display: inline-block;
  margin-right: 20px;
}
collab-start-l1-100554 h1 {
  line-height: 52px;
  font-size: 42px;
  font-weight: 700;
  font-style: normal;
}
collab-start-l1-100554 h2 {
  line-height: 30px;
  font-size: 24px;
  font-weight: 600;
  font-style: normal;
}
collab-start-l1-100554 h1,
collab-start-l1-100554 h2,
collab-start-l1-100554 h3,
collab-start-l1-100554 h4,
collab-start-l1-100554 h5,
collab-start-l1-100554 h6,
collab-start-l1-100554 h7 {
  letter-spacing: -0.011em;
}
collab-start-l1-100554 ol > li,
collab-start-l1-100554 ul > li {
  margin-top: 1em;
}
collab-start-l1-100554 span,
collab-start-l1-100554 p,
collab-start-l1-100554 li {
  line-height: 32px;
  font-size: 20px;
}
collab-start-l1-100554 .collab_marca {
  position: absolute;
  bottom: 10px;
  right: 20px;
  opacity: 0.2;
}
`);
    this.msg = messages["en"];
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
        <section class="collab-codes-start">
            <div class="collab-codes-banner">
                <img id="serviceStartL1ImageBanner" src="./l3/_100529_/images/startl1.avif" height="250" width="800" alt="banner">
            </div>
            <div class="collab-codes-content">
                <details id="serviceStartL1DetailsAbout" open="open">
                    <summary>${this.msg.details1}</summary>
                    <div>
                        <h1>${this.msg.module1Title}</h1>
                        <div>
                            <h2>${this.msg.desc}</h2>
                            <span>${this.msg.module1Text}

                                <ol>
                                    <li>
                                        <span>${this.msg.module1List1}</span>
                                        <ul>
                                            <li>${this.msg.module1List1_1}
                                            </li>
                                            <li>${this.msg.module1List1_2}</b>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List2}</span>
                                        <ul>
                                            <li>${this.msg.module1List2_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List3}</span>
                                        <ul>
                                            <li>${this.msg.module1List3_1}</li>
                                        </ul>
                                    </li>
                                </ol>

                            </span>
                        </div>
                        <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module2Title}</h3>
                            <ol>
                                <li>${this.msg.module2List1}</li>
                                <li>${this.msg.module2List2}</li>
                                <li>${this.msg.module2List3}</li>
                                <li>${this.msg.module2List4}</li>
                            </ol>
                            <span>${this.msg.moduleExplain}</span>
                        </div>
                    </div>
                </details>
                <details id="serviceStartL1DetailsNews" open="open">
                    <summary>${this.msg.news}</summary>
                    <div>
                        <span>${this.msg.inDevelopment}</span>
                    </div>
                </details>
            </div>
        </section>
        <img class="collab_marca" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==" height="140" width="140" alt="collab codes">
         `;
  }
};
CollabStartL1100554 = __decorateClass([
  customElement("collab-start-l1-100554")
], CollabStartL1100554);
export {
  CollabStartL1100554
};
