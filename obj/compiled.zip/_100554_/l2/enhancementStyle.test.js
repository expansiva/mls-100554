/// <mls fileReference="_100554_/l2/enhancementStyle.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
