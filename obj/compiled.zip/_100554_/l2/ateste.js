/// <mls fileReference="_100554_/l2/ateste.js" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let SimpleGreeting = class SimpleGreeting extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-100554{display:block}ateste-100554 .cls1{font-size:14px;border:1px;clip-path:none;text-shadow:1px 1px;column-count:auto;flex:1 1 auto;cursor:pointer;padding:0px;margin:0rem}ateste-100554 .cls1 h1{background-color:var(--bg-primary-color);color:red}ateste-100554.thema2 .cls1{background-color:var(--text-primary-color-lighter-disabled);color:var(--success-color-focus);font-size:12px;border-width:1px}ateste-100554.thema2 .cls1 h1{color:red}ateste-100554.thema2 .cls1 h1:hover{color:yellowgreen}`);
        this.list = [];
        this.current = 0;
        this.tot = 0;
    }
    render() {
        return html ` 
    <div>
      <h2>${this.current}/${this.tot}</h2>
      <button style="border:1px solid gray;" @click=${this.clickBusca}> Rodar</button>
      <ol style="background:black;color:white; height:150px; overflow:auto" id="list">
      ${this.list.map((l) => html `<li>${l}</li>`)}
      </ol>
      <textarea style="border:1px solid gray; margin-top:1rem; width:100%; min-height:300px" id="teste"></textarea>
    </div>
  `;
    }
    async clickBusca() {
        let itens = [];
        let erros = [];
        Object.keys(mls.stor.files).forEach((key) => {
            const f = mls.stor.files[key];
            if (f && f.level === 2 && f.shortName.toLocaleLowerCase().startsWith('a') && f.project === mls.actualProject && !['.html'].includes(f.extension))
                itens.push(key);
        });
        this.tot = itens.length;
        for await (const key of itens) {
            this.current = this.current + 1;
            const f = mls.stor.files[key];
            if (!f)
                continue;
            let newSource = await this.changeSource(f);
            if (!newSource || !this.teste) {
                if (this.teste)
                    this.teste.value = 'Nada';
                continue;
            }
            this.teste.value = newSource;
            const info = {
                contentType: 'string',
                content: newSource,
            };
            f.status = 'changed';
            await mls.stor.localStor.setContent(f, info);
            this.list.push(key);
            this.list = [...this.list];
        }
        console.info('---------ERROS---------', erros);
    }
    async changeSource(file) {
        try {
            if (!file)
                throw new Error(`[beforePromptStep] invalid args, file dont exists`);
            const source = (await file.getContent());
            if (typeof source !== 'string' || !source)
                throw new Error(`[beforePromptAtomic] invalid source`);
            const array = source.split("\n");
            if (!array)
                return '';
            const fileReference = mls.stor.convertFileToFileReference(file);
            if (!array[0].includes('fileReference') || array[0].includes('groupName')) {
                const tp = mls.common.tripleslash.parseXMLTripleSlash(array[0]).variables;
                array[0] = `/// <mls fileReference="${fileReference}" enhancement="${tp.enhancement || "_blank"}" />`;
            }
            return array.join("\n");
        }
        catch (e) {
            return '';
        }
    }
};
__decorate([
    query('#teste')
], SimpleGreeting.prototype, "teste", void 0);
__decorate([
    state()
], SimpleGreeting.prototype, "list", void 0);
__decorate([
    state()
], SimpleGreeting.prototype, "current", void 0);
__decorate([
    state()
], SimpleGreeting.prototype, "tot", void 0);
SimpleGreeting = __decorate([
    customElement('ateste-100554')
], SimpleGreeting);
export { SimpleGreeting };
