/// <mls fileReference="_100554_/l2/ateste.js" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, state, query } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
let SimpleGreeting = class extends CollabLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`ateste-100554 {
  display: block;
}
ateste-100554 .cls1 {
  font-size: 14px;
  border: 1px;
  clip-path: none;
  text-shadow: 1px 1px;
  column-count: auto;
  flex: 1 1 auto;
  cursor: pointer;
  padding: 0px;
  margin: 0rem;
}
ateste-100554 .cls1 h1 {
  background-color: var(--bg-primary-color);
  color: red;
}
ateste-100554.thema2 .cls1 {
  background-color: var(--text-primary-color-lighter-disabled);
  color: var(--success-color-focus);
  font-size: 12px;
  border-width: 1px;
}
ateste-100554.thema2 .cls1 h1 {
  color: red;
}
ateste-100554.thema2 .cls1 h1:hover {
  color: yellowgreen;
}
`);
    this.list = [];
    this.current = 0;
    this.tot = 0;
  }
  render() {
    return html` 
    <div>
      <h2>${this.current}/${this.tot}</h2>
      <button style="border:1px solid gray;" @click=${this.clickBusca}> Rodar</button>
      <ol style="background:black;color:white; height:150px; overflow:auto" id="list">
      ${this.list.map((l) => html`<li>${l}</li>`)}
      </ol>
      <textarea style="border:1px solid gray; margin-top:1rem; width:100%; min-height:300px" id="teste"></textarea>
    </div>
  `;
  }
  async clickBusca() {
    let itens = [];
    let erros = [];
    Object.keys(mls.stor.files).forEach((key) => {
      const f = mls.stor.files[key];
      if (f && f.level === 2 && f.shortName.toLocaleLowerCase().startsWith("w") && f.project === mls.actualProject && ![".html"].includes(f.extension)) itens.push(key);
    });
    this.tot = itens.length;
    for await (const key of itens) {
      this.current = this.current + 1;
      const f = mls.stor.files[key];
      if (!f) continue;
      let newSource = await this.changeSource(f);
      if (!newSource || !this.teste) {
        if (this.teste) this.teste.value = "Nada";
        continue;
      }
      this.teste.value = newSource;
      const info = {
        contentType: "string",
        content: newSource
      };
      f.status = "changed";
      await mls.stor.localStor.setContent(f, info);
      this.list.push(key);
      this.list = [...this.list];
    }
    console.info("---------ERROS---------", erros);
  }
  async changeSource(file) {
    try {
      if (!file) throw new Error(`[beforePromptStep] invalid args, file dont exists`);
      const source = await file.getContent();
      if (typeof source !== "string" || !source) throw new Error(`[beforePromptAtomic] invalid source`);
      const array = source.split("\n");
      if (!array) return "";
      const fileReference = mls.stor.convertFileToFileReference(file);
      if (!array[0].includes("fileReference") || array[0].includes("groupName")) {
        const tp = this.parseXMLTripleSlash(array[0]).variables;
        array[0] = `/// <mls fileReference="${fileReference}" enhancement="${tp.enhancement || "_blank"}" />`;
      } else {
        return "";
      }
      return array.join("\n");
    } catch (e) {
      return "";
    }
  }
  parseXMLTripleSlash(line) {
    if (!line.startsWith("/// <")) throw new Error('line must start with "/// <" (triple slash and xml');
    const tagName = "mls";
    const requiredVars = ["enhancement", "fileReference"];
    const optionalVars = ["author", "groupName"];
    const res = this.parseXML(line.substring(3).trim());
    if (typeof res === "string") throw new Error(`invalid triple slash: ${res}`);
    if (res.tagName !== tagName) throw new Error(`invalid tag name: '${res.tagName}', use '${tagName}'`);
    return res;
  }
  parseXML(str) {
    const regex = /<(\w+)((?:\s+\w+(?:\s*=\s*(?:"[^"]*"|'[^']*'))?)*)\s*\/?>/;
    const match = str.match(regex);
    if (!match) return "XML invalid: use ex: <mls variable='text' />";
    const tagName2 = match[1];
    const variables = {};
    const attributes = match[2].match(/\w+(?:\s*=\s*(?:"[^"]*"|'[^']*'))?/g) || [];
    for (let i = 0; i < attributes.length; i++) {
      const [name, value] = attributes[i].split("=");
      variables[name || "?"] = value ? value.replace(/(^['"]|['"]$)/g, "") : "";
    }
    const text = str.replace(match[0], "").trim();
    if (text) return `XML text invalid: '${text}' use ex: <mls variable='text' />`;
    return { tagName: tagName2, variables };
  }
};
__decorateClass([
  query("#teste")
], SimpleGreeting.prototype, "teste", 2);
__decorateClass([
  state()
], SimpleGreeting.prototype, "list", 2);
__decorateClass([
  state()
], SimpleGreeting.prototype, "current", 2);
__decorateClass([
  state()
], SimpleGreeting.prototype, "tot", 2);
SimpleGreeting = __decorateClass([
  customElement("ateste-100554")
], SimpleGreeting);
export {
  SimpleGreeting
};
