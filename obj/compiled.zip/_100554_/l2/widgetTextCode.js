/// <mls fileReference="_100554_/l2/widgetTextCode.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let WidgetTextCode = class WidgetTextCode extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`widget-text-code-100554 {
  /*
      * Visual Studio 2015 dark style
      * Author: Nicolas LLOBERA <nllobera@gmail.com>
      */
}
widget-text-code-100554 pre {
  position: relative;
  white-space: pre-wrap;
  margin: 0;
}
widget-text-code-100554 pre select {
  position: absolute;
  top: 62px;
  left: 5px;
  border: none;
  outline: none;
}
widget-text-code-100554 pre code.hljs {
  display: block;
  overflow-x: auto;
  padding: 1em;
}
widget-text-code-100554 code.hljs {
  padding: 3px 5px;
}
widget-text-code-100554 .hljs {
  background: #fff;
  border: 1px solid var(--grey-color);
  color: #000;
  outline: none;
}
widget-text-code-100554 .hljs-keyword,
widget-text-code-100554 .hljs-literal,
widget-text-code-100554 .hljs-symbol,
widget-text-code-100554 .hljs-name {
  color: #569CD6;
}
widget-text-code-100554 .hljs-link {
  color: #569CD6;
  text-decoration: underline;
}
widget-text-code-100554 .hljs-built_in,
widget-text-code-100554 .hljs-type {
  color: #4EC9B0;
}
widget-text-code-100554 .hljs-number,
widget-text-code-100554 .hljs-class {
  color: #B8D7A3;
}
widget-text-code-100554 .hljs-string,
widget-text-code-100554 .hljs-meta .hljs-string {
  color: #D69D85;
}
widget-text-code-100554 .hljs-regexp,
widget-text-code-100554 .hljs-template-tag {
  color: #9A5334;
}
widget-text-code-100554 .hljs-subst,
widget-text-code-100554 .hljs-function,
widget-text-code-100554 .hljs-title,
widget-text-code-100554 .hljs-params,
widget-text-code-100554 .hljs-formula {
  color: #DCDCDC;
}
widget-text-code-100554 .hljs-comment,
widget-text-code-100554 .hljs-quote {
  color: #57A64A;
  font-style: italic;
}
widget-text-code-100554 .hljs-doctag {
  color: #608B4E;
}
widget-text-code-100554 .hljs-meta,
widget-text-code-100554 .hljs-meta .hljs-keyword,
widget-text-code-100554 .hljs-tag {
  color: #9B9B9B;
}
widget-text-code-100554 .hljs-variable,
widget-text-code-100554 .hljs-template-variable {
  color: #BD63C5;
}
widget-text-code-100554 .hljs-attr,
widget-text-code-100554 .hljs-attribute {
  color: #9CDCFE;
}
widget-text-code-100554 .hljs-section {
  color: gold;
}
widget-text-code-100554 .hljs-emphasis {
  font-style: italic;
}
widget-text-code-100554 .hljs-strong {
  font-weight: bold;
}
widget-text-code-100554 .hljs-bullet,
widget-text-code-100554 .hljs-selector-tag,
widget-text-code-100554 .hljs-selector-id,
widget-text-code-100554 .hljs-selector-class,
widget-text-code-100554 .hljs-selector-attr,
widget-text-code-100554 .hljs-selector-pseudo {
  color: #D7BA7D;
}
widget-text-code-100554 .hljs-addition {
  background-color: #144212;
  display: inline-block;
  width: 100%;
}
widget-text-code-100554 .hljs-deletion {
  background-color: #600;
  display: inline-block;
  width: 100%;
}
widget-text-code-100554.hljs {
  /*!
        Theme: Default
        Description: Original highlight.js style
        Author: (c) Ivan Sagalaev <maniac@softwaremaniacs.org>
        Maintainer: @highlightjs/core-team
        Website: https://highlightjs.org/
        License: see project LICENSE
        Touched: 2021
    */
}
widget-text-code-100554.hljs pre code.hljs {
  display: block;
  overflow-x: auto;
  padding: 1em;
}
widget-text-code-100554.hljs code.hljs {
  padding: 3px 5px;
}
widget-text-code-100554.hljs .hljs {
  background: #f3f3f3;
  color: #444;
}
widget-text-code-100554.hljs .hljs-comment {
  color: #697070;
}
widget-text-code-100554.hljs .hljs-punctuation,
widget-text-code-100554.hljs .hljs-tag {
  color: #444a;
}
widget-text-code-100554.hljs .hljs-tag .hljs-attr,
widget-text-code-100554.hljs .hljs-tag .hljs-name {
  color: #444;
}
widget-text-code-100554.hljs .hljs-attribute,
widget-text-code-100554.hljs .hljs-doctag,
widget-text-code-100554.hljs .hljs-keyword,
widget-text-code-100554.hljs .hljs-meta .hljs-keyword,
widget-text-code-100554.hljs .hljs-name,
widget-text-code-100554.hljs .hljs-selector-tag {
  font-weight: 700;
}
widget-text-code-100554.hljs .hljs-deletion,
widget-text-code-100554.hljs .hljs-number,
widget-text-code-100554.hljs .hljs-quote,
widget-text-code-100554.hljs .hljs-selector-class,
widget-text-code-100554.hljs .hljs-selector-id,
widget-text-code-100554.hljs .hljs-string,
widget-text-code-100554.hljs .hljs-template-tag,
widget-text-code-100554.hljs .hljs-type {
  color: #800;
}
widget-text-code-100554.hljs .hljs-section,
widget-text-code-100554.hljs .hljs-title {
  color: #800;
  font-weight: 700;
}
widget-text-code-100554.hljs .hljs-link,
widget-text-code-100554.hljs .hljs-operator,
widget-text-code-100554.hljs .hljs-regexp,
widget-text-code-100554.hljs .hljs-selector-attr,
widget-text-code-100554.hljs .hljs-selector-pseudo,
widget-text-code-100554.hljs .hljs-symbol,
widget-text-code-100554.hljs .hljs-template-variable,
widget-text-code-100554.hljs .hljs-variable {
  color: #ab5656;
}
widget-text-code-100554.hljs .hljs-literal {
  color: #695;
}
widget-text-code-100554.hljs .hljs-addition,
widget-text-code-100554.hljs .hljs-built_in,
widget-text-code-100554.hljs .hljs-bullet,
widget-text-code-100554.hljs .hljs-code {
  color: #397300;
}
widget-text-code-100554.hljs .hljs-meta {
  color: #1f7199;
}
widget-text-code-100554.hljs .hljs-meta .hljs-string {
  color: #38a;
}
widget-text-code-100554.hljs .hljs-emphasis {
  font-style: italic;
}
widget-text-code-100554.hljs .hljs-strong {
  font-weight: 700;
}
widget-text-code-100554.github {
  /*!
    Theme: GitHub
    Description: Light theme as seen on github.com
    Author: github.com
    Maintainer: @Hirse
    Updated: 2021-05-15

    Outdated base version: https://github.com/primer/github-syntax-light
    Current colors taken from GitHub's CSS
    */
}
widget-text-code-100554.github pre code.hljs {
  display: block;
  overflow-x: auto;
  padding: 1em;
}
widget-text-code-100554.github code.hljs {
  padding: 3px 5px;
}
widget-text-code-100554.github .hljs {
  color: #24292e;
  background: #fff;
}
widget-text-code-100554.github .hljs-doctag,
widget-text-code-100554.github .hljs-keyword,
widget-text-code-100554.github .hljs-meta .hljs-keyword,
widget-text-code-100554.github .hljs-template-tag,
widget-text-code-100554.github .hljs-template-variable,
widget-text-code-100554.github .hljs-type,
widget-text-code-100554.github .hljs-variable.language_ {
  color: #d73a49;
}
widget-text-code-100554.github .hljs-title,
widget-text-code-100554.github .hljs-title.class_,
widget-text-code-100554.github .hljs-title.class_.inherited__,
widget-text-code-100554.github .hljs-title.function_ {
  color: #6f42c1;
}
widget-text-code-100554.github .hljs-attr,
widget-text-code-100554.github .hljs-attribute,
widget-text-code-100554.github .hljs-literal,
widget-text-code-100554.github .hljs-meta,
widget-text-code-100554.github .hljs-number,
widget-text-code-100554.github .hljs-operator,
widget-text-code-100554.github .hljs-selector-attr,
widget-text-code-100554.github .hljs-selector-class,
widget-text-code-100554.github .hljs-selector-id,
widget-text-code-100554.github .hljs-variable {
  color: #005cc5;
}
widget-text-code-100554.github .hljs-meta .hljs-string,
widget-text-code-100554.github .hljs-regexp,
widget-text-code-100554.github .hljs-string {
  color: #032f62;
}
widget-text-code-100554.github .hljs-built_in,
widget-text-code-100554.github .hljs-symbol {
  color: #e36209;
}
widget-text-code-100554.github .hljs-code,
widget-text-code-100554.github .hljs-comment,
widget-text-code-100554.github .hljs-formula {
  color: #6a737d;
}
widget-text-code-100554.github .hljs-name,
widget-text-code-100554.github .hljs-quote,
widget-text-code-100554.github .hljs-selector-pseudo,
widget-text-code-100554.github .hljs-selector-tag {
  color: #22863a;
}
widget-text-code-100554.github .hljs-subst {
  color: #24292e;
}
widget-text-code-100554.github .hljs-section {
  color: #005cc5;
  font-weight: 700;
}
widget-text-code-100554.github .hljs-bullet {
  color: #735c0f;
}
widget-text-code-100554.github .hljs-emphasis {
  color: #24292e;
  font-style: italic;
}
widget-text-code-100554.github .hljs-strong {
  color: #24292e;
  font-weight: 700;
}
widget-text-code-100554.github .hljs-addition {
  color: #22863a;
  background-color: #f0fff4;
}
widget-text-code-100554.github .hljs-deletion {
  color: #b31d28;
  background-color: #ffeef0;
}
`);
        this.language = 'typescript';
        this.languages = [];
        this.text = '';
    }
    updated(changedProperties) {
        if (changedProperties.has('language')) {
            if (!window.hljsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js';
                script.onload = () => {
                    window.hljsLoaded = true;
                    this.setCode();
                };
                document.head.appendChild(script);
            }
            else {
                this.setCode();
            }
        }
        if (changedProperties.has('text')) {
            if (!this.codeBlock)
                return;
            this.waitForLoadIfNeeded(() => {
                this.setCode();
            });
        }
        if (changedProperties.has('languages')) {
            if (this.select)
                this.select.value = this.language;
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.hljsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load highlight.js. please try again`);
            }
        };
        checkVariable();
    }
    unescapeHtml(str) {
        const map = {
            '&lt;': '<',
            '&gt;': '>',
            '&quot;': '"',
            '&#039;': "'",
            '&amp;': '&',
        };
        let result = str;
        let changed = true;
        while (changed) {
            changed = false;
            result = result.replace(/&(lt|gt|quot|#039|amp);/g, (match) => {
                changed = true;
                return map[match] ?? match;
            });
        }
        return result;
    }
    setCode() {
        if (!this.codeBlock)
            return;
        this.codeBlock.innerHTML = '';
        this.codeBlock.removeAttribute('data-highlighted');
        this.codeBlock.classList.add('language-' + this.language);
        const that = this;
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            window.hljs.configure({ ignoreUnescapedHTML: true });
            if (!that.languages || that.languages.length === 0)
                that.languages = window.hljs.listLanguages();
            const res = window.hljs.highlight(this.unescapeHtml(this.text), { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
        });
    }
    firstUpdated() {
        this.setCode();
    }
    render() {
        return html `
       <pre>
            <code class="code" spellcheck="false"></code>
       </pre>
    `;
    }
    onChangeText(e) {
        const target = e.target;
        const val = target.textContent;
        const that = this;
        function setCursorToEnd(el) {
            const range = document.createRange();
            const selection = window.getSelection();
            range.selectNodeContents(el);
            range.collapse(false);
            if (!selection)
                return;
            selection.removeAllRanges();
            selection.addRange(range);
        }
        this.waitForLoadIfNeeded(() => {
            if (!that.codeBlock)
                return;
            const res = window.hljs.highlight(val, { language: that.language });
            that.codeBlock.removeAttribute("data-highlighted");
            window.hljs.highlightElement(that.codeBlock, { language: that.language });
            that.codeBlock.innerHTML = res.value;
            setCursorToEnd(that.codeBlock);
        });
    }
};
__decorate([
    property({ type: String })
], WidgetTextCode.prototype, "config", void 0);
__decorate([
    property({ type: String, reflect: true, attribute: true })
], WidgetTextCode.prototype, "language", void 0);
__decorate([
    property({ type: Array })
], WidgetTextCode.prototype, "languages", void 0);
__decorate([
    property({ type: String, reflect: true })
], WidgetTextCode.prototype, "text", void 0);
__decorate([
    query('.code')
], WidgetTextCode.prototype, "codeBlock", void 0);
__decorate([
    query('select')
], WidgetTextCode.prototype, "select", void 0);
WidgetTextCode = __decorate([
    customElement('widget-text-code-100554')
], WidgetTextCode);
export { WidgetTextCode };
