/// <mls fileReference="_100554_/l2/collabStartL4.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
const message_pt = {
  desc: "Descri\xE7\xE3o",
  news: "Novidades",
  inDevelopment: "Em desenvolvimento...",
  details1: "Sobre esse level",
  module1Title: "M\xF3dulo L4 - Business: Descri\xE7\xE3o e Funcionalidades",
  module1Text: "O m\xF3dulo L4 \xE9 voltado para o usu\xE1rio respons\xE1vel por entender do neg\xF3cio e montar as p\xE1ginas do projeto. Ele serve como uma ponte entre a vis\xE3o do neg\xF3cio e a implementa\xE7\xE3o t\xE9cnica, permitindo que o usu\xE1rio crie, teste e publique p\xE1ginas de forma eficiente.",
  module1List1: "Desenhar P\xE1gina no Modo Wireframe",
  module1List1_1: "Permite criar o layout inicial da p\xE1gina em modo wireframe, que pode ser adaptado para v\xE1rios dispositivos (desktop, mobile, tablet), e tamb\xE9m permite criar v\xE1rias varia\xE7\xF5es , com ideias para serem apresentadas e aprovadas.",
  module1List2: "Usar Design System (UI)",
  module1List2_1: "Oferece a op\xE7\xE3o de utilizar elementos do Design System existente ou solicitar altera\xE7\xF5es que ser\xE3o tratadas no m\xF3dulo L3.",
  module1List3: "Usar Componentes",
  module1List3_1: "Permite utilizar componentes prontos dispon\xEDveis no sistema ou solicitar a inclus\xE3o de novos componentes, que ser\xE3o desenvolvidos no m\xF3dulo L2.Mostra uma lista de todas as pessoas envolvidas no projeto e m\xE9tricas sobre sua colabora\xE7\xE3o, como tarefas conclu\xEDdas, horas trabalhadas, etc.",
  module1List4: "Usar Funcionalidades de Back-End",
  module1List4_1: "Oferece a op\xE7\xE3o de utilizar APIs prontas ou solicitar a inclus\xE3o de novas funcionalidades que ser\xE3o desenvolvidas no m\xF3dulo L1.",
  module1List5: "Programar funcionalidades da P\xE1gina",
  module1List5_1: "Permite ao Analista Business ou Programador Web ou Programador Back-end, implementar as funcionalidades da p\xE1gina.",
  module1List6: "Testar e Liberar para Homologa\xE7\xE3o/Publish",
  module1List6_1: "Permite testar as p\xE1ginas criadas e, uma vez aprovadas, liber\xE1-las para a fase de homologa\xE7\xE3o ou publica\xE7\xE3o direta.",
  module2Title: "Fluxo de Uso",
  module2List1: "O usu\xE1rio inicia criando o layout da p\xE1gina em modo wireframe, ajustando para diferentes dispositivos.",
  module2List2: "Seleciona elementos do Design System ou solicita altera\xE7\xF5es para adequar \xE0 est\xE9tica do projeto.",
  module2List3: "Incorpora componentes prontos ou solicita novos, conforme a necessidade.",
  module2List4: "Integra APIs prontas ou solicita novas funcionalidades de back-end.",
  module2List5: "Realiza testes e, se tudo estiver conforme o esperado, libera a p\xE1gina para homologa\xE7\xE3o ou publica\xE7\xE3o.",
  module3Title: "Exemplos de Prompts para Iniciar Projetos via IA",
  module3List1: "Prompt: Preciso de um painel de administra\xE7\xE3o para gerenciar usu\xE1rios e conte\xFAdo.",
  module3List2: "Prompt: Quero uma p\xE1gina de checkout otimizada para convers\xE3o, com op\xE7\xF5es de pagamento m\xFAltiplo.",
  module3List3: "Prompt: Necessito de uma interface de usu\xE1rio para visualizar relat\xF3rios e m\xE9tricas em tempo real.",
  module3List4: "Prompt: Gostaria de criar uma p\xE1gina de perfil de usu\xE1rio com op\xE7\xF5es para editar informa\xE7\xF5es pessoais.",
  module3List5: "Prompt: Preciso de uma p\xE1gina de FAQ interativa para ajudar os usu\xE1rios a encontrar respostas rapidamente.",
  moduleExplain: "O m\xF3dulo L4 \xE9 essencial para transformar ideias de neg\xF3cio em realidade, fornecendo as ferramentas necess\xE1rias para criar, ajustar e publicar p\xE1ginas de forma \xE1gil e alinhada com os objetivos do projeto."
};
const message_en = {
  desc: "Description",
  news: "News",
  inDevelopment: "In development...",
  details1: "About this level",
  module1Title: "Module L4 - Business: Description and Features",
  module1Text: "The L4 module is designed for users responsible for understanding the business and assembling project pages. It acts as a bridge between business vision and technical implementation, enabling users to create, test, and publish pages efficiently.",
  module1List1: "Design Page in Wireframe Mode",
  module1List1_1: "Allows the creation of an initial page layout in wireframe mode, adaptable to various devices (desktop, mobile, tablet) and supports multiple variations for presentation and approval.",
  module1List2: "Use Design System (UI)",
  module1List2_1: "Provides the option to use existing Design System elements or request changes handled in module L3.",
  module1List3: "Use Components",
  module1List3_1: "Enables the use of ready-made components available in the system or requests for new ones to be developed in module L2. Displays a list of all project collaborators and metrics on their contributions, such as completed tasks and hours worked.",
  module1List4: "Use Back-End Features",
  module1List4_1: "Provides the option to use ready-made APIs or request the addition of new features to be developed in module L1.",
  module1List5: "Program Page Features",
  module1List5_1: "Allows a Business Analyst, Web Developer, or Back-End Programmer to implement page functionalities.",
  module1List6: "Test and Release for Approval/Publish",
  module1List6_1: "Allows testing of created pages and, once approved, releasing them for the approval phase or direct publication.",
  module2Title: "Usage Flow",
  module2List1: "The user starts by creating the page layout in wireframe mode, adjusting for different devices.",
  module2List2: "Selects Design System elements or requests changes to match the project\u2019s aesthetics.",
  module2List3: "Incorporates ready-made components or requests new ones as needed.",
  module2List4: "Integrates ready-made APIs or requests new back-end features.",
  module2List5: "Performs tests and, if everything is as expected, releases the page for approval or publication.",
  module3Title: "Prompt Examples to Start Projects via AI",
  module3List1: "Prompt: I need an admin panel to manage users and content.",
  module3List2: "Prompt: I want a checkout page optimized for conversion with multiple payment options.",
  module3List3: "Prompt: I need a user interface to view reports and metrics in real-time.",
  module3List4: "Prompt: I\u2019d like to create a user profile page with options to edit personal information.",
  module3List5: "Prompt: I need an interactive FAQ page to help users find answers quickly.",
  moduleExplain: "The L4 module is essential for turning business ideas into reality, providing the tools necessary to create, adjust, and publish pages quickly and aligned with project goals."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let CollabStartL4100554 = class extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-start-l4-100554 {
  line-height: 1.15;
  position: relative;
  height: 100%;
  overflow: auto;
  font-family: 'Cambria', serif;
  font-size: var(--font-size-16);
  font-weight: 400;
}
collab-start-l4-100554 details > summary {
  cursor: pointer;
  font-size: var(--font-size-20);
}
collab-start-l4-100554 .collab-codes-banner {
  margin-left: auto;
  margin-right: auto;
  display: block;
  width: 100%;
  max-width: 100%;
  position: relative;
}
collab-start-l4-100554 .collab-codes-banner img {
  width: 100% !important;
  height: auto !important;
}
collab-start-l4-100554 .collab-codes-link {
  display: flex;
  justify-content: center;
  gap: 2rem;
  padding: 2rem;
}
collab-start-l4-100554 .collab-codes-link button {
  cursor: pointer;
  background: none;
  border: none;
  text-decoration: underline;
  color: var(--active-color);
}
collab-start-l4-100554 .collab-codes-content {
  padding: 0 0.5rem;
  margin-left: auto;
  margin-right: auto;
  max-width: 800px;
  justify-content: center;
}
collab-start-l4-100554 .collab-codes-content details {
  margin-bottom: 1rem;
}
collab-start-l4-100554 .collab-codes-content details > div {
  padding-left: 1.5rem;
}
collab-start-l4-100554 .collab-codes-contents {
  justify-content: center;
}
collab-start-l4-100554 .collab-codes-contents details {
  margin-bottom: 1rem;
}
collab-start-l4-100554 .collab-codes-contents details > div {
  padding-left: 1.5rem;
}
collab-start-l4-100554 .separator {
  padding-top: 24px;
  padding-bottom: 10px;
  margin-top: 32px;
  margin-bottom: 14px;
  display: flex;
  justify-content: center;
}
collab-start-l4-100554 .separator > span {
  width: 4px;
  height: 4px;
  background-color: var(--text-primary-color);
  border-radius: 50%;
  display: inline-block;
  margin-right: 20px;
}
collab-start-l4-100554 h1 {
  line-height: 52px;
  font-size: 42px;
  font-weight: 700;
  font-style: normal;
}
collab-start-l4-100554 h2 {
  line-height: 30px;
  font-size: 24px;
  font-weight: 600;
  font-style: normal;
}
collab-start-l4-100554 h1,
collab-start-l4-100554 h2,
collab-start-l4-100554 h3,
collab-start-l4-100554 h4,
collab-start-l4-100554 h5,
collab-start-l4-100554 h6,
collab-start-l4-100554 h7 {
  letter-spacing: -0.011em;
}
collab-start-l4-100554 ol > li,
collab-start-l4-100554 ul > li {
  margin-top: 1em;
}
collab-start-l4-100554 span,
collab-start-l4-100554 p,
collab-start-l4-100554 li {
  line-height: 32px;
  font-size: 20px;
}
collab-start-l4-100554 .collab_marca {
  position: absolute;
  bottom: 10px;
  right: 20px;
  opacity: 0.2;
}
`);
    }
  msg = messages["en"];
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
        <section class="collab-codes-start">
            <div class="collab-codes-banner">
                <img id="serviceStartL4ImageBanner" src="./l3/_100529_/images/startl4.avif" height="250" width="800" alt="banner">
            </div>
            <div class="collab-codes-content">
                <details id="serviceStartL4DetailsAbout" open="open">
                    <summary>${this.msg.details1}</summary>
                    <div>
                        <h1>${this.msg.module1Title}</h1>
                        <div>
                            <h2>${this.msg.desc}</h2>
                            <span>${this.msg.module1Text}

                                <ol>
                                    <li>
                                        <span>${this.msg.module1List1}</span>
                                        <ul>
                                            <li>${this.msg.module1List1_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List2}</span>
                                        <ul>
                                            <li>${this.msg.module1List2_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List3}</span>
                                        <ul>
                                            <li>${this.msg.module1List3_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List4}</span>
                                        <ul>
                                            <li>${this.msg.module1List4_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List5}</span>
                                        <ul>
                                            <li>${this.msg.module1List5_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List6}</span>
                                        <ul>
                                            <li>${this.msg.module1List6_1}</li>
                                        </ul>
                                    </li>
                                </ol>

                            </span>
                        </div>
                          <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module2Title}</h3>
                            <ol>
                                <li>${this.msg.module2List1}</li>
                                <li>${this.msg.module2List2}</li>
                                <li>${this.msg.module2List3}</li>
                                <li>${this.msg.module2List4}</li>
                                <li>${this.msg.module2List5}</li>

                            </ol>
                        </div>
                          <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module3Title}</h3>
                            <ol>
                                <li>${this.msg.module3List1}</li>
                                <li>${this.msg.module3List2}</li>
                                <li>${this.msg.module3List3}</li>
                                <li>${this.msg.module3List4}</li>
                            </ol>
                            <span>${this.msg.moduleExplain}</span>
                        </div>
                    </div>
                </details>
                <details id="serviceStartL4DetailsNews" open="open">
                    <summary>${this.msg.news}</summary>
                    <div>
                        <span>${this.msg.inDevelopment}</span>
                    </div>
                </details>
            </div>
        </section>
        <img class="collab_marca" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==" height="140" width="140" alt="collab codes">
         `;
  }
};
CollabStartL4100554 = __decorateClass([
  customElement("collab-start-l4-100554")
], CollabStartL4100554);
export {
  CollabStartL4100554
};
