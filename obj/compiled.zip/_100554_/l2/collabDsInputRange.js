/// <mls fileReference="_100554_/l2/collabDsInputRange.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html, repeat } from "lit";
import { customElement, property } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
function initCollabDSInputRange() {
}
;
let CollabDSInputRange = class extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-ds-input-range-100554 {
  display: grid;
  grid-template-columns: auto 1fr auto auto;
  gap: 8px;
  align-items: center;
}
collab-ds-input-range-100554 input[type="text"] {
  background-color: #f8f9fa;
  width: 100%;
  min-width: 80px;
  border-width: 0px;
  border: none;
  border-radius: 2px 0 0 2px;
  height: 100%;
  color: black;
  font-size: 11.5px;
  padding: 0;
}
collab-ds-input-range-100554 > div {
  display: flex;
  border: 1px solid #b5b4b4;
  border-radius: 5px;
  background-color: #f8f9fa;
}
collab-ds-input-range-100554 > div input[type="text"] {
  border: none;
  padding: 0.1rem 0.1rem;
  outline: none;
  flex: 1;
  width: 100%;
  max-width: 100px;
  min-width: 50px;
  height: 25px;
}
collab-ds-input-range-100554 > div select {
  display: block;
  border: 0px;
  border-top-left-radius: 0px;
  border-bottom-left-radius: 0px;
  min-width: 30px;
  padding: 0.1rem 0.1rem;
  outline: none;
  -webkit-appearance: none;
  font-size: 13px;
  text-align-last: center;
  transition: all 0.3s;
  user-select: none;
  background-color: #f8f9fa;
  background-clip: padding-box;
  border-radius: 0.25rem;
  height: 25px;
}
collab-ds-input-range-100554 > div select:hover {
  background-color: #40404054;
  color: white;
  transition: all 0.3s;
}
collab-ds-input-range-100554 input[type="range"]::-webkit-input-placeholder {
  font-size: 6px;
}
`);
    }
  arraySelect = [];
  useSelect = "true";
  value = "";
  valueInput = "";
  prop = "";
  min = 0;
  max = 100;
  render() {
    return html`
            ${this.renderSelect()}
            
        `;
  }
  renderSelect() {
    return html`
            <div>
                <input type="text" .value="${this.onlyNumber(this.value)}" @input="${this.changeInput}" @wheel=${this.handleWhell}> </input>
                <select @change="${this.changeSelect}" style="${this.useSelect === "false" ? "display:none" : ""}">
                    ${repeat(
      this.arraySelect,
      ((key) => key),
      ((k, index) => {
        return html`<option value="${k}">${k}</option>`;
      })
    )}
                </select>
            </div>
        `;
  }
  async updated(_changedProperties) {
    if (_changedProperties.has("value")) {
      const sel = this.querySelector("select");
      const inpt = this.querySelector("input");
      if (!sel) return;
      sel.value = this.onlyTxt(this.value);
      setTimeout(() => {
        const newPosition = Math.min(this.cursorPosition, inpt.value.length);
        inpt.setSelectionRange(newPosition, newPosition);
      }, 10);
    }
  }
  //---------IMPLEMENTS-------------
  cursorPosition;
  onlyNumber(str) {
    const regexNum = /-?\d+(?:\.\d+)?/;
    const res = str.match(regexNum);
    return res ? res[0] : "";
  }
  onlyTxt(str) {
    const regexStr = /[a-zA-Z]+/;
    const res = str.match(regexStr);
    return res && res[0] ? res[0].replace(".", "") : "px";
  }
  handleWhell(wheelEvent) {
    wheelEvent.preventDefault();
    const input = wheelEvent.target;
    let currentValue = input.value.replace(",", ".");
    if (!currentValue) currentValue = "0";
    let isDecimal = currentValue.includes(".");
    let parsedValue = parseFloat(currentValue);
    let isScrollingUp = wheelEvent.deltaY < 0;
    if (isNaN(parsedValue)) {
      return;
    }
    if (!isDecimal) parsedValue += wheelEvent.deltaY < 0 ? 1 : -1;
    else {
      let decimalPart = currentValue.split(".")[1] || "";
      let decimalLength = decimalPart.length;
      if (decimalLength > 0) {
        let factor = Math.pow(10, decimalLength);
        if (isScrollingUp) parsedValue = (Math.floor(parsedValue * factor) + 1) / factor;
        else parsedValue = (Math.floor(parsedValue * factor) - 1) / factor;
      }
    }
    input.value = parsedValue.toString();
    this.allChange(wheelEvent, "input");
  }
  changeInput(e) {
    const input = e.target;
    let value = input.value.replace(/[^0-9.,]/g, "");
    let dotCount = (value.match(/\./g) || []).length;
    if (dotCount > 1) value = value.replace(/\.(?=[^\.]*$)/, "");
    value = value.replace(",", ".");
    input.value = value;
    if (value.endsWith(".")) return;
    this.cursorPosition = input.selectionStart;
    this.allChange(e, "input");
  }
  changeSelect(e) {
    this.allChange(e, "sel");
  }
  async allChange(e, mode) {
    e.stopPropagation();
    let input = this.querySelector('input[type="text"]');
    let sel = this.querySelector("select");
    if (!input || !sel) return;
    this.value = input.value + sel.value;
    await this.updateComplete;
    input.setSelectionRange(input.value.length, input.value.length);
    this.fireEvents(
      {
        key: this.prop,
        value: input.value + sel.value
      }
    );
  }
  fireEvents(obj) {
    obj.target = this;
    const onChangePropEvento = new CustomEvent("onchange", {
      bubbles: true,
      detail: obj
    });
    this.dispatchEvent(onChangePropEvento);
  }
};
__decorateClass([
  property()
], CollabDSInputRange.prototype, "useSelect", 2);
__decorateClass([
  property()
], CollabDSInputRange.prototype, "value", 2);
__decorateClass([
  property()
], CollabDSInputRange.prototype, "valueInput", 2);
__decorateClass([
  property()
], CollabDSInputRange.prototype, "prop", 2);
CollabDSInputRange = __decorateClass([
  customElement("collab-ds-input-range-100554")
], CollabDSInputRange);
export {
  CollabDSInputRange,
  initCollabDSInputRange
};
