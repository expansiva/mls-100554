const asis = {
  "meta": {
    "fileReference": "_100554_/l2/designSystem.ts",
    "componentType": "other",
    "componentScope": "appFrontEnd",
    "group": "enhancement"
  },
  "references": {
    "imports": [
      {
        "ref": "/_100554_/l2/designSystemBase.js",
        "dependencies": [
          {
            "name": "IDesignSystemTokens",
            "type": "interface"
          }
        ]
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Exports design system tokens",
      "businessCapabilities": [],
      "technicalCapabilities": [
        "Defines color, global, and typography tokens"
      ],
      "implementedFeatures": [
        "Default theme",
        "Natal theme"
      ]
    }
  }
};
export {
  asis
};
