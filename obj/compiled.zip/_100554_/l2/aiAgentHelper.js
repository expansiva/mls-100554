/// <mls fileReference="_100554_/l2/aiAgentHelper.ts" enhancement="_blank" />
import { updateMessage, getMessage, getThreadByName } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { getUserId, createThread } from '/_102025_/l2/collabMessagesHelper.js';
import { loadAgent, executeBeforePrompt } from '/_100554_/l2/aiAgentOrchestration.js';
import { openService } from '/_100554_/l2/libCommom.js';
/**
 * Helper function to collect all steps from a task in a flat array
 */
export const getAllSteps = (firstStep) => {
    if (!firstStep || firstStep.length < 1) {
        return [];
    }
    const allSteps = [];
    const queue = [...firstStep];
    // BFS approach to collect all steps
    while (queue.length > 0) {
        const currentStep = queue.shift();
        allSteps.push(currentStep);
        // Add nextSteps to queue if they exist
        if (currentStep.nextSteps) {
            queue.push(...currentStep.nextSteps);
        }
        // Add steps from interaction.payload if they exist
        if (currentStep.interaction?.payload) {
            queue.push(...currentStep.interaction.payload);
        }
    }
    return allSteps;
};
export const getAgentStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.find((step) => step.type === 'agent' && step.agentName === agentName);
    return agentSteps || null;
};
export const getAgentsStepByAgentName = (task, agentName, status) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent' && step.agentName === agentName);
    if (!status)
        return agentSteps || [];
    return agentSteps.filter(step => step.status === status);
};
export const getStepById = (task, stepId) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.stepId === stepId) || null;
};
export const getNextPendentStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    return allSteps.find(step => step.status === 'pending') || null;
};
export const getNextResultStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'result');
    return agentSteps.find(step => step.status === 'completed') || null;
};
export const getNextClarificationStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'clarification');
    return agentSteps.find(step => step.status === 'pending') || null;
};
export const getNextPendingStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'pending' && step.agentName === agentName) || null;
};
export const getNextFlexiblePendingStep = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'flexible');
    return agentSteps.find(step => step.status === 'pending') || null;
};
export const getNextInProgressStepByAgentName = (task, agentName) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps.find(step => step.status === 'in_progress' && step.agentName === agentName) || null;
};
export const getRootAgent = (task) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    const agentSteps = allSteps.filter((step) => step.type === 'agent');
    return agentSteps[0] || null;
};
export const getInteractionStepId = (task, stepId) => {
    // nextSteps []
    // | interaction
    // | | nextsSteps []
    // ...
    // this routine find the parent interaction stepId
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    if (!allSteps)
        return null;
    for (const step of allSteps) {
        if (!step.interaction || !step.interaction.payload)
            continue;
        if (step.interaction.payload.length < 1)
            continue;
        if (step.interaction.payload.find(s => s.stepId === stepId))
            return step.stepId;
    }
    return null;
};
export const calculateStepsStatistics = (steps, removeFirstStep) => {
    const allSteps = getAllSteps(steps);
    if (removeFirstStep)
        allSteps.shift();
    return {
        agents: allSteps.filter(step => step.type === 'agent').length,
        tools: allSteps.filter(step => step.type === 'tool').length,
        clarification: allSteps.filter(step => step.type === 'clarification').length,
        result: allSteps.filter(step => step.type === 'result').length,
        flexible: allSteps.filter(step => step.type === 'flexible').length,
        totalCost: allSteps.reduce((sum, step) => sum + (step.interaction?.cost || 0), 0),
        totalSteps: allSteps.length
    };
};
export const calculateStepsByFilter = (task, filter) => {
    const allSteps = getAllSteps(task.iaCompressed?.nextSteps);
    // example: calculateStepsByFilter(task, { toolName: "abc "})
    let result = 0;
    for (const step of allSteps) {
        let allPropertiesMatch = true;
        for (const [key, value] of Object.entries(filter)) {
            const value2 = step[key];
            if (value2 !== value) {
                allPropertiesMatch = false;
                break; // exit for
            }
        }
        if (allPropertiesMatch)
            result += 1;
    }
    return result;
};
export const getTemporaryContext = (threadId, userId, prompt) => {
    // create temporary context
    const context = {
        task: undefined,
        message: {
            threadId: threadId,
            orderAt: "",
            createAt: "",
            senderId: userId,
            content: prompt.trim(),
        },
        isTest: false
    };
    return context;
};
export async function appendLongTermMemory(context, longTermMemory) {
    if (!context.task)
        throw new Error('[appendLongTermMemory] invalid task');
    const messageId = context.task.messageid_created;
    if (!messageId)
        throw new Error("[appendLongTermMemory] Invalid messageId");
    try {
        const ret = await mls.api.msgAppendLongTermMemory({
            longTermMemory,
            messageId,
            taskId: context.task.PK,
            userId: getUserId() || context.message.senderId,
        });
        if (!ret || ret.statusCode !== 200)
            throw new Error("error on AI appendLongTermMemory , stoped");
        return ret.task;
    }
    catch (err) {
        throw new Error('[appendLongTermMemory] ' + err.message);
    }
}
export const updateStepStatus = async (context, stepId, status, traceMsg) => {
    if (!context.task)
        throw new Error("[updateStepStatus] , invalid task");
    const args = {
        "action": "updateStepStatus",
        "userId": getUserId() || context.task.owner || '',
        "messageId": context.task.messageid_created || '',
        "taskId": context.task.PK,
        stepId,
        status,
        traceMsg
    };
    try {
        const ret = await mls.api.msgUpdateStepStatus(args);
        if (!ret || ret.statusCode !== 200)
            throw new Error("error on AI update status , stoped");
        if (ret.message) {
            context.message = ret.message;
            const message = await getMessage(`${ret.message.threadId}/${ret.message.createAt}`);
            if (message)
                await updateMessage(ret.message);
        }
        context.task = ret.task;
        return context;
    }
    catch (err) {
        throw new Error("[updateStepStatus] " + err.message);
    }
};
export const updateTaskTitle = async (task, newTitle) => {
    const args = {
        userId: getUserId() || task.owner,
        newTitle,
        taskId: task.PK,
        messageId: task.messageid_created || '',
        action: 'updateTaskTitle',
    };
    try {
        const ret = await mls.api.msgUpdateTaskTitle(args);
        if (!ret || ret.statusCode !== 200)
            throw new Error("[updateTaskTitle] , stoped");
        return ret.task;
    }
    catch (err) {
        throw new Error("[updateTaskTitle] " + err.message);
    }
};
export async function appendPromptToInteraction(userId, messageId, taskId, interactionStepId, inputAI, stepdIdToChangeStatus, newStatus) {
    if (!messageId)
        throw new Error("Message ID is undefined");
    if (!taskId)
        throw new Error("Task ID is undefined");
    const args = {
        action: "appendPromptToInteraction",
        userId,
        messageId,
        taskId,
        interactionStepId,
        inputAI,
        stepdIdToChangeStatus,
        newStatus
    };
    const ret = await mls.api.msgAppendPromptToInteraction(args);
    if (!ret || ret.statusCode !== 200)
        throw new Error("error on AI update status , stoped");
    return ret.task;
}
export function notifyMessageSendChange(context) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('message-send', {
        detail: { context },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyTaskChange(context, oldContextCreateAt) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-change', {
        detail: { context, oldContextCreateAt },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyTaskCompleted(context, result) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-completed', {
        detail: { context, result },
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadChange(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-change', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function notifyThreadCreate(thread) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('thread-create', {
        detail: thread,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function dispatchDetailsTaskClose(taskId) {
    const scopeWindow = window?.top ? window.top : window;
    const event = new CustomEvent('task-details-close', {
        detail: taskId,
        bubbles: true,
        composed: true
    });
    scopeWindow.dispatchEvent(event);
}
export function getTotalCost(task) {
    let tot = 0;
    const nextSteps = task.iaCompressed?.nextSteps;
    if (!nextSteps || nextSteps.length === 0)
        return "$ 0.01"; // garante saída mínima
    const sumCosts = (payload) => {
        payload.forEach((pay) => {
            const { interaction, nextSteps } = pay;
            if (interaction) {
                tot += interaction.cost ? interaction.cost : 0;
                if (interaction.payload)
                    sumCosts(interaction.payload);
            }
            if (nextSteps) {
                nextSteps.forEach((next) => sumCosts([next]));
            }
        });
    };
    nextSteps.forEach((step) => sumCosts([step]));
    const rounded = Math.ceil(tot * 100) / 100;
    return `${rounded.toFixed(2)}`;
}
export function getNextStepIdAvaliable(task) {
    let nextStepId = 0;
    const nextSteps = task.iaCompressed?.nextSteps;
    if (!nextSteps || nextSteps.length === 0)
        return nextStepId + 1;
    const findNextStepId = (payload) => {
        payload.forEach((pay) => {
            const { interaction, nextSteps, stepId } = pay;
            if (stepId > nextStepId)
                nextStepId = stepId + 1;
            if (interaction) {
                if (interaction.payload)
                    findNextStepId(interaction.payload);
            }
            if (nextSteps) {
                nextSteps.forEach((next) => {
                    if (next.stepId > nextStepId)
                        nextStepId = next.stepId + 1;
                    findNextStepId([next]);
                });
            }
        });
    };
    nextSteps.forEach((step) => {
        if (step.stepId > nextStepId)
            nextStepId = step.stepId + 1;
        findNextStepId([step]);
    });
    return nextStepId;
}
export async function executeAgentByFile(agentName, prompt, file, openMsg = false) {
    const pageName = file.folder ? `_${file.project}_${file.folder}/${file.shortName}` : `${file.project}_${file.shortName}`;
    let thread = await getThreadByName(pageName);
    if (!thread) {
        thread = await createThread(pageName, [], 'company');
    }
    const userId = getUserId();
    if (!userId)
        return;
    const threadId = thread?.threadId;
    if (!threadId)
        throw new Error('[executeAgentByFile] Cannot find thread');
    const agent = await loadAgent(agentName);
    if (!agent)
        throw new Error('[executeAgentByFile] Invalid Agent' + agentName);
    const context = getTemporaryContext(threadId, userId, prompt);
    if (openMsg) {
        mls.events.fire([mls.actualLevel], 'collabMessages', JSON.stringify({ threadId: threadId, taskId: 'last', type: 'thread-open' }));
    }
    executeBeforePrompt(agent, context);
}
export async function openCollabMessage(file) {
    const pageName = file.folder ? `_${file.project}_${file.folder}/${file.shortName}` : `${file.project}_${file.shortName}`;
    let thread = await getThreadByName(pageName);
    if (!thread) {
        openService('_100554_serviceCollabMessages', 'left', mls.actualLevel);
        return;
    }
    const threadId = thread?.threadId;
    if (!threadId) {
        openService('_100554_serviceCollabMessages', 'left', mls.actualLevel);
        return;
    }
    mls.events.fire([mls.actualLevel], 'collabMessages', JSON.stringify({ threadId: threadId, type: 'thread-open' }));
}
export function formatTimestamp(timestamp) {
    if (!timestamp || timestamp.length < 14) {
        return;
    }
    const year = timestamp.slice(0, 4);
    const month = timestamp.slice(4, 6);
    const day = timestamp.slice(6, 8);
    const hour = timestamp.slice(8, 10);
    const minute = timestamp.slice(10, 12);
    const second = timestamp.slice(12, 14);
    const utcDate = new Date(Date.UTC(parseInt(year), parseInt(month) - 1, parseInt(day), parseInt(hour), parseInt(minute), parseInt(second)));
    const localYear = utcDate.getFullYear();
    const localMonth = (utcDate.getMonth() + 1).toString().padStart(2, '0');
    const localDay = utcDate.getDate().toString().padStart(2, '0');
    const localHour = utcDate.getHours().toString().padStart(2, '0');
    const localMinute = utcDate.getMinutes().toString().padStart(2, '0');
    const localSecond = utcDate.getSeconds().toString().padStart(2, '0');
    const date = `${localYear}-${localMonth}-${localDay}`;
    const time = `${localHour}:${localMinute}:${localSecond}`;
    const timeShort = `${localHour}:${localMinute}`;
    const dateFull = `${date} ${time}`;
    return { dateFull, date, time, timeShort };
}
