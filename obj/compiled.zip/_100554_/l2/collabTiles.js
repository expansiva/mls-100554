/// <mls fileReference="_100554_/l2/collabTiles.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { customElement, property, query } from 'lit/decorators.js';
import { getConfigProject, updateConfigProjectPlugins } from '/_102027_/l2/libProjectConfig.js';
import '/_100554_/l2/collabTilesItem.js';
import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js'; //https://github.com/SortableJS/Sortable/blob/master/Sortable.js
let CollabTiles = class CollabTiles extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tiles-100554 {
  background-color: #bfc0edab;
  display: block;
  padding: 10px;
}
collab-tiles-100554 .collabtilesconfigiten {
  background: none;
  border: none;
  box-shadow: none;
  cursor: pointer;
}
collab-tiles-100554 .collabtilesconfigiten:hover {
  background: none;
  border: none;
  box-shadow: none;
  fill: #7d00ff;
  color: #7d00ff;
}
collab-tiles-100554 collab-tiles {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
  grid-auto-rows: 100px;
  gap: 10px;
}
collab-tiles-100554 collab-tiles-item-100554 {
  background-color: #fff;
  border-radius: 8px;
  padding: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 1.2rem;
  text-align: center;
}
collab-tiles-100554 break-800 collab-tiles {
  display: flex;
  flex-direction: column;
}
collab-tiles-100554 break-800 collab-tiles-item-100554 {
  grid-area: none !important;
  height: 300px;
}
`);
        this.config = 'close';
        this.tilesItens = [];
        this.text = '';
        this.example = '';
        this.oldJson = '';
    }
    //---------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    render() {
        return html `
            ${this.renderConfigItens()}
            <collab-tiles>
                ${repeat(this.tilesItens, ((key, idx) => key.plugin), ((item, index) => {
            return this.renderItem(item, index);
        }))}
            </collab-tiles>
        `;
    }
    renderItem(item, idx) {
        return html `
        <collab-tiles-item-100554 position="${item.position}" index="${idx}" plugin="${item.plugin}" .myinfo=${item}></collab-tiles-item-100554>
        `;
    }
    renderConfigItens() {
        if (this.config === 'close')
            return this.renderConfigItensOpen();
        return this.renderConfigItensClose();
    }
    renderConfigItensOpen() {
        return html `
            <div style="display:flex; justify-content: end;">
                <button class="collabtilesconfigiten" style="margin-right:10px" title="config" @click="${this.open}">
                    <svg xmlns="http://www.w3.org/2000/svg" style="width:15px" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M362.7 19.3L314.3 67.7 444.3 197.7l48.4-48.4c25-25 25-65.5 0-90.5L453.3 19.3c-25-25-65.5-25-90.5 0zm-71 71L58.6 323.5c-10.4 10.4-18 23.3-22.2 37.4L1 481.2C-1.5 489.7 .8 498.8 7 505s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L421.7 220.3 291.7 90.3z"/></svg>
                    
                </button>
            <div>
        `;
    }
    renderConfigItensClose() {
        return html `
            <div style="display:flex; justify-content: end;">
                <button class="collabtilesconfigiten" style="margin-right:10px" title="save" @click="${this.close}">
                    <svg xmlns="http://www.w3.org/2000/svg" style="width:15px" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM369 209c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-111 111-47-47c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l64 64c9.4 9.4 24.6 9.4 33.9 0L369 209z"/></svg>
                    Save
                </button>
                <button class="collabtilesconfigiten" style="margin-right:10px" title="cancel" @click="${this.onlyclose}">
                    <svg xmlns="http://www.w3.org/2000/svg" style="width:15px" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 48a208 208 0 1 1 0 416 208 208 0 1 1 0-416zm0 464A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM175 175c-9.4 9.4-9.4 24.6 0 33.9l47 47-47 47c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l47-47 47 47c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-47-47 47-47c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-47 47-47-47c-9.4-9.4-24.6-9.4-33.9 0z"/></svg>
                    Cancel
                </button>
                
            </div>
            
        `;
    }
    renderItemConfig(item, index) {
        return html `
        <li>
            <div>${item.title}: <div>
            <input .value="${item.position}" .index=${index} @blur="${this.fireChange}"/>
        </li>
        `;
    }
    setDragAndDrop(active) {
        const all = this.querySelectorAll('collab-tiles-item-100554');
        if (!active) {
            Array.from(all).forEach((e) => {
                e.removeAttribute('edit');
            });
            if (this.sort)
                this.sort.destroy();
            return;
        }
        if (window['Sortable']) {
            this.sort = window['Sortable'].create(this.collabTiles, {
                group: "sorting",
                sort: active,
                onUpdate: function (evt) { },
            });
        }
        Array.from(all).forEach((e) => {
            e.setAttribute('edit', 'true');
        });
    }
    open() {
        this.oldJson = JSON.stringify(this.tilesItens);
        this.config = 'open';
        this.setDragAndDrop(true);
        if (mls.actualLevel !== 2)
            mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify({
                shortName: '',
                project: '',
                htmlText: '<div></div>'
            }), 0);
    }
    async close() {
        await this.verifyNeedSaveAndSave();
        this.config = 'close';
        this.setDragAndDrop(false);
    }
    onlyclose() {
        this.tilesItens = JSON.parse(this.oldJson);
        this.config = 'close';
        this.setDragAndDrop(false);
    }
    async verifyNeedSaveAndSave() {
        const all = this.querySelectorAll('collab-tiles-item-100554');
        const actualTiles = [];
        Array.from(all).forEach((e, index) => {
            const tl = e && e.myinfo ? e.myinfo : undefined;
            if (!tl)
                return;
            const idx = e.getAttribute('index') ? +e.getAttribute('index') : 0;
            if (idx !== index) {
                tl.index = (index + 1).toString();
            }
            actualTiles.push(tl);
        });
        const actualJson = JSON.stringify(actualTiles);
        const need = actualJson !== this.oldJson;
        if (need) {
            await this.changeConfig(actualTiles);
            actualTiles.sort((a, b) => {
                return Number(a.index) - Number(b.index);
            });
            this.tilesItens = actualTiles;
        }
        return;
    }
    async changeConfig(tiles) {
        const prj = mls.actualProject;
        if (!prj)
            return;
        const config = await getConfigProject(prj);
        if (!config)
            return;
        tiles.forEach((t) => {
            this.setInfoPlugin(config, t);
        });
        await updateConfigProjectPlugins(prj, config.plugins);
    }
    setInfoPlugin(config, tile) {
        if (!config)
            return;
        const dash = "l6Dashboard";
        const ex = "Examples " + this.example;
        const pos = 'tile ' + tile.position + ' ' + tile.index;
        const plugin = config.plugins;
        if (!plugin[tile.widgetConfig]) {
            plugin[tile.widgetConfig] = {
                [tile.plugin]: {
                    "l6Dashboard": {
                        [ex]: pos
                    },
                    "enabled": tile.enabled
                }
            };
        }
        else if (plugin[tile.widgetConfig] && !plugin[tile.widgetConfig][tile.plugin]) {
            plugin[tile.widgetConfig][tile.plugin] = {
                "l6Dashboard": {
                    [ex]: pos
                },
                "enabled": tile.enabled
            };
        }
        else if (plugin[tile.widgetConfig] && plugin[tile.widgetConfig][tile.plugin] && !plugin[tile.widgetConfig][tile.plugin][dash]) {
            plugin[tile.widgetConfig][tile.plugin][dash] = {
                [ex]: pos
            };
            plugin[tile.widgetConfig][tile.plugin].enabled = tile.enabled;
        }
        else if (plugin[tile.widgetConfig] && plugin[tile.widgetConfig][tile.plugin] && plugin[tile.widgetConfig][tile.plugin][dash]) {
            plugin[tile.widgetConfig][tile.plugin][dash][ex] = pos;
            plugin[tile.widgetConfig][tile.plugin].enabled = tile.enabled;
        }
    }
    fireChange(e) {
        const el = e.target;
        const index = el.index;
        if (this.tilesItens[index])
            this.tilesItens[index].position = el.value;
        this.tilesItens = Object.assign([], this.tilesItens);
    }
};
__decorate([
    property({ type: String, reflect: true })
], CollabTiles.prototype, "config", void 0);
__decorate([
    property({ type: [], reflect: true })
], CollabTiles.prototype, "tilesItens", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabTiles.prototype, "text", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabTiles.prototype, "example", void 0);
__decorate([
    query('collab-tiles')
], CollabTiles.prototype, "collabTiles", void 0);
CollabTiles = __decorate([
    customElement('collab-tiles-100554')
], CollabTiles);
export { CollabTiles };
