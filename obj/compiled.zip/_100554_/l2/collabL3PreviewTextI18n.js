/// <mls fileReference="_100554_/l2/collabL3PreviewTextI18n.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { propertyDataSource } from "/_100554_/l2/collabDecorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
let CollabL3PreviewTextI18n = class extends StateLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-l3-preview-text-i18n-100554 {
  outline: none;
}
`);
    this.findby = "";
    this.timeFireEvent = 0;
  }
  render() {
    this.onclick = this.handleClick.bind(this);
    this.onblur = this.handleChange.bind(this);
    this.setAttribute("contenteditable", "true");
    return html`${this.value}`;
  }
  handleChange(event) {
    this.value = this.innerText;
    event.stopPropagation();
    event.preventDefault();
  }
  handleClick(event) {
    event.stopPropagation();
    event.preventDefault();
    this.onSelect();
    this.fireEvent();
  }
  fireEvent() {
    clearTimeout(this.timeFireEvent);
    this.timeFireEvent = setTimeout(() => {
      const el = this.closest("[id]");
      if (!el) return;
      const param = {
        "position": "right",
        "action": "select",
        "id": el.id
      };
      mls.events.fire(3, "L3EditEvents", JSON.stringify(param));
    }, 500);
  }
  onSelect() {
    const elActive = document.querySelector("*[clb_mode]");
    if (elActive && elActive.id === this.findby) return;
    const el = document.querySelector("#" + this.findby);
    if (el) el.setAttribute("clb_mode", "edit");
    if (elActive) elActive.removeAttribute("clb_mode");
  }
};
__decorateClass([
  property()
], CollabL3PreviewTextI18n.prototype, "findby", 2);
__decorateClass([
  propertyDataSource({ type: String })
], CollabL3PreviewTextI18n.prototype, "value", 2);
CollabL3PreviewTextI18n = __decorateClass([
  customElement("collab-l3-preview-text-i18n-100554")
], CollabL3PreviewTextI18n);
export {
  CollabL3PreviewTextI18n
};
