/// <mls fileReference="_100554_/l2/collabConsoleL1.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
let CollabConsoleL1100554 = class extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-console-l1-100554 {
  display: block;
  height: 100%;
}
collab-console-l1-100554 .console {
  height: 100%;
  background: #000;
  border-radius: 5px;
  padding: 10px;
  display: flex;
  flex-direction: column;
}
collab-console-l1-100554 .output {
  flex: 1;
  overflow-y: auto;
  padding: 5px;
}
collab-console-l1-100554 .output div {
  color: #d2d2d2;
}
collab-console-l1-100554 .header {
  display: flex;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid #444;
  padding: 5px;
  color: #0f0;
}
collab-console-l1-100554 button {
  background-color: #3c3434;
  border: 1px solid #4c4747;
  color: #0f0;
  cursor: pointer;
}
collab-console-l1-100554 .input-area {
  display: flex;
  align-items: center;
  border-top: 1px solid #444;
  padding: 5px;
}
collab-console-l1-100554 .prompt {
  color: #0f0;
  margin-right: 5px;
}
collab-console-l1-100554 .input-box {
  flex: 1;
  background: transparent;
  border: none;
  outline: none;
  color: #0f0;
  font-size: 16px;
}
`);
    }
  output;
  inputBox;
  file;
  firstUpdated() {
    this.configLog();
  }
  //-----COMPOENENT-----------
  render() {
    return html`
        <div class="console">  
            <div class="header">Collab Server: ${this.file}</div>
            <div class="output" id="output"></div>
            <div class="input-area">
                <span class="prompt">$</span>
                <input type="text" autocomplete="off" @keydown="${this.onKeyDown}" class="input-box" id="inputBox" autofocus>
                <button @click="${this.execute}">&gt;</button>
            </div>
        </div>
        `;
  }
  //-------IMPLEMENTS----------
  onKeyDown(event) {
    if (event.key === "Enter") this.execute();
  }
  async execute() {
    if (!this.inputBox || !this.output) return;
    let command = this.inputBox.value.trim();
    this.inputBox.value = "";
    if (!command) return;
    this.output.innerHTML += `<div><span class="prompt">$</span> ${command}</div>`;
    try {
      if (!window.consoleScope) window.consoleScope = {};
      let result;
      const runAsync = async (code, scope) => {
        const keys = Object.keys(scope);
        const values = Object.values(scope);
        const fn = new Function(...keys, `
                return (async () => {
                    return (${code});
                })();
            `);
        return fn(...values);
      };
      const isDeclaration = /^(let|const|var)\s+/.test(command);
      if (isDeclaration) {
        const match = command.match(/^(?:let|const|var)\s+([a-zA-Z_$][a-zA-Z0-9_$]*)\s*=\s*(.*)$/);
        if (!match) throw new Error("Declara\xE7\xE3o inv\xE1lida");
        const varName = match[1];
        const expr = match[2];
        result = await runAsync(expr, window.consoleScope);
        window.consoleScope[varName] = result;
      } else {
        result = await runAsync(command, window.consoleScope);
      }
      if (typeof result === "object") result = JSON.stringify(result);
      if (result !== void 0)
        this.output.innerHTML += `<div><span class="prompt">&lt;</span> ${result}</div>`;
    } catch (error) {
      this.output.innerHTML += `<div style="color: red;">Erro: ${error.message}</div>`;
    }
    this.output.scrollTop = this.output.scrollHeight;
  }
  configLog() {
    const originalLog = console.log;
    const originalInfo = console.info;
    const writeToConsole = (...args) => {
      if (!this.inputBox || !this.output) return;
      const message = args.map((arg) => typeof arg === "object" ? JSON.stringify(arg) : String(arg)).join(" ");
      this.output.innerHTML += `<div><span class="prompt">&lt;</span> ${message}</div>`;
      this.output.scrollTop = this.output.scrollHeight;
    };
    console.log = (...args) => {
      writeToConsole(...args);
      originalLog.apply(console, args);
    };
    console.info = (...args) => {
      writeToConsole(...args);
      originalInfo.apply(console, args);
    };
  }
};
__decorateClass([
  query("#output")
], CollabConsoleL1100554.prototype, "output", 2);
__decorateClass([
  query("#inputBox")
], CollabConsoleL1100554.prototype, "inputBox", 2);
__decorateClass([
  property()
], CollabConsoleL1100554.prototype, "file", 2);
CollabConsoleL1100554 = __decorateClass([
  customElement("collab-console-l1-100554")
], CollabConsoleL1100554);
export {
  CollabConsoleL1100554
};
