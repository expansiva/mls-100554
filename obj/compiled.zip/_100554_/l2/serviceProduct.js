/// <mls fileReference="_100554_/l2/serviceProduct.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, queryAll } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
/// **collab_i18n_start**
const message_pt = {
    updateListVerify: "atualizar lista/verificar",
    update: "atualizar",
    addNewFile: "adicionar novo arquivo",
    filter: "Filtrar",
    localProject: "Todos",
    projectFolder: "Pasta",
    totalFiles: "arquivos totais",
    filesWithErrors: "arquivos com erros",
    filesInLocalStorage: "arquivos no armazenamento local",
    filesChangedOnTheServer: "arquivos alterados no servidor",
    history: "Histórico",
    undo: "desfazer",
    clone: "clonar",
    rename: "renomear",
    delete: "excluir",
    security: 'segurança',
};
const message_en = {
    updateListVerify: 'update list/ verify',
    update: 'update',
    addNewFile: 'add new file',
    filter: 'Filter',
    projectFolder: "Folder",
    localProject: 'All',
    totalFiles: 'total files',
    filesWithErrors: 'files with errors',
    filesInLocalStorage: 'file in local storage',
    filesChangedOnTheServer: 'files changed on the server',
    history: 'History',
    undo: 'undo',
    clone: 'clone',
    rename: 'rename',
    delete: "delete",
    security: 'security',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceProduct = class ServiceProduct extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-product-100554 {
  overflow-y: auto;
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-20);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
  /*.groupHiddenList {
        border-radius: 4px;
        padding: .3rem;
        transition: all 0.5s;
        cursor: pointer;
        display: inline-block; //flex!important;
        z-index: 9;
        height: .7rem;
        box-sizing: initial;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");
        background-repeat: no-repeat;
        background-position-y: center;

        &::before {
            content: ' ';
            width: 23px;
            height: 19px;
            position: absolute;
            left: 2px;
        }

        .mls-gpbtnslider-item {
            display: none;
            transition: 0.5s;
            margin-left: 1rem;
            z-index: 10;

            &:hover {
                color: var(--active-color);
            }
        }

        &.activegpbtnslider {
            padding-right: 24px;
            padding-left: 8px;
        }

        &.activegpbtnslider .mls-gpbtnslider-item {
            display: inherit;
            text-align: center;
            float: left;
        }
    }*/
}
service-product-100554 .contentServiceList {
  padding: 1rem;
  position: relative;
  background-color: var(--bg-primary-color);
}
service-product-100554.breakContent .groupInfo,
service-product-100554.breakContent .groupFilter {
  flex-direction: column;
  align-items: baseline !important;
}
service-product-100554.breakContent .groupFilter input[type="text"] {
  width: 90% !important;
}
service-product-100554.breakContent .toolbar {
  flex-direction: column;
  align-items: stretch;
}
service-product-100554.breakContent .toolbar__left,
service-product-100554.breakContent .toolbar__center,
service-product-100554.breakContent .toolbar__right {
  width: 100%;
  justify-content: flex-start;
}
service-product-100554.breakContent .toolbar__search {
  width: 100%;
}
service-product-100554.breakContent .toolbar__center {
  justify-content: flex-start;
  flex-wrap: wrap;
}
service-product-100554 .groupHeader {
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 0.1rem;
  border-bottom: 1px solid #e0e0e0;
  margin-bottom: 1rem;
}
service-product-100554 .groupHeader .toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0rem 0rem;
  background-color: var(--bg-primary-color);
  gap: 1rem;
}
service-product-100554 .groupHeader .toolbar__left {
  flex: 1;
  display: flex;
}
service-product-100554 .groupHeader .toolbar__search {
  flex: 1;
  padding: 0.4rem 0.8rem;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 0.9rem;
}
service-product-100554 .groupHeader .toolbar__search:focus {
  outline: none;
  box-shadow: 0 0 0 2px rgba(0, 119, 255, 0.2);
}
service-product-100554 .groupHeader .toolbar__center {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}
service-product-100554 .groupHeader .toolbar__radio-group {
  display: flex;
  gap: 0.3rem;
}
service-product-100554 .groupHeader .toolbar__radio-group label {
  position: relative;
  /*input[type="radio"]:checked+span {
                        background-color: var(--grey-color-dark);
                        color: var(--text-primary-color);
                        border-color: var(--bg-secondary-color-darker-disabled);
                        font-weight: 600;
                    }*/
}
service-product-100554 .groupHeader .toolbar__radio-group label input[type="radio"] {
  display: none;
}
service-product-100554 .groupHeader .toolbar__radio-group label span {
  display: inline-block;
  padding: 0.3rem 0.6rem;
  border: 1px solid var(--grey-color);
  border-radius: 4px;
  background: var(--bg-primary-color);
  cursor: pointer;
  font-size: 0.8rem;
  line-height: 1;
  transition: all 0.2s ease;
}
service-product-100554 .groupHeader .toolbar__radio-group label span svg {
  fill: var(--text-primary-color);
}
service-product-100554 .groupHeader .toolbar__radio-group label span:hover {
  background-color: var(--grey-color);
}
service-product-100554 .groupHeader .toolbar__radio-group label span.checked {
  background-color: var(--grey-color-dark);
  color: var(--text-primary-color);
  border-color: var(--bg-secondary-color-darker-disabled);
  font-weight: 600;
}
service-product-100554 .groupHeader .toolbar__right {
  display: flex;
  align-items: center;
}
service-product-100554 .groupHeader .toolbar__add-button {
  padding: 0.4rem 0.6rem;
  font-size: 0.9rem;
  border: none;
  border-radius: 6px;
  background-color: var(--grey-color-darker);
  color: var(--text-primary-color);
  cursor: pointer;
  transition: background-color 0.2s ease;
}
service-product-100554 .groupHeader .toolbar__add-button:hover {
  background-color: var(--bg-primary-color-disabled);
}
@media (max-width: 600px) {
  service-product-100554 .groupHeader .toolbar {
    flex-direction: column;
    align-items: stretch;
  }
  service-product-100554 .groupHeader .toolbar__left,
  service-product-100554 .groupHeader .toolbar__center,
  service-product-100554 .groupHeader .toolbar__right {
    width: 100%;
    justify-content: flex-start;
  }
  service-product-100554 .groupHeader .toolbar__search {
    width: 100%;
  }
  service-product-100554 .groupHeader .toolbar__center {
    justify-content: flex-start;
    flex-wrap: wrap;
  }
}
service-product-100554 .groupHeader .groupInfo {
  display: flex;
  justify-content: start;
  align-items: center;
  gap: 0.4rem;
  margin-bottom: 1rem;
  color: var(--text-primary-color);
}
service-product-100554 .groupHeader .groupInfo span {
  font-size: 0.78rem;
  display: flex !important;
  justify-content: center;
  align-items: center !important;
  gap: 3px !important;
}
service-product-100554 .groupHiddenListIcon {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 128 512'><path d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>");
  background-repeat: no-repeat;
  background-position-y: center;
  width: 22px;
  height: 21px;
  display: block;
  transition: transform 200ms;
  position: relative;
}
service-product-100554 .groupHiddenList {
  padding: 0.3rem;
  transition: all 0.5s;
  cursor: pointer;
  display: none;
  z-index: 9;
  border-top: 1px solid #c4c4c4;
}
service-product-100554 .groupHiddenList .mls-gpbtnslider-item {
  display: block;
  transition: 0.5s;
  z-index: 10;
  color: #444343;
  border-bottom: 1px solid #c7c4c4;
  padding: 0.2rem;
  font-size: 13px;
}
service-product-100554 .groupHiddenList .mls-gpbtnslider-item:hover {
  background: #2f2f2f17;
  color: var(--active-color);
}
service-product-100554 .groupHiddenList.activegpbtnslider {
  display: flex;
  flex-direction: column;
}
service-product-100554 info-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: width 2s;
}
service-product-100554 ul {
  display: flex;
  -ms-flex-direction: column;
  flex-direction: column;
  padding-left: 0;
  margin: 0px;
  list-style: none;
}
service-product-100554 ul li.selected {
  background: var(--grey-color-dark);
}
service-product-100554 ul li {
  padding: 0.5rem !important;
  cursor: pointer;
  position: relative;
  font-size: 0.95rem;
  z-index: 1;
}
service-product-100554 ul li .fileDeleted {
  text-decoration: line-through;
  color: var(--error-color);
}
service-product-100554 ul li .elContent {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  user-select: none;
}
service-product-100554 ul li .elContent .spanFileName {
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
service-product-100554 ul li .elContentAux {
  display: flex;
  margin-top: 1.5rem;
  flex-direction: column;
}
service-product-100554 ul li .elContentAux .elContentAux2 {
  display: flex;
  gap: 0.5rem;
}
service-product-100554 ul li .elContentAux input {
  border: 1px solid var(--grey-color);
  border-radius: 5px;
  padding-left: 0.3rem;
  font-size: 13px;
  outline: none;
  height: 20px;
  z-index: 10;
}
service-product-100554 ul li .elContentAux button {
  border: none;
  border-radius: 5px;
  width: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
  cursor: pointer;
  background: none;
}
service-product-100554 ul li .elContentAux button:hover {
  filter: sepia(100%) hue-rotate(190deg) saturate(500%);
}
service-product-100554 ul li .elContentAux .spanPrj {
  position: relative;
}
service-product-100554 ul li .elContentAux .spanPrj::before {
  content: 'New project:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
service-product-100554 ul li .elContentAux .spanName {
  position: relative;
}
service-product-100554 ul li .elContentAux .spanName::before {
  content: 'New short name:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
service-product-100554 ul li::after {
  content: ' ';
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z' fill='rgb(66,65,65,1)'/></svg>");
  background-repeat: no-repeat;
  width: 12px;
  height: 12px;
  background-position-y: center;
  position: absolute;
  right: 7px;
  top: 10px;
}
service-product-100554 ul li.headerTitle {
  padding: 0.3em 1em;
  list-style-type: none;
  background: #f7f7f7;
  color: #000;
  font-weight: 600;
  cursor: default;
  font-size: 1rem !important;
}
service-product-100554 ul li.headerTitle::after {
  content: "";
  background: none;
}
service-product-100554 ul li:hover:not(.headerTitle) {
  background: var(--grey-color-dark);
}
`);
        this.refresh = '';
        this.msg = messages['en'];
        this.levelFiles = 2;
        this.project = -1; // -1: noFilter; 0: all project
        this.filterProject = -1; // -1: noFilter; 0: all project
        this.projectLabel = '1';
        this.errorAux = '';
        this.files = [];
        this.activeTab = 'ITasks';
        this.info = {
            tot: 0,
            version: 0,
            storage: 0,
            error: 0,
        };
        //----------SERVICE--------------------
        this.details = {
            icon: '&#xf6ff',
            state: 'foreground',
            position: 'left',
            tooltip: 'Product',
            visible: true,
            widget: '_100554_serviceProduct',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.menu = {
            title: '',
            main: {
                opAboutThis: 'About this content',
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [
                    { text: 'MindMap', icon: 'f5dc' },
                ]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.changeListTimeout = 0;
        this.inFilter = false;
        this.timeFilterChange = 0;
        this.dataDifBaseTemplate = {};
    }
    async prepare() {
        this.init();
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        this.activeTab = ISceneries[index];
    }
    onServiceClick(visible, reinit, el) {
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'nothing selected';
        switch (this.activeTab) {
            case 'IMindMap':
                name = 'widget-mind-map-l4-100554';
                break;
            default:
                name = 'nothing selected';
        }
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
		

        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    //--------EVENTS----------
    onlevelChange(ev) {
        this.changeList();
        this.showLoading(false);
    }
    //---------COMPONENT-------------
    connectedCallback() {
        super.connectedCallback();
        this.initObserverResize();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
    }
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.renderModeList();
    }
    renderModeList() {
        return html `
            <div class="contentServiceList scroll-custom">
                ${this.renderHeader()}
                <ul>
                    ${this.renderList()}
                </ul>
            </div>
        `;
    }
    renderHeader() {
        let auxV = '';
        let auxE = '';
        let auxS = '';
        if (this.info.version > 0) {
            auxV = `<b>[${this.info.version}]</b> <span class="fa fa-unbalanced"></span> <b>${this.msg.filesChangedOnTheServer}, </b>`;
        }
        if (this.info.error > 0) {
            auxE = `<b>[${this.info.error}]</b> <span class="fa fa-bug"></span><b>${this.msg.filesWithErrors},</b>`;
        }
        if (this.info.storage > 0) {
            auxS = `<b>[${this.info.storage}]</b> <span class="fa fa-location-dot"></span> <b>${this.msg.filesInLocalStorage}.</b>`;
        }
        return html `
        <div class="groupHeader">
            <header class="toolbar">
                <div class="toolbar__left">
                    <input name="projectFilter" class="toolbar__search" type="text" placeholder="Filter" autocomplete="off" @input="${this.filterLiChange}">
                </div>
            </header>
            <div class="groupInfo">
                <span style="margin-right:10px">
                    [${this.info.tot}]
				    <span class="fa fa-file"></span> 
                    ${this.msg.totalFiles}
                </span>
                ${auxV ? html `<span .innerHTML="${auxV}" style="margin-right:10px"></span>` : ''}
                ${auxE ? html `<span .innerHTML="${auxE}" style="margin-right:10px"></span>` : ''}
                ${auxS ? html `<span .innerHTML="${auxS}" style="margin-right:10px"></span>` : ''}
            </div>
        </div>
        `;
    }
    renderList() {
        let letterInit = '';
        return html `
            ${this.files.length <= 0 ? '' :
            html `
                    ${repeat(this.files, ((item) => item.project + '_' + item.shortName + '_' + item.folder), ((file, index) => {
                if (letterInit !== file.shortName.charAt(0).toUpperCase()) {
                    letterInit = file.shortName.charAt(0).toUpperCase();
                    return html `
                                    <li class="headerTitle">${letterInit} </li>
                                    ${this.renderLiItem(file, index)}
                                `;
                }
                return this.renderLiItem(file, index);
            }))}
                `}
        `;
    }
    renderLiItem(file, index) {
        const name = this.getAllName(file);
        const nameFilter = name.toLocaleLowerCase();
        const style = this.inFilter ? 'display:none' : '';
        const actualL2 = mls.actual[2][this.position]?.shortName;
        const actualL2Folder = mls.actual[2][this.position]?.folder;
        let auxValidProject = '';
        return html `
            <li @click="${this.clickOptOpen}" class="${file.shortName === actualL2 && file.folder === actualL2Folder ? 'selected' : ''}" style="${style}${auxValidProject}" .myFile=${file} .nameFilter="${nameFilter}" >
                <div class="elContent">
                    <info-item>
                        <span class="spanFileName ${file.status === 'deleted' ? 'fileDeleted' : ''}">${name}</span>
                    </info-item>    
                </div>
            </li>
        `;
    }
    //------------ ACTIONS -----------------
    getAllName(file) {
        let name = '';
        const folder = file.folder ? file.folder : '';
        if (folder)
            name = folder + '/' + file.shortName;
        else
            name = file.shortName;
        return name;
    }
    showLoading(show) {
        if (this.service)
            this.service.loading = show;
    }
    showError(error) {
        if (this.service)
            this.service.setError(error);
    }
    async clickOptOpen(e) {
        e.stopPropagation();
        const target = e.target;
        const li = target.closest('li');
        if (li && li.querySelector('*[contenteditable]'))
            return;
        this.lis?.forEach((l) => l.classList.remove('selected'));
        if (li)
            li.classList.add('selected');
        const mfile = this.getMyFileInElement(e.target);
        if (!mfile)
            return;
        this.fireEvents('open', mfile, {});
    }
    async fireEvents(action, file, info, timeout = 0) {
        try {
            const params = {};
            params.action = action;
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = this.position;
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
        }
        catch (err) {
            this.showError(err.message || '[fireEvents]: erro open');
        }
    }
    changeList(time = 500) {
        this.showLoading(false);
        if (this.changeListTimeout)
            window.clearTimeout(this.changeListTimeout);
        this.changeListTimeout = window.setTimeout(async () => {
            await this.init();
        }, time);
    }
    //------------ IMPLEMENTS -----------------
    async init() {
        this.info.tot = 0;
        this.info.version = 0;
        this.info.storage = 0;
        this.info.error = 0;
        this.projectLabel = (mls.actualProject || 0).toString();
        await this.getFiles();
    }
    getMyFileInElement(el) {
        el = el.closest('li');
        if (!el || !el['myFile'])
            return;
        const mfile = el['myFile'];
        return mfile;
    }
    filterLiChange(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        if (this.timeFilterChange)
            window.clearTimeout(this.timeFilterChange);
        this.timeFilterChange = window.setTimeout(() => {
            this.inFilter = el.value.length > 0;
            const contentServiceList = el.closest('.contentServiceList');
            if (!contentServiceList)
                return;
            const all = contentServiceList.querySelectorAll('li');
            all.forEach((li) => {
                const name = li.nameFilter ? li.nameFilter : '******';
                const inp = el.value.toLocaleLowerCase();
                if (name.indexOf(inp) >= 0) {
                    li.style.display = '';
                }
                else {
                    li.style.display = 'none';
                }
            });
        }, 500);
    }
    async getFiles() {
        try {
            const arraySf = await this.getFilesProject();
            this.files = [...arraySf];
        }
        catch (e) {
            console.info(e);
        }
    }
    validFileByLevel(sf) {
        const ext = '.defs.ts';
        if (sf.project !== mls.actualProject ||
            sf.level !== 2 ||
            sf.extension !== ext)
            return false;
        return true;
    }
    async getFilesProject() {
        if (!window['mls'])
            return [];
        const arraySf = [];
        for (const i of Object.keys(mls.stor.files)) {
            const sf = mls.stor.files[i];
            if (!this.validFileByLevel(sf))
                continue;
            this.info.tot++;
            arraySf.push(sf);
        }
        arraySf.sort((a, b) => a.shortName.localeCompare(b.shortName));
        return arraySf;
    }
    verifyDifBaseTemplate(file) {
        const { folder, shortName, project, extension } = file;
        const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, extension);
        if (this.dataDifBaseTemplate[key] === undefined)
            return file.inLocalStorage;
        return this.dataDifBaseTemplate[key];
    }
    initObserverResize() {
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
        this.resizeObserver = new ResizeObserver(entries => {
            for (let entry of entries) {
                if (entry.contentRect.width < 515) {
                    this.classList.add('breakContent');
                }
                else {
                    this.classList.remove('breakContent');
                }
            }
        });
        this.resizeObserver.observe(this);
    }
};
__decorate([
    property()
], ServiceProduct.prototype, "refresh", void 0);
__decorate([
    property()
], ServiceProduct.prototype, "levelFiles", void 0);
__decorate([
    property()
], ServiceProduct.prototype, "project", void 0);
__decorate([
    property()
], ServiceProduct.prototype, "filterProject", void 0);
__decorate([
    property()
], ServiceProduct.prototype, "projectLabel", void 0);
__decorate([
    property()
], ServiceProduct.prototype, "errorAux", void 0);
__decorate([
    property({ type: Array })
], ServiceProduct.prototype, "files", void 0);
__decorate([
    property()
], ServiceProduct.prototype, "activeTab", void 0);
__decorate([
    queryAll('li')
], ServiceProduct.prototype, "lis", void 0);
ServiceProduct = __decorate([
    customElement('service-product-100554')
], ServiceProduct);
export { ServiceProduct };
var ISceneries;
(function (ISceneries) {
    ISceneries[ISceneries["IMindMap"] = 0] = "IMindMap";
})(ISceneries || (ISceneries = {}));
