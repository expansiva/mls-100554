/// <mls fileReference="_100554_/l2/agents/agentToBeConceptual2Clarification.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, state, property, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let AgentToBeConceptual2Clarification = class AgentToBeConceptual2Clarification extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.entitiesCount = 0;
        this.rulesCount = 0;
        this.capabilitiesCount = 0;
        this.suggestions = [];
        this.badgePop = false;
        this.suggestionState = [];
        this.isAdding = false;
        this.activeTab = 'suggestions';
        this.editors = {
            rules: undefined,
            entities: undefined,
            capabilities: undefined,
        };
        this.renderedTabs = new Set(['suggestions']);
    }
    get suggestionsCount() {
        return this.suggestionState.filter(s => s.selected).length;
    }
    firstUpdated(changed) {
        this.suggestionState = this.suggestions.map(s => ({
            ...s,
            selected: s.yagni === 'now'
        }));
        if (!this.toBe)
            return;
        this.rules = this.toBe.rules || {};
        this.capabilities = this.toBe.capabilities || {};
        this.entities = this.toBe.ontology?.entities || {};
        this.rulesCount = Object.keys(this.rules || {}).length;
        this.capabilitiesCount = Object.keys(this.capabilities || {}).length;
        this.entitiesCount = Object.keys(this.entities || {}).length;
    }
    updated(changed) {
        if (changed.has('activeTab') && this.activeTab !== 'suggestions') {
            this.createEditor(this.activeTab);
        }
    }
    getValue(mode) {
        const values = {
            'rules': JSON.stringify(this.rules, null, 2),
            'capabilities': JSON.stringify(this.capabilities, null, 2),
            'entities': JSON.stringify(this.entities, null, 2),
        };
        return values[mode];
    }
    setTab(tab) {
        if (!this.renderedTabs.has(tab)) {
            this.renderedTabs.add(tab);
        }
        this.activeTab = tab;
    }
    triggerBadgePop() {
        this.badgePop = true;
        requestAnimationFrame(() => {
            setTimeout(() => {
                this.badgePop = false;
            }, 160);
        });
    }
    renderTabButton(tab, label, count) {
        return html `
            <button
                class="tab ${this.activeTab === tab ? 'active' : ''}"
                @click=${() => this.setTab(tab)}
            >
                ${label}
                ${count ? html `
                    <span class="badge ${tab === 'suggestions' && this.badgePop ? 'pop' : ''}">
                        ${count}
                    </span>
            ` : nothing}
            </button>
        `;
    }
    /* ---------------------------
     * Editor
     * --------------------------- */
    getEditorEl(mode) {
        if (mode === 'rules')
            return this.editorRules;
        else if (mode === 'capabilities')
            return this.editorCapabilities;
        else if (mode === 'entities')
            return this.editorEntities;
    }
    createEditor(mode) {
        if (this.editors[mode])
            return;
        const el = this.getEditorEl(mode);
        if (!el)
            return;
        requestAnimationFrame(() => {
            this.editors[mode] = monaco.editor.create(el, {
                automaticLayout: true,
                readOnly: true,
                minimap: {
                    enabled: false
                }
            });
            this.setInitialEditorValue(this.getValue(mode), mode);
        });
    }
    setInitialEditorValue(value, mode) {
        const model = this.createOrGetModel('json', value, mode);
        this.editors[mode]?.setModel(model);
    }
    createOrGetModel(editorType, src, mode) {
        const uri = this.getUri(`${this.constructor.name}`, mode);
        let model1 = monaco.editor.getModel(uri);
        if (!model1)
            model1 = monaco.editor.createModel(src, editorType, uri);
        return model1;
    }
    getUri(shortFN, mode) {
        return monaco.Uri.parse(`file://server/${shortFN}_${mode}.ts`);
    }
    /* ---------------------------
     * Lazy content
     * --------------------------- */
    renderPanel(tab) {
        if (!this.renderedTabs.has(tab))
            return nothing;
        return html `
        <div class="panel ${this.activeTab === tab ? 'show' : ''}">
            ${this.renderTabContent(tab)}
        </div>
    `;
    }
    renderTabContent(tab) {
        switch (tab) {
            case 'suggestions':
                return this.renderContentSuggestions();
            case 'entities':
                return this.renderContentEntities();
            case 'rules':
                return this.renderContentRules();
            case 'capabilities':
                return this.renderContentCapabilities();
            default:
                return nothing;
        }
    }
    /* ---------------------------
     * Render
     * --------------------------- */
    render() {
        return html `
            <div class="container">

                <div class="tabs">
                    ${this.renderTabButton('suggestions', html `Suggestions ${this.suggestionsCount
            ? html `<span class="badge selected-info ${this.badgePop ? 'pop' : ''}">${this.suggestionsCount} selected</span>`
            : nothing}`)}
                                
                    ${this.renderTabButton('entities', 'Entities', this.entitiesCount)}
                    ${this.renderTabButton('rules', 'Rules', this.rulesCount)}
                    ${this.renderTabButton('capabilities', 'Capabilities', this.capabilitiesCount)}
                </div>

                <div class="content">
                    ${this.renderPanel('suggestions')}
                    ${this.renderPanel('entities')}
                    ${this.renderPanel('rules')}
                    ${this.renderPanel('capabilities')}
                </div>

            </div>
        `;
    }
    renderContentEntities() {
        return html `<div class="editorEntities"></div>`;
    }
    renderContentRules() {
        return html `<div class="editorRules"></div>`;
    }
    renderContentCapabilities() {
        return html `<div class="editorCapabilities"></div>`;
    }
    renderContentSuggestions() {
        return html `
        <div class="suggestions">

        <div class="actions">
            <button type="button" class="action-btn cancel" @click=${() => { this.onAction('cancel'); }}>Cancel</button>
            <button type="button" class="action-btn continue" @click=${() => { this.onAction('continue'); }} >Continue</button>
        </div>

            ${this.suggestionState.map((s, i) => this.renderSuggestionCard(s, i))}
            ${this.renderAddSuggestion()}
        </div>
    `;
    }
    onAction(action) {
        const value = this.suggestionState.map(({ custom, selected, ...rest }) => rest);
        this.dispatchEvent(new CustomEvent('clarification-finish', {
            detail: {
                value,
                action
            },
            bubbles: true,
            composed: true
        }));
    }
    toggleSuggestion(index) {
        this.suggestionState[index].selected =
            !this.suggestionState[index].selected;
        if (this.suggestionState[index].selected)
            this.suggestionState[index].yagni = 'now';
        else
            this.suggestionState[index].yagni = 'later';
        this.triggerBadgePop();
        this.requestUpdate();
    }
    renderSuggestionCard(s, index) {
        return html `
        <div
            class="card ${s.selected ? 'selected' : ''}"
            @click=${() => this.toggleSuggestion(index)}
        >

            <input
                type="checkbox"
                .checked=${s.selected}
                @click=${(e) => e.stopPropagation()}
                @change=${() => this.toggleSuggestion(index)}
            />

            <div class="body">
                <div class="title">${s.suggestion}</div>
                <div class="desc">${s.customerPerception}</div>

                <div class="meta">
                    <span class="yagni ${s.yagni}">${s.yagni}</span>
                    ${s.businessImpact.map(b => html `<span class="tag">${b}</span>`)}
                </div>
            </div>

            ${s.custom ? html `
                <button
                    class="remove"
                    @click=${(e) => {
            e.stopPropagation();
            this.removeSuggestion(index);
        }}
                >
                    ✕
                </button>
            ` : nothing}

        </div>
    `;
    }
    addSuggestion(text) {
        if (!text.trim())
            return;
        this.suggestionState = [
            ...this.suggestionState,
            {
                suggestion: text,
                customerPerception: '',
                businessImpact: [],
                requiresConfiguration: false,
                yagni: 'now',
                selected: true,
                custom: true
            }
        ];
        this.triggerBadgePop();
        this.isAdding = false;
    }
    removeSuggestion(index) {
        this.suggestionState = this.suggestionState.filter((_, i) => i !== index);
        this.triggerBadgePop();
    }
    renderAddSuggestion() {
        if (this.isAdding) {
            return html `
            <input
                class="add-input"
                placeholder="Nova sugestão..."
                @keydown=${(e) => {
                if (e.key === 'Enter') {
                    this.addSuggestion(e.target.value);
                }
            }}
                autofocus
            />
        `;
        }
        return html `
        <button class="add-btn" @click=${() => this.isAdding = true}>
            + Add suggestion
        </button>
    `;
    }
};
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "entitiesCount", void 0);
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "rulesCount", void 0);
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "capabilitiesCount", void 0);
__decorate([
    property({ type: Array })
], AgentToBeConceptual2Clarification.prototype, "suggestions", void 0);
__decorate([
    property()
], AgentToBeConceptual2Clarification.prototype, "toBe", void 0);
__decorate([
    state()
], AgentToBeConceptual2Clarification.prototype, "rules", void 0);
__decorate([
    state()
], AgentToBeConceptual2Clarification.prototype, "capabilities", void 0);
__decorate([
    state()
], AgentToBeConceptual2Clarification.prototype, "entities", void 0);
__decorate([
    query('div.editorEntities')
], AgentToBeConceptual2Clarification.prototype, "editorEntities", void 0);
__decorate([
    query('div.editorRules')
], AgentToBeConceptual2Clarification.prototype, "editorRules", void 0);
__decorate([
    query('div.editorCapabilities')
], AgentToBeConceptual2Clarification.prototype, "editorCapabilities", void 0);
__decorate([
    state()
], AgentToBeConceptual2Clarification.prototype, "badgePop", void 0);
__decorate([
    state()
], AgentToBeConceptual2Clarification.prototype, "suggestionState", void 0);
__decorate([
    state()
], AgentToBeConceptual2Clarification.prototype, "isAdding", void 0);
__decorate([
    state()
], AgentToBeConceptual2Clarification.prototype, "activeTab", void 0);
AgentToBeConceptual2Clarification = __decorate([
    customElement('agents--agent-to-be-conceptual2-clarification-100554')
], AgentToBeConceptual2Clarification);
export { AgentToBeConceptual2Clarification };
