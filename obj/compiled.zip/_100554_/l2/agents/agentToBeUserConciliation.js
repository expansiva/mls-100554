/// <mls fileReference="_100554_/l2/agents/agentToBeUserConciliation.ts" enhancement="_100554_enhancementAgent" />
import { outputPrompt } from '/_100554_/l2/agents/agentToBeConceptual.js';
export function createAgent() {
    return {
        agentName: "agentToBeUserConciliation",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Generate User Journeys",
        visibility: "private",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1.replace("{{outputPrompt}}", outputPrompt)
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: `test ${agent.agentName}`,
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    try {
        const output = payload.result;
        intents = await processOutput(output);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [];
    // return [...intents, updateStatus];
}
async function processOutput(moduleToBe) {
    console.log("=== User journeys");
    console.log(JSON.stringify(moduleToBe, null, 2));
    const inTest = true; // todo: define
    if (inTest)
        return [];
    const step = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'pending',
        nextSteps: [],
        agentName: "agentToBeConceptual3",
        prompt: "",
        rags: null,
    };
    // const rc: mls.msg.AgentIntentAddSteps = {
    //   type: 'add-steps',
    //   steps: [step]
    // }
    return [];
}
/*
"t1, grok-code-fast-1, 6s, $0.0013, 6.2/10",
"t2, gpt-5.2, 42s, $0.0377, 8.9/10",
"t3, gemini-2.5-pro, 35s, $0.0094, 7.4/10"
*/
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior BUSINESS Analyst with 20+ years of experience in system design, requirements analysis, and business process optimization.

Your task is to update the to be conceptual.

{{outputPrompt}}
`;
