/// <mls fileReference="_100554_/l2/agents/agentToBePageTemplate.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
import { beInvoke, readLocal, savelocal, generateId } from "/_100554_/l2/agents/collabAuraPageCommon.js";
import { getState, setState, subscribe, unsubscribe, initState } from "/_100554_/l2/collabState.js";
import "/_100554_/l2/pluginExploreList.js";
const message_pt = {
  loading: "Carregando..."
};
const message_en = {
  loading: "Loading..."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let Page1 = class extends CollabLitElement {
  /**
   * =========================================================================
   * CONFIGURATION
   * =========================================================================
   */
  msg = messages["en"];
  msize = "";
  /* LLM_REMOVE_START */
  /**
   * Base namespace for all states of this page
   * LLM MUST keep consistency between this and States enum
   */
  /* LLM_REMOVE_END */
  STATE_BASE = "ui.page1";
  /* LLM_REMOVE_START */
  /**
   * =========================================================================
   * LIFECYCLE
   * =========================================================================
   */
  /* LLM_REMOVE_END */
  constructor() {
    super();
  }
  /**
   * Called when component is attached to DOM
   * This is the main initialization entrypoint
   */
  async connectedCallback() {
    super.connectedCallback();
    await this.initState();
    await this.initListeners();
    await this.initData();
  }
  /**
   * Called when component is removed from DOM
   * Responsible for cleanup
   */
  async disconnectedCallback() {
    super.disconnectedCallback();
    await this.dispose();
  }
  /**
   * =========================================================================
   * INITIALIZATION
   * =========================================================================
   */
  /* LLM_REMOVE_START */
  /**
   * Initialize ALL states used by this page
   *
   * LLM MUST initialize every state defined in States enum
   */
  /* LLM_REMOVE_END */
  async initState() {
    initState(this.STATE_BASE, {
      loading: false,
      name: "",
      error: "",
      updateUser: "",
      consistency: 0 /* empty */
    });
  }
  /**
   * Subscribe to state changes
   * LLM_REMOVE_START
   * LLM MUST subscribe to relevant state transitions
   * LLM_REMOVE_END
   */
  async initListeners() {
    subscribe(pageState.user.events.update, this.handleUpdateUser);
  }
  /**
   * Load initial data from backend
   * LLM_REMOVE_START
   * LLM MAY call backend routines here
   * LLM_REMOVE_END
   */
  async initData() {
    await this.loadUser();
  }
  /* LLM_REMOVE_START */
  /**
   * =========================================================================
   * DISPOSE
   * =========================================================================
   *
   * Cleanup all listeners and resources
   */
  /* LLM_REMOVE_END */
  async dispose() {
    unsubscribe(pageState.user.events.update, this.handleUpdateUser);
  }
  /**
   * =========================================================================
   * STATE HANDLERS
   * =========================================================================
   *
   * Called when state changes
   * LLM_REMOVE_START
   * LLM MUST implement handlers when needed
   * LLM_REMOVE_END
   */
  async handleUpdateUser() {
    const value = getState(pageState.user.events.update);
  }
  /**
   * =========================================================================
   * UI HANDLERS
   * =========================================================================
   *
   * Called from user interactions
   *
   * Example:
   * - button clicks
   * - organism events
   */
  async handleClickUpdateUser() {
    await this.createOrder();
  }
  /**
   * =========================================================================
   * RENDER
   * =========================================================================
   *
   * RULES:
   *
   * - MUST be pure
   * - MUST NOT call backend
   * - MUST NOT mutate state
   *
   * Only reads state and renders organisms/plugins
   */
  render() {
    const loading = getState(pageState.ui.loading);
    if (loading)
      return html`<div>${this.msg.loading}</div>`;
    return html`

            <!--
                LLM MUST render organisms here

                Example:

                <user-list-organism
                    .users=$ {getState(States.users)}
                >
                </user-list-organism>

            -->

            <div>

                Page Template Ready

            </div>

        `;
  }
  /**
   * =============================================================================
   * BACKEND READS
   * =============================================================================
   * LLM_REMOVE_START
   * MODULE Scope
   * LLM MUST define read routines here
   *
   * Reads DO NOT change server state
   * LLM_REMOVE_END
   */
  async loadUser() {
    function updateStates(result2) {
    }
    const userRequestId = generateId();
    setState(pageState.user.requestId, userRequestId);
    const params = { id: 123 };
    const local = await readLocal(routines.user.get, params);
    if (local) {
      setState(pageState.user.consistency, 1 /* stale */);
      updateStates(local);
    } else {
      setState(pageState.user.consistency, 3 /* loading */);
    }
    setState(pageState.ui.error, "");
    const result = await beInvoke(routines.user.get, userRequestId, params);
    if (!result.requestId) throw new Error("invalid return, no requestId");
    if (result.requestId !== userRequestId) return;
    await savelocal(routines.user.get, params, result);
    if (result.error) {
      setState(pageState.user.consistency, 4 /* error */);
      setState(pageState.ui.error, result.error);
    } else {
      setState(pageState.user.consistency, 2 /* fresh */);
      setState(pageState.ui.error, "");
      updateStates(result);
    }
  }
  /**
   * =============================================================================
   * BACKEND MUTATIONS
   * =============================================================================
   * LLM_REMOVE_START
   * MODULE Scope
   * LLM MUST define mutations here
   *
   * Mutations change server state
   * LLM_REMOVE_END
   */
  async createOrder() {
    setState(pageState.ui.loading, true);
    const orderRequestId = generateId();
    setState(pageState.order.requestId, orderRequestId);
    const params = {
      customerId: "123",
      name: "john"
    };
    function updateStates(result2) {
    }
    const result = await beInvoke(routines.order.create, orderRequestId, params);
    setState(pageState.ui.loading, false);
    if (result.error) {
      setState(pageState.ui.error, result.error);
    } else {
      setState(pageState.ui.error, "");
      updateStates(result);
    }
  }
  /**
   * =============================================================================
   * PLUGINS INVOKE
   * =============================================================================
   * Ex:
   * const params = { phone: "123", message: "hello" };
   * const result = await pluginInvoke( "whatsapp.openConsultation", params);
   */
};
__decorateClass([
  property({ type: String })
], Page1.prototype, "msize", 2);
Page1 = __decorateClass([
  customElement("agents--agent-to-be-page-template-100554")
], Page1);
var Consistency = /* @__PURE__ */ ((Consistency2) => {
  Consistency2[Consistency2["empty"] = 0] = "empty";
  Consistency2[Consistency2["stale"] = 1] = "stale";
  Consistency2[Consistency2["fresh"] = 2] = "fresh";
  Consistency2[Consistency2["loading"] = 3] = "loading";
  Consistency2[Consistency2["error"] = 4] = "error";
  return Consistency2;
})(Consistency || {});
;
const pageState = {
  ui: {
    loading: "ui.page1.loading",
    error: "ui.page1.error"
  },
  user: {
    name: "ui.page1.name",
    consistency: "ui.page1.userConsistency",
    requestId: "ui.page1.userRequestId",
    events: {
      update: "ui.page1.updateUser"
    }
  },
  order: {
    consistency: "ui.page1.orderConsistency",
    requestId: "ui.page1.orderRequestId"
  }
};
const routines = {
  order: {
    create: "page1.order.create"
  },
  user: {
    get: "page1.user.get"
  }
};
export {
  Consistency,
  Page1,
  pageState,
  routines
};
