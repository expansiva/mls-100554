/// <mls fileReference="_100554_/l2/agents/agentToBePageTemplate.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// LLM must replace fileReference to new page name
// LLM must add clear and concise comments to improve code readability for humans.
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { beInvoke, readLocal, savelocal, generateId } from '/_100554_/l2/agents/collabAuraPageCommon.js';
import { getState, setState, subscribe, unsubscribe, initState } from '/_100554_/l2/collabState.js';
// getState(key: string): any ...
// setState(key: string, value: any): void
// subscribe(keyOrKeys: string | string[], component: Object): void
// unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void
// initState(path: string, value: string | Object | Array<unknown>): void
// Import organisms and plugins used in render()
// LLM MUST add imports here when needed
import "/_100554_/l2/pluginExploreList.js";
/**
 * =============================================================================
 * I18N SECTION
 * =============================================================================
 */
/* LLM_REMOVE_START */
// LLM MAY EXTEND THIS
// LLM MUST use only the languages specified by the user
/* LLM_REMOVE_END */
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
};
const message_en = {
    loading: 'Loading...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
/* LLM_REFERENCE_START */
/**
 * =============================================================================
 * EXPERIENCE MODEL — PAGE CONTEXT
 * =============================================================================
 *
 * -----------------------------------------------------------------------------
 * SUPPORTED CAPABILITIES
 * -----------------------------------------------------------------------------
 *
 * LLM must list capabilities
 *
 * -----------------------------------------------------------------------------
 * APPLIED RULES
 * -----------------------------------------------------------------------------
 *
 * LLM must list rules
 *
 */
/* LLM_REFERENCE_END */
/* LLM_REMOVE_START */
/**
 * =============================================================================
 * PAGE COMPONENT
 * =============================================================================
 *
 * LLM MUST:
 *
 * - Rename class to semantic name
 * - Keep lifecycle structure
 * - Extend States enum
 *
 */
/* LLM_REMOVE_END */
let Page1 = class Page1 extends CollabLitElement {
    /* LLM_REMOVE_START */
    /**
     * =========================================================================
     * LIFECYCLE
     * =========================================================================
     */
    /* LLM_REMOVE_END */
    constructor() {
        super();
        /**
         * =========================================================================
         * CONFIGURATION
         * =========================================================================
         */
        this.msg = messages['en'];
        this.msize = '';
        /* LLM_REMOVE_START */
        /**
         * Base namespace for all states of this page
         * LLM MUST keep consistency between this and States enum
         */
        /* LLM_REMOVE_END */
        this.STATE_BASE = "ui.page1";
    }
    /**
     * Called when component is attached to DOM
     * This is the main initialization entrypoint
     */
    async connectedCallback() {
        super.connectedCallback();
        await this.initState();
        await this.initListeners();
        await this.initData();
    }
    /**
     * Called when component is removed from DOM
     * Responsible for cleanup
     */
    async disconnectedCallback() {
        super.disconnectedCallback();
        await this.dispose();
    }
    /**
     * =========================================================================
     * INITIALIZATION
     * =========================================================================
     */
    /* LLM_REMOVE_START */
    /**
     * Initialize ALL states used by this page
     *
     * LLM MUST initialize every state defined in States enum
     */
    /* LLM_REMOVE_END */
    async initState() {
        initState(this.STATE_BASE, {
            loading: false,
            name: '',
            error: '',
            updateUser: '',
            consistency: Consistency.empty
        });
    }
    /**
     * Subscribe to state changes
     * LLM_REMOVE_START
     * LLM MUST subscribe to relevant state transitions
     * LLM_REMOVE_END
     */
    async initListeners() {
        subscribe(pageState.user.events.update, this.handleUpdateUser);
    }
    /**
     * Load initial data from backend
     * LLM_REMOVE_START
     * LLM MAY call backend routines here
     * LLM_REMOVE_END
     */
    async initData() {
        // LLM must load initial data
        await this.loadUser();
    }
    /* LLM_REMOVE_START */
    /**
     * =========================================================================
     * DISPOSE
     * =========================================================================
     *
     * Cleanup all listeners and resources
     */
    /* LLM_REMOVE_END */
    async dispose() {
        unsubscribe(pageState.user.events.update, this.handleUpdateUser);
    }
    /**
     * =========================================================================
     * STATE HANDLERS
     * =========================================================================
     *
     * Called when state changes
     * LLM_REMOVE_START
     * LLM MUST implement handlers when needed
     * LLM_REMOVE_END
     */
    async handleUpdateUser() {
        const value = getState(pageState.user.events.update);
        // LLM MUST implement logic
    }
    /**
     * =========================================================================
     * UI HANDLERS
     * =========================================================================
     *
     * Called from user interactions
     *
     * Example:
     * - button clicks
     * - organism events
     */
    async handleClickUpdateUser() {
        await this.createOrder();
    }
    /**
     * =========================================================================
     * RENDER
     * =========================================================================
     *
     * RULES:
     *
     * - MUST be pure
     * - MUST NOT call backend
     * - MUST NOT mutate state
     *
     * Only reads state and renders organisms/plugins
     */
    render() {
        const loading = getState(pageState.ui.loading);
        if (loading)
            return html `<div>${this.msg.loading}</div>`;
        return html `

            <!--
                LLM MUST render organisms here

                Example:

                <user-list-organism
                    .users=$ {getState(States.users)}
                >
                </user-list-organism>

            -->

            <div>

                Page Template Ready

            </div>

        `;
    }
    /**
     * =============================================================================
     * BACKEND READS
     * =============================================================================
     * LLM_REMOVE_START
     * MODULE Scope
     * LLM MUST define read routines here
     *
     * Reads DO NOT change server state
     * LLM_REMOVE_END
     */
    async loadUser() {
        function updateStates(result) {
            // LLM MUST update state here
        }
        const userRequestId = generateId();
        setState(pageState.user.requestId, userRequestId);
        const params = { id: 123 };
        const local = await readLocal(routines.user.get, params);
        if (local) {
            setState(pageState.user.consistency, Consistency.stale);
            updateStates(local);
        }
        else {
            setState(pageState.user.consistency, Consistency.loading);
        }
        setState(pageState.ui.error, '');
        const result = await beInvoke(routines.user.get, userRequestId, params);
        if (!result.requestId)
            throw new Error("invalid return, no requestId");
        if (result.requestId !== userRequestId)
            return; // ignore
        await savelocal(routines.user.get, params, result);
        if (result.error) {
            setState(pageState.user.consistency, Consistency.error);
            setState(pageState.ui.error, result.error);
        }
        else {
            setState(pageState.user.consistency, Consistency.fresh);
            setState(pageState.ui.error, '');
            updateStates(result);
        }
    }
    /**
     * =============================================================================
     * BACKEND MUTATIONS
     * =============================================================================
     * LLM_REMOVE_START
     * MODULE Scope
     * LLM MUST define mutations here
     *
     * Mutations change server state
     * LLM_REMOVE_END
     */
    async createOrder() {
        setState(pageState.ui.loading, true);
        const orderRequestId = generateId();
        setState(pageState.order.requestId, orderRequestId);
        const params = {
            customerId: "123",
            name: "john"
        };
        function updateStates(result) {
            // LLM MUST update state here
        }
        const result = await beInvoke(routines.order.create, orderRequestId, params);
        setState(pageState.ui.loading, false);
        if (result.error) {
            setState(pageState.ui.error, result.error);
        }
        else {
            setState(pageState.ui.error, '');
            updateStates(result);
        }
    }
};
__decorate([
    property({ type: String })
], Page1.prototype, "msize", void 0);
Page1 = __decorate([
    customElement('agents--agent-to-be-page-template-100554')
], Page1);
export { Page1 };
/**
 * =============================================================================
 * CONTRACTS
 * =============================================================================
 * LLM_REMOVE_START
 * LLM MUST define and export all contracts used by organisms rendered by this page.
 * These contracts define the interface between the page and its organisms.
 * Contracts include:
 * - organism props interfaces
 * - organism event interfaces
 * - data view models
 * LLM_REMOVE_END
 */
export var Consistency;
(function (Consistency) {
    Consistency[Consistency["empty"] = 0] = "empty";
    Consistency[Consistency["stale"] = 1] = "stale";
    Consistency[Consistency["fresh"] = 2] = "fresh";
    Consistency[Consistency["loading"] = 3] = "loading";
    Consistency[Consistency["error"] = 4] = "error";
})(Consistency || (Consistency = {}));
;
/**
 * =============================================================================
 * PAGE STATE — strongly typed state tree
 * =============================================================================
 *
 * Use this object instead of string literals.
 * Provides autocomplete and compile-time safety.
 */
export const pageState = {
    ui: {
        loading: "ui.page1.loading",
        error: "ui.page1.error"
    },
    user: {
        name: "ui.page1.name",
        consistency: "ui.page1.userConsistency",
        requestId: "ui.page1.userRequestId",
        events: {
            update: "ui.page1.updateUser"
        }
    },
    order: {
        consistency: "ui.page1.orderConsistency",
        requestId: "ui.page1.orderRequestId"
    }
};
// page1 = name of this page, exemplo
export const routines = {
    order: {
        create: "page1.order.create"
    },
    user: {
        get: "page1.user.get"
    }
};
