/// <mls fileReference="_100554_/l2/agents/collabAuraPageCommon.ts" enhancement="_blank" />
/**
 * =============================================================================
 * BACKEND BRIDGE (REAL + MOCK)
 * =============================================================================
 */
const isMockMode = true;
const localCache = new Map();
export async function beInvoke(routine, requestId, params) {
    if (isMockMode) {
        const handler = globalThis.__BE_DRIVER__?.invoke;
        if (!handler) {
            return { requestId, error: "Mock not implemented: " + routine };
        }
        await delay(50);
        const result = await handler(routine, params, requestId);
        return {
            requestId,
            ...result
        };
    }
    // 🔴 Aqui entraria o backend real
    return {
        requestId,
        error: "Real backend not implemented"
    };
}
export async function readLocal(routine, params) {
    const key = buildCacheKey(routine, params);
    return localCache.get(key);
}
export async function savelocal(routine, params, result) {
    const key = buildCacheKey(routine, params);
    localCache.set(key, result);
}
export function generateId() {
    return Date.now();
}
function buildCacheKey(routine, params) {
    return routine + "::" + JSON.stringify(params ?? {});
}
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
