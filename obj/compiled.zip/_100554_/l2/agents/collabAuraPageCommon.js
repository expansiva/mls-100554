/// <mls fileReference="_100554_/l2/agents/collabAuraPageCommon.ts" enhancement="_blank" />
const isMockMode = true;
export async function beInvoke(routine, requestId, params) {
    if (isMockMode) {
        const handler = globalThis.__BE_DRIVER__?.invoke;
        if (!handler) {
            return { requestId, error: "Mock not implemented: " + routine };
        }
        await delay(50);
        const result = await handler(routine, params, requestId);
        return {
            requestId,
            ...result
        };
    }
    return {
        requestId,
        error: "Real backend not implemented"
    };
}
export async function readLocal(routine, params) {
}
export async function savelocal(routine, params, result) {
}
export async function pluginInvoke(pluginRef, params) {
    console.log('error, plugin not found ' + pluginRef);
    return null;
}
export function generateId() {
    return Date.now();
}
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
