/// <mls fileReference="_100554_/l2/agents/collabAuraPageCommon.ts" enhancement="_blank" />
export async function beInvoke(routine, requestId, params) {
    return {
        requestId: requestId,
        error: 'not implemented'
    };
}
export async function pluginInvoke(pluginRef, params) {
    console.log('error, plugin not found ' + pluginRef);
    return null;
}
export async function readLocal(routine, params) {
    return undefined;
}
export async function savelocal(routine, params, result) {
}
export function generateId() {
    return 1;
}
