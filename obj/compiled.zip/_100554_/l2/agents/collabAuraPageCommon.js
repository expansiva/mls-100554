async function beInvoke(routine, requestId, params) {
  return {
    requestId,
    error: "not implemented"
  };
}
async function pluginInvoke(pluginRef, params) {
  console.log("error, plugin not found " + pluginRef);
  return null;
}
async function readLocal(routine, params) {
  return void 0;
}
async function savelocal(routine, params, result) {
}
function generateId() {
  return 1;
}
export {
  beInvoke,
  generateId,
  pluginInvoke,
  readLocal,
  savelocal
};
