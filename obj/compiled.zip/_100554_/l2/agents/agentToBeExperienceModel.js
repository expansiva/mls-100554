/// <mls fileReference="_100554_/l2/agents/agentToBeExperienceModel.ts" enhancement="_100554_enhancementAgent" />
export function createAgent() {
    return {
        agentName: "agentToBeExperienceModel",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Generate Experience Model",
        visibility: "private",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: `test ${agent.agentName}`,
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    try {
        const output = payload.result;
        intents = await processOutput(output);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [];
    // return [...intents, updateStatus];
}
async function processOutput(experienceModel) {
    console.log("=== User journeys");
    console.log(JSON.stringify(experienceModel, null, 2));
    const inTest = true; // todo: define
    if (inTest)
        return [];
    const step = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'pending',
        nextSteps: [],
        agentName: "agentToBeConceptual3",
        prompt: "",
        rags: null,
    };
    // const rc: mls.msg.AgentIntentAddSteps = {
    //   type: 'add-steps',
    //   steps: [step]
    // }
    return [];
}
/*
"t1, gemini-2.5-pro, 39s, $0.0211, 6/10",
"t2, grok-code-fast-1, 11s, $0.0037, 4/10",
"t3, gpt-5.2, 59s, $0.0727, 7/10",
"t4, moonshotai/kimi-k2.5, 28s, $0.0117, 8/10"
*/
const system1 = `
<!-- modelType: code2 -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior BUSINESS Analyst with 20+ years of experience in system design, requirements analysis, and business process optimization.

Define screens and journeys required to realize all capabilities.

Screens must represent navigable UI states.
Journeys must represent realistic user navigation flows.

Do not define UI components, layouts, or backend details.

## Output format
You must return the object strictly as JSON
[[OutputSection]]
`;
//#endregion
