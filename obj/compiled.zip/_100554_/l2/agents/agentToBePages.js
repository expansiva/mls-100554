/// <mls fileReference="_100554_/l2/agents/agentToBePages.ts" enhancement="_100554_enhancementAgent" />
export function createAgent() {
    return {
        agentName: "agentToBePages",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Generate Page List",
        visibility: "private",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1.replace("{{systemExperienceConstraints}}", systemExperienceConstraints)
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: `test ${agent.agentName}`,
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    try {
        const output = payload.result;
        intents = await processOutput(output);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [];
    // return [...intents, updateStatus];
}
async function processOutput(experienceModel) {
    const inTest = true; // todo: define
    if (inTest)
        return [];
    const step = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'pending',
        nextSteps: [],
        agentName: "agentToBeConceptual3",
        prompt: "",
        rags: null,
    };
    // const rc: mls.msg.AgentIntentAddSteps = {
    //   type: 'add-steps',
    //   steps: [step]
    // }
    return [];
}
/*
"agentToBePages",
"t1, gemini-2.5-pro, 42s, $0.0192, 7.1/10",
"t2, gpt-5.2, 40s, $0.0477, 8.8/10",
"t3, grok-code-fast-1, 26s, $0.0036, 6.2/10",
"t4, moonshotai/kimi-k2.5, 61s, $0.0156, 5.8/10 - double deffinition of staff pages, json formatting issues, loop"*/
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior BUSINESS Analyst.

Task: Generate ToBePages from the given 'Experience Model' and 'Capabilities Summary'.

Step-by-step (MANDATORY):
1) Read screens[] from the Experience Model.
2) For each screens[i], create exactly one pages[i].
3) pages[i].screenId MUST equal screens[i].screenId (same order, 1:1).
4) Do not create extra pages and do not skip screens.

Rules:
- Do NOT invent screens/pages that are not in screens[].
- Navigation is handled by the AppShell; pages must NOT include menus/tabs/navigation controls.
- Sections are content containers. If a section uses tabs/panels, set mode="exclusive" (only one organism visible at a time).
- Organisms are layout containers with a single purpose (no business logic).
- Do NOT define molecules or atoms yet.
- Do NOT define technical implementation.
- You MUST follow experienceConstraints when deciding organisms and interaction patterns.

{{systemExperienceConstraints}}

## Output format
You must return the object strictly as JSON, no spaces, no indent, minified
[[OutputSection]]
`;
export const systemExperienceConstraints = `
## Experience Constraints
[[ExperienceConstraints]]
`;
//#region ExperienceConstraints 
const experienceConstraints = {
    navigationMode: "state-driven",
    listLoadingPattern: "infinite-scroll",
    // pagination | load-more | infinite-scroll
    dialogPattern: "modal",
    // modal | inline | none
    allowPopups: false,
    allowMultiplePanels: false,
    // false -> Prefer tab-based layout for complex entity screens (identification, relationships, contracts, incidents).
    // true  -> Allow multiple panels visible at the same time (modern stacked layout).
    preferInlineEditing: true,
    preferOptimisticUpdates: true,
    navigationContainer: "appShell",
    screenPersistence: "keep-alive",
    layoutStructure: {
        separateContextSection: true,
        // true = create "header" section for contextual organisms
        // false = allow context organisms inside "main"
        preferSingleMainSection: false,
        // true = collapse all organisms into "main"
        allowedSections: ["header", "main", "aside", "footer"],
        contextSectionName: "header",
        mainSectionName: "main"
    }
};
//#endregion
