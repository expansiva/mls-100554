/// <mls fileReference="_100554_/l2/agents/agentToBePages.ts" enhancement="_100554_enhancementAgent" />
import { getAgentStepByAgentName } from "/_100554_/l2/aiAgentHelper.js";
function createAgent() {
  return {
    agentName: "agentToBePages",
    agentProject: 100554,
    agentFolder: "agents",
    agentDescription: "Generate Page List",
    visibility: "private",
    beforePromptImplicit,
    beforePromptStep,
    afterPromptStep
  };
}
async function beforePromptImplicit(agent, context, userPrompt) {
  if (!userPrompt) throw new Error("invalid prompt");
  if (userPrompt === "test") {
    userPrompt = userPromptTest;
  }
  const addMessageAI = {
    type: "add-message-ai",
    request: {
      action: "addMessageAI",
      agentName: agent.agentName,
      inputAI: [{
        type: "system",
        content: system1.replace("{{systemExperienceConstraints}}", systemExperienceConstraints)
      }, {
        type: "human",
        content: userPrompt
      }],
      taskTitle: agent.agentDescription,
      threadId: context.message.threadId,
      userMessage: `test ${agent.agentName}`,
      longTermMemory: {}
    }
  };
  return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
  if (!args) throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
  console.info(`BeforePromptStep ${agent.agentName}`);
  console.info(`${args}`);
  const continueIntent = {
    type: "prompt_ready",
    args,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || "",
    hookSequential,
    parentStepId: parentStep.stepId,
    humanPrompt: args || "",
    systemPrompt: system1.replace("{{systemExperienceConstraints}}", systemExperienceConstraints)
  };
  return [continueIntent];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
  if (!agent || !context || !step) throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
  const payload = step.interaction?.payload?.[0] || void 0;
  if (payload?.type !== "flexible" || !payload.result) throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
  let status = "completed";
  let intents = [];
  try {
    const output = payload.result;
    intents = await processOutputToBePages(context, output, step);
  } catch (e) {
    console.error(e);
    status = "failed";
  }
  const updateStatus = {
    type: "update-status",
    hookSequential,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || "",
    parentStepId: parentStep.stepId,
    stepId: step.stepId,
    status
  };
  return [...intents, updateStatus];
}
async function processOutputToBePages(context, toBePages, step) {
  console.log("processOutputToBePages === toBePages");
  console.log({ toBePages });
  if (context.isTest) return [];
  const paths = toBePages.pages.map((page) => page.pageName).slice(0, 2);
  const newStep = {
    type: "add-step",
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || "",
    parentStepId: step.stepId,
    step: {
      type: "agent",
      stepId: 0,
      interaction: null,
      status: "waiting_human_input",
      nextSteps: [],
      agentName: "agentToBePage",
      rags: null
    },
    executionMode: {
      type: "parallel",
      args: paths
    }
  };
  return [newStep];
}
function getPayloadToBePages(context) {
  if (!context.task) return void 0;
  const agentName = "agentToBePages";
  const agentStep = getAgentStepByAgentName(context.task, agentName);
  if (!agentStep) throw new Error(`[${agentName}] [getPayload] no agent found`);
  const resultStep = agentStep.interaction?.payload?.[0];
  if (!resultStep || resultStep.type !== "flexible" || !resultStep.result) throw new Error(`[${agentName}] [getPayload] No step clarification found for this agent.`);
  let payloadToBePages = resultStep.result;
  if (typeof payloadToBePages === "string") payloadToBePages = JSON.parse(payloadToBePages);
  return payloadToBePages;
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior BUSINESS Analyst.

Task: Generate ToBePages from the given 'Experience Model' and 'Capabilities Summary'.

Step-by-step (MANDATORY):
1) Read screens[] from the Experience Model.
2) For each screens[i], create exactly one pages[i].
3) pages[i].screenId MUST equal screens[i].screenId (same order, 1:1).
4) Do not create extra pages and do not skip screens.

Rules:
- Do NOT invent screens/pages that are not in screens[].
- Navigation is handled by the AppShell; pages must NOT include menus/tabs/navigation controls.
- Sections are content containers. If a section uses tabs/panels, set mode="exclusive" (only one organism visible at a time).
- Organisms are layout containers with a single purpose (no business logic).
- Do NOT define molecules or atoms yet.
- Do NOT define technical implementation.
- You MUST follow experienceConstraints when deciding organisms and interaction patterns.

{{systemExperienceConstraints}}

## Output format
You must return the object strictly as JSON, no spaces, no indent, minified
export type Output = {
        type: "flexible";
        result: ToBePages;
};
export interface ToBePages {
        pages: Page[];
}
export interface Page {
        screenId: string;
        pageName: string; // ex: listProducts
        actor: string;
        purpose: string;
        sections: Section[];
}
export interface Section {
        sectionName: string; // main, aside, header, footer, ...
        mode: "stack" | "exclusive";
        organisms: Organism[];
}
export interface Organism {
        organismName: string;  // e.g. "listProductsTop5", always prefixed with pageName in camelCase
        purpose: string;       // Short description of the organism's single responsibility
        fieldsets?: string[];  // Optional: list of thematic groups inside this organism (e.g. ["Personal Data", "Addresses", "Preferences"])
        // Each string represents a <fieldset> + <legend> grouping of related form fields.
        // Used only when the organism contains a complex form that benefits from semantic grouping.
}
`;
const systemExperienceConstraints = `
## Experience Constraints
const experienceConstraints = {
        navigationMode: "state-driven",
        listLoadingPattern: "infinite-scroll",
        // pagination | load-more | infinite-scroll
        dialogPattern: "modal",
        // modal | inline | none
        allowPopups: false,

        allowMultiplePanels: false,
        // false -> Prefer tab-based layout for complex entity screens (identification, relationships, contracts, incidents).
        // true  -> Allow multiple panels visible at the same time (modern stacked layout).

        preferInlineEditing: true,
        preferOptimisticUpdates: true,
        navigationContainer: "appShell",
        screenPersistence: "keep-alive",
        layoutStructure: {
                separateContextSection: true,
                // true = create "header" section for contextual organisms
                // false = allow context organisms inside "main"
                preferSingleMainSection: false,
                // true = collapse all organisms into "main"
                allowedSections: ["header", "main", "aside", "footer"],
                contextSectionName: "header",
                mainSectionName: "main"
        }
}
`;
const experienceConstraints = {
  navigationMode: "state-driven",
  listLoadingPattern: "infinite-scroll",
  // pagination | load-more | infinite-scroll
  dialogPattern: "modal",
  // modal | inline | none
  allowPopups: false,
  allowMultiplePanels: false,
  // false -> Prefer tab-based layout for complex entity screens (identification, relationships, contracts, incidents).
  // true  -> Allow multiple panels visible at the same time (modern stacked layout).
  preferInlineEditing: true,
  preferOptimisticUpdates: true,
  navigationContainer: "appShell",
  screenPersistence: "keep-alive",
  layoutStructure: {
    separateContextSection: true,
    // true = create "header" section for contextual organisms
    // false = allow context organisms inside "main"
    preferSingleMainSection: false,
    // true = collapse all organisms into "main"
    allowedSections: ["header", "main", "aside", "footer"],
    contextSectionName: "header",
    mainSectionName: "main"
  }
};
const userPromptTest = `
## Experience Model
\`\`\`json
{
        "screens": [
                {
                        "screenId": "home",
                        "actor": "customer",
                        "screenType": "page",
                        "isEntryPoint": true,
                        "purpose": "P\xE1gina inicial do site com destaque para produtos, blog e informa\xE7\xF5es institucionais em tom acolhedor",
                        "supportsCapabilities": [
                                "catalog",
                                "blog",
                                "about",
                                "contact",
                                "cart",
                                "footerContactHighlights"
                        ],
                        "rulesApplied": [
                                "RULE-TONE-001",
                                "RULE-LANG-001",
                                "RULE-CONTACT-002"
                        ]
                },
                {
                        "screenId": "productCatalog",
                        "actor": "customer",
                        "screenType": "page",
                        "purpose": "Listagem de produtos com navega\xE7\xE3o por categorias, busca e filtros",
                        "supportsCapabilities": [
                                "catalog",
                                "catalogAdvancedFilters"
                        ],
                        "rulesApplied": [
                                "RULE-PRODUCT-001",
                                "RULE-PRODUCT-002",
                                "RULE-PRODUCT-004",
                                "RULE-PRODUCT-005",
                                "RULE-TONE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "productDetail",
                        "actor": "customer",
                        "screenType": "page",
                        "purpose": "P\xE1gina de detalhes do produto com galeria de imagens, descri\xE7\xE3o completa, pre\xE7o e disponibilidade",
                        "supportsCapabilities": [
                                "catalog",
                                "cart"
                        ],
                        "rulesApplied": [
                                "RULE-PRODUCT-001",
                                "RULE-PRODUCT-003",
                                "RULE-PRODUCT-005",
                                "RULE-CART-001",
                                "RULE-TONE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "cart",
                        "actor": "customer",
                        "screenType": "page",
                        "purpose": "Visualiza\xE7\xE3o e gerenciamento do carrinho com CTAs de finaliza\xE7\xE3o configurados",
                        "supportsCapabilities": [
                                "cart",
                                "cartCheckoutCtas"
                        ],
                        "rulesApplied": [
                                "RULE-CART-001",
                                "RULE-CART-002",
                                "RULE-CART-003",
                                "RULE-TONE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "about",
                        "actor": "customer",
                        "screenType": "page",
                        "purpose": "P\xE1gina institucional com hist\xF3ria e valores do pet shop",
                        "supportsCapabilities": [
                                "about"
                        ],
                        "rulesApplied": [
                                "RULE-CONTENT-001",
                                "RULE-TONE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "blogList",
                        "actor": "customer",
                        "screenType": "page",
                        "purpose": "Listagem de posts do blog organizados por t\xF3picos",
                        "supportsCapabilities": [
                                "blog",
                                "blogProductLinking"
                        ],
                        "rulesApplied": [
                                "RULE-BLOG-001",
                                "RULE-BLOG-002",
                                "RULE-TONE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "blogPost",
                        "actor": "customer",
                        "screenType": "page",
                        "purpose": "Visualiza\xE7\xE3o de post do blog com conte\xFAdo completo e produtos relacionados",
                        "supportsCapabilities": [
                                "blog",
                                "blogProductLinking"
                        ],
                        "rulesApplied": [
                                "RULE-BLOG-001",
                                "RULE-BLOG-002",
                                "RULE-TONE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "contact",
                        "actor": "customer",
                        "screenType": "page",
                        "purpose": "P\xE1gina de contato com informa\xE7\xF5es, WhatsApp clic\xE1vel, hor\xE1rios, endere\xE7o e a\xE7\xE3o 'Como chegar'",
                        "supportsCapabilities": [
                                "contact",
                                "footerContactHighlights"
                        ],
                        "rulesApplied": [
                                "RULE-CONTACT-001",
                                "RULE-CONTACT-002",
                                "RULE-TONE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminLogin",
                        "actor": "staff",
                        "screenType": "login",
                        "isEntryPoint": true,
                        "purpose": "Tela de autentica\xE7\xE3o para acesso \xE0 \xE1rea administrativa",
                        "supportsCapabilities": [
                                "adminProductManagement",
                                "blog",
                                "about",
                                "contact",
                                "catalogAdvancedFilters",
                                "cartCheckoutCtas",
                                "footerContactHighlights"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminDashboard",
                        "actor": "staff",
                        "screenType": "dashboard",
                        "purpose": "Painel administrativo com vis\xE3o geral de produtos, posts e a\xE7\xF5es r\xE1pidas",
                        "supportsCapabilities": [
                                "adminProductManagement",
                                "blog",
                                "about",
                                "contact",
                                "catalogAdvancedFilters",
                                "cartCheckoutCtas",
                                "footerContactHighlights"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminProductList",
                        "actor": "staff",
                        "screenType": "page",
                        "purpose": "Listagem de produtos para gerenciamento com a\xE7\xF5es de editar e remover",
                        "supportsCapabilities": [
                                "adminProductManagement"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-PRODUCT-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminProductEditor",
                        "actor": "staff",
                        "screenType": "editor",
                        "purpose": "Editor para cria\xE7\xE3o e edi\xE7\xE3o de produtos com campos completos de cat\xE1logo",
                        "supportsCapabilities": [
                                "adminProductManagement"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-PRODUCT-001",
                                "RULE-PRODUCT-003",
                                "RULE-PRODUCT-004",
                                "RULE-PRODUCT-005",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminBlogList",
                        "actor": "staff",
                        "screenType": "page",
                        "purpose": "Listagem de posts do blog com indicadores de status editorial (rascunho/publicado)",
                        "supportsCapabilities": [
                                "blog"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-BLOG-001",
                                "RULE-BLOG-003",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminBlogEditor",
                        "actor": "staff",
                        "screenType": "editor",
                        "purpose": "Editor de posts do blog com suporte a rascunho, publica\xE7\xE3o e pr\xE9-visualiza\xE7\xE3o",
                        "supportsCapabilities": [
                                "blog",
                                "blogProductLinking"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-BLOG-001",
                                "RULE-BLOG-002",
                                "RULE-BLOG-003",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminBlogPreview",
                        "actor": "staff",
                        "screenType": "page",
                        "purpose": "Pr\xE9-visualiza\xE7\xE3o do post do blog antes da publica\xE7\xE3o, simulando visualiza\xE7\xE3o do cliente",
                        "supportsCapabilities": [
                                "blog"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-BLOG-003",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminAboutEditor",
                        "actor": "staff",
                        "screenType": "editor",
                        "purpose": "Editor da p\xE1gina 'Sobre N\xF3s' para atualiza\xE7\xE3o de hist\xF3ria e valores",
                        "supportsCapabilities": [
                                "about"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-CONTENT-001",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminContactSettings",
                        "actor": "staff",
                        "screenType": "settings",
                        "purpose": "Configura\xE7\xE3o de informa\xE7\xF5es de contato, WhatsApp, hor\xE1rios, endere\xE7o e link do mapa",
                        "supportsCapabilities": [
                                "contact",
                                "footerContactHighlights"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-CONTACT-001",
                                "RULE-CONTACT-002",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminCatalogSettings",
                        "actor": "staff",
                        "screenType": "settings",
                        "purpose": "Configura\xE7\xE3o de filtros avan\xE7ados do cat\xE1logo (tipos de pet, marcas, faixa de pre\xE7o)",
                        "supportsCapabilities": [
                                "catalogAdvancedFilters"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-PRODUCT-004",
                                "RULE-LANG-001"
                        ]
                },
                {
                        "screenId": "adminCartSettings",
                        "actor": "staff",
                        "screenType": "settings",
                        "purpose": "Configura\xE7\xE3o do caminho de finaliza\xE7\xE3o do carrinho e textos dos CTAs",
                        "supportsCapabilities": [
                                "cartCheckoutCtas"
                        ],
                        "rulesApplied": [
                                "RULE-ROLE-001",
                                "RULE-CART-003",
                                "RULE-LANG-001"
                        ]
                }
        ],
        "journeys": [
                {
                        "journeyId": "customerBrowseAndPurchaseIntent",
                        "actor": "customer",
                        "supportsCapabilities": [
                                "catalog",
                                "cart",
                                "cartCheckoutCtas"
                        ],
                        "steps": [
                                {
                                        "screenId": "home"
                                },
                                {
                                        "screenId": "productCatalog"
                                },
                                {
                                        "screenId": "productDetail",
                                        "params": [
                                                "prodId"
                                        ]
                                },
                                {
                                        "screenId": "cart"
                                },
                                {
                                        "screenId": "productDetail",
                                        "params": [
                                                "prodId"
                                        ]
                                },
                                {
                                        "screenId": "cart"
                                }
                        ]
                },
                {
                        "journeyId": "customerSearchProduct",
                        "actor": "customer",
                        "supportsCapabilities": [
                                "catalog",
                                "catalogAdvancedFilters"
                        ],
                        "steps": [
                                {
                                        "screenId": "home"
                                },
                                {
                                        "screenId": "productCatalog"
                                },
                                {
                                        "screenId": "productDetail",
                                        "params": [
                                                "prodId"
                                        ]
                                }
                        ]
                },
                {
                        "journeyId": "customerExploreBlogAndRelatedProducts",
                        "actor": "customer",
                        "supportsCapabilities": [
                                "blog",
                                "blogProductLinking",
                                "catalog"
                        ],
                        "steps": [
                                {
                                        "screenId": "home"
                                },
                                {
                                        "screenId": "blogList"
                                },
                                {
                                        "screenId": "blogPost",
                                        "params": [
                                                "postId"
                                        ]
                                },
                                {
                                        "screenId": "productDetail",
                                        "params": [
                                                "prodId"
                                        ]
                                }
                        ]
                },
                {
                        "journeyId": "customerContactAndVisitStore",
                        "actor": "customer",
                        "supportsCapabilities": [
                                "contact",
                                "footerContactHighlights"
                        ],
                        "steps": [
                                {
                                        "screenId": "home"
                                },
                                {
                                        "screenId": "contact"
                                },
                                {
                                        "screenId": "home"
                                }
                        ]
                },
                {
                        "journeyId": "customerLearnAboutStore",
                        "actor": "customer",
                        "supportsCapabilities": [
                                "about"
                        ],
                        "steps": [
                                {
                                        "screenId": "home"
                                },
                                {
                                        "screenId": "about"
                                },
                                {
                                        "screenId": "contact"
                                }
                        ]
                },
                {
                        "journeyId": "staffLoginAndDashboard",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "adminProductManagement",
                                "blog",
                                "about",
                                "contact"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                }
                        ]
                },
                {
                        "journeyId": "staffCreateAndPublishProduct",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "adminProductManagement"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminProductList"
                                },
                                {
                                        "screenId": "adminProductEditor"
                                },
                                {
                                        "screenId": "adminProductList"
                                },
                                {
                                        "screenId": "adminDashboard"
                                }
                        ]
                },
                {
                        "journeyId": "staffEditProductCatalog",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "adminProductManagement"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminProductList"
                                },
                                {
                                        "screenId": "adminProductEditor",
                                        "params": [
                                                "prodId"
                                        ]
                                },
                                {
                                        "screenId": "adminProductList"
                                }
                        ]
                },
                {
                        "journeyId": "staffCreateAndPreviewBlogPost",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "blog",
                                "blogProductLinking"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminBlogList"
                                },
                                {
                                        "screenId": "adminBlogEditor"
                                },
                                {
                                        "screenId": "adminBlogPreview",
                                        "params": [
                                                "postId"
                                        ]
                                },
                                {
                                        "screenId": "adminBlogEditor"
                                },
                                {
                                        "screenId": "adminBlogList"
                                }
                        ]
                },
                {
                        "journeyId": "staffPublishDraftBlogPost",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "blog"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminBlogList"
                                },
                                {
                                        "screenId": "adminBlogEditor",
                                        "params": [
                                                "postId"
                                        ]
                                },
                                {
                                        "screenId": "adminBlogPreview",
                                        "params": [
                                                "postId"
                                        ]
                                },
                                {
                                        "screenId": "adminBlogList"
                                }
                        ]
                },
                {
                        "journeyId": "staffUpdateAboutPage",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "about"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminAboutEditor"
                                },
                                {
                                        "screenId": "adminDashboard"
                                }
                        ]
                },
                {
                        "journeyId": "staffConfigureContactAndFooter",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "contact",
                                "footerContactHighlights"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminContactSettings"
                                },
                                {
                                        "screenId": "adminDashboard"
                                }
                        ]
                },
                {
                        "journeyId": "staffConfigureCatalogFilters",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "catalogAdvancedFilters"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminCatalogSettings"
                                },
                                {
                                        "screenId": "adminDashboard"
                                }
                        ]
                },
                {
                        "journeyId": "staffConfigureCartCheckout",
                        "actor": "staff",
                        "supportsCapabilities": [
                                "cartCheckoutCtas"
                        ],
                        "steps": [
                                {
                                        "screenId": "adminLogin"
                                },
                                {
                                        "screenId": "adminDashboard"
                                },
                                {
                                        "screenId": "adminCartSettings"
                                },
                                {
                                        "screenId": "adminDashboard"
                                }
                        ]
                }
        ]
}
\`\`\`
## Capabilities Summary
\`\`\`json
[
        {
                "capabilityId": "catalog",
                "description": "Exibi\xE7\xE3o e explora\xE7\xE3o do cat\xE1logo de produtos (categorias, busca e detalhes).",
                "impliesUI": [
                        {
                                "actionId": "listProducts",
                                "description": "Listar produtos com suporte a categorias."
                        },
                        {
                                "actionId": "searchProducts",
                                "description": "Pesquisar produtos por texto."
                        },
                        {
                                "actionId": "viewProductDetails",
                                "description": "Visualizar detalhes do produto (fotos, descri\xE7\xE3o, pre\xE7o e disponibilidade)."
                        },
                        {
                                "actionId": "filterProducts",
                                "description": "Filtrar produtos por tipo de pet, marca e faixa de pre\xE7o."
                        }
                ]
        },
        {
                "capabilityId": "cart",
                "description": "Carrinho para sele\xE7\xE3o de itens antes de finalizar a compra (externa ou futura).",
                "impliesUI": [
                        {
                                "actionId": "addToCart",
                                "description": "Adicionar produto ao carrinho."
                        },
                        {
                                "actionId": "removeFromCart",
                                "description": "Remover produto do carrinho."
                        },
                        {
                                "actionId": "updateQuantity",
                                "description": "Atualizar quantidade de um item no carrinho."
                        },
                        {
                                "actionId": "viewCart",
                                "description": "Visualizar o carrinho atual."
                        },
                        {
                                "actionId": "viewCheckoutCtas",
                                "description": "Visualizar CTAs de finaliza\xE7\xE3o dispon\xEDveis no carrinho, com explica\xE7\xE3o do pr\xF3ximo passo."
                        }
                ]
        },
        {
                "capabilityId": "about",
                "description": "P\xE1gina institucional 'Sobre N\xF3s' com hist\xF3ria e valores.",
                "impliesUI": [
                        {
                                "actionId": "viewAboutPage",
                                "description": "Visualizar a se\xE7\xE3o 'Sobre N\xF3s'."
                        },
                        {
                                "actionId": "adminEditAboutPage",
                                "description": "Administrador edita hist\xF3ria e valores."
                        }
                ]
        },
        {
                "capabilityId": "blog",
                "description": "Blog com artigos para engajamento e informa\xE7\xE3o.",
                "impliesUI": [
                        {
                                "actionId": "listBlogPosts",
                                "description": "Listar posts do blog."
                        },
                        {
                                "actionId": "viewBlogPost",
                                "description": "Visualizar um post do blog."
                        },
                        {
                                "actionId": "adminCreateBlogPost",
                                "description": "Administrador cria um post."
                        },
                        {
                                "actionId": "adminEditBlogPost",
                                "description": "Administrador edita um post."
                        },
                        {
                                "actionId": "adminPublishBlogPost",
                                "description": "Administrador publica um post."
                        },
                        {
                                "actionId": "adminLinkBlogPostToProducts",
                                "description": "Administrador relaciona um post a produtos relevantes."
                        },
                        {
                                "actionId": "adminLinkBlogPostToCategories",
                                "description": "Administrador relaciona um post a categorias relevantes."
                        },
                        {
                                "actionId": "adminSaveDraftBlogPost",
                                "description": "Administrador salva post como rascunho."
                        },
                        {
                                "actionId": "adminPreviewBlogPost",
                                "description": "Administrador pr\xE9-visualiza o post antes de publicar."
                        }
                ]
        },
        {
                "capabilityId": "contact",
                "description": "P\xE1gina/\xE1rea de contato com informa\xE7\xF5es claras e mapa de localiza\xE7\xE3o (quando houver).",
                "impliesUI": [
                        {
                                "actionId": "viewContactInfo",
                                "description": "Visualizar informa\xE7\xF5es de contato."
                        },
                        {
                                "actionId": "viewMapLocation",
                                "description": "Visualizar/abrir mapa da localiza\xE7\xE3o f\xEDsica, quando houver."
                        },
                        {
                                "actionId": "adminEditContactInfo",
                                "description": "Administrador edita informa\xE7\xF5es de contato e link do mapa."
                        },
                        {
                                "actionId": "viewWhatsAppContact",
                                "description": "Acessar WhatsApp clic\xE1vel quando configurado."
                        },
                        {
                                "actionId": "viewBusinessHours",
                                "description": "Visualizar hor\xE1rios de atendimento quando configurados."
                        },
                        {
                                "actionId": "viewDirections",
                                "description": "Acionar 'Como chegar' quando endere\xE7o/mapa estiverem configurados."
                        }
                ]
        },
        {
                "capabilityId": "adminProductManagement",
                "description": "Administra\xE7\xE3o de produtos e conte\xFAdo do cat\xE1logo.",
                "impliesUI": [
                        {
                                "actionId": "adminCreateProduct",
                                "description": "Administrador cadastra produto."
                        },
                        {
                                "actionId": "adminEditProduct",
                                "description": "Administrador edita produto."
                        },
                        {
                                "actionId": "adminRemoveProduct",
                                "description": "Administrador remove produto."
                        },
                        {
                                "actionId": "adminSetProductPrice",
                                "description": "Administrador define/atualiza o pre\xE7o do produto."
                        },
                        {
                                "actionId": "adminSetProductStockAvailability",
                                "description": "Administrador define/atualiza a disponibilidade de estoque do produto."
                        },
                        {
                                "actionId": "adminSetProductPetType",
                                "description": "Administrador define/atualiza o tipo de pet associado ao produto (quando aplic\xE1vel)."
                        },
                        {
                                "actionId": "adminSetProductBrand",
                                "description": "Administrador define/atualiza a marca do produto (quando aplic\xE1vel)."
                        },
                        {
                                "actionId": "adminSetProductShortHighlight",
                                "description": "Administrador define/atualiza o destaque curto do produto para cards/listagens (quando aplic\xE1vel)."
                        },
                        {
                                "actionId": "adminSetProductPrimaryImage",
                                "description": "Administrador define/atualiza a imagem principal do produto para cards/listagens (quando aplic\xE1vel)."
                        }
                ]
        },
        {
                "capabilityId": "catalogAdvancedFilters",
                "description": "Configura\xE7\xE3o e disponibiliza\xE7\xE3o de filtros avan\xE7ados no cat\xE1logo (tipo de pet, marca e faixa de pre\xE7o).",
                "isOptional": true,
                "impliesUI": [
                        {
                                "actionId": "adminEnableAdvancedFilters",
                                "description": "Administrador habilita/desabilita filtros avan\xE7ados no cat\xE1logo."
                        },
                        {
                                "actionId": "adminConfigureFilterOptions",
                                "description": "Administrador ajusta op\xE7\xF5es e crit\xE9rios de filtragem (ex: quais tipos de pet e marcas aparecem)."
                        }
                ]
        },
        {
                "capabilityId": "blogProductLinking",
                "description": "Relacionar posts do blog a produtos e categorias relevantes para conectar conte\xFAdo e cat\xE1logo.",
                "isOptional": true,
                "impliesUI": [
                        {
                                "actionId": "showRelatedProductsOnBlogPost",
                                "description": "Exibir produtos relacionados ao final (ou em \xE1rea dedicada) de um post do blog."
                        },
                        {
                                "actionId": "showRelatedBlogPostsOnCategory",
                                "description": "Exibir posts do blog relacionados ao navegar por uma categoria de produto."
                        }
                ]
        },
        {
                "capabilityId": "cartCheckoutCtas",
                "description": "Configurar e apresentar CTAs de finaliza\xE7\xE3o no carrinho alinhados ao caminho de compra escolhido (ex.: WhatsApp/parceiro), com texto explicativo do que acontece ao clicar.",
                "isOptional": true,
                "impliesUI": [
                        {
                                "actionId": "adminConfigureCheckoutPath",
                                "description": "Administrador configura o caminho de finaliza\xE7\xE3o do carrinho (ex.: WhatsApp, parceiro, outro)."
                        },
                        {
                                "actionId": "adminConfigureCheckoutCtaText",
                                "description": "Administrador define textos do CTA e explica\xE7\xE3o do pr\xF3ximo passo para o cliente."
                        },
                        {
                                "actionId": "showCheckoutCtasInCart",
                                "description": "Exibir CTAs de finaliza\xE7\xE3o no carrinho conforme configura\xE7\xE3o."
                        }
                ]
        },
        {
                "capabilityId": "footerContactHighlights",
                "description": "Destacar no rodap\xE9 e em \xE1reas de contato: WhatsApp clic\xE1vel, hor\xE1rios, endere\xE7o e a\xE7\xE3o 'Como chegar' quando houver localiza\xE7\xE3o configurada.",
                "isOptional": true,
                "impliesUI": [
                        {
                                "actionId": "adminEnableFooterContactHighlights",
                                "description": "Administrador habilita/desabilita destaques de contato no rodap\xE9."
                        },
                        {
                                "actionId": "showFooterWhatsApp",
                                "description": "Exibir WhatsApp clic\xE1vel no rodap\xE9 quando configurado."
                        },
                        {
                                "actionId": "showFooterBusinessHours",
                                "description": "Exibir hor\xE1rios no rodap\xE9 quando configurados."
                        },
                        {
                                "actionId": "showFooterAddressAndDirections",
                                "description": "Exibir endere\xE7o e a\xE7\xE3o 'Como chegar' no rodap\xE9 quando endere\xE7o/mapa estiverem configurados."
                        }
                ]
        }
]
\`\`\`

`;
export {
  createAgent,
  getPayloadToBePages,
  systemExperienceConstraints
};
