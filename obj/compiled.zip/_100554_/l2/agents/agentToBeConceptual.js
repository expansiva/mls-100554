/// <mls shortName="agentToBeConceptual" project="100554" enhancement="_100554_enhancementAgent" folder="agents" />
export function createAgent() {
    return {
        agentName: "agentToBeConceptual",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Create New ToBe Conceptual",
        visibility: "private",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const inTest = true; // todo: resolve
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system2.replace("{{outputPrompt}}", outputPrompt)
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: inTest ? `test ${agent.agentName}` : 'defining ToBe conceptual',
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type === "result") {
        throw new Error(payload?.result);
    }
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    try {
        const output = payload.result;
        intents = await processToBe(output);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function processToBe(moduleToBe) {
    console.log("=== processToBe");
    console.log(JSON.stringify(moduleToBe, null, 2));
    const step = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'pending',
        nextSteps: [],
        agentName: "agentToBeConceptual2",
        prompt: "",
        rags: null,
    };
    // const rc: mls.msg.AgentIntentAddSteps = {
    //   type: 'add-steps',
    //   steps: [step]
    // }
    return [];
}
const system2 = `
<!-- modelType: claude -->
<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) ou nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10, code2 (kimi 2.5) -->

You are a Senior Software Engineer at Collab.codes, with 25 years of hands-on experience building scalable, maintainable systems in production environments. You have led architecture decisions, code reviews, and refactors in multiple companies, always prioritizing clean design, performance, security, and long-term maintainability over quick hacks.

You will receive a user request to create a new module, followed by a clarification section containing questions and answers that provide additional context, constraints, requirements, or refinements to the original request.

Task:
Generate an ToBeFactual JSON object that strictly follows the provided JSON schema.

## Details
[[Constraints]]

{{outputPrompt}}

[[Defs1]]
`;
export const outputPrompt = `
## Output format
You must return the object strictly as JSON
[[OutputSection]]
`;
//#region Constraints
const constraints = [
    'Output MUST be valid JSON only.',
    'NO indentation, NO newlines except when strictly required by JSON syntax.',
    'NO extra spaces or whitespace.',
];
//#endregion
