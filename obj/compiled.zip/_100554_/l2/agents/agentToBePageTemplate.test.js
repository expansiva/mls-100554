const tests = [];
globalThis.__BE_DRIVER__ = {
  async invoke(routine, params, requestId) {
    await delay(100);
    return {
      requestId,
      error: "Mock not implemented: " + routine
    };
  }
};
globalThis.__BE_LOCAL_CACHE__ = /* @__PURE__ */ new Map();
function mountPage() {
  document.body.innerHTML = "";
  const element = document.createElement(
    "[page-tag-name]"
  );
  document.body.appendChild(element);
}
const icanTest1 = {
  functionName: "test1",
  params: [{ "id": 123 }]
};
tests.push(icanTest1);
async function test1(id) {
  mountPage();
  await delay(300);
}
const icanTest2 = {
  functionName: "test2",
  params: [{ "id": 123 }]
};
tests.push(icanTest2);
async function test2(id) {
  mountPage();
  await delay(500);
}
function createMockEntity(params) {
  return {
    id: params.id,
    name: "Example Entity"
  };
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
export {
  tests
};
