/// <mls shortName="agentDefs" project="100554" enhancement="_100554_enhancementAgent" folder="agents" />
import { getSource } from '/_100554_/l2/aiPrompts.js';
export function createAgent() {
    return {
        agentName: "agentDefs",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Create or Update Defs",
        visibility: "public",
        beforePromptAtomic,
        afterPromptStep
    };
}
async function beforePromptAtomic(agent, context, file, userPrompt) {
    if (userPrompt)
        throw new Error(`[beforePromptAtomic] invalid args: '${userPrompt}'`);
    const source = await getSource(file);
    if (typeof source !== 'string' || !source)
        throw new Error(`[beforePromptAtomic] invalid source`);
    // const inputs: mls.msg.IAMessageInputType[] = await getPromptByTS({
    //   project: agent.agentProject, shortName: agent.agentName, folder: agent.agentFolder, data: {
    //     system1, // parse systemPrompt
    //     userPrompt: source
    //   }
    // });
    const inputs = [
        { type: "system", content: system1 },
        { type: "human", content: source }
    ];
    // await startNewAiTaskAsync(
    //   "generating defs...",
    //   agent,
    //   context.message.content,
    //   inputs,
    //   context);
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: `Generating defs file ${mls.stor.getShortPath(file)}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {}
        }
    };
    return [addMessageAI];
}
;
async function afterPromptStep(agent, context, step) {
    console.log('afterPromptStep ', step);
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid args`);
    const updateStatus = {
        type: 'update-status',
        step,
        status: "completed"
    };
    return [updateStatus];
}
const system1 = `
<!-- modelType: code -->
<!-- modelTypeList: geminiChat, code (grok), deepseekchat, codeflash, deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct -->

You are a Senior Software Engineer at Collab.codes.

Your task is to analyze the TypeScript code provided in the user message and generate structured documentation (BaseDefs) for the component.

This documentation will be used for search, filtering, and AI-driven development workflows.

## Details
[[SudoLang]]

## Output format
You must return the object strictly as JSON
[[OutputSection]]

[[Defs1]]
[[Defs2]]
[[Defs3]]
`;
//#region SudoLang
const constraints = [
    'Always output valid JSON only.',
    'NO indentation, NO newlines except when strictly required by JSON syntax.',
    'NO extra spaces or whitespace.',
    'Only include data that can be directly and confidently derived from the code',
    'Only include states that start with "db." or "ui." prefix, as these are the global states',
    'Only declare imports and dependencies that are ACTUALLY present in the code. Do NOT invent or assume any imports/dependencies.'
];
//#endregion
