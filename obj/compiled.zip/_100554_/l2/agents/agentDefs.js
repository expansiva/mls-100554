/// <mls shortName="agentDefs" project="100554" enhancement="_blank" folder="agents" />
import { svg_agent } from '/_100554_/l2/aiAgentBase.js';
import { getNextInProgressStepByAgentName, updateStepStatus, getNextPendentStep, notifyTaskChange } from "/_100554_/l2/aiAgentHelper.js";
import { startNewAiTaskAsync, executeNextStep } from "/_100554_/l2/aiAgentOrchestration.js";
import { getSource, getPromptByTS } from '/_100554_/l2/aiPrompts.js';
const agentProject = 100554;
const agentFolder = "agents";
const agentName = "agentDefs";
export function createAgent() {
    return {
        agentName,
        agentProject,
        agentFolder,
        avatar_url: svg_agent,
        agentDescription: "Create or Update Defs",
        visibility: "public",
        async beforePromptAtomic(context, file, userPrompt) {
            if (userPrompt)
                throw new Error("[beforePromptAtomic] invalid args: '${userPrompt}'");
            const source = await getSource(file);
            if (typeof source !== 'string' || !source)
                throw new Error(`[beforePromptAtomic] invalid source`);
            const inputs = await getPromptByTS({
                project: agentProject, shortName: agentName, folder: agentFolder, data: {
                    system1, // parse systemPrompt
                    userPrompt: source
                }
            });
            await startNewAiTaskAsync("generating defs...", this, context.message.content, inputs, context);
            return [];
        },
        // async beforePrompt(context: mls.msg.ExecutionContext): Promise<void> {
        //   // only accept if this agent is the first agent
        //   try {
        //     return await initNewTaskFromUserInput(context,
        //       this, // IAgent
        //       {
        //         taskTitle: "generating defs...",
        //         acceptFreePrompt: false,
        //         systemForFreePrompt: null,
        //         commands: [{ commandName: "update", system: system1, human: humanCommandUpdate }], // update all files in project
        //         jsons: [{ schemeType: 'ref', system: system1 }] // atomic , 1 ref
        //       }
        //     );
        //   } catch (e) {
        //     console.log("[beforePrompt] error", e);
        //   }
        // },
        // async afterPrompt(context: mls.msg.ExecutionContext): Promise<void> {
        //   return _afterPrompt(context);
        // },
    };
}
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No step for this agent`);
    context = await updateStepStatus(context, step.stepId, "completed");
    if (!context.task)
        throw new Error("Invalid context task");
    const payload = getNextPendentStep(context.task);
    // context = await updateDefs(context, payload);
    notifyTaskChange(context);
    await executeNextStep(context);
};
export const humanCommandUpdate = ``;
export const system1 = `
<!-- modelType: codeflash -->
<!-- modelTypeList: geminiChat, code (grok), deepseekchat, codeflash, deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct -->

You are a Senior Software Engineer at Collab.codes.

Your task is to analyze the TypeScript code provided in the user message and generate structured documentation (BaseDefs) for the component.

This documentation will be used for search, filtering, and AI-driven development workflows.

## Details
[[SudoLang]]

## Output format
You must return the object strictly as JSON
[[OutputSection]]

[[Defs1]]
[[Defs2]]
[[Defs3]]
`;
//#region SudoLang
const constraints = [
    'Always output valid JSON only.',
    'NO indentation, NO newlines except when strictly required by JSON syntax.',
    'NO extra spaces or whitespace.',
    'Only include data that can be directly and confidently derived from the code',
    'Only include states that start with "db." or "ui." prefix, as these are the global states',
    'Only declare imports and dependencies that are ACTUALLY present in the code. Do NOT invent or assume any imports/dependencies.'
];
//#endregion
