/// <mls shortName="agentDefs" project="100554" enhancement="_100554_enhancementAgent" folder="agents" />
import { createModel } from '/_100554_/l2/collabLibModel.js';
export function createAgent() {
    return {
        agentName: "agentDefs",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Create or Update Defs",
        visibility: "public",
        beforePromptAtomic,
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptAtomic(agent, context, file, userPrompt) {
    if (userPrompt)
        throw new Error(`[beforePromptAtomic] invalid args: '${userPrompt}'`);
    const inputs = [
        { type: "system", content: system1 },
        { type: "human", content: await getSource(file) }
    ];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: `Generating defs file ${mls.stor.getShortPath(file)}`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {}
        }
    };
    return [addMessageAI];
}
;
async function beforePromptImplicit(agent, context, userPrompt) {
    if (userPrompt !== "update")
        throw new Error(`[afterPromptImplicit] Use one of this commands: "update"`);
    const paths = mls.stor.findFilesNeedingDefsUpdate({ project: mls.actualProject || 0, level: 2 })
        .map(f => mls.stor.getKeyToFile(f))
        .filter(Boolean)
        .slice(0, 20); // only x first 
    if (paths.length < 1)
        throw new Error('no files to update defs');
    const inputs = [
        { type: "system", content: system1 },
    ];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: `Generating defs for ${paths.length} files`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        },
        executionMode: {
            type: 'parallel',
            args: paths
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[beforePromptStep] args invalid`);
    const file = mls.stor.files[args];
    const continueParallel = {
        type: "continue-parallel-step",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: await getSource(file)
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    try {
        const asIs = payload.result;
        await updateDefs(asIs);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [updateStatus];
}
async function getSource(file) {
    // change first line to new pattern
    if (!file)
        throw new Error(`[beforePromptStep] invalid args, file dont exists`);
    const source = (await file.getContent());
    if (typeof source !== 'string' || !source)
        throw new Error(`[beforePromptAtomic] invalid source`);
    const array = source.split("\n");
    if (!array || array.length < 2)
        throw new Error('[beforePrompt] invalid source, no lines');
    const fileReference = mls.stor.convertFileToFileReference(file);
    if (!array[0].includes('fileReference')) {
        const tp = mls.common.tripleslash.parseXMLTripleSlash(array[0]).variables;
        array[0] = `/// <mls fileReference="${fileReference}" group=${tp.group || ""} enhancement=${tp.enhancemente || ""} />`;
    }
    return `
FILE: ${fileReference}
LANG: typescript
BEGIN_CODE
${array.map(f => f.trim()).filter(Boolean).join("\n")}
END_CODE
`;
}
async function updateDefs(defs) {
    const fileReference = defs?.meta?.fileReference || "";
    let fileInfo = mls.stor.convertFileReferenceToFile(fileReference);
    if (!fileReference || fileInfo.project < 1)
        throw new Error(`Invalid step in update defs, incorrect meta fileRecerence: ${fileReference}`);
    const template = `/// <mls fileReference="${defs.meta.fileReference}" enhancement="_blank" />

// Do not change – automatically generated code. 

export const asis: mls.defs.AsIs = ${JSON.stringify(defs, null, 2)}
    `;
    const files = await mls.stor.getFiles({ ...fileInfo, loadContent: false });
    if (!files.ts)
        throw new Error(`[agentDefs] file .ts dont exists, defs: ${JSON.stringify(defs.meta)}`);
    const params = { ...fileInfo, content: template, versionRef: '0', extension: ".defs.ts" };
    if (!files.defs) {
        await createStorFile(params);
    }
    else {
        await updateStorFile(params);
    }
}
async function createStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentDefs] Invalid storFile');
    const path = mls.stor.getKeyToFile(params);
    console.log(`[agentDefs] creating new file: ${path}`);
    file.status = 'new';
    const fileInfo = {
        content: params.content,
        contentType: 'string',
    };
    await mls.stor.localStor.setContent(file, fileInfo);
    file.updatedAt = new Date().toISOString();
    return file;
}
async function updateStorFile(params) {
    const file = await mls.stor.addOrUpdateFile(params);
    if (!file)
        throw new Error('[agentDefs] Invalid storFile');
    const path = mls.stor.getKeyToFile(params);
    console.log(`[agentDefs] updating file: ${path}`);
    const models = mls.editor.getModels(params.project, params.shortName, params.folder, params.level);
    if (!models || !models.defs) {
        const modelDefs = await createModel(file, false, false);
        if (!modelDefs)
            throw new Error('[agentDefs] model .defs not created');
        modelDefs.model.setValue(params.content);
    }
    else {
        models.defs.model.setValue(params.content);
    }
    file.updatedAt = new Date().toISOString();
}
const system1 = `
<!-- modelType: codeflash -->
<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) ou nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10-->

You are a Senior Software Engineer at Collab.codes.

You will receive a user message containing:
FILE, LANG, and a code block delimited by BEGIN_CODE and END_CODE.

Task:
Generate an AsIsFactual JSON object that strictly follows the provided JSON schema.

## Details
[[SudoLang]]

## Output format
You must return the object strictly as JSON
[[OutputSection]]

[[Defs1]]
[[Defs2]]
[[Defs3]]
`;
//#region SudoLang
const constraints = [
    'Output MUST be valid JSON only.',
    'NO indentation, NO newlines except when strictly required by JSON syntax.',
    'NO extra spaces or whitespace.',
    'Any text outside JSON is a failure.',
    'Only extract information that appears literally in the provided code.',
    'No interpretation, no abstraction, no normalization.',
    'If something is not explicitly declared in code, it MUST NOT appear in the output.',
    'Do NOT create empty arrays or placeholder values.',
    'Do NOT populate optional fields unless data is explicitly present.',
    'Only list imports and dependencies that can be verified line-by-line in the code.',
    'Only list state paths that appear verbatim in the code and start with "db." or "ui.".',
    'If uncertain, omit.'
];
//#endregion
