/// <mls fileReference="_100554_/l2/agents/agentBackendMaterializationPlan.defs.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
