/// <mls fileReference="_100554_/l2/agents/agentToBeConceptual2.ts" enhancement="_100554_enhancementAgent" />
export function createAgent() {
    return {
        agentName: "agentToBeConceptual2",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Improve ToBe conceptual",
        visibility: "private",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system3
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: `test ${agent.agentName}`,
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    try {
        const output = payload.result;
        intents = await processOutput3(output);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [];
    // return [...intents, updateStatus];
}
async function processOutput3(moduleToBe) {
    console.log("=== Suggestions");
    console.log(JSON.stringify(moduleToBe, null, 2));
    const inTest = true; // todo: define
    if (inTest)
        return [];
    const step = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'pending',
        nextSteps: [],
        agentName: "agentToBeConceptual3",
        prompt: "",
        rags: null,
    };
    // const rc: mls.msg.AgentIntentAddSteps = {
    //   type: 'add-steps',
    //   steps: [step]
    // }
    return [];
}
/*
"t1, gemini-2.5-pro, 35s, $0.0113, 8.1/10", **business**
"t2, gpt-5.2, 21s, $0.0267, 9/10",
"t3, kimi-2.5, 35s, $0.0050, 7.4/10",
"t4, grok-code-fast-1, 6s, $0.0015, 6.8/10"
*/
const system3 = `
<!-- modelType: geminiChat -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior BUSINESS Analyst with 20+ years of experience in system design, requirements analysis, and business process optimization.

Your task is to review a generated TO-BE conceptual model and identify between 1 and 20 business improvements.

Focus on gaps, enhancements, or opportunities related to:
- Business capabilities
- Policies and rules
- Customer experience
- Revenue, retention, or operational efficiency

## CRITICAL INSTRUCTIONS
- Each suggestion MUST be a short, business-focused command (imperative form).
- Keep each suggestion under 250 characters.
- Focus ONLY on business value.
- Do NOT mention technical implementation, frameworks, or architecture.
- Do NOT explain the suggestions.
- All field names and keys MUST be in English.,
- All suggestions must be written in the language specified by the "userLanguage" field.

## OPTIONAL SUGGESTIONS
- Some suggestions may represent OPTIONAL or CONFIGURABLE capabilities that can be enabled or disabled by the client via an admin interface.

## Output format
You must return the object strictly as JSON
[[OutputSection]]
`;
//#endregion
