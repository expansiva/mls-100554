/// <mls shortName="agentNewModule" project="100554" enhancement="_blank" folder="agents" />
export const integrations = [];
export const tests = [];
