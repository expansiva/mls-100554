/// <mls fileReference="_100554_/l2/agents/agentToBeOrganism.ts" enhancement="_100554_enhancementAgent" />
import { systemExperienceConstraints } from "/_100554_/l2/agents/agentToBePages.js";
import { systemSkillAura } from "/_100554_/l2/agents/agentToBePage.js";
const templateReference = "_100554_/l2/agents/agentToBeOrganismTemplate.ts";
const templateReferenceTest = "_100554_/l2/agents/agentToBeOrganismTemplate.test.ts";
function createAgent() {
  return {
    agentName: "agentToBeOrganism",
    agentProject: 100554,
    agentFolder: "agents",
    agentDescription: "Implement Page",
    visibility: "private",
    beforePromptImplicit,
    afterPromptStep
  };
}
async function beforePromptImplicit(agent, context, userPrompt) {
  if (!userPrompt || userPrompt.length < 5) throw new Error("invalid prompt");
  const templatePage = await loadTemplate(templateReference);
  const templateTest = await loadTemplate(templateReferenceTest);
  const addMessageAI = {
    type: "add-message-ai",
    request: {
      action: "addMessageAI",
      agentName: agent.agentName,
      inputAI: [{
        type: "system",
        content: system1.replace("{{systemExperienceConstraints}}", systemExperienceConstraints).replace("{{systemSkillAura}}", systemSkillAura).replace("{{templatePage}}", templatePage).replace("{{templateTest}}", templateTest)
      }, {
        type: "human",
        content: userPrompt
      }],
      taskTitle: agent.agentDescription,
      threadId: context.message.threadId,
      userMessage: `test ${agent.agentName}`,
      longTermMemory: {}
    }
  };
  return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
  if (!agent || !context || !step) throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
  const payload = step.interaction?.payload?.[0] || void 0;
  if (payload?.type !== "flexible" || !payload.result) throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
  let status = "completed";
  let intents = [];
  try {
    const output = payload.result;
    intents = await processOutput(output);
  } catch (e) {
    console.error(e);
    status = "failed";
  }
  const updateStatus = {
    type: "update-status",
    hookSequential,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || "",
    parentStepId: parentStep.stepId,
    stepId: step.stepId,
    status
  };
  return [...intents, updateStatus];
}
async function loadTemplate(fileReference) {
  const info = mls.stor.convertFileReferenceToFile(fileReference);
  const key = mls.stor.getKeyToFile(info);
  let templatePage = await mls.stor.files[key]?.getContent("");
  if (typeof templatePage !== "string" || !templatePage) throw new Error(`Template not found: ${fileReference}`);
  templatePage = "\n```typescript\n" + templatePage.replace(/```/g, "'''") + "\n```\n";
  return templatePage;
}
async function processOutput(implementPages) {
  const inTest = true;
  console.log("=== Page ");
  console.log(implementPages?.pageSource?.join("\n"));
  if (inTest) return [];
  const step = {
    type: "agent",
    stepId: 0,
    interaction: null,
    status: "pending",
    nextSteps: [],
    agentName: "agentToBeConceptual3",
    prompt: "",
    rags: null
  };
  return [];
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior Frontend Architect and Staff Software Engineer with 20+ years of experience building large-scale web applications using TypeScript, Lit, and state-driven architectures.

You must generate production-ready code that compiles without errors.

Task: Generate a organism given 'Experience Model Organism' and 'PageDefs' and 'Template Page'.

{{systemExperienceConstraints}}

{{systemSkillAura}}

## Template Page
{{templatePage}}

## Template Test
{{templateTest}}

## Output format
You must return the object strictly as JSON, no spaces, no indent, minified
export type Output = {
  type: "flexible";
  result: ImplementPages;
};
export interface ImplementPages {
  pageSource: string[];
  // follow 'Template Page'

  testSource: string[];
  // follow 'Template Test'

  codeInsights?: {
    todos?: string[];
    securityWarnings?: string[];
    unusedImports?: string[];
    accessibilityIssues?: string[];
    i18nWarnings?: string[]; // strings that should be translated, only if i18n is enabled and if string is essential
    performanceHints?: string[];
  };

  moleculesToCreate: MoleculesToCreate[];
}
export interface MoleculesToCreate {

  moleculeName: string;
  // Must be prefixed with "molecule", in camelCase.

  purpose: string;
  // Short, description of what the molecule renders or controls.

  businessCapabilities: string[];
  technicalCapabilities: string[];
  implementedFeatures: string[];
  constrains: string[];

  properties?: string[];
}
`;
export {
  createAgent
};
