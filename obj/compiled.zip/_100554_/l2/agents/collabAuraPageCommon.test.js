/// <mls fileReference="_100554_/l2/agents/collabAuraPageCommon.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
// example of tests
