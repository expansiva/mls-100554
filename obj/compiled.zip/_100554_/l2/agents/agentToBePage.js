/// <mls fileReference="_100554_/l2/agents/agentToBePage.ts" enhancement="_100554_enhancementAgent" />
import { systemExperienceConstraints } from "/_100554_/l2/agents/agentToBePages.js";
import { getPayloadToBeConceptual3 } from "/_100554_/l2/agents/agentToBeConceptual3.js";
import { getPayloadToBePages } from "/_100554_/l2/agents/agentToBePages.js";
const templateReference = "_100554_/l2/agents/agentToBePageTemplate.ts";
const templateReferenceTest = "_100554_/l2/agents/agentToBePageTemplate.test.ts";
function createAgent() {
  return {
    agentName: "agentToBePage",
    agentProject: 100554,
    agentFolder: "agents",
    agentDescription: "Implement Page",
    visibility: "private",
    beforePromptImplicit,
    beforePromptStep,
    afterPromptStep
  };
}
async function beforePromptImplicit(agent, context, userPrompt) {
  if (!userPrompt) throw new Error("invalid prompt");
  let toBePages = {
    pages: []
  };
  if (userPrompt === "test") toBePages = pagesForTest;
  else toBePages = JSON.parse(userPrompt);
  const paths = toBePages.pages.map((page) => page.pageName).slice(0, 1);
  const templatePage = await loadTemplate(templateReference);
  const templateTest = await loadTemplate(templateReferenceTest);
  const inputs = [{
    type: "system",
    content: system1.replace("{{systemExperienceConstraints}}", systemExperienceConstraints).replace("{{systemSkillAura}}", systemSkillAura).replace("{{templatePage}}", templatePage).replace("{{templateTest}}", templateTest)
  }];
  const addMessageAI = {
    type: "add-message-ai",
    request: {
      action: "addMessageAI",
      agentName: agent.agentName,
      inputAI: inputs,
      taskTitle: agent.agentDescription,
      threadId: context.message.threadId,
      userMessage: context.message.content,
      longTermMemory: {}
    },
    executionMode: {
      type: "parallel",
      args: paths
    }
  };
  return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
  if (!args) throw new Error(`[beforePromptStep] args invalid`);
  let toBePages;
  let moduleToBe;
  console.info({ args });
  try {
    toBePages = getPayloadToBePages(context);
    moduleToBe = getPayloadToBeConceptual3(context);
  } catch (err) {
    toBePages = pagesForTest;
    moduleToBe = toBeConceptualTest;
  }
  if (!toBePages || !moduleToBe) throw new Error(`[${agent.agentName}] [beforePromptStep] no toBePages/moduleToBe found`);
  const actualPage = toBePages.pages.find((page) => page.pageName === args);
  console.info({ toBePages, actualPage, moduleToBe, args });
  const continueParallel = {
    type: "prompt_ready",
    args,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || "",
    hookSequential,
    parentStepId: parentStep.stepId,
    humanPrompt: `
## Experience Model Page
\`\`\`json
${JSON.stringify(actualPage)}

\`\`\`
## ToBe Summary
\`\`\`json
${JSON.stringify(moduleToBe)}
\`\`\`
    `
  };
  return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
  if (!agent || !context || !step) throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
  const payload = step.interaction?.payload?.[0] || void 0;
  if (payload?.type !== "flexible" || !payload.result) throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
  let status = "completed";
  let intents = [];
  try {
    const output = payload.result;
    intents = await processOutput(context, output);
  } catch (e) {
    console.error(e);
    status = "failed";
  }
  const updateStatus = {
    type: "update-status",
    hookSequential,
    messageId: context.message.orderAt,
    threadId: context.message.threadId,
    taskId: context.task?.PK || "",
    parentStepId: parentStep.stepId,
    stepId: step.stepId,
    status
  };
  return [...intents, updateStatus];
}
async function loadTemplate(fileReference) {
  const info = mls.stor.convertFileReferenceToFile(fileReference);
  const key = mls.stor.getKeyToFile(info);
  let templatePage = await mls.stor.files[key]?.getContent("");
  if (typeof templatePage !== "string" || !templatePage) throw new Error(`Template not found: ${fileReference}`);
  templatePage = "\n```typescript\n" + templatePage.replace(/```/g, "'''") + "\n```\n";
  return templatePage;
}
async function processOutput(context, implementPages) {
  console.log("=== Page ");
  console.info(implementPages);
  console.log(implementPages?.pageSource?.join("\n"));
  if (context.isTest) return [];
  await updateFiles(implementPages);
  const step = {
    type: "agent",
    stepId: 0,
    interaction: null,
    status: "pending",
    nextSteps: [],
    agentName: "agentToBeConceptual3",
    prompt: "",
    rags: null
  };
  return [];
}
async function updateFiles(implementPages) {
  const fileReference = implementPages?.pageSource?.join("\n").trim().split("\n")[0];
  const tripleSlash = mls.common.tripleslash.parseXMLTripleSlash(fileReference);
  let fileInfo = mls.stor.convertFileReferenceToFile(tripleSlash.variables["fileReference"]);
  if (!fileReference || fileInfo.project < 1) throw new Error(`Invalid step in create file, incorrect meta fileRecerence: ${fileReference}`);
  const paramsTs = { ...fileInfo, content: implementPages?.pageSource?.join("\n"), versionRef: (/* @__PURE__ */ new Date()).toISOString(), extension: ".ts" };
  const paramsTestTs = { ...fileInfo, content: implementPages?.testSource?.join("\n"), versionRef: (/* @__PURE__ */ new Date()).toISOString(), extension: ".test.ts" };
  await createStorFile(paramsTs);
  await createStorFile(paramsTestTs);
}
async function createStorFile(params) {
  const file = await mls.stor.addOrUpdateFile(params);
  if (!file) throw new Error("[agentToBePage] Invalid storFile");
  const path = mls.stor.getKeyToFile(params);
  console.log(`[agentToBePage] creating new file: ${path}`);
  file.status = "new";
  const fileInfo = {
    content: params.content,
    contentType: "string"
  };
  file.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
  await mls.stor.localStor.setContent(file, fileInfo);
  return file;
}
async function getSystem() {
  const templatePage = await loadTemplate(templateReference);
  const templateTest = await loadTemplate(templateReferenceTest);
  return system1.replace("{{systemExperienceConstraints}}", systemExperienceConstraints).replace("{{systemSkillAura}}", systemSkillAura).replace("{{templatePage}}", templatePage).replace("{{templateTest}}", templateTest);
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat ?/10 , code (grok) ?/10, deepseekchat ?/10, codeflash (gemini) ?/10, deepseekreasoner ?/10, mini (4.1) ou nano (openai) ?/10, codeinstruct (4.1) ?/10, codereasoning(gpt5) ?/10, code2 (kimi 2.5) ?/10 -->

You are a senior Frontend Architect and Staff Software Engineer with 20+ years of experience building large-scale web applications using TypeScript, Lit, and state-driven architectures.

You must generate production-ready code that compiles without errors.

Task: Generate a page and descriptions to organisms given 'Experience Model Page' and 'ToBe Summary' and 'Template Page'.

{{systemExperienceConstraints}}

{{systemSkillAura}}

## Template Page
{{templatePage}}

## Template Test
{{templateTest}}

## Output format
You must return the object strictly as JSON, no spaces, no indent, minified
export type Output = {
  type: "flexible";
  result: ImplementPages;
};
export interface ImplementPages {
  pageSource: string[];
  // follow 'Template Page'

  testSource: string[];
  // follow 'Template Test'

  codeInsights?: {
    todos?: string[];
    securityWarnings?: string[];
    unusedImports?: string[];
    accessibilityIssues?: string[];
    i18nWarnings?: string[]; // strings that should be translated, only if i18n is enabled and if string is essential
    performanceHints?: string[];
  };

  organismsToCreate: OrganismToCreate[];
  pluginsToCreate?: PluginToCreate[];
}
export interface OrganismToCreate {

  organismName: string;
  // Must be prefixed with the pageName in camelCase.

  imports: string[];
  // List of modules or types the organism must import.

  states: string[];
  // List of all global state keys the organism will access.
  // Must use the pageState type, ex: 'page.user.name'

  purpose: string;
  // Short, single-responsibility description of what the organism renders or controls.
  // Must describe UI responsibility, not business logic.

  supportsCapabilities: string[];
  // List of capability IDs supported by this organism.

  rulesApplied?: string[];
  // List of rule IDs that influence this organism's behavior or presentation.

  fieldsets?: string[];
  // Optional: list of thematic groups inside this organism
  // (e.g. ["Personal Data", "Addresses", "Preferences"])
  // Each string represents a <fieldset> + <legend> grouping of related form fields.
  // Used only when the organism contains a complex form that benefits from semantic grouping.

}
export interface PluginToCreate {

  pluginName: string;
  // Example: pluginWhatsAppConsultation

  contractName: string;
  // Example: whatsapp

  purpose: string;
  // What the plugin does

  methods: PluginMethod[];

  supportsCapabilities: string[];

  rulesApplied?: string[];

}
export interface PluginMethod {

  methodName: string;
  // Example: openConsultation
  // pluginInvoke("whatsapp.openConsultation", {...})

  params: string[];

  returnType: string;

}
`;
const systemSkillAura = `
## Skill \u2014 Frontend Architecture \u2014 Collab Aurea

This document defines the official frontend architecture, design principles, and responsibilities for building applications using Collab Aurea.
All components, pages, and integrations MUST follow these rules.

## Core Architecture Principles
### Atomic Design Structure
The frontend follows Atomic Design, with the following hierarchy:
- Page \u2192 Top-level screen and orchestration layer
- Organism \u2192 Complex UI sections composed of molecules and plugins
- Molecule \u2192 Reusable UI components, presentation-only
- Plugin \u2192 Integration components that communicate with external services
Each level has a strict responsibility and separation of concerns.

### Technology Stack
- Use Lit 3 to build Web Components
- Do NOT use Shadow DOM
- Use Tailwind CSS for styling
- Use SPA (Single Page Application) architecture
- Each page corresponds to a URL entry point

### Backend Communication Model
Follow the BFF (Backend for Frontend) pattern.
Frontend MUST communicate with backend routines using the BFF abstraction layer.
All backend communication MUST go through the frontend backend gateway (beInvoke or equivalent).
Direct backend calls outside this abstraction are NOT allowed.

### Data Fetching Strategy
Use Stale-While-Revalidate (SWR) strategy for optimal perceived performance.
This means:
- First attempt to load data from local IndexedDB (fast response)
- Mark data consistency as "stale"
- Then fetch fresh data from backend
- Update state and IndexedDB when backend responds
- Mark data consistency as "fresh"
This improves performance and user experience.

## State Management
Global state is used by pages and organisms.
State naming:
ui.[pageName].[stateName]
Examples:
ui.productDetail.product  
ui.productDetail.productConsistency  
ui.productDetail.onLoadMore  
State types:
- Data state \u2192 holds UI data
- Event state \u2192 triggers actions (example: onUpdateUser)
Rules:
- Pages MUST NOT pass data to organisms via properties, prefer states.
- Molecules MUST NOT access global state.

## Page Definitions
A Page is a Web Component responsible for orchestrating the entire screen.
Responsibilities:
- Entry point of the user interface
- Each page corresponds to a URL
- Render the overall layout
- Render organisms and plugins
- Own business logic
- Communicate with backend using BFF
- Manage state lifecycle
- Define state contracts for child organisms
- Implement data fetching using SWR pattern
Pages MUST:
- Follow business rules
- Render SPA-compatible HTML
- Render organisms and sections inside a root <div>
- Orchestrate tabs and conditional content if needed
- Update state based on backend responses
Pages MUST NOT:
- Contain reusable UI logic that belongs in organisms
- Contain reusable UI components that belong in molecules
Testing:
Each page MUST have a corresponding test file:
pageName.test.ts
Tests MUST verify:
- Business logic
- State transitions
- Backend communication behavior

## Organism Definitions
Organisms are Web Components responsible for rendering complex UI sections.
Responsibilities:
- Render layout sections
- Combine molecules and plugins
- Receive data via global states
- Emit events via state updates
Organisms MUST:
- Follow defined property contracts
- Be reusable within the project
Organisms MUST NOT:
- Communicate directly with backend
- Own business logic
- Fetch data
Testing:
Each organism MUST have:
organismName.test.ts
Tests MUST verify:
- Layout rendering
- Property handling
- State-driven rendering behavior

## Molecule Definitions
Molecules are reusable UI components.
Responsibilities:
- Render UI elements
- Be highly reusable
- Be presentation-only
Molecules MUST:
- Receive data only via properties
- Be stateless regarding global application state
Molecules MUST NOT:
- Access global state
- Communicate with backend
- Contain business logic

## Plugin Definitions
Plugins are Web Components responsible for integrating with external services.
Examples:
- Payment platforms
- External APIs
- Third-party integrations
- Analytics services
Plugins MAY:
- Communicate with external services
- Provide integration functionality
Plugins MUST NOT:
- Contain core business logic of the application
- Own application state

## Folder and File Organization
All frontend files MUST follow this structure:
_[projectId]_/l2/[moduleName]/[componentName].[extension]
Definitions:
- projectId \u2192 numeric project identifier (example: 100111)
- l2 \u2192 frontend layer
- moduleName \u2192 module name or folder
- componentName \u2192 component name using camelCase
- extension \u2192 file type (ts, test.ts, defs.ts, css, etc.)
Import rules:
- Always use absolute project-based imports 
Example:
import "/_100111_/l2/user/userProfileOrganism.js";

All generated frontend code MUST strictly follow this architecture.
`;
const pagesForTest = {
  "pages": [
    {
      "screenId": "HOME",
      "pageName": "home",
      "actor": "customer",
      "purpose": "P\xE1gina inicial com destaques, categorias, conte\xFAdos institucionais e acesso ao cat\xE1logo.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "homeHeroHighlights",
              "purpose": "Exibir destaques principais (campanhas/benef\xEDcios) e chamar para navega\xE7\xE3o do cat\xE1logo."
            },
            {
              "organismName": "homeQuickSearchEntry",
              "purpose": "Permitir iniciar busca por produto por texto livre a partir da home."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "homeFeaturedProducts",
              "purpose": "Listar produtos em destaque com acesso ao detalhe do produto e indica\xE7\xE3o de oferta quando aplic\xE1vel."
            },
            {
              "organismName": "homeMainCategories",
              "purpose": "Exibir categorias principais para entrada r\xE1pida no cat\xE1logo filtrado."
            },
            {
              "organismName": "homeLatestBlogPosts",
              "purpose": "Exibir \xFAltimos posts publicados do blog quando a funcionalidade estiver habilitada."
            },
            {
              "organismName": "homeStoreInfoTeaser",
              "purpose": "Exibir resumo institucional (localiza\xE7\xE3o/hor\xE1rio/contato) com acesso \xE0 p\xE1gina completa."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "homeFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "CATALOG_LIST",
      "pageName": "catalogList",
      "actor": "customer",
      "purpose": "Listar produtos com busca, filtros, ordena\xE7\xE3o e navega\xE7\xE3o por categorias.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "catalogListContextSummary",
              "purpose": "Exibir contexto atual do cat\xE1logo (categoria ativa/consulta) e contagem/estado geral dos resultados."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "catalogListSearchBar",
              "purpose": "Capturar texto livre para busca por nome de produto."
            },
            {
              "organismName": "catalogListFilters",
              "purpose": "Selecionar e ajustar filtros (categoria, marca, faixa de pre\xE7o e atributos aplic\xE1veis)."
            },
            {
              "organismName": "catalogListSortControl",
              "purpose": "Selecionar ordena\xE7\xE3o dos resultados (relev\xE2ncia, menor/maior pre\xE7o e condicionais quando dispon\xEDveis)."
            },
            {
              "organismName": "catalogListResultsInfinite",
              "purpose": "Exibir grade/lista de produtos com carregamento em infinite-scroll e acesso ao detalhe do produto."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "catalogListFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "PRODUCT_DETAIL",
      "pageName": "productDetail",
      "actor": "customer",
      "purpose": "Exibir detalhes do produto com m\xEDdia, descri\xE7\xE3o, pre\xE7o/oferta, avalia\xE7\xF5es e a\xE7\xE3o de adicionar ao carrinho.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "productDetailContextHeader",
              "purpose": "Exibir identifica\xE7\xE3o do produto (nome, marca/categoria quando aplic\xE1vel) e estado de oferta."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "exclusive",
          "organisms": [
            {
              "organismName": "productDetailOverviewPanel",
              "purpose": "Exibir fotos/galeria, descri\xE7\xE3o, atributos, pre\xE7o (incluindo promocional) e chamada para adicionar ao carrinho."
            },
            {
              "organismName": "productDetailReviewsPanel",
              "purpose": "Exibir lista de avalia\xE7\xF5es aprovadas do produto e permitir envio de nova avalia\xE7\xE3o quando habilitado."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "productDetailFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "CART",
      "pageName": "cart",
      "actor": "customer",
      "purpose": "Visualizar e gerenciar itens do carrinho, quantidades, subtotal e simula\xE7\xE3o de frete.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "cartContextSummary",
              "purpose": "Exibir resumo do carrinho (quantidade de itens e subtotal) e estado geral do pedido."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "cartItemsList",
              "purpose": "Listar itens do carrinho permitindo atualiza\xE7\xE3o inline de quantidades e remo\xE7\xE3o de itens com atualiza\xE7\xF5es otimistas."
            },
            {
              "organismName": "cartShippingEstimator",
              "purpose": "Capturar CEP e exibir estimativa de frete e total estimado quando dispon\xEDvel."
            },
            {
              "organismName": "cartOrderSummary",
              "purpose": "Exibir resumo de valores (subtotal, frete estimado quando houver, total estimado) e a\xE7\xE3o para iniciar checkout."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "cartFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "CHECKOUT",
      "pageName": "checkout",
      "actor": "customer",
      "purpose": "Finalizar compra com dados do cliente, endere\xE7o de entrega, resumo do pedido e mensagens de confian\xE7a.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "checkoutContextHeader",
              "purpose": "Exibir contexto do checkout (etapa atual/estado do pedido) e refor\xE7o de confian\xE7a quando aplic\xE1vel."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "checkoutCustomerForm",
              "purpose": "Coletar/confirmar dados do cliente com pr\xE9-preenchimento quando autenticado.",
              "fieldsets": [
                "Identifica\xE7\xE3o",
                "Contato"
              ]
            },
            {
              "organismName": "checkoutDeliveryAddressForm",
              "purpose": "Coletar/confirmar endere\xE7o de entrega e prefer\xEAncias relacionadas.",
              "fieldsets": [
                "Endere\xE7o",
                "Complemento/Refer\xEAncia"
              ]
            },
            {
              "organismName": "checkoutOrderReview",
              "purpose": "Exibir revis\xE3o do pedido (itens e valores) antes do envio."
            },
            {
              "organismName": "checkoutSubmitOrder",
              "purpose": "Consolidar valida\xE7\xF5es e acionar envio do pedido (submit) com feedback de processamento e resultado."
            },
            {
              "organismName": "checkoutTrustMessages",
              "purpose": "Exibir mensagens de confian\xE7a durante o checkout quando habilitado."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "checkoutFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ORDER_CONFIRMATION",
      "pageName": "orderConfirmation",
      "actor": "customer",
      "purpose": "Confirmar pedido criado com resumo, n\xFAmero do pedido e pr\xF3ximos passos.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "orderConfirmationHeader",
              "purpose": "Exibir confirma\xE7\xE3o e identifica\xE7\xE3o do pedido (n\xFAmero/status inicial)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "orderConfirmationSummary",
              "purpose": "Exibir resumo do pedido (itens, valores, entrega) e instru\xE7\xF5es de pr\xF3ximos passos."
            },
            {
              "organismName": "orderConfirmationNextActions",
              "purpose": "Exibir a\xE7\xF5es p\xF3s-compra (ex.: acompanhar pedidos, voltar ao cat\xE1logo) conforme contexto de conta."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "orderConfirmationFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "CUSTOMER_LOGIN",
      "pageName": "customerLogin",
      "actor": "customer",
      "purpose": "Autenticar cliente para acesso \xE0 conta e hist\xF3rico de pedidos.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerLoginContextHeader",
              "purpose": "Exibir contexto da autentica\xE7\xE3o (benef\xEDcios de entrar e continuidade do fluxo)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerLoginForm",
              "purpose": "Coletar credenciais do cliente e executar autentica\xE7\xE3o."
            },
            {
              "organismName": "customerLoginAssistance",
              "purpose": "Exibir ajuda e alternativas (ex.: link para cadastro) sem navega\xE7\xE3o embutida."
            }
          ]
        }
      ]
    },
    {
      "screenId": "CUSTOMER_REGISTER",
      "pageName": "customerRegister",
      "actor": "customer",
      "purpose": "Criar nova conta de cliente com dados b\xE1sicos.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerRegisterContextHeader",
              "purpose": "Explicar cria\xE7\xE3o de conta e vantagens para checkout/hist\xF3rico."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerRegisterForm",
              "purpose": "Coletar dados b\xE1sicos para cria\xE7\xE3o da conta.",
              "fieldsets": [
                "Identifica\xE7\xE3o",
                "Contato",
                "Credenciais"
              ]
            },
            {
              "organismName": "customerRegisterConfirmation",
              "purpose": "Exibir feedback de cria\xE7\xE3o de conta e instru\xE7\xF5es do pr\xF3ximo passo."
            }
          ]
        }
      ]
    },
    {
      "screenId": "CUSTOMER_ACCOUNT",
      "pageName": "customerAccount",
      "actor": "customer",
      "purpose": "Painel da conta com acesso a dados pessoais e hist\xF3rico de pedidos.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerAccountHeader",
              "purpose": "Exibir sauda\xE7\xE3o e contexto da conta (nome, status de autentica\xE7\xE3o)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerAccountOverviewCards",
              "purpose": "Exibir atalhos/resumos para dados do perfil e pedidos recentes."
            },
            {
              "organismName": "customerAccountRecentOrders",
              "purpose": "Listar pedidos recentes com acesso ao detalhe do pedido."
            },
            {
              "organismName": "customerAccountProfileSummary",
              "purpose": "Exibir resumo de dados pessoais e endere\xE7o padr\xE3o com acesso \xE0 edi\xE7\xE3o."
            }
          ]
        }
      ]
    },
    {
      "screenId": "CUSTOMER_PROFILE_EDIT",
      "pageName": "customerProfileEdit",
      "actor": "customer",
      "purpose": "Editar dados pessoais e endere\xE7o padr\xE3o com edi\xE7\xE3o inline e atualiza\xE7\xF5es otimistas.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerProfileEditHeader",
              "purpose": "Exibir contexto da edi\xE7\xE3o de perfil e estado de salvamento."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "customerProfileEditForm",
              "purpose": "Permitir edi\xE7\xE3o inline dos dados do perfil e endere\xE7o padr\xE3o com agrupamento sem\xE2ntico.",
              "fieldsets": [
                "Dados Pessoais",
                "Contato",
                "Endere\xE7o Padr\xE3o"
              ]
            },
            {
              "organismName": "customerProfileEditSaveFeedback",
              "purpose": "Exibir feedback de atualiza\xE7\xE3o (otimista) e erros por campo quando ocorrerem."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ORDER_HISTORY",
      "pageName": "orderHistory",
      "actor": "customer",
      "purpose": "Listar pedidos anteriores do cliente com status e acesso a detalhes.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "orderHistoryContextHeader",
              "purpose": "Exibir contexto do hist\xF3rico (filtros/contagem/estado geral)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "orderHistoryListInfinite",
              "purpose": "Listar pedidos do cliente com carregamento em infinite-scroll e acesso ao detalhe."
            },
            {
              "organismName": "orderHistoryStatusFilter",
              "purpose": "Filtrar visualiza\xE7\xE3o por status quando aplic\xE1vel."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ORDER_DETAIL_CUSTOMER",
      "pageName": "orderDetailCustomer",
      "actor": "customer",
      "purpose": "Visualizar detalhes de um pedido espec\xEDfico do cliente.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "orderDetailCustomerHeader",
              "purpose": "Exibir identifica\xE7\xE3o do pedido, status atual e datas relevantes."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "exclusive",
          "organisms": [
            {
              "organismName": "orderDetailCustomerSummaryPanel",
              "purpose": "Exibir itens, valores, entrega e informa\xE7\xF5es principais do pedido."
            },
            {
              "organismName": "orderDetailCustomerActionsPanel",
              "purpose": "Exibir a\xE7\xF5es relacionadas ao pedido (ex.: acessar produtos para avaliar quando aplic\xE1vel) sem l\xF3gica de neg\xF3cio embutida."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "orderDetailCustomerFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "STORE_INFO",
      "pageName": "storeInfo",
      "actor": "customer",
      "purpose": "Exibir informa\xE7\xF5es institucionais da loja (localiza\xE7\xE3o, hor\xE1rio e contato).",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "storeInfoHeader",
              "purpose": "Exibir t\xEDtulo e contexto institucional da loja."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "storeInfoDetails",
              "purpose": "Exibir localiza\xE7\xE3o, hor\xE1rio de funcionamento e canais de contato."
            },
            {
              "organismName": "storeInfoContactCTA",
              "purpose": "Destacar principais canais de contato (ex.: telefone, email, redes) para facilitar acionamento."
            }
          ]
        },
        {
          "sectionName": "footer",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "storeInfoFooterTrustBar",
              "purpose": "Exibir mensagens de confian\xE7a no rodap\xE9 quando habilitado."
            }
          ]
        }
      ]
    },
    {
      "screenId": "BLOG_LIST",
      "pageName": "blogList",
      "actor": "customer",
      "purpose": "Listar posts do blog publicados com dicas de cuidados para pets.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "blogListHeader",
              "purpose": "Exibir contexto do blog e destaque editorial quando aplic\xE1vel."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "blogListPostsInfinite",
              "purpose": "Listar posts publicados com carregamento em infinite-scroll e acesso ao post."
            },
            {
              "organismName": "blogListSearch",
              "purpose": "Permitir filtrar/buscar posts por texto quando aplic\xE1vel."
            }
          ]
        }
      ]
    },
    {
      "screenId": "BLOG_POST",
      "pageName": "blogPost",
      "actor": "customer",
      "purpose": "Exibir leitura de post individual do blog com conte\xFAdo completo.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "blogPostHeader",
              "purpose": "Exibir t\xEDtulo, metadados (data/autor quando houver) e imagem de capa quando aplic\xE1vel."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "blogPostContent",
              "purpose": "Exibir conte\xFAdo completo do post com formata\xE7\xE3o e m\xEDdias."
            },
            {
              "organismName": "blogPostRelatedPosts",
              "purpose": "Exibir sugest\xF5es de posts relacionados/mais recentes para continuidade de leitura."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_LOGIN",
      "pageName": "adminLogin",
      "actor": "staff",
      "purpose": "Autenticar administrador para acesso ao painel de gest\xE3o.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminLoginHeader",
              "purpose": "Exibir contexto do acesso administrativo e aviso de perfil (staff)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminLoginForm",
              "purpose": "Coletar credenciais administrativas e executar autentica\xE7\xE3o."
            },
            {
              "organismName": "adminLoginAccessNotice",
              "purpose": "Exibir pol\xEDticas/avisos de seguran\xE7a e acesso restrito."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_DASHBOARD",
      "pageName": "adminDashboard",
      "actor": "staff",
      "purpose": "Painel administrativo inicial com acesso \xE0s funcionalidades de gest\xE3o.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminDashboardHeader",
              "purpose": "Exibir contexto do painel (usu\xE1rio, data/ambiente) e indicadores gerais."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminDashboardQuickActions",
              "purpose": "Exibir cards/atalhos para \xE1reas de gest\xE3o (produtos, pedidos, blog, informa\xE7\xF5es da loja, confian\xE7a, modera\xE7\xE3o)."
            },
            {
              "organismName": "adminDashboardOperationalSnapshot",
              "purpose": "Exibir resumo operacional (ex.: pedidos recentes/pendentes) para prioriza\xE7\xE3o."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_PRODUCTS_LIST",
      "pageName": "adminProductsList",
      "actor": "staff",
      "purpose": "Listar produtos para gest\xE3o com busca e filtros administrativos.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminProductsListContextHeader",
              "purpose": "Exibir contexto da gest\xE3o de produtos (contagem, status, filtros ativos)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminProductsListSearch",
              "purpose": "Buscar produtos por nome/identificador para gest\xE3o."
            },
            {
              "organismName": "adminProductsListFilters",
              "purpose": "Filtrar por status (ativo/inativo), categoria, marca e atributos relevantes."
            },
            {
              "organismName": "adminProductsListResultsInfinite",
              "purpose": "Listar produtos com carregamento em infinite-scroll e acesso \xE0 edi\xE7\xE3o/cria\xE7\xE3o."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_PRODUCT_EDIT",
      "pageName": "adminProductEdit",
      "actor": "staff",
      "purpose": "Criar/editar produto com dados, imagens, pre\xE7o promocional e atributos.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminProductEditHeader",
              "purpose": "Exibir contexto do produto (novo/edi\xE7\xE3o), identifica\xE7\xE3o e estado de salvamento."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "exclusive",
          "organisms": [
            {
              "organismName": "adminProductEditBasicPanel",
              "purpose": "Editar dados principais do produto (nome, descri\xE7\xE3o, categoria, marca, status).",
              "fieldsets": [
                "Identifica\xE7\xE3o",
                "Classifica\xE7\xE3o",
                "Status"
              ]
            },
            {
              "organismName": "adminProductEditPricingPanel",
              "purpose": "Editar pre\xE7o padr\xE3o e pre\xE7o promocional quando aplic\xE1vel.",
              "fieldsets": [
                "Pre\xE7o",
                "Promo\xE7\xE3o"
              ]
            },
            {
              "organismName": "adminProductEditMediaPanel",
              "purpose": "Gerenciar imagens/m\xEDdias do produto (adicionar/remover/ordenar)."
            },
            {
              "organismName": "adminProductEditAttributesPanel",
              "purpose": "Editar atributos espec\xEDficos (pet/est\xE1gio de vida e demais atributos do cat\xE1logo).",
              "fieldsets": [
                "Atributos do Pet",
                "Atributos Gerais"
              ]
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_ORDERS_LIST",
      "pageName": "adminOrdersList",
      "actor": "staff",
      "purpose": "Listar pedidos para acompanhamento operacional com filtros por status.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminOrdersListContextHeader",
              "purpose": "Exibir contexto de pedidos (contagem, filtros ativos e prioridades)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminOrdersListFilters",
              "purpose": "Filtrar pedidos por status e outros crit\xE9rios operacionais relevantes."
            },
            {
              "organismName": "adminOrdersListResultsInfinite",
              "purpose": "Listar pedidos com carregamento em infinite-scroll e acesso ao detalhe do pedido."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_ORDER_DETAIL",
      "pageName": "adminOrderDetail",
      "actor": "staff",
      "purpose": "Exibir detalhes do pedido com dados do cliente, itens e controle de status.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminOrderDetailHeader",
              "purpose": "Exibir identifica\xE7\xE3o do pedido, status atual e principais flags operacionais."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "exclusive",
          "organisms": [
            {
              "organismName": "adminOrderDetailSummaryPanel",
              "purpose": "Exibir itens, valores, frete e detalhes de entrega do pedido."
            },
            {
              "organismName": "adminOrderDetailCustomerPanel",
              "purpose": "Exibir dados do cliente e informa\xE7\xF5es de contato relacionadas ao pedido."
            },
            {
              "organismName": "adminOrderDetailStatusPanel",
              "purpose": "Permitir atualiza\xE7\xE3o inline do status do pedido com feedback otimista e trilha de altera\xE7\xF5es quando aplic\xE1vel."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_STORE_INFO_EDIT",
      "pageName": "adminStoreInfoEdit",
      "actor": "staff",
      "purpose": "Editar informa\xE7\xF5es institucionais da loja (localiza\xE7\xE3o, hor\xE1rio, contato).",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminStoreInfoEditHeader",
              "purpose": "Exibir contexto da edi\xE7\xE3o institucional e estado de salvamento."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminStoreInfoEditForm",
              "purpose": "Editar informa\xE7\xF5es da loja com edi\xE7\xE3o inline e agrupamento sem\xE2ntico.",
              "fieldsets": [
                "Localiza\xE7\xE3o",
                "Hor\xE1rio de Funcionamento",
                "Contato"
              ]
            },
            {
              "organismName": "adminStoreInfoEditPreview",
              "purpose": "Exibir pr\xE9-visualiza\xE7\xE3o textual do conte\xFAdo institucional para valida\xE7\xE3o antes/depois de salvar."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_BLOG_LIST",
      "pageName": "adminBlogList",
      "actor": "staff",
      "purpose": "Listar posts do blog com controle de status (rascunho/publicado).",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminBlogListContextHeader",
              "purpose": "Exibir contexto da gest\xE3o do blog (contagens por status e filtros ativos)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminBlogListFilters",
              "purpose": "Filtrar posts por status (rascunho/publicado) e outros crit\xE9rios."
            },
            {
              "organismName": "adminBlogListResultsInfinite",
              "purpose": "Listar posts com carregamento em infinite-scroll e acesso \xE0 edi\xE7\xE3o/cria\xE7\xE3o."
            },
            {
              "organismName": "adminBlogListSearch",
              "purpose": "Buscar posts por t\xEDtulo/slug quando aplic\xE1vel."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_BLOG_EDIT",
      "pageName": "adminBlogEdit",
      "actor": "staff",
      "purpose": "Criar/editar post do blog com editor de conte\xFAdo e controle de publica\xE7\xE3o.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminBlogEditHeader",
              "purpose": "Exibir contexto do post (novo/edi\xE7\xE3o), status e estado de salvamento."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "exclusive",
          "organisms": [
            {
              "organismName": "adminBlogEditContentPanel",
              "purpose": "Editar conte\xFAdo do post (t\xEDtulo, corpo, m\xEDdia) em um editor dedicado.",
              "fieldsets": [
                "Metadados",
                "Conte\xFAdo"
              ]
            },
            {
              "organismName": "adminBlogEditPublicationPanel",
              "purpose": "Controlar status de publica\xE7\xE3o (rascunho/publicado) e valida\xE7\xF5es associadas.",
              "fieldsets": [
                "Publica\xE7\xE3o"
              ]
            },
            {
              "organismName": "adminBlogEditPreviewPanel",
              "purpose": "Pr\xE9-visualizar o post renderizado para revis\xE3o antes de publicar."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_REVIEWS_MODERATION",
      "pageName": "adminReviewsModeration",
      "actor": "staff",
      "purpose": "Moderar avalia\xE7\xF5es de produtos com a\xE7\xF5es de aprovar e rejeitar.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminReviewsModerationHeader",
              "purpose": "Exibir contexto da fila de modera\xE7\xE3o (pendentes, crit\xE9rios e contagem)."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminReviewsModerationQueueInfinite",
              "purpose": "Listar avalia\xE7\xF5es pendentes com carregamento em infinite-scroll e exibi\xE7\xE3o do contexto (produto/cliente)."
            },
            {
              "organismName": "adminReviewsModerationActions",
              "purpose": "Permitir aprovar/rejeitar avalia\xE7\xF5es com atualiza\xE7\xF5es otimistas e justificativa opcional quando aplic\xE1vel."
            }
          ]
        }
      ]
    },
    {
      "screenId": "ADMIN_TRUST_MESSAGES",
      "pageName": "adminTrustMessages",
      "actor": "staff",
      "purpose": "Gerenciar mensagens de confian\xE7a exibidas no checkout e no rodap\xE9.",
      "sections": [
        {
          "sectionName": "header",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminTrustMessagesHeader",
              "purpose": "Exibir contexto da configura\xE7\xE3o de confian\xE7a e estado de salvamento."
            }
          ]
        },
        {
          "sectionName": "main",
          "mode": "stack",
          "organisms": [
            {
              "organismName": "adminTrustMessagesEditor",
              "purpose": "Criar/editar/remover itens de confian\xE7a e definir quais est\xE3o ativos com edi\xE7\xE3o inline e atualiza\xE7\xF5es otimistas.",
              "fieldsets": [
                "Itens de Confian\xE7a",
                "Ativa\xE7\xE3o/Ordem"
              ]
            },
            {
              "organismName": "adminTrustMessagesPreview",
              "purpose": "Pr\xE9-visualizar como as mensagens aparecer\xE3o no checkout e no rodap\xE9."
            }
          ]
        }
      ]
    }
  ]
};
const toBeConceptualTest = {
  "meta": {
    "userLanguage": "pt",
    "moduleName": "petShop",
    "userPromptOriginal": "Criar um novo m\xF3dulo para um site de pet shop.",
    "userPromptFinal": 'Criar o m\xF3dulo "petShop" para um site de pet shop em Portugu\xEAs (Brasil), voltado a donos de pets em geral. O site deve funcionar como um e-commerce com cat\xE1logo de produtos bem organizado, carrinho de compras e sistema de pagamento. Deve conter tamb\xE9m se\xE7\xF5es institucionais como "quem somos" e informa\xE7\xF5es de contato. Pap\xE9is principais: clientes (navegar e comprar) e administradores (gerenciar conte\xFAdo, produtos e pedidos). Tom de comunica\xE7\xE3o amig\xE1vel, acolhedor e informativo, transmitindo confian\xE7a e carinho pelos animais. Design limpo, moderno e intuitivo, com cores que remetam \xE0 natureza e bem-estar animal e imagens de pets felizes e saud\xE1veis. Categorias de produtos: ra\xE7\xF5es para c\xE3es e gatos, brinquedos, acess\xF3rios (coleiras e guias), produtos de higiene e possivelmente vestu\xE1rio para pets. N\xE3o incluir funcionalidades de agendamento de servi\xE7os nem ado\xE7\xE3o. Atualiza\xE7\xF5es aplicadas (yagni=now): controle de estoque por produto; c\xE1lculo de frete por endere\xE7o e op\xE7\xF5es de entrega; avalia\xE7\xF5es e coment\xE1rios de produtos; cupons de desconto; hist\xF3rico detalhado de pedidos para o cliente; rastreamento e status detalhado de envio; FAQ r\xE1pido no checkout (frete, prazos, trocas, formas de pagamento) com links para pol\xEDticas; p\xE1ginas institucionais adicionais (trocas e devolu\xE7\xF5es, privacidade, termos) acess\xEDveis via rodap\xE9.'
  },
  "ontology": {
    "entities": {
      "User": {
        "description": "Pessoa que interage com o site do pet shop.",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "role": {
            "type": "string",
            "required": true,
            "values": [
              "cliente",
              "administrador"
            ],
            "constraints": "O papel define permiss\xF5es: cliente compra; administrador gerencia conte\xFAdo, produtos e pedidos."
          },
          "name": {
            "type": "string",
            "required": false
          },
          "email": {
            "type": "string",
            "required": false
          }
        },
        "rules": [
          "RULE-USER-ROLES-001"
        ]
      },
      "Product": {
        "description": "Item vendido no e-commerce do pet shop.",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "name": {
            "type": "string",
            "required": true
          },
          "category": {
            "type": "string",
            "required": true,
            "values": [
              "racao_caes",
              "racao_gatos",
              "brinquedos",
              "acessorios",
              "higiene",
              "vestuario"
            ],
            "constraints": "Categorias devem refletir o cat\xE1logo planejado para o pet shop."
          },
          "description": {
            "type": "string",
            "required": false
          },
          "price": {
            "type": "number",
            "required": true,
            "constraints": "Pre\xE7o em moeda local (BRL)."
          },
          "active": {
            "type": "boolean",
            "required": true
          },
          "stockQuantity": {
            "type": "number",
            "required": true,
            "constraints": "Quantidade dispon\xEDvel em estoque (inteiro >= 0). Deve impedir venda de itens indispon\xEDveis."
          },
          "stockStatus": {
            "type": "string",
            "required": true,
            "values": [
              "disponivel",
              "indisponivel"
            ],
            "constraints": "Status derivado do estoque (ex.: indisponivel quando stockQuantity = 0) para comunica\xE7\xE3o clara no cat\xE1logo."
          }
        },
        "rules": [
          "RULE-PRODUCT-CATEGORIES-001",
          "RULE-INVENTORY-CONTROL-001"
        ]
      },
      "Cart": {
        "description": "Carrinho de compras do cliente.",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "userId": {
            "type": "string",
            "required": true
          },
          "items": {
            "type": "array",
            "required": true,
            "constraints": "Lista de itens com produto e quantidade."
          },
          "appliedCouponCode": {
            "type": "string",
            "required": false,
            "constraints": "C\xF3digo de cupom aplicado ao carrinho (se houver)."
          },
          "discountTotal": {
            "type": "number",
            "required": false,
            "constraints": "Total de descontos aplicados ao carrinho (BRL)."
          },
          "shippingAddress": {
            "type": "string",
            "required": false,
            "constraints": "Endere\xE7o informado para estimativa/c\xE1lculo de frete."
          },
          "selectedShippingOptionId": {
            "type": "string",
            "required": false,
            "constraints": "Identificador da op\xE7\xE3o de entrega selecionada para c\xE1lculo do frete."
          },
          "shippingCost": {
            "type": "number",
            "required": false,
            "constraints": "Custo de frete estimado/calculado (BRL)."
          }
        },
        "rules": [
          "RULE-COUPONS-001",
          "RULE-SHIPPING-CALCULATION-001"
        ]
      },
      "Order": {
        "description": "Pedido realizado pelo cliente.",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "userId": {
            "type": "string",
            "required": true
          },
          "status": {
            "type": "string",
            "required": true,
            "values": [
              "criado",
              "pago",
              "cancelado",
              "enviado",
              "entregue"
            ],
            "constraints": "Fluxo t\xEDpico de e-commerce com pagamento."
          },
          "total": {
            "type": "number",
            "required": true
          },
          "createdAt": {
            "type": "string",
            "required": true,
            "constraints": "Data/hora em formato ISO-8601."
          },
          "shippingCost": {
            "type": "number",
            "required": false,
            "constraints": "Custo de frete (BRL) aplicado ao pedido."
          },
          "shippingOptionLabel": {
            "type": "string",
            "required": false,
            "constraints": "Descri\xE7\xE3o da op\xE7\xE3o de entrega escolhida (ex.: normal/expressa)."
          },
          "trackingCode": {
            "type": "string",
            "required": false,
            "constraints": "C\xF3digo de rastreamento do envio (quando aplic\xE1vel)."
          },
          "shippingStatus": {
            "type": "string",
            "required": false,
            "values": [
              "aguardando_envio",
              "postado",
              "em_transito",
              "saiu_para_entrega",
              "entregue",
              "problema_no_envio"
            ],
            "constraints": "Status detalhado do envio para acompanhamento pelo cliente."
          },
          "couponCode": {
            "type": "string",
            "required": false,
            "constraints": "C\xF3digo de cupom aplicado no pedido (se houver)."
          },
          "discountTotal": {
            "type": "number",
            "required": false,
            "constraints": "Total de descontos aplicados ao pedido (BRL)."
          }
        },
        "rules": [
          "RULE-SHIPPING-TRACKING-001",
          "RULE-COUPONS-001",
          "RULE-SHIPPING-CALCULATION-001",
          "RULE-INVENTORY-CONTROL-001"
        ]
      },
      "ContentPage": {
        "description": "P\xE1gina institucional/informativa do site (ex.: quem somos, contato, pol\xEDticas).",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "slug": {
            "type": "string",
            "required": true,
            "values": [
              "quem-somos",
              "contato",
              "trocas-e-devolucoes",
              "politica-de-privacidade",
              "termos-de-uso"
            ],
            "constraints": "Deve incluir no m\xEDnimo as p\xE1ginas 'quem somos' e 'contato'. Tamb\xE9m deve suportar p\xE1ginas de pol\xEDticas no rodap\xE9."
          },
          "title": {
            "type": "string",
            "required": true
          },
          "body": {
            "type": "string",
            "required": true
          }
        },
        "rules": [
          "RULE-INSTITUTIONAL-PAGES-001",
          "RULE-POLICIES-PAGES-001"
        ]
      },
      "ProductReview": {
        "description": "Avalia\xE7\xE3o e coment\xE1rio de um produto feito por um cliente.",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "productId": {
            "type": "string",
            "required": true
          },
          "userId": {
            "type": "string",
            "required": true,
            "constraints": "Apenas usu\xE1rios com role=cliente podem avaliar."
          },
          "rating": {
            "type": "number",
            "required": true,
            "constraints": "Nota (ex.: 1 a 5)."
          },
          "comment": {
            "type": "string",
            "required": false
          },
          "createdAt": {
            "type": "string",
            "required": true,
            "constraints": "Data/hora em formato ISO-8601."
          },
          "status": {
            "type": "string",
            "required": true,
            "values": [
              "pendente",
              "publicado",
              "oculto"
            ],
            "constraints": "Permite modera\xE7\xE3o de avalia\xE7\xF5es/coment\xE1rios."
          }
        },
        "rules": [
          "RULE-PRODUCT-REVIEWS-001",
          "RULE-USER-ROLES-001",
          "RULE-LANGUAGE-PTBR-001"
        ]
      },
      "Coupon": {
        "description": "Cupom de desconto criado por administrador e aplicado no carrinho/pedido.",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "code": {
            "type": "string",
            "required": true,
            "constraints": "C\xF3digo \xFAnico do cupom."
          },
          "active": {
            "type": "boolean",
            "required": true
          },
          "discountType": {
            "type": "string",
            "required": true,
            "values": [
              "percentual",
              "valor_fixo"
            ]
          },
          "discountValue": {
            "type": "number",
            "required": true,
            "constraints": "Valor do desconto conforme discountType (percentual: 0-100; valor_fixo: BRL)."
          },
          "validFrom": {
            "type": "string",
            "required": false,
            "constraints": "Data/hora ISO-8601 de in\xEDcio de vig\xEAncia."
          },
          "validTo": {
            "type": "string",
            "required": false,
            "constraints": "Data/hora ISO-8601 de fim de vig\xEAncia."
          },
          "minOrderTotal": {
            "type": "number",
            "required": false,
            "constraints": "Valor m\xEDnimo do carrinho/pedido para aplicar o cupom (BRL)."
          }
        },
        "rules": [
          "RULE-COUPONS-001",
          "RULE-USER-ROLES-001"
        ]
      },
      "ShippingOption": {
        "description": "Op\xE7\xE3o de entrega dispon\xEDvel para um endere\xE7o e um conjunto de itens (ex.: normal/expressa).",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "label": {
            "type": "string",
            "required": true,
            "constraints": "Nome/descri\xE7\xE3o da op\xE7\xE3o (ex.: Normal, Expressa)."
          },
          "estimatedDelivery": {
            "type": "string",
            "required": false,
            "constraints": "Prazo estimado em formato textual (ex.: '3 a 5 dias \xFAteis')."
          },
          "cost": {
            "type": "number",
            "required": true,
            "constraints": "Custo de frete (BRL) para a op\xE7\xE3o."
          },
          "active": {
            "type": "boolean",
            "required": true
          }
        },
        "rules": [
          "RULE-SHIPPING-CALCULATION-001"
        ]
      },
      "CheckoutFAQItem": {
        "description": "Item de FAQ exibido no checkout para reduzir d\xFAvidas (frete, prazos, trocas, pagamento) e orientar para pol\xEDticas.",
        "fields": {
          "id": {
            "type": "string",
            "required": true
          },
          "question": {
            "type": "string",
            "required": true
          },
          "answer": {
            "type": "string",
            "required": true,
            "constraints": "Resposta curta e clara, adequada ao contexto do checkout."
          },
          "topic": {
            "type": "string",
            "required": true,
            "values": [
              "frete",
              "prazos",
              "trocas",
              "pagamento",
              "outros"
            ]
          },
          "relatedPolicySlugs": {
            "type": "array",
            "required": false,
            "constraints": "Lista de slugs de ContentPage que devem ser linkados (ex.: 'trocas-e-devolucoes', 'politica-de-privacidade', 'termos-de-uso')."
          },
          "active": {
            "type": "boolean",
            "required": true
          }
        },
        "rules": [
          "RULE-CHECKOUT-FAQ-001",
          "RULE-LANGUAGE-PTBR-001"
        ]
      }
    }
  },
  "rules": {
    "RULE-LANGUAGE-PTBR-001": {
      "kind": "policy",
      "description": "O site deve estar dispon\xEDvel apenas em Portugu\xEAs (Brasil).",
      "scope": [
        "global"
      ],
      "acceptanceCriteria": [
        "Todo o conte\xFAdo e textos do m\xF3dulo devem estar em pt-BR.",
        "N\xE3o deve existir altern\xE2ncia/sele\xE7\xE3o de idioma."
      ]
    },
    "RULE-USER-ROLES-001": {
      "kind": "platform",
      "description": "O sistema deve suportar apenas os pap\xE9is principais 'cliente' e 'administrador', com responsabilidades coerentes: cliente navega e compra; administrador gerencia conte\xFAdo, produtos e pedidos.",
      "scope": [
        "entities.User",
        "capabilities"
      ],
      "acceptanceCriteria": [
        "Usu\xE1rios devem ter role em {cliente,administrador}.",
        "A\xE7\xF5es administrativas devem ser restritas ao papel administrador."
      ]
    },
    "RULE-ECOMMERCE-CORE-001": {
      "kind": "domain",
      "description": "O site deve funcionar como e-commerce, incluindo cat\xE1logo de produtos, carrinho de compras e sistema de pagamento.",
      "scope": [
        "global",
        "capabilities"
      ],
      "acceptanceCriteria": [
        "Deve existir navega\xE7\xE3o de cat\xE1logo por categorias.",
        "Deve existir carrinho de compras com itens e quantidades.",
        "Deve existir fluxo de checkout com pagamento."
      ]
    },
    "RULE-INSTITUTIONAL-PAGES-001": {
      "kind": "domain",
      "description": "O site deve incluir se\xE7\xE3o institucional 'quem somos' e informa\xE7\xF5es de contato.",
      "scope": [
        "entities.ContentPage",
        "capabilities"
      ],
      "acceptanceCriteria": [
        "Deve existir p\xE1gina 'quem somos'.",
        "Deve existir p\xE1gina 'contato' com informa\xE7\xF5es de contato."
      ]
    },
    "RULE-PRODUCT-CATEGORIES-001": {
      "kind": "domain",
      "description": "O cat\xE1logo deve contemplar as categorias: ra\xE7\xF5es para c\xE3es, ra\xE7\xF5es para gatos, brinquedos, acess\xF3rios (coleiras e guias), higiene e possivelmente vestu\xE1rio para pets.",
      "scope": [
        "entities.Product"
      ],
      "acceptanceCriteria": [
        "Product.category deve suportar: racao_caes,racao_gatos,brinquedos,acessorios,higiene,vestuario."
      ]
    },
    "RULE-TONE-VOICE-001": {
      "kind": "policy",
      "description": "O tom de comunica\xE7\xE3o do site deve ser amig\xE1vel, acolhedor e informativo, transmitindo confian\xE7a e carinho pelos animais.",
      "scope": [
        "global"
      ],
      "acceptanceCriteria": [
        "Textos institucionais e mensagens do fluxo de compra devem refletir tom amig\xE1vel e acolhedor.",
        "Conte\xFAdo deve ser informativo sem perder a sensa\xE7\xE3o de confian\xE7a e cuidado com os pets."
      ]
    },
    "RULE-DESIGN-STYLE-001": {
      "kind": "policy",
      "description": "O design deve ser limpo, moderno e intuitivo, com cores que remetam \xE0 natureza e bem-estar animal e uso de imagens de pets felizes e saud\xE1veis.",
      "scope": [
        "global"
      ],
      "acceptanceCriteria": [
        "Interface deve priorizar clareza e navega\xE7\xE3o simples.",
        "Paleta visual deve remeter \xE0 natureza/bem-estar animal.",
        "P\xE1ginas principais devem utilizar imagens de pets felizes e saud\xE1veis."
      ]
    },
    "RULE-NO-SERVICES-SCHEDULING-001": {
      "kind": "domain",
      "description": "O m\xF3dulo n\xE3o deve oferecer agendamento de servi\xE7os.",
      "scope": [
        "global",
        "capabilities"
      ],
      "acceptanceCriteria": [
        "N\xE3o deve existir funcionalidade de agendar banho/tosa/consulta ou similares."
      ]
    },
    "RULE-NO-ADOPTION-001": {
      "kind": "domain",
      "description": "O m\xF3dulo n\xE3o deve permitir ado\xE7\xE3o de animais.",
      "scope": [
        "global",
        "capabilities"
      ],
      "acceptanceCriteria": [
        "N\xE3o deve existir fluxo, se\xE7\xE3o ou formul\xE1rios de ado\xE7\xE3o."
      ]
    },
    "RULE-INVENTORY-CONTROL-001": {
      "kind": "domain",
      "description": "O sistema deve controlar estoque por produto e evitar venda de itens indispon\xEDveis.",
      "scope": [
        "entities.Product",
        "entities.Cart",
        "entities.Order",
        "capabilities.CART_MANAGEMENT",
        "capabilities.CHECKOUT_AND_PAYMENT",
        "capabilities.ADMIN_MANAGEMENT"
      ],
      "acceptanceCriteria": [
        "Cada produto deve possuir quantidade em estoque (>=0).",
        "N\xE3o deve ser poss\xEDvel finalizar pedido com item sem estoque suficiente.",
        "Ao gerenciar produtos, administrador deve poder ajustar o estoque."
      ]
    },
    "RULE-SHIPPING-CALCULATION-001": {
      "kind": "domain",
      "description": "O sistema deve calcular o frete com base no endere\xE7o do cliente e nas op\xE7\xF5es de entrega, exibindo o custo antes da finaliza\xE7\xE3o do pedido.",
      "scope": [
        "entities.Cart",
        "entities.Order",
        "entities.ShippingOption",
        "capabilities.CHECKOUT_AND_PAYMENT"
      ],
      "acceptanceCriteria": [
        "No checkout, deve ser poss\xEDvel informar endere\xE7o para c\xE1lculo/estimativa de frete.",
        "Deve ser poss\xEDvel escolher entre op\xE7\xF5es de entrega quando houver.",
        "O custo do frete deve compor o total apresentado antes da confirma\xE7\xE3o do pedido."
      ]
    },
    "RULE-PRODUCT-REVIEWS-001": {
      "kind": "policy",
      "description": "O sistema deve permitir que clientes avaliem e comentem produtos, com possibilidade de modera\xE7\xE3o.",
      "scope": [
        "entities.ProductReview",
        "capabilities.PRODUCT_REVIEWS"
      ],
      "acceptanceCriteria": [
        "Clientes devem poder registrar nota e opcionalmente coment\xE1rio em um produto.",
        "Avalia\xE7\xF5es devem ter status (pendente/publicado/oculto) para controle de exibi\xE7\xE3o.",
        "Somente avalia\xE7\xF5es publicadas devem ser exibidas no cat\xE1logo."
      ]
    },
    "RULE-COUPONS-001": {
      "kind": "domain",
      "description": "O sistema deve permitir cria\xE7\xE3o e aplica\xE7\xE3o de cupons de desconto no carrinho e refletir descontos no total do pedido.",
      "scope": [
        "entities.Coupon",
        "entities.Cart",
        "entities.Order",
        "capabilities.COUPONS_AND_DISCOUNTS",
        "capabilities.CHECKOUT_AND_PAYMENT",
        "capabilities.ADMIN_MANAGEMENT"
      ],
      "acceptanceCriteria": [
        "Deve ser poss\xEDvel aplicar/remover um cupom no carrinho.",
        "Cupom deve respeitar status ativo e janela de validade quando informada.",
        "O desconto deve ser exibido e subtra\xEDdo do total antes da confirma\xE7\xE3o do pedido."
      ]
    },
    "RULE-SHIPPING-TRACKING-001": {
      "kind": "domain",
      "description": "O sistema deve informar c\xF3digo de rastreamento e status detalhado do envio para pedidos enviados.",
      "scope": [
        "entities.Order",
        "capabilities.ORDER_TRACKING"
      ],
      "acceptanceCriteria": [
        "Quando um pedido estiver em processo de entrega, deve existir c\xF3digo de rastreamento quando aplic\xE1vel.",
        "O cliente deve conseguir visualizar o status detalhado do envio do pedido."
      ]
    },
    "RULE-POLICIES-PAGES-001": {
      "kind": "policy",
      "description": "O site deve disponibilizar p\xE1ginas de pol\xEDticas essenciais (Trocas e devolu\xE7\xF5es, Pol\xEDtica de privacidade, Termos de uso) com acesso pelo rodap\xE9.",
      "scope": [
        "entities.ContentPage",
        "capabilities.INSTITUTIONAL_CONTENT"
      ],
      "acceptanceCriteria": [
        "Deve existir p\xE1gina 'trocas-e-devolucoes'.",
        "Deve existir p\xE1gina 'politica-de-privacidade'.",
        "Deve existir p\xE1gina 'termos-de-uso'.",
        "Essas p\xE1ginas devem ser acess\xEDveis via links no rodap\xE9."
      ]
    },
    "RULE-CHECKOUT-FAQ-001": {
      "kind": "domain",
      "description": "O checkout deve exibir um FAQ r\xE1pido e contextual sobre frete, prazos, trocas e formas de pagamento, com links para pol\xEDticas aplic\xE1veis.",
      "scope": [
        "entities.CheckoutFAQItem",
        "capabilities.CHECKOUT_SUPPORT_FAQ",
        "capabilities.CHECKOUT_AND_PAYMENT"
      ],
      "acceptanceCriteria": [
        "No checkout, deve existir acesso a itens de FAQ de leitura r\xE1pida.",
        "Itens de FAQ devem cobrir ao menos: frete, prazos, trocas e pagamento (podendo incluir outros).",
        "Quando relevante, itens de FAQ devem incluir links para p\xE1ginas de pol\xEDticas (ex.: trocas e devolu\xE7\xF5es, privacidade, termos).",
        "Somente itens ativos devem ser exibidos."
      ]
    }
  },
  "capabilities": {
    "CATALOG_BROWSING": {
      "description": "Navegar e pesquisar o cat\xE1logo de produtos por categorias.",
      "usesRules": [
        "RULE-ECOMMERCE-CORE-001",
        "RULE-PRODUCT-CATEGORIES-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001",
        "RULE-DESIGN-STYLE-001",
        "RULE-INVENTORY-CONTROL-001"
      ],
      "isOptional": false,
      "actions": [
        {
          "actionId": "listProducts",
          "description": "Listar produtos do cat\xE1logo com filtros por categoria."
        },
        {
          "actionId": "viewProductDetails",
          "description": "Visualizar detalhes de um produto."
        },
        {
          "actionId": "viewAvailability",
          "description": "Exibir disponibilidade do produto com base no estoque."
        }
      ]
    },
    "CART_MANAGEMENT": {
      "description": "Gerenciar carrinho de compras (adicionar, remover e alterar quantidades).",
      "usesRules": [
        "RULE-ECOMMERCE-CORE-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001",
        "RULE-INVENTORY-CONTROL-001",
        "RULE-COUPONS-001"
      ],
      "isOptional": false,
      "actions": [
        {
          "actionId": "addToCart",
          "description": "Adicionar produto ao carrinho (respeitando limite de estoque)."
        },
        {
          "actionId": "removeFromCart",
          "description": "Remover produto do carrinho."
        },
        {
          "actionId": "updateQuantity",
          "description": "Atualizar quantidade de um item no carrinho (respeitando limite de estoque)."
        },
        {
          "actionId": "viewCart",
          "description": "Visualizar itens, subtotal, descontos (se houver) e estimativa de total."
        }
      ]
    },
    "CHECKOUT_AND_PAYMENT": {
      "description": "Finalizar compra e realizar pagamento.",
      "usesRules": [
        "RULE-ECOMMERCE-CORE-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001",
        "RULE-NO-SERVICES-SCHEDULING-001",
        "RULE-NO-ADOPTION-001",
        "RULE-SHIPPING-CALCULATION-001",
        "RULE-INVENTORY-CONTROL-001",
        "RULE-COUPONS-001",
        "RULE-CHECKOUT-FAQ-001",
        "RULE-POLICIES-PAGES-001"
      ],
      "isOptional": false,
      "actions": [
        {
          "actionId": "startCheckout",
          "description": "Iniciar checkout a partir do carrinho."
        },
        {
          "actionId": "calculateShipping",
          "description": "Informar endere\xE7o, listar op\xE7\xF5es de entrega e calcular custo de frete antes da confirma\xE7\xE3o."
        },
        {
          "actionId": "applyCouponAtCheckout",
          "description": "Aplicar ou remover cupom durante o checkout, refletindo no total final."
        },
        {
          "actionId": "viewCheckoutFAQ",
          "description": "Acessar FAQ r\xE1pido no checkout (frete, prazos, trocas e pagamento) com links para pol\xEDticas relacionadas."
        },
        {
          "actionId": "processPayment",
          "description": "Processar pagamento do pedido."
        },
        {
          "actionId": "confirmOrder",
          "description": "Confirmar cria\xE7\xE3o do pedido ap\xF3s pagamento, registrando frete e descontos."
        }
      ]
    },
    "INSTITUTIONAL_CONTENT": {
      "description": "Exibir p\xE1ginas institucionais e de contato.",
      "usesRules": [
        "RULE-INSTITUTIONAL-PAGES-001",
        "RULE-POLICIES-PAGES-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001",
        "RULE-DESIGN-STYLE-001"
      ],
      "isOptional": false,
      "actions": [
        {
          "actionId": "viewAboutUs",
          "description": "Exibir a p\xE1gina 'quem somos'."
        },
        {
          "actionId": "viewContact",
          "description": "Exibir a p\xE1gina de contato com informa\xE7\xF5es para o cliente."
        },
        {
          "actionId": "viewReturnsPolicy",
          "description": "Exibir a p\xE1gina 'Trocas e devolu\xE7\xF5es'."
        },
        {
          "actionId": "viewPrivacyPolicy",
          "description": "Exibir a p\xE1gina 'Pol\xEDtica de privacidade'."
        },
        {
          "actionId": "viewTermsOfUse",
          "description": "Exibir a p\xE1gina 'Termos de uso'."
        },
        {
          "actionId": "viewFooterPolicyLinks",
          "description": "Disponibilizar links no rodap\xE9 para as p\xE1ginas de pol\xEDticas."
        }
      ]
    },
    "ADMIN_MANAGEMENT": {
      "description": "\xC1rea administrativa para gerenciar produtos, pedidos e conte\xFAdo.",
      "usesRules": [
        "RULE-USER-ROLES-001",
        "RULE-ECOMMERCE-CORE-001",
        "RULE-INSTITUTIONAL-PAGES-001",
        "RULE-POLICIES-PAGES-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-INVENTORY-CONTROL-001",
        "RULE-COUPONS-001",
        "RULE-PRODUCT-REVIEWS-001",
        "RULE-SHIPPING-TRACKING-001",
        "RULE-CHECKOUT-FAQ-001"
      ],
      "isOptional": false,
      "actions": [
        {
          "actionId": "manageProducts",
          "description": "Criar/editar/ativar/desativar produtos e categorias."
        },
        {
          "actionId": "manageInventory",
          "description": "Ajustar e manter o estoque de cada produto."
        },
        {
          "actionId": "manageOrders",
          "description": "Visualizar e atualizar status de pedidos."
        },
        {
          "actionId": "updateShippingTracking",
          "description": "Informar/atualizar c\xF3digo de rastreamento e status detalhado de envio no pedido."
        },
        {
          "actionId": "managePages",
          "description": "Editar p\xE1ginas institucionais, incluindo 'quem somos', 'contato' e p\xE1ginas de pol\xEDticas."
        },
        {
          "actionId": "manageCoupons",
          "description": "Criar/editar/ativar/desativar cupons e definir regras b\xE1sicas de validade e desconto."
        },
        {
          "actionId": "moderateReviews",
          "description": "Publicar/ocultar avalia\xE7\xF5es e coment\xE1rios de produtos."
        }
      ]
    },
    "PRODUCT_REVIEWS": {
      "description": "Permitir que clientes avaliem e comentem produtos, e exibir avalia\xE7\xF5es publicadas na p\xE1gina do produto.",
      "usesRules": [
        "RULE-PRODUCT-REVIEWS-001",
        "RULE-USER-ROLES-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001"
      ],
      "isOptional": true,
      "actions": [
        {
          "actionId": "submitReview",
          "description": "Cliente registra uma avalia\xE7\xE3o (nota e coment\xE1rio opcional) para um produto."
        },
        {
          "actionId": "listPublishedReviews",
          "description": "Exibir avalia\xE7\xF5es publicadas de um produto."
        }
      ]
    },
    "COUPONS_AND_DISCOUNTS": {
      "description": "Aplicar e validar cupons de desconto no carrinho e refletir o desconto no checkout.",
      "usesRules": [
        "RULE-COUPONS-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001"
      ],
      "isOptional": true,
      "actions": [
        {
          "actionId": "applyCoupon",
          "description": "Aplicar cupom no carrinho e recalcular totais."
        },
        {
          "actionId": "removeCoupon",
          "description": "Remover cupom do carrinho e recalcular totais."
        }
      ]
    },
    "CUSTOMER_ORDER_HISTORY": {
      "description": "Disponibilizar hist\xF3rico detalhado de pedidos na conta do cliente.",
      "usesRules": [
        "RULE-ECOMMERCE-CORE-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001"
      ],
      "isOptional": false,
      "actions": [
        {
          "actionId": "listMyOrders",
          "description": "Listar pedidos do cliente com principais informa\xE7\xF5es (data, total, status)."
        },
        {
          "actionId": "viewMyOrderDetails",
          "description": "Visualizar detalhes de um pedido (itens, frete, descontos, status e dados de envio quando existirem)."
        }
      ]
    },
    "ORDER_TRACKING": {
      "description": "Permitir que o cliente acompanhe o envio do pedido com status detalhado e c\xF3digo de rastreamento (quando aplic\xE1vel).",
      "usesRules": [
        "RULE-SHIPPING-TRACKING-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001"
      ],
      "isOptional": false,
      "actions": [
        {
          "actionId": "viewTrackingInfo",
          "description": "Exibir c\xF3digo de rastreamento e status detalhado de envio do pedido."
        }
      ]
    },
    "CHECKOUT_SUPPORT_FAQ": {
      "description": "Gerenciar e exibir um FAQ r\xE1pido no checkout, com respostas curtas e links para pol\xEDticas aplic\xE1veis.",
      "usesRules": [
        "RULE-CHECKOUT-FAQ-001",
        "RULE-LANGUAGE-PTBR-001",
        "RULE-TONE-VOICE-001",
        "RULE-POLICIES-PAGES-001",
        "RULE-USER-ROLES-001"
      ],
      "isOptional": true,
      "actions": [
        {
          "actionId": "listActiveFAQItems",
          "description": "Exibir itens ativos do FAQ no checkout."
        },
        {
          "actionId": "manageFAQItems",
          "description": "Administrador cria/edita/ativa/desativa itens do FAQ e define links para pol\xEDticas relacionadas."
        }
      ]
    }
  }
};
export {
  createAgent,
  getSystem,
  systemSkillAura
};
