/// <mls fileReference="_100554_/l2/agents/agentUserJourney" enhancement="_100554_enhancementAgent"/>
export const integrations = [];
export const tests = [];
