/// <mls fileReference="_100554_/l2/agents/agentToBeOrganism.test.ts" enhancement="_100554_enhancementAgent" />
export const integrations = [];
export const tests = [];
