/// <mls fileReference="_100554_/l2/agents/agentToBePages.test.ts" enhancement="_100554_enhancementAgent" />
const integrations = [];
const tests = [];
export {
  integrations,
  tests
};
