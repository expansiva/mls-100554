/// <mls shortName="agentBackendMaterializationPlan" project="100554" enhancement="_100554_enhancementAgent" folder="agents" />
export function createAgent() {
    return {
        agentName: "agentBackendMaterializationPlan",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Backend Materialization Plan",
        visibility: "private",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const inTest = true;
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system3
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: inTest ? `test ${agent.agentName}` : agent.agentDescription,
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    try {
        const output = payload.result;
        intents = await processOutput(output);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    if (step.stepId === 1)
        intents = []; // test mode do not advance
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(backendMaterializationPlan) {
    console.log("=== Materialization Plan");
    console.log(JSON.stringify(backendMaterializationPlan, null, 2));
    const inTest = true; // todo: define
    if (inTest)
        return [];
    const step = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'pending',
        nextSteps: [],
        agentName: "agentNewModule5",
        prompt: "",
        rags: null,
    };
    // const rc: mls.msg.AgentIntentAddSteps = {
    //   type: 'add-steps',
    //   steps: [step]
    // }
    return [];
}
const system3 = `
<!-- modelType: geminiChat -->
<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) ou nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10, code2 (kimi 2.5) -->

You are a senior BUSINESS ANALYST and SOLUTION ARCHITECT with 20+ years of experience in system design, domain modeling, and backend architecture.

Your task is to analyze:
- a TO-BE conceptual model
- a TO-BE normalized-by-domain model

And generate a MATERIALIZED BACKEND PLAN for a single Domain.

---

## Mandatory rules (do NOT ignore)

1. **Reuse first**
   Before creating any new entity, you MUST verify if it already exists in a known module such as:
   - MDM
   - Finance
   - Inventory
   - CRM

   If reused or extended, mark:
   - entity.source = "existing" or "extended"
   - add a decision of type "reuse-existing-module" or "extend-existing-module"

2. **Avoid unnecessary tables**
   Do NOT create separate entities or tables unless strictly necessary.

   Prefer:
   - document-oriented persistence
   - single aggregate roots with embedded structures
   - JSON-style storage (e.g. Order with embedded OrderItems)

3. **Explicit persistence decisions**
   For each entity, decide and justify:
   - flat vs aggregate
   - document-style vs separate entities

   All non-trivial choices MUST be recorded in "decisions".

4. **Commands are authoritative**
   - Commands represent real backend use-cases
   - Do not create commands without clear business intent
   - Each command must map to an action and optional rules

5. **No assumptions**
   If information is missing:
   - make a reasonable assumption
   - record it as a decision with clear reasoning

---

## Output format

You MUST return strictly valid JSON.
No explanations outside JSON.
No comments.
No markdown.

[[OutputSection]]
`;
//#endregion 
