/// <mls fileReference="_100554_/l2/agents/agentToBePageDefs.ts" enhancement="_blank"/>
import { getSource, updateDefs, system1 } from '/_100554_/l2/agents/agentDefs.js';
export function createAgent() {
    return {
        agentName: "agentToBePageDefs",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Create or Update Defs",
        visibility: "public",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const implementPages = JSON.parse(userPrompt);
    const fileReference = implementPages?.pageSource?.join("\n").trim().split('\n')[0];
    const tripleSlash = mls.common.tripleslash.parseXMLTripleSlash(fileReference);
    let fileInfo = mls.stor.convertFileReferenceToFile(tripleSlash.variables['fileReference']);
    const key = mls.stor.getKeyToFile(fileInfo);
    const storFile = mls.stor.files[key];
    if (!userPrompt)
        throw new Error('invalid prompt');
    const inputs = [{
            type: "system",
            content: system1
        },
        {
            type: "human",
            content: await getSource(storFile)
        }];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        },
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    try {
        const asIs = payload.result;
        await updateDefs(asIs);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [updateStatus];
}
