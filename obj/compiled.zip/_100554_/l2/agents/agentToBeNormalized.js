/// <mls shortName="agentToBeNormalized" project="100554" enhancement="_100554_enhancementAgent" folder="agents" />
export function createAgent() {
    return {
        agentName: "agentToBeNormalized",
        agentProject: 100554,
        agentFolder: "agents",
        agentDescription: "Normalize ToBe conceptual",
        visibility: "private",
        beforePromptImplicit,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const isTest = true;
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1
                }, {
                    type: "human",
                    content: userPrompt
                }],
            taskTitle: agent.agentDescription,
            threadId: context.message.threadId,
            userMessage: isTest ? `test ${agent.agentName}` : agent.agentDescription,
            longTermMemory: {},
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]) || undefined;
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    try {
        const output = payload.result;
        intents = await processOutput(output);
    }
    catch (e) {
        console.error(e);
        status = 'failed';
    }
    if (step.stepId === 1)
        intents = []; // test mode do not advance
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(moduleToBe) {
    console.log("=== ModuleToBe Normalized");
    console.log(JSON.stringify(moduleToBe, null, 2));
    const isTest = true; // todo: define
    if (isTest)
        return [];
    const step = {
        type: 'agent',
        stepId: 0,
        interaction: null,
        status: 'pending',
        nextSteps: [],
        agentName: "agentNewModule5",
        prompt: "",
        rags: null,
    };
    // const rc: mls.msg.AgentIntentAddSteps = {
    //   type: 'add-steps',
    //   steps: [step]
    // }
    return [];
}
const system1 = `
<!-- modelType: codereasoning -->
<!-- modelTypeList: geminiChat 9/10 , code (grok) 7/10, deepseekchat 2/10, codeflash (gemini) 8/10, deepseekreasoner 3/10, mini (4.1) ou nano (openai) 4/10, codeinstruct (4.1) 4/10, codereasoning(gpt5) 3/10, code2 (kimi 2.5) -->


You are a senior BUSINESS Analyst with 20+ years of experience in system design,
requirements analysis, and business process optimization.

Your task is to analyze an existing TO-BE conceptual model and generate a
TO-BE NORMALIZED representation.

The TO-BE Normalized model is a NEUTRAL DOMAIN CONTRACT.
It must NOT contain UI concepts, API concepts, database technologies, or frameworks.

You must:

- Identify BOUNDED CONTEXTS and define them as domains (DDD-oriented).
- Identify AGGREGATE ROOT entities and mark them explicitly.
- Use "dataShape: aggregate" when an entity represents a composed business object.
- Use "event-derived" ONLY when data is clearly derived from domain events.
- Assign ownership using MDM semantics (system, user, shared).

Actions:
- Define DOMAIN ACTIONS (business intents), not UI or CRUD actions.
- Prefer verbs that express behavior (e.g. confirmOrder, cancelAppointment).
- Do NOT list read or search actions as domain actions.

States:
- Define only BUSINESS STATES that affect lifecycle.
- Avoid technical or UI states.

Events:
- Define DOMAIN EVENTS as immutable facts.
- Prefer specific events (e.g. OrderConfirmed) over generic ones (e.g. StatusUpdated).

Read Models:
- Define read models ONLY when they serve BI or LLM queries.
- Mark their purpose explicitly (BI, llm-query).

General rules:
- Do NOT invent functionality not present in the TO-BE model.
- Do NOT introduce technical or implementation details.
- Keep the model minimal, explicit, and semantically correct.
- Write all descriptions in the language specified in the "userLanguage" field.
- Write all domain IDs in English.

## Output format
Return only valid JSON in the following structure:
[[OutputSection]]

[[Types]]
`;
//#endregion
