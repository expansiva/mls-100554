/// <mls fileReference="_100554_/l2/collabOrgTeams.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import '/_100554_/l2/collabOrgTeamCard.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Times',
    btnNewTeam: 'Novo time',
    btnCancel: 'Cancelar',
    btnCreate: 'Criar',
    btnCreating: 'Criando…',
    colTeam: 'Time',
    colAuth: 'Auth',
    colProjects: 'Projetos',
    colUsers: 'Usuários',
    fieldName: 'Nome do time',
    viewProjects: 'Ver projetos',
    viewUsers: 'Ver usuários',
    loading: 'Carregando times…',
    error: 'Erro ao carregar times.',
    noTeams: 'Nenhum time encontrado.',
    feedbackSuccess: 'Time criado com sucesso.',
    feedbackError: 'Erro ao criar time.',
};
const message_en = {
    title: 'Teams',
    btnNewTeam: 'New Team',
    btnCancel: 'Cancel',
    btnCreate: 'Create',
    btnCreating: 'Creating…',
    colTeam: 'Team',
    colAuth: 'Auth',
    colProjects: 'Projects',
    colUsers: 'Users',
    fieldName: 'Team name',
    viewProjects: 'View projects',
    viewUsers: 'View users',
    loading: 'Loading teams…',
    error: 'Failed to load teams.',
    noTeams: 'No teams found.',
    feedbackSuccess: 'Team created successfully.',
    feedbackError: 'Failed to create team.',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
const MOCK_TEAMS = [
    { name: 'frontend', auth: 'write', projectCount: 3, userCount: 5 },
    { name: 'backend', auth: 'admin', projectCount: 4, userCount: 3 },
    { name: 'design', auth: 'read', projectCount: 2, userCount: 4 },
    { name: 'devops', auth: 'admin', projectCount: 6, userCount: 2 },
];
let CollabOrgTeams = class CollabOrgTeams extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-org-teams-100554 {
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
}
collab-org-teams-100554 .state-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 48px 24px;
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-16);
}
collab-org-teams-100554 .spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid var(--grey-color);
  border-top-color: var(--active-color);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-org-teams-100554 .feedback {
  font-size: var(--font-size-16);
  padding: 10px 14px;
  border-radius: 4px;
}
collab-org-teams-100554 .feedback.error {
  color: var(--error-color);
  background-color: var(--grey-color-lighter);
}
collab-org-teams-100554 .teams-root {
  max-width: 860px;
  margin: 0 auto;
  padding: 24px 16px;
  display: flex;
  flex-direction: column;
  gap: 24px;
}
collab-org-teams-100554 .header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
collab-org-teams-100554 .page-title {
  font-size: var(--font-size-24);
  color: var(--text-primary-color);
  margin: 0;
}
collab-org-teams-100554 .new-team-form-wrapper {
  border: 1px solid var(--grey-color-dark);
  border-radius: 4px;
  padding: 20px;
  background-color: var(--bg-secondary-color-lighter);
}
collab-org-teams-100554 .new-team-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
collab-org-teams-100554 .form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
collab-org-teams-100554 .form-group label {
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
}
collab-org-teams-100554 .form-group input {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
  border: 1px solid var(--grey-color-dark);
  border-radius: 4px;
  padding: 8px 12px;
  box-sizing: border-box;
  width: 100%;
}
collab-org-teams-100554 .form-group input:focus {
  outline: none;
  border-color: var(--active-color);
}
collab-org-teams-100554 .form-group input:disabled {
  background-color: var(--bg-primary-color-disabled);
  color: var(--text-primary-color-disabled);
  cursor: not-allowed;
}
collab-org-teams-100554 .form-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
collab-org-teams-100554 .btn-primary {
  padding: 8px 20px;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  background-color: var(--active-color);
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
collab-org-teams-100554 .btn-primary:hover:not(:disabled) {
  background-color: var(--active-color-hover);
}
collab-org-teams-100554 .btn-primary:disabled {
  background-color: var(--active-color-disabled);
  cursor: not-allowed;
}
collab-org-teams-100554 .btn-secondary {
  padding: 8px 20px;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  background-color: transparent;
  color: var(--text-primary-color);
  border: 1px solid var(--grey-color-dark);
  border-radius: 4px;
  cursor: pointer;
}
collab-org-teams-100554 .btn-secondary:hover:not(:disabled) {
  background-color: var(--bg-primary-color-hover);
}
collab-org-teams-100554 .btn-secondary:disabled {
  color: var(--text-primary-color-disabled);
  cursor: not-allowed;
}
collab-org-teams-100554 .table-wrapper {
  overflow-x: auto;
}
collab-org-teams-100554 .teams-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-16);
}
collab-org-teams-100554 .teams-table thead tr {
  background-color: var(--bg-secondary-color-lighter);
  border-bottom: 2px solid var(--grey-color-dark);
}
collab-org-teams-100554 .teams-table th {
  text-align: left;
  padding: 10px 14px;
  font-size: var(--font-size-16);
  color: var(--text-primary-color-lighter);
}
collab-org-teams-100554 .teams-table td {
  padding: 10px 14px;
  border-bottom: 1px solid var(--grey-color);
  color: var(--text-primary-color);
  vertical-align: middle;
}
collab-org-teams-100554 .team-row.expanded td {
  border-bottom: none;
}
collab-org-teams-100554 .expand-row td {
  padding: 0 0 1px 0;
  border-bottom: 1px solid var(--grey-color);
  background-color: var(--bg-secondary-color-lighter);
}
collab-org-teams-100554 .btn-expand {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-12);
  padding: 4px 6px;
}
collab-org-teams-100554 .btn-expand:hover {
  color: var(--text-primary-color);
}
collab-org-teams-100554 .td-name {
  font-weight: 600;
}
collab-org-teams-100554 .auth-badge {
  font-size: var(--font-size-12);
  padding: 2px 8px;
  border-radius: 4px;
}
collab-org-teams-100554 .auth-badge.auth-admin {
  background-color: var(--active-color);
  color: #fff;
}
collab-org-teams-100554 .auth-badge.auth-write {
  background-color: var(--success-color);
  color: #fff;
}
collab-org-teams-100554 .auth-badge.auth-read {
  background-color: var(--grey-color-dark);
  color: var(--text-primary-color);
}
collab-org-teams-100554 .btn-link {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--link-color);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  padding: 0;
  text-decoration: underline;
}
collab-org-teams-100554 .btn-link:hover {
  color: var(--link-color-hover);
}
collab-org-teams-100554 .no-teams {
  font-size: var(--font-size-16);
  color: var(--text-primary-color-lighter);
  margin: 0;
}
`);
        this.orgSlug = '';
        this.baseUrl = '';
        this.msg = messages['en'];
        this._teams = [];
        this._loading = false;
        this._error = '';
        this._expandedTeam = null;
        this._newTeamOpen = false;
        this._newTeamName = '';
        this._formStatus = 'idle';
        this._formError = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this._fetchTeams();
    }
    async _fetchTeams() {
        this._loading = true;
        this._error = '';
        this.requestUpdate();
        try {
            // const res = await fetch(`${this.baseUrl}/organizations/${this.orgSlug}/teams`);
            // if (!res.ok) throw new Error(`HTTP ${res.status}`);
            // this._teams = await res.json() as Team[];
            await new Promise((resolve) => setTimeout(resolve, 700));
            this._teams = [...MOCK_TEAMS];
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : 'Unknown error';
        }
        finally {
            this._loading = false;
            this.requestUpdate();
        }
    }
    async _handleCreate(e) {
        e.preventDefault();
        this._formStatus = 'saving';
        this._formError = '';
        this.requestUpdate();
        try {
            // const res = await fetch(`${this.baseUrl}/organizations/${this.orgSlug}/teams`, {
            //     method: 'POST',
            //     headers: { 'Content-Type': 'application/json' },
            //     body: JSON.stringify({ name: this._newTeamName }),
            // });
            // if (!res.ok) throw new Error(`HTTP ${res.status}`);
            await new Promise((resolve) => setTimeout(resolve, 600));
            this.dispatchEvent(new CustomEvent('team-created', {
                detail: { name: this._newTeamName },
                bubbles: true,
                composed: true,
            }));
            this._formStatus = 'success';
            this._newTeamName = '';
            await this._fetchTeams();
            this._newTeamOpen = false;
            this._formStatus = 'idle';
        }
        catch (err) {
            this._formStatus = 'error';
            this._formError = err instanceof Error ? err.message : 'Unknown error';
        }
        finally {
            this.requestUpdate();
        }
    }
    _toggleExpand(teamName) {
        this._expandedTeam = this._expandedTeam === teamName ? null : teamName;
        this.requestUpdate();
    }
    _toggleNewTeam() {
        this._newTeamOpen = !this._newTeamOpen;
        this._newTeamName = '';
        this._formStatus = 'idle';
        this._formError = '';
        this.requestUpdate();
    }
    _handleNameInput(e) {
        const target = e.target;
        this._newTeamName = target.value;
    }
    _emitViewProjects(teamName) {
        this.dispatchEvent(new CustomEvent('view-team-projects', {
            detail: { team_name: teamName },
            bubbles: true,
            composed: true,
        }));
    }
    _emitViewUsers(teamName) {
        this.dispatchEvent(new CustomEvent('view-team-users', {
            detail: { team_name: teamName },
            bubbles: true,
            composed: true,
        }));
    }
    _renderNewTeamForm() {
        const saving = this._formStatus === 'saving';
        return html `
            <div class="new-team-form-wrapper">
                <form class="new-team-form" @submit="${(e) => this._handleCreate(e)}">
                    <div class="form-group">
                        <label for="new-team-name">${this.msg.fieldName}</label>
                        <input
                            id="new-team-name"
                            type="text"
                            .value="${this._newTeamName}"
                            ?disabled="${saving}"
                            @input="${(e) => this._handleNameInput(e)}"
                        />
                    </div>

                    ${this._formStatus === 'error' ? html `
                        <div class="feedback error">${this._formError || this.msg.feedbackError}</div>
                    ` : ''}

                    <div class="form-actions">
                        <button
                            type="button"
                            class="btn-secondary"
                            ?disabled="${saving}"
                            @click="${() => this._toggleNewTeam()}"
                        >${this.msg.btnCancel}</button>
                        <button type="submit" class="btn-primary" ?disabled="${saving}">
                            ${saving ? this.msg.btnCreating : this.msg.btnCreate}
                        </button>
                    </div>
                </form>
            </div>
        `;
    }
    _renderTable() {
        if (this._teams.length === 0) {
            return html `<p class="no-teams">${this.msg.noTeams}</p>`;
        }
        return html `
            <div class="table-wrapper">
                <table class="teams-table">
                    <thead>
                        <tr>
                            <th></th>
                            <th>${this.msg.colTeam}</th>
                            <th>${this.msg.colAuth}</th>
                            <th>${this.msg.colProjects}</th>
                            <th>${this.msg.colUsers}</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this._teams.map((t) => this._renderRow(t))}
                    </tbody>
                </table>
            </div>
        `;
    }
    _renderRow(t) {
        const expanded = this._expandedTeam === t.name;
        return html `
            <tr class="team-row ${expanded ? 'expanded' : ''}">
                <td class="td-toggle">
                    <button class="btn-expand" @click="${() => this._toggleExpand(t.name)}">
                        ${expanded ? '▲' : '▼'}
                    </button>
                </td>
                <td class="td-name">${t.name}</td>
                <td class="td-auth"><span class="auth-badge auth-${t.auth}">${t.auth}</span></td>
                <td class="td-link">
                    <button class="btn-link" @click="${() => this._emitViewProjects(t.name)}">
                        ${t.projectCount} ${this.msg.viewProjects}
                    </button>
                </td>
                <td class="td-link">
                    <button class="btn-link" @click="${() => this._emitViewUsers(t.name)}">
                        ${t.userCount} ${this.msg.viewUsers}
                    </button>
                </td>
            </tr>
            ${expanded ? html `
                <tr class="expand-row">
                    <td colspan="5">
                        <collab-org-team-card-100554
                            team-name="${t.name}"
                            org-slug="${this.orgSlug}"
                            base-url="${this.baseUrl}"
                        ></collab-org-team-card-100554>
                    </td>
                </tr>
            ` : ''}
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this._loading) {
            return html `
                <div class="state-loading">
                    <span class="spinner"></span>
                    <span>${this.msg.loading}</span>
                </div>
            `;
        }
        if (this._error) {
            return html `<div class="feedback error">${this._error}</div>`;
        }
        return html `
            <div class="teams-root">

                <div class="header">
                    <h1 class="page-title">${this.msg.title}</h1>
                    <button class="btn-primary" @click="${() => this._toggleNewTeam()}">
                        ${this._newTeamOpen ? this.msg.btnCancel : this.msg.btnNewTeam}
                    </button>
                </div>

                ${this._newTeamOpen ? this._renderNewTeamForm() : ''}

                ${this._renderTable()}

            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabOrgTeams.prototype, "orgSlug", void 0);
__decorate([
    property({ type: String })
], CollabOrgTeams.prototype, "baseUrl", void 0);
CollabOrgTeams = __decorate([
    customElement('collab-org-teams-100554')
], CollabOrgTeams);
export { CollabOrgTeams };
