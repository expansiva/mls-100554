/// <mls fileReference="_100554_/l2/previewModeSinglePage.ts" enhancement="_100554_/l2/enhancementLit" />
import { setErrorOnModel, convertTagToFileName, getPath } from '/_102027_/l2/utils.js';
import * as util from '/_100554_/l2/previewModeUtil.js';
export class PreviewModeSinglePage {
    constructor(_j, _i, _l, _s, _f, _m) {
        this.isService = false;
        this.models = undefined;
        this.file = undefined;
        this.needAwait = true;
        this.json = _j;
        this.ifr = _i;
        this.level = _l;
        this.isService = _s;
        this.file = _f;
        this.models = _m;
    }
    async init() {
        if (!this.json || !this.ifr)
            return;
        await this.loadEsbuild();
        if (this.needAwait)
            setTimeout(async () => await this.configIframe(), 200);
        else
            this.configIframe();
    }
    async buildJS(other) {
        await this.loadEsbuild();
        return this._buildJS(other);
    }
    async configIframe() {
        if (!this.json || !this.ifr || !this.esbuild || !this.file)
            return;
        const find = this.findWidgets(this.ifr.contentDocument?.body);
        const savedBody = this.ifr.contentDocument?.body.innerHTML || '';
        if (this.ifr.contentDocument)
            this.ifr.contentDocument.body.innerHTML = '';
        const result = await this._buildJS(find);
        util.mountJSImporMap(this.json, this.ifr);
        util.mountLinks(this.json, this.ifr);
        util.mountTokens(this.json.tokens || '', this.file);
        util.addJsReference(this.ifr, this.level || '2');
        const s = document.createElement('script');
        s.textContent = result.outputFiles[0].text;
        this.ifr.contentDocument?.body.appendChild(s);
        if (this.isService && this.file)
            util.simulateService(this.json, this.ifr, this.file);
        if (this.ifr && this.ifr.contentDocument && savedBody) {
            const div = this.ifr.contentDocument.createElement('div');
            div.innerHTML = savedBody;
            div.style.height = '100%';
            this.ifr.contentDocument.body.appendChild(div);
            //this.ifr.contentDocument.body.insertAdjacentHTML('beforeend', savedBody);
        }
    }
    async _buildJS(other) {
        if (!this.json || !this.esbuild || !this.file)
            return;
        let myMap = this.parseImportsMap(this.json.importsMap);
        let valids = [...Object.keys(myMap), ...this.json.importsJs, ...other];
        valids = [...new Set(valids)];
        if (Object.keys(myMap).length === 0) {
            const enhancementModules = await import('/_100554_/l2/enhancementLit.js');
            const maps = enhancementModules.requires.filter((item) => item.type === 'cdn');
            maps.forEach((item) => {
                myMap[item.name] = item.ref;
            });
        }
        const virtualFsPlugin = {
            name: 'virtual-fs',
            setup(build) {
                build.onResolve({ filter: /.*/ }, (args) => {
                    if (args.path.startsWith('./_100554_')) {
                        return {
                            path: args.path.replace('./_100554_', '/_100554_'),
                            namespace: 'virtual',
                        };
                    }
                    if (valids.includes(args.path)) {
                        return {
                            path: args.path,
                            namespace: 'virtual',
                        };
                    }
                    if (args.path.startsWith("_") &&
                        !args.importer.startsWith("https://")) {
                        return {
                            path: args.path.replace('_', '/_'),
                            namespace: 'virtual',
                        };
                    }
                    if ((args.path.startsWith("/") || args.path.startsWith("./") || args.path.startsWith("../")) &&
                        !args.importer.startsWith("https://") && !myMap[args.importer]) {
                        const url = new URL(args.path, 'file:' + args.importer);
                        let path = url.pathname;
                        if (!(/_(\d+)_/.test(path))) {
                            const info = getPath(args.importer.replace('/l2/', '').replace('/', ''));
                            if (!info)
                                throw new Error('[virtualFsPlugin] Not found path:' + args.importer.replace('/l2/', '').replace('/', ''));
                            if (!info.project)
                                info.project = mls.actualProject;
                            if (path.indexOf(`_${info.project}_`) < 0) {
                                path = url.pathname.replace('/', `/_${info.project}_`);
                            }
                        }
                        return { path, namespace: 'virtual' };
                    }
                    // import url externa
                    if ((args.path.startsWith("./") ||
                        args.path.startsWith("../") ||
                        args.path.startsWith("/")) &&
                        args.importer.startsWith("https://")) {
                        const url = new URL(args.path, args.importer);
                        return { path: url.href, namespace: 'virtual' };
                    }
                    // import url externa
                    if (args.path.startsWith("/") && myMap[args.importer]) {
                        const url = new URL(args.path, myMap[args.importer]);
                        return { path: url.href, namespace: 'virtual' };
                    }
                    // url externa
                    if (args.path.startsWith("http")) {
                        return { path: args.path, namespace: 'virtual' };
                    }
                    if (myMap[args.path]) {
                        return { path: myMap[args.path], namespace: 'virtual' };
                    }
                    return null;
                });
                build.onLoad({ filter: /.*/, namespace: 'virtual' }, async (args) => {
                    try {
                        let path = myMap[args.path] ? myMap[args.path] : args.path;
                        const res = await fetch(path);
                        if (!res.ok)
                            throw new Error(`Error get ${args.path}`);
                        const text = await res.text();
                        return { contents: text, loader: 'js' };
                    }
                    catch (e) {
                        console.info('erro:' + args.path);
                        return {
                            contents: '',
                            loader: 'js',
                            warnings: [{
                                    text: e.message, notes: [
                                        { text: 'build-error' }
                                    ]
                                }]
                        };
                    }
                });
            },
        };
        let allImports = [...this.json.importsJs, ...other];
        allImports = [...new Set(allImports)];
        const virtualEntryPath = "virtual-entry.js";
        const virtualEntryContent = allImports.map(path => `import "${path}";`).join("\n");
        const cachedJs = this.loadCache();
        const result = cachedJs ? cachedJs : await this.esbuild.build({
            stdin: {
                contents: virtualEntryContent,
                resolveDir: "/",
                sourcefile: virtualEntryPath,
                loader: "js"
            },
            bundle: true,
            minify: true,
            format: "esm",
            sourcemap: 'inline',
            write: false,
            plugins: [virtualFsPlugin]
        });
        if (result.warnings && result.warnings.length > 0) {
            const msgs = result.warnings
                .filter((item) => item.notes?.[0]?.text === 'build-error')
                .map((item) => item.text)
                .join('\n');
            if (this.models?.ts?.model && msgs.trim()) {
                const lineLength = this.models.ts.model.getLineLength(1);
                setErrorOnModel(this.models.ts.model, 1, 1, lineLength, msgs, monaco.MarkerSeverity.Error);
                this.models.ts.storFile.hasError = true;
            }
        }
        if (!window.cachePreview) {
            window.cachePreview = {};
        }
        window.cachePreview[this.json.importsJs[0]] = result;
        return result;
    }
    parseImportsMap(importsArray) {
        return Object.fromEntries(importsArray.map(str => {
            const match = str.match(/^"(.+?)":\s*"(.+?)"$/);
            if (!match)
                throw new Error("Formato inválido: " + str);
            const [, key, value] = match;
            return [key, value];
        }));
    }
    findWidgets(rootElement) {
        if (!rootElement)
            return [];
        const els = rootElement.querySelectorAll('[widget]');
        const array = Array.from(els)
            .map((el) => {
            if (!el.tagName.toLocaleLowerCase().startsWith('ica-'))
                return '';
            const info = convertTagToFileName(el.getAttribute('widget') || '');
            if (!info)
                return '';
            return '/' + `_${info.project}_${info.shortName}`;
        })
            .filter(Boolean);
        const ret = [...new Set(array)];
        return ret;
    }
    async loadEsbuild() {
        this.needAwait = true;
        if (mls.esbuild) {
            this.esbuild = mls.esbuild;
            this.needAwait = false;
        }
        else if (!mls.esbuildInLoad)
            await this.initializeEsBuild();
    }
    async initializeEsBuild() {
        mls.esbuildInLoad = true;
        const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
        if (!this.esbuild) {
            this.esbuild = await import(url);
            await this.esbuild.initialize({
                wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
            });
            mls.esbuild = this.esbuild;
            mls.esbuildInLoad = false;
        }
    }
    loadCache() {
        if (mls.actualLevel !== 7)
            return;
        if (!window.cachePreview || !this.json)
            return;
        if (!window.cachePreview[this.json.importsJs[0]])
            return;
        let needCompile = false;
        this.json.importsJs.forEach((i) => {
            const name = i.startsWith('/') ? i.replace('/', '') : i;
            const f = getPath(name);
            if (!f)
                throw new Error('[loadCache] Not found path:' + name);
            const key = mls.stor.getKeyToFiles(f.project, 2, f.shortName, f.folder, '.ts');
            if (mls.stor.files[key] && mls.stor.files[key].inLocalStorage) {
                needCompile = true;
            }
        });
        if (needCompile)
            return;
        return window.cachePreview[this.json.importsJs[0]];
    }
}
