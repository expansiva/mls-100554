/// <mls shortName="pluginPreviewInsights" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_code, collab_file_fragment, collab_file_half_dashed } from '/_100554_/l2/collabIcons.js';
import { globalState } from '/_100554_/l2/collabState.js';
import { collabImport } from '/_100554_/l2/collabImport.js';
import { createModel } from '/_100554_/l2/collabLibModel.js';
import '/_100554_/l2/widgetDefsListEdit.js';
/// **collab_i18n_start**
const message_pt = {
    tecInsights: 'Insights técnicos',
    busInsights: 'Insights de negócio',
    settingsInsights: 'Configurações',
    insightFor: 'Insight para'
};
const message_en = {
    tecInsights: 'Technical Insights',
    busInsights: 'Business Insights',
    settingsInsights: 'Settings',
    insightFor: 'Insight for'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginPreviewInsights100554 = class PluginPreviewInsights100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-preview-insights-100554{display:block;font-family:var(--font-family-primary);padding:1rem;position:relative;background-color:var(--bg-primary-color);color:var(--text-primary-color);font-size:var(--font-size-16);border-radius:10px;overflow:auto;height:calc(100% - 20px)}plugin-preview-insights-100554 .header{display:flex;align-items:center;margin-bottom:var(--space-16)}plugin-preview-insights-100554 .tab-header{display:flex;justify-content:space-between;border-bottom:1px solid #ccc;background-color:var(--bg-primary-color);overflow:hidden;flex-shrink:0}plugin-preview-insights-100554 .tab-group-left{display:flex;overflow-x:auto;flex:1;min-width:0;scrollbar-width:thin}plugin-preview-insights-100554 .tab-group-left::-webkit-scrollbar{height:6px}plugin-preview-insights-100554 .tab-group-left::-webkit-scrollbar-thumb{background-color:var(--grey-color-darker);border-radius:4px}plugin-preview-insights-100554 .tab-group-right{display:flex;flex-shrink:0}plugin-preview-insights-100554 .tab-item{display:flex;align-items:center;position:relative}plugin-preview-insights-100554 .tab-button{padding:10px 16px;cursor:pointer;background:none;border:none;border-right:1px solid var(--grey-color);font-size:14px;transition:background-color .2s ease;display:flex;flex-direction:column}plugin-preview-insights-100554 .tab-button:not(.active):hover{background-color:var(--grey-color-light);color:var(--text-primary-color)}plugin-preview-insights-100554 .tab-button.active{background-color:var(--bg-primary-color-lighter-disabled);font-weight:bold;border-bottom:2px solid var(--active-color)}plugin-preview-insights-100554 .tab-content{position:relative;flex:1;padding:var(--space-8);margin:0;background-color:var(--bg-primary-color-lighter);color:var(--text-primary-color);display:flex;flex-grow:1;flex-direction:column}plugin-preview-insights-100554 .tab-content h1{padding-left:.3rem;display:flex;gap:.5rem;align-items:center}plugin-preview-insights-100554 .tab-content h1 svg{fill:var(--text-primary-color);color:var(--text-primary-color)}plugin-preview-insights-100554 section{padding:.5rem .8rem;margin-bottom:1.5rem;border:1px solid #cecece;border-radius:10px}plugin-preview-insights-100554 .business .planning-info{margin-bottom:2rem;display:flex;flex-direction:column;gap:1rem}plugin-preview-insights-100554 .business .planning-checklist-item{display:flex;gap:.3rem;align-items:center;padding-left:.5rem}plugin-preview-insights-100554 .business .planning-checklist-item widget-defs-planning-checklist-edit-100554{flex:1}plugin-preview-insights-100554 .business .planning-checklist-item i{cursor:pointer;width:20px;visibility:hidden;pointer-events:none}plugin-preview-insights-100554 .business .planning-checklist-item:hover i{visibility:visible;pointer-events:all}plugin-preview-insights-100554 .business .planning-add-item{display:flex;justify-content:center;align-items:center;cursor:pointer;padding:.3rem;border:1px solid transparent;color:var(--active-color)}plugin-preview-insights-100554 .business .planning-add-item svg{fill:var(--active-color)}plugin-preview-insights-100554 .business .planning-add-item:hover{border:1px solid var(--grey-color-light)}plugin-preview-insights-100554 .business .add-new-userStorie-container{display:flex;width:100%}plugin-preview-insights-100554 .business .add-new-userStorie-container button{cursor:pointer;padding:.3rem .6rem;border:1px solid #ccc;border-radius:4px;background:#f8f8f8;font-size:.85rem;display:flex;gap:.3rem}plugin-preview-insights-100554 .business .section{display:block;padding:.2rem 1.5em}plugin-preview-insights-100554 .business .section details{margin-bottom:1rem}plugin-preview-insights-100554 .business .section details .summary-done{color:var(--success-color)}plugin-preview-insights-100554 .business .section details .summary-done svg{fill:var(--success-color)}plugin-preview-insights-100554 .business .section details .summary-pending{color:var(--warning-color)}plugin-preview-insights-100554 .business .section details .summary-pending svg{fill:var(--warning-color)}plugin-preview-insights-100554 .business .section details>div{margin-left:1rem;padding:1rem}plugin-preview-insights-100554 .business .section details>summary{cursor:pointer}plugin-preview-insights-100554 .business .section details>summary svg{height:14px;width:14px}plugin-preview-insights-100554 .technical .meta-item{display:flex;flex-direction:column;gap:.3rem;overflow:hidden;width:100%}plugin-preview-insights-100554 .technical .meta-item input[type="text"]{padding:4px 4px;border:1px solid #d1d1d1;background-color:#fff;color:#000;font-size:14px;transition:border-color .3s ease;outline:none;line-height:1.2}plugin-preview-insights-100554 .metric{margin-bottom:1em;display:flex;align-items:center;gap:.5em}plugin-preview-insights-100554 .metric label{width:140px;display:inline-block}plugin-preview-insights-100554 .metric input{width:60px}plugin-preview-insights-100554 .emoji{font-size:1.5em}`);
        this.page = '';
        this.level = 0;
        this.loading = false;
        this.mode = 'technical';
        this.models = undefined;
        this.msg = messages['en'];
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('page') && this.page) {
            this.setInfos();
            this.requestUpdate();
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.asIs)
            return html `<div>Defs not found'</div>`;
        const aux = this.loading ? '' : 'none';
        return html `
            <div class="overlay" style="display:${aux}">
                <div class="spinner"></div>
            </div>
            <div class="actions">
                ${this.renderHead()}
                
            </div>
            <div>
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button
                            class="tab-button ${this.mode === 'technical' ? 'active' : ''}" @click=${() => this.setTabActive('technical')} >
                            ${this.msg.tecInsights}
                        </button>
                        <button
                            class="tab-button ${this.mode === 'business' ? 'active' : ''}" @click=${() => this.setTabActive('business')} >
                            ${this.msg.busInsights}

                        </button>
                        <button
                            class="tab-button ${this.mode === 'settings' ? 'active' : ''}" @click=${() => this.setTabActive('settings')} >
                            ${this.msg.settingsInsights}
                        </button>
                    </div>
                    <button @click=${this.saveDefs}>Save</button>
            </div>
        <div class="tab-content">
            ${this.renderMode()}
        </div>
    </div>`;
    }
    renderHead() {
        return html `
            <div class="header" >
                <strong>${this.msg.insightFor} ${this.fileType} : </strong> ${this.page}
            </div>
                        `;
    }
    renderMode() {
        switch (this.mode) {
            case 'business': return this.renderBusiness();
            case 'technical': return this.renderTechnical();
            case 'settings': return this.renderSettings();
            default: html `Invalid tab`;
        }
    }
    renderSettings() {
        return html `
            <div class="settings">
                In development Settings
            </div>
        `;
    }
    renderTechnical() {
        return html `
            <div class="technical">
                <h1>${collab_file_half_dashed}Meta</h1>
                <section>
                  ${this.renderMeta()}
                </section>
                <h1>${collab_file_fragment} References</h1>
                <section>
                  ${this.renderWidgets()}
                </section>
                <section>
                  ${this.renderStatesRO()}
                </section>
                <section>
                  ${this.renderStatesRW()}
                </section>
                <section>
                  ${this.renderStatesWO()}
                </section>

                <h1>${collab_code} Code Insights</h1>
                <section>
                  ${this.renderTodos()}
                </section>
                <section>
                  ${this.renderSecurityWarnings()}
                </section>
                <section>
                  ${this.renderUnusedImports()}
                </section>
                <section>
                  ${this.renderDeadCodeBlocks()}
                </section>
                <section>
                  ${this.renderAccessibility()}
                </section>
                <section>
                  ${this.renderi18nWarnings()}
                </section>                
            </div>
        `;
    }
    renderWidgets() {
        return html `
    <h3>Widgets</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.references?.webComponents || []}
      @onSaveEditClick=${(e) => this.onSaveReferencesWidgets(e.detail.item)} 
    ></widget-defs-list-edit-100554>
    `;
    }
    renderStatesRO() {
        return html `
    <h3>States RO (read-only)</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.references?.statesRO}
      @onSaveEditClick=${(e) => this.onSaveReferences('statesRO', e.detail.item)}
    ></widget-defs-list-edit-100554>
    `;
    }
    renderStatesRW() {
        return html `
    <h3>States RW (read-write)</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.references?.statesRW}
      @onSaveEditClick=${(e) => this.onSaveReferences('statesRW', e.detail.item)}
    ></widget-defs-list-edit-100554>
    `;
    }
    renderStatesWO() {
        return html `
    <h3>States WO</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.references?.statesWO}
      @onSaveEditClick=${(e) => this.onSaveReferences('statesWO', e.detail.item)}
    ></widget-defs-list-edit-100554>
    `;
    }
    renderi18nWarnings() {
        return html `
    <h3>i18nWarnings</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.codeInsights?.i18nWarnings}
      @onSaveEditClick=${(e) => this.onSaveCodeInsights('i18nWarnings', e.detail.item)}
    ></widget-defs-list-edit-100554>
    `;
    }
    renderAccessibility() {
        return html `
    <h3>Accessibility</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.codeInsights?.accessibilityIssues}
      @onSaveEditClick=${(e) => this.onSaveCodeInsights('accessibilityIssues', e.detail.item)}    
    ></widget-defs-list-edit-100554>
    `;
    }
    renderTodos() {
        return html `
    <h3>Todos</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.codeInsights?.todos}
      @onSaveEditClick=${(e) => this.onSaveCodeInsights('todos', e.detail.item)}    
    ></widget-defs-list-edit-100554>
    `;
    }
    renderSecurityWarnings() {
        return html `
    <h3>SecurityWarnings</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.codeInsights?.securityWarnings}
      @onSaveEditClick=${(e) => this.onSaveCodeInsights('securityWarnings', e.detail.item)}    
    ></widget-defs-list-edit-100554>
    `;
    }
    renderDeadCodeBlocks() {
        return html `
    <h3>DeadCodeBlocks</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.codeInsights?.deadCodeBlocks}
      @onSaveEditClick=${(e) => this.onSaveCodeInsights('deadCodeBlocks', e.detail.item)}    
    ></widget-defs-list-edit-100554>
    `;
    }
    renderUnusedImports() {
        return html `
    <h3>UnusedImports</h3>
    <widget-defs-list-edit-100554
      .listItem=${this.asIs?.codeInsights?.securityWarnings}
      @onSaveEditClick=${(e) => this.onSaveCodeInsights('securityWarnings', e.detail.item)}    
    ></widget-defs-list-edit-100554>
    `;
    }
    renderMeta() {
        return html `
    <div class="meta-container">
      <div class="meta-item">
        <label>Group:</label>
        <input type="text" .value=${this.asIs?.meta.group || ''}></input>
      </div>
    </div>
    
    `;
    }
    renderBusiness() {
        if (!this.asIs?.asIs.semantic.generalDescription)
            return html `No planning`;
        return html `
      <div class="business">
        <h1>Planning</h1>
          <div class="planning-info">
            <div class="field">
              <div class="label">📝 Description:</div>
              <div class="value">${this.asIs?.asIs.semantic.generalDescription || '—'}</div>
            </div>
          </div>
      </div>
        `;
    }
    onSaveCodeInsights(mode, value) {
        if (!this.asIs || !this.asIs.codeInsights || !this.asIs.codeInsights[mode])
            return;
        this.asIs.codeInsights[mode] = value;
        this.requestUpdate();
    }
    onSaveReferences(mode, value) {
        if (!this.asIs || !this.asIs.references || !this.asIs.references[mode])
            return;
        this.asIs.references[mode] = value;
        this.requestUpdate();
    }
    onSaveReferencesWidgets(value) {
        debugger;
        if (!this.asIs || !this.asIs.references)
            return;
        this.asIs.references.webComponents = value;
        this.requestUpdate();
    }
    async setInfos() {
        if (!this.page)
            throw new Error(`Page not found: ${this.page}`);
        const { project, folder, shortName } = mls.l2.getPath(this.page);
        if (!project || !shortName)
            throw new Error(`Project or shortName invalids: ${this.page}`);
        const mkey = mls.editor.getKeyModel(project, shortName, folder, 2);
        this.models = mls.editor.models[mkey];
        const moduleDefs = await collabImport({ project, folder, shortName, extension: '.defs.ts' });
        if (!moduleDefs)
            throw new Error('Invalid module defs.ts:' + mkey);
        if (!moduleDefs.asis)
            throw new Error('Invalid const asIs in module .defs.ts:' + mkey);
        this.asIs = moduleDefs.asis;
        this.fileType = this.asIs?.meta.componentType;
    }
    saveDefs() {
        if (!this.asIs)
            return;
        this.updateDefs(this.asIs);
    }
    async updateDefs(defs) {
        const fileReference = defs?.meta?.fileReference || "";
        let fileInfo = mls.stor.convertFileReferenceToFile(fileReference);
        if (!fileReference || fileInfo.project < 1)
            throw new Error(`Invalid step in update defs, incorrect meta fileRecerence: ${fileReference}`);
        const template = `/// <mls fileReference="${defs.meta.fileReference}" enhancement="_blank" />

// Do not change – automatically generated code. 

export const asis: mls.defs.AsIs = ${JSON.stringify(defs, null, 2)}
    `;
        const params = { ...fileInfo, content: template, versionRef: '0', extension: '.defs.ts' };
        await this.updateStorFile(params);
    }
    async updateStorFile(params) {
        const file = await mls.stor.addOrUpdateFile(params);
        if (!file)
            throw new Error('[agentDefs] Invalid storFile');
        const path = mls.stor.getKeyToFile(params);
        console.log(`[agentDefs] updating file: ${path}`);
        const models = mls.editor.getModels(params.project, params.shortName, params.folder, params.level);
        let modelDefs = models?.defs;
        if (!modelDefs) {
            modelDefs = await createModel(file, false, false);
        }
        if (!modelDefs)
            return;
        const serviceSource = globalState._ica?.serviceSource.left?.service;
        if (!serviceSource)
            throw new Error('Not found service source instance');
        serviceSource.setValueInModeKeepingUndo(modelDefs.model, params.content, false);
    }
    setTabActive(tab) {
        this.mode = tab;
    }
};
__decorate([
    property({ type: String })
], PluginPreviewInsights100554.prototype, "page", void 0);
__decorate([
    property({ type: String, converter: Number })
], PluginPreviewInsights100554.prototype, "level", void 0);
__decorate([
    property({ type: String })
], PluginPreviewInsights100554.prototype, "fileType", void 0);
__decorate([
    state()
], PluginPreviewInsights100554.prototype, "asIs", void 0);
__decorate([
    state()
], PluginPreviewInsights100554.prototype, "loading", void 0);
__decorate([
    state()
], PluginPreviewInsights100554.prototype, "mode", void 0);
PluginPreviewInsights100554 = __decorate([
    customElement('plugin-preview-insights-100554')
], PluginPreviewInsights100554);
export { PluginPreviewInsights100554 };
