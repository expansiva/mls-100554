/// <mls fileReference="_100554_/l2/pluginExploreListAddL1.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { propertyDataSource } from '/_100554_/l2/collabDecorators.js';
import { isNameValid } from '/_100554_/l2/libCommom.js';
import { createStorFile } from '/_100554_/l2/collabLibStor.js';
import { getPath } from '/_102027_/l2/utils.js';
/// **collab_i18n_start**
const message_pt = {
    labelProject: "Projeto",
    labelShortName: "Nome",
    invalidName: "Nome invalido",
    labelType: "Por favor, selecione um modelo abaixo",
    btnAdd: "Adicionar",
    please: "Por facor selecione um projeto primeiro!",
    msgInitial: "Por favor, selecione um modelo",
};
const message_en = {
    labelProject: "Project",
    labelShortName: "Shortname",
    invalidName: "Invalid shortName",
    labelType: "Please select a template below",
    btnAdd: "Add",
    please: "Please select a project first!",
    msgInitial: "Please select a template",
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceListFilesAdd100554 = class ServiceListFilesAdd100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-explore-list-add-l1-100554 {
  overflow-y: auto;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
plugin-explore-list-add-l1-100554 .headerNav {
  height: 40px;
  background: var(--bg-primary-color-darker-hover);
  border-bottom: 1px solid var(--bg-primary-color-lighter);
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  box-shadow: 0 1px 3px var(--bg-primary-color-lighter);
}
plugin-explore-list-add-l1-100554 .headerNav h1 {
  font-size: 16px;
  font-weight: 500;
  color: var(--text-primary-color);
  margin: 0;
  pointer-events: none;
}
plugin-explore-list-add-l1-100554 .headerNav .btn-nav {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  border: none;
  background-color: var(--grey-color-darker);
  color: var(--text-primary-color);
  width: 26px;
  height: 26px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.2s;
}
plugin-explore-list-add-l1-100554 .headerNav.left .btn-nav {
  left: 10px;
}
plugin-explore-list-add-l1-100554 .headerNav.right .btn-nav {
  right: 10px;
}
plugin-explore-list-add-l1-100554 .headerNav .btn-nav:hover {
  opacity: 0.5;
}
plugin-explore-list-add-l1-100554 .headerNav .btn-nav svg {
  width: 14px;
  height: 14px;
  fill: #fff;
}
plugin-explore-list-add-l1-100554 button {
  background-color: var(--bg-secondary-color-lighter);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: var(--text-primary-color);
  cursor: pointer;
}
plugin-explore-list-add-l1-100554 button:hover {
  background-color: var(--grey-color-light);
}
plugin-explore-list-add-l1-100554 input,
plugin-explore-list-add-l1-100554 select,
plugin-explore-list-add-l1-100554 textarea {
  display: block;
  font-size: 1rem;
  line-height: 1.5;
  color: #000000;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
}
plugin-explore-list-add-l1-100554 .section-add {
  padding: 0 1rem;
}
plugin-explore-list-add-l1-100554 .row-form {
  display: flex;
  gap: 0.5rem;
}
plugin-explore-list-add-l1-100554 .row-form button {
  display: inline-block;
  width: 80px;
  height: 25px;
  padding: 0;
  text-align: center;
}
plugin-explore-list-add-l1-100554 .row-form span {
  color: var(--error-color);
  width: 100px;
  top: -5px;
  font-size: 12px;
}
plugin-explore-list-add-l1-100554 .row-form .btn-cancel:hover {
  color: var(--error-color);
}
plugin-explore-list-add-l1-100554 .template-container {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-around;
  margin: auto;
  margin-top: 1rem;
}
plugin-explore-list-add-l1-100554 .template-container:hover .template-item:not(:hover) {
  opacity: 0.5;
}
plugin-explore-list-add-l1-100554 .template-container .template-item {
  flex: 1 1 500px;
  margin: 10px;
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  transition: 0.3s;
  cursor: pointer;
}
plugin-explore-list-add-l1-100554 .template-container .template-item:hover {
  background-color: var(--grey-color-light);
}
plugin-explore-list-add-l1-100554 .template-container .template-item .template-item-content {
  padding: 20px;
}
plugin-explore-list-add-l1-100554 .template-container .template-item .template-item-content .template-item-title {
  font-weight: bold;
  font-size: var(--font-size-24);
}
plugin-explore-list-add-l1-100554 .template-container .template-item .template-item-content .template-item-body {
  text-align: justify;
  font-size: var(--font-size-16);
}
plugin-explore-list-add-l1-100554 .template-container .template-item .template-item-content .template-item-tags {
  font-size: var(--font-size-12);
  text-transform: uppercase;
  font-weight: bold;
}
plugin-explore-list-add-l1-100554 input,
plugin-explore-list-add-l1-100554 select,
plugin-explore-list-add-l1-100554 textarea {
  outline: none;
}
`);
        this.baseProject = 100554;
        this.msg = messages['en'];
        this.level = mls.actualLevel;
        this.error = '';
        this.position = '';
        this.loading = true;
    }
    async connectedCallback() {
        super.connectedCallback();
        await this.init();
    }
    async init() {
        this.loading = false;
    }
    render() {
        const lang = this.service?.getMessageKey(messages);
        this.msg = lang ? messages[lang] : message_en;
        const project = mls.actualProject || 0;
        return html `
            ${this.renderHeader()}
            ${project !== undefined ? this.renderAdd(project)
            : html `${this.msg.please}`}
        `;
    }
    renderHeader() {
        return html `
            <div class="headerNav left">
                <h1>Add</h1>
                <button class="btn-nav" title="add organism" @click="${() => this.clickCancel()}">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg>
                </button>            
            </div>
        `;
    }
    renderAdd(project) {
        return html `
            <div class="section-add">
                <div class="row-form">
                    <div>
                        <label>${this.msg.labelProject}:</label>
                        <input type="text" disabled value="${project.toString()}"/>
                    </div>
                    <div>
                        <label>${this.msg.labelShortName}:</label>
                        <input autocomplete="off" value=${this.shortName} type="text" id="iptShortName" @input=${this.handleInputInput}/>
                        <span>${this.error}</span>
                    </div>
                    <div style="display: flex;justify-content: center;align-items: center;padding-top: 19px;">
                        <button class="btn-save" @click=${this.createFile}>Execute</button>
                    </div>
                </div>
            </div>

        `;
    }
    handleInputInput(e) {
        const target = e.target;
        if (!target)
            return;
        const project = mls.actualProject;
        if (project === undefined)
            throw new Error('No project selected');
        const name = this.inputShortName?.value || '';
        this.error = '';
        const isValidName = this.getNewNameAndValid(project, name);
        if (!isValidName) {
            this.error = this.msg.invalidName;
            return;
        }
    }
    //--------------- IMPLEMENTS----------------
    clickCancel() {
        if (!this.father)
            return;
        this.father.mode = 'list';
    }
    getNewNameAndValid(prj, name) {
        if (name === '' || !name || name === null)
            return false;
        if (/\s/.test(name))
            return false;
        if (/^\d+$/.test(name))
            return false;
        if (/^\d/.test(name))
            return false;
        const split = name.split('/');
        return isNameValid(prj, split.pop() || name, split.length > 0 ? split.join('/') : '', +this.level, '.ts');
    }
    showLoad(active) {
        setTimeout(() => {
            if (!this.service)
                return;
            this.service.loading = active;
        }, 500);
    }
    async createFile() {
        try {
            const project = mls.actualProject;
            if (project === undefined)
                throw new Error('No project selected');
            const name = this.inputShortName?.value || '';
            this.error = '';
            const isValidName = this.getNewNameAndValid(project, name);
            if (!isValidName) {
                this.showError(this.msg.invalidName);
                return;
            }
            const info = getPath(`_${project}_${name}`);
            if (!info)
                throw new Error('[createFile] Not found path:' + `_${project}_${name}`);
            this.showLoad(true);
            const srcTs = ` /// <mls shortName="${info.shortName}" project="${info.project}" folder="${info.folder}" enhancement="_blank" groupName="${info.folder}" />`;
            const srcDefs = `/// <mls shortName="${info.shortName}" project="${info.project}" folder="${info.folder}" groupName="${info.folder}" enhancement="_blank" />

    // Do not change – automatically generated code.`;
            const param = {
                shortName: info.shortName,
                project: mls.actualProject || 0,
                folder: info.folder,
                level: 1,
                source: srcTs.trim(),
                status: 'new',
                extension: '.ts'
            };
            const file = await createStorFile(param, true, true);
            if (file && !(file instanceof Error)) {
                this.setHistory(file);
                this.fireEvents('open', file, {});
            }
            this.showLoad(false);
        }
        catch (e) {
            this.showError('[createFile]' + e.message);
            this.showLoad(false);
        }
    }
    setHistory(file) {
        const info = localStorage.getItem('mlsInfoHistoryL' + mls.actualLevel);
        const res = info ? JSON.parse(info) : [];
        let idx = -1;
        res.forEach((i, index) => {
            if (i.project !== file.project || i.shortName !== file.shortName || i.folder !== file.folder)
                return;
            idx = index;
        });
        if (idx >= 0) {
            res.splice(idx, 1);
        }
        res.unshift({ project: file.project, shortName: file.shortName, extension: file.extension, folder: file.folder });
        if (res.length > 10) {
            for (let i = res.length - 1; i >= 0; i--) {
                if (res.length <= 10)
                    break;
                res.splice(i, 1);
            }
        }
        localStorage.setItem('mlsInfoHistoryL' + mls.actualLevel, JSON.stringify(res));
    }
    showError(msg) {
        if (!this.service)
            return;
        this.service.setError(msg);
    }
    async fireEvents(action, file, info, timeout = 0) {
        try {
            const params = {};
            params.action = action;
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = this.position;
            if (info && info.shortName) {
                params.newshortName = info.shortName;
                params.newProject = info.project;
                params.newfolder = file.folder;
            }
            if (['open'].includes(action)) {
                const lv = mls.actualLevel;
                let name = `_${file.project}_${file.shortName}`;
                if (file.folder)
                    name = `_${file.project}_${file.folder}/${file.shortName}`;
                mls.actual[lv].setFullName(name);
                mls.actual[lv][this.position] = file;
            }
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
        }
        catch (err) {
            this.showError('false');
            this.showError(err.message || '[fireEvents]: erro open');
        }
    }
};
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "service", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "father", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "level", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "error", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "position", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceListFilesAdd100554.prototype, "loading", void 0);
__decorate([
    propertyDataSource()
], ServiceListFilesAdd100554.prototype, "shortName", void 0);
__decorate([
    query('#iptShortName')
], ServiceListFilesAdd100554.prototype, "inputShortName", void 0);
ServiceListFilesAdd100554 = __decorate([
    customElement('plugin-explore-list-add-l1-100554')
], ServiceListFilesAdd100554);
export { ServiceListFilesAdd100554 };
