/// <mls fileReference="_100554_/l2/collabStartL6.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
const message_pt = {
  desc: "Descri\xE7\xE3o",
  news: "Novidades",
  inDevelopment: "Em desenvolvimento...",
  details1: "Sobre esse level",
  module1Title: "M\xF3dulo L6 - Owner: Funcionalidades",
  module1List1: "Dashboard de Projetos: Vis\xE3o geral de todos os projetos, seu status e m\xE9tricas relevantes.",
  module1List2: "Dashboard do Uso do Aplicativo: M\xE9tricas de uso do aplicativo, como n\xFAmero de usu\xE1rios ativos, funil de convers\xE3o, etc",
  module1List3: "Dashboard do Custo de Desenvolvimento: Informa\xE7\xF5es financeiras relacionadas ao custo de desenvolvimento do projeto.",
  module1List4: "Dashboard do Custo de Hospedagem: Custos associados \xE0 infraestrutura e hospedagem do aplicativo.",
  module2Title: "Fluxo de Uso",
  module2List1: "O usu\xE1rio acessa o m\xF3dulo L6 e visualiza os dashboards.",
  module2List2: "Utiliza um dos prompts para iniciar um novo projeto ou funcionalidade.",
  module2List3: "Monitora m\xE9tricas e custos atrav\xE9s dos dashboards.",
  module3Title: "Exemplos de Prompts para Iniciar Projetos via IA",
  module3List1: "Sistema de Farm\xE1cia",
  module3List1_1: "Prompt: Preciso de um sistema para controlar o estoque e vendas da minha farm\xE1cia.",
  module3List1_2: "A\xE7\xE3o: A IA inicia a cria\xE7\xE3o de um projeto focado em um sistema de gest\xE3o para farm\xE1cias, incluindo m\xF3dulos como controle de estoque, vendas e integra\xE7\xE3o com fornecedores.",
  module3List2: "Site de Vendas",
  module3List2_1: "Prompt: Preciso de um site para vendas e controle de funil.",
  module3List2_2: "A IA come\xE7a a esbo\xE7ar um projeto de site de e-commerce com funcionalidades de controle de funil de vendas.",
  module3List3: "Aplicativo de Entrega",
  module3List3_1: "Prompt: Quero um aplicativo para gerenciar entregas e rastreamento em tempo real.",
  module3List3_2: "A\xE7\xE3o: A IA prop\xF5e um projeto de aplicativo m\xF3vel focado em log\xEDstica e rastreamento de entregas.",
  module3List4: "Sistema Financeiro.",
  module3List4_1: "Prompt: Necessito de um sistema para gerenciar as finan\xE7as da minha empresa, incluindo contas a pagar e receber.",
  module3List4_2: "A\xE7\xE3o: A IA inicia o desenvolvimento de um projeto que inclui m\xF3dulos para contas a pagar, contas a receber, erelat\xF3rios financeiros."
};
const message_en = {
  desc: "Description",
  news: "News",
  inDevelopment: "In development...",
  details1: "About this level",
  module1Title: "Module L6 - Owner: Features",
  module1List1: "Project Dashboard: Overview of all projects, their status, and relevant metrics.",
  module1List2: "Application Usage Dashboard: Metrics related to app usage, such as the number of active users, conversion funnel, etc.",
  module1List3: "Development Cost Dashboard: Financial information about the project\u2019s development costs.",
  module1List4: "Hosting Cost Dashboard: Costs associated with the application\u2019s infrastructure and hosting.",
  module2Title: "Usage Flow",
  module2List1: "The user accesses the L6 module and views the dashboards.",
  module2List2: "Uses one of the prompts to start a new project or functionality.",
  module2List3: "Monitors metrics and costs through the dashboards.",
  module3Title: "Examples of Prompts to Start Projects via AI",
  module3List1: "Pharmacy System",
  module3List1_1: "Prompt: I need a system to manage the inventory and sales of my pharmacy.",
  module3List1_2: "Action: The AI starts creating a project focused on a pharmacy management system, including modules such as inventory control, sales, and supplier integration.",
  module3List2: "Sales Website",
  module3List2_1: "Prompt: I need a website for sales and funnel control.",
  module3List2_2: "Action: The AI begins drafting an e-commerce website project with sales funnel management features.",
  module3List3: "Delivery Application",
  module3List3_1: "Prompt: I want an app to manage deliveries and real-time tracking.",
  module3List3_2: "Action: The AI proposes a mobile application project focused on logistics and delivery tracking.",
  module3List4: "Financial System",
  module3List4_1: "Prompt: I need a system to manage my company\u2019s finances, including accounts payable and receivable.",
  module3List4_2: "Action: The AI begins developing a project that includes modules for accounts payable, accounts receivable, and financial reporting."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let CollabStartL6100554 = class extends StateLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-start-l6-100554 {
  line-height: 1.15;
  position: relative;
  height: 100%;
  overflow: auto;
  font-family: 'Cambria', serif;
  font-size: var(--font-size-16);
  font-weight: 400;
}
collab-start-l6-100554 details > summary {
  cursor: pointer;
  font-size: var(--font-size-20);
}
collab-start-l6-100554 .collab-codes-banner {
  margin-left: auto;
  margin-right: auto;
  display: block;
  width: 100%;
  max-width: 100%;
  position: relative;
}
collab-start-l6-100554 .collab-codes-banner img {
  width: 100% !important;
  height: auto !important;
}
collab-start-l6-100554 .collab-codes-link {
  display: flex;
  justify-content: center;
  gap: 2rem;
  padding: 2rem;
}
collab-start-l6-100554 .collab-codes-link button {
  cursor: pointer;
  background: none;
  border: none;
  text-decoration: underline;
  color: var(--active-color);
}
collab-start-l6-100554 .collab-codes-content {
  padding: 0 0.5rem;
  margin-left: auto;
  margin-right: auto;
  max-width: 800px;
  justify-content: center;
}
collab-start-l6-100554 .collab-codes-content details {
  margin-bottom: 1rem;
}
collab-start-l6-100554 .collab-codes-content details > div {
  padding-left: 1.5rem;
}
collab-start-l6-100554 .collab-codes-contents {
  justify-content: center;
}
collab-start-l6-100554 .collab-codes-contents details {
  margin-bottom: 1rem;
}
collab-start-l6-100554 .collab-codes-contents details > div {
  padding-left: 1.5rem;
}
collab-start-l6-100554 .separator {
  padding-top: 24px;
  padding-bottom: 10px;
  margin-top: 32px;
  margin-bottom: 14px;
  display: flex;
  justify-content: center;
}
collab-start-l6-100554 .separator > span {
  width: 4px;
  height: 4px;
  background-color: var(--text-primary-color);
  border-radius: 50%;
  display: inline-block;
  margin-right: 20px;
}
collab-start-l6-100554 h1 {
  line-height: 52px;
  font-size: 42px;
  font-weight: 700;
  font-style: normal;
}
collab-start-l6-100554 h2 {
  line-height: 30px;
  font-size: 24px;
  font-weight: 600;
  font-style: normal;
}
collab-start-l6-100554 h1,
collab-start-l6-100554 h2,
collab-start-l6-100554 h3,
collab-start-l6-100554 h4,
collab-start-l6-100554 h5,
collab-start-l6-100554 h6,
collab-start-l6-100554 h7 {
  letter-spacing: -0.011em;
}
collab-start-l6-100554 ol > li,
collab-start-l6-100554 ul > li {
  margin-top: 1em;
}
collab-start-l6-100554 span,
collab-start-l6-100554 p,
collab-start-l6-100554 li {
  line-height: 32px;
  font-size: 20px;
}
collab-start-l6-100554 .collab_marca {
  position: absolute;
  bottom: 10px;
  right: 20px;
  opacity: 0.2;
}
`);
    this.msg = messages["en"];
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
        <section class="collab-codes-start">
            <div class="collab-codes-banner">
                <img id="serviceStartL6ImageBanner" src="./l3/_100529_/images/startl6.avif" height="250" width="800" alt="banner">
            </div>
            <div class="collab-codes-content">
                <details id="serviceStartL6DetailsAbout" open="open">
                    <summary>${this.msg.details1}</summary>
                    <div>
                        <h1>${this.msg.module1Title}</h1>
                        <div>
                            <h2>${this.msg.desc}</h2>
                                <ol>
                                    <li>${this.msg.module1List1}</li>
                                    <li>${this.msg.module1List2}</li>
                                    <li>${this.msg.module1List3}</li>
                                    <li>${this.msg.module1List4}</li>
                                </ol>
                            </span>
                        </div>
                          <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module2Title}</h3>
                                <ol>
                                    <li>${this.msg.module2List1}</li>
                                    <li>${this.msg.module2List2}</li>
                                    <li>${this.msg.module2List3}</li>
                                </ol>
                        </div>
                        </div>
                          <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module3Title}</h3>
                                <ol>
                                    <li>
                                        <span>${this.msg.module3List1}</span>
                                        <ul>
                                            <li>${this.msg.module3List1_1}</li>
                                            <li>${this.msg.module3List1_2}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module3List2}</span>
                                        <ul>
                                            <li>${this.msg.module3List2_1}</li>
                                            <li>${this.msg.module3List2_2}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module3List3}</span>
                                        <ul>
                                            <li>${this.msg.module3List3_1}</li>
                                            <li>${this.msg.module3List3_2}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module3List4}</span>
                                        <ul>
                                            <li>${this.msg.module3List4_1}</li>
                                            <li>${this.msg.module3List4_2}</li>
                                        </ul>
                                    </li>
                                </ol>
                        </div>
                </details>
                <details id="serviceStartL6DetailsNews" open="open">
                    <summary>${this.msg.news}</summary>
                    <div>
                        <span>${this.msg.inDevelopment}</span>
                    </div>
                </details>
            </div>
        </section>
        <img class="collab_marca" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==" height="140" width="140" alt="collab codes">
         `;
  }
};
CollabStartL6100554 = __decorateClass([
  customElement("collab-start-l6-100554")
], CollabStartL6100554);
export {
  CollabStartL6100554
};
