/// <mls fileReference="_100554_/l2/pluginExploreListAddL3.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, property, query } from 'lit/decorators.js';
import { createAllFiles } from '/_100554_/l2/collabLibStor.js';
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
import { isNameValid } from '/_100554_/l2/libCommom.js';
import { executeAgentByFile } from '/_100554_/l2/aiAgentHelper.js';
import { collabImport } from '/_100554_/l2/collabImport.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
/// **collab_i18n_start**
const message_pt = {
    noItens: 'Nenhum item foi encontrado!'
};
const message_en = {
    noItens: 'No items were found!',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginExploreListAddL3 = class PluginExploreListAddL3 extends PluginBaseModule {
    constructor() {
        //--------VARIABLES--------------
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-explore-list-add-l3-100554 {
  display: block;
}
plugin-explore-list-add-l3-100554 .headerNav {
  height: 40px;
  background: var(--bg-primary-color-darker-hover);
  border-bottom: 1px solid var(--bg-primary-color-lighter);
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  box-shadow: 0 1px 3px var(--bg-primary-color-lighter);
}
plugin-explore-list-add-l3-100554 .headerNav h1 {
  font-size: 16px;
  font-weight: 500;
  color: var(--text-primary-color);
  margin: 0;
  pointer-events: none;
}
plugin-explore-list-add-l3-100554 .headerNav .btn-nav {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  border: none;
  background-color: var(--grey-color-darker);
  color: var(--text-primary-color);
  width: 26px;
  height: 26px;
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: background 0.2s;
}
plugin-explore-list-add-l3-100554 .headerNav.left .btn-nav {
  left: 10px;
}
plugin-explore-list-add-l3-100554 .headerNav.right .btn-nav {
  right: 10px;
}
plugin-explore-list-add-l3-100554 .headerNav .btn-nav:hover {
  opacity: 0.5;
}
plugin-explore-list-add-l3-100554 .headerNav .btn-nav svg {
  width: 14px;
  height: 14px;
  fill: #fff;
}
plugin-explore-list-add-l3-100554 .form-container {
  background: var(--bg-primary-color);
  color: var(--text-primary-color);
  padding: 20px 24px;
}
plugin-explore-list-add-l3-100554 .form-group {
  display: flex;
  flex-direction: column;
  margin-bottom: 14px;
}
plugin-explore-list-add-l3-100554 .form-group label {
  font-size: 13px;
  margin-bottom: 6px;
}
plugin-explore-list-add-l3-100554 .form-group input,
plugin-explore-list-add-l3-100554 .form-group textarea,
plugin-explore-list-add-l3-100554 .form-group select {
  padding: 8px 10px;
  border: 1px solid var(--grey-color);
  border-radius: 6px;
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
plugin-explore-list-add-l3-100554 .form-group input:disabled {
  color: var(--text-primary-color);
}
plugin-explore-list-add-l3-100554 .form-group input:focus,
plugin-explore-list-add-l3-100554 .form-group textarea:focus,
plugin-explore-list-add-l3-100554 .form-group select:focus {
  border-color: #4A90E2;
  box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
}
plugin-explore-list-add-l3-100554 .form-group textarea {
  resize: vertical;
  min-height: 60px;
}
plugin-explore-list-add-l3-100554 .btn-save {
  width: 100%;
  padding: 10px;
  background-color: var(--grey-color-darker);
  color: var(--text-primary-color);
  font-size: 14px;
  font-weight: 500;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.2s;
}
plugin-explore-list-add-l3-100554 .btn-save:hover {
  opacity: 0.5;
}
`);
        this.modules = [];
        this.autoPrepare = false;
    }
    //------COMPONENTS--------------
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        let btn = html `
            <button class="btn-nav" title="add organism" @click="${() => this.goBack()}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg>
            </button>
        `;
        return html `
            ${this.renderHeader('Add', btn, 'left')}
        
            <div class="form-container">

                <div class="form-group">
                    <label for="project">Project</label>
                    <input type="text" disabled .value="${mls.actualProject}"/>
                </div>

                <div class="form-group">
                    <label for="module">Module</label>
                    <select id="iptModule">
                        ${this.modules.map((m) => html `<option value="${m}">${m}</option>`)}
                            
                    </select>
                </div>

                <div class="form-group">
                <label for="organism">Organism</label>
                <input type="text" autocomplete="off" id="iptOrganism" placeholder="organismXxx">
                </div>

                <div class="form-group">
                <label for="prompt">Prompt</label>
                <textarea id="iptPrompt" placeholder="Escreva seu prompt..."></textarea>
                </div>

                <button class="btn-save" @click=${this.createFile}>Execute</button>
            </div>
        `;
    }
    renderHeader(txt, btn, pos) {
        return html `
            <div class="headerNav ${pos}">
                <h1>${txt}</h1>
                ${btn}               
            </div>
        `;
    }
    //------IMPLEMENTS-------------
    async prepare() {
        this.init();
    }
    async init() {
        const key = mls.stor.getKeyToFiles(mls.actualProject, 2, 'project', '', '.ts');
        const file = mls.stor.files[key];
        if (!file)
            return;
        //const m: any | undefined = await getInstanceByFile(file);
        const m = await collabImport({ project: file.project, folder: file.folder, shortName: file.shortName, extension: file.extension });
        if (!m || !m.projectConfig || !m.projectConfig.modules)
            return;
        const md = [];
        m.projectConfig.modules.forEach((i) => md.push(i.name));
        this.modules = md;
        setTimeout(() => {
            const sel = this.querySelector('#iptModule');
            if (sel && mls.actualModule)
                sel.value = mls.actualModule;
        }, 100);
    }
    goBack() {
        if (!this.father)
            return;
        this.father.mode = 'list';
    }
    async createFile() {
        try {
            this.showLoad(true);
            if (!this.iptModule || !this.iptOrganism || !this.iptOrganism.value || !this.iptPrompt || !this.iptPrompt.value || !this.iptModule.value) {
                throw new Error('Enter the name, module and prompt');
            }
            const project = mls.actualProject || 0;
            const folder = this.iptModule.value || '';
            const name = this.iptOrganism.value;
            if (!name.startsWith('organism'))
                throw new Error('The name must start with organism');
            if (!this.getNewNameAndValid(project, name, folder)) {
                throw new Error('Invalid Name');
            }
            const tag = convertFileNameToTag({ folder, project, shortName: name });
            const srcTs = ` /// <mls shortName="${name}" project="${project}" folder="${folder}" enhancement="_100554_enhancementLit" groupName="${folder}" />

    import { html } from 'lit';
    import { customElement } from 'lit/decorators.js';
    import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';

    @customElement('${tag}')
    export class ${name} extends CollabLitElement {
        render(){
            return html\`<h3>In developed</h3>\`
        }

    }
            `;
            const srcDefs = `/// <mls shortName="${name}" project="${project}" folder="${folder}" groupName="${folder}" enhancement="_blank" />

    // Do not change – automatically generated code.

    export const defs: mls.l4.BaseDefs = {
    "meta": {
        "projectId": ${project},
        "folder": "${folder}",
        "shortName": "${name}",
        "type": "organism",
        "devFidelity": "scaffold",
        "group": "${folder}",
        "tags": [
        "lit",
        "organism"
        ]
    },
    "references": {
        "widgets": [],
        "plugins": [],
        "statesRO": [],
        "statesRW": [],
        "statesWO": [],
        "imports": []
    },
    "planning": {
        "generalDescription": "",
        "goal": "",
        "userStories": [],
        "userRequestsEnhancements": [],
        "constraints": []
    }
}
`;
            const param = {
                shortName: this.iptOrganism.value,
                project: mls.actualProject || 0,
                folder: this.iptModule.value,
                enhancement: '_blank',
                level: 2,
                defsSource: srcDefs.trim(),
                tsSource: srcTs.trim(),
            };
            const files = await createAllFiles(param, true, true);
            if (files.ts && !(files.ts instanceof Error)) {
                this.setHistory(files.ts);
                const prompt = JSON.stringify({
                    project: project.toString(),
                    shortName: name,
                    folder,
                    userPrompt: this.iptPrompt.value
                });
                await executeAgentByFile('agentCreateNewPrototypeOrganism', prompt, files.ts, true);
            }
            this.showLoad(false);
            this.goBack();
        }
        catch (e) {
            this.showError('[createFile]' + e.message);
            this.showLoad(false);
        }
    }
    async fireImprove(file, prompt) {
    }
    setHistory(file) {
        const info = localStorage.getItem('mlsInfoHistoryL' + mls.actualLevel);
        const res = info ? JSON.parse(info) : [];
        let idx = -1;
        res.forEach((i, index) => {
            if (i.project !== file.project || i.shortName !== file.shortName || i.folder !== file.folder)
                return;
            idx = index;
        });
        if (idx >= 0) {
            res.splice(idx, 1);
        }
        res.unshift({ project: file.project, shortName: file.shortName, extension: file.extension, folder: file.folder });
        if (res.length > 10) {
            for (let i = res.length - 1; i >= 0; i--) {
                if (res.length <= 10)
                    break;
                res.splice(i, 1);
            }
        }
        localStorage.setItem('mlsInfoHistoryL' + mls.actualLevel, JSON.stringify(res));
    }
    getNewNameAndValid(prj, name, folder) {
        if (name === '' || !name || name === null)
            return false;
        return isNameValid(prj, name, folder, 2, '.ts');
    }
    hasInvalidCharacter(name) {
        const invalidCharacters = /[_\{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        if (invalidCharacters.test(name) || name.indexOf("\\") >= 0)
            return true;
        return false;
    }
    isValidNewName(obj) {
        if (obj.shortName === '')
            return false;
        if (obj.shortName.length === 0 || obj.shortName.length > 255)
            return false;
        const invalidCharacters = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        if (invalidCharacters.test(obj.shortName))
            return false;
        const key = mls.stor.getKeyToFiles(obj.project, obj.level, obj.shortName, obj.folder, obj.extension);
        let find = false;
        const keys = Object.keys(mls.stor.files);
        for (const k of keys) {
            if (key.toLocaleLowerCase() === k.toLocaleLowerCase())
                find = true;
        }
        return !mls.stor.files[key] && !find;
    }
    showLoad(active) {
        setTimeout(() => {
            if (!this.service)
                return;
            this.service.loading = active;
        }, 500);
    }
    showError(msg) {
        if (!this.service)
            return;
        this.service.setError(msg);
    }
};
__decorate([
    state()
], PluginExploreListAddL3.prototype, "modules", void 0);
__decorate([
    property()
], PluginExploreListAddL3.prototype, "father", void 0);
__decorate([
    property()
], PluginExploreListAddL3.prototype, "service", void 0);
__decorate([
    property({ type: Boolean })
], PluginExploreListAddL3.prototype, "autoPrepare", void 0);
__decorate([
    query('#iptModule')
], PluginExploreListAddL3.prototype, "iptModule", void 0);
__decorate([
    query('#iptOrganism')
], PluginExploreListAddL3.prototype, "iptOrganism", void 0);
__decorate([
    query('#iptPrompt')
], PluginExploreListAddL3.prototype, "iptPrompt", void 0);
PluginExploreListAddL3 = __decorate([
    customElement('plugin-explore-list-add-l3-100554')
], PluginExploreListAddL3);
export { PluginExploreListAddL3 };
