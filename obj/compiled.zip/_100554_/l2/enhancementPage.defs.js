const asis = {
  "meta": {
    "fileReference": "_100554_/l2/enhancementPage.ts",
    "componentType": "tool",
    "componentScope": "editor",
    "group": "enhancement"
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Use this enhancement for pages",
      "businessCapabilities": [],
      "technicalCapabilities": [],
      "implementedFeatures": [
        "getExample",
        "getDesignDetails",
        "prepareAdd",
        "onAfterChange",
        "getPromptDefault",
        "onAfterCompile"
      ]
    }
  }
};
export {
  asis
};
