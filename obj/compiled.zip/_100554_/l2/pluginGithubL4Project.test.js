/// <mls fileReference="_100554_/l2/pluginGithubL4Project.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
