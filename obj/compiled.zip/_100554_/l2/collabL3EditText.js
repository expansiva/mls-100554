/// <mls fileReference="_100554_/l2/collabL3EditText.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { initState } from '/_102029_/l2/collabState.js';
import { createModel } from '/_102027_/l2/libModel.js';
import { getPath } from '/_102027_/l2/utils.js';
import '/_100554_/l2/collabL3PreviewText.js';
import '/_100554_/l2/collabL3PreviewTextAttr.js';
import '/_100554_/l2/collabL3PreviewTextI18n.js';
let CollabL3EditText = class CollabL3EditText extends CollabLitElement {
    constructor() {
        super();
        this.dev = false;
        this.target = null;
        this.baseTexti18n = '';
        this.baseSearch = 'id';
    }
    //-------COMPONENT-----------
    firstUpdated() {
        setTimeout(() => {
            if (!this.target)
                this.target = this.closest('body');
            this.getBaseI18n();
            this.json = this.process(this.target);
            this.initState(this.json);
            this.addEls(this.json);
            console.log(this.json);
        }, 200);
    }
    render() {
        if (this.dev)
            return html `<button @click="${this.save}">Save</button>`;
        return html ``;
    }
    //--------IMPLEMENTS---------
    getBaseI18n() {
        const info = getPath(mls.actual[mls.actualLevel].getFullName());
        if (!info)
            return;
        const storKey = mls.stor.getKeyToFile({ ...info, extension: '.ts', level: 2 });
        const stor = mls.stor.files[storKey];
        if (!stor)
            return;
        const models = top?.mls.editor.getModels(stor.project, stor.shortName, stor.folder, stor.level);
        if (!models || !models.ts)
            return;
        const allTxt = models.ts.model.getValue();
        const idxStart = allTxt.indexOf('/// **collab_i18n_start**');
        if (idxStart < 0)
            return;
        let txt = allTxt.substring(idxStart, allTxt.length);
        const idxEnd = txt.indexOf('/// **collab_i18n_end**');
        txt = txt.substring(0, idxEnd);
        this.baseTexti18n = txt;
    }
    process(root) {
        const inner = {};
        const attr = {};
        const i18n = {};
        const isWrapper = (el) => el?.tagName?.toLowerCase() === 'collab-l3-preview-text' ||
            el?.tagName?.toLowerCase() === 'collab-l3-preview-text-attr';
        const traverse = (node) => {
            if (isWrapper(node))
                return;
            const elOri = node.closest('*[' + this.baseSearch + ']');
            const ori = elOri ? elOri.getAttribute(this.baseSearch) : '';
            if (!elOri) {
                Array.from(node.children).forEach((child) => {
                    if (child instanceof HTMLElement) {
                        traverse(child);
                    }
                });
            }
            // Nó de texto simples ou dinâmico
            node.childNodes.forEach((childNode, index) => {
                const vl = node.textContent?.trim() || '';
                if (childNode.nodeType !== Node.TEXT_NODE || !vl)
                    return;
                const textContent = childNode.textContent || '';
                if (!textContent.trim())
                    return;
                const prev = childNode.previousSibling;
                const isLitDynamic = prev && prev.nodeType === Node.COMMENT_NODE && prev.nodeValue?.startsWith('?lit$');
                if (isLitDynamic) {
                    let searchPos = 0;
                    let idx = -1;
                    let varName = 'unknown';
                    let keyName = 'unknown_key';
                    while (true) {
                        idx = this.baseTexti18n.indexOf(textContent, searchPos);
                        if (idx === -1)
                            break;
                        // Confirma se está entre aspas corretamente
                        const charBefore = this.baseTexti18n[idx - 1];
                        const charAfter = this.baseTexti18n[idx + textContent.length];
                        const validQuotes = [`'`, `"`];
                        if (validQuotes.includes(charBefore) && validQuotes.includes(charAfter) && charBefore === charAfter) {
                            // Encontrar '{' anterior
                            const braceStart = this.baseTexti18n.lastIndexOf('{', idx);
                            // Encontrar '=' anterior ao '{'
                            const equalIndex = this.baseTexti18n.lastIndexOf('=', braceStart);
                            const varDecl = this.baseTexti18n.substring(0, equalIndex).trim();
                            const varNameMatch = /([a-zA-Z0-9_]+)\s*$/.exec(varDecl);
                            varName = varNameMatch ? varNameMatch[1] : 'unknown';
                            // Extrair chave do objeto antes do texto
                            const objSection = this.baseTexti18n.substring(braceStart, idx);
                            const keyMatch = objSection.match(/([a-zA-Z0-9_]+)\s*:\s*['"`][^'"`]*$/);
                            if (keyMatch) {
                                keyName = keyMatch[1];
                                break; // Achou ocorrência correta e chave válida
                            }
                        }
                        // Continua procurando
                        searchPos = idx + textContent.length;
                    }
                    if (idx !== -1) {
                        const i18nKey = `${varName}_${keyName}`;
                        if (!i18n[i18nKey]) {
                            i18n[i18nKey] = { key: keyName, old_v: textContent, new_v: textContent, textNode: [childNode] };
                        }
                        else {
                            i18n[i18nKey].textNode.push(childNode);
                        }
                    }
                }
                else if (elOri && elOri.childNodes && elOri.childNodes[0].nodeType !== Node.COMMENT_NODE) {
                    // Texto simples (não dinâmico)
                    const tag = node.tagName.toLowerCase();
                    const key = tag + '_' + ori + '_' + index;
                    if (!inner[key]) {
                        inner[key] = { old_v: textContent, ori: `${this.baseSearch}="${ori}"`, new_v: textContent, textNode: childNode, tag };
                    }
                }
            });
            // Atributos visíveis no DOM renderizado
            for (const attrName of node.getAttributeNames()) {
                if (['innertext', 'innerhtml', 'style', 'id', 'class', 'clb_id', this.baseSearch].includes(attrName.toLocaleLowerCase()))
                    continue;
                const value = node.getAttribute(attrName);
                if (!value)
                    continue;
                const tag = node.tagName.toLowerCase();
                const key = `${tag.replace(/\-/g, '_')}_${attrName}_${ori}`;
                // Procurar texto visível igual ao valor do atributo
                const matches = [];
                node.querySelectorAll('*').forEach((child) => {
                    child.childNodes.forEach((n) => {
                        if (n.nodeType === Node.TEXT_NODE && n.textContent?.includes(value)) {
                            matches.push(n);
                        }
                    });
                });
                if (matches.length > 0) {
                    matches.forEach((textNode) => {
                        attr[key] = { old_v: value, new_v: value, attr: attrName, ori: `${this.baseSearch}="${ori}"`, textNode: textNode };
                    });
                }
            }
            // Continua percorrendo a árvore
            Array.from(node.children).forEach((child) => {
                if (child instanceof HTMLElement) {
                    traverse(child);
                }
            });
        };
        traverse(root);
        return { i18n, inner, attr };
    }
    initState(json) {
        initState('collabl3edit', json);
    }
    addEls(json) {
        const inners = Object.keys(json.inner);
        inners.forEach((key) => {
            const inner = json.inner[key];
            const wrapper = document.createElement('collab-l3-preview-text-100554');
            let el = inner.textNode.parentElement?.closest('[id]');
            let findby = el ? el.id : '';
            wrapper.setAttribute('value', `{{ collabl3edit.inner.${key}.new_v }}`);
            wrapper.setAttribute('contenteditable', 'true');
            wrapper.setAttribute('findby', findby);
            wrapper.info = inner;
            // Substitui apenas o TextNode original
            inner.textNode.parentNode?.replaceChild(wrapper, inner.textNode);
        });
        const attrs = Object.keys(json.attr);
        attrs.forEach((key) => {
            const attr = json.attr[key];
            const wrapper = document.createElement('collab-l3-preview-text-attr-100554');
            let el = attr.textNode.parentElement?.closest('[id]');
            let findby = el ? el.id : '';
            wrapper.setAttribute('value', `{{ collabl3edit.attr.${key}.new_v }}`);
            wrapper.setAttribute('attr', attr.attr);
            wrapper.setAttribute('findby', findby);
            wrapper.info = attr;
            attr.textNode.parentNode?.replaceChild(wrapper, attr.textNode);
        });
        const i18ns = Object.keys(json.i18n);
        i18ns.forEach((key) => {
            const i18n = json.i18n[key];
            i18n.textNode.forEach((t) => {
                let el = t.parentElement?.closest('[id]');
                let findby = el ? el.id : '';
                const wrapper = document.createElement('collab-l3-preview-text-i18n-100554');
                wrapper.setAttribute('value', `{{ collabl3edit.i18n.${key}.new_v }}`);
                wrapper.setAttribute('findby', findby);
                wrapper.info = i18n;
                t.parentNode?.replaceChild(wrapper, t);
            });
        });
    }
    async save() {
        try {
            if (!this.json)
                return;
            const { project, path } = mls.actual[mls.actualLevel];
            const info = getPath(`_${project}_${path}`);
            if (!info)
                return;
            let models = mls.editor.getModels(info.project, info.shortName, info.folder);
            if (!models || !models.ts) {
                const keySF = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, '.ts');
                const st = mls.stor.files[keySF];
                if (!st)
                    throw new Error(`[CollabL3EditText save]Not found stor: _${project}_${path}`);
                await createModel(st, true, false);
                models = mls.editor.getModels(info.project, info.shortName, info.folder);
            }
            if (!models || !models.ts)
                throw new Error(`[CollabL3EditText save]Not found model ts: _${project}_${path}`);
            let edits = [];
            const inners = Object.keys(this.json.inner);
            for await (const key of inners) {
                const inner = this.json?.inner[key];
                if (!inner || (inner && inner.old_v === inner.new_v))
                    continue;
                const edt = await this.replaceValueAfterKeyWithUndo(models.ts.model, inner.ori, inner.old_v, inner.new_v);
                edits = [...edits, ...edt];
            }
            const attrs = Object.keys(this.json.attr);
            for await (const key of attrs) {
                const attr = this.json?.attr[key];
                if (!attr || (attr && attr.old_v === attr.new_v))
                    continue;
                const edt = await this.replaceAttributeValueWithUndo(models.ts.model, attr.ori, attr.old_v, attr.new_v);
                edits = [...edits, ...edt];
            }
            const i18ns = Object.keys(this.json.i18n);
            for await (const key of i18ns) {
                const i18n = this.json?.i18n[key];
                if (!i18n || (i18n && i18n.old_v === i18n.new_v))
                    continue;
                const edt = await this.replaceI18nValueWithUndo(models.ts.model, i18n.key, i18n.old_v, i18n.new_v);
                edits = [...edits, ...edt];
            }
            if (edits.length > 0) {
                models.ts.model.pushEditOperations([], edits, () => null);
                return true;
            }
            else {
                return false;
            }
        }
        catch (e) {
            console.info(e);
        }
    }
    async replaceValueAfterKeyWithUndo(model, key, oldValue, newValue, replaceOnlyFirst = true) {
        const fullText = model.getValue();
        const edits = [];
        let searchStartIndex = 0;
        let keyIndex = fullText.indexOf(key, searchStartIndex);
        while (keyIndex !== -1) {
            const afterKeyStart = keyIndex + key.length;
            const nextKeyIndex = fullText.indexOf(key, afterKeyStart);
            const afterKeyEnd = nextKeyIndex !== -1 ? nextKeyIndex : fullText.length;
            const afterKeyText = fullText.substring(afterKeyStart, afterKeyEnd);
            if (replaceOnlyFirst) {
                const oldValueIndex = afterKeyText.indexOf(oldValue);
                if (oldValueIndex !== -1) {
                    // Calcula índices absolutos no texto completo
                    const startIndex = afterKeyStart + oldValueIndex;
                    const endIndex = startIndex + oldValue.length;
                    // Converte para posição linha/coluna no Monaco
                    const startPos = model.getPositionAt(startIndex);
                    const endPos = model.getPositionAt(endIndex);
                    // Prepara operação de edição para substituir oldValue por newValue
                    edits.push({
                        range: new monaco.Range(startPos.lineNumber, startPos.column, endPos.lineNumber, endPos.column),
                        text: newValue,
                        forceMoveMarkers: true,
                    });
                }
            }
            else {
                // Substitui todas as ocorrências do oldValue após a key
                let relativeSearchIndex = 0;
                while (true) {
                    const oldValueIndex = afterKeyText.indexOf(oldValue, relativeSearchIndex);
                    if (oldValueIndex === -1)
                        break;
                    const startIndex = afterKeyStart + oldValueIndex;
                    const endIndex = startIndex + oldValue.length;
                    const startPos = model.getPositionAt(startIndex);
                    const endPos = model.getPositionAt(endIndex);
                    edits.push({
                        range: new monaco.Range(startPos.lineNumber, startPos.column, endPos.lineNumber, endPos.column),
                        text: newValue,
                        forceMoveMarkers: true,
                    });
                    relativeSearchIndex = oldValueIndex + oldValue.length;
                }
            }
            searchStartIndex = afterKeyEnd;
            keyIndex = fullText.indexOf(key, searchStartIndex);
        }
        return edits;
    }
    async replaceAttributeValueWithUndo(model, key, oldValue, newValue, replaceOnlyFirst = true) {
        const fullText = model.getValue();
        const edits = [];
        let searchStartIndex = 0;
        let keyIndex = fullText.indexOf(key, searchStartIndex);
        while (keyIndex !== -1) {
            // Encontrar o caractere '<' antes da key
            const tagStartIndex = fullText.lastIndexOf('<', keyIndex);
            // Encontrar o caractere '>' depois da key
            const tagEndIndex = fullText.indexOf('>', keyIndex);
            if (tagStartIndex !== -1 && tagEndIndex !== -1 && tagEndIndex > tagStartIndex) {
                // Pegamos o conteúdo da tag inteira onde a key está
                const tagContent = fullText.substring(tagStartIndex, tagEndIndex + 1);
                if (replaceOnlyFirst) {
                    // Substitui somente a primeira ocorrência de oldValue dentro da tag
                    const relativeIndex = tagContent.indexOf(oldValue);
                    if (relativeIndex !== -1) {
                        const startIndex = tagStartIndex + relativeIndex;
                        const endIndex = startIndex + oldValue.length;
                        const startPos = model.getPositionAt(startIndex);
                        const endPos = model.getPositionAt(endIndex);
                        edits.push({
                            range: new monaco.Range(startPos.lineNumber, startPos.column, endPos.lineNumber, endPos.column),
                            text: newValue,
                            forceMoveMarkers: true,
                        });
                    }
                }
                else {
                    // Substitui todas as ocorrências de oldValue dentro da tag
                    let offset = 0;
                    while (true) {
                        const relativeIndex = tagContent.indexOf(oldValue, offset);
                        if (relativeIndex === -1)
                            break;
                        const startIndex = tagStartIndex + relativeIndex;
                        const endIndex = startIndex + oldValue.length;
                        const startPos = model.getPositionAt(startIndex);
                        const endPos = model.getPositionAt(endIndex);
                        edits.push({
                            range: new monaco.Range(startPos.lineNumber, startPos.column, endPos.lineNumber, endPos.column),
                            text: newValue,
                            forceMoveMarkers: true,
                        });
                        offset = relativeIndex + oldValue.length;
                    }
                }
                // Move o ponteiro de busca para depois do final da tag
                searchStartIndex = tagEndIndex + 1;
            }
            else {
                // Se não encontrou delimitadores de tag válidos, avança o ponteiro
                searchStartIndex = keyIndex + key.length;
            }
            keyIndex = fullText.indexOf(key, searchStartIndex);
        }
        return edits;
    }
    async replaceI18nValueWithUndo(model, key, oldValue, newValue, replaceOnlyFirst = true) {
        const fullText = model.getValue();
        const edits = [];
        const startMarker = '/// **collab_i18n_start**';
        const endMarker = '/// **collab_i18n_end**';
        let searchIndex = 0;
        while (true) {
            const blockStart = fullText.indexOf(startMarker, searchIndex);
            if (blockStart === -1)
                break;
            const blockEnd = fullText.indexOf(endMarker, blockStart);
            if (blockEnd === -1)
                break;
            const blockContent = fullText.substring(blockStart, blockEnd + endMarker.length);
            let offset = 0;
            while (true) {
                const oldIdx = blockContent.indexOf(oldValue, offset);
                if (oldIdx === -1)
                    break;
                // Verifica se antes do oldValue há a chave correta
                const beforeValue = blockContent.substring(0, oldIdx);
                const keyPattern = new RegExp(`${key}\\s*:\\s*['"\`]?$`, 'm');
                if (keyPattern.test(beforeValue)) {
                    const startIndex = blockStart + oldIdx;
                    const endIndex = startIndex + oldValue.length;
                    const startPos = model.getPositionAt(startIndex);
                    const endPos = model.getPositionAt(endIndex);
                    edits.push({
                        range: new monaco.Range(startPos.lineNumber, startPos.column, endPos.lineNumber, endPos.column),
                        text: newValue,
                        forceMoveMarkers: true,
                    });
                    if (replaceOnlyFirst)
                        break;
                }
                offset = oldIdx + oldValue.length;
            }
            if (replaceOnlyFirst && edits.length > 0)
                break;
            searchIndex = blockEnd + endMarker.length;
        }
        return edits;
    }
};
__decorate([
    property({ type: Boolean })
], CollabL3EditText.prototype, "dev", void 0);
__decorate([
    property({ type: Object })
], CollabL3EditText.prototype, "target", void 0);
CollabL3EditText = __decorate([
    customElement('collab-l3-edit-text-100554')
], CollabL3EditText);
export { CollabL3EditText };
