/// <mls fileReference="_100554_/l2/collabTasks.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_spinner_clock } from '/_100554_/l2/collabIcons.js';
let CollabTasks100554 = class CollabTasks100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.view = 'list';
        this.selectedTask = null;
    }
    _backToList() {
        this.view = 'list';
        this.selectedTask = null;
    }
    render() {
        if (this.view === 'list') {
            return this._renderTaskList();
        }
        else {
            return this._renderTaskDetails();
        }
    }
    _renderTaskDetails() {
        return html `
      <div class="task-details">
        <button class="back-btn" @click=${this._backToList}>← Voltar</button>
        <h2>${this.selectedTask?.title}</h2>
        <p>In development</p>
      </div>
    `;
    }
    _renderTaskList() {
        return html `
      <div class="task-list-container">

        <!-- Stage: Em Progresso -->
        <div class="task-stage">
          <div class="task-stage-header">
            <span class="stage-name">EM PROGRESSO</span>
            <span class="stage-count">(2)</span>
            <span class="stage-add">+ Adicionar Tarefa</span>
          </div>
          <ul class="task-items">
            <li class="task-row">
              <span class="task-check">${collab_spinner_clock}</span>
              <span class="task-title">Bug explorer</span>
              <span class="task-tag bug">bug</span>
            </li>
            <li class="task-row">
              <span class="task-check">${collab_spinner_clock}</span>
              <span class="task-title">collab messages - ajustes</span>
              <span class="task-meta">3/23</span>
            </li>
          </ul>
        </div>

        <!-- Stage: Review -->
        <div class="task-stage">
          <div class="task-stage-header">
            <span class="stage-name">REVIEW</span>
            <span class="stage-count">(4)</span>
            <span class="stage-add">+ Adicionar Tarefa</span>
          </div>
          <ul class="task-items">
            <li class="task-row" @click=${() => this._openTaskDetails({ id: 1, title: 'Bug add new file' })}>
              <span class="task-check">✔</span>
              <span class="task-title">Bug add new file</span>
            </li>
            <li class="task-row">✔ <span class="task-title">Bug action</span></li>
            <li class="task-row">✔ <span class="task-title">agentImprovePrototype</span></li>
          </ul>
        </div>
        
        <!-- Stage: Pendente -->
        <div class="task-stage">
          <div class="task-stage-header">
            <span class="stage-name">PENDENTE</span>
            <span class="stage-count">(5)</span>
            <span class="stage-add">+ Adicionar Tarefa</span>
          </div>
          <ul class="task-items">
            <li class="task-row">⏳ <span class="task-title">criar widgets de galeria imagens</span></li>
            <li class="task-row">⏳ <span class="task-title">Bug Inicialização</span> <span class="task-tag bug">bug</span></li>
            <li class="task-row">⏳ <span class="task-title">Bug rename com folder</span></li>
            <li class="task-row">⏳ <span class="task-title">Bug import entre projetos</span></li>
            <li class="task-row">⏳ <span class="task-title">collabPreviewL4</span></li>
          </ul>
        </div>

      </div>
    `;
    }
    _openTaskDetails(task) {
        this.selectedTask = task;
        console.info('aq');
        this.view = 'details';
    }
};
__decorate([
    state()
], CollabTasks100554.prototype, "view", void 0);
__decorate([
    state()
], CollabTasks100554.prototype, "selectedTask", void 0);
CollabTasks100554 = __decorate([
    customElement('collab-tasks-100554')
], CollabTasks100554);
export { CollabTasks100554 };
