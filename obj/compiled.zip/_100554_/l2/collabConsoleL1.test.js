/// <mls fileReference="_100554_/l2/collabConsoleL1.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
