/// <mls shortName="collabConsoleL1" project="100554" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
