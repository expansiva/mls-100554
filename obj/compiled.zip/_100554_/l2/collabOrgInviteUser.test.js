/// <mls fileReference="_100554_/l2/collabOrgInviteUser.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
