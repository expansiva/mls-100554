/// <mls shortName="icaInteractionButtonBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { IcaLitElementBase } from '/_100554_/l2/icaLitElementBase.js';
export class IcaInteractionButtonBase extends IcaLitElementBase {
    constructor() {
        super(...arguments);
        this.baseName = 'IcaInteractionButtonBase';
    }
    getActionsTags() {
        return [
            { name: "margin" },
            { name: "padding" },
            { name: "menu" },
            { name: "size" },
            { name: "title" },
        ];
    }
}
