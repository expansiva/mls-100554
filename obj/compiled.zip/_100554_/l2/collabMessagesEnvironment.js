/// <mls fileReference="_100554_/l2/collabMessagesEnvironment.ts" enhancement="_blank"/>
import { loadAgent, executeBeforePrompt } from '/_102027_/l2/aiAgentOrchestration.js';
import { getTemporaryContext } from '/_102027_/l2/aiAgentHelper.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
export const collabEnvironment = {
    getAgents,
    getIntegrationsOpenClaw,
    setIntegrationsOpenClaw: (integrations) => setIntegrationsOpenClaw(integrations),
    notifications: {
        getFCMTokenForBackend,
        getNotifySoundUrl,
        sendACK: (id) => sendACK(id),
        sendRequestMissed,
    },
    bots: {
        getArgsToBots,
        getBotContextVarsBeforeMessageSend,
        getBotContextVarsBeforeMessageSend2
    },
    agents: {
        generateSvgAvatar: (threadId, userId, promptToAvatar) => generateSvgAvatar(threadId, userId, promptToAvatar),
        executeAgent: (agent, context) => executeAgent(agent, context),
        loadAgent: (agentName) => loadAgent2(agentName)
    },
    tasks: {
        openTaskDetails: (messageId, taskId, task, message) => openTaskDetails(messageId, taskId, task, message)
    },
    config: {
        getMenuMode: () => 'custom',
        generateSvgAvatarEnabled: () => true
    }
};
async function getAgents() {
    const keys = Object.keys(mls.stor.files);
    const ret = [];
    for await (const k of keys) {
        if (k.indexOf('agent') < 0)
            continue;
        const file = mls.stor.files[k];
        const path = `/_${file.project}_${file.folder ? file.folder + '/' : ''}${file.shortName}`;
        if (file.extension !== '.ts' || !file.shortName.startsWith('agent'))
            continue;
        try {
            const mdl = await import(path);
            if (!mdl.createAgent)
                continue;
            const agent = mdl.createAgent();
            ret.push(agent);
        }
        catch (err) {
            console.info(err);
            continue;
        }
    }
    return ret;
}
async function getIntegrationsOpenClaw() {
    if (mls.l5.actualOrg === undefined)
        return [];
    const actualOrgDetails = getOrgDetails(mls.l5.actualOrg);
    if (!actualOrgDetails || !actualOrgDetails.value)
        return [];
    try {
        const data = JSON.parse(actualOrgDetails.value);
        return data.integrations || [];
    }
    catch (err) {
        throw new Error(err.message);
    }
}
async function setIntegrationsOpenClaw(integrations) {
    if (mls.l5.actualOrg === undefined)
        throw new Error(`Invalid org actual: ${mls.l5.actualOrg}`);
    const actualOrgDetails = getOrgDetails(mls.l5.actualOrg);
    if (!actualOrgDetails)
        throw new Error(`Invalid org details: ${mls.l5.actualOrg}`);
    try {
        let data = {};
        if (actualOrgDetails.value) {
            data = JSON.parse(actualOrgDetails.value);
        }
        data = { ...data, integrations };
        await mls.api.cbeAddOrUpdateOrgValue(actualOrgDetails.sett.name, JSON.stringify(data));
    }
    catch (err) {
        throw new Error(err.message);
    }
}
async function getNotifySoundUrl() {
    return './l3/_100529_/audio/collabNotification.mp3';
}
async function getFCMTokenForBackend() {
    const token = await mls.events.getFCMTokenForBackend();
    return token;
}
async function sendRequestMissed() {
    return await mls.stor.cache.sendRequestMissed();
}
async function sendACK(id) {
    return await mls.stor.cache.sendACK(id);
}
async function getArgsToBots() {
    const data = {};
    return data;
}
async function getBotContextVarsBeforeMessageSend(thread, prompt) {
    return mls.bots.getBotContextVarsBeforeMessageSend(thread, prompt);
}
async function getBotContextVarsBeforeMessageSend2(vars, myArgs) {
    return mls.bots.getBotContextVarsBeforeMessageSend2(vars, myArgs);
}
async function generateSvgAvatar(threadId, userId, promptToAvatar) {
    const agentName = '_100554_/l2/agents/agentGenerateAvatarSvg';
    const agent = await loadAgent(agentName);
    if (!agent)
        throw new Error('Invalid agent');
    const context = getTemporaryContext(threadId, userId, promptToAvatar);
    await executeBeforePrompt(agent, context);
    const svg = extractSvgFromContext(context);
    return svg;
}
async function loadAgent2(agentName) {
    const agent = await loadAgent(agentName);
    if (!agent)
        return null;
    return agent;
}
async function executeAgent(agentToCall, context) {
    const agent = await loadAgent(agentToCall);
    if (!agent)
        throw new Error('Invalid agent' + agentToCall);
    await executeBeforePrompt(agent, context);
}
async function openTaskDetails(messageId, taskId, task, message) {
    await import('/_102025_/l2/collabMessagesTaskInfo.js');
    const el = document.createElement('collab-messages-task-info-102025');
    el.setAttribute('messageId', messageId);
    if (task && task.PK)
        el.setAttribute('taskId', task.PK);
    el['task'] = task;
    el['message'] = message;
    openElementInServiceDetails(el);
    return { openLocal: false, element: undefined };
}
function extractSvgFromContext(context) {
    return context?.task?.iaCompressed?.nextSteps?.[0]?.interaction?.payload?.[0]?.result ?? null;
}
function getOrgDetails(orgIndex) {
    const actualOrgName = Object.keys(mls.stor.orgs)[orgIndex];
    const actualOrgDetails = mls.stor.orgs[actualOrgName];
    return actualOrgDetails;
}
