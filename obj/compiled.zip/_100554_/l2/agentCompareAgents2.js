/// <mls fileReference="_100554_/l2//agentCompareAgents2.ts" enhancement="_100554_/l2/enhancementAgent.ts"/>
import { appendLongTermMemory } from '/_100554_/l2/aiAgentHelper.js';
export function createAgent() {
    return {
        agentName: "agentCompareAgents2",
        agentProject: 100554,
        agentFolder: "",
        agentDescription: "New agent",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1,
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `Test 1`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    await appendLongTermMemory(context, { "afterPromptProxy": step.stepId.toString() });
    console.info(args);
    const info = JSON.parse(args);
    const steps = [];
    info.agentNames.forEach((agName) => {
        const newStep = {
            type: "add-step",
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: 1,
            step: {
                type: 'agent',
                stepId: 0,
                interaction: null,
                status: 'waiting_human_input',
                nextSteps: [],
                agentName: agName,
                prompt: info.promptUser,
                rags: [],
            }
        };
        steps.push(newStep);
    });
    return steps;
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    console.info(step);
    return [];
}
async function processOutput(context, output) {
    // Do something with output
    return [];
}
const system1 = `
<!-- modelType: code-->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

Your instructions here


## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: any;
    }

`;
//#endregion 
