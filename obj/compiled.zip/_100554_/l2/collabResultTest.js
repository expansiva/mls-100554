/// <mls fileReference="_100554_/l2/collabResultTest.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
import { collab_spinner_clock, collab_check, collab_xmark } from "/_100554_/l2/collabIcons.js";
let CollabConsole100554 = class extends StateLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-result-test-100554 {
  color: #000000;
}
collab-result-test-100554 .test-container {
  display: flex;
  align-items: center;
  gap: 10px;
  font-family: Arial, sans-serif;
}
collab-result-test-100554 .test-container i > svg {
  width: 18px;
  height: 16px;
}
collab-result-test-100554 .test-container details > summary {
  cursor: pointer;
  margin-left: 0.2rem;
}
collab-result-test-100554 .test-container details > div {
  margin-top: 0.1rem;
  margin-left: 1.5rem;
}
collab-result-test-100554 .loading {
  font-size: 24px;
  animation: spin 5s linear infinite;
}
collab-result-test-100554 .result {
  font-size: 16px;
}
collab-result-test-100554 .result pre {
  white-space: pre-line;
  margin: 0;
  font-size: 12px;
}
collab-result-test-100554 .result.pass {
  color: var(--success-color);
}
collab-result-test-100554 .result.failed {
  color: var(--error-color);
  fill: var(--error-color);
}
@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
`);
    this.testName = "";
    this.status = "pending";
    this.resultStatus = "pass";
    this.result = "";
    this.timeResult = 0;
    this.timeStart = 0;
    this.timeEnd = 0;
  }
  updated(changedProperties) {
    super.updated(changedProperties);
  }
  renderRunning() {
    this.timeStart = performance.now();
    return html`
                <span class="loading">${collab_spinner_clock}</span>
                <span>${this.testName}</span>
        `;
  }
  renderFinished() {
    this.timeEnd = performance.now();
    this.timeResult = this.timeEnd - this.timeStart;
    return html`
                <details style="width:100%" open class="result">
                    <summary>
                        ${this.testName} 
                        <small style="flex:1; text-align:end;">
                            ${this.timeResult >= 1e3 ? `(${(this.timeResult / 1e3).toFixed(2)}s)` : `(${this.timeResult.toFixed(2)}ms)`}
                        </small>
                        <i class="result ${this.resultStatus}">${this.resultStatus === "pass" ? collab_check : collab_xmark}</i>
                    </summary>
                    <div>
                        <div style="display:flex; align-items:center;">
                            <pre>${this.result}</pre>
                        </div>                    
                    </div>
                </details>
        `;
  }
  render() {
    return html`
            <div class="test-container">
                ${this.status === "running" ? this.renderRunning() : this.renderFinished()}
            </div>
        `;
  }
};
__decorateClass([
  property({ type: String })
], CollabConsole100554.prototype, "testName", 2);
__decorateClass([
  property({ type: String })
], CollabConsole100554.prototype, "status", 2);
__decorateClass([
  property({ type: String })
], CollabConsole100554.prototype, "resultStatus", 2);
__decorateClass([
  property({ type: String })
], CollabConsole100554.prototype, "result", 2);
__decorateClass([
  property()
], CollabConsole100554.prototype, "timeResult", 2);
CollabConsole100554 = __decorateClass([
  customElement("collab-result-test-100554")
], CollabConsole100554);
export {
  CollabConsole100554
};
