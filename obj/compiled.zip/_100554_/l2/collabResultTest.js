/// <mls fileReference="_100554_/l2/collabResultTest.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_spinner_clock, collab_check, collab_xmark } from '/_100554_/l2/collabIcons.js';
let CollabConsole100554 = class CollabConsole100554 extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-result-test-100554 {
  color: #000000;
}
collab-result-test-100554 .test-container {
  display: flex;
  align-items: center;
  gap: 10px;
  font-family: Arial, sans-serif;
}
collab-result-test-100554 .test-container i > svg {
  width: 18px;
  height: 16px;
}
collab-result-test-100554 .test-container details > summary {
  cursor: pointer;
  margin-left: 0.2rem;
}
collab-result-test-100554 .test-container details > div {
  margin-top: 0.1rem;
  margin-left: 1.5rem;
}
collab-result-test-100554 .loading {
  font-size: 24px;
  animation: spin 5s linear infinite;
}
collab-result-test-100554 .result {
  font-size: 16px;
}
collab-result-test-100554 .result pre {
  white-space: pre-line;
  margin: 0;
  font-size: 12px;
}
collab-result-test-100554 .result.pass {
  color: var(--success-color);
}
collab-result-test-100554 .result.failed {
  color: var(--error-color);
  fill: var(--error-color);
}
@keyframes spin {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
`);
    }
    testName = '';
    status = 'pending';
    resultStatus = 'pass';
    result = '';
    timeResult = 0;
    timeStart = 0;
    timeEnd = 0;
    updated(changedProperties) {
        super.updated(changedProperties);
    }
    renderRunning() {
        this.timeStart = performance.now();
        return html `
                <span class="loading">${collab_spinner_clock}</span>
                <span>${this.testName}</span>
        `;
    }
    renderFinished() {
        this.timeEnd = performance.now();
        this.timeResult = this.timeEnd - this.timeStart;
        return html `
                <details style="width:100%" open class="result">
                    <summary>
                        ${this.testName} 
                        <small style="flex:1; text-align:end;">
                            ${this.timeResult >= 1000
            ? `(${(this.timeResult / 1000).toFixed(2)}s)`
            : `(${this.timeResult.toFixed(2)}ms)`}
                        </small>
                        <i class="result ${this.resultStatus}">${this.resultStatus === 'pass' ? collab_check : collab_xmark}</i>
                    </summary>
                    <div>
                        <div style="display:flex; align-items:center;">
                            <pre>${this.result}</pre>
                        </div>                    
                    </div>
                </details>
        `;
    }
    render() {
        return html `
            <div class="test-container">
                ${this.status === 'running'
            ? this.renderRunning()
            : this.renderFinished()}
            </div>
        `;
    }
};
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "testName", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "status", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "resultStatus", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "result", void 0);
__decorate([
    property()
], CollabConsole100554.prototype, "timeResult", void 0);
CollabConsole100554 = __decorate([
    customElement('collab-result-test-100554')
], CollabConsole100554);
export { CollabConsole100554 };
