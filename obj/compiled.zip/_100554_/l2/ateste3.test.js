/// <mls fileReference="_100554_/l2/ateste3.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
