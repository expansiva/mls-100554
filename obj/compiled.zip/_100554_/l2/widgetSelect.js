/// <mls fileReference="_100554_/l2/widgetSelect.ts" enhancement="_blank"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let WcInputText100554 = class WcInputText100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.autocapitalize = "off";
        this.maxlength = undefined;
        this.minlength = undefined;
        this.required = false;
        this.disabled = false;
        this.readonly = false;
        this.autofocus = false;
        this.error = '';
    }
    get _options() {
        if (this.options)
            return JSON.parse(this.options);
        else
            return [];
    }
    render() {
        return html `
        <label class="form-control-label">
          ${this.label}
        </label>

        <select
            class="input_control"
            name=${ifDefined(this.name)}
            ?disabled=${this.disabled}
            ?readonly=${this.readonly}
            ?required=${this.required}
            .value=${this.value || ''}
            ?autofocus=${this.autofocus}
            pattern=${ifDefined(this.pattern)}

        
        >
            ${this._options.map((s) => html `<option value="${s}">${s}</option>`)}
        </select>
        <small class="form_hint">${this.hint}</small>
        <div class="form_error_message">${this.error}</div>
        `;
    }
    handleChange(event) {
        const input = event.target;
        this.value = input.value;
    }
};
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "value", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "name", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "label", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "errormessage", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "placeholder", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "autocomplete", void 0);
__decorate([
    property({ type: Number })
], WcInputText100554.prototype, "maxlength", void 0);
__decorate([
    property({ type: Number })
], WcInputText100554.prototype, "minlength", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "required", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "disabled", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "readonly", void 0);
__decorate([
    property({ type: Boolean })
], WcInputText100554.prototype, "autofocus", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "hint", void 0);
__decorate([
    property({ type: String })
], WcInputText100554.prototype, "options", void 0);
WcInputText100554 = __decorate([
    customElement('widget-select-100554')
], WcInputText100554);
export { WcInputText100554 };
