/// <mls fileReference="_100554_/l2/pluginStyleBackground.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
