/// <mls fileReference="_100554_/l2/pluginNewFilePage.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { convertFileNameToTag } from "/_102027_/l2/utils.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
import { getMessageKey } from "/_100554_/l2/collabLitElement.js";
import { propertyDataSource } from "/_100554_/l2/collabDecorators.js";
import { createNewFile, changeTagName, changeClassName, changeWidget, changeStateName, getTemplateImport } from "/_100554_/l2/pluginNewFileBase.js";
import "/_100554_/l2/widgetTextCode.js";
const message_pt = {
  title: "Criar um arquivo de pagina.",
  description: "Criar um arquivo do tipo pagina. Na pagina sera possivel manipular o globalState e dos eventos da p\xE1gina.",
  project: "Projeto",
  shortName: "Nome",
  header: "Criar uma pagina",
  btnCreate: "Criar arquivo",
  loading: "Criando arquivo...",
  error: "Nome do arquivo em branco ou invalido",
  errorPageName: 'O nome do arquivo deve come\xE7ar com "page"'
};
const message_en = {
  title: "Create a page file.",
  description: "Create a page file. In the page, it will be possible to manipulate the globalState and the page events.",
  project: "Project",
  shortName: "ShortName",
  header: "Create a page",
  btnCreate: "Create file",
  loading: "Creating File...",
  error: "Blank or invalid file name",
  errorPageName: 'File name must start with "page"'
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
const lang = getMessageKey(messages);
let msg = messages[lang];
const details = {
  title: msg.title,
  description: msg.description,
  tags: ["lit", "html", "page"]
};
let PluginNewFilePage = class extends StateLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file-page-100554 {
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
plugin-new-file-page-100554 widget-text-code-100554 {
  font-size: var(--font-size-12);
}
plugin-new-file-page-100554 button {
  background-color: var(--active-color);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: #fff;
  cursor: pointer;
}
plugin-new-file-page-100554 button:hover {
  background-color: var(--active-color-hover);
}
`);
    this.position = "left";
    this.loading = false;
    this.service = this.closest("service-detail-100554");
    this.template = `
import { CollabPageElement } from '${getTemplateImport(100554, "collabPageElement", "")}';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from '${getTemplateImport(100554, "collabState", "")}';

@customElement('[tagName]')
export class [className] extends CollabPageElement {
    initPage() {

    }
}
`;
    this.enhancement = `_100554_enhancementLit`;
    this.groupName = `other`;
  }
  getTemplateTS() {
    let newExample = this.template;
    if (this.shortName && this.project) {
      newExample = changeTagName(newExample, convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder }));
      newExample = changeClassName(newExample, this.project, this.shortName);
      newExample = changeWidget(newExample, this.project, this.shortName);
      newExample = changeStateName(newExample, this.shortName);
    }
    const group = this.groupName && this.groupName != "other" ? ` groupName="${this.groupName}"` : ` groupName="page"`;
    const enhancement = this.enhancement ? this.enhancement : "_blank";
    const folder = this.folder ? `${this.folder}/` : "";
    const name = `_${this.project}_/l2/${folder}${this.shortName}.ts`;
    return `/// <mls fileReference="${name}" enhancement="${enhancement}"${group}/>
${newExample}
`;
  }
  getTemplateHTML() {
    if (!this.shortName || !this.project) return "";
    const tagName = convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder });
    return `<${tagName}></${tagName}>`;
  }
  async handleAddFile() {
    if (!this.project || !this.shortName) {
      this.service.setError(msg.error);
      return;
    }
    ;
    this.loading = true;
    try {
      await createNewFile({
        folder: this.folder,
        project: this.project,
        position: this.position,
        shortName: this.shortName,
        enhancement: this.enhancement,
        sourceTS: this.getTemplateTS(),
        sourceHTML: this.getTemplateHTML(),
        openPreview: true
      });
    } catch (e) {
      this.loading = false;
    }
  }
  render() {
    return html`
            ${this.loading ? html`<div>${msg.loading}</div>` : html`   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>

                    <widget-text-code-100554 language="typescript" text="${this.getTemplateTS()}"></widget-text-code-100554>
                    <widget-text-code-100554 language="html" text="${this.getTemplateHTML()}"></widget-text-code-100554>

                
                </div>`}
        `;
  }
};
__decorateClass([
  propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "shortName", 2);
__decorateClass([
  propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "project", 2);
__decorateClass([
  propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "folder", 2);
__decorateClass([
  property()
], PluginNewFilePage.prototype, "position", 2);
__decorateClass([
  property()
], PluginNewFilePage.prototype, "loading", 2);
PluginNewFilePage = __decorateClass([
  customElement("plugin-new-file-page-100554")
], PluginNewFilePage);
export {
  PluginNewFilePage,
  details
};
