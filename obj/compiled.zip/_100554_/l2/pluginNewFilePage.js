/// <mls shortName="pluginNewFilePage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { convertFileNameToTag } from '/_100554_/l2/utilsLit.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getMessageKey } from "/_100554_/l2/collabLitElement.js";
import { propertyDataSource } from '/_100554_/l2/collabDecorators.js';
import { createNewFile, changeTagName, changeClassName, changeWidget, changeStateName, getTemplateImport } from "/_100554_/l2/pluginNewFileBase.js";
import '/_100554_/l2/widgetTextCode.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Criar um arquivo de pagina.',
    description: "Criar um arquivo do tipo pagina. Na pagina sera possivel manipular o globalState e dos eventos da página.",
    project: "Projeto",
    shortName: "Nome",
    header: "Criar uma pagina",
    btnCreate: 'Criar arquivo',
    loading: 'Criando arquivo...',
    error: 'Nome do arquivo em branco ou invalido',
    errorPageName: 'O nome do arquivo deve começar com "page"',
};
const message_en = {
    title: 'Create a page file.',
    description: "Create a page file. In the page, it will be possible to manipulate the globalState and the page events.",
    project: "Project",
    shortName: "ShortName",
    header: "Create a page",
    btnCreate: 'Create file',
    loading: 'Creating File...',
    error: 'Blank or invalid file name',
    errorPageName: 'File name must start with "page"',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
let msg = messages[lang];
export const details = {
    title: msg.title,
    description: msg.description,
    tags: ["lit", "html", "page"],
};
let PluginNewFilePage = class PluginNewFilePage extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file-page-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-new-file-page-100554 widget-text-code-100554{font-size:var(--font-size-12)}plugin-new-file-page-100554 button{background-color:var(--active-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#fff;cursor:pointer}plugin-new-file-page-100554 button:hover{background-color:var(--active-color-hover)}`);
        this.position = 'left';
        this.loading = false;
        this.service = this.closest('service-detail-100554');
        this.template = `
import { CollabPageElement } from '${getTemplateImport(100554, 'collabPageElement', '')}';
import { customElement } from 'lit/decorators.js';
import { globalState, initState, setState } from '${getTemplateImport(100554, 'collabState', '')}';

@customElement('[tagName]')
export class [className] extends CollabPageElement {
    initPage() {

    }
}
`;
        this.enhancement = `_100554_enhancementLit`;
        this.groupName = `other`;
    }
    getTemplateTS() {
        let newExample = this.template;
        if (this.shortName && this.project) {
            newExample = changeTagName(newExample, convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder }));
            newExample = changeClassName(newExample, this.project, this.shortName);
            newExample = changeWidget(newExample, this.project, this.shortName);
            newExample = changeStateName(newExample, this.shortName);
        }
        const group = this.groupName && this.groupName != 'other' ? ` groupName="${this.groupName}"` : ` groupName="page"`;
        const folder = this.folder ? ` folder="${this.folder}"` : '';
        const enhancement = this.enhancement ? this.enhancement : '_blank';
        return `/// <mls shortName="${this.shortName}" project="${this.project}" enhancement="${enhancement}"${group}${folder} />\n${newExample}\n`;
        ;
    }
    getTemplateHTML() {
        if (!this.shortName || !this.project)
            return '';
        const tagName = convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder });
        return `<${tagName}></${tagName}>`;
    }
    async handleAddFile() {
        if (!this.project || !this.shortName) {
            this.service.setError(msg.error);
            return;
        }
        ;
        this.loading = true;
        try {
            await createNewFile({
                folder: this.folder,
                project: this.project,
                position: this.position,
                shortName: this.shortName,
                enhancement: this.enhancement,
                sourceTS: this.getTemplateTS(),
                sourceHTML: this.getTemplateHTML(),
                openPreview: true
            });
        }
        catch (e) {
            this.loading = false;
        }
    }
    render() {
        return html `
            ${this.loading ?
            html `<div>${msg.loading}</div>`
            :
                html `   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>

                    <widget-text-code-100554 language="typescript" text="${this.getTemplateTS()}"></widget-text-code-100554>
                    <widget-text-code-100554 language="html" text="${this.getTemplateHTML()}"></widget-text-code-100554>

                
                </div>`}
        `;
    }
};
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "shortName", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "project", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFilePage.prototype, "folder", void 0);
__decorate([
    property()
], PluginNewFilePage.prototype, "position", void 0);
__decorate([
    property()
], PluginNewFilePage.prototype, "loading", void 0);
PluginNewFilePage = __decorate([
    customElement('plugin-new-file-page-100554')
], PluginNewFilePage);
export { PluginNewFilePage };
