/// <mls shortName="agentGeneratePrototype" project="100554" enhancement="_100554_enhancementLit" />
import { html } from 'lit';
import { svg_agent } from '/_100554_/l2/aiAgentBase.js';
import { getPromptByHtml } from '/_100554_/l2/aiPrompts.js';
import '/_100554_/l2/widgetQuestionsForClarification.js';
import '/_100554_/l2/agentGeneratePrototypeFeedback.js';
import { getNextPendingStepByAgentName, getNextInProgressStepByAgentName, getAgentStepByAgentName, getNextStepIdAvaliable, notifyTaskChange, updateStepStatus, updateTaskTitle } from "/_100554_/l2/aiAgentHelper.js";
import { startNewInteractionInAiTask, startNewAiTask, executeNextStep, addNewStep, startClarification } from "/_100554_/l2/aiAgentOrchestration.js";
const agentName = "agentGeneratePrototype";
const project = 100554;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent for create a new Module",
        visibility: "public",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async beforeClarification(context, stepId, readOnly) {
            return _beforeClarification(context, stepId, readOnly);
        },
        async afterClarification(context, stepId, clarification) {
            return _afterClarification(context, stepId, clarification);
        },
        async getFeedBack(task) {
            return _getFeedBack(task);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning...";
    if (!context || !context.message)
        throw new Error(`[${agentName}](_beforePrompt) Invalid context`);
    if (!context.task) {
        const inputs = await getPrompts(context.message.content || getPromptMock());
        //const inputs: any = await getPrompts(getPromptMock());
        await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt, { "project": mls.actualProject?.toString() || '0' });
        return;
    }
    const step = getNextPendingStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}](beforePrompt) No pending step found for this agent.`);
    if (!step.prompt)
        throw new Error(`[${agentName}](beforePrompt) No prompt found in step for this agent.`);
    const inputs = await getPrompts(step.prompt);
    await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error(`[${agentName}](afterPrompt) Invalid context`);
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}](afterPrompt) No in progress interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    if (context.task)
        context.task = await updateTaskTitle(context.task, "Waiting for user");
    notifyTaskChange(context);
    await executeNextStep(context);
};
const _getFeedBack = async (task) => {
    if (!task)
        throw new Error(`[${agentName}](getFeedBack) Invalid task`);
    // await import('/_100554_/l2/agentGeneratePrototypeFeedback.js');
    return html `<agent-generate-prototype-feedback-100554 .task=${task}></agent-generate-prototype-feedback-100554>`;
};
const _beforeClarification = async (context, stepId, readOnly) => {
    const projectStart = context.task?.iaCompressed?.longMemory['project'];
    if (mls.actualProject?.toString() !== projectStart) {
        const div = document.createElement('div');
        div.innerHTML = 'This task may only be continued on project: ' + projectStart;
        return div;
    }
    return startClarification(context, stepId, readOnly);
};
const _afterClarification = async (context, stepId, clarification) => {
    // only execute after button 'continue'
    if (!context || !context.message || !context.task)
        throw new Error(`[${agentName}](afterClarification) Invalid context`);
    if (!clarification)
        throw new Error(`[${agentName}](afterClarification) Invalid json after clarification`);
    const newStep = {
        type: 'agent',
        agentName: `${agentName}2`,
        prompt: '...',
        status: 'pending',
        stepId: getNextStepIdAvaliable(context.task),
        interaction: null,
        nextSteps: null,
        rags: null
    };
    // complete this step (payload) and push another step
    await addNewStep(context, stepId, [newStep], "Waiting ...");
};
async function getPrompts(userPrompt) {
    if (!userPrompt)
        throw new Error(`Erro [${agentName}](getPrompts) invalid userPrompt`);
    const dataForReplace = {
        userPrompt
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
function getPromptMock() {
    return "criar site petshop";
}
export function getPayload1(context) {
    if (!context || !context.task)
        throw new Error(`[${agentName}](getPayload1) Invalid context`);
    const agentStep = getAgentStepByAgentName(context.task, agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agentName}](getPayload1) no agent found`);
    // get result
    const resultStep = agentStep.interaction?.payload?.[0];
    if (!resultStep || resultStep.type !== "clarification" || !resultStep.json)
        throw new Error(`[${agentName}] [getPayload] No step clarification found for this agent.`);
    let payload1 = resultStep.json;
    if (typeof payload1 === "string")
        payload1 = JSON.parse(payload1);
    // get userPrompt
    payload1.userPrompt = agentStep?.interaction?.input.find((input) => input.type === 'human')?.content || '';
    return payload1;
}
