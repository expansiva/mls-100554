var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_100554_/l2/servicePreviewL1.ts" enhancement="_100554_/l2/enhancementLit" />
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, query, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { getPath } from '/_102027_/l2/utils.js';
import "/_100554_/l2/servicePreviewL1ListServer.js";
import { getProjectConfig } from '/_102027_/l2/libCommom.js';
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
/// **collab_i18n_start**
const message_pt = {
    noFindModule: 'Nenhum modulo configurado.',
};
const message_en = {
    noFindModule: 'No modules configured',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreviewL1100554 = class ServicePreviewL1100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        //@property() msize: string = '';
        this.error = '';
        this.watch = true;
        this.startServer = false;
        //--------VARIABLES-----------
        this.timeEvent = -1;
        this.actualTheme = 'Default';
        //---------SERVICE------------
        this.details = {
            icon: '&#xf06e',
            state: 'background',
            position: 'right',
            tooltip: 'Preview L1',
            visible: true,
            widget: '_100554_servicePreviewL1',
            level: [1]
        };
        this.menu = {
            title: 'Preview L1',
            main: {},
            tabs: undefined,
            tools: {},
            onClickMain: () => { },
            onClickTabs: () => { },
            onClickTools: this.onClickTools.bind(this),
        };
        //--------IMPLEMENTS---------
    }
    //--------PROPERTS------------ 
    get liveServerView() {
        if (!this.liveViewTag)
            return null;
        return this.querySelector(this.liveViewTag);
    }
    onServiceClick(visible, reinit, el) {
    }
    onClickTools(op) {
    }
    //--------COMPONENT----------
    async connectedCallback() {
        super.connectedCallback();
        const moduleConfig = await getProjectConfig(mls.actualProject);
        if (!moduleConfig || !moduleConfig.masterBackEnd)
            return;
        const info = getPath(moduleConfig.masterBackEnd.serverView);
        if (!info)
            throw new Error('[connectedCallback] Not found path:' + moduleConfig.masterBackEnd.serverView);
        await import(`/${moduleConfig.masterBackEnd.serverView}`);
        if (moduleConfig.masterBackEnd.start) {
            this.startInstance = await import(`/${moduleConfig.masterBackEnd.start}`);
            await this.startInstance.start(mls.actualProject, 'none');
        }
        this.liveViewTag = convertFileNameToTag(info);
    }
    updated(changedProperties) {
        super.updated(changedProperties);
    }
    render() {
        this.style.display = 'block';
        if (!this.liveViewTag)
            return html `<h3>${this.msg.noFindModule}<h3>`;
        const htmlString = `<${this.liveViewTag}></${this.liveViewTag}>`;
        return html `${unsafeHTML(htmlString)}`;
    }
};
__decorate([
    state()
], ServicePreviewL1100554.prototype, "liveViewTag", void 0);
__decorate([
    query('#preview-container-l1')
], ServicePreviewL1100554.prototype, "elContent", void 0);
__decorate([
    property()
], ServicePreviewL1100554.prototype, "error", void 0);
__decorate([
    property()
], ServicePreviewL1100554.prototype, "watch", void 0);
__decorate([
    property()
], ServicePreviewL1100554.prototype, "startServer", void 0);
ServicePreviewL1100554 = __decorate([
    customElement('service-preview-l1-100554')
], ServicePreviewL1100554);
export { ServicePreviewL1100554 };
