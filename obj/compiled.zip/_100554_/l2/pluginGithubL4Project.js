/// <mls fileReference="_100554_/l2/pluginGithubL4Project.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg, repeat, unsafeHTML } from 'lit';
import { query, property, customElement } from 'lit/decorators.js';
import { getMyKeysBranch } from '/_102027_/l2/libCommom.js';
import * as gitIO from '/_100554_/l2/libGithubIo.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
import 'https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.3/Sortable.min.js';
export const pluginData = {
    title: "GitHub Projects",
    getSvg() {
        return svg `
        <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3 .3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5 .3-6.2 2.3zm44.2-1.7c-2.9 .7-4.9 2.6-4.6 4.9 .3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3 .7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3 .3 2.9 2.3 3.9 1.6 1 3.6 .7 4.3-.7 .7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3 .7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3 .7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"/></svg>        
    `;
    }
};
let PluginGithubL4Project = class PluginGithubL4Project extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-github-l4-project-100554 {
  --github-back: #0d1117;
  --github-back2: #101204;
  --github-back3: #22272b;
  --github-back4: #323940;
  --github-back5: #f5f5f5;
  --github-color-primary: #B6C2CF;
  --github-color-secundary: #969494;
  --github-shadow1: #ffffff96;
  --github-shadow2: #8b88881a;
  --github-border1: #393939;
  --github-shadow-hover: #dad5d563;
  --github-color-sucess: #1c8139;
  --github-color-sucess-hover: #22a547;
  background-color: var(--bg-primary-color);
  font-family: var(--font-family-primary);
  display: block;
  height: 100%;
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  position: relative;
  color: var(--text-primary-color-lighter);
  overflow: hidden;
}
plugin-github-l4-project-100554 ::-webkit-scrollbar {
  width: 5px;
}
plugin-github-l4-project-100554 ::-webkit-scrollbar-thumb {
  background-color: #888;
  border-radius: 6px;
}
plugin-github-l4-project-100554 ::-webkit-scrollbar-track {
  background-color: #f1f1f1;
}
plugin-github-l4-project-100554 backbutton {
  width: 20px;
  display: flex;
  transform: rotate(180deg);
  cursor: pointer;
  position: absolute;
  left: 5px;
}
plugin-github-l4-project-100554 .showinfo {
  width: max-content;
  margin: 0 auto;
}
plugin-github-l4-project-100554 .showinfo:hover .infohv {
  display: none;
}
plugin-github-l4-project-100554 .showinfo .infotxt {
  display: none;
}
plugin-github-l4-project-100554 .showinfo:hover .infotxt {
  display: inline;
}
plugin-github-l4-project-100554 contentlistissues {
  display: flex;
  flex-direction: column;
  padding: 0.5rem;
}
plugin-github-l4-project-100554 contentlistitem {
  cursor: pointer;
  display: flex;
  flex-direction: column;
  margin-bottom: 1rem;
  padding: 0.5rem;
  border-radius: 10px;
  border: 1px solid var(--github-border1);
  box-shadow: var(--github-shadow2) 0px 4px 10px -3px;
}
plugin-github-l4-project-100554 contentlistitem:hover {
  box-shadow: var(--github-shadow1) 0px 2px 8px -4px;
}
plugin-github-l4-project-100554 contentlistitem div {
  display: flex;
  justify-content: left;
  align-items: center;
  gap: 0.5rem;
}
plugin-github-l4-project-100554 contentlistitem h3 {
  margin: 0;
}
plugin-github-l4-project-100554 contentlistitem span {
  font-size: 1rem;
  color: var(--text-primary-color-darker);
}
plugin-github-l4-project-100554 contentheader {
  cursor: pointer;
  display: flex;
  flex-direction: column;
  padding: 0.5rem;
  position: relative;
  border-bottom: 1px solid var(--github-border1);
}
plugin-github-l4-project-100554 contentheader div {
  display: flex;
  justify-content: left;
  align-items: center;
  gap: 0.5rem;
}
plugin-github-l4-project-100554 contentheader h3 {
  margin: 0;
  width: 100%;
  text-align: center;
}
plugin-github-l4-project-100554 contentheader span {
  text-align: center;
}
plugin-github-l4-project-100554 contentstatus {
  display: flex;
  height: calc(100vh - 183px);
  padding: 1rem;
  width: calc(100% - 32px);
  overflow-x: auto;
  position: relative;
}
plugin-github-l4-project-100554 contentstatus contentstatusitem {
  display: block;
  flex-shrink: 0;
  align-self: flex-start;
  padding: 0 6px;
  height: 100%;
  white-space: nowrap;
}
plugin-github-l4-project-100554 contentstatus contentstatusitem img {
  width: 30px;
  border-radius: 50%;
}
plugin-github-l4-project-100554 contentstatus contentstatusitem contentstatusitembody {
  display: flex;
  position: relative;
  box-sizing: border-box;
  flex-direction: column;
  justify-content: flex-start;
  gap: 0.5rem;
  padding: 0.5rem;
  width: 280px;
  max-height: 100%;
  padding-bottom: 8px;
  border-radius: 12px;
  background-color: var(--github-back2);
  color: var(--github-color-primary);
  vertical-align: top;
  white-space: normal;
  scroll-margin: 8px;
}
plugin-github-l4-project-100554 contentstatusitembody contentst {
  min-height: 80px;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
plugin-github-l4-project-100554 contentstatusitembody h4 {
  margin: 0px;
  padding-left: 0.4rem;
  color: var(--github-color-primary);
  font-size: 13px;
  display: flex;
  justify-content: space-between;
}
plugin-github-l4-project-100554 itemstatusissues {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  background: var(--github-back3);
  padding: 0.5rem;
  border-radius: 10px;
  cursor: pointer;
}
plugin-github-l4-project-100554 itemstatusissues:hover {
  box-shadow: 0px 0px 3px 0px var(--github-shadow-hover);
}
plugin-github-l4-project-100554 itemstatusissues contentlabel {
  font-size: 10px;
  padding: 0.2rem;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
}
plugin-github-l4-project-100554 contentviewissue {
  background: var(--github-back4);
  display: block;
  width: 80%;
  position: absolute;
  top: 0px;
  padding: 1rem;
  border-radius: 10px;
  z-index: 99;
  transform: translate(10%, 78px);
  height: calc(100vh - 242px);
  overflow-y: auto;
  color: var(--github-color-primary);
}
plugin-github-l4-project-100554 contentviewissue .header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
plugin-github-l4-project-100554 contentviewissue svg {
  fill: var(--github-color-secundary);
}
plugin-github-l4-project-100554 contentviewissue .header button {
  background: transparent;
  border: none;
  cursor: pointer;
}
plugin-github-l4-project-100554 contentviewissue .textcomment {
  width: 80%;
  border-radius: 5px;
  padding: 0.5rem;
  background: var(--github-back3);
  color: var(--github-color-primary);
}
plugin-github-l4-project-100554 contentviewissue .button {
  background: var(--github-color-sucess);
  color: var(--github-color-primary);
  padding: 0.5rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}
plugin-github-l4-project-100554 contentviewissue .button:hover {
  background: var(--github-color-sucess-hover);
}
plugin-github-l4-project-100554 constentviewoptions {
  width: 25%;
  gap: 0.5rem;
  display: flex;
  flex-direction: column;
  padding-top: 1rem;
}
plugin-github-l4-project-100554 constentviewoptions viewoptionitens {
  display: flex;
  flex-direction: column;
}
plugin-github-l4-project-100554 constentviewoptions h5 {
  background: #3b444c;
  padding: 0.3rem;
  border-radius: 5px;
  cursor: pointer;
  margin: 0px;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
plugin-github-l4-project-100554 constentviewoptions h5:hover {
  background: #3b444cde;
}
plugin-github-l4-project-100554 constentviewoptions viewoptionitens {
  background: #282e33;
  padding: 0.2rem;
  max-height: 150px;
  overflow-y: auto;
  gap: 0.3rem;
}
plugin-github-l4-project-100554 contentnewissue {
  display: flex;
  justify-content: center;
  gap: 0.5rem;
  padding-top: 1rem;
  background: var(--github-back4);
  max-width: 750px;
  width: 80%;
  position: absolute;
  top: 0px;
  padding: 1rem;
  border-radius: 10px;
  z-index: 99;
  transform: translate(15%, 78px);
}
plugin-github-l4-project-100554 contentnewissue input {
  width: 100%;
  border-radius: 5px;
  outline: none;
  padding-left: 0.2rem;
  height: 25px;
  border: 1px solid var(--bg-secondary-color-darker);
}
plugin-github-l4-project-100554 contentnewissue textarea {
  width: 100%;
  border-radius: 5px;
  outline: none;
  padding-left: 0.2rem;
  height: 120px;
  border: 1px solid var(--bg-secondary-color-darker);
}
plugin-github-l4-project-100554 contentnewissue h4 {
  margin: 0px;
}
plugin-github-l4-project-100554 contentnewissue svg {
  fill: var(--github-color-secundary);
}
plugin-github-l4-project-100554 contentnewissue buttonnewissues {
  background: var(--github-color-sucess);
  color: var(--github-color-primary);
  padding: 0.5rem;
  border: none;
  border-radius: 8px;
  cursor: pointer;
}
plugin-github-l4-project-100554 contentnewissue buttonnewissues:hover {
  background: var(--github-color-sucess-hover);
}
plugin-github-l4-project-100554 .contentloader {
  background: var(--bg-primary-color-darker-disabled);
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0px;
  left: 0px;
  display: flex;
  justify-content: center;
  align-items: center;
}
plugin-github-l4-project-100554 .loader {
  width: 50px;
  height: 28px;
  --_g: no-repeat radial-gradient(farthest-side, var(--text-primary-color) 94%, #0000);
  background: var(--_g) 50% 0, var(--_g) 100% 0;
  background-size: 12px 12px;
  position: relative;
  animation: l23-0 1.5s linear infinite;
}
plugin-github-l4-project-100554 .loader:before {
  content: "";
  position: absolute;
  height: 12px;
  aspect-ratio: 1;
  border-radius: 50%;
  background: var(--text-primary-color);
  left: 0;
  top: 0;
  animation: l23-1 1.5s linear infinite, l23-2 0.5s cubic-bezier(0, 200, 0.8, 200) infinite;
}
@keyframes l23-0 {
  0%,
  31% {
    background-position: 50% 0, 100% 0;
  }
  33% {
    background-position: 50% 100%, 100% 0;
  }
  43%,
  64% {
    background-position: 50% 0, 100% 0;
  }
  66% {
    background-position: 50% 0, 100% 100%;
  }
  79% {
    background-position: 50% 0, 100% 0;
  }
  100% {
    transform: translateX(calc(-100%/3));
  }
}
@keyframes l23-1 {
  100% {
    left: calc(100% + 7px);
  }
}
@keyframes l23-2 {
  100% {
    top: -0.1px;
  }
}
`);
        this.repositoryId = '';
        this.myLabels = [];
        this.myUsers = [];
        this.myProjcts = [];
        this.sort = [];
        this.error = '';
        this.scenary = 'list';
        this.isLoader = true;
        this.autoClick = 'false';
        //-----ICONS------
        this.myIcons = {
            plus: `<svg style="width:13px;fill:var(--github-color-primary)" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg>`,
            git: `<svg style="width:20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3 .3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5 .3-6.2 2.3zm44.2-1.7c-2.9 .7-4.9 2.6-4.6 4.9 .3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3 .7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3 .3 2.9 2.3 3.9 1.6 1 3.6 .7 4.3-.7 .7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3 .7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3 .7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"/></svg>`,
            bars: `<svg style="width:20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M448 64c0-17.7-14.3-32-32-32L32 32C14.3 32 0 46.3 0 64S14.3 96 32 96l384 0c17.7 0 32-14.3 32-32zm0 256c0-17.7-14.3-32-32-32L32 288c-17.7 0-32 14.3-32 32s14.3 32 32 32l384 0c17.7 0 32-14.3 32-32zM0 192c0 17.7 14.3 32 32 32l384 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L32 160c-17.7 0-32 14.3-32 32zM448 448c0-17.7-14.3-32-32-32L32 416c-17.7 0-32 14.3-32 32s14.3 32 32 32l384 0c17.7 0 32-14.3 32-32z"/></svg>`,
            list: `<svg style="width:20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M40 48C26.7 48 16 58.7 16 72l0 48c0 13.3 10.7 24 24 24l48 0c13.3 0 24-10.7 24-24l0-48c0-13.3-10.7-24-24-24L40 48zM192 64c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L192 64zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zM16 232l0 48c0 13.3 10.7 24 24 24l48 0c13.3 0 24-10.7 24-24l0-48c0-13.3-10.7-24-24-24l-48 0c-13.3 0-24 10.7-24 24zM40 368c-13.3 0-24 10.7-24 24l0 48c0 13.3 10.7 24 24 24l48 0c13.3 0 24-10.7 24-24l0-48c0-13.3-10.7-24-24-24l-48 0z"/></svg>`,
            close: `<svg style="width: 18px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M342.6 150.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 210.7 86.6 105.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L146.7 256 41.4 361.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L192 301.3 297.4 406.6c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L237.3 256 342.6 150.6z"/></svg>`,
            table: `<svg style="width:15px;fill:var(--github-color-primary)" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M64 256l0-96 160 0 0 96L64 256zm0 64l160 0 0 96L64 416l0-96zm224 96l0-96 160 0 0 96-160 0zM448 256l-160 0 0-96 160 0 0 96zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32z"/></svg>`,
            card: `<svg style="width:15px;fill:var(--github-color-primary)" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M64 32C28.7 32 0 60.7 0 96l0 32 576 0 0-32c0-35.3-28.7-64-64-64L64 32zM576 224L0 224 0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-192zM112 352l64 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-64 0c-8.8 0-16-7.2-16-16s7.2-16 16-16zm112 16c0-8.8 7.2-16 16-16l128 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-128 0c-8.8 0-16-7.2-16-16z"/></svg>`,
            back2: `<svg style="width:15px;fill:var(--github-color-primary)" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M352 96l64 0c17.7 0 32 14.3 32 32l0 256c0 17.7-14.3 32-32 32l-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l64 0c53 0 96-43 96-96l0-256c0-53-43-96-96-96l-64 0c-17.7 0-32 14.3-32 32s14.3 32 32 32zm-9.4 182.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3L242.7 224 32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l210.7 0-73.4 73.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0l128-128z"/></svg>`,
            back: `<svg xmlns="http://www.w3.org/2000/svg" style="width:15px;" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg>`,
            member: `<svg xmlns="http://www.w3.org/2000/svg" style="width:12px;" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0z"/></svg>`,
            label: `<svg xmlns="http://www.w3.org/2000/svg" style="width:12px;" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M0 80L0 229.5c0 17 6.7 33.3 18.7 45.3l176 176c25 25 65.5 25 90.5 0L418.7 317.3c25-25 25-65.5 0-90.5l-176-176c-12-12-28.3-18.7-45.3-18.7L48 32C21.5 32 0 53.5 0 80zm112 32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>`,
            trash: `<svg xmlns="http://www.w3.org/2000/svg" style="width:12px;" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M135.2 17.7C140.6 6.8 151.7 0 163.8 0L284.2 0c12.1 0 23.2 6.8 28.6 17.7L320 32l96 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 96C14.3 96 0 81.7 0 64S14.3 32 32 32l96 0 7.2-14.3zM32 128l384 0 0 320c0 35.3-28.7 64-64 64L96 512c-35.3 0-64-28.7-64-64l0-320zm96 64c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16zm96 0c-8.8 0-16 7.2-16 16l0 224c0 8.8 7.2 16 16 16s16-7.2 16-16l0-224c0-8.8-7.2-16-16-16z"/></svg>`,
            eye: `<svg xmlns="http://www.w3.org/2000/svg" style="width:12px;fill:var(--github-color-primary)" viewBox="0 0 576 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M288 32c-80.8 0-145.5 36.8-192.6 80.6C48.6 156 17.3 208 2.5 243.7c-3.3 7.9-3.3 16.7 0 24.6C17.3 304 48.6 356 95.4 399.4C142.5 443.2 207.2 480 288 480s145.5-36.8 192.6-80.6c46.8-43.5 78.1-95.4 93-131.1c3.3-7.9 3.3-16.7 0-24.6c-14.9-35.7-46.2-87.7-93-131.1C433.5 68.8 368.8 32 288 32zM144 256a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm144-64c0 35.3-28.7 64-64 64c-7.1 0-13.9-1.2-20.3-3.3c-5.5-1.8-11.9 1.6-11.7 7.4c.3 6.9 1.3 13.8 3.2 20.7c13.7 51.2 66.4 81.6 117.6 67.9s81.6-66.4 67.9-117.6c-11.1-41.5-47.8-69.4-88.6-71.1c-5.8-.2-9.2 6.1-7.4 11.7c2.1 6.4 3.3 13.2 3.3 20.3z"/></svg>`
        };
    }
    async prepare() {
        this.setInfos();
    }
    //----------COMPONENT--------------------
    firstUpdated() {
        this.setInfos();
    }
    createRenderRoot() {
        return this;
    }
    render() {
        if (this.error != '')
            return this.renderError();
        if (this.isLoader)
            return this.renderLoader();
        if (this.scenary === 'list')
            return this.renderList();
        if (this.scenary === 'showStatus')
            return this.renderShow();
        if (this.scenary === 'listAddIssues')
            return this.renderListIssues();
        return html ``;
    }
    renderLoader() {
        return html `<div class="contentloader">
            <div class="loader"></div>
        </div>`;
    }
    renderError() {
        return html `<h3 style=" padding: 2rem; text-align: center;">${this.error}</h3>`;
    }
    //---LIST
    renderList() {
        if (this.myProjcts.length <= 0)
            return html `<h3>No projects</h3>`;
        return html `
            ${this.renderListFilter()}
            <contentlistissues>
                ${repeat(this.myProjcts, ((key) => key.id), ((k, index) => {
            return this.renderListItem(k, index);
        }))}
            </contentlistissues>
        `;
    }
    renderListFilter() {
        return html `
        <div style="display: flex; justify-content: center; margin-bottom: 2rem; align-items: center; gap: .5rem;">
            <div style="background:#fff;padding:.2rem;margin-bottom:1rem;margin-top:1rem; width:80%; border:1px solid #dfdfdf; border-radius:10px;display:flex;gap:.2rem">
                <input type="text" style="border:none;border-right:1px solid #dfdfdf;outline:none;height:25px; width:calc(100% - 30px)" placeholder="Filter issues ...">
                ${unsafeHTML(this.myIcons.back)}
            </div>
        </div>
        `;
    }
    renderListItem(item, idx) {
        return html `
        <contentlistitem @click="${this.clickItemProject}" .info=${item} filter="${item.title}">
            <div>
                <h3>${item.title}</h3>
            </div>
            <span>
                #${item.number} opened on ${new Date(item.createdAt).toLocaleString()} by ${item.author}
            </span>
        </contentlistitem>
        `;
    }
    //---- HEADER
    renderHeader() {
        if (!this.viewProject)
            return html `Not found project`;
        return html `
        <contentheader>
            <div>
                <backbutton back="list" @click=${this.backButton}>
                    ${unsafeHTML(this.myIcons.back2)}
                </backbutton>
                <h3>
                    <span class="showinfo" style="margin-left:1rem">
                        <span class="infohv">
                            ${this.viewProject.title}
                        </span>
                        <span class="infotxt">
                            #${this.viewProject.number} opened on ${new Date(this.viewProject.createdAt).toLocaleString()} by ${this.viewProject.author}
                        </span>
                    </span>
                </h3>
            </div>
            
            <div style=" position: absolute; right: 7px; bottom: 0px; display: flex; gap: 1rem; transform: translate(0, -37%);">
            
                <viewtype @click="${this.listAllIssues}">
                    ${unsafeHTML(this.myIcons.plus)}
                </viewtype>
                <viewtype style="display:none" show="show" @click="${this.clickChangeView}">
                    ${unsafeHTML(this.myIcons.card)}
                </viewtype>
                <viewtype style="display:none" show="showStatus" @click="${this.clickChangeView}">
                    ${unsafeHTML(this.myIcons.table)}
                </viewtype>
            </div>
        </contentheader>
        `;
    }
    //-- SHOW TAB
    renderShow() {
        if (!this.viewProject)
            return html `Not found project`;
        return html `
            <contentshow>
                ${this.renderHeader()}
                ${this.renderTab()}
                ${this.renderViewIssue()}
                ${this.renderAddIssue()}
            </contentshow>
        `;
    }
    renderTab() {
        if (!this.viewProject)
            return html `Not found project`;
        const item = this.viewProject.fields.find((i) => i.dataType === 'select' && i.name.toLocaleLowerCase() === 'status');
        if (!item || item.options.length <= 0)
            return html `Not found status collumn`;
        const info = this.organizeItens();
        setTimeout(() => { this.setDragAndDrop(true); }, 100);
        this.idFieldStatus = item.id;
        return html `

            <contentstatus>
                <contentstatusitem>
                    <contentstatusitembody>
                        <h4>
                            No Status
                            <span style="cursor:pointer" @click="${() => { this.addIssuesin('null'); }}">${unsafeHTML(this.myIcons.plus)}</span>
                        </h4>
                        <contentst id="stnull" idfield="${item.id}" >
                            ${this.renderTaksTab(info ? info['null'] : [])}
                        </contentst>
                    </contentstatusitembody>
                </contentstatusitem>
                ${repeat(item.options, ((key) => key.id), ((k, index) => {
            return html `
                            <contentstatusitem>
                                <contentstatusitembody>
                                    <h4>
                                        ${k.name}
                                        <span style="cursor:pointer" @click="${() => { this.addIssuesin(k.id); }}">${unsafeHTML(this.myIcons.plus)}</span>
                                    </h4>
                                    <contentst id="st${k.id}" idfield="${item.id}" namefield="${k.name}">
                                        ${this.renderTaksTab(info ? info[k.id] : [])}
                                    </contentst>
                                </contentstatusitembody>
                            </contentstatusitem>
                        `;
        }))}
            </contentstatus>
            
        `;
    }
    renderTaksTab(array) {
        if (!array)
            return html ``;
        return html `
            ${repeat(array, ((key) => key.id), ((p, index) => {
            return this.renderTaskTab(p);
        }))}
        `;
    }
    renderTaskTab(p) {
        return html `
            <itemstatusissues .info=${p} @click=${this.showViewIssue}>
                <div style="display: flex; flex-wrap: wrap; gap: .2rem;">
                    ${repeat(p.issue.labels, ((key) => key.id), ((l, index) => {
            return html `
                                <contentlabel style="background:#${l.color}3b; color:#${l.color}; border: 1px solid #${l.color}">${l.name}</contentlabel>
                                `;
        }))}
                    
                </div>
                <div>
                    ${p.issue.title}
                </div>
                <div style="display: flex; flex-wrap: wrap; gap: .2rem;align-items: center; justify-content: flex-end;">

                    ${repeat(p.issue.assignees, ((key) => key.avatarUrl), ((a, index) => {
            return html `
                                <img src="${a.avatarUrl}" title="${a.login}">
                                `;
        }))}
                    
                </div>
            </itemstatusissues>
        `;
    }
    //----- ISSUE
    renderViewIssue() {
        if (!this.viewIssue || !this.userInfo)
            return html ``;
        return html `
            <contentviewissue class="scroll-custom" >
                <div class="header">
                    <div style=" display: flex; gap: .5rem; align-items: center;font-size: 20px;">
                        <a href="${this.viewIssue.issue.url}" style="display: flex;" target="_blank">
                            ${unsafeHTML(this.myIcons.git)}
                        </a>
                        ${this.viewIssue.issue.title}
                        
                    </div>
                    <button @click="${this.clickCloseIssue}">
                        ${unsafeHTML(this.myIcons.close)}
                    </button>
                </div>
                <div style="display:flex">
                    ${this.renderViewMain()}
                    ${this.renderViewOptions()}
                </div>
            </contentviewissue>
        
        `;
    }
    renderViewMain() {
        if (!this.viewIssue || !this.userInfo)
            return html ``;
        return html `
            <div style="width:75%">
                <div style="display: flex; gap: 1.5rem; align-items: center; margin-top: 1rem; padding-left: 31px;">
                    <div style="display: flex; flex-direction: column; gap: .3rem;height: 65px;">
                        <label style="font-size: 13px;">Members:</label>
                        <div style="display: flex; gap: .5rem; flex-wrap: wrap;">
                            ${repeat(this.viewIssue.issue.assignees, ((key) => key.avatarUrl), ((a, index) => {
            return html `<img style="width: 37px; border-radius: 50%;" src="${a.avatarUrl}" title="${a.login}"/>`;
        }))}
                        </div>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: .3rem;height: 65px;">
                        <label style="font-size: 13px;">Labels:</label>
                        <div style="display: flex; gap: .5rem; flex-wrap: wrap;">
                            ${repeat(this.viewIssue.issue.labels, ((key) => key.id), ((l, index) => {
            return this.renderLabelsInTask(l);
        }))}
                        </div>
                    </div>
                </div>
                <div style="display: flex; margin-top: 1rem; flex-direction: column;">
                    <div style="display: flex; gap: .5rem; font-size: 18px;">
                        ${unsafeHTML(this.myIcons.bars)}
                        Description
                    </div>
                    <div style=" margin-left: 30px; border-radius: 10px; padding: .5rem; margin-top: .5rem;">
                        ${unsafeHTML(this.viewIssue.issue.bodyText)}
                    </div>
                </div>
                <div class="activity" style="display: flex; margin-top: 1rem; flex-direction: column;">
                    <div style="display: flex; gap: .5rem; font-size: 18px;">
                        ${unsafeHTML(this.myIcons.list)}
                        Activity
                    </div>
                    <div style=" border-radius: 10px; margin-top: .5rem;">
                        <div style="display:flex;gap: .5rem; flex-direction: row; align-items: center;">
                            <img style="width: 37px; border-radius: 50%;" src="${this.userInfo.avatarUrl}" title="${this.userInfo.login}">
                            <textarea class="textcomment" placeholder="Write a comment ..."></textarea>
                        </div>
                        <button class="button" @click="${this.clickSaveComment}" style="margin-left: 44px; margin-top: .5rem;">
                            Save
                        </button>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: .5rem; margin-top: 3rem;">
                        ${repeat(this.viewIssue.issue.comments, ((key) => key.id), ((c, index) => {
            return this.renderComentsInTask(c);
        }))}
                    </div>
                </div>
            </div>
        `;
    }
    renderViewOptions() {
        if (!this.viewIssue || !this.userInfo)
            return html ``;
        return html `
            <constentviewoptions>
                <div>
                    <h5 open="labels" @click="${this.openMyChild}">
                        ${unsafeHTML(this.myIcons.label)}
                        Labels
                    </h5>
                    <viewoptionitens child="labels" style="display:none;">
                        ${repeat(this.myLabels, ((key) => key.id), ((l, index) => { return this.renderOptionsLabels(l); }))}
                    </viewoptionitens>
                </div>
                <div>
                    <h5 open="members" @click="${this.openMyChild}">
                        ${unsafeHTML(this.myIcons.member)}
                        Members
                    </h5>
                    <viewoptionitens child="members" style="display:none;">
                        ${repeat(this.myUsers, ((key) => key.login), ((l, index) => { return this.renderOptionsMembers(l); }))}
                    </viewoptionitens>
                </div>
                <div>
                    <h5 @click="${this.removeIssueInProject}">
                        ${unsafeHTML(this.myIcons.trash)}
                        Delete
                    </h5>
                </div>
            </constentviewoptions>
        `;
    }
    renderOptionsLabels(l) {
        const find = this.viewIssue?.issue.labels.find((f) => f.id === l.id);
        if (find)
            return html `
            <label for="${l.id}" style="cursor:pointer;padding:2px; background:#${l.color}3b; color:#${l.color}">
                <input type="checkbox" @change="${this.changeLabel}" checked="true" id="${l.id}" value="${l.id}">
                ${l.name}
            </label>    
        `;
        return html `
            <label for="${l.id}" style="cursor:pointer;padding:2px; background:#${l.color}3b; color:#${l.color}">
                <input type="checkbox" @change="${this.changeLabel}" id="${l.id}" value="${l.id}">
                ${l.name}
            </label>    
        `;
    }
    renderOptionsMembers(l) {
        const find = this.viewIssue?.issue.assignees.find((f) => f.login === l.login);
        if (find)
            return html `
            <label for="${l.login}" style="cursor: pointer;padding: 3px; font-size: 11px; display: flex; align-items: center; gap: .2rem;">
                <input type="checkbox" @change="${this.changeMembers}" checked="true" id="${l.login}" value="${l.login}">
                <img src="${l.avatarUrl}" style="width:20px; border-radius:50%" />
                ${l.login}
            </label>    
        `;
        return html `
            <label for="${l.login}" style="cursor: pointer;padding: 3px; font-size: 11px; display: flex; align-items: center; gap: .2rem;">
                <input type="checkbox" @change="${this.changeMembers}" id="${l.login}" value="${l.login}">
                <img src="${l.avatarUrl}" style="width:20px; border-radius:50%" />
                ${l.login}
            </label>    
        `;
    }
    renderComentsInTask(c) {
        return html `
            <div style="display: flex; flex-direction: column;">
                <div style="display: flex; gap: .5rem; align-items: center; font-size: 15px;">
                    <img style="width: 35px; border-radius: 50%;" src="${c.avatarUrl}" title="${c.author}"/>
                    <label>
                        ${c.author}
                        ${new Date(c.createdAt).toLocaleString()}
                    </label>
                </div>
                <div style="margin-left: 43px; background: #22272b; width: 81%; padding: .2rem; border-radius: 5px;">
                    ${unsafeHTML(c.bodyText)}
                </div>
            </div>`;
    }
    renderLabelsInTask(l) {
        return html `
        <contentlabel style="background:#${l.color}3b; color:#${l.color}; border: 1px solid #${l.color};border-radius: 10px; padding: .2rem; font-size: 12px;">
            ${l.name}
        </contentlabel>`;
    }
    //-----ADD ISSUE
    renderAddIssue() {
        if (!this.addInStatus || !this.userInfo)
            return html ``;
        return html `
            <contentnewissue>

                <backbutton back="list" style="align-items: self-end;" @click=${() => { this.addInStatus = undefined; }}>
                    ${unsafeHTML(this.myIcons.close)}
                </backbutton>

                <div style="width: 80%;">
                    <div style="margin-bottom:1rem">
                        <div style="display: flex;">
                            <h4>Add Title</h4>
                        </div>
                        <input id="inputtitle" type="text" />
                    </div>

                    <div>
                        <h4>Add a description</h4>
                        <textarea id="inputdesc"></textarea>
                    </div>
                    <div style="margin-top: 1rem;">
                        <buttonnewissues @click="${this.addIssue}">Add new issue</buttonnewissues>
                    </div>
                </div>
                
            </contentnewissue>

        `;
    }
    // Add List Issue
    renderListIssues() {
        if (!this.listIssues || this.listIssues.length <= 0) {
            return html ` <h3 style="padding:0rem 4rem">No issues</h3>`;
        }
        return html `
            <div style="padding:1rem">
                <backbutton back="showStatus" @click=${this.backButton}>
                    ${unsafeHTML(this.myIcons.back2)}
                </backbutton>
                <h3 style="text-align: center;margin:0px"> Issues </h3>
            </div>
            <contentlistissues>
                ${repeat(this.listIssues, ((key) => key.id), ((k, index) => {
            return this.renderListItemIssues(k, index);
        }))}
            </contentlistissues>
        `;
    }
    renderListItemIssues(item, idx) {
        return html `
        <contentlistitem .info=${item} filter="${item.title}">
            <div>
                <h3>${item.title}</h3>
                <contentlabels>
                    ${repeat(item.labels, ((key) => key.name), ((k, index) => {
            return html `
                            <contentlabel style="background:#${k.color}3b; color:#${k.color}; border: 1px solid #${k.color}">
                                ${k.name}
                            </contentlabel>`;
        }))}
                </contentlabels>
            </div>
            <span>
                #${item.numberIssues} opened on ${new Date(item.createdAt).toLocaleString()} by ${item.author}  <span style="margin-left:1rem">project: ${!item.project ? 'none yet' : item.project.title}</span>
                <contentthumb style="float:right" title="add" @click="${this.addIssueInProject}">
                    ${unsafeHTML(this.myIcons.plus)}
                </contentthumb>
            </span>
        </contentlistitem>
        `;
    }
    //---------IMPLEMENTATION---------------
    async setInfos() {
        try {
            await this.initInfoProject();
            if (!this.req)
                return;
            this.repositoryId = await gitIO.getRepositoryId(this.req);
            this.userInfo = await gitIO.getUserInfoIO(this.req);
            this.myProjcts = await gitIO.getProjects(this.req);
            this.myLabels = await gitIO.getLabels(this.req);
            this.myUsers = await gitIO.getUsers(this.req);
            await this.isAutoClick();
            this.isLoader = false;
            this.requestUpdate();
        }
        catch (e) {
            this.error = e.message;
        }
    }
    async initInfoProject() {
        const prj = mls.actualProject;
        if (!prj)
            return;
        const info = getMyKeysBranch(prj);
        if (!info)
            return;
        this.req = {
            owner: info.owner, //"santiagoExpansiva", //info.owner,
            repo: info.repo, //"testGit", //info.repo,
            branch: info.branch,
        };
    }
    backButton(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'backbutton') {
            el = el.closest('backbutton');
        }
        if (!el || !el.getAttribute('back'))
            return;
        this.scenary = el.getAttribute('back');
        setTimeout(() => this.requestUpdate(), 100);
    }
    clickChangeView(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'viewtype') {
            el = el.closest('viewtype');
        }
        if (!el || !el.getAttribute('show'))
            return;
        this.scenary = el.getAttribute('show');
    }
    async addIssuesin(status) {
        this.addInStatus = status;
    }
    async addIssueInProject(e) {
        let el = e.target;
        let parent = el.closest('contentlistitem');
        if (!parent || !parent.info || !this.req || !this.viewProject)
            return;
        const { info } = parent;
        const isAdd = await gitIO.addIssueInProject(this.req, this.viewProject.id, info.id);
        if (isAdd)
            this.itensShowProject = await gitIO.getIssuesInProjects(this.req, this.viewProject.id);
        this.scenary = 'showStatus';
        setTimeout(() => { this.requestUpdate(); }, 100);
    }
    async clickSaveComment(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'button') {
            el = el.closest('button');
        }
        const input = el.parentElement?.querySelector('.textcomment');
        if (!input || !this.req || !this.viewIssue)
            return;
        if (!input.value) {
            alert('Empty comment');
            return;
        }
        const comm = await gitIO.addComment(this.req, this.viewIssue.issue, input.value);
        input.value = '';
        if (comm) {
            this.viewIssue.issue.comments.push(comm);
            this.requestUpdate();
            return;
        }
    }
    async clickItemProject(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'contentlistitem') {
            el = el.closest('contentlistitem');
        }
        if (!el || !el.info || !this.req)
            return;
        this.isLoader = true;
        this.viewProject = el.info;
        if (this.viewProject && this.viewProject.fields.length <= 0) {
            this.viewProject.fields = await gitIO.getProjectFields(this.req, this.viewProject.id);
        }
        if (this.viewProject) {
            this.itensShowProject = await gitIO.getIssuesInProjects(this.req, this.viewProject.id);
        }
        this.isLoader = false;
        this.scenary = 'showStatus';
        setTimeout(() => { this.requestUpdate(); }, 100);
    }
    async listAllIssues(e) {
        try {
            if (!this.req)
                return;
            let listIssues = await gitIO.getIssues(this.req);
            listIssues = listIssues.filter((l) => l.project === undefined);
            this.listIssues = listIssues;
            this.scenary = 'listAddIssues';
        }
        catch (err) {
            console.info('listAllIssues:' + err.message);
        }
    }
    async addIssue(e) {
        try {
            let el = e.target;
            if (el.tagName.toLocaleLowerCase() !== 'contentnewissue') {
                el = el.closest('contentnewissue');
            }
            if (!el || !this.req || !this.userInfo || !this.viewProject || !this.itensShowProject || !this.idFieldStatus)
                return;
            const title = el.querySelector('#inputtitle');
            const desc = el.querySelector('#inputdesc');
            if (!title || !desc || !title.value || !desc.value) {
                alert('fill in all fields');
                return;
            }
            this.isLoader = true;
            const issue = await gitIO.addNewIssueIO(this.req, this.userInfo, this.repositoryId, [], title.value, desc.value);
            title.value = '';
            desc.value = '';
            if (!issue)
                return;
            const isAdd = await gitIO.addIssueInProject(this.req, this.viewProject.id, issue.id);
            if (this.addInStatus && isAdd && this.addInStatus !== 'null') {
                await gitIO.updateFieldSelectProjects(this.req, this.viewProject.id, isAdd, this.idFieldStatus, this.addInStatus);
            }
            if (isAdd)
                this.itensShowProject = await gitIO.getIssuesInProjects(this.req, this.viewProject.id);
            this.addInStatus = undefined;
            this.isLoader = false;
            setTimeout(() => { this.requestUpdate(); }, 200);
        }
        catch (err) {
            this.isLoader = false;
            this.addInStatus = undefined;
            this.error = err.message;
        }
    }
    changeLabel(e) {
        if (!this.viewIssue)
            return;
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'input') {
            el = el.closest('input');
        }
        let item;
        this.myLabels.forEach((l, idx) => {
            if (l.id === el.id) {
                item = Object.assign({}, l);
            }
        });
        if (!item || !this.req)
            return;
        if (el.checked) {
            this.viewIssue.issue.labels.push(item);
            try {
                gitIO.addLabelInIssue(this.req, this.viewIssue.issue.id, item.id);
            }
            catch (err) {
                console.info('changeLabel add error:' + err.message);
            }
        }
        else {
            let index = -1;
            this.viewIssue.issue.labels.forEach((l, idx) => {
                if (l.id === el.id)
                    index = idx;
            });
            if (index >= 0) {
                this.viewIssue.issue.labels.splice(index, 1);
                try {
                    gitIO.removeLabelInIssue(this.req, this.viewIssue.issue.id, item.id);
                }
                catch (err) {
                    console.info('changeLabel remove error:' + err.message);
                }
            }
        }
        this.requestUpdate();
    }
    changeMembers(e) {
        if (!this.viewIssue)
            return;
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'input') {
            el = el.closest('input');
        }
        let item;
        this.myUsers.forEach((l, idx) => {
            if (l.login === el.id) {
                item = Object.assign({}, l);
            }
        });
        if (!item || !this.req)
            return;
        if (el.checked) {
            this.viewIssue.issue.assignees.push(item);
            try {
                gitIO.addMemberInIssue(this.req, this.viewIssue.issue.id, item.id);
            }
            catch (err) {
                console.info('changeMembers add error:' + err.message);
            }
        }
        else {
            let index = -1;
            this.viewIssue.issue.assignees.forEach((l, idx) => {
                if (l.login === el.id)
                    index = idx;
            });
            if (index >= 0) {
                this.viewIssue.issue.assignees.splice(index, 1);
                try {
                    gitIO.removeMemberInIssue(this.req, this.viewIssue.issue.id, item.id);
                }
                catch (err) {
                    console.info('changeMembers add error:' + err.message);
                }
            }
        }
        this.requestUpdate();
    }
    async removeIssueInProject(e) {
        if (!this.viewIssue || !this.itensShowProject || !this.req || !this.viewProject)
            return;
        let indexDel = -1;
        this.itensShowProject.forEach((i, index) => {
            if (this.viewIssue && i.issue.id === this.viewIssue.issue.id) {
                indexDel = index;
            }
        });
        if (indexDel < 0)
            return;
        this.itensShowProject.splice(indexDel, 1);
        try {
            gitIO.removeIssueInProject(this.req, this.viewProject.id, this.viewIssue.id);
        }
        catch (e) {
            console.info('removeIssueInProject:' + e.message);
        }
        this.viewIssue = undefined;
        this.requestUpdate();
    }
    async isAutoClick() {
        if (this.autoClick !== 'true' || !this.req)
            return;
        this.isLoader = true;
        this.viewProject = this.myProjcts[0];
        if (this.viewProject && this.viewProject.fields.length <= 0) {
            this.viewProject.fields = await gitIO.getProjectFields(this.req, this.viewProject.id);
        }
        if (this.viewProject) {
            this.itensShowProject = await gitIO.getIssuesInProjects(this.req, this.viewProject.id);
        }
        this.isLoader = false;
        this.scenary = 'showStatus';
    }
    //---- TAB MODE
    organizeItens() {
        if (!this.itensShowProject || !this.contentstatus)
            return;
        const ret = {};
        this.itensShowProject.forEach((i) => {
            const find = i.fieldValues.find((f) => f.fieldName.toLowerCase() === 'status');
            let id = find ? find.value : 'null';
            if (ret[id]) {
                ret[id].push(i);
            }
            else {
                ret[id] = [i];
            }
        });
        return ret;
    }
    async showViewIssue(e) {
        try {
            let el = e.target;
            if (el.tagName.toLocaleLowerCase() !== 'itemstatusissues') {
                el = el.closest('itemstatusissues');
            }
            const p = el && el.info ? el.info : undefined;
            if (!p || !this.req)
                return;
            p.issue.comments = await gitIO.getIssueComments(this.req, p.issue);
            this.viewIssue = p;
        }
        catch (e) {
            console.info(e);
        }
    }
    clickCloseIssue(e) {
        this.viewIssue = undefined;
    }
    openMyChild(e) {
        let el = e.target;
        let open = el.getAttribute('open');
        if (!open) {
            open = el.parentElement?.getAttribute('open');
            if (!open)
                return;
        }
        const elsOpen = this.querySelectorAll('*[child]');
        if (!elsOpen)
            return;
        Array.from(elsOpen).forEach((i) => {
            const my = i.getAttribute('child');
            if (my === open) {
                const st = i.style.display;
                i.style.display = st === 'none' ? '' : 'none';
            }
            else {
                i.style.display = 'none';
            }
        });
    }
    setDragAndDrop(active) {
        if (!active) {
            if (this.sort) {
                this.sort.forEach((i) => i.destroy());
            }
            return;
        }
        if (window['Sortable']) {
            const columns = this.querySelectorAll('contentst');
            if (!columns)
                return;
            const func = async (evt) => {
                const namefield = evt.to.getAttribute('namefield');
                const idField = evt.to.getAttribute('idfield');
                const idIssue = evt.item.info.id;
                const idStatus = evt.to.id.replace('st', '');
                const find = evt.item.info.fieldValues.find((f) => f.fieldName.toLowerCase() === 'status');
                if (find) {
                    find.value = idStatus;
                    find.valueText = namefield;
                }
                try {
                    if (!this.req || !this.viewProject)
                        throw new Error('Not found project');
                    await gitIO.updateFieldSelectProjects(this.req, this.viewProject.id, idIssue, idField, idStatus);
                    evt.item.remove();
                    this.requestUpdate();
                }
                catch (e) {
                    this.error = e.message;
                }
            };
            Array.from(columns).forEach((i) => {
                this.sort.push(window['Sortable'].create(i, {
                    group: 'shared',
                    sort: active,
                    onEnd: func,
                }));
            });
        }
    }
};
__decorate([
    property()
], PluginGithubL4Project.prototype, "error", void 0);
__decorate([
    property()
], PluginGithubL4Project.prototype, "scenary", void 0);
__decorate([
    property()
], PluginGithubL4Project.prototype, "isLoader", void 0);
__decorate([
    property()
], PluginGithubL4Project.prototype, "autoClick", void 0);
__decorate([
    property()
], PluginGithubL4Project.prototype, "viewIssue", void 0);
__decorate([
    property()
], PluginGithubL4Project.prototype, "addInStatus", void 0);
__decorate([
    property()
], PluginGithubL4Project.prototype, "listIssues", void 0);
__decorate([
    query('contentstatus')
], PluginGithubL4Project.prototype, "contentstatus", void 0);
__decorate([
    query('contentviewissue')
], PluginGithubL4Project.prototype, "contentviewissue", void 0);
PluginGithubL4Project = __decorate([
    customElement('plugin-github-l4-project-100554')
], PluginGithubL4Project);
export { PluginGithubL4Project };
