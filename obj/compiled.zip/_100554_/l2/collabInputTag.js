/// <mls fileReference="_100554_/l2/collabInputTag.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, ifDefined } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
export function initCollabInputTag() {
    return true;
}
let CollabInputTag = class CollabInputTag extends StateLitElement {
    constructor() {
        super(...arguments);
        this.tags = [];
        this.pattern = null;
        this.placeholder = null;
        this.allowDelete = false;
        this.hasError = false;
    }
    get value() {
        return this.tags.join(',');
    }
    set value(val) {
        if (!val) {
            this.empty();
            return;
        }
        const arrTags = val.split(',');
        this.tags = arrTags;
    }
    addTag(tag) { return this._addTag(tag); }
    deleteTag(index) { return this._deleteTag(index); }
    empty() { return this._empty(); }
    _addTag(tag) {
        if (!tag)
            return;
        if (!this.isValidTag(tag)) {
            this.input?.parentElement?.classList.add('invalid');
            setTimeout(() => this.input?.parentElement?.classList.remove('invalid'), 500);
            this.hasError = true;
            return;
        }
        if (this.tags.indexOf(tag) === -1) {
            this.tags.push(tag);
            if (this.input)
                this.input.value = '';
            this.requestUpdate();
        }
        else {
            const element = this.querySelector(`[data-index="${this.tags.indexOf(tag)}"]`);
            element.classList.add('duplicate');
            setTimeout(() => element.classList.remove('duplicate'), 500);
            this.hasError = true;
        }
    }
    _deleteTag(index) {
        const newTags = [];
        this.tags.forEach((tag, idx) => {
            if (idx !== index) {
                newTags.push(tag);
            }
        });
        this.tags = newTags;
        this.requestUpdate();
    }
    _empty() {
        this.tags = [];
        this.requestUpdate();
    }
    onInputLeave() {
        if (!this.input)
            return;
        const { value } = this.input;
        this._addTag(value);
        if (this.onValueChanged)
            this.onValueChanged(this.value);
    }
    onInputKeyDown(event) {
        event.stopImmediatePropagation();
        if (!this.input)
            return;
        const { value } = this.input;
        this.hasError = false;
        if (event.keyCode === 13) {
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 188) {
            event.preventDefault();
            this._addTag(value);
            if (this.onValueChanged)
                this.onValueChanged(this.value);
        }
        else if (event.keyCode === 8 && value.length === 0) {
            if (this.allowDelete) {
                this._deleteTag(this.tags.length - 1);
                if (this.onValueChanged)
                    this.onValueChanged(this.value);
                this.allowDelete = false;
            }
            else {
                this.allowDelete = true;
            }
        }
    }
    isValidTag(tag) {
        if (this.pattern) {
            const regex = new RegExp(this.pattern);
            if (!regex.test(tag))
                return false;
        }
        return true;
    }
    render() {
        return html `<div class="collab-tag-input">
                <input
                    id="tag-input"
                    placeholder=${ifDefined(!this.value ? this.placeholder : undefined)}
                    autocomplete="off"
                    @blur=${this.onInputLeave}
                    @keydown=${(ev) => { this.onInputKeyDown(ev); }}
                ></input>
                ${this.tags.map((tag, index) => {
            return html `
                    <div data-index=${index} class="tag">
                        ${tag}
                    </div>
                    `;
        })}
        </div>`;
    }
};
__decorate([
    property()
], CollabInputTag.prototype, "tags", void 0);
__decorate([
    query('#tag-input')
], CollabInputTag.prototype, "input", void 0);
__decorate([
    property({ type: String })
], CollabInputTag.prototype, "pattern", void 0);
__decorate([
    property({ type: String })
], CollabInputTag.prototype, "placeholder", void 0);
__decorate([
    property({ attribute: true, reflect: true })
], CollabInputTag.prototype, "hasError", void 0);
CollabInputTag = __decorate([
    customElement('collab-input-tag-100554')
], CollabInputTag);
export { CollabInputTag };
