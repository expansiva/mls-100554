/// <mls fileReference="_100554_/l2/pluginProjectInfo.ts" group="other" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { query, property, state } from 'lit/decorators.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
import { collab_trash, collab_lock, collab_lock_open, collab_arrow_up_long, collab_arrow_down_long } from '/_100554_/l2/collabIcons.js';
/// **collab_i18n_start**
const message_pt = {
    detailsResume: 'Resumo',
    designSystems: 'Design systems',
    lastModified: 'Última modificação',
    fork: 'Galhos',
    deps: 'Dependências',
    files: 'Arquivos',
    detailsInfo: 'Info',
    name: 'Nome',
    projectDriver: 'Driver',
    projectOrg: 'Organização',
    projectOwner: 'Proprietário',
    projectCreatedAt: 'Criado em',
    projectURL: 'URL do Projeto',
    save: 'Salvar',
    successSavingDeps: 'Dependências atualizadas',
    errorDepNull: "Informe o ID da dependência.",
    errorDepSame: "Não é permitido adicionar o próprio projeto como dependência.",
    errorDepAlreadyAdded: "Esta dependência já foi adicionada.",
    errorDepInvalid: "Este projeto não existe.",
    btnAddDep: "Adicionar",
    btnOpenDep: "Adicionar nova dependência",
    placeholderDep: "ID da dependência"
};
const message_en = {
    designSystems: 'Design systems',
    lastModified: 'Last Modified',
    detailsResume: 'Resume',
    fork: 'Forks',
    deps: 'Dependencies',
    files: 'Files',
    detailsInfo: 'Info',
    name: 'Name',
    projectDriver: 'Project Driver',
    projectOrg: 'Organization',
    projectOwner: 'Owner',
    projectCreatedAt: 'CreatedAt',
    projectURL: 'Project URL',
    save: 'Save',
    successSavingDeps: 'Dependencies updated',
    errorDepNull: "Please enter the dependency ID.",
    errorDepSame: "You cannot add the project itself as a dependency.",
    errorDepAlreadyAdded: "This dependency has already been added.",
    errorDepInvalid: "This project does not exist.",
    btnAddDep: "Add",
    btnOpenDep: "Add new dependency",
    placeholderDep: "Dependency ID"
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Info",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM216 336l24 0 0-64-24 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l48 0c13.3 0 24 10.7 24 24l0 88 8 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24zm40-208a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"/></svg>
    `;
    }
};
export class PluginProjectInfo extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-project-info-100554{font-family:var(--font-family-primary);display:block;overflow:auto;background:var(--bg-primary-color);font-size:var(--font-size-16)}plugin-project-info-100554 .saving-ok{color:var(--success-color);font-size:var(--font-size-12)}plugin-project-info-100554 .saving-error{color:var(--error-color);font-size:var(--font-size-12)}plugin-project-info-100554 input,plugin-project-info-100554 select,plugin-project-info-100554 textarea{display:block;font-size:1rem;line-height:1.5;color:#495057;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}plugin-project-info-100554 button{background-color:var(--info-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:inline-flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;width:max-content;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#ffffff;cursor:pointer}plugin-project-info-100554 button:hover{background-color:var(--info-color-hover)}plugin-project-info-100554 button .loader{display:inline-block;width:16px;height:16px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}plugin-project-info-100554 .plugin-body{height:100%;width:-webkit-fill-available;padding:1rem;overflow:hidden}plugin-project-info-100554 .plugin-container{padding:10px 0;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1);display:flex;flex-direction:column;align-items:flex-start;height:100%;width:100%}plugin-project-info-100554 header{margin-left:16px}plugin-project-info-100554 header>div{display:flex;gap:.5rem}plugin-project-info-100554 icon{margin-right:10px}plugin-project-info-100554 h2{font-size:18px;font-weight:bold;margin:0;color:#333}plugin-project-info-100554 small{color:#888;margin-left:auto;font-size:14px}plugin-project-info-100554 p{font-size:16px;color:#555}plugin-project-info-100554 .details-card{margin-top:1rem;border:1px solid var(--grey-color-light);padding:1rem;border-radius:10px}plugin-project-info-100554 .listInfo{list-style:none;margin:0px;padding:0px;padding-left:.5rem;margin-bottom:2rem}plugin-project-info-100554 .listInfo ul{list-style:none}plugin-project-info-100554 .deps-action{margin-top:4rem;display:flex;justify-content:end}plugin-project-info-100554 .deps-details-list{list-style:none;padding-inline-start:0}plugin-project-info-100554 .deps-details-list li.li-add{border:none;display:flex;justify-content:center}plugin-project-info-100554 .deps-details-list li.li-add span{text-decoration:underline;color:var(--active-color);cursor:pointer}plugin-project-info-100554 .deps-details-list li{padding:.75rem 1.25rem;border:1px solid var(--grey-color-light);display:flex;justify-content:start;align-items:center;border-right-width:0;border-left-width:0;border-radius:0;gap:1rem}plugin-project-info-100554 .deps-details-list li:first-child{border-top-width:0}plugin-project-info-100554 .deps-details-list li .deps-details-tags span{display:flex;align-items:center;padding:.2em .3em;font-size:75%;text-align:center;white-space:nowrap;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;color:#fff;background-color:#2e6596;border-radius:.25rem}plugin-project-info-100554 .deps-details-list li .deps-details-tags span svg{height:8px;fill:currentColor}plugin-project-info-100554 .deps-details-list li .deps-details-actions{display:flex;gap:.5rem;margin-left:auto;cursor:pointer}plugin-project-info-100554 .add-dep-wrapper{overflow:hidden;max-height:0;opacity:0;transform:translateY(-8px);transition:max-height 300ms ease,opacity 200ms ease,transform 200ms ease}plugin-project-info-100554 .add-dep-wrapper.open{max-height:120px;opacity:1;transform:translateY(0)}plugin-project-info-100554 .add-dep-content{display:flex;gap:8px;margin-top:8px}plugin-project-info-100554 .add-dep-content input{flex:1}plugin-project-info-100554 details{margin-bottom:1rem}plugin-project-info-100554 details summary{cursor:pointer}plugin-project-info-100554 details>div{padding-left:2rem}`);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.deps = [];
        this.isSavingDeps = false;
        this.labelOk = '';
        this.labelError = '';
        this.labelErrorDeps = '';
        this.isAddingDep = false;
        this.newDepId = null;
    }
    async prepare() {
        await this.init();
    }
    //------COMPONENT------
    firstUpdated() {
        if (!this.body || !this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.display = 'block';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderBody()}
            </div>
        `;
    }
    renderBody() {
        return html `<div class="plugin-body">
            ${this.renderInfo()}
            ${this.renderDependencies()}

        </div>`;
    }
    renderInfo() {
        return html `
            <div class="details-card">

                <details open>
                    <summary>${this.msg.detailsInfo}</summary>
                    <div>
                        <ul class="listInfo">
                            <li>
                                <b>${this.msg.name}:</b> 
                                ${this.projectName}
                            </li>
                            <li>
                                <b>${this.msg.projectOrg}:</b> 
                                ${this.projectOrg}
                            </li>
                                <li>
                                <b>${this.msg.projectOwner}:</b> 
                                ${this.projectOwner}
                            </li>
                                <li>
                                <b>${this.msg.projectCreatedAt}:</b> 
                                ${this.projectCreatedAt}
                            </li>
                            <li style="display:flex">
                                <b>${this.msg.projectDriver}:</b> 
                                ${this.projectDriver}
                            </li>
                            <li>
                                <b>${this.msg.projectURL}:</b>
                                ${this.projectURL}
                            </li>
                        </ul>
                    </div>
                </details>
            </div>
        `;
    }
    renderDependencies() {
        return html `

        <div class="details-card">
            <details open>
                <summary>${this.msg.deps}</summary>
                <div>
                    <ul class="deps-details-list">
                        ${this.deps.map((dep, index) => {
            return html `
                                <li>
                                    <span> ${dep.name}(${dep.id})</span>
                                    <div class="deps-details-tags">
                                        <span>
                                            <i>${dep.auth === 'public' ? collab_lock_open : collab_lock}</i>
                                            <span>${dep.auth}</span>
                                        </span>
                                    </div>
                                    <div class="deps-details-actions">
                                        <span @click=${() => this.moveDepUp(index)}>${collab_arrow_up_long}</span>
                                        <span @click=${() => this.moveDepDown(index)}>${collab_arrow_down_long}</span>
                                        <span @click=${() => {
                this.deps.splice(index, 1);
                this.requestUpdate();
            }}>
                                            ${collab_trash}
                                        </span>
                                    </div>

                                </li>
                            `;
        })}
        
                    <li class="li-add" @click=${this.toggleAddDep}>
                        <span>${this.msg.btnOpenDep}</span>
                    </li>
                    </ul>
                    <div class="add-dep-wrapper ${this.isAddingDep ? 'open' : ''}">
                    <div class="add-dep-content">
                        <input
                            type="number"
                            placeholder=${this.msg.placeholderDep}
                            .value=${this.newDepId ?? ''}
                            @input=${(e) => this.newDepId = Number(e.target.value)}
                        />

                        <button @click=${this.addDependency}>
                            ${this.msg.btnAddDep}
                        </button>
                    </div>

                    ${this.labelErrorDeps ? html `<small class="saving-error">${this.labelErrorDeps}<small>` : ''}      

                    </div>
                    <div class="deps-action">
                        <button
                            ?disabled=${this.isSavingDeps}
                            @click=${this.handleSaveDeps}
                        >
                            ${this.isSavingDeps ? html `<span class="loader"></span>` : this.msg.save}
                        </button>
                    </div>
                    ${this.labelOk ? html `<small class="saving-ok">${this.labelOk}<small>` : ''}
                    ${this.labelError ? html `<small class="saving-error">${this.labelError}<small>` : ''}      
                </div>
            </details>
        </div>
    
        `;
    }
    //-------IMPLEMENTS-----------
    moveDepUp(index) {
        if (index === 0)
            return;
        const deps = [...this.deps];
        [deps[index - 1], deps[index]] = [deps[index], deps[index - 1]];
        this.deps = deps;
    }
    moveDepDown(index) {
        if (index === this.deps.length - 1)
            return;
        const deps = [...this.deps];
        [deps[index], deps[index + 1]] = [deps[index + 1], deps[index]];
        this.deps = deps;
    }
    toggleAddDep() {
        this.isAddingDep = !this.isAddingDep;
        if (this.isAddingDep) {
            this.newDepId = null;
            this.labelErrorDeps = '';
        }
    }
    addDependency() {
        if (this.newDepId === null) {
            this.labelErrorDeps = this.msg.errorDepNull;
            return;
        }
        if (this.newDepId === this.project) {
            this.labelErrorDeps = this.msg.errorDepSame;
            return;
        }
        const exists = this.deps.some(dep => dep.id === this.newDepId);
        if (exists) {
            this.labelErrorDeps = this.msg.errorDepAlreadyAdded;
            return;
        }
        const depDetails = mls.l5.getProjectDetails(this.newDepId);
        if (!depDetails) {
            this.labelErrorDeps = this.msg.errorDepInvalid;
            return;
        }
        this.deps = [
            ...this.deps,
            {
                id: this.newDepId,
                name: depDetails.name,
                auth: depDetails.userAuth
            }
        ];
        this.newDepId = null;
        this.isAddingDep = false;
        this.labelErrorDeps = '';
    }
    async handleSaveDeps() {
        this.labelError = '';
        this.labelOk = '';
        this.isSavingDeps = true;
        try {
            await this.saveDeps();
            this.isSavingDeps = false;
            this.labelOk = `${this.msg.successSavingDeps}`;
        }
        catch (error) {
            console.error('Error on update perfil:', error);
            this.labelError = error.message;
            this.isSavingDeps = false;
        }
    }
    async saveDeps() {
        if (!this.project)
            throw new Error(`Project not found`);
        if (!this.projectDetails)
            throw new Error(`Project details ${this.project} not found`);
        this.projectDetails.prj_dependencies = this.deps.map((item) => item.id);
        mls.api.cbeSavePrjSettings(this.project);
    }
    async init() {
        try {
            const project = this.project ? +this.project : mls.actualProject;
            if (!project)
                return;
            this.setInfos(project);
            this.deps = this.getDependencies();
        }
        catch (err) {
            console.info(err);
        }
    }
    getDependencies() {
        const project = this.project ? +this.project : mls.actualProject;
        let deps = [];
        if (project)
            deps = mls.l5.getProjectDependencies(project, false);
        const allDependencies = [];
        deps.forEach((id) => {
            const depPrjDetails = mls.l5.getProjectDetails(id);
            const objDep = {};
            if (depPrjDetails) {
                objDep.name = depPrjDetails.name;
                objDep.id = depPrjDetails.id;
                objDep.auth = depPrjDetails.userAuth;
            }
            else {
                objDep.name = `Unknown - Project don't exists or deleted`;
                objDep.id = id;
                objDep.auth = '';
                objDep.unknown = true;
            }
            allDependencies.push(objDep);
        });
        return allDependencies;
    }
    setInfos(project) {
        this.project = project;
        let settings = mls.l5.getProjectSettings(project);
        this.projectDetails = mls.l5.getProjectDetails(project);
        if (!this.projectDetails || !settings)
            return;
        this.projectName = this.projectDetails.name;
        this.projectDriver = settings.projectDriver;
        this.projectCreatedAt = new Date(this.projectDetails.created_at).toLocaleString();
        this.projectOwner = this.projectDetails.owner;
        this.projectDriver = settings.projectDriver;
        this.projectURL = settings.projectURL;
        if (mls.l5.actualOrg) {
            this.projectOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
        }
    }
}
__decorate([
    property({ type: Boolean })
], PluginProjectInfo.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "project", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectName", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectDriver", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOrg", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectOwner", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectCreatedAt", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "projectURL", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "forks", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "branches", void 0);
__decorate([
    state()
], PluginProjectInfo.prototype, "deps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "isSavingDeps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelOk", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelError", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "labelErrorDeps", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "isAddingDep", void 0);
__decorate([
    property()
], PluginProjectInfo.prototype, "newDepId", void 0);
__decorate([
    query('.plugin-body')
], PluginProjectInfo.prototype, "body", void 0);
if (!customElements.get('plugin-project-info-100554')) {
    customElements.define('plugin-project-info-100554', PluginProjectInfo);
}
