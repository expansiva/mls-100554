/// <mls fileReference="_100554_/l2/agentGeneratePrototypeOrganism.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
