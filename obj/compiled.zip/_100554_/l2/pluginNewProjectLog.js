/// <mls fileReference="_100554_/l2/pluginNewProjectLog.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { collab_check, collab_circle_notch, collab_triangle_exclamation } from "/_100554_/l2/collabIcons";
import { CollabLitElement } from "/_100554_/l2/collabLitElement";
let CollabLogLine100554 = class extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-new-project-log-100554 {
  font-family: var(--font-family-primary);
}
plugin-new-project-log-100554 > div {
  display: flex;
  align-items: center;
  gap: 0.125rem;
  padding: 0.2rem;
  font-size: var(--font-size-16);
}
plugin-new-project-log-100554 > div > div {
  display: flex;
  align-items: center;
}
plugin-new-project-log-100554 [status="inprogress"] > div {
  animation: rotate 1s linear infinite;
}
@keyframes rotate {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}
plugin-new-project-log-100554 [status="error"] svg {
  fill: var(--error-color);
}
plugin-new-project-log-100554 [status="finish"] svg {
  fill: var(--success-color);
}
`);
    }
  text = "";
  status = "inprogress";
  iconsByStatus = {
    inprogress: collab_circle_notch,
    error: collab_triangle_exclamation,
    finish: collab_check,
    waiting: collab_circle_notch
  };
  render() {
    if (!this.text) return html``;
    return html`
        <div status=${this.status} style=" display: flex;">
            <div>${this.iconsByStatus[this.status]}</div>
            <span>${this.text}</span>
        </div>`;
  }
};
__decorateClass([
  property()
], CollabLogLine100554.prototype, "text", 2);
__decorateClass([
  property()
], CollabLogLine100554.prototype, "status", 2);
CollabLogLine100554 = __decorateClass([
  customElement("plugin-new-project-log-100554")
], CollabLogLine100554);
export {
  CollabLogLine100554
};
