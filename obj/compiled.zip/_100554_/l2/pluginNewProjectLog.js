/// <mls shortName="pluginNewProjectLog" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { collab_check, collab_circle_notch, collab_triangle_exclamation } from '/_100554_/l2/collabIcons';
import { CollabLitElement } from '/_100554_/l2/collabLitElement';
let CollabLogLine100554 = class CollabLogLine100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-project-log-100554{font-family:var(--font-family-primary)}plugin-new-project-log-100554>div{display:flex;align-items:center;gap:.125rem;padding:.2rem;font-size:var(--font-size-16)}plugin-new-project-log-100554>div>div{display:flex;align-items:center}plugin-new-project-log-100554 [status="inprogress"]>div{animation:rotate 1s linear infinite}@keyframes rotate{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}plugin-new-project-log-100554 [status="error"] svg{fill:var(--error-color)}plugin-new-project-log-100554 [status="finish"] svg{fill:var(--success-color)}`);
        this.text = '';
        this.status = 'inprogress';
        this.iconsByStatus = {
            inprogress: collab_circle_notch,
            error: collab_triangle_exclamation,
            finish: collab_check,
            waiting: collab_circle_notch
        };
    }
    render() {
        if (!this.text)
            return html ``;
        return html `
        <div status=${this.status} style=" display: flex;">
            <div>${this.iconsByStatus[this.status]}</div>
            <span>${this.text}</span>
        </div>`;
    }
};
__decorate([
    property()
], CollabLogLine100554.prototype, "text", void 0);
__decorate([
    property()
], CollabLogLine100554.prototype, "status", void 0);
CollabLogLine100554 = __decorate([
    customElement('plugin-new-project-log-100554')
], CollabLogLine100554);
export { CollabLogLine100554 };
