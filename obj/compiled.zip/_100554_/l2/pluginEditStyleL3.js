/// <mls fileReference="_100554_/l2/pluginEditStyleL3.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { html } from "lit";
import { customElement, query, property, state } from "lit/decorators.js";
import { convertFileNameToTag } from "/_102027_/l2/utils.js";
import { PluginBaseModule } from "/_100554_/l2/pluginBaseModule.js";
import { LessAST } from "/_100554_/l2/pluginEditStyleAST.js";
const message_pt = {
  noItens: "Nenhum item foi encontrado!"
};
const message_en = {
  noItens: "No items were found!"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let PluginEditStyleL3 = class extends PluginBaseModule {
  editorEl;
  msize = "";
  error = "";
  _ed1;
  _ed2;
  initalSelectors = [];
  msg = messages["en"];
  model;
  modelDest;
  modelBase;
  lessAst;
  lessAstDest;
  keysResolve = {};
  //-----------INIT------------
  get getKeyEditor() {
    return "l3_left";
  }
  get confE() {
    return `l3_left`;
  }
  constructor() {
    super();
    this.setEvents();
  }
  //--------EVENTS-------------
  setEvents() {
    mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ["ToolBarSelected"], (ev) => this.onlevelChange(ev));
    mls.events.addListener(3, "L3EditEvents", this.onL3EditEvents.bind(this));
  }
  onL3EditEvents(ev) {
    if (!ev.desc || ev.level !== 3) return;
    const info = JSON.parse(ev.desc);
    if (!info || !info.action || !info.position || info.position === "left") return;
  }
  onlevelChange(ev) {
    if (!ev.desc) return;
    const j = JSON.parse(ev.desc);
    if (j.level === 3) {
      this.forceUpdate();
    }
  }
  //-------COMPONENT----------
  createRenderRoot() {
    return this;
  }
  firstUpdated() {
    this.init();
  }
  updated(changedProperties) {
    super.updated(changedProperties);
    if (changedProperties.has("msize")) {
      this.updatedMSizeEditor();
    }
  }
  render() {
    this.style.display = "block";
    return html`
            ${this.error ? html`<h3 style="color:red">${this.error}</h3>` : ""}
            <mls-editor-100529 style="${this.error ? "display:none" : 'display: ""'}" slot="left"></mls-editor-100529>
        `;
  }
  //-------- IMPLEMENTATION --------------
  async forceUpdate() {
    this.error = "";
    await this.updateComplete;
    this.init();
  }
  async init() {
    if (!this._ed1) {
      await this.initMonaco_Editor();
    }
    this.openFile();
  }
  async initMonaco_Editor() {
    if (!this.editorEl) return;
    this._ed1 = monaco.editor.create(this.editorEl, { minimap: { enabled: false } });
    this._ed2 = monaco.editor.create(document.createElement("div"), { minimap: { enabled: false } });
    this.editorEl["mlsEditor"] = this._ed1;
    mls.editor.instances[this.confE] = this._ed1;
    mls.editor.InitEditor(this._ed1);
  }
  async openFile() {
    const path = mls.l2.getPath(mls.actual[3].getFullName());
    const key = mls.stor.getKeyToFiles(path.project, 2, path.shortName, path.folder, ".ts");
    const file = mls.stor.files[key];
    if (!file) {
      this.error = "Not found storfile";
      return;
    }
    const scope = window.preview?.iframe?.contentDocument?.body;
    const iframeDoc = window.preview?.iframe?.contentWindow;
    if (!scope || !iframeDoc) {
      this.error = "Not found preview";
      return;
    }
    if (!this.model) this.model = await this.createModel(file, "ori");
    if (!this.modelDest) this.modelDest = await this.createModel(file, "dest");
    const modelBase = mls.editor.getModels(file.project, file.shortName, file.folder);
    if (!modelBase || !modelBase.style) {
      this.error = "Not found base model";
      return;
    }
    if (!this._ed1 || !this.model || !this._ed2 || !this.modelDest) {
      this.error = "Not found model";
      return;
    }
    this._ed1.setModel(this.model);
    this._ed2.setModel(this.modelDest);
    this.modelBase = modelBase;
    PluginEditStyleL3.inSetValue = true;
    await this.setContentDest();
    await this.setContent(scope, iframeDoc);
    this.updatedMSizeEditor();
    PluginEditStyleL3.inSetValue = false;
  }
  async setContentDest() {
    if (!this.modelDest || !this.modelBase || !this.modelBase.style) return;
    this.modelDest.setValue(this.modelBase.style.model.getValue());
    await this._ed2?.getAction("editor.action.formatDocument")?.run();
  }
  async setContent(scope, iframeDoc) {
    const active = scope.querySelector("*[clb_mode]");
    if (!active) {
      this.error = "Not found element";
      return;
    }
    if (!this.lessAstDest) return;
    let cssText = "";
    const sel = this.getMatchingRulesForElement(active, iframeDoc);
    sel.forEach((selector) => {
      if (!this.lessAstDest) return;
      this.lessAstDest.select(selector.selector);
      cssText += `
${this.lessAstDest.exportSelectorGroupStrict(selector.selector)}`;
    });
    if (!cssText) {
      const { project, path } = mls.actual[3];
      const info = mls.l2.getPath(`_${project}_${path}`);
      const nameTag = convertFileNameToTag(info);
      cssText += `
            ${nameTag}{
                #${active.id}{

                }
            }
    
            `;
    }
    this.model?.setValue(cssText);
    await this._ed1?.getAction("editor.action.formatDocument")?.run();
  }
  async createModel(storFile, mode) {
    try {
      const uri = monaco.Uri.parse(`file://server/_${storFile.project + mode}_l3_editor.less`);
      let model = monaco.editor.getModel(uri);
      if (!model) model = monaco.editor.createModel("", "less", uri);
      model.onDidChangeContent(
        (e) => {
          this._onModelChange(e, mode);
        }
      );
      return model;
    } catch (e) {
      this.error = e.message;
    }
  }
  _onModelChange(e, mode) {
    if (PluginEditStyleL3.inEdit) return;
    if (mode === "ori" && this.model) {
      let isfirtTime = !this.lessAst;
      this.lessAst = new LessAST(this.model);
      if (isfirtTime) {
        this.initalSelectors = [...this.lessAst.blocks.keys()].filter((i) => i.indexOf(" ") >= 0);
      } else if (!PluginEditStyleL3.inSetValue) this.changeLessOrigin();
    } else if (mode === "dest" && this.modelDest) {
      this.lessAstDest = new LessAST(this.modelDest);
    }
  }
  timeOnChangeLessOrigin = 0;
  changeLessOrigin() {
    clearTimeout(this.timeOnChangeLessOrigin);
    this.timeOnChangeLessOrigin = setTimeout(() => {
      this.changeLessOrigin2();
    }, 600);
  }
  changeLessOrigin2() {
    if (!this.lessAst || !this.lessAstDest) return;
    PluginEditStyleL3.inEdit = true;
    const keys = [...this.lessAst.blocks.keys()].filter((i) => i.indexOf(" ") >= 0);
    keys.forEach((myKey) => {
      if (!this.lessAst || !this.lessAstDest) return;
      const keyCss = this.keysResolve[myKey] || myKey;
      if (!keyCss) return;
      if (this.lessAstDest.blocks.get(keyCss)) {
        this.lessAstDest.select(keyCss);
        this.lessAst.select(keyCss);
        this.mergeCssDeclarations();
      } else if (!this.lessAstDest.blocks.get(keyCss)) {
        this.lessAst.select(myKey);
        this.initalSelectors.push(keyCss);
        this.lessAstDest.addSelector(keyCss, this.lessAst.rules);
      }
    });
    const diff = this.initalSelectors.filter((item) => !keys.includes(item));
    diff.forEach((myKey) => {
      if (!this.lessAst || !this.lessAstDest) return;
      const keyCss = this.keysResolve[myKey] || myKey;
      this.lessAstDest.removeSelector(keyCss);
    });
    const newLess = this.modelDest?.getValue() || "";
    if (this.modelBase && this.modelBase.style && this.modelDest) this.modelBase.style.model.setValue(newLess);
    PluginEditStyleL3.inEdit = false;
    setTimeout(() => {
      this.modelDest?.setValue(newLess);
      if (this.modelBase && this.modelBase.ts && this.modelBase.style) {
        mls.events.fire([3], ["styleChanged"], JSON.stringify({ position: "left", storFile: this.modelBase.style.storFile }));
      }
    }, 500);
  }
  mergeCssDeclarations() {
    if (!this.lessAst || !this.lessAstDest || !this.lessAst.rules) return;
    for (const prop of Object.keys(this.lessAst.rules)) {
      const vl = this.lessAst.rules[prop];
      if (vl) this.lessAstDest.setRule(prop, vl);
    }
  }
  getMatchingRulesForElement(element, iframeDoc) {
    if (!iframeDoc.getMatchingRulesForElement) return [];
    return iframeDoc.getMatchingRulesForElement(element);
  }
  updatedMSizeEditor() {
    this.editorEl?.setAttribute("msize", this.msize);
  }
  resolveSelector(selector) {
    const parts = selector.trim().split(/\s+/);
    const result = [];
    for (const part of parts) {
      if (part.startsWith("&.")) {
        const className = part.slice(1);
        if (result.length > 0) {
          result[result.length - 1] += className;
        } else {
          result.push(className);
        }
      } else {
        result.push(part);
      }
    }
    return result.join(" ");
  }
};
//--------VARIABLES-----------
__publicField(PluginEditStyleL3, "inEdit", false);
__publicField(PluginEditStyleL3, "inSetValue", false);
__decorateClass([
  query("mls-editor-100529")
], PluginEditStyleL3.prototype, "editorEl", 2);
__decorateClass([
  property({ type: String })
], PluginEditStyleL3.prototype, "msize", 2);
__decorateClass([
  state()
], PluginEditStyleL3.prototype, "error", 2);
PluginEditStyleL3 = __decorateClass([
  customElement("plugin-edit-style-l3-100554")
], PluginEditStyleL3);
export {
  PluginEditStyleL3
};
