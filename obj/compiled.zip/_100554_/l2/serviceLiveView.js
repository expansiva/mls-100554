/// <mls fileReference="_100554_/l2/serviceLiveView.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { getProjectConfig, getProjectModuleConfig } from '/_102027_/l2/libCommom.js';
import { convertFileNameToTag, getPath } from '/_102027_/l2/utils.js';
import '/_100554_/l2/collabNav4Menu.js';
/// **collab_i18n_start**
const message_pt = {
    noFindModule: 'Nenhum modulo configurado.',
    noFindBuild: 'Nenhum arquivo "build" encontrado.',
    noFindStart: 'Nenhum arquivo "start" encontrado.',
};
const message_en = {
    noFindModule: 'No modules configured',
    noFindBuild: 'No find "build" file.',
    noFindStart: 'No find "start" file.',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceLiveView100554 = class ServiceLiveView100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-live-view-100554 {
  display: block;
}
service-live-view-100554 > * {
  height: 100%;
  width: 100%;
  display: block;
}
`);
        this.msg = messages['en'];
        this.details = {
            icon: '&#xf06e',
            state: 'foreground',
            position: 'right',
            tooltip: 'Live View',
            visible: true,
            widget: '_100554_serviceLiveView',
            level: [7]
        };
        this.menu = {
            enabled: false,
            title: '',
            main: {},
            tools: {},
            tabs: undefined,
        };
    }
    get liveView() {
        if (!this.liveViewTag)
            return null;
        return this.querySelector(this.liveViewTag);
    }
    async onServiceClick(visible, reinit, el) {
        if (visible && this.liveView?.iframe?.contentDocument) {
            const tabActual = this.liveView.tabs[this.liveView.actualTab];
            if (!tabActual)
                return;
            this.loading = true;
            const needUpdate = await this.buildInstance?.buildModule(tabActual.project, tabActual.moduleName);
            this.loading = false;
            /*
            if (needUpdate) {
                const actual7 = mls.actual[7];
                if (!actual7 || !actual7.project) return;
                const fullName = mls.actual[7].getFullName();
                const info = getPath(fullName);
                this.loading = true;
                await this.liveView.init(info.project, info.shortName, info.folder);
                this.loading = false;
            }*/
        }
    }
    async connectedCallback() {
        super.connectedCallback();
        const moduleConfig = await getProjectConfig(mls.actualProject);
        if (!moduleConfig || !moduleConfig.masterFrontEnd)
            return;
        const infoLiveView = getPath(moduleConfig.masterFrontEnd.liveView);
        const infoBuild = getPath(moduleConfig.masterFrontEnd.build);
        const infoStart = getPath(moduleConfig.masterFrontEnd.start);
        if (!infoLiveView)
            throw new Error('[connectedCallback] Not found path:' + moduleConfig.masterFrontEnd.liveView);
        if (!infoBuild)
            throw new Error('[connectedCallback 2] Not found path:' + moduleConfig.masterFrontEnd.build);
        if (!infoStart)
            throw new Error('[connectedCallback 3] Not found path:' + moduleConfig.masterFrontEnd.start);
        const storFileLiveView = mls.stor.files[mls.stor.getKeyToFiles(infoLiveView.project, 2, infoLiveView.shortName, infoLiveView.folder, '.ts')];
        const storFileBuild = mls.stor.files[mls.stor.getKeyToFiles(infoBuild.project, 2, infoBuild.shortName, infoBuild.folder, '.ts')];
        const storFileStart = mls.stor.files[mls.stor.getKeyToFiles(infoStart.project, 2, infoStart.shortName, infoStart.folder, '.ts')];
        if (storFileLiveView)
            await import(`/${moduleConfig.masterFrontEnd.liveView}`);
        if (storFileBuild)
            this.buildInstance = await import(`/${moduleConfig.masterFrontEnd.build}`);
        if (storFileStart)
            this.startInstance = await import(`/${moduleConfig.masterFrontEnd.start}`);
        if (moduleConfig.masterBackEnd && moduleConfig.masterBackEnd.start) {
            const infoBuildBE = getPath(moduleConfig.masterBackEnd.start);
            if (!infoBuildBE)
                throw new Error('[connectedCallback 4] Not found path:' + moduleConfig.masterBackEnd.start);
            const storFileStartBE = mls.stor.files[mls.stor.getKeyToFiles(infoBuildBE.project, 2, infoBuildBE.shortName.replace('.js', '').replace('.ts', ''), infoBuildBE.folder.replace('/l2', ''), '.ts')];
            if (storFileStartBE)
                this.startServerInstance = await import(`/${moduleConfig.masterBackEnd.start}`);
        }
        if (infoLiveView.shortName)
            this.liveViewTag = convertFileNameToTag(infoLiveView);
    }
    async updated(_changedProperties) {
        super.updated(_changedProperties);
        if (_changedProperties.has('liveViewTag') && _changedProperties.get('liveViewTag') !== '') {
            this.loading = true;
            const projectConfig = await getProjectConfig(mls.actualProject);
            const actual7 = mls.actual[7];
            if (!actual7 || !actual7.project) {
                if (!projectConfig) {
                    this.loading = false;
                    return;
                }
                const firstModule = projectConfig.modules[0];
                if (!firstModule) {
                    this.loading = false;
                    return;
                }
                ;
                const moduleConfig = await getProjectModuleConfig(firstModule.path, mls.actualProject);
                if (!moduleConfig) {
                    this.loading = false;
                    return;
                }
                ;
                const page = moduleConfig.initialPage;
                mls.actual[7].setFullName(`_${mls.actualProject}_${firstModule.path}/${page}`);
            }
            // openService('_100554_serviceCollabMessages', 'left', 7, { mode: 'Apps ' });
            const fullName = mls.actual[7].getFullName();
            const info = getPath(fullName);
            if (!info)
                throw new Error('[updated] Not found path:' + fullName);
            this.liveView.setAttribute('mode', 'develpoment');
            await this.liveView.updatedCompleted;
            if (this.startInstance.start && typeof this.startInstance.start === 'function') {
                await this.startInstance.start();
            }
            if (this.startServerInstance && typeof this.startServerInstance.start === 'function') {
                await this.startServerInstance.start(info.project, 'all');
            }
            await this.buildInstance?.buildModule(info.project, info.folder);
            await this.liveView?.init(info.project, info.shortName, info.folder);
            this.loading = false;
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.liveViewTag)
            return html `<h3>${this.msg.noFindModule}<h3>`;
        else if (!this.startInstance)
            return html `<h3>${this.msg.noFindStart}<h3>`;
        else if (!this.buildInstance)
            return html `<h3>${this.msg.noFindBuild}<h3>`;
        const htmlString = `<${this.liveViewTag}></${this.liveViewTag}>`;
        return html `${unsafeHTML(htmlString)}`;
    }
};
__decorate([
    state()
], ServiceLiveView100554.prototype, "liveViewTag", void 0);
ServiceLiveView100554 = __decorate([
    customElement('service-live-view-100554')
], ServiceLiveView100554);
export { ServiceLiveView100554 };
