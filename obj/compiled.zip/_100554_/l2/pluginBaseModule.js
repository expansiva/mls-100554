/// <mls fileReference="_100554_/l2/pluginBaseModule.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { property } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
class PluginBaseModule extends StateLitElement {
  scope = "dashboard";
}
__decorateClass([
  property()
], PluginBaseModule.prototype, "scope", 2);
export {
  PluginBaseModule
};
