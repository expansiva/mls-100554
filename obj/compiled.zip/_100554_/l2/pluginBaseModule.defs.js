/// <mls fileReference="_100554_/l2/pluginBaseModule.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/pluginBaseModule.ts",
        "componentType": "pluginUI",
        "componentScope": "appFrontEnd"
    },
    "references": {
        "imports": [
            {
                "ref": "lit/decorators.js",
                "dependencies": [
                    {
                        "name": "property"
                    }
                ]
            },
            {
                "ref": "/_102029_/l2/stateLitElement.js",
                "dependencies": [
                    {
                        "name": "StateLitElement",
                        "type": "class"
                    }
                ]
            }
        ]
    },
    "asIs": {
        "semantic": {
            "generalDescription": "Abstract base class for plugin modules.",
            "technicalCapabilities": [
                "Base class for Lit-based plugin modules",
                "Scope management for plugins"
            ],
            "businessCapabilities": [],
            "implementedFeatures": [
                "scope property",
                "abstract render method"
            ]
        }
    }
};
