/// <mls fileReference="_100554_/l2/ateste2.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
