/// <mls fileReference="_100554_/l2/pluginCodelensServiceDetails.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html, unsafeHTML } from "lit";
import { customElement } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
const message_pt = {
  title: "Detalhes do servi\xE7o",
  p1: "Para que seu service esteja disponivel para uso, \xE9 preciso configurar corretamente o service details, assim definindo o nome, icone, posi\xE7\xF5es, level entre outras defini\xE7\xF5es.",
  icon: "Icone",
  p2: 'Para definir o icone, voc\xEA precisa primeiro escolher um que mais representa ao seu service, no <a href="https://fontawesome.com/icons" target="_blank">FontAwesome </a>. Ap\xF3s escolher, copie o seu unicode e preencha na propriedade icon.',
  example: "Exemplo",
  state: "Estado",
  p3: ' \xC9 possivel escolher entre o state "foreground" e "background". No caso do foreground, o seu service ser\xE1 executado somente quando chamado em tela pelo usu\xE1rio. No caso do background, seu service \xE9 instanciado, assim que inicia o level em que ele executa. ',
  exampleCustom: "Exemplo Personalizado por posi\xE7\xE3o:",
  p4: "Tamb\xE9m \xE9 possivel customizar, determinadas propriedades para cada level/position",
  exampleLevel: "Exemplo Personalizado por n\xEDvel:",
  p5: "Tamb\xE9m \xE9 possivel customizar, determinadas propriedades para cada level, nesse caso as configura\xE7\xF5es ser\xE3o aplicadas tanto para a posi\xE7\xE3o left e right"
};
const message_en = {
  title: "Service Details",
  p1: "For your service to be available for use, it is necessary to properly configure the service details, thus defining the name, icon, positions, level, among other settings.",
  icon: "Icon",
  p2: 'To set the icon, you first need to choose one that best represents your service, on <a href="https://fontawesome.com/icons" target="_blank">FontAwesome</a>. After choosing, copy its unicode and fill in the icon property.',
  example: "Example",
  state: "State",
  p3: 'You can choose between the states "foreground" and "background". In the case of foreground, your service will only be executed when called on screen by the user. In the case of background, your service is instantiated as soon as the level it executes on starts.',
  exampleCustom: "Custom Example by Position:",
  p4: "It is also possible to customize certain properties for each level/position.",
  exampleLevel: "Custom Example by Level:",
  p5: "It is also possible to customize certain properties for each level; in this case, the settings will be applied to both the left and right positions."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let PluginCodelensServiceDetails = class extends CollabLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-codelens-service-details-100554 wc-code-100554 code {
  white-space: pre;
}
`);
    this.msg = messages["en"];
    this.textExampleIcon = `public details: IService = {
    icon: '&#x[seu unicode]',
    ...
}
`;
    this.textExampleNormal = `public details: IService = {
    icon:'&#x[seu unicode]',
    state: 'background',
    tooltip: 'My service',
    visible: true,
    position: "right",
    level: [3]
}
    `;
    this.textExampleCustom = `public details: IService = {
    icon:'&#x[seu unicode]',
    state: 'background',
    tooltip: 'My service',
    visible: true,
    position: "all",
    level: [4,5]
    customConfiguration: {
        4: {
            left: {
                tooltip: 'My title 1'
            },
            right: {
                show: false
            }
        },

        5: {
            right: {
                tooltip: 'My title 2',
                classname: 'separator-left'
            }
        }
    }
}
`;
    this.textExampleCustomLevel = `public details: IService = {
    icon:'&#x[seu unicode]',
    state: 'background',
    tooltip: 'My service',
    visible: true,
    position: "all",
    level: [3,4,5]
    customConfiguration: {
        4: {
            tooltip: 'My service title left and right'
    
        }
    }
}
`;
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
        <h1> ${this.msg.title} </h1>
        <p> ${this.msg.p1}</p>
        <h2>${this.msg.icon}</h2>
        <p> ${unsafeHTML(this.msg.p2)} </p>
        <p>${this.msg.example}:</p>
         <wc-code-100554
            text=${this.textExampleIcon}
            language="typescript">
        </wc-code-100554>

        <h2>${this.msg.state}</h2>
        <p>${this.msg.p3}</p>
        <h2>${this.msg.example}:</h2>
        <wc-code-100554
            text=${this.textExampleNormal}
            language="typescript">
        </wc-code-100554>
        
        <h2>${this.msg.exampleCustom}</h2>
        <p>${this.msg.p4}</p>
        <wc-code-100554
            text=${this.textExampleCustom}
            language="typescript">
        </wc-code-100554>
        
        <h2>${this.msg.exampleLevel}</h2>
        <p>${this.msg.p5}</p>
        <wc-code-100554
            text=${this.textExampleCustomLevel}
            language="typescript">
        </wc-code-100554>
    
        `;
  }
};
PluginCodelensServiceDetails = __decorateClass([
  customElement("plugin-codelens-service-details-100554")
], PluginCodelensServiceDetails);
export {
  PluginCodelensServiceDetails
};
