/// <mls fileReference="_100554_/l2/collabEditorPreviewMd.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
// ─── Component ────────────────────────────────────────────────────────────────
let PageMdPreview = class PageMdPreview extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-editor-preview-md-100554 {
  display: block;
  font-family: var(--font-sans);
}
collab-editor-preview-md-100554 .error-banner {
  background: var(--color-background-danger);
  border: 0.5px solid var(--color-border-danger);
  border-radius: var(--border-radius-md);
  padding: 10px 14px;
  color: var(--color-text-danger);
  font-size: 12px;
  font-family: var(--font-mono);
  white-space: pre-wrap;
}
collab-editor-preview-md-100554 .error-banner strong {
  display: block;
  margin-bottom: 4px;
  font-size: 13px;
}
collab-editor-preview-md-100554 .pg-title {
  font-size: 17px;
  font-weight: 500;
  color: var(--color-text-primary);
  margin-bottom: 4px;
}
collab-editor-preview-md-100554 .pg-meta {
  font-size: 11px;
  color: var(--color-text-tertiary);
  margin-bottom: 16px;
  font-family: var(--font-mono);
}
collab-editor-preview-md-100554 .pg-layout {
  display: flex;
  gap: 16px;
  align-items: flex-start;
}
collab-editor-preview-md-100554 .pg-main {
  flex: 2;
  min-width: 0;
}
collab-editor-preview-md-100554 .pg-aside {
  flex: 1;
  min-width: 0;
}
collab-editor-preview-md-100554 .pg-full {
  width: 100%;
}
collab-editor-preview-md-100554 .section-label {
  font-size: 10px;
  font-weight: 500;
  color: var(--color-text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-bottom: 10px;
  padding-bottom: 6px;
  border-bottom: 0.5px solid var(--color-border-tertiary);
}
collab-editor-preview-md-100554 .fieldset {
  margin-bottom: 14px;
}
collab-editor-preview-md-100554 .fieldset-title {
  font-size: 11px;
  font-weight: 500;
  color: var(--color-text-secondary);
  margin-bottom: 8px;
  padding: 4px 8px;
  background: var(--color-background-secondary);
  border-radius: 4px;
}
collab-editor-preview-md-100554 .tabs {
  display: flex;
  gap: 2px;
  margin-bottom: 12px;
  border-bottom: 0.5px solid var(--color-border-tertiary);
  padding-bottom: 0;
}
collab-editor-preview-md-100554 .tab {
  font-size: 11px;
  padding: 5px 10px;
  cursor: pointer;
  color: var(--color-text-secondary);
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
}
collab-editor-preview-md-100554 .tab.active {
  color: var(--color-text-primary);
  border-bottom-color: var(--color-text-primary);
  font-weight: 500;
}
collab-editor-preview-md-100554 .tab-content {
  display: none;
}
collab-editor-preview-md-100554 .tab-content.active {
  display: block;
}
collab-editor-preview-md-100554 .field-wrap {
  margin-bottom: 10px;
}
collab-editor-preview-md-100554 .field-label-above {
  font-size: 11px;
  color: var(--color-text-secondary);
  margin-bottom: 3px;
}
collab-editor-preview-md-100554 .field-mock {
  border: 0.5px solid var(--color-border-secondary);
  border-radius: 6px;
  padding: 7px 10px;
  font-size: 12px;
  background: var(--color-background-primary);
  color: var(--color-text-primary);
  min-height: 32px;
  position: relative;
  display: flex;
  align-items: center;
}
collab-editor-preview-md-100554 .field-mock.textarea {
  min-height: 64px;
  align-items: flex-start;
  padding-top: 8px;
}
collab-editor-preview-md-100554 .field-mock.inside-label {
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  gap: 1px;
}
collab-editor-preview-md-100554 .inside-lbl {
  font-size: 9px;
  color: var(--color-text-tertiary);
  line-height: 1;
}
collab-editor-preview-md-100554 .example-text {
  color: var(--color-text-tertiary);
  font-size: 12px;
}
collab-editor-preview-md-100554 .suffix {
  margin-left: auto;
  font-size: 10px;
  color: var(--color-text-tertiary);
}
collab-editor-preview-md-100554 .field-hint {
  font-size: 10px;
  color: var(--color-text-tertiary);
  margin-top: 3px;
  padding-left: 2px;
}
collab-editor-preview-md-100554 .field-select .arrow {
  width: 10px;
  height: 10px;
  margin-left: auto;
  border-right: 1.5px solid var(--color-text-tertiary);
  border-bottom: 1.5px solid var(--color-text-tertiary);
  transform: rotate(45deg);
  margin-top: -4px;
  flex-shrink: 0;
}
collab-editor-preview-md-100554 .field-badge {
  display: inline-flex;
  align-items: center;
  padding: 3px 8px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 500;
  background: var(--color-background-success);
  color: var(--color-text-success);
}
collab-editor-preview-md-100554 .field-toggle {
  width: 30px;
  height: 16px;
  border-radius: 8px;
  background: var(--color-background-success);
  position: relative;
  flex-shrink: 0;
}
collab-editor-preview-md-100554 .field-toggle::after {
  content: '';
  position: absolute;
  top: 2px;
  right: 2px;
  width: 12px;
  height: 12px;
  border-radius: 6px;
  background: #fff;
}
collab-editor-preview-md-100554 .field-currency::before {
  content: 'R$';
  margin-right: 5px;
  color: var(--color-text-secondary);
  font-size: 11px;
}
collab-editor-preview-md-100554 .search-icon {
  width: 12px;
  height: 12px;
  border: 1.5px solid var(--color-text-tertiary);
  border-radius: 50%;
  margin-right: 6px;
  flex-shrink: 0;
}
collab-editor-preview-md-100554 .callout {
  background: var(--color-background-info);
  border-left: 3px solid var(--color-border-info);
  border-radius: 0 6px 6px 0;
  padding: 8px 12px;
  font-size: 12px;
  color: var(--color-text-info);
  margin-bottom: 12px;
}
collab-editor-preview-md-100554 .actions-bar {
  display: flex;
  gap: 8px;
  margin-top: 16px;
  padding-top: 12px;
  border-top: 0.5px solid var(--color-border-tertiary);
}
collab-editor-preview-md-100554 .btn-primary {
  background: var(--color-text-primary);
  color: var(--color-background-primary);
  border: none;
  border-radius: 6px;
  padding: 7px 14px;
  font-size: 12px;
  cursor: pointer;
}
collab-editor-preview-md-100554 .btn-secondary {
  background: transparent;
  border: 0.5px solid var(--color-border-secondary);
  border-radius: 6px;
  padding: 7px 14px;
  font-size: 12px;
  cursor: pointer;
  color: var(--color-text-primary);
}
collab-editor-preview-md-100554 .btn-danger {
  background: transparent;
  border: 0.5px solid var(--color-border-danger);
  border-radius: 6px;
  padding: 7px 14px;
  font-size: 12px;
  cursor: pointer;
  color: var(--color-text-danger);
  margin-left: auto;
}
`);
        this._tree = null;
        this._error = '';
        this._html = '';
        this._rawMd = '';
    }
    connectedCallback() {
        this._rawMd = this.innerHTML;
        this.innerHTML = '';
        super.connectedCallback();
    }
    firstUpdated() {
        try {
            this._tree = this.parseMd(this._rawMd);
            this._html = this.renderNode(this._tree);
            this._error = '';
            console.log('[page-md-preview] tree:', this._tree);
        }
        catch (e) {
            this._error = e.message;
        }
    }
    render() {
        if (this._error)
            return html `<pre class="err">${this._error}</pre>`;
        if (!this._tree)
            return html `<pre>parsing...</pre>`;
        return html `${unsafeHTML(this._html)}`;
    }
    // ─── Parser ───────────────────────────────────────────────────────────────────
    parseAttrs(raw) {
        // ex: "main {cols: 2/3}" => { name:'main', cols:'2/3' }
        const attrs = {};
        const m = raw.match(/^([^\{]+)(?:\{([^\}]*)\})?/);
        if (!m)
            return attrs;
        attrs.name = m[1].trim();
        if (m[2]) {
            m[2].split(',').forEach((p) => {
                const [k, v] = p.split(':');
                if (k && v)
                    attrs[k.trim()] = v.trim();
            });
        }
        return attrs;
    }
    parseFieldProps(lines, i) {
        // lê propriedades indentadas após um "> field:"
        const props = {};
        while (i < lines.length && /^\s{2,}/.test(lines[i])) {
            const m = lines[i].trim().match(/^(\w+):\s*(.*)/);
            if (m)
                props[m[1]] = m[2];
            i++;
        }
        return { props, newI: i };
    }
    parseMd(md) {
        const lines = md.split('\n');
        let i = 0;
        const root = { molecule: 'div', cols: 1, child: [], name: "root" };
        const stack = [root];
        const currentParent = (level) => {
            return stack[level - 1] || root;
        };
        const pushNode = (level, node) => {
            const parent = currentParent(level);
            if (!parent.child)
                parent.child = [];
            parent.child.push(node);
            stack[level] = node;
            for (let l = level + 1; l < stack.length; l++)
                stack[l] = undefined;
        };
        while (i < lines.length) {
            const line = lines[i];
            i++;
            if (!line.trim())
                continue;
            // ── Headings → div container ─────────────────────────────────────
            const hm = line.match(/^(#{1,6})\s+(.*)/);
            if (hm) {
                const level = hm[1].length;
                const attrs = this.parseAttrs(hm[2]);
                const molecule = attrs.molecule ? attrs.molecule : 'div';
                if (attrs.molecule)
                    delete attrs.molecule;
                const node = {
                    name: attrs.name || '',
                    molecule,
                    ...attrs,
                    child: [],
                };
                pushNode(level, node);
                continue;
            }
            // ── > field: → campo ─────────────────────────────────────────────
            if (line.startsWith('> field:') || line.startsWith('&gt; field:')) {
                const fieldId = line.replace('> field:', '').replace('&gt; field:', '').trim();
                const { props, newI } = this.parseFieldProps(lines, i);
                i = newI;
                const molecule = props.molecule || 'span';
                if (props.molecule)
                    delete props.molecule;
                const field = { molecule, field: fieldId, atrs: props };
                const parent = stack.filter(Boolean).at(-1) || root;
                if (!parent.child)
                    parent.child = [];
                parent.child.push(field);
                continue;
            }
            // ── > callout ────────────────────────────────────────────────────
            if (line.startsWith('> ')) {
                const parent = stack.filter(Boolean).at(-1) || root;
                if (!parent.child)
                    parent.child = [];
                parent.child.push({ molecule: 'callout', label: line.slice(2).trim() });
                continue;
            }
            // ── ## actions / lista numerada ───────────────────────────────────
            if (/^\d+\./.test(line)) {
                const al = line.replace(/^\d+\.\s*/, '');
                const parts = al.split('|').map((s) => s.trim());
                const [id, label] = (parts[0] || '').split(':').map((s) => s.trim());
                const parent = stack.filter(Boolean).at(-1) || root;
                if (!parent.child)
                    parent.child = [];
                parent.child.push({ molecule: 'action', atrs: { name: id, label, style: parts[1] || 'secondary', condition: parts[2] } });
                continue;
            }
        }
        return root;
    }
    // ─── Renderer ─────────────────────────────────────────────────────────────────
    attrsStr(atrs = {}) {
        return Object.entries(atrs)
            .map(([k, v]) => `${k}="${v}"`)
            .join(' ');
    }
    renderNode(node) {
        let { molecule, child = [] } = node;
        // nós sem tag própria → só renderiza filhos
        if (!molecule)
            return this.renderChildren(child);
        const nodeAttrs = this.attrsStr(node.atrs ? node.atrs : {});
        const inner = this.renderChildren(child);
        // self-closing se não tiver filhos nem label inline
        if (!inner) {
            if (['action'].includes(molecule)) {
                return `<button ${nodeAttrs}>${node.atrs.label}</button>`;
            }
            if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'label', 'span'].includes(molecule) && node.atrs.label) {
                return `<${molecule} ${nodeAttrs}>${node.atrs.label}</${molecule}>`;
            }
            return `<${molecule} ${nodeAttrs}></${molecule}>`;
        }
        let style = "";
        let name = node.name;
        if (node.cols > 1) {
            style = `style="display:flex"`;
        }
        return `<${molecule} ${nodeAttrs} ${style} name="${name}">${inner}</${molecule}>`;
    }
    renderChildren(children = []) {
        return children.map((n) => this.renderNode(n)).join('');
    }
};
__decorate([
    state()
], PageMdPreview.prototype, "_tree", void 0);
__decorate([
    state()
], PageMdPreview.prototype, "_error", void 0);
__decorate([
    state()
], PageMdPreview.prototype, "_html", void 0);
PageMdPreview = __decorate([
    customElement('collab-editor-preview-md-100554')
], PageMdPreview);
export { PageMdPreview };
