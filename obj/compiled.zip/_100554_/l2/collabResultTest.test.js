/// <mls fileReference="_100554_/l2/collabResultTest.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
