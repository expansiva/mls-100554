/// <mls shortName="enhancementLit" project="100554" enhancement="_blank" groupName="other" />
import { convertFileNameToTag } from '/_100554_/l2/utilsLit.js';
import { getPropierties } from '/_100554_/l2/propiertiesLit.js';
import { getComponentDependencies } from '/_100554_/l2/dependenciesLit.js';
import { validateTagName, validateRender } from '/_100554_/l2/validateLit.js';
import { setCodeLens } from '/_100554_/l2/codeLensLit.js';
import { injectStyle } from '/_100554_/l2/processCssLit.js';
export const requires = [
    {
        type: 'tspath',
        name: 'lit',
        ref: "file://server/_100554_/l2/litElement.ts"
    },
    {
        type: 'tspath',
        name: 'lit/decorators.js',
        ref: "file://server/_100554_/l2/litDecorators.ts"
    },
    {
        type: "cdn",
        name: "lit",
        ref: "https://cdn.jsdelivr.net/gh/lit/dist@3/all/lit-all.min.js",
    },
    {
        type: "cdn",
        name: "lit/decorators.js",
        ref: "https://cdn.jsdelivr.net/npm/lit@3.0.0/decorators/+esm",
    }
];
export const getDefaultHtmlExamplePreview = (modelTS) => {
    const { project, shortName, folder } = modelTS.storFile;
    const tag = convertFileNameToTag({ project, shortName, folder });
    return `<${tag}></${tag}>`;
};
export const getDesignDetails = (modelTS) => {
    return new Promise((resolve, reject) => {
        try {
            const ret = {};
            ret.defaultHtmlExamplePreview = getDefaultHtmlExamplePreview(modelTS);
            ret.properties = getPropierties(modelTS);
            ret.webComponentDependencies = getComponentDependencies(modelTS);
            ret['servicePreviewDefault'] = '_100529_service_preview';
            resolve(ret);
        }
        catch (e) {
            reject(e);
        }
    });
};
export const onAfterChange = async (modelTS) => {
    try {
        setCodeLens(modelTS);
        if (validateTagName(modelTS)) {
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'left');
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'right');
            return;
        }
        if (validateRender(modelTS)) {
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'left');
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'right');
            return;
        }
    }
    catch (e) {
        return e.message || e;
    }
};
export const onAfterCompile = async (modelTS) => {
    await injectStyle(modelTS, 'Default');
    return;
};
