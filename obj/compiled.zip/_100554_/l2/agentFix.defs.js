const asis = {
  "meta": {
    "fileReference": "_100554_/l2/agentFix.ts",
    "componentType": "agent",
    "componentScope": "editor",
    "group": "enhancement"
  },
  "references": {
    "imports": [
      {
        "ref": "/_100554_/l2/aiAgentBase.js",
        "dependencies": [
          {
            "name": "IAgent",
            "type": "interface"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/aiAgentHelper.js",
        "dependencies": [
          {
            "name": "getNextPendingStepByAgentName",
            "type": "function"
          },
          {
            "name": "getNextInProgressStepByAgentName",
            "type": "function"
          },
          {
            "name": "updateStepStatus",
            "type": "function"
          },
          {
            "name": "getNextFlexiblePendingStep",
            "type": "function"
          },
          {
            "name": "updateTaskTitle",
            "type": "function"
          },
          {
            "name": "appendLongTermMemory",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/aiAgentOrchestration.js",
        "dependencies": [
          {
            "name": "startNewInteractionInAiTask",
            "type": "function"
          },
          {
            "name": "startNewAiTask",
            "type": "function"
          },
          {
            "name": "executeNextStep",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/libCommom.js",
        "dependencies": [
          {
            "name": "forceServiceInstance",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/collabState.js",
        "dependencies": [
          {
            "name": "getState",
            "type": "function"
          },
          {
            "name": "setState",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/serviceSource.js",
        "dependencies": [
          {
            "name": "ServiceSource100554",
            "type": "class"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/collabLibModel.js",
        "dependencies": [
          {
            "name": "createAllModels",
            "type": "function"
          }
        ]
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Responsavel por corrigir erros",
      "businessCapabilities": [
        "Voc\xEA \xE9 um agente especializado em corrigir erros de componentes web desenvolvidos com o framework Lit",
        "O arquivo do source seria fornecido, juntamente com um resumo dos erros encontrados no arquivo. Sua tarefa \xE9: 1. Ver os erros e identificar quais altera\xE7\xF5es precisam ser realizadas 2. Executar apenas as altera\xE7\xF5es necess\xE1rias 3. Retornar somente os arquivos que voc\xEA modificou"
      ],
      "technicalCapabilities": [
        "Arquivo '.ts' com a l\xF3gica do componente",
        "Arquivo '.html' com a pagina em que o componente esta sendo usado",
        "Arquivo '.less' com os estilos"
      ],
      "implementedFeatures": [
        "beforePrompt",
        "afterPrompt",
        "replayForSupport"
      ],
      "constraints": [
        "N\xE3o se deve remover ou renomear atributos sem a solicita\xE7\xE3o do usuario",
        "N\xE3o se deve adicionar novos tokens no less",
        '*N\xE3o remover*, a primeira linha com tripleslash ex: /// <mls shortName="xxx" project="yyy" enhancement="yyy" groupName="zzzz" />',
        "N\xE3o alterar o valor dos itens do tripleslash(shortName,project,enhancement,groupName)",
        "Os arquivos .ts e .less tem como controle a primeira linha sendo um tripleslash. Essa linha \xE9 obrigat\xF3ria, n\xE3o remover.",
        "Os atributos v\xE1lidos s\xE3o : shortName,project,enhancement,groupName.",
        "Corrigir o nome dos atributos se necess\xE1rio.",
        "N\xE3o adicionar novos atributos.",
        "N\xE3o alterar o value dos atributos",
        'O value dever\xE1 ser sempre entre aspas duplas "" ex: /// <mls shortName="xxx" project="yyy" enhancement="yyy" groupName="zzzz" />',
        "Erro na tipagem do *repeat* no lit: is not assignable to parameter of type 'RepeatFunction'.",
        "Erros de nomes de tokens Less: ex margin: @space-4 => NameError: variable @space-4 is undefined"
      ]
    }
  }
};
export {
  asis
};
