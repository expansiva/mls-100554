import { getPromptByHtml } from "/_100554_/l2/aiPrompts.js";
import { createAllModels } from "/_100554_/l2/collabLibModel.js";
import { removeTokensFromSource } from "/_102027_/l2/libCompileStyle.js";
import { getTokensLess, getGlobalLess } from "/_100554_/l2/designSystemBase.js";
import {
  getNextPendingStepByAgentName,
  getNextInProgressStepByAgentName,
  getNextFlexiblePendingStep,
  appendLongTermMemory,
  notifyTaskChange,
  updateStepStatus
} from "/_100554_/l2/aiAgentHelper.js";
import {
  startNewInteractionInAiTask,
  startNewAiTask,
  executeNextStep
} from "/_100554_/l2/aiAgentOrchestration.js";
const agentName = "agentGenerateStyle";
const project = 100554;
function createAgent() {
  return {
    agentName,
    avatar_url: svgStyle,
    agentDescription: "Agent for optimize style",
    visibility: "public",
    scope: ["l2_preview"],
    async beforePrompt(context) {
      return _beforePrompt(context);
    },
    async afterPrompt(context) {
      return _afterPrompt(context);
    }
  };
}
const _beforePrompt = async (context) => {
  const taskTitle = "Planning Style....";
  if (!context || !context.message) throw new Error("Invalid context");
  if (!context.task) {
    let data2;
    let pp = context.message.content.replace(`@@ ${agentName}`, "").replace(`@@${agentName}`, "").trim().replace(`@@GenerateStyle`, "");
    data2 = mls.common.safeParseArgs(pp);
    if (!("page" in data2)) throw new Error(`[${agentName}] beforePrompt: Invalid prompt structure`);
    let inputs2 = await getPrompts(data2);
    await startNewAiTask(
      agentName,
      taskTitle,
      context.message.content,
      context.message.threadId,
      context.message.senderId,
      inputs2,
      context,
      _afterPrompt,
      { "fileName": data2.page }
    ).catch((err) => {
      throw new Error(err.message);
    });
    return;
  }
  const step = getNextPendingStepByAgentName(context.task, agentName);
  if (!step) throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
  context = await updateStepStatus(context, step.stepId, "in_progress");
  if (!step.prompt) throw new Error(`[${agentName}] beforePrompt: No prompt found in step for this agent.`);
  const data = mls.common.safeParseArgs(step.prompt);
  if (!("page" in data)) throw new Error(`[${agentName}] beforePrompt: Invalid prompt structure`);
  await appendLongTermMemory(context, { "fileName": data.page });
  const inputs = await getPrompts(data);
  await startNewInteractionInAiTask(agentName, taskTitle, inputs, context, _afterPrompt, step.stepId);
};
const _afterPrompt = async (context) => {
  if (!context || !context.message || !context.task) throw new Error("Invalid context");
  const step = getNextInProgressStepByAgentName(context.task, agentName);
  if (!step) throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
  context = await updateStepStatus(context, step.stepId, "completed");
  context = await updateFile(context);
  notifyTaskChange(context);
  await executeNextStep(context);
};
async function getPrompts(data) {
  const info = mls.l2.getPath(data.page);
  const typescript = data.mode === "organism" ? await getContentByExtension(info, "ts") : "";
  const html = data.mode === "page" ? await getContentByExtension(info, "html") : "";
  let less = await getContentByExtension(info, "style");
  if (less) less = removeTokensFromSource(less);
  const themeModule = await import(`/_${info.project}_/l2/${info.folder}/module.js`);
  let theme = "Default";
  if (themeModule && themeModule.moduleConfig && themeModule.moduleConfig.theme && typeof themeModule.moduleConfig.theme === "string") {
    theme = themeModule.moduleConfig.theme;
  }
  const tokens = await getTokensLess(info.project, theme);
  const globalCss = await getGlobalLess(info.project);
  const dataForReplace = {
    html,
    typescript,
    tokens,
    globalCss: globalCss.replace(/project-\d+\s*{([\s\S]*)}$/m, "$1"),
    less,
    promptUser: data.prompt || ""
  };
  console.info(dataForReplace);
  const prompts = await getPromptByHtml({ project, shortName: agentName, folder: "", data: dataForReplace });
  return prompts;
}
async function getContentByExtension(info, modelType) {
  try {
    let models = getModel(info);
    if (!models) {
      const keyToStorFile = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, ".ts");
      const stotFile = mls.stor.files[keyToStorFile];
      if (!stotFile) throw new Error(`[${agentName}][getContentByExtension]: Invalid storFile`);
      models = await createAllModels(stotFile);
    }
    if (!models) throw new Error(`[${agentName}][getContentByExtension]:Not found models for file:` + info.shortName);
    if (!models[modelType]) return "";
    return models[modelType]?.model.getValue();
  } catch (e) {
    throw new Error(`[${agentName}][getContentByExtension]: ${e.message}`);
  }
}
function getModel(info) {
  const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, mls.actualLevel);
  return mls.editor.models[key];
}
async function updateFile(context) {
  if (!context || !context.task) throw new Error(`[${agentName}] updateFile: Not found context`);
  const step = getNextFlexiblePendingStep(context.task);
  if (!step || step.type !== "flexible") throw new Error(`[${agentName}] updateFile: Invalid step in updateFile`);
  const result = step.result;
  if (!result) throw new Error(`[${agentName}] updateFile: Not found "result"`);
  const fileName = context.task?.iaCompressed?.longMemory["fileName"];
  if (!fileName) throw new Error(`[${agentName}] updateFile: Invalid task memory arguments`);
  const { logs, resultHtmlComponent, resultLessComponent, resultLessGlobal, resultTypescriptComponent } = result;
  const { folder, project: project2, shortName } = mls.l2.getPath(fileName);
  const models = getModel({ folder, project: project2, shortName });
  if (!models) throw new Error(`[${agentName}] updateFile: Not found models`);
  if (resultHtmlComponent && models.html) models.html.model.setValue(resultHtmlComponent);
  if (resultLessComponent && models.style) {
    const resultLessComponent2 = await prepareComponentCss(resultLessComponent, project2, folder);
    models.style.model.setValue(resultLessComponent2);
  }
  if (resultTypescriptComponent && models.ts) {
    models.ts.model.setValue(resultTypescriptComponent);
    mls.editor.forceModelUpdate(models.ts.model);
  }
  if (resultLessGlobal) await updateGlobalCss(resultLessGlobal, project2, folder);
  context = await updateStepStatus(context, step.stepId, "completed");
  return context;
}
async function updateGlobalCss(globalCss, project2, theme) {
  const pathGlobal = mls.l2.getPath(`_${project2}_project`);
  let modelsGlobal = getModel({ folder: pathGlobal.folder, project: pathGlobal.project, shortName: pathGlobal.shortName });
  if (!modelsGlobal) {
    const keyToStorFile = mls.stor.getKeyToFiles(pathGlobal.project, 2, "project", pathGlobal.folder, ".ts");
    const storFile = mls.stor.files[keyToStorFile];
    if (!storFile) throw new Error(`[${agentName}] updateFile: Not found project file`);
    modelsGlobal = await createAllModels(storFile, true, true);
  }
  if (!modelsGlobal) throw new Error(`[${agentName}] updateFile: Not found models for project file`);
  const css = await prepareGlobalCss(globalCss, project2, theme);
  if (css && modelsGlobal.style) {
    modelsGlobal.style.model.setValue(css);
    mls.editor.forceModelUpdate(modelsGlobal.style.model);
  }
}
async function prepareComponentCss(css, projectId, theme) {
  const tokens = await getTokensLess(projectId, theme);
  const resultCss = removeTokensFromSource(css);
  const tokensCss = `

//Start Less Tokens
${tokens}
//End Less Tokens`;
  return `${resultCss}
${tokensCss}`;
}
async function prepareGlobalCss(css, projectId, theme) {
  let lines = css.split("\n");
  if (lines[0].trim().startsWith("///")) {
    lines.shift();
  }
  let cssContent = lines.join("\n").trim();
  const tokens = await getTokensLess(projectId, theme);
  cssContent = removeTokensFromSource(cssContent);
  const tokensCss = `

//Start Less Tokens
${tokens}
//End Less Tokens`;
  return `/// <mls shortName="project" project="${projectId}" enhancement="enhancementStyle" folder="" />
project-${projectId} {
${cssContent}
}${tokensCss}`;
}
const svgStyle = `<svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M17.5.381a1.5 1.5 0 0 1 .119 2.119l-9 10a1.14 1.14 0 0 1-.2.18 5.116 5.116 0 0 1-.69 2.54 4.1 4.1 0 0 1-.7.9c-2.2 2.21-6.529 2.25-7 1.26-.15-.33.22-.57 1.31-2.45 1.3-2.27 1.4-3 1.95-3.55.099-.103.21-.194.33-.27a4.092 4.092 0 0 1 2.76-.7l.04.04L15.379.5A1.5 1.5 0 0 1 17.5.381z" fill="#494c4e" fill-rule="evenodd"></path> </g></svg>`;
export {
  createAgent
};
