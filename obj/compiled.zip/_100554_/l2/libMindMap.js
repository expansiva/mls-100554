const allDefs = {};
async function getAllDefs() {
  await loadAllDefs();
  return { ...allDefs };
}
async function getDefsByFile(file) {
  await loadAllDefs();
  const key = mls.stor.getKeyToFile({ ...file, extension: ".defs.ts" });
  return allDefs[key] ? { ...allDefs[key].defs } : void 0;
}
async function getMindMapByName(file) {
  try {
    if (!file) throw new Error(`Not found file: ${file}`);
    const info = mls.l2.getPath(file);
    if (!info || !info.shortName) return;
    let { project, folder, shortName } = info;
    folder = folder.replace("/l2", "").trim();
    shortName = shortName.replace(".defs.ts", "").trim();
    shortName = shortName.replace(".ts", "").trim();
    const key = mls.stor.getKeyToFile({ project, level: 2, shortName, folder, extension: ".defs.ts" });
    if (!mls.stor.files[key]) throw new Error(`Not found mls.stor: ${key}`);
    return _getMindMapByFile(mls.stor.files[key]);
  } catch (e) {
    throw new Error(`Error: ${e.message}`);
  }
}
async function getMindMapByStorFile(file) {
  if (file.extension !== ".defs.ts") {
    let { project, folder, shortName, level } = file;
    const key = mls.stor.getKeyToFile({ project, folder, shortName, extension: ".defs.ts", level });
    if (!mls.stor.files[key]) throw new Error(`Not found mls.stor: ${key}`);
    file = mls.stor.files[key];
  }
  return _getMindMapByFile(file);
}
function setMindMapVariable(bread) {
  window.mlsBreadcrumbMindMap = bread;
}
function getMindMapVariable() {
  return window.mlsBreadcrumbMindMap || [];
}
async function _getMindMapByFile(file) {
  await loadAllDefs();
  const key = mls.stor.getKeyToFile({ project: file.project, level: file.level, shortName: file.shortName, folder: file.folder, extension: ".defs.ts" });
  if (!allDefs[key]) return;
  const data = buildMindMapFromInsights(allDefs[key].defs);
  data.nodes = data.nodes.map((i) => {
    i = {
      ...i,
      related: Array.from(new Set(i.related))
    };
    if (i.related.length <= 1 && !["imports", "asIs", "importedBy"].includes(i.id)) i.related = [];
    return i;
  });
  return data;
}
function buildMindMapFromInsights(input) {
  const nodes = [];
  const centerId = `service:${input.meta.fileReference}`;
  const pushNode = (node) => {
    nodes.push(node);
    return node;
  };
  const normalizeRelations = () => {
    nodes.forEach((n) => {
      n.related = Array.from(new Set(n.related));
    });
  };
  const fileKey = input.meta.fileReference;
  const centerNode = pushNode({
    id: fileKey + "_" + centerId,
    label: input.meta.fileReference,
    type: "main",
    meta: { fileKey },
    related: []
  });
  if (Array.isArray(input.meta.languages) && input.meta.languages.length) {
    const groupId = fileKey + "_language";
    const groupNode = pushNode({
      id: groupId,
      label: "Languages",
      type: "language",
      meta: { fileKey },
      related: []
    });
    centerNode.related.push(groupId);
    input.meta.languages.forEach((lang) => {
      const id = fileKey + `_lang:${lang}`;
      pushNode({
        id,
        label: lang.toUpperCase(),
        type: "attributes",
        meta: { fileKey },
        related: [groupId]
      });
      groupNode.related.push(id);
    });
  }
  if (Array.isArray(input.references?.webComponents) && input.references.webComponents.length) {
    const groupId = fileKey + "_webComponents";
    const groupNode = pushNode({
      id: groupId,
      label: "Web Components",
      type: "webcomponent",
      meta: { fileKey },
      related: []
    });
    centerNode.related.push(groupId);
    input.references.webComponents.forEach((wc) => {
      const id = fileKey + `_wc:${wc}`;
      pushNode({
        id,
        label: wc,
        type: "file_wc",
        related: [groupId],
        meta: { fileKey },
        navigate: true
      });
      groupNode.related.push(id);
    });
  }
  if (Array.isArray(input.references?.imports) && input.references.imports.length) {
    const groupId = fileKey + "_imports";
    const groupNode = pushNode({
      id: groupId,
      label: "Imports",
      type: "imports",
      meta: { fileKey },
      related: []
    });
    centerNode.related.push(groupId);
    input.references.imports.forEach((imp) => {
      const importId = fileKey + `_import:${imp.ref}`;
      let text = "";
      (imp.dependencies || []).forEach((dep) => {
        text = `${text}<li>${dep.name}</li>`;
      });
      if (text !== "") text = `<ul>${text}</ul>`;
      pushNode({
        id: importId,
        label: imp.ref,
        type: "file",
        related: [groupId],
        navigate: true,
        meta: { fileKey },
        description: text
      });
      groupNode.related.push(importId);
    });
  }
  if (Array.isArray(input.references?.importedBy) && input.references.importedBy.length) {
    const groupId = fileKey + "_importedBy";
    const groupNode = pushNode({
      id: groupId,
      label: "ImportedBy",
      type: "importedBy",
      meta: { fileKey },
      related: []
    });
    centerNode.related.push(groupId);
    input.references.importedBy.forEach((wc) => {
      const id = fileKey + `_importedBy:${wc}`;
      pushNode({
        id,
        label: wc,
        type: "file_wc",
        related: [groupId],
        meta: { fileKey },
        navigate: true
      });
      groupNode.related.push(id);
    });
  }
  const insights = input.codeInsights || {};
  if (Object.keys(insights).length) {
    const groupId = fileKey + "_codeInsights";
    const groupNode = pushNode({
      id: groupId,
      label: "Code Insights",
      type: "codeInsights",
      meta: { fileKey },
      related: []
    });
    centerNode.related.push(groupId);
    Object.entries(insights).forEach(([key, value]) => {
      const sectionId = fileKey + `_insight:${key}`;
      let description = joinStringArrayDescription(value);
      description = description === "<ul></ul>" ? "" : description;
      pushNode({
        id: sectionId,
        label: key.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase()),
        type: "text",
        related: [groupId],
        meta: { fileKey },
        description
      });
      groupNode.related.push(sectionId);
    });
  }
  const asIs = input.asIs || {};
  const semantic = asIs.semantic || {};
  if (Object.keys(semantic).length) {
    const groupId = fileKey + "_asIs";
    const groupNode = pushNode({
      id: groupId,
      label: "As Is",
      type: "asIs",
      meta: { fileKey },
      related: ["asIs:semantic"]
    });
    centerNode.related.push(groupId);
    const semanticId = fileKey + "_asIs:semantic";
    const semanticNode = pushNode({
      id: semanticId,
      label: "Semantic",
      type: "attributes",
      meta: { fileKey },
      related: [groupId]
    });
    groupNode.related.push(semanticId);
    Object.entries(semantic).forEach(([key, value]) => {
      const nodeId = fileKey + `_asIs:semantic:${key}`;
      let description = joinStringArrayDescription(value);
      description = description === "<ul></ul>" ? "" : description;
      pushNode({
        id: nodeId,
        label: key.replace(/([A-Z])/g, " $1").replace(/^./, (s) => s.toUpperCase()),
        type: "text",
        related: [semanticId],
        meta: { fileKey },
        description
      });
      semanticNode.related.push(nodeId);
    });
  }
  normalizeRelations();
  return {
    current: fileKey + "_" + centerId,
    nodes
  };
}
function joinStringArrayDescription(value) {
  if (Array.isArray(value) && value.every((v) => typeof v === "string")) {
    return `<ul>${value.map((i) => `<li>${i}</li>`).join("\n")}</ul>`;
  }
  if (typeof value === "string") {
    return value;
  }
  return void 0;
}
async function loadAllDefs() {
  if (Object.keys(allDefs).length > 0) return;
  const allKeys = Object.keys(mls.stor.files).filter((k) => {
    const f = mls.stor.files[k];
    return f.extension === ".defs.ts" && f.level === 2;
  });
  for await (const key of allKeys) {
    try {
      const f = mls.stor.files[key];
      if (!f) return;
      const fileName = `/_${f.project}_/l2/${f.folder ? f.folder + "/" : ""}${f.shortName}.defs.js`;
      const m = await import(fileName);
      if (!m || !m.asis) continue;
      allDefs[key] = {
        defs: m.asis,
        file: f
      };
    } catch (e) {
      continue;
    }
  }
  configAdditionalInformations();
}
async function configAdditionalInformations() {
  configiImportedBy();
}
function configiImportedBy() {
  for (const key of Object.keys(allDefs)) {
    try {
      const info = allDefs[key];
      const importedBy = [];
      const name = `/_${info.file.project}_/l2/${info.file.folder ? info.file.folder + "/" : ""}${info.file.shortName}.js`;
      Object.keys(allDefs).forEach((into) => {
        if (into === key) return;
        const obj = allDefs[into];
        if (!obj.defs.references?.imports) return;
        let find = obj.defs.references?.imports.find((i) => i.ref === name);
        if (find) {
          const nameFile = `/_${obj.file.project}_/l2/${obj.file.folder ? obj.file.folder + "/" : ""}${obj.file.shortName}.js`;
          importedBy.push(nameFile);
        }
      });
      if (!info.defs.references) info.defs.references = {};
      if (importedBy.length > 0) info.defs.references.importedBy = importedBy;
    } catch (e) {
      continue;
    }
  }
}
export {
  allDefs,
  getAllDefs,
  getDefsByFile,
  getMindMapByName,
  getMindMapByStorFile,
  getMindMapVariable,
  setMindMapVariable
};
