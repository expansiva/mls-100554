/// <mls fileReference="_100554_/l2/cssHelperIndexBase.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/cssHelperIndexBase.ts",
        "componentType": "other",
        "componentScope": "editor",
        "group": "enhancement"
    },
    "asIs": {
        "semantic": {
            "generalDescription": "TypeScript types for CSS helpers",
            businessCapabilities: [],
            "technicalCapabilities": [
                "Defines TypeScript types"
            ],
            "implementedFeatures": [
                "IMode type",
                "IHelpers interface"
            ]
        }
    }
};
