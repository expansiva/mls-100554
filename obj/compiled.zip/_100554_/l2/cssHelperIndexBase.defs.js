const asis = {
  "meta": {
    "fileReference": "_100554_/l2/cssHelperIndexBase.ts",
    "componentType": "other",
    "componentScope": "editor",
    "group": "enhancement"
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Defines types for CSS helpers",
      "businessCapabilities": [],
      "technicalCapabilities": [
        "TypeScript types and interfaces"
      ],
      "implementedFeatures": [
        "IMode",
        "IHelpers"
      ]
    }
  }
};
export {
  asis
};
