/// <mls fileReference="_100554_/l2/collabSelectOneWithDescription.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property, query, queryAll } from "lit/decorators.js";
import { propertyDataSource, propertyCompositeDataSource } from "/_100554_/l2/collabDecorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
import { collab_bolt } from "/_100554_/l2/collabIcons.js";
const initCollabSelectOneWithDescription = "";
const message_pt = {
  defaultMsg: "Passe o mouse sobre as op\xE7\xF5es para saber mais."
};
const message_en = {
  defaultMsg: "Hover over the options to learn more."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let CollabSelectOneWithDescription100554 = class extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-select-one-with-description-100554 {
  display: block;
  position: relative;
}
collab-select-one-with-description-100554 .select_container {
  font-size: 14px;
  transform: translate3d(0px, 0px, 0px);
  box-sizing: content-box;
  border-width: 0px;
  border-style: solid;
  border-color: var(--bg-primary-color-darker);
  border-radius: 4px;
  box-shadow: 0px 12px 24px 8px rgba(0, 0, 0, 0.08), 0px 8px 16px 4px rgba(0, 0, 0, 0.08), 0px 4px 8px 2px rgba(0, 0, 0, 0.08), 0px 2px 6px 0px rgba(0, 0, 0, 0.08), 0px -0.5px 0.5px 0px rgba(0, 0, 0, 0.12) inset, 0px 0.5px 0.5px 0px rgba(255, 255, 255, 0.12) inset;
  overflow: hidden;
  width: 300px;
  position: absolute;
  background: var(--bg-primary-color-lighter);
  color: var(--text-primary-color);
  z-index: 9999;
  top: 30px;
  display: none;
}
collab-select-one-with-description-100554 .select_toogle {
  cursor: pointer;
  width: 30px;
  text-align: center;
  border-radius: 8px;
  color: var(--text-primary-color);
}
collab-select-one-with-description-100554 .select_toogle svg {
  fill: var(--text-primary-color);
}
collab-select-one-with-description-100554 .select_container.open {
  display: block;
}
collab-select-one-with-description-100554 .desc_container {
  padding: 1rem 0;
  font-weight: bold;
  text-align: center;
}
collab-select-one-with-description-100554 ul {
  list-style: none;
  padding-inline-start: 0px;
  border-bottom: 1px solid var(--grey-color-dark);
  margin: 0;
  padding: 0.5rem 0;
}
collab-select-one-with-description-100554 ul > li {
  outline: 0px;
  cursor: default;
  user-select: none;
  height: 24px;
  padding: 4px 8px;
}
collab-select-one-with-description-100554 ul > li.hover {
  background: var(--grey-color-light);
  font-weight: bold;
}
`);
    }
  msg = messages["en"];
  hint;
  required = false;
  disabled = false;
  label;
  options;
  selectedvalue;
  select_container;
  select_toogle;
  desc_container;
  optionItems;
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    this.defaultMsg = this.msg.defaultMsg;
    return html`
            <div class="select_toogle" tabindex="1" @blur=${this.onBlur} @click=${this.onIconClick}>${collab_bolt}</div>
            <div tabindex="0" @blur=${this.onBlur} class="select_container">
                <ul>
                    ${this.renderOpt()}
                </ul>
                <div tabindex="0" @blur=${this.onBlur} class="desc_container">
                    ${this.defaultMsg}
                </div>
            </div>
   
    `;
  }
  firstUpdated() {
    this.onkeydown = (e) => {
      this.handleKeyDown(e);
    };
  }
  defaultMsg = "";
  currentIndex = -1;
  onIconClick(e) {
    e.stopPropagation();
    this.toogle();
  }
  onBlur(e) {
    if (this.select_container?.contains(e.relatedTarget)) {
      e.preventDefault();
      return;
    }
    this.select_container?.classList.remove("open");
  }
  renderOpt() {
    if (this.options) {
      return html`
                ${this.options.map((opt, index) => {
        return html`
                <li 
                    tabindex="0"  
                    @blur=${this.onBlur} 
                    @mouseover=${this.handleHover}
                    @mouseout=${this.handleOut}
                    @focus=${(ev) => {
          this.handleFocus(ev, index);
        }}
                    @click=${() => {
          this.handleChange(opt.value);
        }}
                    .description=${opt.description}
                    .val=${opt.value}
                    >
                    ${opt.key}
                </li>`;
      })}
        `;
    }
  }
  handleHover(ev) {
    const target = ev.target;
    if (!this.desc_container || !this.optionItems) return;
    this.desc_container.innerHTML = target.description;
    this.optionItems.forEach((item) => item.classList.remove("hover"));
    target.classList.add("hover");
  }
  handleOut() {
    if (!this.desc_container) return;
    this.desc_container.innerHTML = this.defaultMsg;
  }
  handleFocus(ev, index) {
    const target = ev.target;
    this.currentIndex = index;
    if (!this.desc_container || !this.optionItems) return;
    this.desc_container.innerHTML = target.description;
    this.optionItems.forEach((item) => item.classList.remove("hover"));
    target.classList.add("hover");
  }
  handleChange(value) {
    this.selectedvalue = value;
    this.dispatchEvent(new CustomEvent("select-change", {
      detail: value,
      bubbles: true,
      composed: true
    }));
    this.toogle();
  }
  handleKeyDown(event) {
    event.preventDefault();
    switch (event.key) {
      case "ArrowDown":
        if (this.optionItems && this.currentIndex < this.optionItems.length - 1) {
          this.currentIndex++;
          this.optionItems[this.currentIndex].focus();
        }
        break;
      case "ArrowUp":
        if (this.optionItems && this.currentIndex > 0) {
          this.currentIndex--;
          this.optionItems[this.currentIndex].focus();
        }
        break;
      case "Enter":
      case " ":
        event.preventDefault();
        if (this.optionItems && this.currentIndex > -1) {
          const val = this.optionItems[this.currentIndex].val;
          this.handleChange(val);
        }
        break;
    }
  }
  toogle() {
    if (!this.select_container || !this.optionItems) return;
    this.select_container.classList.toggle("open");
    if (this.select_container.classList.contains("open")) {
      this.calculatePopupPosition();
      if (this.optionItems[this.currentIndex]) this.optionItems[this.currentIndex].focus();
    }
  }
  calculatePopupPosition() {
    if (!this.select_toogle || !this.select_container) return;
    const selectBoxRect = this.select_toogle.getBoundingClientRect();
    const popupHeight = this.select_container.offsetHeight;
    const popupWidth = this.select_container.offsetWidth;
    this.select_container.style.left = "";
    this.select_container.style.top = "";
    this.select_container.style.bottom = "";
    const spaceBelow = window.innerHeight - selectBoxRect.bottom;
    const spaceRight = window.innerWidth - selectBoxRect.right;
    if (spaceBelow >= popupHeight) this.select_container.style.top = `${30}px`;
    else this.select_container.style.top = `-${popupHeight + 5}px`;
    if (spaceRight >= popupWidth) this.select_container.style.left = `${5}px`;
    else this.select_container.style.right = `${5}px`;
  }
};
__decorateClass([
  propertyDataSource({ type: String })
], CollabSelectOneWithDescription100554.prototype, "hint", 2);
__decorateClass([
  property({ type: Boolean })
], CollabSelectOneWithDescription100554.prototype, "required", 2);
__decorateClass([
  property({ type: Boolean })
], CollabSelectOneWithDescription100554.prototype, "disabled", 2);
__decorateClass([
  propertyCompositeDataSource({ type: String })
], CollabSelectOneWithDescription100554.prototype, "label", 2);
__decorateClass([
  propertyDataSource()
], CollabSelectOneWithDescription100554.prototype, "options", 2);
__decorateClass([
  propertyDataSource()
], CollabSelectOneWithDescription100554.prototype, "selectedvalue", 2);
__decorateClass([
  query(".select_container")
], CollabSelectOneWithDescription100554.prototype, "select_container", 2);
__decorateClass([
  query(".select_toogle")
], CollabSelectOneWithDescription100554.prototype, "select_toogle", 2);
__decorateClass([
  query(".desc_container")
], CollabSelectOneWithDescription100554.prototype, "desc_container", 2);
__decorateClass([
  queryAll("ul > li")
], CollabSelectOneWithDescription100554.prototype, "optionItems", 2);
CollabSelectOneWithDescription100554 = __decorateClass([
  customElement("collab-select-one-with-description-100554")
], CollabSelectOneWithDescription100554);
export {
  CollabSelectOneWithDescription100554,
  initCollabSelectOneWithDescription
};
