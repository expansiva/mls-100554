/// <mls fileReference="_100554_/l2/serviceHistories.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ServiceHistories100554_1;
import { html } from 'lit';
import { customElement, query, property, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import '/_102027_/l2/collabMonacoEditor.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    noHistoriesSelected: 'Nenhum historico selecionado',
};
const message_en = {
    loading: 'Loading...',
    noHistoriesSelected: 'No histories selected',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceHistories100554 = ServiceHistories100554_1 = class ServiceHistories100554 extends ServiceBase {
    constructor() {
        super();
        this.msg = messages['en'];
        this.msize = '';
        this.lastModeEditor = 'inline';
        this.details = {
            icon: '&#xf15c',
            state: 'background',
            tooltip: 'Histories',
            visible: false,
            position: "all",
            widget: '_100554_serviceHistories',
            level: [2, 5]
        };
        this.menu = {
            title: 'Histories',
            main: {
                opHistories: 'Start',
                opSide: 'Side by Side',
                opOnlyOne: 'Inline Diff'
            },
            tabs: undefined,
            tools: {},
            mainDefault: 'opHistories',
            onClickMain: this.onClickMain.bind(this),
        };
        this.hashOriginal = "";
        this.hashModified = "";
        this.histories = {};
        mls.events.addEventListener([2, 5], ['HistoriesSelected'], (ev) => this.onSelectHistories(ev));
        mls.events.addEventListener([2], ['ToolBarSelected'], (ev) => { this.onToolbarSelected(ev); });
    }
    createRenderRoot() {
        return this;
    }
    onServiceClick(visible, reinit, el) {
        this._onServiceClick(visible, reinit, el);
    }
    onClickMain(op) {
        if (op === 'opHistories')
            this.showStart();
        else if (op === 'opSide')
            this.changeEditorMode('sideBySide');
        else if (op === 'opOnlyOne')
            this.changeEditorMode('inline');
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    get confE() { return `l${this.level}_${this.position}_histories`; }
    showStart() {
        return true;
    }
    onToolbarSelected(ev) {
        if (!ev || !ev.desc)
            return;
        const params = ev.desc ? JSON.parse(ev.desc) : {};
        const item = this.serviceItemNav;
        if (!item)
            return;
        if (!['_100529_service_Source'].includes(params.to) && this.visible === 'true' && this.position !== params.position)
            this.showNav2Item(false);
    }
    async onSelectHistories(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.position === this.position)
            return;
        if (!this.serviceItemNav)
            return;
        this.loading = true;
        this.showNav2Item(true);
        this.openMe();
        const editorType = {
            '.ts': 'typescript',
            '.test.ts': 'typescript',
            '.html': 'html',
            '.less': 'less',
        };
        if (params.action) {
            this.setInitialHistories('loading...', 'loading...', 'typescript');
        }
        else {
            const key = mls.stor.getKeyToFiles(params.project, params.level, params.shortName, params.folder, params.extension);
            const storFile = mls.stor.files[key];
            if (!storFile) {
                this.loading = false;
                return;
            }
            this.fileInfo = storFile;
            this.hashModified = params.hashModified;
            this.hashOriginal = params.hashOriginal;
            let src2 = '';
            if (this.hashModified === 'local') {
                const info = this.fileInfo.getValueInfo ? await this.fileInfo.getValueInfo() : undefined;
                src2 = info && info.content ? info.content : (await this.fileInfo.getContent());
            }
            else {
                src2 = this.hashModified ? await this.getHistories(this.hashModified) : '';
            }
            const src1 = this.hashOriginal ? await this.getHistories(this.hashOriginal) : '';
            this.setInitialHistories(src1, src2, editorType[params.extension]);
        }
        this.updateEditor();
        this.setMsizeEditor();
        this.loading = false;
    }
    changeEditorMode(mode) {
        this.lastModeEditor = mode;
        this.updateEditor();
        if (this.menu.closeMenu)
            this.menu.closeMenu();
        return true;
    }
    async getHistories(hash) {
        if (this.histories[hash])
            return this.histories[hash];
        if (!this.fileInfo)
            return '';
        const content = await this.fileInfo.getHistoryContent(hash);
        if (content)
            this.histories[hash] = content;
        return this.histories[hash];
    }
    setInitialHistories(srcOriginal, srcModified, language) {
        const modelOriginal = this.createOrGetModel(language, srcOriginal, 'original');
        const modelModified = this.createOrGetModel(language, srcModified, 'modified');
        if (!this._ed1)
            return;
        this._ed1.updateOptions({ readOnly: true });
        this._ed1.setModel({
            original: modelOriginal,
            modified: modelModified,
        });
    }
    createOrGetModel(editorType, src, tp) {
        const uri = this.getUri(`${this.constructor.name}_${this.position}_${tp}`);
        let model1 = monaco.editor.getModel(uri);
        if (!model1) {
            model1 = monaco.editor.createModel(src, editorType, uri);
        }
        return model1;
    }
    getUri(shortFN) {
        ServiceHistories100554_1.modelCount = ServiceHistories100554_1.modelCount + 1 || 1;
        return monaco.Uri.parse(`file://server/${shortFN}_${ServiceHistories100554_1.modelCount}.ts`);
    }
    createEditor() {
        if (!this.c2 || this._ed1)
            return;
        const opt = {
            automaticLayout: true,
            renderSideBySide: this.lastModeEditor === 'sideBySide'
        };
        this._ed1 = monaco.editor.createDiffEditor(this.c2, opt);
        this.c2['mlsEditor'] = this._ed1;
        this.setMsizeEditor();
    }
    updateEditor() {
        if (!this._ed1)
            return;
        this._ed1.updateOptions({
            renderSideBySide: this.lastModeEditor === 'sideBySide'
        });
        const originalEditor = this._ed1.getOriginalEditor();
        const modifiedEditor = this._ed1.getModifiedEditor();
        originalEditor.setPosition({ lineNumber: 1, column: 1 });
        modifiedEditor.setPosition({ lineNumber: 1, column: 1 });
        originalEditor.revealLine(1);
        modifiedEditor.revealLine(1);
    }
    setMsizeEditor() {
        if (!this.visible)
            return;
        this.c2?.setAttribute('msize', this.msize);
    }
    async _onServiceClick(visible, reinit, el) {
        if (visible) {
            this.createEditor();
            this.setInitialHistories(this.msg.loading, this.msg.loading, 'text');
            if (!this.fileInfo)
                this.setInitialHistories(this.msg.noHistoriesSelected, this.msg.noHistoriesSelected, 'text');
            setTimeout(() => {
                if (el && typeof el.layout === 'function')
                    el.layout();
            }, 100);
        }
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            this.setMsizeEditor();
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <collab-monaco-editor-102027 ismls2="true"></collab-monaco-editor-102027>
        `;
    }
};
__decorate([
    property({ type: String })
], ServiceHistories100554.prototype, "msize", void 0);
__decorate([
    state()
], ServiceHistories100554.prototype, "lastModeEditor", void 0);
__decorate([
    query('collab-monaco-editor-102027')
], ServiceHistories100554.prototype, "c2", void 0);
ServiceHistories100554 = ServiceHistories100554_1 = __decorate([
    customElement('service-histories-100554')
], ServiceHistories100554);
export { ServiceHistories100554 };
