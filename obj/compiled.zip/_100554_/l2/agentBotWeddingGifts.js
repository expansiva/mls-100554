/// <mls fileReference="_100554_/l2/agentBotWeddingGifts.ts" enhancement="_blank" />
import { msgAddOrUpdateThreadBot } from '/_102036_/l2/shared/api.js';
export function createAgent() {
    return {
        agentName: "agentBotWeddingGifts",
        agentProject: 100554,
        agentFolder: "",
        agentDescription: "Agent Bot, for gifts management",
        visibility: "public",
        installBot,
        beforeBot,
        beforePromptImplicit,
        // beforePromptStep,
        afterPromptStep
    };
}
import { notifyThreadChange } from "/_102027_/l2/aiAgentHelper.js";
import { addMessage } from '/_102025_/l2/collabMessagesHelper.js';
const agentName = "agentBotWeddingGifts";
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const prompts = await getPrompts(getPromptMock(), getOriginalRecord());
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: prompts,
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `Test 1`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    let status = 'completed';
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [updateStatus];
}
const installBot = async (context) => {
    const llmPrompt = system1
        .replace('{{userPrompt}}', '')
        .replace('{{botRecord}}', '');
    const rc = await msgAddOrUpdateThreadBot({
        botId: agentName,
        llmPrompt,
        status: "active",
        threadId: context.message.threadId,
        userId: context.message.senderId,
        config: undefined
    });
    if (rc.success) {
        await addMessage(context.message.threadId, `Bot ${agentName} instaled OK!`);
        notifyThreadChange(rc.response.thread);
        return true;
    }
    ;
    console.error("error on install bot", rc);
    return false;
};
async function beforeBot(context, msg, toolsBeforeSendMessage) {
    // prepare config to send in 
    const contextToBot = {};
    return contextToBot;
}
async function getPrompts(userPrompt, botRecord) {
    if (!userPrompt)
        throw new Error(`Erro [${agentName}] getPrompts: invalid userPrompt`);
    const prompts = system1
        .replace('{{userPrompt}}', userPrompt)
        .replace('{{botRecord}}', botRecord);
    return prompts;
}
function getPromptMock() {
    return "me retorne a lista dos presentes";
}
function getOriginalRecord() {
    const gifts = [
        {
            "name": "geladeira",
            "originalNames": [
                "geladeira"
            ],
            "status": "available"
        },
        {
            "name": "chaleira elétrica",
            "originalNames": [
                "chaleira elétrica"
            ],
            "status": "available"
        },
        {
            "name": "filtro de barro",
            "originalNames": [
                "filtro de barro"
            ],
            "status": "reserved",
            "reservedBy": "Wagner",
            "date": "2025-07-19"
        }
    ];
    return JSON.stringify(gifts);
}
const system1 = `
<!-- modelType: mini -->
<!-- modelContext: CollabMessageBot -->
<!-- trigger: [{"type":"onNewMessage", "conditions":[] }] -->
<!-- threadFeature: summary -->
<!-- threadPermissionLevel: all -->

You are an assistant responsible for managing a wedding gift list.

Each message is a user input from the Collab.Messages thread.  
Your job is to analyze the message, identify if it refers to the wedding list, and take appropriate action.

If the message is NOT related to the wedding gift list, simply return the previous context (unchanged) in the "flexible" format.

If the message is a gift suggestion, add it to the list.

If the message indicates a user will buy or reserve a gift, mark the item accordingly with the user's name or ID.

If the message requests to view the current gift list or a summary of it, return it using the "result" format (in the user’s language if possible).

You should normalize gift names to group similar items (e.g., "coffee maker" and "espresso machine" may refer to the same concept).

Include the user language (e.g., \`en\`, \`pt\`, \`es\`) in the summary result for multilingual support.

---

## Context
### Old WeddingGifts
\`\`\`json
{{botRecord}}
\`\`\`

## Output Format (JSON)

`;
//#endregion
