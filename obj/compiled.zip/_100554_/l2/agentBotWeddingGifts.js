/// <mls fileReference="_100554_/l2/agentBotWeddingGifts.ts" enhancement="_blank" />
import { svg_agent } from '/_100554_/l2/aiAgentBase.js';
import { getPromptByHtml } from '/_100554_/l2/aiPrompts.js';
import '/_100554_/l2/widgetQuestionsForClarification.js';
import { getNextInProgressStepByAgentName, notifyTaskChange, notifyThreadChange, updateStepStatus, } from "/_100554_/l2/aiAgentHelper.js";
import { addMessage } from '/_102025_/l2/collabMessagesHelper.js';
import { startNewAiTask, executeNextStep, } from "/_100554_/l2/aiAgentOrchestration.js";
const agentName = "agentBotWeddingGifts";
const project = 100554;
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent Bot, for gifts management",
        visibility: "public",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        },
        async installBot(context) {
            return _installBot(context);
        },
        async beforeBot(context, msg, toolsBeforeSendMessage) {
            return _beforeBot(context, msg, toolsBeforeSendMessage);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning...";
    if (!context || !context.message)
        throw new Error("Invalid context");
    if (context.task)
        throw new Error("this agent cannot execute with anothers agentes");
    const inputs = await getPrompts(getPromptMock(), getOriginalRecord());
    await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
    return;
};
const _afterPrompt = async (context) => {
    if (!context || !context.message || !context.task)
        throw new Error("Invalid context");
    const step = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step)
        throw new Error(`[${agentName}] afterPrompt: No in progress interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    notifyTaskChange(context);
    await executeNextStep(context);
};
const _installBot = async (context) => {
    const inputs = await getPromptByHtml({ project, shortName: agentName, folder: '', data: undefined });
    const llmPrompt = inputs
        .filter(i => i.type === "system")
        .map(i => i.content)
        .join("\n\n");
    const rc = await mls.api.msgAddOrUpdateThreadBot({
        botId: agentName,
        llmPrompt,
        status: "active",
        threadId: context.message.threadId,
        userId: context.message.senderId,
        config: undefined
    });
    if (rc.statusCode === 200) {
        await addMessage(context.message.threadId, `Bot ${agentName} instaled OK!`);
        notifyThreadChange(rc.thread);
        return true;
    }
    ;
    console.error("error on install bot", rc);
    return false;
};
async function _beforeBot(context, msg, toolsBeforeSendMessage) {
    // prepare config to send in 
    const contextToBot = {};
    return contextToBot;
}
async function getPrompts(userPrompt, botRecord) {
    if (!userPrompt)
        throw new Error(`Erro [${agentName}] getPrompts: invalid userPrompt`);
    const dataForReplace = {
        userPrompt,
        botRecord
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data: dataForReplace });
    return prompts;
}
function getPromptMock() {
    return "me retorne a lista dos presentes";
}
function getOriginalRecord() {
    const gifts = [
        {
            "name": "geladeira",
            "originalNames": [
                "geladeira"
            ],
            "status": "available"
        },
        {
            "name": "chaleira elétrica",
            "originalNames": [
                "chaleira elétrica"
            ],
            "status": "available"
        },
        {
            "name": "filtro de barro",
            "originalNames": [
                "filtro de barro"
            ],
            "status": "reserved",
            "reservedBy": "Wagner",
            "date": "2025-07-19"
        }
    ];
    return JSON.stringify(gifts);
}
