/// <mls shortName="agentProjectSearch" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { svg_agent } from '/_100554_/l2/aiAgentBase.js';
import { getPromptByHtml } from '/_100554_/l2/aiPrompts.js';
import { getAgentStepByAgentName, notifyTaskChange, updateStepStatus, getNextStepIdAvaliable, } from "/_100554_/l2/aiAgentHelper.js";
import { startNewAiTask, executeNextStep, addNewStep } from "/_100554_/l2/aiAgentOrchestration.js";
const agentName = "agentProjectSearch";
const project = 100554; //Number(localStorage.getItem("l5-last-project") || "1");
export function createAgent() {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "Agent for create a new Module",
        visibility: "public",
        async beforePrompt(context) {
            return _beforePrompt(context);
        },
        async afterPrompt(context) {
            return _afterPrompt(context);
        }
    };
}
const _beforePrompt = async (context) => {
    const taskTitle = "Planning...";
    if (!context || !context.message || context.task)
        throw new Error("Invalid context");
    const inputs = await getPrompts(context.message.content);
    await startNewAiTask(agentName, taskTitle, context.message.content, context.message.threadId, context.message.senderId, inputs, context, _afterPrompt);
    return;
};
const _afterPrompt = async (context) => {
    if (!context || !context.task)
        throw new Error(`[${agentName}] [_afterPrompt] Invalid context`);
    const agentStep = getAgentStepByAgentName(context.task, agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agentName}] [_afterPrompt] no agent found`);
    context = await updateStepStatus(context, agentStep.stepId, "completed");
    if (!context.task)
        throw new Error(`[${agentName}] [_afterPrompt] Invalid context task`);
    const newStep = {
        type: 'agent',
        agentName: 'agentProjectSearch2',
        prompt: '...',
        status: 'pending',
        stepId: getNextStepIdAvaliable(context.task),
        interaction: null,
        nextSteps: null,
        rags: null
    };
    // complete this step (payload) and push another step
    await addNewStep(context, agentStep.stepId, [newStep], "Search");
    notifyTaskChange(context);
    await executeNextStep(context);
};
async function getPrompts(userPrompt) {
    if (!userPrompt)
        throw new Error(`Erro [${agentName}] getPrompts: invalid userPrompt`);
    if (userPrompt.startsWith("@@"))
        userPrompt = userPrompt.replace(/^@@\S+\s*/, ""); // remove '@@xxx ' , first word
    const data = {
        userPrompt
    };
    const prompts = await getPromptByHtml({ project, shortName: agentName, folder: '', data });
    return prompts;
}
export function getPayload1(context) {
    if (!context || !context.task)
        throw new Error(`[${agentName}] [getPayload] Invalid context`);
    const agentStep = getAgentStepByAgentName(context.task, agentName); // Only one agent execution must exist in this task
    if (!agentStep)
        throw new Error(`[${agentName}] [getPayload] no agent found`);
    // get result
    const resultStep = agentStep.interaction?.payload?.[0];
    if (!resultStep || resultStep.type !== "flexible" || !resultStep.result)
        throw new Error(`[${agentName}] [getPayload] No step flexible found for this agent.`);
    let payload1 = resultStep.result;
    if (typeof payload1 === "string")
        payload1 = JSON.parse(payload1);
    // get userPrompt
    payload1.userPrompt = agentStep?.interaction?.input.find((input) => input.type === 'human')?.content || '';
    if (payload1.embedding) {
        payload1.embeddingVector = mls.l4.decompressVector(payload1.embedding);
    }
    return payload1;
}
