/// <mls fileReference="_100554_/l2/modules.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { getInstanceByFile, openService, saveOpenedFile, getLastModule, setLastModule, getProjectConfig } from '/_102027_/l2/libCommom.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Módulos Instalados',
    titleAdd: 'Novo Módulo',
    addModule: 'Adicionar Módulo',
    back: 'Voltar',
    loading: 'Carregando...',
    empty: 'Nenhum módulo instalado',
    files: 'arquivos',
    moduleName: 'Nome do Módulo',
    moduleNamePlaceholder: 'Digite o nome do módulo',
    category: 'Categoria',
    categoryPlaceholder: 'Digite a categoria',
    save: 'Salvar Módulo',
};
const message_en = {
    title: 'Installed Modules',
    titleAdd: 'New Module',
    addModule: 'Add Module',
    back: 'Back',
    loading: 'Loading...',
    empty: 'No modules installed',
    files: 'files',
    moduleName: 'Module Name',
    moduleNamePlaceholder: 'Enter module name',
    category: 'Category',
    categoryPlaceholder: 'Enter category',
    save: 'Save Module',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
let Modules = class Modules extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`modules-100554 {
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-12);
}
modules-100554 .container {
  padding: var(--space-16);
}
modules-100554 .header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: var(--space-24);
  gap: var(--space-16);
}
modules-100554 .title {
  font-size: var(--font-size-20);
  font-weight: var(--font-weight-bold);
  color: var(--text-default);
  margin: 0;
}
modules-100554 .btn-add {
  display: flex;
  align-items: center;
  gap: var(--space-8);
  padding: var(--space-8) var(--space-16);
  background-color: var(--button-primary-bg);
  color: var(--button-primary-text);
  border: none;
  border-radius: 4px;
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
  cursor: pointer;
  transition: background-color var(--transition-normal);
}
modules-100554 .btn-add:hover {
  background-color: var(--button-primary-bg-hover);
}
modules-100554 .btn-back {
  display: flex;
  align-items: center;
  gap: var(--space-8);
  padding: var(--space-8) var(--space-16);
  background-color: var(--surface-alt-bg);
  color: var(--text-default);
  border: none;
  border-radius: 4px;
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
  cursor: pointer;
  transition: background-color var(--transition-normal);
}
modules-100554 .btn-back:hover {
  background-color: var(--surface-alt-bg-hover);
}
modules-100554 .icon {
  font-size: var(--font-size-16);
}
modules-100554 .loading {
  text-align: center;
  padding: var(--space-32);
  color: var(--text-muted);
}
modules-100554 .empty {
  text-align: center;
  padding: var(--space-32);
  color: var(--text-muted);
  background-color: var(--surface-alt-bg);
  border-radius: 4px;
}
modules-100554 .modules-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
}
modules-100554 .module-card {
  display: flex;
  cursor: pointer;
  justify-content: space-between;
  align-items: center;
  padding: var(--space-16);
  background-color: var(--surface-alt-bg);
  border-radius: 4px;
  border-left: 3px solid var(--selected-border);
  transition: background-color var(--transition-normal);
}
modules-100554 .module-card:hover {
  background-color: var(--surface-alt-bg);
}
modules-100554 .module-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
modules-100554 .module-name {
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  color: var(--text-default);
}
modules-100554 .module-category {
  font-size: var(--font-size-12);
  color: var(--text-muted);
}
modules-100554 .module-files {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
}
modules-100554 .files-count {
  font-size: var(--font-size-20);
  font-weight: var(--font-weight-bold);
  color: var(--link-text);
}
modules-100554 .files-label {
  font-size: var(--font-size-12);
  color: var(--text-muted);
}
modules-100554 .form {
  display: flex;
  flex-direction: column;
  gap: var(--space-16);
}
modules-100554 .form-group {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
}
modules-100554 .label {
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
  color: var(--text-default);
}
modules-100554 .input {
  padding: var(--space-8) var(--space-16);
  font-size: var(--font-size-16);
  border: 1px solid var(--border-default);
  border-radius: 4px;
  background-color: var(--surface-bg);
  color: var(--text-default);
  transition: border-color var(--transition-normal);
}
modules-100554 .input:focus {
  outline: none;
  border-color: var(--selected-border);
}
modules-100554 .input::placeholder {
  color: var(--text-muted-disabled);
}
modules-100554 .btn-save {
  padding: var(--space-16);
  background-color: var(--status-success-text);
  color: var(--button-primary-text);
  border: none;
  border-radius: 4px;
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  cursor: pointer;
  transition: background-color var(--transition-normal);
  margin-top: var(--space-8);
}
modules-100554 .btn-save:hover:not(:disabled) {
  background-color: var(--status-success-text-hover);
}
modules-100554 .btn-save:disabled {
  background-color: var(--status-success-text-disabled);
  cursor: not-allowed;
}
`);
        this.msg = messages['en'];
        this.viewMode = 'list';
        this.modules = [];
        this.loading = false;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.loadModule();
        this.fetchModules();
    }
    async fetchModules() {
        this.loading = true;
        try {
            this.modules = await this.getModulesByActualProject() || [];
        }
        catch (error) {
            console.error('Erro ao buscar módulos:', error);
            this.modules = [
                { name: 'Dashboard', category: 'Core', totFiles: 12 },
                { name: 'Authentication', category: 'Security', totFiles: 8 },
                { name: 'Reports', category: 'Analytics', totFiles: 15 },
            ];
        }
        finally {
            this.loading = false;
        }
    }
    getLocal() {
        const modulesLS = getLastModule();
        if (!modulesLS || !mls.actualProject)
            return '';
        return modulesLS[mls.actualProject];
    }
    loadModule() {
        const mm = this.getLocal();
        if (!mm)
            return;
        mls.setActualModule(mm);
    }
    async getModulesByActualProject() {
        try {
            const key = mls.stor.getKeyToFiles(mls.actualProject, 2, 'project', '', '.ts');
            const f = mls.stor.files[key];
            if (!f)
                throw new Error('[setMyModules] Not found storfile');
            const { project } = f;
            const mm = await getProjectConfig(project);
            if (!mm || !mm.modules)
                throw new Error('[setMyModules] Not found modules');
            const ar = [];
            const files = Object.keys(mls.stor.files).reduce((acc, key) => {
                const f = mls.stor.files[key];
                if (f && f.extension === '.ts')
                    acc.push(f);
                return acc;
            }, []);
            mm.modules.forEach((m) => {
                const tot = files.filter((f) => f.folder === m.name || (f.folder === '' && m.name.toLowerCase() === 'default')).length;
                ar.push({
                    name: m.name,
                    category: 'core',
                    totFiles: tot
                });
            });
            const modules = this.moveActualToFirst(ar, mls.actualModule || '');
            return modules;
        }
        catch (e) {
        }
    }
    moveActualToFirst(modules, moduleName) {
        const found = modules.find(m => m.name === moduleName);
        if (!found)
            return modules;
        const others = modules.filter(m => m.name !== moduleName);
        return [found, ...others];
    }
    ;
    handleAddClick() {
        this.viewMode = 'add';
    }
    handleBackClick() {
        this.viewMode = 'list';
    }
    selectThis(module) {
        mls.setActualModule(module.name);
        this.setLocal(module.name);
        this.goToL4();
        this.requestUpdate();
    }
    setLocal(moduleName) {
        if (!mls.actualProject)
            return;
        setLastModule(mls.actualProject, moduleName);
    }
    async goToL4() {
        try {
            if (mls.actualModule?.toLocaleLowerCase() !== 'default') {
                const key = mls.stor.getKeyToFiles(mls.actualProject, 2, 'module', mls.actualModule || '', '.ts');
                const f = mls.stor.files[key];
                if (f) {
                    const mm = await getInstanceByFile(f);
                    if (!mm || !mm.moduleConfig)
                        throw new Error('[goToL4] Not found moduleConfig');
                    const folder = mls.actualModule || '';
                    const project = mls.actualProject || 0;
                    const shortName = mm.moduleConfig.initialPage;
                    const fullName = folder ? `_${project}_${folder}/${shortName}` : `_${project}_${shortName}`;
                    mls.actual[4].setFullName(fullName);
                    mls.actual[7].setFullName(fullName);
                    saveOpenedFile(project, 4, fullName);
                    saveOpenedFile(project, 7, fullName);
                }
            }
            openService('', 'left', 4, { 'tab': 'navigation' });
        }
        catch (e) {
            openService('', 'left', 4);
        }
    }
    renderListView() {
        return html `
            <div class="container">
                <div class="header">
                    <h2 class="title">${this.msg.title}</h2>
                    <button class="btn-add" @click=${this.handleAddClick}>
                        <span class="icon">+</span>
                        ${this.msg.addModule}
                    </button>
                </div>

                ${this.loading
            ? html `<div class="loading">${this.msg.loading}</div>`
            : html `
                        <div class="modules-list">
                            ${this.modules.length === 0
                ? html `<div class="empty">${this.msg.empty}</div>`
                : this.modules.map(module => html `
                                    <div class="module-card" @click=${() => this.selectThis(module)}>
                                        <div class="module-info">
                                            <span class="module-name">${module.name}</span>
                                            <span class="module-category">${module.category}</span>
                                        </div>
                                        <div class="module-files">
                                            <span class="files-count">${module.totFiles}</span>
                                            <span class="files-label">${this.msg.files}</span>
                                        </div>
                                    </div>
                                `)}
                        </div>
                    `}
            </div>
        `;
    }
    renderAddView() {
        return html `
            <div class="container">
                <div class="header">
                    <button class="btn-back" @click=${this.handleBackClick}>
                        <span class="icon">←</span>
                        ${this.msg.back}
                    </button>
                    <h2 class="title">${this.msg.titleAdd}</h2>
                </div>
                    In develpoment
                </div>
            </div>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.viewMode === 'list'
            ? this.renderListView()
            : this.renderAddView();
    }
};
__decorate([
    state()
], Modules.prototype, "viewMode", void 0);
__decorate([
    state()
], Modules.prototype, "modules", void 0);
__decorate([
    state()
], Modules.prototype, "loading", void 0);
Modules = __decorate([
    customElement('modules-100554')
], Modules);
export { Modules };
