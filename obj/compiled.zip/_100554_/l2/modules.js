/// <mls fileReference="_100554_/l2/modules.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { getInstanceByFile, openService, saveOpenedFile, getLastModule, setLastModule, getProjectConfig } from '/_100554_/l2/libCommom.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import '/_100554_pluginDeleteModule';
let Modules100554 = class Modules100554 extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`modules-100554{display:block;padding:2rem;color:#fff;font-family:sans-serif}modules-100554 .header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:2rem;color:var(--text-primary-color)}modules-100554 #module-filter{width:60%}modules-100554 .module-card.selected{border:2px solid #007bff;background:#262626}modules-100554 h3,modules-100554 h2{color:var(--text-primary-color)}modules-100554 .modules-list{display:grid;grid-template-columns:repeat(auto-fill, minmax(250px, 1fr));gap:1rem}modules-100554 .module-card{background:#1e1e1e;border-radius:12px;padding:1rem;box-shadow:0 4px 10px rgba(0,0,0,0.3);transition:transform .2s}modules-100554 .module-card:hover{transform:scale(1.02)}modules-100554 .card-content{display:flex;flex-direction:column;gap:.5rem}modules-100554 .module-title{font-size:1.2rem;color:#fff}modules-100554 .module-category,modules-100554 .module-uses{font-size:.9rem;color:#ccc}modules-100554 .actions{display:flex;justify-content:space-between;gap:.5rem;margin-top:1rem}modules-100554 .actions a{flex:1;text-align:center;text-decoration:none;background:#2a2a2a;color:white;padding:.5rem;border-radius:6px;transition:background .2s}modules-100554 .actions a:hover{background:#444}modules-100554 .module-details{padding:2rem;margin:2rem auto;color:#000;background:#fff;border-radius:12px;box-shadow:0 0 15px rgba(0,0,0,0.5)}modules-100554 .back-button{background:none;border:none;font-size:1rem;cursor:pointer;margin-bottom:1rem;color:#007bff}modules-100554 .back-button:hover{text-decoration:underline}modules-100554 input{width:100%;padding:.5rem;border:1px solid #ccc;border-radius:4px}modules-100554 button:not(.back-button){background:#007bff;color:#fff;border:none;padding:.5rem 1rem;margin-top:.5rem;cursor:pointer;border-radius:4px}modules-100554 button:not(.back-button):hover{background:#0056b3}`);
    }
    currentView = 'list';
    error = '';
    archiveConfirmationText = '';
    selectedModule;
    myModules = [];
    //------------COMPONENT---------------
    firstUpdated() {
        this.loadModule();
        this.setMyModules();
    }
    render() {
        switch (this.currentView) {
            case ('list'): return this.renderModuleList();
            case ('details'): return this.renderModuleDetails();
            case ('error'): return this.renderError();
            case ('add'): return this.renderAdd();
        }
    }
    renderHeader() {
        return html `
      <div class="header">
        <h2>Select a Module</h2>
        <input type="text" autocomplete="off" placeholder="Filter modules..." id="module-filter" @input="${this.filterLiChange}">
        <button style="margin:0px; width:150px;" @click=${() => { this.goTo('add'); }}><svg style="width:12px; fill:#fff" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg></button>
      </div> 
    `;
    }
    renderError() {
        return html `
      <div class="header">
        <h2>Select a Module</h2>
      </div> 
      <h3 style="color:red">${this.error}</h3> 
      `;
    }
    renderAdd() {
        return html `
      <button style="margin:0px; width:150px;" @click=${() => { this.goTo('list'); }}>cancel</button>
      <div class="header">
        <h2>In developed</h2>
      </div> 
       
      `;
    }
    renderModuleList() {
        if (!this.myModules || this.myModules.length <= 0) {
            return html `
      ${this.renderHeader()}
      <div class="modules-list">
        <h3>Any modules found!</h3>
      </div>
      `;
        }
        return html `
      ${this.renderHeader()}

      <div class="modules-list">
        ${this.myModules.map(mm => html `
          <div class="module-card ${mls.actualModule === mm.name ? 'selected' : ''} " .filter="${mm.name.toLocaleLowerCase()}">
            <div class="card-content">
              <div class="module-title">${mm.name}</div>
              <div class="module-category">Category: ${mm.category}</div>
              <div class="module-uses">Used in ${mm.totFiles} files</div>
              <div class="actions">
                <a href="#" @click=${(e) => this.selectThis(e, mm)} class="btnSelect">${mls.actualModule === mm.name ? 'Selected' : 'Select'}</a>
                <a href="#" @click=${(e) => this.openDetails(e, mm)}>⋯</a>
              </div>
            </div>
          </div>
        `)}
      </div>
    `;
    }
    renderModuleDetails() {
        return html `
        <div class="module-details">
        <button class="back-button" @click=${this.goBack}>← Back</button>
        <div>
          <plugin-delete-module-100554 moduleName=${this.selectedModule?.name} project=${mls.actualProject}></plugin-delete-module-100554>
        </div>
      </div>
    `;
    }
    //--------IMPLEMENTATION-------------
    KeyItem = '_100554_modules';
    selectThis(ev, mm) {
        ev.preventDefault();
        mls.setActualModule(mm.name);
        this.setLocal(mm.name);
        this.goToL4();
        this.requestUpdate();
    }
    loadModule() {
        const mm = this.getLocal();
        if (!mm)
            return;
        mls.setActualModule(mm);
    }
    setLocal(mm) {
        if (!mls.actualProject)
            return;
        setLastModule(mls.actualProject, mm);
    }
    getLocal() {
        const modulesLS = getLastModule();
        if (!modulesLS || !mls.actualProject)
            return '';
        return modulesLS[mls.actualProject];
    }
    openDetails(ev, mm) {
        ev.preventDefault();
        this.selectedModule = mm;
        this.currentView = 'details';
        this.archiveConfirmationText = '';
    }
    goBack() {
        this.currentView = 'list';
        this.setMyModules();
        this.selectedModule = undefined;
        this.archiveConfirmationText = '';
    }
    goTo(scenary) {
        this.currentView = scenary;
    }
    async setMyModules() {
        try {
            const key = mls.stor.getKeyToFiles(mls.actualProject, 2, 'project', '', '.ts');
            const f = mls.stor.files[key];
            if (!f)
                throw new Error('[setMyModules] Not found storfile');
            const { project } = f;
            const mm = await getProjectConfig(project);
            if (!mm || !mm.modules)
                throw new Error('[setMyModules] Not found modules');
            const ar = [];
            const files = Object.keys(mls.stor.files).reduce((acc, key) => {
                const f = mls.stor.files[key];
                if (f && f.extension === '.ts')
                    acc.push(f);
                return acc;
            }, []);
            mm.modules.forEach((m) => {
                const tot = files.filter((f) => f.folder === m.name || (f.folder === '' && m.name.toLowerCase() === 'default')).length;
                ar.push({
                    name: m.name,
                    category: 'core',
                    totFiles: tot
                });
            });
            this.myModules = this.moveToFirst(ar, mls.actualModule || '');
        }
        catch (e) {
            this.error = e.message;
            this.currentView = 'error';
        }
    }
    timeFilterChange = 0;
    filterLiChange(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        clearTimeout(this.timeFilterChange);
        this.timeFilterChange = setTimeout(() => {
            const all = this.querySelectorAll('.module-card');
            all.forEach((card) => {
                const name = card.filter ? card.filter : '******';
                const inp = el.value.toLocaleLowerCase();
                if (name.indexOf(inp) >= 0) {
                    card.style.display = '';
                }
                else {
                    card.style.display = 'none';
                }
            });
        }, 500);
    }
    moveToFirst(modules, moduleName) {
        const found = modules.find(m => m.name === moduleName);
        if (!found)
            return modules;
        const others = modules.filter(m => m.name !== moduleName);
        return [found, ...others];
    }
    ;
    async goToL4() {
        try {
            if (mls.actualModule?.toLocaleLowerCase() !== 'default') {
                const key = mls.stor.getKeyToFiles(mls.actualProject, 2, 'module', mls.actualModule || '', '.ts');
                const f = mls.stor.files[key];
                if (f) {
                    const mm = await getInstanceByFile(f);
                    if (!mm || !mm.moduleConfig)
                        throw new Error('[goToL4] Not found moduleConfig');
                    const folder = mls.actualModule || '';
                    const project = mls.actualProject || 0;
                    const shortName = mm.moduleConfig.initialPage;
                    const fullName = folder ? `_${project}_${folder}/${shortName}` : `_${project}_${shortName}`;
                    mls.actual[4].setFullName(fullName);
                    mls.actual[7].setFullName(fullName);
                    saveOpenedFile(project, 4, fullName);
                    saveOpenedFile(project, 7, fullName);
                }
            }
            openService('_100554_servicePage', 'left', 4, { 'tab': 'navigation' });
        }
        catch (e) {
            openService('_100554_servicePage', 'left', 4);
        }
    }
    mockModules = [
        { name: 'Authentication', category: 'Core', uses: 312 },
        { name: 'Payments', category: 'Integration', uses: 159 },
        { name: 'Dashboard', category: 'UI', uses: 512 },
        { name: 'Notifications', category: 'Service', uses: 98 },
    ];
};
__decorate([
    state()
], Modules100554.prototype, "currentView", void 0);
__decorate([
    state()
], Modules100554.prototype, "error", void 0);
__decorate([
    state()
], Modules100554.prototype, "archiveConfirmationText", void 0);
__decorate([
    state()
], Modules100554.prototype, "selectedModule", void 0);
__decorate([
    state()
], Modules100554.prototype, "myModules", void 0);
Modules100554 = __decorate([
    customElement('modules-100554')
], Modules100554);
export { Modules100554 };
