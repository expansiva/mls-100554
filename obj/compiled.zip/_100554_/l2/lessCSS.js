import { LessAst } from "/_100554_/l2/lessAST.js";
import { setState, getState, initState } from "/_100554_/l2/collabState.js";
const _editor = /* @__PURE__ */ Symbol("ignoredProperty");
_editor;
class LessCSS {
  constructor(url, editor, position = "left") {
    this.position = "left";
    this._url = "";
    this.lessAST = new LessAst(url, editor);
    this[_editor] = editor;
    this.selector = "";
    this.position = position;
    this._url = url;
    this.initStateIfNeeded();
    const cssDeclaration = document.createElement("div").style;
    this.styles = new Proxy(cssDeclaration, {
      get: (target, property) => {
        return this.getProperty(property) ?? target[property];
      },
      set: (target, property, value) => {
        this.setProperty(property, value);
        target[property] = value;
        return true;
      }
    });
  }
  setEditor(editor) {
  }
  /**
   * Sets the current selector for which properties will be applied.
   */
  setSelector(selector) {
    this.selector = selector;
  }
  /**
   * Retrieves a specific CSS property value for the current selector from the AST.
   * @param property The CSS property to retrieve
   */
  getProperty(property) {
    return this.lessAST.getProperty(this.selector, property);
  }
  /**
   * Sets or updates a CSS property in the AST and source model.
   * @param property The CSS property to set
   * @param value The new value for the property
   */
  setProperty(property, value) {
    this.lessAST.saveProperty(this.selector, property, value);
    this.updateState();
  }
  refresh() {
    if (this[_editor]) {
      this.lessAST = new LessAst(this._url, this[_editor]);
    }
    this.setSelector(this.selector);
  }
  setStateByLine(lineNumber, lineContent, emitter) {
    this.refresh();
    const state = getState(`less.${this.position}`);
    if (!state) return;
    const selector = this.lessAST.findSelectorByLine(lineNumber);
    if (!selector) {
      this.clearState();
      setState(`less.${this.position}.lineContent`, lineContent);
      return;
    }
    this.setSelector(selector);
    const info = this.lessAST.findInfoByLine(selector, lineNumber);
    const obj = {
      selector,
      lineContent,
      emitter,
      lineNumber,
      lessCSS: this
    };
    if (info && info.key) obj.key = info.key;
    if (info && info.value !== void 0) obj.value = info.value;
    setState(`less.${this.position}`, obj);
  }
  clearState() {
    const state = getState(`less.${this.position} `);
    if (!state) return;
    setState(`less.${this.position}.lessCSS`, void 0);
    setState(`less.${this.position}.key`, void 0);
    setState(`less.${this.position}.value`, void 0);
    setState(`less.${this.position}.selector`, void 0);
  }
  updateState() {
    const state = getState(`less.${this.position} `);
    if (!state) return;
    setState(`less.${this.position}.lessCSS`, this);
    setState(`less.${this.position}.lessCSS.styles`, this.styles);
  }
  initStateIfNeeded() {
    const stateLess = getState(`less`);
    if (!stateLess) {
      initState("less", {
        left: {},
        right: {}
      });
    }
    setState(`less.${this.position}`, {
      lessCSS: this,
      emitter: "editor",
      key: void 0,
      value: void 0,
      lineNumber: void 0,
      selector: void 0,
      uri: this._url
    });
  }
}
export {
  LessCSS
};
