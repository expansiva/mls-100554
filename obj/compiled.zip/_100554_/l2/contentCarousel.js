/// <mls fileReference="_100554_/l2/contentCarousel.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let ContentTabs = class ContentTabs extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`content-carousel-100554 {
  position: relative;
  z-index: 1;
  box-shadow: 0px 3px 10px 0px #3f474f26;
  border-radius: 20px;
  padding-inline: 0px;
  padding-block: 24px;
  overflow: hidden;
  display: block;
  width: 98%;
  margin: 0 auto;
}
content-carousel-100554 .group {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: stretch;
  margin: 0px auto;
}
content-carousel-100554 nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin: 0px auto;
  width: 95%;
  border-radius: 20px;
  background: #FFF;
  box-shadow: 0px 3px 10px 0px #3f474f26;
}
content-carousel-100554 .contentTabNavList {
  position: relative;
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: space-between;
  padding: 0px 1rem;
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens {
  overflow-x: auto;
  scrollbar-width: none;
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 1;
  padding-block: 12px;
  padding-inline: 8px;
  margin-left: calc(8px * -1);
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens .tab {
  width: auto;
  flex-shrink: 0;
  position: relative;
  transition: --gradient-ai-color-1 0.3s, --gradient-ai-color-2 0.3s, 0.3s;
  display: inline-flex;
  justify-content: center;
  align-items: center;
  color: #0565C6;
  background: transparent;
  box-shadow: inset 0 0 0 1px #0565C6;
  height: 32px;
  padding-inline: 8px;
  border-radius: 8px;
  font-size: 0.875rem;
  cursor: pointer;
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens .tab:hover {
  color: #0565C6;
  background: #F1F8FE;
  box-shadow: inset 0 0 0 1px #0565C6;
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens .tab[selected] {
  color: #FFF;
  background: #0079F2;
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens-nav {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: nowrap;
  flex-shrink: 0;
  padding-block: 12px;
  height: 100%;
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens-nav button {
  cursor: pointer;
  border-radius: 100%;
  width: 28px;
  height: 28px;
  padding: 0px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  transition: --gradient-ai-color-1 0.3s, --gradient-ai-color-2 0.3s, 0.3s;
  color: #0565C6;
  background: transparent;
  border: 1px solid #0071e1;
  padding-inline: 8px;
  font-size: 0.875rem;
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens-nav button svg {
  width: 15px;
  height: 15px;
  fill: #0071e1;
  display: inline-block;
  flex-shrink: 0;
}
content-carousel-100554 .contentTabNavList .contentTabNavList-itens-nav button:hover {
  color: #0565C6;
  background: #F1F8FE;
  box-shadow: inset 0 0 0 1px #0565C6;
}
content-carousel-100554 .sectionMain {
  display: flex;
  width: 100%;
  position: relative;
  border-radius: var(--radius-sm, 8px);
  overflow: hidden;
}
content-carousel-100554 .sectionMain .content {
  display: block;
  padding: 12px;
  width: 100%;
}
content-carousel-100554 .sectionMain .content:not([active]) {
  display: none;
}
`);
        this.navItems = [];
        this.contentItems = [];
        this.selectedIndex = 0;
    }
    //------------------------------------------
    connectedCallback() {
        super.connectedCallback();
        const div = document.createElement('div');
        div.innerHTML = this.innerHTML;
        this.innerHTML = '';
        this.navItems = Array.from(div.querySelectorAll('nav-item'));
        this.contentItems = Array.from(div.querySelectorAll('content-item'));
    }
    render() {
        return html `
            <div class="group">
                ${this.renderContent()}
                ${this.renderNav()}
            </div>
        `;
    }
    renderNav() {
        if (this.navItems.length === 0)
            return '';
        return html `
        <nav>
            <div class="contentTabNavList">
                <div class="contentTabNavList-itens">
                    ${this.navItems.map((item, i) => html `
                            <nav-item class="tab" ?selected=${this.selectedIndex === i} @click=${() => this.handleSelect(i)} >
                                ${item.innerHTML}
                            </nav-item>
                        `)}
                </div>
                <div class="contentTabNavList-itens-nav">
                    <button @click=${this.handleClickPrevius}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg>
                    </button>
                    <button @click=${this.handleClickNext}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                    </button>
                </div>
            </div>
        </nav>
            
        `;
    }
    renderContent() {
        if (this.contentItems.length === 0)
            return '';
        return html `
        <div class="sectionMain">
        ${this.contentItems.map((content, i) => html `
            <content-item class="content" ?active=${this.selectedIndex === i}>
              ${unsafeHTML(content.innerHTML)}
            </content-item>
          `)}
      </div>
        `;
    }
    //--------------------------------------
    handleSelect(index) {
        this.selectedIndex = index;
    }
    handleClickPrevius() {
        if (this.selectedIndex === 0)
            return;
        this.selectedIndex = this.selectedIndex - 1;
    }
    handleClickNext() {
        if (this.selectedIndex === (this.navItems.length - 1))
            return;
        this.selectedIndex = this.selectedIndex + 1;
    }
};
__decorate([
    property({ type: Number, reflect: true })
], ContentTabs.prototype, "selectedIndex", void 0);
ContentTabs = __decorate([
    customElement('content-carousel-100554')
], ContentTabs);
export { ContentTabs };
