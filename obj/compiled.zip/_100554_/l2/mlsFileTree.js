/// <mls fileReference="_100554_/l2/mlsFileTree.ts" enhancement="_100554_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { undoFile, deleteFile, createStorFile } from '/_102027_/l2/libStor.js';
import { getBaseTemplate } from '/_102027_/l2/libCommom.js';
import { createModel } from '/_102027_/l2/libModel.js';
let MlsFileTree = class MlsFileTree extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`mls-file-tree-100554 {
  display: block;
  background: var(--bg-primary-color);
  color: var(--text-primary-color-lighter-disabled);
  font-family: 'Segoe UI', sans-serif;
  font-size: 13px;
  min-height: 200px;
  user-select: none;
}
mls-file-tree-100554 .tree-root {
  padding: 4px 0;
}
mls-file-tree-100554 .tree-item {
  display: flex;
  align-items: center;
  height: 22px;
  padding-left: calc(var(--depth, 0) * 16px + 8px);
  cursor: pointer;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  gap: 4px;
}
mls-file-tree-100554 .tree-item:hover {
  background: var(--bg-primary-color-darker-disabled);
}
mls-file-tree-100554 .tree-item.selected {
  background: var(--active-color);
  color: #ffffff;
}
mls-file-tree-100554 .arrow {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  color: #bbbbbb;
  font-size: 10px;
  transition: transform 0.1s;
}
mls-file-tree-100554 .arrow.open {
  transform: rotate(90deg);
}
mls-file-tree-100554 .arrow-spacer {
  width: 16px;
  flex-shrink: 0;
}
mls-file-tree-100554 .icon {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
}
mls-file-tree-100554 .label {
  overflow: hidden;
  text-overflow: ellipsis;
}
mls-file-tree-100554 .ext-ts {
  color: #3178c6;
}
mls-file-tree-100554 .ext-json {
  color: #cbcb41;
}
mls-file-tree-100554 .ext-js {
  color: #e8c84e;
}
mls-file-tree-100554 .ext-html {
  color: #e44d26;
}
mls-file-tree-100554 .ext-css {
  color: #42a5f5;
}
mls-file-tree-100554 .ext-other {
  color: #cccccc;
}
mls-file-tree-100554 .test-item {
  padding: 0.5rem;
  cursor: pointer;
  position: relative;
  font-size: 0.95rem;
  z-index: 1;
  padding-left: calc(var(--depth, 0) * 16px + 8px) !important;
}
mls-file-tree-100554 .test-item svg {
  fill: var(--text-primary-color);
}
mls-file-tree-100554 .test-item .fileDeleted {
  text-decoration: line-through;
  color: var(--error-color);
}
mls-file-tree-100554 .test-item .elContent {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  user-select: none;
}
mls-file-tree-100554 .test-item .elContent .spanFileName {
  margin-left: 30px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
}
mls-file-tree-100554 .test-item .elContentAux {
  display: flex;
  margin-top: 1.5rem;
  flex-direction: column;
}
mls-file-tree-100554 .test-item .elContentAux .elContentAux2 {
  display: flex;
  gap: 0.5rem;
}
mls-file-tree-100554 .test-item .elContentAux input {
  border: 1px solid var(--grey-color);
  border-radius: 5px;
  padding-left: 0.3rem;
  font-size: 13px;
  outline: none;
  height: 20px;
  z-index: 10;
}
mls-file-tree-100554 .test-item .elContentAux button {
  border: none;
  border-radius: 5px;
  width: 20px;
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 10;
  cursor: pointer;
  background: none;
}
mls-file-tree-100554 .test-item .elContentAux button:hover {
  filter: sepia(100%) hue-rotate(190deg) saturate(500%);
}
mls-file-tree-100554 .test-item .elContentAux .spanPrj {
  position: relative;
}
mls-file-tree-100554 .test-item .elContentAux .spanPrj::before {
  content: 'New project:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
mls-file-tree-100554 .test-item .elContentAux .spanName {
  position: relative;
}
mls-file-tree-100554 .test-item .elContentAux .spanName::before {
  content: 'New short name:';
  position: absolute;
  color: black;
  width: 100px;
  top: -15px;
  left: 0px;
  z-index: 8;
  font-size: 12px;
}
mls-file-tree-100554 .test-item::after {
  content: ' ';
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z' fill='rgb(66,65,65,1)'/></svg>");
  background-repeat: no-repeat;
  width: 12px;
  height: 12px;
  background-position-y: center;
  position: absolute;
  right: 7px;
  top: 10px;
}
mls-file-tree-100554 .test-item.folder::after {
  background-image: none;
}
mls-file-tree-100554 .test-item.headerTitle {
  padding: 0.3em 1em;
  list-style-type: none;
  background: #f7f7f7;
  color: #000;
  font-weight: 600;
  cursor: default;
  font-size: 1rem !important;
}
mls-file-tree-100554 .test-item.headerTitle::after {
  content: "";
  background: none;
}
mls-file-tree-100554 .test-item:hover:not(.headerTitle) {
  background: var(--grey-color-dark);
}
mls-file-tree-100554 .test-item .classClick {
  position: absolute;
  height: 37px;
  width: 33px;
  display: flex;
  align-items: center;
  justify-content: center;
  left: auto !important;
}
mls-file-tree-100554 .test-item .groupHiddenListIcon {
  width: 8px;
  height: 21px;
  display: block;
}
mls-file-tree-100554 .test-item .groupHiddenList {
  padding: 0.3rem;
  transition: all 0.5s;
  cursor: pointer;
  display: none;
  z-index: 9;
  border-top: 1px solid #c4c4c4;
}
mls-file-tree-100554 .test-item .mls-gpbtnslider-item {
  color: var(--text-primary-color);
}
mls-file-tree-100554 .test-item .groupHiddenList .mls-gpbtnslider-item {
  display: block;
  transition: 0.5s;
  z-index: 10;
  color: var(--text-primary-color);
  border-bottom: 1px solid #c7c4c4;
  padding: 0.2rem;
  font-size: 13px;
}
mls-file-tree-100554 .test-item .groupHiddenList .mls-gpbtnslider-item:hover {
  background: #2f2f2f17;
  color: var(--active-color);
}
mls-file-tree-100554 .test-item .groupHiddenList.activegpbtnslider {
  display: flex;
  flex-direction: column;
}
mls-file-tree-100554 .test-item info-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: width 2s;
}
`);
        this.files = {};
        this.expanded = new Set();
        this.selected = '';
        this.dataDifBaseTemplate = {};
    }
    firstUpdated() {
        this.project = this.project ? this.project : (mls.actualProject || 0).toString();
    }
    render() {
        // read from global if no property passed
        const src = Object.keys(this.files).length > 0
            ? this.files
            : mls.stor.files ?? {};
        if (Object.keys(src).length === 0) {
            this.files = src;
            return html `<div style="padding:8px;color:#888">Nenhum arquivo encontrado em mls.stor.files</div>`;
        }
        if (this.files !== src)
            this.files = src;
        const tree = this.buildTree();
        return html `
            <ul class="tree-root">
                ${tree.children.map(c => this.renderNode(c, 0))}
            </ul>
        `;
    }
    renderNode(node, depth) {
        if (node.isFolder) {
            const isOpen = this.expanded.has(node.fullPath);
            return html `
                <li class="test-item folder" style="--depth: ${depth}" @click=${() => this.toggleFolder(node.fullPath)} >
                    <div class="elContent">
                        <info-item>
                            <span class="arrow ${isOpen ? 'open' : ''}">▶</span>
                            <span class="icon">📁</span>
                            <div style="display:flex; gap:.5rem" .innerHTML="${node.name}"></div>
                        
                        <span style="cursor:pointer;z-index: 99;display: flex; position: absolute; right: 25px;" title="delete all this folder" @click=${() => { this.undoAllByFolders(node.fullPath); }}><span class="fa fa-undo"></span></span>

                        <span style="cursor:pointer;z-index: 99;display: flex; position: absolute; right: 5px;" title="delete all this folder" @click=${() => { this.delAllByFolders(node.fullPath); }}><svg xmlns="http://www.w3.org/2000/svg" style="width:15px; cursor:pointer; z-index:-1" viewBox="0 0 640 640"><!--!Font Awesome Free v7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M232.7 69.9L224 96L128 96C110.3 96 96 110.3 96 128C96 145.7 110.3 160 128 160L512 160C529.7 160 544 145.7 544 128C544 110.3 529.7 96 512 96L416 96L407.3 69.9C402.9 56.8 390.7 48 376.9 48L263.1 48C249.3 48 237.1 56.8 232.7 69.9zM512 208L128 208L149.1 531.1C150.7 556.4 171.7 576 197 576L443 576C468.3 576 489.3 556.4 490.9 531.1L512 208z"/></svg></span>
                        </info-item>
                    </div>
                </li>
                ${isOpen ? node.children.map(c => this.renderNode(c, depth + 1)) : nothing}
            `;
        }
        else {
            return this.renderItem(node, depth);
        }
    }
    renderItem(node, depth) {
        const isSelected = this.selected === node.fileKey;
        const file = node.file;
        let auxVersion = '';
        let auxStorage = '';
        let auxBug = '';
        let auxHtml = '';
        const titleLocalStorage = this.getTitleInLocalStorage(file);
        if (titleLocalStorage) {
            auxStorage = `<span title=" ${titleLocalStorage} in localstorage" class="fa fa-location-dot" style="color:lightskyblue; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.hasError) {
            auxBug = `<span title="bug" class="fa fa-bug" style="color:rgb(169, 3, 3); height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        if (file.isLocalVersionOutdated) {
            auxVersion = `<span title="need conciliation" class="fa fa-unbalanced" style="color:orange; height: 14px; display: flex; justify-content: center; align-items: center;"></span>`;
        }
        return html ` 
                <li  .myFile=${node.file} class="test-item ${isSelected ? 'selected' : ''}" @click=${() => this.selectFile(node.fileKey, node.file)} style="--depth: ${depth}" .nameFilter="${node.file.shortName.toLocaleLowerCase()}">
                    <div class="elContent">
                        <info-item>
                            <span class="classClick" @click="${this.clickGroupHidden}">
                                <span class="groupHiddenListIcon" >
                                    <svg xmlns='http://www.w3.org/2000/svg' style='height: 21px;' viewBox='0 0 128 512' ><path style='fill:var(--text-primary-color)' d='M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z' fill='rgb(66,65,65,1)'/></svg>
                                </span>
                            </span>
                            </span>
                            <span class="spanFileName ${node.file.status === 'deleted' ? 'fileDeleted' : ''}">${node.name}</span>
                            <div style="display:flex; gap:.5rem" .innerHTML="${auxStorage + auxBug + auxVersion + auxHtml}"></div>
                        </info-item>
                        <div class="groupHiddenList">
                            <span class="mls-gpbtnslider-item" title="Undo" @click=${(e) => { e.stopPropagation(); this.undoFile(node.file); }}><span class="fa fa-undo"></span> Undo</span>
                            <span class="mls-gpbtnslider-item" title="Delete" @click=${(e) => { e.stopPropagation(); this.deleteFile(node.file); }}><span class=" fa fa-trash"></span> Delete</span>
                        </div>
                    </div>
                </li>
            `;
    }
    async deleteFile(file) {
        await deleteFile(file);
        this.requestUpdate();
    }
    async undoFile(file) {
        await undoFile(file);
        this.requestUpdate();
    }
    getTitleInLocalStorage(file) {
        const fileLocal = file && file.inLocalStorage && this.verifyDifBaseTemplate(file);
        return fileLocal ? file.extension : '';
    }
    verifyDifBaseTemplate(file) {
        const { folder, shortName, project, extension } = file;
        const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, extension);
        if (this.dataDifBaseTemplate[key] === undefined)
            return file.inLocalStorage;
        return this.dataDifBaseTemplate[key];
    }
    buildTree() {
        const root = { name: '', fullPath: '', isFolder: true, children: [], file: {} };
        const getOrCreateFolder = (parent, name, path) => {
            let node = parent.children.find(c => c.isFolder && c.name === name);
            if (!node) {
                node = { name, fullPath: path, isFolder: true, children: [], file: {} };
                parent.children.push(node);
            }
            return node;
        };
        for (const [key, file] of Object.entries(this.files)) {
            if (file.project !== +(this.project || '0') || isNaN(file.level))
                continue;
            const segments = [];
            if (file.level > 0)
                segments.push(`l${file.level}`);
            if (file.folder)
                segments.push(file.folder);
            let current = root;
            let pathSoFar = '';
            for (const seg of segments) {
                pathSoFar += '/' + seg;
                current = getOrCreateFolder(current, seg, pathSoFar);
            }
            const fileName = file.shortName + file.extension;
            current.children.push({
                name: fileName,
                fullPath: key,
                isFolder: false,
                children: [],
                fileKey: key,
                extension: file.extension,
                file: file
            });
        }
        // sort: folders first, then files, alphabetically
        const sortNode = (node) => {
            node.children.sort((a, b) => {
                if (a.isFolder !== b.isFolder)
                    return a.isFolder ? -1 : 1;
                return a.name.localeCompare(b.name);
            });
            node.children.forEach(sortNode);
        };
        sortNode(root);
        return root;
    }
    toggleFolder(path) {
        const next = new Set(this.expanded);
        next.has(path) ? next.delete(path) : next.add(path);
        this.expanded = next;
    }
    selectFile(key, file) {
        this.selected = key;
        if (['.ts'].includes(file.extension)) {
            this.fireEvents(file);
        }
        else {
            this.fireEventsDetails(file);
        }
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        const father = el.closest('div');
        if (!father)
            return;
        const target = father.querySelector('.groupHiddenList');
        if (!target)
            return;
        target.classList.toggle('activegpbtnslider');
    }
    async delAllByFolders(folder) {
        const level = this.getLevel(folder + '/');
        folder = this.clearPath(folder + '/');
        if (folder === 'root')
            folder = '';
        const all = Object.keys(mls.stor.files).filter((k) => {
            const s = mls.stor.files[k];
            if (!s || s.project !== +(this.project || '0') || s.folder !== folder || s.level !== level)
                return false;
            return true;
        });
        for await (const k of all) {
            const mfile = mls.stor.files[k];
            if (!mfile)
                continue;
            await deleteFile(mfile);
        }
        this.requestUpdate();
    }
    async undoAllByFolders(folder) {
        const level = this.getLevel(folder + '/');
        folder = this.clearPath(folder + '/');
        if (folder === 'root')
            folder = '';
        const all = Object.keys(mls.stor.files).filter((k) => {
            const s = mls.stor.files[k];
            if (!s || s.project !== +(this.project || '0') || s.folder !== folder || s.level !== level)
                return false;
            return true;
        });
        for await (const k of all) {
            const mfile = mls.stor.files[k];
            if (!mfile)
                continue;
            await undoFile(mfile);
        }
        this.requestUpdate();
    }
    getLevel(str) {
        const match = str.match(/\/l(\d+)\//);
        return match ? Number(match[1]) : null;
    }
    clearPath(str) {
        let path = str.replace(/^\/l\d+\//, '/').replace(/\/$/, '');
        if (path.startsWith('/'))
            path = path.replace(/^\/+/, '');
        return path;
    }
    fireEventsDetails(stor) {
        const key = mls.stor.getKeyToFile(stor);
        const options = {
            shortName: undefined,
            project: undefined,
            htmlText: '<plugin-view-file-100554 nameFile="' + key + '"></plugin-view-file-100554>'
        };
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
    async fireEvents(file, timeout = 0) {
        try {
            const params = {};
            //const files = await createAllModels(file, true);
            if ([1, 2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.ts');
            if ([2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.less');
            if ([2, 3, 4].includes(mls.actualLevel))
                await this.createModel(file, '.html');
            params.action = 'open';
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = this.position;
            const lv = mls.actualLevel;
            let name = `_${file.project}_${file.shortName}`;
            if (file.folder)
                name = `_${file.project}_${file.folder}/${file.shortName}`;
            mls.actual[lv].setFullName(name);
            mls.actual[lv][this.position] = file;
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
        }
        catch (err) {
            console.info(err.message || '[fireEvents]: erro open');
        }
    }
    async createModel(base, ext) {
        if (ext === '.ts') {
            return await createModel(base, true, false);
        }
        const { project, shortName, folder, level } = base;
        const key = mls.stor.getKeyToFiles(project, base.level, shortName, folder, ext);
        let stor = mls.stor.files[key];
        if (!stor) {
            const param = {
                project,
                shortName,
                folder,
                level,
                extension: '.ts',
                source: '',
                status: 'new'
            };
            if (ext === '.less') {
                const templateLess = await getBaseTemplate({ folder, shortName, project, extension: '.less' }, 'enhancementStyle');
                return createStorFile({ ...param, extension: '.less', source: templateLess }, true, true, false);
            }
            if (ext === '.html') {
                const templateHTML = await getBaseTemplate({ folder, shortName, project, extension: '.html' });
                return createStorFile({ ...param, extension: '.html', source: templateHTML }, true, true, false);
            }
        }
        else {
            await createModel(stor, true, false);
        }
    }
};
__decorate([
    property()
], MlsFileTree.prototype, "position", void 0);
__decorate([
    property()
], MlsFileTree.prototype, "project", void 0);
__decorate([
    property({ type: Object })
], MlsFileTree.prototype, "files", void 0);
__decorate([
    state()
], MlsFileTree.prototype, "expanded", void 0);
__decorate([
    state()
], MlsFileTree.prototype, "selected", void 0);
MlsFileTree = __decorate([
    customElement('mls-file-tree-100554')
], MlsFileTree);
export { MlsFileTree };
