/// <mls fileReference="_100554_/l2/serviceReportBug.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Reportar Bug',
    emptyHint: 'Aperte Ctrl+Shift+B na tela onde o problema aconteceu para capturar o estado e o print.',
    description: 'O que você tentou fazer quando o erro aconteceu?',
    descriptionPlaceholder: 'Descreva os passos que levaram ao erro...',
    sendTo: 'Enviar para',
    selectDestination: 'Selecione a pessoa ou sala...',
    noThreads: 'Nenhuma conversa encontrada — abra o Collab Messages ao menos uma vez.',
    noMatches: 'Nenhuma conversa corresponde ao filtro.',
    send: 'Enviar bug',
    sending: 'Enviando...',
    sent: 'Bug enviado — o JSON completo também está no console do navegador.',
    sendFailed: 'Falha ao enviar',
    viewTitle: 'Visualização de bug (somente leitura)',
    viewClose: 'Fechar visualização',
    viewInvalid: 'Não foi possível ler o JSON do bug.',
    viewScreenshotUnavailable: 'Print não incluído na mensagem (ver console.log de quem reportou).',
    screenshot: 'Print da tela',
    noScreenshot: 'Print não capturado (permissão negada ou não suportado).',
    context: 'Contexto (mls)',
    network: 'Últimas requisições',
    console: 'Mensagens do console',
    capturedAt: 'Capturado em',
    user: 'Usuário',
    newCapture: 'Nova captura',
    colField: 'Campo',
    colValue: 'Valor',
    colMethod: 'Método',
    colRequest: 'Requisição',
    colStatus: 'Status',
    colTime: 'Tempo',
    colWhen: 'Hora',
    colType: 'Tipo',
    colMessage: 'Mensagem',
};
const message_en = {
    title: 'Report Bug',
    emptyHint: 'Press Ctrl+Shift+B on the screen where the problem happened to capture the state and screenshot.',
    description: 'What were you trying to do when the error happened?',
    descriptionPlaceholder: 'Describe the steps that led to the error...',
    sendTo: 'Send to',
    selectDestination: 'Select the person or room...',
    noThreads: 'No conversations found — open Collab Messages at least once.',
    noMatches: 'No conversation matches the filter.',
    send: 'Send bug',
    sending: 'Sending...',
    sent: 'Bug sent — the full JSON is also in the browser console.',
    sendFailed: 'Failed to send',
    viewTitle: 'Bug view (read-only)',
    viewClose: 'Close view',
    viewInvalid: 'Could not parse the bug JSON.',
    viewScreenshotUnavailable: 'Screenshot not included in the message (see the reporter\'s console.log).',
    screenshot: 'Screenshot',
    noScreenshot: 'Screenshot not captured (permission denied or not supported).',
    context: 'Context (mls)',
    network: 'Last requests',
    console: 'Console messages',
    capturedAt: 'Captured at',
    user: 'User',
    newCapture: 'New capture',
    colField: 'Field',
    colValue: 'Value',
    colMethod: 'Method',
    colRequest: 'Request',
    colStatus: 'Status',
    colTime: 'Time',
    colWhen: 'When',
    colType: 'Type',
    colMessage: 'Message',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
const CONSOLE_CAP = 200;
const CONSOLE_ENTRY_MAX_CHARS = 2000;
const NETWORK_CAP = 30;
const NETWORK_SEND = 10;
const SCREENSHOT_JPEG_QUALITY = 0.7;
const SHORTCUT = { key: 'B', ctrl: true, shift: true };
const consoleBuffer = [];
const networkBuffer = [];
let lastSnapshot;
let activeInstance;
let capturing = false;
function nowIso() { return new Date().toISOString(); }
function pushCapped(buffer, entry, cap) {
    buffer.push(entry);
    if (buffer.length > cap)
        buffer.splice(0, buffer.length - cap);
}
function safeText(args) {
    const text = args.map((a) => {
        if (typeof a === 'string')
            return a;
        if (a instanceof Error)
            return `${a.message}\n${a.stack || ''}`;
        try {
            return JSON.stringify(a);
        }
        catch {
            return String(a);
        }
    }).join(' ');
    return text.length > CONSOLE_ENTRY_MAX_CHARS ? `${text.slice(0, CONSOLE_ENTRY_MAX_CHARS)}[truncated]` : text;
}
function installConsoleInterceptor() {
    const methods = ['log', 'info', 'warn', 'error', 'debug', 'trace', 'dir', 'table', 'assert', 'count', 'group', 'groupCollapsed'];
    methods.forEach((method) => {
        const c = console;
        if (typeof c[method] !== 'function')
            return;
        const original = c[method].bind(console);
        c[method] = (...args) => {
            try {
                pushCapped(consoleBuffer, { ts: nowIso(), level: method, text: safeText(args) }, CONSOLE_CAP);
            }
            catch { /* never break console */ }
            original(...args);
        };
    });
}
function installNetworkInterceptor() {
    const originalFetch = window.fetch.bind(window);
    window.fetch = async (input, init) => {
        const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
        const method = (init?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
        const started = performance.now();
        try {
            const res = await originalFetch(input, init);
            pushCapped(networkBuffer, { ts: nowIso(), method, url, status: res.status, durationMs: Math.round(performance.now() - started) }, NETWORK_CAP);
            return res;
        }
        catch (err) {
            pushCapped(networkBuffer, { ts: nowIso(), method, url, status: 'failed', durationMs: Math.round(performance.now() - started) }, NETWORK_CAP);
            throw err;
        }
    };
    const XHR = XMLHttpRequest.prototype;
    const originalOpen = XHR.open;
    const originalSend = XHR.send;
    XHR.open = function (method, url, ...rest) {
        this.__bugReport = { method: (method || 'GET').toUpperCase(), url: String(url) };
        return originalOpen.call(this, method, url, ...rest);
    };
    XHR.send = function (...args) {
        const info = this.__bugReport;
        if (info) {
            const started = performance.now();
            this.addEventListener('loadend', () => {
                pushCapped(networkBuffer, {
                    ts: nowIso(), method: info.method, url: info.url,
                    status: this.status || 'failed', durationMs: Math.round(performance.now() - started)
                }, NETWORK_CAP);
            });
        }
        return originalSend.apply(this, args);
    };
}
function installShortcutListener() {
    window.addEventListener('keydown', (ev) => {
        if (!ev.ctrlKey || !ev.shiftKey || ev.key.toUpperCase() !== SHORTCUT.key)
            return;
        ev.preventDefault();
        ev.stopPropagation();
        captureAndOpen();
    }, true);
}
function installOpenViewListener() {
    // Fired by collab-messages-rich-preview-text-102025 when the user clicks
    // "Open" on a ```BUG code block in the chat.
    window.addEventListener('collab-bug-report-open', ((ev) => {
        if (!activeInstance)
            return;
        activeInstance.openView(ev.detail?.json || '');
    }));
}
function installAll() {
    const w = window;
    if (w.__collabBugReportInstalled)
        return;
    w.__collabBugReportInstalled = true;
    installConsoleInterceptor();
    installNetworkInterceptor();
    installShortcutListener();
    installOpenViewListener();
}
// ---------------------------------------------------------------------------
// Capture
// ---------------------------------------------------------------------------
function serializeFileRef(f) {
    if (!f)
        return undefined;
    return { project: f.project, shortName: f.shortName, folder: f.folder, extension: f.extension };
}
function snapshotMls() {
    const g = mls;
    const actual = (g.actual || []).map((a) => ({
        level: a.level,
        project: a.project,
        path: a.path,
        left: serializeFileRef(a.left),
        right: serializeFileRef(a.right),
    }));
    return {
        actualProject: g.actualProject,
        actualLevel: g.actualLevel,
        actualService: g.actualService,
        actualPosition: g.actualPosition,
        actualModule: g.actualModule,
        actual,
    };
}
async function captureScreenshot() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia)
        return undefined;
    let stream;
    try {
        stream = await navigator.mediaDevices.getDisplayMedia({
            video: true,
            audio: false,
            preferCurrentTab: true,
        });
        const video = document.createElement('video');
        video.srcObject = stream;
        video.muted = true;
        await video.play();
        await new Promise((r) => requestAnimationFrame(r));
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return undefined;
        ctx.drawImage(video, 0, 0);
        return canvas.toDataURL('image/jpeg', SCREENSHOT_JPEG_QUALITY);
    }
    catch {
        return undefined; // user denied the prompt — report goes on without the screenshot
    }
    finally {
        stream?.getTracks().forEach((t) => t.stop());
    }
}
function getUserSafe() {
    try {
        return mls.getActualUser();
    }
    catch {
        return 'unknown';
    }
}
async function loadDestinations() {
    try {
        const idb = await import('/_102025_/l2/collabMessagesIndexedDB.js');
        const threads = await idb.getAllThreads();
        const rank = (name) => name.startsWith('@') ? 0 : name.startsWith('#') ? 1 : 2;
        return threads
            .filter((t) => t.status === 'active')
            .map((t) => ({ threadId: t.threadId, name: t.name, group: t.group }))
            .sort((a, b) => rank(a.name) - rank(b.name) || a.name.localeCompare(b.name));
    }
    catch {
        return [];
    }
}
async function sendToThread(threadId, content) {
    const helper = await import('/_102025_/l2/collabMessagesHelper.js');
    await helper.addMessage(threadId, content);
}
async function captureAndOpen() {
    if (capturing)
        return;
    capturing = true;
    try {
        // Screenshot FIRST: the screen still shows the state where the bug happened.
        const screenshot = await captureScreenshot();
        lastSnapshot = {
            capturedAt: nowIso(),
            user: getUserSafe(),
            href: location.href,
            userAgent: navigator.userAgent,
            viewport: `${window.innerWidth}x${window.innerHeight}`,
            mls: snapshotMls(),
            console: consoleBuffer.slice(),
            network: networkBuffer.slice(-NETWORK_SEND),
            screenshot,
        };
        if (activeInstance) {
            activeInstance.refreshSnapshot();
            activeInstance.showNav2Item(true);
            activeInstance.openMe();
        }
    }
    finally {
        capturing = false;
    }
}
// ---------------------------------------------------------------------------
// Service
// ---------------------------------------------------------------------------
let ServiceReportBug100554 = class ServiceReportBug100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-report-bug-100554 {
  display: block;
  font-family: var(--font-family-primary);
  box-sizing: border-box;
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
  background: var(--bg-primary-color);
  height: 100%;
  overflow: auto;
  padding: var(--space-16);
}
service-report-bug-100554 .rb-root {
  display: flex;
  flex-direction: column;
  gap: var(--space-16);
}
service-report-bug-100554 .rb-section {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
  background: var(--bg-secondary-color-lighter);
  border: 1px solid var(--grey-color);
  border-radius: 4px;
  padding: var(--space-16);
}
service-report-bug-100554 h4 {
  margin: 0;
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary-color-darker);
  border-bottom: 1px solid var(--grey-color-dark);
  padding-bottom: var(--space-8);
}
service-report-bug-100554 .rb-meta {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
}
service-report-bug-100554 .rb-empty {
  padding: var(--space-16) var(--space-8);
  color: var(--text-primary-color-lighter);
}
service-report-bug-100554 .rb-label {
  font-weight: var(--font-weight-bold);
  color: var(--text-primary-color-darker);
}
service-report-bug-100554 .rb-description {
  width: 100%;
  box-sizing: border-box;
  resize: vertical;
  padding: var(--space-8);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color-darker);
  border-radius: 4px;
}
service-report-bug-100554 .rb-description:focus {
  outline: none;
  border-color: var(--active-color);
}
service-report-bug-100554 .rb-view-banner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-8);
  padding: var(--space-8) var(--space-16);
  background: var(--info-color);
  color: var(--bg-primary-color-lighter);
  border-radius: 4px;
  font-weight: var(--font-weight-bold);
  font-size: var(--font-size-12);
}
service-report-bug-100554 .rb-view-close {
  padding: 2px var(--space-8);
  cursor: pointer;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-12);
  color: var(--info-color);
  background: var(--bg-primary-color-lighter);
  border: none;
  border-radius: 4px;
}
service-report-bug-100554 .rb-view-close:hover {
  background: var(--bg-primary-color-lighter-hover);
}
service-report-bug-100554 .rb-view-description {
  white-space: pre-wrap;
  word-break: break-word;
}
service-report-bug-100554 .rb-select {
  width: 100%;
  box-sizing: border-box;
  padding: var(--space-8);
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color-darker);
  border-radius: 4px;
}
service-report-bug-100554 .rb-select:focus {
  outline: none;
  border-color: var(--active-color);
}
service-report-bug-100554 .rb-filter-select {
  position: relative;
}
service-report-bug-100554 .rb-suggestions {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  z-index: 10;
  max-height: 220px;
  overflow: auto;
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color-darker);
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}
service-report-bug-100554 .rb-suggestion {
  padding: var(--space-8);
  cursor: pointer;
  font-size: var(--font-size-12);
  color: var(--text-primary-color);
}
service-report-bug-100554 .rb-suggestion:hover,
service-report-bug-100554 .rb-suggestion.highlighted {
  background: var(--bg-primary-color-hover);
}
service-report-bug-100554 .rb-suggestion.selected {
  color: var(--active-color);
  font-weight: var(--font-weight-bold);
}
service-report-bug-100554 .rb-suggestion .rb-suggestion-group {
  color: var(--text-primary-color-lighter);
}
service-report-bug-100554 .rb-suggestion-empty {
  cursor: default;
  color: var(--text-primary-color-lighter);
}
service-report-bug-100554 .rb-suggestion-empty:hover {
  background: transparent;
}
service-report-bug-100554 .rb-send-error {
  color: var(--error-color);
  font-size: var(--font-size-12);
}
service-report-bug-100554 .rb-send {
  align-self: flex-start;
  padding: var(--space-8) var(--space-24);
  cursor: pointer;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  color: var(--bg-primary-color-lighter);
  background: var(--active-color);
  border: none;
  border-radius: 4px;
  transition: background var(--transition-slow);
}
service-report-bug-100554 .rb-send:hover {
  background: var(--active-color-hover);
}
service-report-bug-100554 .rb-send:focus {
  background: var(--active-color-focus);
}
service-report-bug-100554 .rb-send:disabled {
  cursor: default;
  background: var(--active-color-disabled);
}
service-report-bug-100554 .rb-sent {
  color: var(--success-color);
  font-size: var(--font-size-12);
}
service-report-bug-100554 .rb-screenshot {
  max-width: 100%;
  border: 1px solid var(--grey-color-darker);
  border-radius: 4px;
}
service-report-bug-100554 .rb-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-12);
}
service-report-bug-100554 .rb-table th {
  text-align: left;
  padding: var(--space-8);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary-color-darker);
  background: var(--bg-secondary-color);
  border-bottom: 1px solid var(--grey-color-darker);
}
service-report-bug-100554 .rb-table td {
  border-bottom: 1px solid var(--grey-color);
  padding: var(--space-8);
  vertical-align: top;
  color: var(--text-primary-color);
}
service-report-bug-100554 .rb-table .rb-url {
  max-width: 0;
  width: 60%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
service-report-bug-100554 .rb-table .rb-error td {
  color: var(--error-color);
}
service-report-bug-100554 .rb-console {
  max-height: 260px;
  overflow: auto;
  font-family: monospace;
  font-size: var(--font-size-12);
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color);
  border-radius: 4px;
}
service-report-bug-100554 .rb-console .rb-console-header {
  display: flex;
  gap: var(--space-8);
  position: sticky;
  top: 0;
  padding: var(--space-8);
  font-family: var(--font-family-primary);
  font-weight: var(--font-weight-bold);
  color: var(--text-primary-color-darker);
  background: var(--bg-secondary-color);
  border-bottom: 1px solid var(--grey-color-darker);
}
service-report-bug-100554 .rb-console .rb-line {
  display: flex;
  gap: var(--space-8);
  padding: 2px var(--space-8);
  white-space: pre-wrap;
  word-break: break-word;
  border-bottom: 1px dotted var(--grey-color);
  color: var(--text-primary-color);
}
service-report-bug-100554 .rb-console .rb-col-when {
  flex: 0 0 60px;
  color: var(--text-primary-color-lighter);
}
service-report-bug-100554 .rb-console .rb-col-type {
  flex: 0 0 60px;
  color: var(--text-secondary-color);
}
service-report-bug-100554 .rb-console .rb-col-text {
  flex: 1;
}
service-report-bug-100554 .rb-console .rb-error {
  color: var(--error-color);
}
service-report-bug-100554 .rb-console .rb-error .rb-col-text {
  color: var(--error-color);
}
service-report-bug-100554 .rb-console .rb-warn .rb-col-text {
  color: var(--warning-color);
}
`);
        this.msg = messages['en'];
        this.description = '';
        this.sent = false;
        this.sending = false;
        this.sendError = '';
        this.destinations = [];
        this.selectedThreadId = '';
        this.destinationFilter = '';
        this.showSuggestions = false;
        this.highlightedIndex = -1;
        this.viewError = false;
        this.details = {
            icon: '&#xf188',
            state: 'background',
            tooltip: 'Report Bug',
            visible: true,
            position: 'all',
            widget: '_100554_serviceReportBug',
            level: [0, 1, 2, 3, 4, 5, 6, 7]
        };
        this.menu = {
            title: 'Report Bug',
            main: {},
            tabs: undefined,
            tools: {},
        };
        installAll();
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        activeInstance = this;
        this.snapshot = lastSnapshot;
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (activeInstance === this)
            activeInstance = undefined;
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            this.snapshot = lastSnapshot;
            this.loadDestinations();
        }
    }
    refreshSnapshot() {
        this.snapshot = lastSnapshot;
        this.description = '';
        this.sent = false;
        this.sending = false;
        this.sendError = '';
        this.viewData = undefined;
        this.viewError = false;
        this.loadDestinations();
    }
    openView(json) {
        this.viewError = false;
        try {
            const data = JSON.parse(json);
            this.viewData = {
                capturedAt: data.capturedAt || '-',
                user: data.user || '-',
                href: data.href || '-',
                userAgent: data.userAgent || '-',
                viewport: data.viewport || '-',
                mls: data.mls || { actual: [] },
                console: Array.isArray(data.console) ? data.console : [],
                network: Array.isArray(data.network) ? data.network : [],
                screenshot: data.screenshot,
                description: data.description,
            };
        }
        catch {
            this.viewData = undefined;
            this.viewError = true;
        }
        this.showNav2Item(true);
        this.openMe();
    }
    closeView() {
        this.viewData = undefined;
        this.viewError = false;
        this.snapshot = lastSnapshot;
    }
    async loadDestinations() {
        this.destinations = await loadDestinations();
        if (this.selectedThreadId && !this.destinations.some((d) => d.threadId === this.selectedThreadId)) {
            this.selectedThreadId = '';
            this.destinationFilter = '';
        }
    }
    get filteredDestinations() {
        const filter = this.destinationFilter.trim().toLowerCase();
        if (!filter)
            return this.destinations;
        return this.destinations.filter((d) => d.name.toLowerCase().includes(filter));
    }
    selectDestination(d) {
        this.selectedThreadId = d.threadId;
        this.destinationFilter = d.name;
        this.showSuggestions = false;
        this.highlightedIndex = -1;
    }
    onFilterInput(e) {
        this.destinationFilter = e.target.value;
        this.selectedThreadId = '';
        this.showSuggestions = true;
        this.highlightedIndex = -1;
    }
    onFilterBlur() {
        // Delay so a click on a suggestion lands before the list closes.
        setTimeout(() => { this.showSuggestions = false; this.highlightedIndex = -1; }, 150);
    }
    onFilterKeyDown(e) {
        const items = this.filteredDestinations;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.showSuggestions = true;
            this.highlightedIndex = Math.min(this.highlightedIndex + 1, items.length - 1);
        }
        else if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.highlightedIndex = Math.max(this.highlightedIndex - 1, 0);
        }
        else if (e.key === 'Enter') {
            if (this.showSuggestions && this.highlightedIndex >= 0 && items[this.highlightedIndex]) {
                e.preventDefault();
                this.selectDestination(items[this.highlightedIndex]);
            }
        }
        else if (e.key === 'Escape') {
            this.showSuggestions = false;
            this.highlightedIndex = -1;
        }
    }
    buildPayload() {
        if (!this.snapshot)
            return undefined;
        return { description: this.description, ...this.snapshot };
    }
    buildMessageContent(payload) {
        const json = JSON.stringify({
            ...payload,
            screenshot: payload.screenshot ? `[jpeg base64 - ${payload.screenshot.length} chars - ver console.log]` : undefined,
        }, null, 2);
        return `Bug: ${payload.capturedAt} — ${payload.user}\n\`\`\`BUG\n${json}\n\`\`\``;
    }
    async onSend() {
        const payload = this.buildPayload();
        if (!payload || !this.selectedThreadId || this.sending)
            return;
        // Full payload (screenshot included) stays available in the browser console.
        console.log('[serviceReportBug] payload:', payload);
        this.sending = true;
        this.sendError = '';
        try {
            await sendToThread(this.selectedThreadId, this.buildMessageContent(payload));
            this.sent = true;
        }
        catch (err) {
            this.sendError = err?.message || String(err);
        }
        finally {
            this.sending = false;
        }
    }
    renderEmpty() {
        return html `<div class="rb-empty">${this.msg.emptyHint}</div>`;
    }
    renderMlsContext(m) {
        const rows = [
            ['actualProject', String(m.actualProject ?? '-')],
            ['actualLevel', String(m.actualLevel ?? '-')],
            ['actualService', m.actualService || '-'],
            ['actualPosition', m.actualPosition || '-'],
            ['actualModule', m.actualModule || '-'],
        ];
        return html `
            <table class="rb-table">
                <thead>
                    <tr><th>${this.msg.colField}</th><th>${this.msg.colValue}</th></tr>
                </thead>
                <tbody>
                    ${rows.map(([k, v]) => html `<tr><td>${k}</td><td>${v}</td></tr>`)}
                    ${m.actual.filter((a) => a.project || a.left || a.right).map((a) => html `
                        <tr>
                            <td>actual[${a.level}]</td>
                            <td>prj ${a.project ?? '-'}${a.left?.shortName ? ` | L: ${a.left.shortName}` : ''}${a.right?.shortName ? ` | R: ${a.right.shortName}` : ''}</td>
                        </tr>
                    `)}
                </tbody>
            </table>
        `;
    }
    renderNetwork(entries) {
        return html `
            <table class="rb-table">
                <thead>
                    <tr>
                        <th>${this.msg.colMethod}</th>
                        <th>${this.msg.colRequest}</th>
                        <th>${this.msg.colStatus}</th>
                        <th>${this.msg.colTime}</th>
                    </tr>
                </thead>
                <tbody>
                    ${entries.map((n) => html `
                        <tr class="${typeof n.status === 'number' && n.status < 400 ? '' : 'rb-error'}">
                            <td>${n.method}</td>
                            <td class="rb-url" title="${n.url}">${n.url}</td>
                            <td>${n.status}</td>
                            <td>${n.durationMs}ms</td>
                        </tr>
                    `)}
                </tbody>
            </table>
        `;
    }
    renderConsole(entries) {
        return html `
            <div class="rb-console">
                <div class="rb-console-header">
                    <span class="rb-col-when">${this.msg.colWhen}</span>
                    <span class="rb-col-type">${this.msg.colType}</span>
                    <span>${this.msg.colMessage}</span>
                </div>
                ${entries.map((c) => html `
                    <div class="rb-line rb-${c.level}">
                        <span class="rb-col-when">${c.ts.slice(11, 19)}</span>
                        <span class="rb-col-type">${c.level}</span>
                        <span class="rb-col-text">${c.text}</span>
                    </div>
                `)}
            </div>
        `;
    }
    renderDataSections(s) {
        return html `
            <div class="rb-section">
                <h4>${this.msg.screenshot}</h4>
                ${s.screenshot && s.screenshot.startsWith('data:image')
            ? html `<img class="rb-screenshot" src="${s.screenshot}" alt="screenshot" />`
            : html `<div class="rb-empty">${s.screenshot ? this.msg.viewScreenshotUnavailable : this.msg.noScreenshot}</div>`}
            </div>

            <div class="rb-section">
                <h4>${this.msg.context}</h4>
                ${this.renderMlsContext(s.mls)}
            </div>

            <div class="rb-section">
                <h4>${this.msg.network} (${s.network.length})</h4>
                ${this.renderNetwork(s.network)}
            </div>

            <div class="rb-section">
                <h4>${this.msg.console} (${s.console.length})</h4>
                ${this.renderConsole(s.console)}
            </div>
        `;
    }
    renderView(s) {
        return html `
            <div class="rb-view-banner">
                <span>${this.msg.viewTitle}</span>
                <button class="rb-view-close" @click=${() => this.closeView()}>${this.msg.viewClose}</button>
            </div>
            <div class="rb-meta">${this.msg.capturedAt}: ${s.capturedAt} — ${this.msg.user}: ${s.user}</div>

            <div class="rb-section">
                <label class="rb-label">${this.msg.description}</label>
                <div class="rb-view-description">${s.description || '-'}</div>
            </div>

            ${this.renderDataSections(s)}
        `;
    }
    renderSnapshot(s) {
        return html `
            <div class="rb-meta">${this.msg.capturedAt}: ${s.capturedAt} — ${this.msg.user}: ${s.user}</div>

            <div class="rb-section">
                <label class="rb-label">${this.msg.description}</label>
                <textarea class="rb-description" rows="4" placeholder="${this.msg.descriptionPlaceholder}"
                    .value=${this.description}
                    @input=${(e) => { this.description = e.target.value; }}></textarea>

                <label class="rb-label">${this.msg.sendTo}</label>
                ${this.destinations.length === 0
            ? html `<div class="rb-empty">${this.msg.noThreads}</div>`
            : html `
                        <div class="rb-filter-select">
                            <input class="rb-select" type="text" autocomplete="off"
                                placeholder="${this.msg.selectDestination}"
                                .value=${this.destinationFilter}
                                @input=${(e) => this.onFilterInput(e)}
                                @focus=${() => { this.showSuggestions = true; }}
                                @blur=${() => this.onFilterBlur()}
                                @keydown=${(e) => this.onFilterKeyDown(e)} />
                            ${this.showSuggestions ? html `
                                <div class="rb-suggestions">
                                    ${this.filteredDestinations.length === 0
                ? html `<div class="rb-suggestion rb-suggestion-empty">${this.msg.noMatches}</div>`
                : this.filteredDestinations.map((d, index) => html `
                                            <div class="rb-suggestion ${index === this.highlightedIndex ? 'highlighted' : ''} ${d.threadId === this.selectedThreadId ? 'selected' : ''}"
                                                @mousedown=${(e) => e.preventDefault()}
                                                @click=${() => this.selectDestination(d)}>
                                                ${d.name} <span class="rb-suggestion-group">(${d.group})</span>
                                            </div>
                                        `)}
                                </div>
                            ` : ''}
                        </div>`}

                <button class="rb-send"
                    ?disabled=${this.sent || this.sending || !this.description.trim() || !this.selectedThreadId}
                    @click=${() => this.onSend()}>${this.sending ? this.msg.sending : this.msg.send}</button>
                ${this.sent ? html `<div class="rb-sent">${this.msg.sent}</div>` : ''}
                ${this.sendError ? html `<div class="rb-send-error">${this.msg.sendFailed}: ${this.sendError}</div>` : ''}
            </div>

            ${this.renderDataSections(s)}
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.viewData) {
            return html `<div class="rb-root">${this.renderView(this.viewData)}</div>`;
        }
        return html `
            <div class="rb-root">
                ${this.viewError ? html `<div class="rb-send-error">${this.msg.viewInvalid}</div>` : ''}
                ${this.snapshot ? this.renderSnapshot(this.snapshot) : this.renderEmpty()}
            </div>
        `;
    }
};
__decorate([
    state()
], ServiceReportBug100554.prototype, "snapshot", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "description", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "sent", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "sending", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "sendError", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "destinations", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "selectedThreadId", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "destinationFilter", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "showSuggestions", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "highlightedIndex", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "viewData", void 0);
__decorate([
    state()
], ServiceReportBug100554.prototype, "viewError", void 0);
ServiceReportBug100554 = __decorate([
    customElement('service-report-bug-100554')
], ServiceReportBug100554);
export { ServiceReportBug100554 };
