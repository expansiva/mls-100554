/// <mls fileReference="_100554_/l2/collabTabSlider.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let PluginCreateProject = class PluginCreateProject extends StateLitElement {
    constructor() {
        super(...arguments);
        this.activeIndex = 0;
        this.animationTimer = 800;
        this.previousIndex = -1;
    }
    updated(changedProps) {
        if (changedProps.has('animationTimer')) {
            this.style.setProperty('--animation-timer', `${this.animationTimer}ms`);
        }
        if (changedProps.has('activeIndex')) {
            this.switchTab(this.activeIndex);
        }
    }
    switchTab(index) {
        if (index === this.previousIndex)
            return;
        const goingRight = index > this.previousIndex;
        const children = Array.from(this.children);
        const currentEl = children[this.previousIndex];
        const nextEl = children[index];
        if (!nextEl)
            return;
        nextEl.classList.remove('tab-exit-left', 'tab-exit-right', 'tab-active');
        nextEl.classList.add(goingRight ? 'tab-enter-right' : 'tab-enter-left');
        nextEl.getBoundingClientRect();
        if (currentEl) {
            currentEl.classList.add(goingRight ? 'tab-exit-left' : 'tab-exit-right');
            currentEl.classList.remove('tab-active');
        }
        nextEl.classList.add('tab-active');
        nextEl.classList.remove('tab-enter-left', 'tab-enter-right');
        setTimeout(() => {
            if (currentEl)
                currentEl.classList.remove('tab-exit-left', 'tab-exit-right');
        }, this.animationTimer);
        this.previousIndex = index;
    }
    render() {
        return html ``;
    }
};
__decorate([
    property({ type: Number })
], PluginCreateProject.prototype, "activeIndex", void 0);
__decorate([
    property({ type: Number })
], PluginCreateProject.prototype, "animationTimer", void 0);
PluginCreateProject = __decorate([
    customElement('collab-tab-slider-100554')
], PluginCreateProject);
export { PluginCreateProject };
