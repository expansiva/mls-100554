/// <mls fileReference="_100554_/l2/collabTabSlider.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
let PluginCreateProject = class extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-tab-slider-100554 {
  display: block;
  overflow: hidden;
}
collab-tab-slider-100554 .tab-content {
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
  transition: transform var(--animation-timer, 800ms) ease, opacity var(--animation-timer, 800ms) ease;
  opacity: 0;
  pointer-events: none;
  transform: translateX(0);
}
collab-tab-slider-100554 .tab-active {
  opacity: 1;
  pointer-events: auto;
  z-index: 2;
}
collab-tab-slider-100554 .tab-exit-left {
  transform: translateX(-100%);
  opacity: 0;
}
collab-tab-slider-100554 .tab-exit-right {
  transform: translateX(100%);
  opacity: 0;
}
collab-tab-slider-100554 .tab-enter-left {
  transform: translateX(-100%);
  opacity: 1;
  z-index: 2;
}
collab-tab-slider-100554 .tab-enter-right {
  transform: translateX(100%);
  opacity: 1;
  z-index: 2;
}
`);
    }
  activeIndex = 0;
  animationTimer = 800;
  previousIndex = -1;
  updated(changedProps) {
    if (changedProps.has("animationTimer")) {
      this.style.setProperty("--animation-timer", `${this.animationTimer}ms`);
    }
    if (changedProps.has("activeIndex")) {
      this.switchTab(this.activeIndex);
    }
  }
  switchTab(index) {
    if (index === this.previousIndex) return;
    const goingRight = index > this.previousIndex;
    const children = Array.from(this.children);
    const currentEl = children[this.previousIndex];
    const nextEl = children[index];
    if (!nextEl) return;
    nextEl.classList.remove("tab-exit-left", "tab-exit-right", "tab-active");
    nextEl.classList.add(goingRight ? "tab-enter-right" : "tab-enter-left");
    nextEl.getBoundingClientRect();
    if (currentEl) {
      currentEl.classList.add(goingRight ? "tab-exit-left" : "tab-exit-right");
      currentEl.classList.remove("tab-active");
    }
    nextEl.classList.add("tab-active");
    nextEl.classList.remove("tab-enter-left", "tab-enter-right");
    setTimeout(() => {
      if (currentEl) currentEl.classList.remove("tab-exit-left", "tab-exit-right");
    }, this.animationTimer);
    this.previousIndex = index;
  }
  render() {
    return html``;
  }
};
__decorateClass([
  property({ type: Number })
], PluginCreateProject.prototype, "activeIndex", 2);
__decorateClass([
  property({ type: Number })
], PluginCreateProject.prototype, "animationTimer", 2);
PluginCreateProject = __decorateClass([
  customElement("collab-tab-slider-100554")
], PluginCreateProject);
export {
  PluginCreateProject
};
