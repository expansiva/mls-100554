/// <mls fileReference="_100554_/l2/collabFileSystemAccess.ts" enhancement="_100554_/l2/enhancementLit" />
const DB_NAME = 'collabFileSystem100554';
const DB_VERSION = 1;
const STORE_HANDLES = 'directoryHandles';
export class FileSystemAccessAdapter {
    isSupported() {
        return typeof window !== 'undefined' && typeof window.showDirectoryPicker === 'function' && typeof indexedDB !== 'undefined';
    }
    async showDirectoryPicker() {
        if (!window.showDirectoryPicker)
            throw new Error('File System Access API is not available in this browser.');
        return window.showDirectoryPicker({ mode: 'readwrite' });
    }
    async ensurePermission(handle, mode = 'readwrite') {
        const descriptor = { mode };
        if (handle.queryPermission && await handle.queryPermission(descriptor) === 'granted')
            return true;
        if (!handle.requestPermission)
            return false;
        return await handle.requestPermission(descriptor) === 'granted';
    }
    async saveHandle(project, handle) {
        const db = await this.openDB();
        try {
            const tx = db.transaction(STORE_HANDLES, 'readwrite');
            const done = this.transactionDone(tx);
            const store = tx.objectStore(STORE_HANDLES);
            await this.requestToPromise(store.put({
                key: this.getProjectKey(project),
                project,
                handle,
                name: handle.name,
                updatedAt: new Date().toISOString(),
            }));
            await done;
        }
        finally {
            db.close();
        }
    }
    async getHandle(project) {
        const db = await this.openDB();
        try {
            const tx = db.transaction(STORE_HANDLES, 'readonly');
            const store = tx.objectStore(STORE_HANDLES);
            const result = await this.requestToPromise(store.get(this.getProjectKey(project)));
            return result?.handle || null;
        }
        finally {
            db.close();
        }
    }
    async listTextFiles(directory, onProgress, options = {}) {
        const files = [];
        await this.walkTextFiles(directory, '', files, onProgress, options);
        files.sort((a, b) => a.path.localeCompare(b.path));
        return files;
    }
    async readTextFile(directory, path) {
        const handle = await this.getFileHandleByPath(directory, path, false);
        if (!handle)
            return null;
        const file = await handle.getFile();
        return file.text();
    }
    async writeTextFile(directory, path, content) {
        this.assertSafePath(path);
        const handle = await this.getFileHandleByPath(directory, path, true);
        if (!handle)
            throw new Error(`Unable to create file ${path}`);
        const writable = await handle.createWritable();
        await writable.write(content);
        await writable.close();
    }
    async removeFile(directory, path) {
        this.assertSafePath(path);
        const parts = path.split('/').filter(Boolean);
        if (parts.length < 1)
            return;
        const fileName = parts.pop();
        if (!fileName)
            return;
        let current = directory;
        for (const part of parts) {
            current = await current.getDirectoryHandle(part);
        }
        await current.removeEntry(fileName, { recursive: false });
    }
    async walkTextFiles(directory, prefix, files, onProgress, options = {}) {
        for await (const [name, handle] of directory.entries()) {
            if (handle.kind === 'directory') {
                if (this.shouldIgnoreDirectory(name))
                    continue;
                await this.walkTextFiles(handle, prefix ? `${prefix}/${name}` : name, files, onProgress, options);
                continue;
            }
            const path = prefix ? `${prefix}/${name}` : name;
            if (this.shouldIgnoreFile(path))
                continue;
            const file = await handle.getFile();
            files.push({
                path,
                content: options.readContent ? await file.text() : undefined,
                size: file.size,
                lastModified: file.lastModified,
            });
            onProgress?.({ current: files.length, path });
        }
    }
    async getFileHandleByPath(directory, path, create) {
        this.assertSafePath(path);
        const parts = path.split('/').filter(Boolean);
        if (parts.length < 1)
            return null;
        const fileName = parts.pop();
        if (!fileName)
            return null;
        let current = directory;
        for (const part of parts) {
            current = await current.getDirectoryHandle(part, { create });
        }
        return current.getFileHandle(fileName, { create });
    }
    assertSafePath(path) {
        const parts = path.split('/');
        if (!path || path.startsWith('/') || path.includes('\\') || parts.some((part) => part === '..' || part === '')) {
            throw new Error(`Unsafe local path: ${path}`);
        }
    }
    shouldIgnoreDirectory(name) {
        return name === '.git' ||
            name === 'node_modules' ||
            name === 'dist' ||
            name === 'distFrontend' ||
            name === '.cache';
    }
    shouldIgnoreFile(path) {
        const name = path.split('/').pop() || '';
        return name === '.DS_Store' || name.endsWith('.tmp') || name.endsWith('~');
    }
    getProjectKey(project) {
        return `project:${project}`;
    }
    openDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = () => {
                const db = request.result;
                if (!db.objectStoreNames.contains(STORE_HANDLES))
                    db.createObjectStore(STORE_HANDLES, { keyPath: 'key' });
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    requestToPromise(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    transactionDone(tx) {
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error);
        });
    }
}
