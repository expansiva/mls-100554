/// <mls fileReference="_100554_/l2/collabFileSystemAccess.ts" enhancement="_100554_/l2/enhancementLit" />
const DB_NAME = 'collabFileSystem100554';
const TRASH_DIR = '.collab-fs-trash';
const DB_VERSION = 1;
const STORE_HANDLES = 'directoryHandles';
const BASE_HANDLE_KEY = 'base:mls-base';
export class FileSystemAccessAdapter {
    isSupported() {
        return typeof window !== 'undefined' && typeof window.showDirectoryPicker === 'function' && typeof indexedDB !== 'undefined';
    }
    async showDirectoryPicker() {
        if (!window.showDirectoryPicker)
            throw new Error('File System Access API is not available in this browser.');
        return window.showDirectoryPicker({ mode: 'readwrite' });
    }
    async ensurePermission(handle, mode = 'readwrite') {
        const descriptor = { mode };
        if (handle.queryPermission && await handle.queryPermission(descriptor) === 'granted')
            return true;
        if (!handle.requestPermission)
            return false;
        return await handle.requestPermission(descriptor) === 'granted';
    }
    async saveHandle(project, handle) {
        const db = await this.openDB();
        try {
            const tx = db.transaction(STORE_HANDLES, 'readwrite');
            const done = this.transactionDone(tx);
            const store = tx.objectStore(STORE_HANDLES);
            await this.requestToPromise(store.put({
                key: this.getProjectKey(project),
                project,
                handle,
                name: handle.name,
                updatedAt: new Date().toISOString(),
            }));
            await done;
        }
        finally {
            db.close();
        }
    }
    async saveBaseHandle(handle) {
        const db = await this.openDB();
        try {
            const tx = db.transaction(STORE_HANDLES, 'readwrite');
            const done = this.transactionDone(tx);
            const store = tx.objectStore(STORE_HANDLES);
            await this.requestToPromise(store.put({
                key: BASE_HANDLE_KEY,
                handle,
                name: handle.name,
                updatedAt: new Date().toISOString(),
            }));
            await done;
        }
        finally {
            db.close();
        }
    }
    async getBaseHandle() {
        const db = await this.openDB();
        try {
            const tx = db.transaction(STORE_HANDLES, 'readonly');
            const store = tx.objectStore(STORE_HANDLES);
            const result = await this.requestToPromise(store.get(BASE_HANDLE_KEY));
            return result?.handle || null;
        }
        finally {
            db.close();
        }
    }
    async removeHandle(project) {
        const db = await this.openDB();
        try {
            const tx = db.transaction(STORE_HANDLES, 'readwrite');
            const done = this.transactionDone(tx);
            tx.objectStore(STORE_HANDLES).delete(this.getProjectKey(project));
            await done;
        }
        finally {
            db.close();
        }
    }
    async getHandle(project) {
        const db = await this.openDB();
        try {
            const tx = db.transaction(STORE_HANDLES, 'readonly');
            const store = tx.objectStore(STORE_HANDLES);
            const result = await this.requestToPromise(store.get(this.getProjectKey(project)));
            return result?.handle || null;
        }
        finally {
            db.close();
        }
    }
    async listTextFiles(directory, onProgress, options = {}) {
        const files = [];
        await this.walkTextFiles(directory, '', files, onProgress, options);
        files.sort((a, b) => a.path.localeCompare(b.path));
        return files;
    }
    async readTextFile(directory, path) {
        const handle = await this.getFileHandleByPath(directory, path, false);
        if (!handle)
            return null;
        const file = await handle.getFile();
        return file.text();
    }
    async readFileContent(directory, path) {
        const handle = await this.getFileHandleByPath(directory, path, false);
        if (!handle)
            return null;
        const file = await handle.getFile();
        if (this.shouldReadAsText(path))
            return file.text();
        return file;
    }
    async writeFile(directory, path, content) {
        this.assertSafePath(path);
        const handle = await this.getFileHandleByPath(directory, path, true);
        if (!handle)
            throw new Error(`Unable to create file ${path}`);
        const writable = await handle.createWritable();
        await writable.write(content);
        await writable.close();
        const file = await handle.getFile();
        return {
            path,
            content: undefined,
            size: file.size,
            lastModified: file.lastModified,
        };
    }
    async writeTextFile(directory, path, content) {
        await this.writeFile(directory, path, content);
    }
    async removeFile(directory, path) {
        this.assertSafePath(path);
        const parts = path.split('/').filter(Boolean);
        if (parts.length < 1)
            return;
        const fileName = parts.pop();
        if (!fileName)
            return;
        let current = directory;
        for (const part of parts) {
            current = await current.getDirectoryHandle(part);
        }
        await current.removeEntry(fileName, { recursive: false });
        await this.removeEmptyParentDirectories(directory, parts);
    }
    // Backs up the file under .collab-fs-trash before deleting, so a Pull is reversible.
    async trashFile(directory, path, trashFolder) {
        this.assertSafePath(path);
        const handle = await this.getFileHandleByPath(directory, path, false);
        if (!handle)
            return;
        const file = await handle.getFile();
        const content = this.shouldReadAsText(path) ? await file.text() : file;
        await this.writeFile(directory, `${trashFolder}/${path}`, content);
        await this.removeFile(directory, path);
    }
    async walkTextFiles(directory, prefix, files, onProgress, options = {}) {
        for await (const [name, handle] of directory.entries()) {
            if (handle.kind === 'directory') {
                if (this.shouldIgnoreDirectory(name))
                    continue;
                await this.walkTextFiles(handle, prefix ? `${prefix}/${name}` : name, files, onProgress, options);
                continue;
            }
            const path = prefix ? `${prefix}/${name}` : name;
            if (this.shouldIgnoreFile(path))
                continue;
            const file = await handle.getFile();
            files.push({
                path,
                content: options.readContent ? (this.shouldReadAsText(path) ? await file.text() : file) : undefined,
                size: file.size,
                lastModified: file.lastModified,
            });
            onProgress?.({ current: files.length, path });
        }
    }
    async getFileHandleByPath(directory, path, create) {
        this.assertSafePath(path);
        const parts = path.split('/').filter(Boolean);
        if (parts.length < 1)
            return null;
        const fileName = parts.pop();
        if (!fileName)
            return null;
        let current = directory;
        for (const part of parts) {
            current = await current.getDirectoryHandle(part, { create });
        }
        return current.getFileHandle(fileName, { create });
    }
    async removeEmptyParentDirectories(directory, parts) {
        for (let depth = parts.length; depth > 1; depth--) {
            const dirName = parts[depth - 1];
            const parent = await this.getDirectoryHandleByParts(directory, parts.slice(0, depth - 1));
            if (!parent)
                return;
            const child = await this.getDirectoryHandle(parent, dirName);
            if (!child)
                return;
            if (!await this.isDirectoryEmpty(child))
                return;
            await parent.removeEntry(dirName, { recursive: false }).catch(() => undefined);
        }
    }
    async getDirectoryHandleByParts(directory, parts) {
        let current = directory;
        for (const part of parts) {
            const next = await this.getDirectoryHandle(current, part);
            if (!next)
                return null;
            current = next;
        }
        return current;
    }
    async getDirectoryHandle(directory, name) {
        return directory.getDirectoryHandle(name, { create: false }).catch(() => null);
    }
    async isDirectoryEmpty(directory) {
        for await (const _entry of directory.entries())
            return false;
        return true;
    }
    assertSafePath(path) {
        const parts = path.split('/');
        if (!path || path.startsWith('/') || path.includes('\\') || parts.some((part) => part === '..' || part === '')) {
            throw new Error(`Unsafe local path: ${path}`);
        }
    }
    shouldIgnoreDirectory(name) {
        return name === TRASH_DIR ||
            name === '.git' ||
            name === '.github' ||
            name === 'node_modules' ||
            name === 'dist' ||
            name === 'distFrontend' ||
            name === '.cache';
    }
    shouldIgnoreFile(path) {
        const name = path.split('/').pop() || '';
        return name === '.DS_Store' || name === '.gitignore' || name.endsWith('.tmp') || name.endsWith('~');
    }
    shouldReadAsText(path) {
        return /\.(defs\.ts|test\.ts|tsx|ts|html|less|css|json|md|mjs|js|jsx|vue|sql|txt|yml|yaml|style|svg)$/i.test(path);
    }
    getProjectKey(project) {
        return `project:${project}`;
    }
    openDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(DB_NAME, DB_VERSION);
            request.onupgradeneeded = () => {
                const db = request.result;
                if (!db.objectStoreNames.contains(STORE_HANDLES))
                    db.createObjectStore(STORE_HANDLES, { keyPath: 'key' });
            };
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    requestToPromise(request) {
        return new Promise((resolve, reject) => {
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
    transactionDone(tx) {
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error);
        });
    }
}
