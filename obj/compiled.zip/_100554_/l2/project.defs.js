/// <mls fileReference="_100554_/l2/project.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/project.ts",
        "componentType": "other",
        "componentScope": "editor",
        "group": "enhancement"
    },
    "asIs": {
        "semantic": {
            "generalDescription": "Exports projectConfig with empty modules array.",
            "businessCapabilities": [],
            "technicalCapabilities": [],
            "implementedFeatures": []
        }
    }
};
