/// <mls shortName="pluginExploreListAddL2" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { convertFileNameToTag } from '/_100554_/l2/utilsLit.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { propertyDataSource } from '/_100554_/l2/collabDecorators.js';
import { setState, initState } from '/_100554_/l2/collabState.js';
import { loadPluginProject, isNameValid } from '/_100554_/l2/libCommom.js';
/// **collab_i18n_start**
const message_pt = {
    labelProject: "Projeto",
    labelShortName: "Nome",
    invalidName: "Nome invalido",
    labelType: "Por favor, selecione um modelo abaixo",
    btnAdd: "Adicionar",
    please: "Por facor selecione um projeto primeiro!",
    msgInitial: "Por favor, selecione um modelo",
};
const message_en = {
    labelProject: "Project",
    labelShortName: "Shortname",
    invalidName: "Invalid shortName",
    labelType: "Please select a template below",
    btnAdd: "Add",
    please: "Please select a project first!",
    msgInitial: "Please select a template",
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceListFilesAdd100554 = class ServiceListFilesAdd100554 extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-explore-list-add-l2-100554{overflow-y:auto;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-explore-list-add-l2-100554 .headerNav{height:40px;background:var(--bg-primary-color-darker-hover);border-bottom:1px solid var(--bg-primary-color-lighter);display:flex;align-items:center;justify-content:center;position:relative;box-shadow:0 1px 3px var(--bg-primary-color-lighter)}plugin-explore-list-add-l2-100554 .headerNav h1{font-size:16px;font-weight:500;color:var(--text-primary-color);margin:0;pointer-events:none}plugin-explore-list-add-l2-100554 .headerNav .btn-nav{position:absolute;top:50%;transform:translateY(-50%);border:none;background-color:var(--grey-color-darker);color:var(--text-primary-color);width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s}plugin-explore-list-add-l2-100554 .headerNav.left .btn-nav{left:10px}plugin-explore-list-add-l2-100554 .headerNav.right .btn-nav{right:10px}plugin-explore-list-add-l2-100554 .headerNav .btn-nav:hover{opacity:.5}plugin-explore-list-add-l2-100554 .headerNav .btn-nav svg{width:14px;height:14px;fill:#fff}plugin-explore-list-add-l2-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}plugin-explore-list-add-l2-100554 button:hover{background-color:var(--grey-color-light)}plugin-explore-list-add-l2-100554 input,plugin-explore-list-add-l2-100554 select,plugin-explore-list-add-l2-100554 textarea{display:block;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}plugin-explore-list-add-l2-100554 .section-add{padding:0 1rem}plugin-explore-list-add-l2-100554 .row-form{display:flex;gap:.5rem}plugin-explore-list-add-l2-100554 .row-form button{display:inline-block;width:80px;height:25px;padding:0;text-align:center}plugin-explore-list-add-l2-100554 .row-form span{color:var(--error-color);width:100px;top:-5px;font-size:12px}plugin-explore-list-add-l2-100554 .row-form .btn-cancel:hover{color:var(--error-color)}plugin-explore-list-add-l2-100554 .template-container{display:flex;flex-wrap:wrap;justify-content:space-around;margin:auto;margin-top:1rem}plugin-explore-list-add-l2-100554 .template-container:hover .template-item:not(:hover){opacity:.5}plugin-explore-list-add-l2-100554 .template-container .template-item{flex:1 1 500px;margin:10px;box-shadow:0 4px 8px 0 rgba(0,0,0,0.2);transition:.3s;cursor:pointer}plugin-explore-list-add-l2-100554 .template-container .template-item:hover{background-color:var(--grey-color-light)}plugin-explore-list-add-l2-100554 .template-container .template-item .template-item-content{padding:20px}plugin-explore-list-add-l2-100554 .template-container .template-item .template-item-content .template-item-title{font-weight:bold;font-size:var(--font-size-24)}plugin-explore-list-add-l2-100554 .template-container .template-item .template-item-content .template-item-body{text-align:justify;font-size:var(--font-size-16)}plugin-explore-list-add-l2-100554 .template-container .template-item .template-item-content .template-item-tags{font-size:var(--font-size-12);text-transform:uppercase;font-weight:bold}plugin-explore-list-add-l2-100554 input,plugin-explore-list-add-l2-100554 select,plugin-explore-list-add-l2-100554 textarea{outline:none}`);
        this.baseProject = 100554;
        this.msg = messages['en'];
        this.level = -1;
        this.error = '';
        this.position = '';
        this.plugins = [];
        this.loading = true;
    }
    async connectedCallback() {
        super.connectedCallback();
        initState('l2.addFile', { shortName: '', project: 0, folder: '' });
        setState('l2.addFile.shortName', '');
        setState('l2.addFile.folder', '');
        await this.init();
    }
    async init() {
        const plugins = await this.getPlugins();
        this.plugins = await this.getPluginsInfo(plugins);
        this.loading = false;
    }
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        const options = {
            shortName: '',
            project: '',
            htmlText: `<div>${this.msg.msgInitial}</div>`
        };
        mls.events.fire(2, 'PluginDetails', JSON.stringify(options), 0);
    }
    render() {
        const lang = this.father?.getMessageKey(messages);
        this.msg = lang ? messages[lang] : message_en;
        const project = mls.actualProject || 0;
        setState('l2.addFile.project', project);
        return html `
            ${this.renderHeader()}
            ${project !== undefined ? this.renderAdd(project)
            : html `${this.msg.please}`}
        `;
    }
    renderHeader() {
        return html `
            <div class="headerNav left">
                <h1>Add</h1>
                <button class="btn-nav" title="add organism" @click="${() => this.clickCancel()}">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg>
                </button>            
            </div>
        `;
    }
    renderAdd(project) {
        return html `
            <div class="section-add">
                <div class="row-form">
                    <div>
                        <label>${this.msg.labelProject}:</label>
                        <input type="text" disabled value="${project.toString()}"/>
                    </div>
                    <div>
                        <label>${this.msg.labelShortName}:</label>
                        <input autocomplete="off" value=${this.shortName} type="text" id="iptShortName" @input=${this.handleInputInput}/>
                        <span>${this.error}</span>
                    </div>
                </div>
                <hr>
                <div class="row-form">
                    <div>
                        <label>${this.msg.labelType}</label>
                         ${this.renderTemplates()}
                    </div>
                </div>
            </div>

        `;
    }
    renderTemplates() {
        return html `
            <div class="template-container">
             ${this.loading
            ? html `<p>Loading...</p>`
            :
                this.plugins.map((template) => {
                    return html `
                        <div  class="template-item" @click=${() => { this.handleClickTemplate(template); }}>
                            <div class="template-item-content">
                                <div class="template-item-title">${template.title}</div>
                                <div class="template-item-body">
                                    ${template.description.split('\n').map((paragraph) => html `
                                        <p>${paragraph}</p>
                                    `)}
                                </div>
                                <div class="template-item-tags">
                                        Tags: ${template.tags.join(', ')}
                                </div>
                            </div>
                        </div>
                    `;
                })}
            </div>
        `;
    }
    goBack() {
        if (!this.father)
            return;
        this.father.mode = 'list';
    }
    handleInputInput(e) {
        const target = e.target;
        if (!target)
            return;
        const project = mls.actualProject;
        if (project === undefined)
            throw new Error('No project selected');
        const name = this.inputShortName?.value || '';
        this.error = '';
        const isValidName = this.getNewNameAndValid(project, name);
        if (!isValidName) {
            this.error = this.msg.invalidName;
            return;
        }
        const info = mls.l2.getPath(`_${project}_${target.value}`);
        setState('l2.addFile.folder', info.folder);
        setState('l2.addFile.shortName', info.shortName);
    }
    handleClickTemplate(plugin) {
        const { project, shortName, folder } = mls.l2.getPath(plugin.widget);
        const tag = convertFileNameToTag({ project, shortName, folder });
        const options = {
            shortName,
            project,
            folder,
            htmlText: `<${tag} position=${this.position} project="{{ l2.addFile.project }}" shortName="{{ l2.addFile.shortName }}" folder="{{ l2.addFile.folder }}"></${tag}>`
        };
        mls.events.fire(2, 'PluginDetails', JSON.stringify(options), 0);
    }
    //--------------- IMPLEMENTS----------------
    clickCancel() {
        if (!this.father)
            return;
        const options = {
            shortName: '',
            project: '',
            htmlText: `<div></div>`
        };
        mls.events.fire(2, 'PluginDetails', JSON.stringify(options), 0);
        this.father.mode = 'list';
    }
    getNewNameAndValid(prj, name) {
        if (name === '' || !name || name === null)
            return false;
        if (/\s/.test(name))
            return false;
        if (/^\d+$/.test(name))
            return false;
        if (/^\d/.test(name))
            return false;
        const split = name.split('/');
        return isNameValid(prj, split.pop() || name, split.length > 0 ? split.join('/') : '', +this.level, '.ts');
        /*const isValidName = this.isValidNewName({
            shortName: split.pop() || name,
            project: prj,
            level: +this.level,
            folder: split.length > 0 ? split.join('/') : '',
            extension: '.ts'
        });
        if (!isValidName || this.hasInvalidCharacter(name)) return false;
        return true;*/
    }
    hasInvalidCharacter(name) {
        const invalidCharacters = /[_\{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        if (invalidCharacters.test(name) || name.indexOf("\\") >= 0)
            return true;
        return false;
    }
    isValidNewName(obj) {
        if (obj.shortName === '')
            return false;
        if (obj.shortName.length === 0 || obj.shortName.length > 255)
            return false;
        const invalidCharacters = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
        if (invalidCharacters.test(obj.shortName))
            return false;
        const key = mls.stor.getKeyToFiles(obj.project, obj.level, obj.shortName, obj.folder, obj.extension);
        let find = false;
        const keys = Object.keys(mls.stor.files);
        for (const k of keys) {
            if (key.toLocaleLowerCase() === k.toLocaleLowerCase())
                find = true;
        }
        return !mls.stor.files[key] && !find;
    }
    async getPlugins() {
        let project = mls.actualProject;
        return await loadPluginProject(project || 0, 'l2NewFile');
    }
    async getPluginsInfo(plugins) {
        const rc = [];
        for await (const plugin of plugins) {
            const instance = await import(`/${plugin.widget}`);
            if (!instance.details ||
                typeof instance.details !== 'object' ||
                !['title', 'description', 'tags'].every(prop => prop in instance.details))
                continue;
            const details = instance.details;
            const item = {
                ...details,
                widget: plugin.widget,
                category: plugin.category,
            };
            rc.push(item);
        }
        return rc;
    }
};
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "level", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "error", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "position", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "father", void 0);
__decorate([
    property()
], ServiceListFilesAdd100554.prototype, "plugins", void 0);
__decorate([
    property({ type: Boolean, })
], ServiceListFilesAdd100554.prototype, "loading", void 0);
__decorate([
    propertyDataSource()
], ServiceListFilesAdd100554.prototype, "shortName", void 0);
__decorate([
    query('#iptShortName')
], ServiceListFilesAdd100554.prototype, "inputShortName", void 0);
ServiceListFilesAdd100554 = __decorate([
    customElement('plugin-explore-list-add-l2-100554')
], ServiceListFilesAdd100554);
export { ServiceListFilesAdd100554 };
