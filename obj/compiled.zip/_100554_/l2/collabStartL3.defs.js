const asis = {
  "meta": {
    "fileReference": "_100554_/l2/collabStartL3.ts",
    "componentType": "page",
    "componentScope": "appFrontEnd",
    "languages": [
      "en",
      "pt"
    ],
    "group": "enhancement"
  },
  "references": {
    "imports": [
      {
        "ref": "lit",
        "dependencies": [
          {
            "name": "html",
            "type": "function"
          }
        ]
      },
      {
        "ref": "lit/decorators.js",
        "dependencies": [
          {
            "name": "customElement",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/stateLitElement.js",
        "dependencies": [
          {
            "name": "StateLitElement",
            "type": "class"
          }
        ]
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "L3 Design System Start Page",
      "businessCapabilities": [
        "Selecionar Componentes de Interface (Widgets)",
        "Selecionar ou Criar Interfaces de Componentes e P\xE1ginas (CSS)",
        "Selecionar \xCDcones e Imagens",
        "Editar Documenta\xE7\xE3o do Projeto",
        "Ajustar Layout e visual da P\xE1gina"
      ],
      "technicalCapabilities": [
        "Lit",
        "TypeScript",
        "i18n"
      ],
      "implementedFeatures": [
        "Render banner image",
        "Render details about the module",
        "Render news section",
        "Render collab marca image"
      ]
    }
  }
};
export {
  asis
};
