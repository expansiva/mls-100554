/// <mls fileReference="_100554_/l2/pluginNewFileWebComponent.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getMessageKey } from "/_100554_/l2/collabLitElement.js";
import { propertyDataSource } from '/_100554_/l2/collabDecorators.js';
import { createNewFile, changeTagName, changeClassName, changeWidget, getTemplateImport } from "/_100554_/l2/pluginNewFileBase.js";
import '/_100554_/l2/widgetTextCode.js';
/// **collab_i18n_start**
const message_pt = {
    title: 'Criar um web component em lit',
    description: "Criar um web component em lit 3 ,que será utilizado em páginas.\n O Lit é um framework para criar web componentes rápidos e com atualizações dinâmicas sem ter que repintar toda a tela.\n Após criar o arquivo use a inteligência artificial para preparar o web component.",
    project: "Projeto",
    shortName: "Nome",
    header: "Criar um web component em Lit",
    btnCreate: 'Criar arquivo',
    loading: 'Criando arquivo...',
    error: 'Nome do arquivo em branco ou invalido'
};
const message_en = {
    title: 'Create a web component in Lit',
    description: "Create a web component in Lit 3 that will be used on pages.\n Lit is a framework for creating fast web components with dynamic updates without repainting the entire screen.\n After creating the file, use artificial intelligence to prepare the web component.",
    project: "Project",
    shortName: "ShortName",
    header: "Create a web component in Lit",
    btnCreate: 'Create file',
    loading: 'Creating File...',
    error: 'Blank or invalid file name'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
let msg = messages[lang];
export const details = {
    title: msg.title,
    description: msg.description,
    tags: ["lit", "html", "component"],
};
let PluginNewFileWebComponent = class PluginNewFileWebComponent extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-new-file-web-component-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-new-file-web-component-100554 widget-text-code-100554{font-size:var(--font-size-12)}plugin-new-file-web-component-100554 button{background-color:var(--active-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#fff;cursor:pointer}plugin-new-file-web-component-100554 button:hover{background-color:var(--active-color-hover)}`);
    }
    shortName;
    project;
    folder;
    position = 'left';
    loading = false;
    aimActionSuggest = '_100554_aimActionAddIca';
    service = this.closest('service-detail-100554');
    template = `
 import { html } from 'lit'; 
 import { customElement, property } from 'lit/decorators.js';
 import { StateLitElement } from '${getTemplateImport(100554, 'stateLitElement', '')}';

 @customElement('[tagName]')
 export class [className] extends StateLitElement {
    
     @property() name: string = 'Somebody';

     render() {
         return html\`<p> Hello, \${ this.name } !</p>\`;
     }
 }`;
    enhancement = `_100554_enhancementLit`;
    groupName = `other`;
    getTemplate() {
        let newExample = this.template;
        if (this.shortName && this.project) {
            newExample = changeTagName(newExample, convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder }));
            newExample = changeClassName(newExample, this.project, this.shortName);
            newExample = changeWidget(newExample, this.project, this.shortName);
        }
        const group = this.groupName && this.groupName != 'other' ? ` groupName="${this.groupName}"` : '';
        const enhancement = this.enhancement ? this.enhancement : '_blank';
        const folder = this.folder ? `${this.folder}/` : '';
        const name = `_${this.project}_/l2/${folder}${this.shortName}.ts`;
        return `/// <mls fileReference="${name}" enhancement="${enhancement}"${group}/>\n${newExample}\n`;
    }
    async handleAddFile() {
        if (!this.project || !this.shortName) {
            this.service.setError(msg.error);
            return;
        }
        ;
        this.loading = true;
        try {
            await createNewFile({
                project: this.project,
                position: this.position,
                shortName: this.shortName,
                folder: this.folder,
                enhancement: this.enhancement,
                sourceTS: this.getTemplate(),
                openPreview: true
            });
        }
        catch (e) {
            this.loading = false;
        }
    }
    render() {
        return html `
            ${this.loading ?
            html `<div>${msg.loading}</div>`
            :
                html `   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>

                    <widget-text-code-100554 language="typescript" text="${this.getTemplate()}"></widget-text-code-100554>
                
                </div>`}
        `;
    }
};
__decorate([
    propertyDataSource()
], PluginNewFileWebComponent.prototype, "shortName", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFileWebComponent.prototype, "project", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFileWebComponent.prototype, "folder", void 0);
__decorate([
    property()
], PluginNewFileWebComponent.prototype, "position", void 0);
__decorate([
    property()
], PluginNewFileWebComponent.prototype, "loading", void 0);
__decorate([
    property()
], PluginNewFileWebComponent.prototype, "aimActionSuggest", void 0);
PluginNewFileWebComponent = __decorate([
    customElement('plugin-new-file-web-component-100554')
], PluginNewFileWebComponent);
export { PluginNewFileWebComponent };
