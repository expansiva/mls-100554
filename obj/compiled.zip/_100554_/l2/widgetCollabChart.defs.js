/// <mls fileReference="_100554_/l2/widgetCollabChart.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/widgetCollabChart.ts",
        "componentType": "molecule",
        "componentScope": "appFrontEnd",
        "group": "enhancement"
    },
    "references": {
        "webComponents": [
            "widget-collab-chart-100554"
        ],
        "imports": [
            {
                "ref": "lit",
                "dependencies": [
                    {
                        "name": "html"
                    },
                    {
                        "name": "LitElement"
                    }
                ]
            },
            {
                "ref": "lit/decorators.js",
                "dependencies": [
                    {
                        "name": "customElement"
                    },
                    {
                        "name": "property"
                    },
                    {
                        "name": "query"
                    }
                ]
            },
            {
                "ref": "/_102029_/l2/collabDecorators.js",
                "dependencies": [
                    {
                        "name": "propertyDataSource"
                    }
                ]
            },
            {
                "ref": "/_102029_/l2/stateLitElement.js",
                "dependencies": [
                    {
                        "name": "StateLitElement"
                    }
                ]
            }
        ]
    },
    "asIs": {
        "semantic": {
            "generalDescription": "ECharts Pie Chart Widget",
            "businessCapabilities": [],
            "technicalCapabilities": [],
            "implementedFeatures": [],
            "constraints": []
        }
    }
};
