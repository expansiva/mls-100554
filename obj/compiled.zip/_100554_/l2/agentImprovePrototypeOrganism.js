import { svg_agent } from "/_100554_/l2/aiAgentBase.js";
import { getPromptByHtml } from "/_100554_/l2/aiPrompts.js";
import { createAllModels } from "/_100554_/l2/collabLibModel.js";
import { getImages } from "/_100554_/l2/libUnsplash.js";
import { getTokensLess, getGlobalLess } from "/_100554_/l2/designSystemBase.js";
import { removeTokensFromSource } from "/_102027_/l2/libCompileStyle.js";
import { forceServiceInstance } from "/_100554_/l2/libCommom.js";
import { getState } from "/_100554_/l2/collabState.js";
import {
  getNextPendingStepByAgentName,
  getNextInProgressStepByAgentName,
  getNextFlexiblePendingStep,
  appendLongTermMemory,
  updateTaskTitle,
  updateStepStatus
} from "/_100554_/l2/aiAgentHelper.js";
import {
  startNewInteractionInAiTask,
  startNewAiTask,
  executeNextStep,
  addNewStep
} from "/_100554_/l2/aiAgentOrchestration.js";
const agentName = "agentImprovePrototypeOrganism";
const project = 100554;
function createAgent() {
  return {
    agentName,
    avatar_url: svg_agent,
    agentDescription: "Agent for prototype improve on organism",
    visibility: "public",
    scope: ["l3_preview"],
    async beforePrompt(context) {
      return _beforePrompt(context);
    },
    async afterPrompt(context) {
      return _afterPrompt(context);
    }
  };
}
const _beforePrompt = async (context) => {
  if (!context || !context.message) throw new Error("Invalid context");
  if (!context.task) {
    let messageReplace = context.message.content.replace(`@@ ${agentName}`, "").replace(`@@${agentName}`, "").trim().replace(`@@ImprovePrototypeOrganism`, "");
    let data2;
    data2 = mls.common.safeParseArgs(messageReplace);
    if (!("page" in data2) || !("prompt" in data2)) throw new Error(`[${agentName}] beforePrompt: Invalid prompt structure missing page and prompt`);
    try {
      const infoOrganism = mls.l2.getPath(data2.page);
      if (!infoOrganism) throw new Error(`[${agentName}] beforePrompt: Invalid organism file info`);
      const { folder, project: project2, shortName } = infoOrganism;
      const inputs = await getPrompts(data2, infoOrganism);
      const title = `Improve ${infoOrganism.shortName}`;
      await startNewAiTask(
        agentName,
        title,
        context.message.content,
        context.message.threadId,
        context.message.senderId,
        inputs,
        context,
        _afterPrompt,
        { "shortName": `${shortName}`, "project": `${project2}`, "folder": `${folder}` }
      ).catch((err) => {
        throw new Error(err.message);
      });
    } catch (err) {
      throw new Error(err.message);
    }
    return;
  }
  const step = getNextPendingStepByAgentName(context.task, agentName);
  if (!step) throw new Error(`[${agentName}] beforePrompt: No pending step found for this agent.`);
  context = await updateStepStatus(context, step.stepId, "in_progress");
  if (!step.prompt) throw new Error(`[${agentName}] beforePrompt: No prompt found in step for this agent.`);
  const data = mls.common.safeParseArgs(step.prompt);
  if (!("page" in data) || !("prompt" in data)) throw new Error(`[${agentName}] beforePrompt: Invalid prompt structure missing page and prompt`);
  try {
    const infoOrganism = mls.l2.getPath(data.page);
    if (!infoOrganism) throw new Error(`[${agentName}] beforePrompt: Invalid organism file info`);
    const { folder, project: project2, shortName } = infoOrganism;
    const title = `Improve ${infoOrganism.shortName}`;
    await appendLongTermMemory(context, { "shortName": `${shortName}`, "project": `${project2}`, "folder": `${folder}` });
    const inputs = await getPrompts(data, infoOrganism);
    await startNewInteractionInAiTask(agentName, title, inputs, context, _afterPrompt, step.stepId);
  } catch (err) {
    throw new Error(err.message);
  }
};
const _afterPrompt = async (context) => {
  if (!context || !context.message || !context.task) throw new Error("Invalid context");
  const step = getNextInProgressStepByAgentName(context.task, agentName);
  if (!step) throw new Error(`[${agentName}] afterPrompt: No pending interaction found.`);
  const rc = await updateFile(context);
  if (rc.context) context = rc.context;
  context = await updateStepStatus(context, step.stepId, "completed");
  if (!context.task) throw new Error("Invalid context task");
  context.task = await updateTaskTitle(context.task, "Organism improved");
  if (!rc.hasNewSteps) await executeNextStep(context);
};
async function updateFile(context) {
  if (!context || !context.task) throw new Error(`[${agentName}] updateFile: Not found context`);
  const step = getNextFlexiblePendingStep(context.task);
  if (!step || step.type !== "flexible") throw new Error(`[${agentName}] updateFile: Invalid step in updateFile`);
  const result = step.result;
  if (!result) throw new Error(`[${agentName}] updateFile: Not found "result"`);
  const shortNameMemory = context.task?.iaCompressed?.longMemory["shortName"];
  const projectMemory = context.task?.iaCompressed?.longMemory["project"];
  const folderMemory = context.task?.iaCompressed?.longMemory["folder"];
  if (!shortNameMemory || !projectMemory) throw new Error(`[${agentName}] updateFile: Invalid task memory arguments`);
  const contentHTML = result.html ? result.html : void 0;
  let contentTS = result.ts ? result.ts : void 0;
  const contentLess = result.less ? result.less : void 0;
  const models = getModel({ folder: folderMemory || "", project: +projectMemory, shortName: shortNameMemory });
  if (!models) throw new Error(`[${agentName}] updateFile: Not found models`);
  if (contentTS) {
    const resolvedImages = await getAllImages(result.images);
    for (const [key, url] of Object.entries(resolvedImages)) {
      contentTS = replaceByPriority(contentTS, key, url);
    }
  }
  let hasErrorLess = false;
  let hasErrorTypescript = false;
  const serviceSource = getState(`serviceSource.left.service`);
  if (!serviceSource) throw new Error("Not found service source instance");
  if (contentHTML && models.html) serviceSource.setValueInModeKeepingUndo(models.html.model, contentHTML, false);
  if (contentTS && models.ts) {
    serviceSource.setValueInModeKeepingUndo(models.ts.model, contentTS, false);
    const ok = await mls.l2.typescript.compileAndPostProcess(models.ts, true, false);
    hasErrorTypescript = ok === false;
  }
  if (contentLess && models.style) {
    const resultLessComponent2 = await prepareComponentCss(contentLess, +projectMemory, folderMemory || "");
    serviceSource.setValueInModeKeepingUndo(models.style.model, resultLessComponent2, false);
    const ok = await mls.l2.less.compileStyle(models.style);
    hasErrorLess = ok === false;
  }
  context = await updateStepStatus(context, step.stepId, "completed");
  if (hasErrorLess || hasErrorTypescript) {
    const res = await fireAgentFix(context, hasErrorLess, hasErrorTypescript, +projectMemory, folderMemory, shortNameMemory, step.stepId);
    if (res) context = res;
    return {
      hasNewSteps: true,
      context
    };
  }
  return {
    hasNewSteps: false,
    context
  };
}
async function fireAgentFix(context, hasErrorLess, hasErrorTypescript, project2, folder, shortName, stepId) {
  await forceServiceInstance(2, "_100554_serviceSource");
  const page = folder ? `_${project2}_${folder}/${shortName}` : `_${project2}_${shortName}`;
  const nextStepsFix = [];
  let nextStepId = stepId + 1;
  if (hasErrorLess) {
    const data = { page, prompt: "Fix errors in files", position: "left", mode: "less" };
    const newStep = {
      agentName: "agentFix",
      prompt: JSON.stringify(data),
      status: "pending",
      stepId: nextStepId,
      interaction: null,
      nextSteps: null,
      rags: null,
      type: "agent"
    };
    nextStepId = nextStepId + 1;
    nextStepsFix.push(newStep);
  }
  if (hasErrorTypescript) {
    const data = { page, prompt: "Fix errors in files", position: "left", mode: "typescript" };
    const newStep = {
      agentName: "agentFix",
      prompt: JSON.stringify(data),
      status: "pending",
      stepId: nextStepId,
      interaction: null,
      nextSteps: null,
      rags: null,
      type: "agent"
    };
    nextStepsFix.push(newStep);
  }
  return await addNewStep(context, stepId, nextStepsFix);
}
async function getPrompts(data, info) {
  const typescript = await getContentByExtension(info, "ts");
  let less = await getContentByExtension(info, "style");
  if (less) less = removeTokensFromSource(less);
  const themeModule = await import(`/_${info.project}_/l2/${info.folder}/module`);
  let theme = "Default";
  if (themeModule && themeModule.moduleConfig && themeModule.moduleConfig.theme && typeof themeModule.moduleConfig.theme === "string") {
    theme = themeModule.moduleConfig.theme;
  }
  const tokens = await getTokensLess(info.project, theme);
  const globalCss = await getGlobalLess(info.project);
  const dataForReplace = {
    typescript,
    tokens,
    less,
    globalCss,
    promptUser: data.prompt
  };
  const prompts = await getPromptByHtml({ project, shortName: agentName, folder: "", data: dataForReplace });
  return prompts;
}
async function getContentByExtension(info, modelType) {
  try {
    let models = getModel(info);
    if (!models) {
      const keyToStorFile = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, ".ts");
      const stotFile = mls.stor.files[keyToStorFile];
      if (!stotFile) throw new Error(`[${agentName}][getContentByExtension]: Invalid storFile`);
      models = await createAllModels(stotFile);
    }
    if (!models) throw new Error(`[${agentName}][getContentByExtension]:Not found models for file:` + info.shortName);
    if (!models[modelType]) return "";
    return models[modelType]?.model.getValue();
  } catch (e) {
    throw new Error(`[${agentName}][getContentByExtension]: ${e.message}`);
  }
}
function getModel(info) {
  const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, 2);
  return mls.editor.models[key];
}
async function getAllImages(images) {
  const resolved = {};
  for (const img of images) {
    try {
      const result = await getImages(img.searchText, 1, 1);
      if (result.images && result.images.length > 0) {
        const image = result.images[0];
        resolved[img.key] = image.urls[img.type];
      } else {
        resolved[img.key] = `https://source.unsplash.com/800x600/?${encodeURIComponent(img.key)}`;
      }
    } catch (err) {
      console.warn(`Failed to get image for "${img.key}":`, err);
      resolved[img.key] = `https://source.unsplash.com/800x600/?${encodeURIComponent(img.key)}`;
    }
  }
  return resolved;
}
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function replaceByPriority(source, key, value) {
  const escapedKey = escapeRegex(key);
  const pattern1 = new RegExp(`\\{{2}${escapedKey}\\}{2}`, "g");
  const pattern2 = new RegExp(`\\$\\{${escapedKey}\\}`, "g");
  const pattern3 = new RegExp(escapedKey, "g");
  if (pattern1.test(source)) {
    return source.replace(pattern1, value);
  } else if (pattern2.test(source)) {
    return source.replace(pattern2, value);
  } else if (pattern3.test(source)) {
    return source.replace(pattern3, value);
  }
  return source;
}
async function prepareComponentCss(css, projectId, theme) {
  const tokens = await getTokensLess(projectId, theme);
  const resultCss = removeTokensFromSource(css);
  const tokensCss = `

//Start Less Tokens
${tokens}
//End Less Tokens`;
  return `${resultCss}
${tokensCss}`;
}
export {
  createAgent
};
