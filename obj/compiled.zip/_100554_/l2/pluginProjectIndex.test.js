/// <mls fileReference="_100554_/l2/pluginProjectIndex.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
