/// <mls fileReference="_100554_/l2/pluginNavigationRenderOrganism.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, state, property, query } from 'lit/decorators.js';
import { convertFileNameToTag, convertTagToFileName } from '/_102027_/l2/utils.js';
import { collab_trash, collab_pencil, collab_info } from '/_100554_/l2/collabIcons.js';
import { openService } from '/_100554_/l2/libCommom.js';
import { openCollabMessage } from '/_100554_/l2/aiAgentHelper.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
/// **collab_i18n_start** 
const message_pt = {
    noItens: 'Nenhum item foi encontrado!',
    msg1: 'Describe the new element to add inside the organism (e.g., button, text, nav).',
    msg2: 'Type what to create inside the organism, like "add button" or "add text".',
};
const message_en = {
    noItens: 'No items were found!',
    msg1: 'Describe the new element to add inside the organism (e.g., button, text, nav).',
    msg2: 'Type what to create inside the organism, like "add button" or "add text".'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginNavigationRenderOrganism = class PluginNavigationRenderOrganism extends PluginBaseModule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-navigation-render-organism-100554{display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-navigation-render-organism-100554 .contentNav{padding:1rem}plugin-navigation-render-organism-100554 ul{list-style:none;padding:0 0 0 .5rem;border-left:1px solid #d4d4d4}plugin-navigation-render-organism-100554 ul li{position:relative;user-select:none}plugin-navigation-render-organism-100554 ul li small{font-weight:700;font-size:11px}plugin-navigation-render-organism-100554 .dragging{opacity:.5}plugin-navigation-render-organism-100554 .drop-target{background:#d3f9d8}plugin-navigation-render-organism-100554 ul li .header{border:1px solid transparent;padding:.4rem;cursor:pointer}plugin-navigation-render-organism-100554 ul li .header:hover{border:1px solid #d4d4d4}plugin-navigation-render-organism-100554 ul li div.activeBranch{border:1px solid #d4d4d4;display:block;justify-content:space-between;align-items:center;border-radius:5px;background:var(--bg-primary-color-disabled);color:var(--text-primary-color)}plugin-navigation-render-organism-100554 ul li:before{content:' ';position:absolute;width:7px;height:1px;background:#d4d4d4;top:1.2rem;left:-8px}plugin-navigation-render-organism-100554 .groupHiddenListIcon{background-image:url("data:image/svg+xml;utf8,<svg fill='%23727171' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 320 512'><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d='M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z'/></svg>");background-repeat:no-repeat;background-position-y:center;width:15px;height:15px;display:none;margin-top:5px;margin-right:5px;transition:transform 200ms}plugin-navigation-render-organism-100554 .groupHiddenList{padding:.3rem;transition:all .5s;cursor:pointer;display:none;z-index:9;border-top:1px solid #c4c4c4}plugin-navigation-render-organism-100554 ul li div.activeBranch .groupHiddenListIcon{display:block;float:right;position:relative}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item{transition:.5s;z-index:10;font-size:16px;line-height:normal;border-bottom:1px solid #c7c4c4}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item:hover{background:#2f2f2f17}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item:hover{color:#1a83ff !important}plugin-navigation-render-organism-100554 .groupHiddenList .mls-gpbtnslider-item:hover svg{fill:#1a83ff !important}plugin-navigation-render-organism-100554 div.activeBranch.activegpbtnslider .groupHiddenList{display:flex;flex-direction:column;gap:.5rem;padding-right:6px;padding-left:8px}plugin-navigation-render-organism-100554 .activegpbtnslider .groupHiddenListIcon{transform:rotateZ(90deg)}plugin-navigation-render-organism-100554 .activegpbtnslider .groupHiddenList .mls-gpbtnslider-item{display:flex;justify-content:end;align-items:center;gap:.5rem;color:#444343}plugin-navigation-render-organism-100554 .activegpbtnslider .groupHiddenList .mls-gpbtnslider-item svg{fill:#444343}plugin-navigation-render-organism-100554 div.activeBranch.activegpbtnslider info-item{border-bottom:1px solid #d4d4d43d}plugin-navigation-render-organism-100554 info-item{display:flex;align-items:center;width:100%;overflow:hidden;text-overflow:ellipsis;transition:width 2s}plugin-navigation-render-organism-100554 .infoname{display:inline-block;width:100%;text-overflow:ellipsis;overflow:hidden;white-space:nowrap;text-wrap-mode:nowrap}plugin-navigation-render-organism-100554 .showId{display:none}plugin-navigation-render-organism-100554 .activeBranch .showId{display:contents}plugin-navigation-render-organism-100554 .headerNav{height:40px;display:flex;align-items:center;justify-content:center;position:relative;box-shadow:0 1px 3px var(--bg-primary-color-lighter)}plugin-navigation-render-organism-100554 .headerNav h1{font-size:16px;font-weight:500;color:var(--text-primary-color);margin:0;pointer-events:none}plugin-navigation-render-organism-100554 .headerNav .btn-nav{position:absolute;top:50%;transform:translateY(-50%);border:none;background-color:var(--grey-color-darker);color:var(--text-primary-color);width:26px;height:26px;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s}plugin-navigation-render-organism-100554 .headerNav.left .btn-nav{left:10px}plugin-navigation-render-organism-100554 .headerNav.right .btn-nav{right:10px}plugin-navigation-render-organism-100554 .headerNav .btn-nav:hover{opacity:.5}plugin-navigation-render-organism-100554 .headerNav .btn-nav svg{width:14px;height:14px;fill:#fff}plugin-navigation-render-organism-100554 .form-container{background:var(--bg-primary-color);color:var(--text-primary-color);padding:20px 24px}plugin-navigation-render-organism-100554 .form-group{display:flex;flex-direction:column;margin-bottom:14px}plugin-navigation-render-organism-100554 .form-group label{font-size:13px;margin-bottom:6px}plugin-navigation-render-organism-100554 .form-group small{font-size:11px;color:var(--text-primary-color-disabled)}plugin-navigation-render-organism-100554 .form-group input,plugin-navigation-render-organism-100554 .form-group textarea,plugin-navigation-render-organism-100554 .form-group select{padding:8px 10px;border:1px solid var(--grey-color);border-radius:6px;font-size:14px;outline:none;transition:border-color .2s,box-shadow .2s}plugin-navigation-render-organism-100554 .form-group input:disabled{color:var(--text-primary-color)}plugin-navigation-render-organism-100554 .form-group input:focus,plugin-navigation-render-organism-100554 .form-group textarea:focus,plugin-navigation-render-organism-100554 .form-group select:focus{border-color:#4A90E2;box-shadow:0 0 0 2px rgba(74,144,226,0.2)}plugin-navigation-render-organism-100554 .form-group textarea{resize:vertical;min-height:60px}plugin-navigation-render-organism-100554 .btn-save{width:100%;padding:10px;background:#4A90E2;color:#fff;font-size:14px;font-weight:500;border:none;border-radius:6px;cursor:pointer;transition:background .2s}plugin-navigation-render-organism-100554 .btn-save:hover{background:#357ABD}`);
        this.msg = messages['en'];
        this.atributeBase = 'id';
        this.scenary = 'list';
        this.els = [];
        //-------COMPONENT----------
        this.activeId = '';
        this.setEvents();
    }
    setEvents() {
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], (ev) => this.onlevelChange(ev));
        mls.events.addListener(3, 'L3EditEvents', this.onL3EditEvents.bind(this));
        mls.events.addListener(3, 'FineshPreview', this.fineshPreview.bind(this));
    }
    onL3EditEvents(ev) {
        if (!ev.desc || ev.level !== 3)
            return;
        const info = JSON.parse(ev.desc);
        if (!info || !info.action || !info.position || info.position === 'left')
            return;
        switch (info.action) {
            case ('select'):
                this.onSelect(info);
                break;
            case ('navigation'):
                this.onNavigation(info);
                break;
        }
    }
    async fineshPreview(ev) {
        if (ev.level !== 3)
            return;
        setTimeout(() => this.forceUpdate(), 500);
    }
    onSelect(info) {
        if (!info.id)
            return;
        this.activeId = info.id;
    }
    onNavigation(info) {
        this.forceUpdate();
    }
    onlevelChange(ev) {
        if (!ev.desc)
            return;
        const j = JSON.parse(ev.desc);
        if (j.level === 3) {
            this.forceUpdate();
        }
    }
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        this.init();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.setElPreview();
        switch (this.scenary) {
            case ('list'):
                return this.renderNav();
            case ('details'):
                return this.renderDetails();
        }
    }
    renderHeader(txt, btn, pos) {
        return html `
            <div class="headerNav ${pos}">
                <h1 style="display:none">${txt}</h1>
                ${btn}               
            </div>
        `;
    }
    renderDetails() {
        let btn = html `
            <button class="btn-nav" title="add organism" @click="${() => this.goToScenary('list')}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.2 288 416 288c17.7 0 32-14.3 32-32s-14.3-32-32-32l-306.7 0L214.6 118.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-160 160z"/></svg>
            </button>
        `;
        return html `
            ${this.renderHeader('Details', btn, 'left')}
            <h3>In developed</h3>
        `;
    }
    renderNav() {
        let btn = html `
            <button class="btn-nav" title="add organism" @click="${() => this.dispatchEventAdd()}">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg>
            </button>
        `;
        return html `
            ${this.renderHeader(mls.actual[3].getFullName(), btn, 'right')}
            ${this.renderNav2()}
        `;
    }
    renderNav2() {
        if (this.els && this.els.length > 0)
            return this.createNavigation(this.els);
        return html `<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
    }
    createNavigation(array) {
        const obj = html `
            <div class="contentNav">
            <ul>
                ${repeat(array, ((key, idx) => key.id), ((item, index) => { return this.renderItemTree(item, index); }))}
            </ul>
            </div>
        `;
        return obj;
    }
    renderItemTree(item, idx) {
        const cls = item.el.id === this.activeId ? 'activeBranch' : '';
        let mySymbol = 'fa-cubes';
        if (item.el.mySymbol)
            mySymbol = item.el.mySymbol;
        const name = item.el.tagName.toLocaleLowerCase();
        let aux = '';
        if (item.isFather) {
            aux = html `
                <span 
                    class="mls-gpbtnslider-item"
                    @click="${(e) => this.goToL2(e, item)}" 
                    title="edit"
                >
                Edit ${collab_pencil}</span>

                <span class="mls-gpbtnslider-item" @click="${() => this.openCollabMessage(item)}" title="collabMessage">
                    Collab Message <svg width="15px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M208 352c114.9 0 208-78.8 208-176S322.9 0 208 0S0 78.8 0 176c0 38.6 14.7 74.3 39.6 103.4c-3.5 9.4-8.7 17.7-14.2 24.7c-4.8 6.2-9.7 11-13.3 14.3c-1.8 1.6-3.3 2.9-4.3 3.7c-.5 .4-.9 .7-1.1 .8l-.2 .2s0 0 0 0s0 0 0 0C1 327.2-1.4 334.4 .8 340.9S9.1 352 16 352c21.8 0 43.8-5.6 62.1-12.5c9.2-3.5 17.8-7.4 25.2-11.4C134.1 343.3 169.8 352 208 352zM448 176c0 112.3-99.1 196.9-216.5 207C255.8 457.4 336.4 512 432 512c38.2 0 73.9-8.7 104.7-23.9c7.5 4 16 7.9 25.2 11.4c18.3 6.9 40.3 12.5 62.1 12.5c6.9 0 13.1-4.5 15.2-11.1c2.1-6.6-.2-13.8-5.8-17.9c0 0 0 0 0 0s0 0 0 0l-.2-.2c-.2-.2-.6-.4-1.1-.8c-1-.8-2.5-2-4.3-3.7c-3.6-3.3-8.5-8.1-13.3-14.3c-5.5-7-10.7-15.4-14.2-24.7c24.9-29 39.6-64.7 39.6-103.4c0-92.8-84.9-168.9-192.6-175.5c.4 5.1 .6 10.3 .6 15.5z"/></svg>
                </span>
            `;
        }
        return html `
            <li>
                <div 
                    .info=${item}
                    id="${item.el.tagName.toLocaleLowerCase() + idx}"                      
                    class="header ${cls} activegpbtnslider" 
                    @click="${(e) => this.selectItem(e, item)}" 
                    @mouseover="${(e) => this.onMouseover(item)}"
                    @mouseout="${(e) => this.onMouseout(item)}"   
                >
                    <info-item .info=${item}>
                        <span class="fa ${mySymbol}" style="margin-right:.5rem"></span>
                        <span class="infoname">
                            ${name}
                            <small class="showId">(${item.el.id})</small>
                        </span>
                        <span class="groupHiddenListIcon" .info=${item}  @click="${this.clickGroupHidden}">
                        </span>
                    </info-item>
                    <div class="groupHiddenList" >
                        ${aux}
                        <span class="mls-gpbtnslider-item" @click="${() => this.goToScenary('details')}" title="details">
                            Details ${collab_info}
                    
                        </span>
                        <span class="mls-gpbtnslider-item" @click="${() => this.dispatchEventStyle()}" title="style">
                            Element Style <svg width="15px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M512 256c0 .9 0 1.8 0 2.7c-.4 36.5-33.6 61.3-70.1 61.3L344 320c-26.5 0-48 21.5-48 48c0 3.4 .4 6.7 1 9.9c2.1 10.2 6.5 20 10.8 29.9c6.1 13.8 12.1 27.5 12.1 42c0 31.8-21.6 60.7-53.4 62c-3.5 .1-7 .2-10.6 .2C114.6 512 0 397.4 0 256S114.6 0 256 0S512 114.6 512 256zM128 288a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm0-96a32 32 0 1 0 0-64 32 32 0 1 0 0 64zM288 96a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm96 96a32 32 0 1 0 0-64 32 32 0 1 0 0 64z"/></svg>
                    
                        </span>

                        <span class="mls-gpbtnslider-item" @click="${() => this.dispatchEventGlobalStyle()}" title="style">
                            Project Style <svg width="15px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M352 256c0 22.2-1.2 43.6-3.3 64l-185.3 0c-2.2-20.4-3.3-41.8-3.3-64s1.2-43.6 3.3-64l185.3 0c2.2 20.4 3.3 41.8 3.3 64zm28.8-64l123.1 0c5.3 20.5 8.1 41.9 8.1 64s-2.8 43.5-8.1 64l-123.1 0c2.1-20.6 3.2-42 3.2-64s-1.1-43.4-3.2-64zm112.6-32l-116.7 0c-10-63.9-29.8-117.4-55.3-151.6c78.3 20.7 142 77.5 171.9 151.6zm-149.1 0l-176.6 0c6.1-36.4 15.5-68.6 27-94.7c10.5-23.6 22.2-40.7 33.5-51.5C239.4 3.2 248.7 0 256 0s16.6 3.2 27.8 13.8c11.3 10.8 23 27.9 33.5 51.5c11.6 26 20.9 58.2 27 94.7zm-209 0L18.6 160C48.6 85.9 112.2 29.1 190.6 8.4C165.1 42.6 145.3 96.1 135.3 160zM8.1 192l123.1 0c-2.1 20.6-3.2 42-3.2 64s1.1 43.4 3.2 64L8.1 320C2.8 299.5 0 278.1 0 256s2.8-43.5 8.1-64zM194.7 446.6c-11.6-26-20.9-58.2-27-94.6l176.6 0c-6.1 36.4-15.5 68.6-27 94.6c-10.5 23.6-22.2 40.7-33.5 51.5C272.6 508.8 263.3 512 256 512s-16.6-3.2-27.8-13.8c-11.3-10.8-23-27.9-33.5-51.5zM135.3 352c10 63.9 29.8 117.4 55.3 151.6C112.2 482.9 48.6 426.1 18.6 352l116.7 0zm358.1 0c-30 74.1-93.6 130.9-171.9 151.6c25.5-34.2 45.2-87.7 55.3-151.6l116.7 0z"/></svg>
                    
                        </span>
                        
                        
                        <span class="mls-gpbtnslider-item" @click="${() => this.dispatchEventProperty()}" title="properties">
                            Properties <svg xmlns="http://www.w3.org/2000/svg" width="15px" viewBox="0 0 512 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M0 416c0 17.7 14.3 32 32 32l54.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48L480 448c17.7 0 32-14.3 32-32s-14.3-32-32-32l-246.7 0c-12.3-28.3-40.5-48-73.3-48s-61 19.7-73.3 48L32 384c-17.7 0-32 14.3-32 32zm128 0a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM320 256a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm32-80c-32.8 0-61 19.7-73.3 48L32 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l246.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48l54.7 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-54.7 0c-12.3-28.3-40.5-48-73.3-48zM192 128a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm73.3-64C253 35.7 224.8 16 192 16s-61 19.7-73.3 48L32 64C14.3 64 0 78.3 0 96s14.3 32 32 32l86.7 0c12.3 28.3 40.5 48 73.3 48s61-19.7 73.3-48L480 128c17.7 0 32-14.3 32-32s-14.3-32-32-32L265.3 64z"/></svg>
                        </span>
                        
                        <span class="mls-gpbtnslider-item" @click="${this.delEl}" title="remove">
                            Delete ${collab_trash}
                        </span>
                    </div>
                </div>
                <ul>
                    ${repeat(item.children, ((c, idx) => c.el.tagName + idx), ((i, idxI) => { return this.renderItemTree(i, idx + '_' + idxI); }))}
                </ul>
            </li>
        `;
    }
    //-------- IMPLEMENTATION --------------
    forceUpdate() {
        this.init();
    }
    async init() {
        setTimeout(async () => { this.els = await this.getComponents(); }, 500);
    }
    goToScenary(scenary) {
        this.scenary = scenary;
    }
    openCollabMessage(item) {
        const info = convertTagToFileName(item.el.tagName.toLocaleLowerCase());
        if (!info || !info.project)
            return;
        const key = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, '.ts');
        if (!mls.stor.files[key])
            return;
        openCollabMessage(mls.stor.files[key]);
    }
    dispatchEventAdd() {
        this.dispatchEvent(new CustomEvent('on-add-click', {
            bubbles: true,
            composed: true
        }));
    }
    dispatchEventProperty() {
        this.dispatchEvent(new CustomEvent('on-property-click', {
            bubbles: true,
            composed: true
        }));
    }
    dispatchEventGlobalStyle() {
        const key = mls.stor.getKeyToFiles(mls.actualProject || 0, 2, 'project', '', '.ts');
        const f = mls.stor.files[key];
        if (!f)
            return;
        mls.actual[2].left = f;
        mls.actual[2].setFullName(`_${mls.actualProject}_project`);
        openService('_100554_serviceSource', 'left', 2);
    }
    dispatchEventStyle() {
        this.dispatchEvent(new CustomEvent('on-style-click', {
            bubbles: true,
            composed: true
        }));
    }
    setElPreview() {
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return;
        this.elPreviewL3 = scope.querySelector('collab-preview-l3-100554');
    }
    async getComponents() {
        const lessTags = ['script', 'style', 'body', 'head', 'html'];
        let ret = [];
        const scope = window.preview?.iframe?.contentDocument?.body;
        if (!scope)
            return ret;
        const infoFile = mls.l2.getPath(mls.actual[3].getFullName());
        const tag = convertFileNameToTag(infoFile);
        const root = scope.querySelector(tag);
        if (root)
            await root.updateComplete;
        const reentrance = async (array, element) => {
            let info;
            if (element.getAttribute(this.atributeBase) && !lessTags.includes(element.tagName.toLocaleLowerCase())) {
                info = { el: element, id: element.id, children: [], isFather: false };
                array.push(info);
            }
            else if (tag === element.tagName.toLocaleLowerCase()) {
                await element.updateComplete;
                info = { el: element, id: element.id, children: [], isFather: true };
                array.push(info);
            }
            const children = element.shadowRoot ? Array.from(element.shadowRoot.children) : Array.from(element.children);
            for (let i = 0; i < children.length; i++) {
                const child = children[i];
                await reentrance(info ? info.children : array, child);
            }
        };
        await reentrance(ret, scope);
        return ret;
        //return this.mockup();
    }
    mockup() {
        const array = [];
        for (let i = 0; i < 4; i++) {
            const d = document.createElement('div');
            d.id = 'el_' + i;
            const info = { el: d, id: d.id, children: [], isFather: false };
            array.push(info);
        }
        return array;
    }
    selectItem(e, item) {
        e.stopPropagation();
        let target = e.target;
        if (target && target.className.indexOf('header') < 0) {
            target = target.closest('.header');
        }
        if (!target)
            return;
        if (this.elPreviewL3)
            this.elPreviewL3.selectElement(item.el);
        this.activeId = item.id;
        /*if (target.classList.contains('activeBranch')) {
            this.dispatchEventStyle();
        }*/
        const els = this.querySelectorAll('.activeBranch');
        els.forEach((el) => el.classList.remove('activeBranch'));
        target.classList.add('activeBranch');
    }
    clickGroupHidden(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const father = el.closest('.header');
        if (!father)
            return;
        father.classList.toggle('activegpbtnslider');
        if (!el.info)
            return;
        let lock = 'fa-lock-open';
        const isGroup = el.info.el.getAttribute('isFCAGroup');
        if (isGroup || isGroup === 'true') {
            lock = 'fa-lock';
        }
        const group = el.querySelector('.classLock');
        if (group) {
            group.classList.remove('fa-lock');
            group.classList.remove('fa-lock-open');
            group.title = lock === 'fa-lock' ? 'lock' : 'lock open';
            group.classList.add(lock);
        }
    }
    delEl(e) {
        e.stopPropagation();
        setTimeout(() => { this.requestUpdate(); }, 100);
    }
    onMouseover(item) {
        this.highlightElement(item.el);
    }
    onMouseout(item) {
        this.unhighlightElement(item.el);
    }
    ;
    highlightElement(el) {
        if (!this.elPreviewL3 || !this.elPreviewL3.setHover)
            return;
        this.elPreviewL3.setHover(el, true);
    }
    unhighlightElement(el) {
        if (!this.elPreviewL3 || !this.elPreviewL3.setHover)
            return;
        this.elPreviewL3.setHover(el, false);
    }
    goToL2(e, item) {
        const fileInfo = convertTagToFileName(item.el.tagName.toLowerCase());
        if (!fileInfo)
            return;
        const { folder, project, shortName } = fileInfo;
        const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, '.ts');
        const f = mls.stor.files[key];
        if (!f)
            return;
        mls.actual[2].setFullName(folder ? `_${project}_${folder}/${shortName}` : `_${project}_${shortName}`);
        mls.actual[2].left = f;
        openService('_100554_serviceSource', 'left', 2);
    }
};
__decorate([
    property()
], PluginNavigationRenderOrganism.prototype, "service", void 0);
__decorate([
    property()
], PluginNavigationRenderOrganism.prototype, "scenary", void 0);
__decorate([
    property()
], PluginNavigationRenderOrganism.prototype, "els", void 0);
__decorate([
    query('#iptModule')
], PluginNavigationRenderOrganism.prototype, "iptModule", void 0);
__decorate([
    query('#iptOrganism')
], PluginNavigationRenderOrganism.prototype, "iptOrganism", void 0);
__decorate([
    query('#iptPrompt')
], PluginNavigationRenderOrganism.prototype, "iptPrompt", void 0);
__decorate([
    state()
], PluginNavigationRenderOrganism.prototype, "activeId", void 0);
PluginNavigationRenderOrganism = __decorate([
    customElement('plugin-navigation-render-organism-100554')
], PluginNavigationRenderOrganism);
export { PluginNavigationRenderOrganism };
