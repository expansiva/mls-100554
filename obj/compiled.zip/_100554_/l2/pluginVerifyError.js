/// <mls fileReference="_100554_/l2/pluginVerifyError.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { property } from 'lit/decorators.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
import { initCompileMonaco } from '/_100554_/l2/collabInit.js';
/// **collab_i18n_start**
const message_pt = {
    fileVerification: 'Verificação de arquivos',
    checkFiles: 'Verificando arquivos',
    noErros: "Nenhum erro encontrado",
    cancel: 'Cancelar verificação'
};
const message_en = {
    fileVerification: 'File verification',
    checkFiles: 'Checking files',
    noErros: 'No errors found',
    cancel: 'Cancel verification',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export class PluginVerifyError extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-verify-error-100554 {
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  padding-top: var(--space-8);
  position: relative;
  min-height: 150px;
  margin-bottom: 3rem;
}
plugin-verify-error-100554 h3 {
  border-bottom: 1px solid var(--bg-primary-color-focus);
}
plugin-verify-error-100554 ul {
  list-style: decimal;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding-left: 1.3rem;
}
plugin-verify-error-100554 .contentloader {
  padding: 1rem;
  flex-direction: column;
  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
  width: 100%;
  min-height: 50px;
  height: 100%;
  top: 0px;
  left: 0px;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 0.5rem;
  position: relative;
}
plugin-verify-error-100554 .contentloader button {
  margin-top: 1rem;
  border: none;
  cursor: pointer;
  background: no-repeat;
  text-decoration: underline;
  color: var(--text-secondary-color-darker);
}
plugin-verify-error-100554 .textLoader {
  font-size: 1.2rem;
  font-weight: bold;
  margin-right: 0.5rem;
}
plugin-verify-error-100554 .loader {
  width: 25px;
  height: 15px;
  margin-top: 20px;
  --_g: no-repeat radial-gradient(farthest-side, #000 94%, #0000);
  background: var(--_g) 50% 0, var(--_g) 100% 0;
  background-size: 5px 5px;
  position: relative;
  animation: l23-0 1.5s linear infinite;
}
plugin-verify-error-100554 .loader:before {
  content: "";
  position: absolute;
  height: 5px;
  aspect-ratio: 1;
  border-radius: 50%;
  background: #000;
  left: 0;
  top: 0;
  animation: l23-1 1.5s linear infinite, l23-2 0.5s cubic-bezier(0, 200, 0.8, 200) infinite;
}
@keyframes l23-0 {
  0%,
  31% {
    background-position: 50% 0, 100% 0;
  }
  33% {
    background-position: 50% 100%, 100% 0;
  }
  43%,
  64% {
    background-position: 50% 0, 100% 0;
  }
  66% {
    background-position: 50% 0, 100% 100%;
  }
  79% {
    background-position: 50% 0, 100% 0;
  }
  100% {
    transform: translateX(calc(-100%/3));
  }
}
@keyframes l23-1 {
  100% {
    left: calc(100% + 7px);
  }
}
@keyframes l23-2 {
  100% {
    top: -0.1px;
  }
}
`);
        this.msg = messages['en'];
        this.continueVerify = true;
        this.find = [];
        this.current = '0';
        this.tot = '0';
        this.error = '';
        this.autoPrepare = false;
        this.isLoad = false;
        this.listErrors = [];
    }
    //-----COMPONENT---------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.error !== '') {
            return html `${this.renderHeader()}
                <h4 style="color:red">${this.error}</h4>
            `;
        }
        if (this.isLoad) {
            return html `
                ${this.renderHeader()}
                ${this.renderLoad()}
            `;
        }
        return this.renderErros();
    }
    renderLoad() {
        return html `
        <div class="contentloader">
            <div class="textLoader">
                ${this.msg.checkFiles}
                <span>${this.current}/${this.tot}</span>
            </div>
            <button @click=${this.cancelVerify}>${this.msg.cancel}</button>
            <ul>
                ${repeat(this.find, ((key) => key), ((k, index) => this.renderItem(k)))}
            </ul>
        </div>
        `;
    }
    renderHeader() {
        return html `
            <h3>${this.msg.fileVerification}</h3>
        `;
    }
    renderErros() {
        if (this.listErrors.length <= 0)
            this.listErrors.push(this.msg.noErros);
        return html `
            ${this.renderHeader()}
            <ul>

                ${repeat(this.listErrors, ((key) => key), ((k, index) => this.renderItem(k)))}
            
            </ul>
        `;
    }
    renderItem(i) {
        return html `
            <li>
                ${i}
            </li>
        `;
    }
    //------IMPLEMENTS--------
    async prepare() {
        try {
            this.isLoad = true;
            this.continueVerify = true;
            const prj = mls.actualProject;
            if (!prj)
                throw new Error('Not found project');
            await initCompileMonaco(prj);
            const ret = await mls.l2.typescript.compileAll(prj, this.progressCallback.bind(this));
            this.listErrors = ret;
            this.setFilesErros(this.listErrors);
            if (!this.continueVerify)
                this.fireEvent(true);
            else
                this.fireEvent(this.listErrors.length === 0);
            this.isLoad = false;
        }
        catch (e) {
            this.isLoad = false;
            this.error = e.message;
        }
    }
    setFilesErros(array) {
        const ret = [];
        const itens = array.map(str => str.replace(/^--- Error compiling\s+/, ''));
        itens.forEach((f) => {
            let pr = f.substring(1).split("_")[0];
            let prID = Number(pr);
            if (isNaN(prID))
                prID = 0; // error
            let path = f.substring(pr.length + 2);
            const key = mls.stor.getKeyToFiles(prID, 2, path, '', '.ts');
            if (mls.stor.files[key]) {
                mls.stor.files[key].hasError = true;
                ret.push(mls.stor.files[key]);
            }
        });
        return ret;
    }
    cancelVerify() {
        this.continueVerify = false;
    }
    ;
    progressCallback(current, total, results) {
        this.current = current.toString();
        this.tot = total.toString();
        this.find = results;
        return this.continueVerify;
    }
    fireEvent(free) {
        mls.events.fire(mls.actualLevel, 'ProjectCompilationComplete', JSON.stringify({ tsFree: free }), 0);
    }
}
__decorate([
    property()
], PluginVerifyError.prototype, "find", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "current", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "tot", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "error", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "autoPrepare", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "isLoad", void 0);
__decorate([
    property()
], PluginVerifyError.prototype, "listErrors", void 0);
if (!customElements.get('plugin-verify-error-100554')) {
    customElements.define('plugin-verify-error-100554', PluginVerifyError);
}
