/// <mls fileReference="_100554_/l2/collabStartL2.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
const message_pt = {
  desc: "Descri\xE7\xE3o",
  news: "Novidades",
  inDevelopment: "Em desenvolvimento...",
  details1: "Sobre esse level",
  module1Title: "M\xF3dulo L2 - Components: Descri\xE7\xE3o e Funcionalidades",
  module1Text: "O m\xF3dulo L2 \xE9 destinado ao programador front-end respons\xE1vel por desenvolver os componentes visuais e de gerenciamento que ser\xE3o utilizados nas p\xE1ginas do projeto. Este m\xF3dulo tamb\xE9m envolve a documenta\xE7\xE3o, teste e gerenciamento de depend\xEAncias dos componentes.",
  module1List1: "Programar Componentes Visuais",
  module1List1_1: "Permite criar componentes visuais, como bot\xF5es, cards e formul\xE1rios, que ser\xE3o inclu\xEDdos nas p\xE1ginas do projeto.",
  module1List2: "Documenta\xE7\xE3o e Descri\xE7\xE3o",
  module1List2_1: "Espa\xE7o para documentar o componente, descrevendo suas funcionalidades, casos de uso e como integr\xE1-lo ao projeto.",
  module1List3: "Testar em V\xE1rios Dispositivos e Tamanhos de Tela",
  module1List3_1: "Ferramentas para testar o componente em diferentes dispositivos e tamanhos de tela, garantindo a responsividade.",
  module1List4: "Incluir Depend\xEAncias do Componente",
  module1List4_1: "Permite especificar e gerenciar as depend\xEAncias necess\xE1rias para o funcionamento do componente, incluindo aquelas espec\xEDficas para determinados dispositivos.",
  module1List5: "Programar Componentes Internos do Collab.codes",
  module1List5_1: "Desenvolvimento de componentes espec\xEDficos para o gerenciamento e opera\xE7\xE3o da plataforma Collab.codes, sejam eles visuais ou de backend."
};
const message_en = {
  desc: "Description",
  news: "News",
  inDevelopment: "In development...",
  details1: "About this level",
  module1Title: "Module L2 - Components: Description and Features",
  module1Text: "The L2 module is aimed at front-end developers responsible for creating the visual and management components used in project pages. This module also includes component documentation, testing, and dependency management.",
  module1List1: "Program Visual Components",
  module1List1_1: "Enables the creation of visual components, such as buttons, cards, and forms, to be included in project pages.",
  module1List2: "Documentation and Description",
  module1List2_1: "A space to document the component, describing its features, use cases, and how to integrate it into the project.",
  module1List3: "Test Across Devices and Screen Sizes",
  module1List3_1: "Tools to test the component on various devices and screen sizes, ensuring responsiveness.",
  module1List4: "Include Component Dependencies",
  module1List4_1: "Allows specifying and managing the dependencies required for the component to function, including those specific to certain devices.",
  module1List5: "Program Internal Components for Collab.codes",
  module1List5_1: "Development of components specific to the management and operation of the Collab.codes platform, whether visual or backend."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let CollabStartL2100554 = class extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-start-l2-100554 {
  line-height: 1.15;
  position: relative;
  height: 100%;
  overflow: auto;
  font-family: 'Cambria', serif;
  font-size: var(--font-size-16);
  font-weight: 400;
}
collab-start-l2-100554 details > summary {
  cursor: pointer;
  font-size: var(--font-size-20);
}
collab-start-l2-100554 .collab-codes-banner {
  margin-left: auto;
  margin-right: auto;
  display: block;
  width: 100%;
  max-width: 100%;
  position: relative;
}
collab-start-l2-100554 .collab-codes-banner img {
  width: 100% !important;
  height: auto !important;
}
collab-start-l2-100554 .collab-codes-link {
  display: flex;
  justify-content: center;
  gap: 2rem;
  padding: 2rem;
}
collab-start-l2-100554 .collab-codes-link button {
  cursor: pointer;
  background: none;
  border: none;
  text-decoration: underline;
  color: var(--active-color);
}
collab-start-l2-100554 .collab-codes-content {
  padding: 0 0.5rem;
  margin-left: auto;
  margin-right: auto;
  max-width: 800px;
  justify-content: center;
}
collab-start-l2-100554 .collab-codes-content details {
  margin-bottom: 1rem;
}
collab-start-l2-100554 .collab-codes-content details > div {
  padding-left: 1.5rem;
}
collab-start-l2-100554 .collab-codes-contents {
  justify-content: center;
}
collab-start-l2-100554 .collab-codes-contents details {
  margin-bottom: 1rem;
}
collab-start-l2-100554 .collab-codes-contents details > div {
  padding-left: 1.5rem;
}
collab-start-l2-100554 .separator {
  padding-top: 24px;
  padding-bottom: 10px;
  margin-top: 32px;
  margin-bottom: 14px;
  display: flex;
  justify-content: center;
}
collab-start-l2-100554 .separator > span {
  width: 4px;
  height: 4px;
  background-color: var(--text-primary-color);
  border-radius: 50%;
  display: inline-block;
  margin-right: 20px;
}
collab-start-l2-100554 h1 {
  line-height: 52px;
  font-size: 42px;
  font-weight: 700;
  font-style: normal;
}
collab-start-l2-100554 h2 {
  line-height: 30px;
  font-size: 24px;
  font-weight: 600;
  font-style: normal;
}
collab-start-l2-100554 h1,
collab-start-l2-100554 h2,
collab-start-l2-100554 h3,
collab-start-l2-100554 h4,
collab-start-l2-100554 h5,
collab-start-l2-100554 h6,
collab-start-l2-100554 h7 {
  letter-spacing: -0.011em;
}
collab-start-l2-100554 ol > li,
collab-start-l2-100554 ul > li {
  margin-top: 1em;
}
collab-start-l2-100554 span,
collab-start-l2-100554 p,
collab-start-l2-100554 li {
  line-height: 32px;
  font-size: 20px;
}
collab-start-l2-100554 .collab_marca {
  position: absolute;
  bottom: 10px;
  right: 20px;
  opacity: 0.2;
}
`);
    }
  msg = messages["en"];
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
        <section class="collab-codes-start">
            <div class="collab-codes-banner">
                <img id="serviceStartL2ImageBanner" src="./l3/_100529_/images/startl2.avif" height="250" width="800" alt="banner">
            </div>
            <div class="collab-codes-content">
                <details id="serviceStartL2DetailsAbout" open="open">
                    <summary>${this.msg.details1}</summary>
                    <div>
                        <h1>${this.msg.module1Title}</h1>
                        <div>
                            <h2>${this.msg.desc}</h2>
                            <span>${this.msg.module1Text}

                                <ol>
                                    <li>
                                        <span>${this.msg.module1List1}</span>
                                        <ul>
                                            <li>${this.msg.module1List1_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List2}</span>
                                        <ul>
                                            <li>${this.msg.module1List2_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List3}</span>
                                        <ul>
                                            <li>${this.msg.module1List3_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List4}</span>
                                        <ul>
                                            <li>${this.msg.module1List4_1}</li>
                                        </ul>
                                    </li>
                                    <li>
                                        <span>${this.msg.module1List5}</span>
                                        <ul>
                                            <li>${this.msg.module1List5_1}</li>
                                        </ul>
                                    </li>
                                </ol>

                            </span>
                        </div>
                    </div>
                </details>
                <details id="serviceStartL2DetailsNews" open="open">
                    <summary>${this.msg.news}</summary>
                    <div>
                        <span>${this.msg.inDevelopment}</span>
                    </div>
                </details>
            </div>
        </section>
        <img class="collab_marca" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==" height="140" width="140" alt="collab codes">
         `;
  }
};
CollabStartL2100554 = __decorateClass([
  customElement("collab-start-l2-100554")
], CollabStartL2100554);
export {
  CollabStartL2100554
};
