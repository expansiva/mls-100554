/// <mls fileReference="_100554_/l2/agentFullScan.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
