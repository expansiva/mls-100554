/// <mls shortName="pluginNewFileBlank" project="100554" enhancement="_blank" />
export const integrations = [];
export const tests = [];
