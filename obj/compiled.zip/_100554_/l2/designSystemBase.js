const acceptedImages = [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".svg", ".webp"];
const acceptedVideos = [".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm", ".m4v"];
async function getImages(project) {
  const folder = "assets";
  const imagesFiles = Object.values(mls.stor.files).filter((file) => {
    return file.project === project && file.folder === folder && acceptedImages.includes(file.extension);
  });
  return imagesFiles || [];
}
async function getVideos(project) {
  const folder = "assets";
  const videosFiles = Object.values(mls.stor.files).filter((file) => {
    return file.project === project && file.folder === folder && acceptedVideos.includes(file.extension);
  });
  return videosFiles || [];
}
async function addAssets(project, file) {
  const folder = "assets";
  const shortName = file.name;
  const newShortName = shortName.replace(/_/g, "-");
  const ext = newShortName.split(".").pop();
  const extension = `.${ext}`;
  if (!extension) throw new Error("Invalid extension");
  if (!acceptedImages.includes(extension) && !acceptedVideos.includes(extension)) throw new Error(`Invalid extension. Valid extensions: ${acceptedImages.join(",")},${acceptedVideos.join(",")}, `);
  const extensionIndex = newShortName.lastIndexOf(".");
  const fileNameWithoutExtension = newShortName.slice(0, extensionIndex);
  const assetsByName = Object.keys(mls.stor.files).find((key) => {
    const stor = mls.stor.files[key];
    return stor.project === project && stor.folder === folder && stor.shortName === fileNameWithoutExtension && stor.extension === extension;
  });
  if (assetsByName) throw new Error(`assets: ${folder}/${newShortName} already exists`);
  try {
    await createNewAssets(project, fileNameWithoutExtension, extension, folder, file);
    return true;
  } catch (err) {
    throw new Error(`Error on add new asset: ${err.message}`);
  }
}
async function createNewAssets(project, shortName, extension, folder, content) {
  const params = {
    project,
    level: 3,
    shortName,
    extension,
    versionRef: "0",
    folder
  };
  const file = await mls.stor.addOrUpdateFile(params);
  if (!file) throw new Error("Error on update or add File");
  file.status = "new";
  file.getValueInfo = () => _getValueInfo(file);
  file.onAction = (action) => _onAction(action, file);
  const contentType = typeof content === "string" ? "string" : "blob";
  const fileInfo = {
    content,
    contentType
  };
  await mls.stor.localStor.setContent(file, fileInfo);
  return file;
}
async function _getValueInfo(file, originalShortName, originalFolder, originalProject, originalCRC) {
  file.inLocalStorage = file.status !== "nochange";
  const content = await file.getContent();
  const contentType = typeof content === "string" ? "string" : "blob";
  const obj = {
    content,
    contentType,
    originalShortName,
    originalFolder,
    originalProject,
    originalCRC
  };
  return obj;
}
async function _onAction(action, storFile) {
  return new Promise((resolve, reject) => {
    if (action === "aftersave") {
      storFile.status = "nochange";
      storFile.inLocalStorage = false;
      const fileInfoValue = {
        content: null,
        contentType: void 0
      };
      mls.stor.localStor.setContent(storFile, fileInfoValue);
    }
    return resolve();
  });
}
async function getTokens(project) {
  const module = await import("/_100554_/l2/collabImport.js");
  const fileName = `./_${project}_designSystem`;
  const instance = await module.collabImport({ folder: "", project, shortName: "designSystem" });
  if (!instance) throw new Error(`Invalid ds file: ${fileName}`);
  return instance.tokens || [];
}
async function updateTokensTheme(project, themeName, tokenData) {
  const actualTokens = await getTokens(project);
  const tokensByTheme = actualTokens.find((theme) => theme.themeName === themeName);
  if (!tokensByTheme) throw new Error(`Invalid theme`);
  tokensByTheme.color = tokenData.color;
  tokensByTheme.typography = tokenData.typography;
  tokensByTheme.global = tokenData.global;
  tokensByTheme.description = tokenData.themeName;
  await serializeTokens(project, actualTokens);
}
async function addNewTokensTheme(project, tokenData) {
  const actualTokens = await getTokens(project);
  let v = 1;
  const prepareTokens = (tokenData2) => {
    const { themeName } = tokenData2;
    const alreadyExists = actualTokens.find((theme) => theme.themeName === themeName);
    if (alreadyExists) {
      v += 1;
      tokenData2.themeName = tokenData2.themeName + v;
      prepareTokens(tokenData2);
    }
  };
  prepareTokens(tokenData);
  actualTokens.push(tokenData);
  await serializeTokens(project, actualTokens);
}
async function removeTokensTheme(project, themeName) {
  const actualTokens = await getTokens(project);
  const themeIndex = actualTokens.findIndex((theme) => theme.themeName === themeName);
  if (themeIndex === -1) return;
  actualTokens.splice(themeIndex, 1);
  await serializeTokens(project, actualTokens);
}
async function serializeTokens(project, tokens) {
  const content = tokens.map((t) => JSON.stringify(t, null, 4)).join(",\n\n");
  const key = mls.stor.getKeyToFiles(project, 2, "designSystem", "", ".ts");
  const storFile = mls.stor.files[key];
  if (!storFile) return;
  const libCommon = await import("/_100554_/l2/libCommom.js");
  await libCommon.forceServiceInstance(2, "_100554_serviceSource");
  const serviceSource = mls.services["100554_serviceSource_left"];
  if (!serviceSource) throw new Error("Service source is not instancied");
  const libModel = await import("/_100554_/l2/collabLibModel.js");
  const models = await libModel.createAllModels(storFile);
  if (!models || !models.ts) throw new Error(`Invalid models for file: ${project}_designSystem`);
  const newCode = replaceTokensBlock(models.ts.model.getValue(), `
${content}
`);
  serviceSource.setValueInModeKeepingUndo(models.ts.model, newCode, true);
}
function replaceTokensBlock(code, newContent) {
  const regex = /export\s+const\s+tokens\s*:\s*IDesignSystemTokens\[\]\s*=\s*\[[\s\S]*?\];?/g;
  return code.replace(regex, `export const tokens: IDesignSystemTokens[] = [
${newContent}
]`);
}
async function getTokensLess(project, theme) {
  const tokens = await getTokens(project);
  const tokenByTheme = tokens.find((item) => item.themeName === theme);
  if (!tokenByTheme) throw new Error(`no find theme: ${theme}`);
  let tokensLess = "";
  tokensLess += Object.keys(tokenByTheme.color).map((key) => {
    let token = "";
    if (!key.startsWith("_dark-")) token = `@${key}: ${tokenByTheme.color[key]};`;
    return token;
  }).filter((item) => !!item).join("\n");
  tokensLess += "\n" + Object.keys(tokenByTheme.typography).map((key) => `@${key}: ${tokenByTheme.typography[key]};`).join("\n");
  tokensLess += "\n" + Object.keys(tokenByTheme.global).map((key) => `@${key}: ${tokenByTheme.global[key]};`).join("\n");
  return Promise.resolve(tokensLess);
}
async function getTokensCss(project, theme) {
  const tokens = await getTokens(project);
  const prefix = ":root";
  try {
    const tokenInfo = tokens.find((item) => item.themeName === theme);
    if (!tokenInfo) return "";
    const allTokens = { ...tokenInfo.color, ...tokenInfo.typography, ...tokenInfo.global };
    const darkAndLight = getDarkAndLight(allTokens);
    const cssVars = getCssVars(darkAndLight, prefix);
    const tokensCss = convertLessTokensToCss(cssVars, darkAndLight["root"]);
    return tokensCss;
  } catch (err) {
    throw new Error(`Error on compile tokens Less: ${err.message}`);
  }
}
async function getGlobalCss(project, theme) {
  let less = await getGlobalLess(project);
  less = less.replace(/project-\d+\s*{([\s\S]*)}$/m, "$1");
  const compiled = await preCompileLess(project, less, theme);
  return compiled;
}
async function getGlobalLess(project) {
  const shortName = "project";
  const folder = "";
  const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, ".less");
  const storFile = mls.stor.files[key];
  if (!storFile) return "";
  let less = await storFile.getContent();
  if (!less || typeof less !== "string") return "";
  return less;
}
async function compileLess(str) {
  return new Promise((resolve, reject) => {
    if (!str || str.trim().length < 1) resolve("");
    mls.l2.less.compile(str).then(async (css) => {
      resolve(css);
    }).catch((err) => {
      reject(new Error("Error LESS: " + err));
    });
  });
}
async function preCompileLess(project, less, theme) {
  const tokens = await getTokens(project);
  const prefix = ":root";
  try {
    less = removeTokensFromSource(less);
    const tokenInfo = tokens.find((item) => item.themeName === theme);
    if (!tokenInfo) return "";
    const allTokens = { ...tokenInfo.color, ...tokenInfo.typography, ...tokenInfo.global };
    const darkAndLight = getDarkAndLight(allTokens);
    const newLess = convertLessTokensToCss(less, darkAndLight["root"]);
    const tokensLess = await getTokensLess(project, theme);
    const res = await compileLess(`${newLess}
${tokensLess}`);
    return res;
  } catch (err) {
    throw new Error(`Error on pre compile tokens Less: ${err.message}`);
  }
}
async function preCompileLessByThemeOrDefault(project, less, theme) {
  const tokens = await getTokens(project);
  const prefix = ":root";
  try {
    less = removeTokensFromSource(less);
    let tokenInfo = tokens.find((item) => item.themeName === theme);
    if (!tokenInfo) {
      tokenInfo = tokens.find((item) => item.themeName === "Default");
      theme = "Default";
    }
    if (!tokenInfo) throw new Error(`Not found tokens`);
    const allTokens = { ...tokenInfo.color, ...tokenInfo.typography, ...tokenInfo.global };
    const darkAndLight = getDarkAndLight(allTokens);
    const newLess = convertLessTokensToCss(less, darkAndLight["root"]);
    const tokensLess = await getTokensLess(project, theme);
    const res = await compileLess(`${newLess}
${tokensLess}`);
    return res;
  } catch (err) {
    throw new Error(`Error on pre compile tokens Less: ${err.message}`);
  }
}
function getDarkAndLight(allTokens) {
  const themes = {};
  Object.entries(allTokens).forEach((entry) => {
    const [key, value] = entry;
    const [theme] = key.split("-");
    let themeName = "root";
    if (theme === "_dark") themeName = "dark";
    if (!themes[themeName]) themes[themeName] = {};
    themes[themeName][key] = value;
  });
  return themes;
}
function getCssVars(themes, prefix) {
  const cssArr = [];
  Object.entries(themes).forEach((entry) => {
    const [key, value] = entry;
    if (key === "root") {
      const cssVars = [];
      Object.entries(value).forEach((entryTokens) => {
        const [keyToken, valueToken] = entryTokens;
        const cssVar = `--${keyToken}: ${valueToken};`;
        cssVars.push(cssVar);
      });
      const cssFinal = `${prefix}{
	${cssVars.join("\n	")}
}`;
      cssArr.push(cssFinal);
    } else {
      const cssVars = [];
      Object.entries(value).forEach((entryTokensDark) => {
        const [keyToken, valueToken] = entryTokensDark;
        const tokenKey = keyToken.substring(1 + key.length + 1, keyToken.length);
        const cssVar = `--${tokenKey}: ${valueToken};`;
        cssVars.push(cssVar);
      });
      const cssFinal = `[data-theme="dark"] {
	${cssVars.join("\n	")}
}`;
      cssArr.push(cssFinal);
    }
  });
  return cssArr.join("\n");
}
function convertLessTokensToCss(less, tokens) {
  const lessTokens = new Set(Object.keys(tokens));
  return less.replace(/@([a-zA-Z0-9-_]+)/g, (match, token, offset, fullText) => {
    if (!lessTokens.has(token)) {
      return match;
    }
    const beforeText = fullText.slice(0, offset);
    const insideMediaQuery = /@media\s*\([^{}]*$/.test(beforeText);
    const lessFunctions = [
      "lighten",
      "darken",
      "saturate",
      "desaturate",
      "fadein",
      "fadeout",
      "fade",
      "spin",
      "mix",
      "tint",
      "shade",
      "contrast",
      "ceil",
      "floor",
      "round",
      "abs",
      "sqrt",
      "pow",
      "mod",
      "min",
      "max",
      "escape",
      "e",
      "unit",
      "convert",
      "extract",
      "length"
    ];
    const insideLessFunction = new RegExp(`(${lessFunctions.join("|")})\\s*\\([^()]*$`, "i").test(beforeText);
    if (insideMediaQuery || insideLessFunction) {
      return match;
    }
    return `var(--${token})`;
  });
}
function removeTokensFromSource(src) {
  const regex = /\/\/Start Less Tokens[\s\S]*?\/\/End Less Tokens/g;
  return src.replace(regex, "");
}
export {
  acceptedImages,
  acceptedVideos,
  addAssets,
  addNewTokensTheme,
  compileLess,
  getGlobalCss,
  getGlobalLess,
  getImages,
  getTokens,
  getTokensCss,
  getTokensLess,
  getVideos,
  preCompileLess,
  preCompileLessByThemeOrDefault,
  removeTokensFromSource,
  removeTokensTheme,
  replaceTokensBlock,
  updateTokensTheme
};
