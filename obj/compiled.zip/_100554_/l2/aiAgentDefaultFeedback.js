/// <mls shortName="aiAgentDefaultFeedback" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_clock_static, collab_terminal } from '/_100554_/l2/collabIcons.js';
let AiAgentDefaultFeedback100554 = class AiAgentDefaultFeedback100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`ai-agent-default-feedback-100554{display:block;padding:1rem;font-size:14px;font-family:'Inter',sans-serif}ai-agent-default-feedback-100554 .feedback-section a{color:var(--active-color)}ai-agent-default-feedback-100554 .feedback-section a:hover{color:var(--active-color-hover)}ai-agent-default-feedback-100554 .feedback-section .step{font-family:monospace;margin:4px 0}ai-agent-default-feedback-100554 .feedback-section .icon{margin-left:-8px}ai-agent-default-feedback-100554 .feedback-section .row{display:flex;align-items:center;gap:8px}ai-agent-default-feedback-100554 .feedback-section .title{font-weight:500}ai-agent-default-feedback-100554 .feedback-section .actions{display:flex;gap:.5rem}ai-agent-default-feedback-100554 .feedback-section .actions a{font-size:11px;cursor:pointer}ai-agent-default-feedback-100554 .feedback-section .actions a:not(:last-child){padding-right:.4rem;border-right:1px solid}ai-agent-default-feedback-100554 .feedback-section .details pre{padding:12px;overflow:auto}ai-agent-default-feedback-100554 .feedback-section .back{margin-bottom:12px}ai-agent-default-feedback-100554 .feedback-section .log-item{margin-bottom:8px}ai-agent-default-feedback-100554 .progress{margin:12px 0 16px;font-size:13px}ai-agent-default-feedback-100554 .progress-info{display:flex;justify-content:space-between;margin-bottom:6px;opacity:.8}ai-agent-default-feedback-100554 .bar{height:8px;background:#e5e5e5;border-radius:999px;overflow:hidden}ai-agent-default-feedback-100554 .fill{height:100%;width:0%;background:linear-gradient(90deg, var(--info-color), var(--success-color));transition:width 350ms ease;position:relative}ai-agent-default-feedback-100554 .fill.done{background:var(--success-color)}ai-agent-default-feedback-100554 .fill.failed{background:var(--error-color)}ai-agent-default-feedback-100554 .fill:not(.failed):not(.done)::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);animation:shimmer 1.4s infinite}@keyframes shimmer{0%{transform:translateX(-100%)}100%{transform:translateX(100%)}}ai-agent-default-feedback-100554 .log-card{border-radius:8px;padding:10px;font-size:12px}ai-agent-default-feedback-100554 .trace-steps{margin:6px 0 0;padding-left:16px}ai-agent-default-feedback-100554 .trace-steps li{margin-bottom:4px}ai-agent-default-feedback-100554 .loader{display:inline-block;width:8px;height:8px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}`);
        this.selectedStep = null;
        this.selectedTraceStep = null;
        this.isAgentParallelMode = false;
    }
    async firstUpdated() {
        //this.task = await getTask('20250917143000.1001');
        //this.task = await getTask('20251205185425.1001');
        //this.task = await getTask('20251127123524.1001');
        // this.task = await getTask('20260126134300.1001');
        // this.task = await getTask('20260126125152.1001');
        this.isAgentParallelMode = !!this.task?.iaCompressed?.nextSteps[0].progress;
        // console.info({ task: this.task, parallel: this.isAgentParallelMode })
    }
    updated(_changedProperties) {
        super.updated(_changedProperties);
        if (_changedProperties.has('task')) {
            this.isAgentParallelMode = !!this.task?.iaCompressed?.nextSteps[0].progress;
        }
    }
    getTitle(step) {
        return (step.stepTitle ||
            step.agentName ||
            step.toolName ||
            step.type ||
            'step');
    }
    getIconStep(status) {
        switch (status) {
            case 'completed': return '✅';
            case 'in_progress': return html `<div class="loader"></div>`;
            case 'failed': return '❌';
            case 'pending': return '⏳';
            case 'waiting_after_prompt': return html `${collab_terminal}${collab_clock_static}`;
            case 'waiting_human_input': return html `${collab_clock_static}`;
            default: return '•';
        }
    }
    getIconTask(status) {
        switch (status) {
            case 'done': return '✅';
            case 'in progress': return html `<div class="loader"></div>`;
            case 'failed': return '❌';
            default: return '•';
        }
    }
    getChildren(step) {
        return [
            ...(step.nextSteps ?? []),
            ...(step.interaction?.payload ?? [])
        ];
    }
    renderStep(step, depth = 0) {
        const children = this.getChildren(step);
        const hasChildren = children.length > 0;
        if (step.type === 'flexible' || step.type === 'result') {
            return html `
            ${hasChildren
                ? children.map((s) => this.renderStep(s, depth))
                : nothing}
            `;
        }
        return html `
        <div class="step" style="padding-left:${depth + 15}px; ${depth !== 0 ? 'border-left:1px solid #cecece' : ''}" >

            <div class="row">
                <span class="icon">${this.getIconStep(step.status)}</span>

                <span class="title">
                    ${this.getTitle(step)}
                </span>

                <span class="actions">
                    <a href="#" @click=${(e) => { e.preventDefault(); this.selectedStep = step; }}>
                        details
                    </a>
                    <a href="#"
                        @click=${(e) => {
            e.preventDefault();
            this.selectedTraceStep = step;
        }}>
                        trace
                    </a>
                </span>
            </div>

            ${hasChildren
            ? children.map((s) => this.renderStep(s, depth + 1))
            : nothing}
        </div>
    `;
    }
    renderTaskRootDetails() {
        if (!this.task)
            return html ``;
        return html `
            <div class="row">
                <span class="icon">${this.getIconTask(this.task.status)}</span>
                <div>${this.task?.title}</div>
            </div>
            <hr></hr>

        `;
    }
    renderTaskProgress() {
        if (!this.task)
            return html ``;
        const root = this.task.iaCompressed?.nextSteps[0];
        if (!root?.progress)
            return html ``;
        const { completed, failed, total } = root.progress;
        const percent = total ? Math.round((completed / total) * 100) : 0;
        const stateClass = failed > 0
            ? 'failed'
            : percent === 100
                ? 'done'
                : 'running';
        return html `
            <div class="progress">
                <div class="progress-info">
                    <span>Progress</span>
                    <span>
                        ${completed}/${total}
                        ${failed > 0 ? html ` • ❌ ${failed}` : nothing}
                    </span>
                </div>

                <div class="bar">
                    <div
                        class="fill ${stateClass}"
                        style="width:${percent}%"
                    ></div>
                </div>
            </div>
        `;
    }
    renderTree() {
        const steps = this.task?.iaCompressed?.nextSteps ?? [];
        return html `
        <section class="tree">
                ${this.renderTaskRootDetails()}
                ${this.isAgentParallelMode ? this.renderTaskProgress() : ''}
                ${steps.map((s) => this.renderStep(s))}
        </section>
            `;
    }
    renderDetails() {
        const step = JSON.parse(JSON.stringify(this.selectedStep));
        if (step && step.nextSteps)
            step.nextSteps = [];
        if (step && step.interaction && step.interaction.payload) {
            step.interaction.payload.forEach((pay) => {
                pay.nextSteps = [];
            });
        }
        return html `
            <section class="details">
                <a 
                    class="back"
                    href = "#"
                    @click=${(e) => { e.preventDefault(); this.selectedStep = null; }}>
                    ← back
                </a>
                <h3> ${this.getTitle(step)} </h3>
                <pre> ${JSON.stringify(step, null, 2)} </pre>
            </section>
                        `;
    }
    renderTrace() {
        const step = this.selectedTraceStep;
        if (!step)
            return nothing;
        const logs = step.interaction?.trace ?? [];
        return html `
            <section class="trace">
                <a 
                    class="back"
                    href = "#"
                    @click=${(e) => {
            e.preventDefault();
            this.selectedTraceStep = null;
        }}>
                ← back
            </a>

            <h3> Trace • ${this.getTitle(step)} </h3>

            ${logs.length === 0
            ? html `<div>No logs</div>`
            : html `
                    <ul class="log-list">
                        ${logs.map((l) => html `
                        <li class="log-item">
                            ${this.renderLogItem(l)}
                        </li>
                    `)}
                    </ul>
                `}
        </section>
            `;
    }
    renderLogItem(raw) {
        const data = this.tryParseJSON(raw);
        if (typeof data === 'object' && data !== null) {
            const obj = data;
            return html `
            <div class="log-card">
                ${obj.title ? html `<strong>${obj.title}</strong>` : nothing}

                ${Array.isArray(obj.trace)
                ? html `
                        <ul class="trace-steps">
                            ${obj.trace.map((t) => html `<li>${t}</li>`)}
                        </ul>
                    `
                : html `<pre>${JSON.stringify(obj, null, 2)}</pre>`}
            </div>
        `;
        }
        return html `<pre>${String(data)}</pre>`;
    }
    tryParseJSON(value) {
        if (typeof value !== 'string')
            return value;
        try {
            return JSON.parse(value);
        }
        catch {
            return value; // continua string normal
        }
    }
    render() {
        if (!this.task)
            return html `No find task`;
        if (!this.task.iaCompressed)
            return html `No find Ai interaction in task`;
        return html `
            <section class="feedback-section">
                ${this.selectedTraceStep
            ? this.renderTrace()
            : this.selectedStep
                ? this.renderDetails()
                : this.renderTree()}
        </section>
            `;
    }
};
__decorate([
    state()
], AiAgentDefaultFeedback100554.prototype, "task", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback100554.prototype, "selectedStep", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback100554.prototype, "selectedTraceStep", void 0);
__decorate([
    state()
], AiAgentDefaultFeedback100554.prototype, "isAgentParallelMode", void 0);
AiAgentDefaultFeedback100554 = __decorate([
    customElement('ai-agent-default-feedback-100554')
], AiAgentDefaultFeedback100554);
export { AiAgentDefaultFeedback100554 };
