/// <mls fileReference="_100554_/l2/collabOrgUsers.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import "/_100554_/l2/collabOrgInviteUser.js";
/// **collab_i18n_start**
const message_pt = {
    title: 'Membros',
    inviteToggle: 'Convidar usuário',
    colAvatar: 'Avatar',
    colUser: 'Usuário',
    colTeams: 'Times',
    colAccess: 'Acesso ao repositório',
    loading: 'Carregando membros…',
    loadingAccess: 'Verificando…',
    error: 'Erro ao carregar membros.',
    noMembers: 'Nenhum membro encontrado.',
    accessOk: 'Acesso OK',
    accessNone: 'Sem acesso',
};
const message_en = {
    title: 'Members',
    inviteToggle: 'Invite user',
    colAvatar: 'Avatar',
    colUser: 'User',
    colTeams: 'Teams',
    colAccess: 'Repository access',
    loading: 'Loading members…',
    loadingAccess: 'Checking…',
    error: 'Failed to load members.',
    noMembers: 'No members found.',
    accessOk: 'Access OK',
    accessNone: 'No access',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
let CollabOrgUsers = class CollabOrgUsers extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.project = 0;
        this.msg = messages['en'];
        this._members = [];
        this._accessMap = {};
        this._loading = false;
        this._error = '';
        this._inviteOpen = false;
    }
    connectedCallback() {
        super.connectedCallback();
        this._fetchMembers();
    }
    async _fetchMembers() {
        this._loading = true;
        this._error = '';
        this.requestUpdate();
        try {
            const idxOrg = mls.l5.getProjectOrgIndex(this.project) || -1;
            const orgName = mls.l5.getOrgsName()[idxOrg];
            const lastOrg = mls.stor.orgs[orgName];
            if (!lastOrg) {
                this._error = 'Not found organization';
                return;
            }
            this._members = this.configUsers(lastOrg);
            await this._fetchAllAccess();
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : 'Unknown error';
        }
        finally {
            this._loading = false;
            this.requestUpdate();
        }
    }
    configUsers(info) {
        const users = [];
        info.sett.users.forEach((u, idx) => {
            const user = {
                id: idx,
                username: u,
                avatarUrl: 'https://i.pravatar.cc/40?u=alice',
                teams: []
            };
            info.sett.teams.forEach((t) => {
                if (t.usrIndex.includes(idx))
                    user.teams.push(t.name);
            });
            users.push(user);
        });
        return users;
    }
    async _fetchAllAccess() {
        const entries = await Promise.all(this._members.map(async (m) => {
            const access = await this._fetchRepoAccess(m.username);
            return [m.username, access];
        }));
        this._accessMap = Object.fromEntries(entries);
    }
    async _fetchRepoAccess(username) {
        await new Promise((resolve) => setTimeout(resolve, 300));
        return { github: false, gitlab: false };
    }
    _toggleInvite() {
        this._inviteOpen = !this._inviteOpen;
        this.requestUpdate();
    }
    _handleInviteSuccess() {
        this._inviteOpen = false;
        this._fetchMembers();
    }
    _renderAccessBadge(value, platform) {
        if (value === null)
            return html `<span class="badge badge-neutral">${platform} –</span>`;
        return value
            ? html `<span class="badge badge-ok">${platform} ✓</span>`
            : html `<span class="badge badge-fail">${platform} ✗</span>`;
    }
    _renderAccessCell(username) {
        const access = this._accessMap[username];
        if (!access)
            return html `<span class="access-loading">${this.msg.loadingAccess}</span>`;
        return html `
            <div class="access-badges">
                ${this._renderAccessBadge(access.github, 'GitHub')}
                ${this._renderAccessBadge(access.gitlab, 'GitLab')}
            </div>
        `;
    }
    _renderTable() {
        if (this._members.length === 0) {
            return html `<p class="no-members">${this.msg.noMembers}</p>`;
        }
        return html `
            <div class="table-wrapper">
                <table class="members-table">
                    <thead>
                        <tr>
                            <th>${this.msg.colAvatar}</th>
                            <th>${this.msg.colUser}</th>
                            <th>${this.msg.colTeams}</th>
                            <th>${this.msg.colAccess}</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this._members.map((m) => html `
                            <tr>
                                <td class="td-avatar">
                                    <img class="avatar" src="${m.avatarUrl}" alt="${m.username}" />
                                </td>
                                <td class="td-user">${m.username}</td>
                                <td class="td-teams">
                                    <div class="tags-wrapper">
                                        ${m.teams.length > 0
            ? m.teams.map((t) => html `<span class="team-tag">${t}</span>`)
            : html `<span class="no-teams">—</span>`}
                                    </div>
                                </td>
                                <td class="td-access">
                                    ${this._renderAccessCell(m.username)}
                                </td>
                            </tr>
                        `)}
                    </tbody>
                </table>
            </div>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this._loading) {
            return html `
                <div class="state-loading">
                    <span class="spinner"></span>
                    <span>${this.msg.loading}</span>
                </div>
            `;
        }
        if (this._error) {
            return html `<div class="feedback error">${this._error}</div>`;
        }
        return html `
            <div class="users-root">

                <div class="header">
                    <h1 class="page-title">${this.msg.title}</h1>
                    <button class="btn-invite" @click="${() => this._toggleInvite()}">
                        ${this._inviteOpen ? '✕' : '+ ' + this.msg.inviteToggle}
                    </button>
                </div>

                ${this._inviteOpen ? html `
                    <div class="invite-wrapper">
                        <collab-org-invite-user-100554
                            project="${this.project}"
                            @invite-success="${() => this._handleInviteSuccess()}"
                        ></collab-org-invite-user-100554>
                    </div>
                ` : ''}

                ${this._renderTable()}

            </div>
        `;
    }
};
__decorate([
    property({ type: Number })
], CollabOrgUsers.prototype, "project", void 0);
CollabOrgUsers = __decorate([
    customElement('collab-org-users-100554')
], CollabOrgUsers);
export { CollabOrgUsers };
