/// <mls fileReference="_100554_/l2/contentAccordion.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let ContentAccordion = class ContentAccordion extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.navItems = [];
        this.contentItems = [];
        this.selectedIndex = 0;
    }
    connectedCallback() {
        super.connectedCallback();
        const div = document.createElement('div');
        div.innerHTML = this.innerHTML;
        this.innerHTML = '';
        this.navItems = Array.from(div.querySelectorAll('nav-item'));
        this.contentItems = Array.from(div.querySelectorAll('content-item'));
    }
    render() {
        return html `
            <div class="accordion">
                ${this.navItems.map((item, i) => {
            const content = this.contentItems[i];
            return html `
                    <nav-item class="header" ?selected=${this.selectedIndex === i} @click=${() => this.toggle(i)}>
                        ${item.innerHTML}
                    </nav-item>
                    <content-item class="content" ?open=${this.selectedIndex === i}>
                        ${unsafeHTML(content?.innerHTML)}
                    </content-item>
                `;
        })}
            </div>
        `;
    }
    toggle(index) {
        this.selectedIndex = this.selectedIndex === index ? -1 : index;
    }
};
__decorate([
    property({ type: Number, reflect: true })
], ContentAccordion.prototype, "selectedIndex", void 0);
ContentAccordion = __decorate([
    customElement('content-accordion-100554')
], ContentAccordion);
export { ContentAccordion };
