/// <mls fileReference="_100554_/l2/previewState.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/previewState.ts",
        "componentType": "editorService",
        "componentScope": "editor",
        "group": "enhancement"
    },
    "references": {
        "imports": [
            {
                "ref": "/_100554_/l2/aiAgentBase"
            }
        ]
    },
    "asIs": {
        "semantic": {
            "generalDescription": "Declares global Window interface for preview state",
            "businessCapabilities": [],
            "technicalCapabilities": [
                "Declares global interface for preview with editor and iframe"
            ],
            "implementedFeatures": [
                "Global interface declaration"
            ],
            "constraints": []
        }
    }
};
