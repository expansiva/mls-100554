/// <mls fileReference="_100554_/l2/widgetCollabChart.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WcEchartsPie100554 = class WcEchartsPie100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.chartTitle = '';
        this.framework = 'echarts';
        this.renderer = 'canvas';
    }
    updated(changedProperties) {
        if (changedProperties.has('framework') && this.framework === 'echarts') {
            if (!window.echartsLoaded) {
                const script = document.createElement('script');
                script.src = 'https://cdn.jsdelivr.net/npm/echarts@latest';
                script.onload = () => {
                    window.echartsLoaded = true;
                    this.initChart();
                };
                document.head.appendChild(script);
            }
            else {
                this.initChart();
            }
        }
    }
    waitForLoadIfNeeded(callback, timeout = 10000, interval = 100) {
        let elapsedTime = 0;
        const checkVariable = () => {
            if (window.echartsLoaded) {
                callback();
            }
            else if (elapsedTime < timeout) {
                elapsedTime += interval;
                setTimeout(checkVariable, interval);
            }
            else {
                console.error(`Error on load echarts.js. please try again`);
            }
        };
        checkVariable();
    }
    initChart() {
        const that = this;
        if (!this.data)
            return;
        if (typeof this.data === 'string') {
            try {
                this.data = JSON.parse(this.data);
            }
            catch (e) {
                this.data = {};
            }
        }
        if (this.chartTitle) {
            if (!this.data.title)
                this.data.title = {};
            this.data.title.text = this.chartTitle;
        }
        this.waitForLoadIfNeeded(() => {
            if (that.myChart) {
                that.myChart.setOption(that.data);
                return;
            }
            if (!that.main || !echarts)
                return;
            that.myChart = echarts.init(that.main, undefined, { renderer: this.renderer });
            that.myChart.setOption(that.data);
        });
    }
    firstUpdated() {
        this.initChart();
    }
    render() {
        return html `<div class="echart-main" style="width:100%; height:100%;"></div>`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], WcEchartsPie100554.prototype, "data", void 0);
__decorate([
    property({ type: String })
], WcEchartsPie100554.prototype, "chartTitle", void 0);
__decorate([
    property({ type: String })
], WcEchartsPie100554.prototype, "framework", void 0);
__decorate([
    property({ type: String })
], WcEchartsPie100554.prototype, "renderer", void 0);
__decorate([
    query('.echart-main')
], WcEchartsPie100554.prototype, "main", void 0);
WcEchartsPie100554 = __decorate([
    customElement('widget-collab-chart-100554')
], WcEchartsPie100554);
export { WcEchartsPie100554 };
