/// <mls fileReference="_100554_/l2/pluginStyleBorder.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, query, queryAll } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { setState, getState } from '/_102029_/l2/collabState.js';
import { getMessageKey } from '/_102029_/l2/collabLitElement.js';
import { convertColorToHex } from '/_102027_/l2/libCommom.js';
import '/_100554_/l2/collabDsInputSelectColor.js';
import '/_100554_/l2/collabDsInputRange.js';
import { collab_lock, collab_lock_open, collab_border_top, collab_border_left, collab_border_right, collab_border_bottom, collab_border_bottomLeft, collab_border_bottomRight, collab_border_topLeft, collab_border_topRight } from '/_100554_/l2/collabIcons.js';
/// **collab_i18n_start**
const message_pt = {
    advanced: 'Avançado',
    all: 'Todos os cantos',
    border: 'Borda',
    gallery: 'Galeria',
    top: 'Superior',
    left: 'Esquerda',
    bottom: 'Inferior',
    right: 'Direita',
    borderRadius: 'Raio da borda',
    topLeft: 'Superior/Esquerda',
    topRight: 'Superior/Direita',
    bottomLeft: 'Inferior/Esquerda',
    bottomRight: 'Inferior/Direita',
    description: 'Plugin desenvolvido para facilitar a manutenção, personalização e validação de propriedades de borda em estilos CSS, oferecendo suporte a ajustes dinâmicos e regras específicas.'
};
const message_en = {
    advanced: 'Advanced',
    all: 'All corners',
    border: 'Border',
    gallery: 'Gallery',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
    borderRadius: 'Border Radius',
    topLeft: 'Top/Left',
    topRight: 'Top/Right',
    bottomLeft: 'Bottom/Left',
    bottomRight: 'Bottom/Right',
    description: 'Plugin designed to simplify the maintenance, customization, and validation of border properties in CSS styles, providing support for dynamic adjustments and specific rules.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['border*'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleBorder = class PluginStyleBorder extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-style-border-100554 {
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
  padding-top: var(--space-8);
}
plugin-style-border-100554 .helper-group-title {
  margin: 0;
  margin-top: var(--space-16);
  margin-bottom: var(--space-8);
  display: flex;
  gap: 1.5rem;
}
plugin-style-border-100554 .helper-group-lock {
  display: flex;
  justify-content: start;
  align-items: center;
}
plugin-style-border-100554 .helper-group-lock label {
  cursor: pointer;
}
plugin-style-border-100554 .helper-group-lock i {
  margin-left: var(--space-8);
}
plugin-style-border-100554 .group {
  margin-left: var(--space-16);
  margin-top: var(--space-8);
  font-size: var(--font-size-12);
  display: flex;
  flex-direction: column;
  gap: 0.7rem;
}
plugin-style-border-100554 .group .group-edit {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
plugin-style-border-100554 .group .group-edit i {
  display: flex;
  flex-shrink: 0;
}
plugin-style-border-100554 .gallery {
  display: flex;
  justify-content: start;
  align-items: center;
  gap: 1rem;
  padding: 1rem;
  flex-wrap: wrap;
  cursor: pointer;
}
`);
        this.msg = messages['en'];
        this.showFull = 'false';
        this.position = 'left';
        this.borderLocked = false;
        this.borderRadiusLocked = false;
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.tpBorder = ['none', 'solid', 'dotted', 'dashed', 'double', 'groove', 'ridge', 'inset', 'outset', 'hidden'];
        this.timeonChangeBorder = -1;
        this.timeonChangeBorderRadius = -1;
        this.gallery = [
            {
                style: 'border: 3px solid #2c3e50; border-bottom: 6px groove #16a085;',
                state: {
                    borderLeftWidth: '3px',
                    borderRightWidth: '3px',
                    borderTopWidth: '3px',
                    borderBottomWidth: '6px',
                    borderLeftStyle: 'solid',
                    borderRightStyle: 'solid',
                    borderTopStyle: 'solid',
                    borderBottomStyle: 'groove',
                    borderLeftColor: '#2c3e50',
                    borderRightColor: '#2c3e50',
                    borderTopColor: '#2c3e50',
                    borderBottomColor: '#16a085',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border-left: 1px solid #000000; border-right: 1px solid #000000; border-top: 1px solid #000000;',
                state: {
                    borderLeftWidth: '1px',
                    borderRightWidth: '1px',
                    borderTopWidth: '1px',
                    borderBottomWidth: '',
                    borderLeftStyle: 'solid',
                    borderRightStyle: 'solid',
                    borderTopStyle: 'solid',
                    borderBottomStyle: '',
                    borderLeftColor: '#000000',
                    borderRightColor: '#000000',
                    borderTopColor: '#000000',
                    borderBottomColor: '',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border-left: 1px solid #000000; border-right: 1px solid #000000; border-bottom: 1px solid #000000;',
                state: {
                    borderLeftWidth: '1px',
                    borderRightWidth: '1px',
                    borderTopWidth: '',
                    borderBottomWidth: '1px',
                    borderLeftStyle: 'solid',
                    borderRightStyle: 'solid',
                    borderTopStyle: '',
                    borderBottomStyle: 'solid',
                    borderLeftColor: '#000000',
                    borderRightColor: '#000000',
                    borderTopColor: '',
                    borderBottomColor: '#000000',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border: 5px dashed #32557f;',
                state: {
                    borderLeftWidth: '5px',
                    borderRightWidth: '5px',
                    borderTopWidth: '5px',
                    borderBottomWidth: '5px',
                    borderLeftStyle: 'dashed',
                    borderRightStyle: 'dashed',
                    borderTopStyle: 'dashed',
                    borderBottomStyle: 'dashed',
                    borderLeftColor: '#32557f',
                    borderRightColor: '#32557f',
                    borderTopColor: '#32557f',
                    borderBottomColor: '#32557f',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border-left: 4px solid #e85f99; border-right: 4px solid #f18867; border-top: 4px solid #65587f; border-bottom: 4px solid #50bda1;',
                state: {
                    borderLeftWidth: '4px',
                    borderRightWidth: '4px',
                    borderTopWidth: '4px',
                    borderBottomWidth: '4px',
                    borderLeftStyle: 'solid',
                    borderRightStyle: 'solid',
                    borderTopStyle: 'solid',
                    borderBottomStyle: 'solid',
                    borderLeftColor: '#e85f99',
                    borderRightColor: '#f18867',
                    borderTopColor: '#65587f',
                    borderBottomColor: '#50bda1',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border: 8px groove;',
                state: {
                    borderLeftWidth: '8px',
                    borderRightWidth: '8px',
                    borderTopWidth: '8px',
                    borderBottomWidth: '8px',
                    borderLeftStyle: 'groove',
                    borderRightStyle: 'groove',
                    borderTopStyle: 'groove',
                    borderBottomStyle: 'groove',
                    borderLeftColor: '',
                    borderRightColor: '',
                    borderTopColor: '',
                    borderBottomColor: '',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border-top: 2px solid #3C514D; border-bottom: 3px dashed #3C514D; border-left: 5px double #212410; border-right: 3px dotted rgb(223,112,0);',
                state: {
                    borderLeftWidth: '5px',
                    borderRightWidth: '3px',
                    borderTopWidth: '2px',
                    borderBottomWidth: '3px',
                    borderLeftStyle: 'double',
                    borderRightStyle: 'dotted',
                    borderTopStyle: 'solid',
                    borderBottomStyle: 'dashed',
                    borderLeftColor: '#212410',
                    borderRightColor: 'rgb(223,112,0)',
                    borderTopColor: '#3C514D',
                    borderBottomColor: '#3C514D',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border: 3px double #3498db;',
                state: {
                    borderLeftWidth: '3px',
                    borderRightWidth: '3px',
                    borderTopWidth: '3px',
                    borderBottomWidth: '3px',
                    borderLeftStyle: 'double',
                    borderRightStyle: 'double',
                    borderTopStyle: 'double',
                    borderBottomStyle: 'double',
                    borderLeftColor: '#3498db',
                    borderRightColor: '#3498db',
                    borderTopColor: '#3498db',
                    borderBottomColor: '#3498db',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border: 6px outset #2ecc71;',
                state: {
                    borderLeftWidth: '6px',
                    borderRightWidth: '6px',
                    borderTopWidth: '6px',
                    borderBottomWidth: '6px',
                    borderLeftStyle: 'outset',
                    borderRightStyle: 'outset',
                    borderTopStyle: 'outset',
                    borderBottomStyle: 'outset',
                    borderLeftColor: '#2ecc71',
                    borderRightColor: '#2ecc71',
                    borderTopColor: '#2ecc71',
                    borderBottomColor: '#2ecc71',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border: 2px solid #e74c3c;',
                state: {
                    borderLeftWidth: '2px',
                    borderRightWidth: '2px',
                    borderTopWidth: '2px',
                    borderBottomWidth: '2px',
                    borderLeftStyle: 'solid',
                    borderRightStyle: 'solid',
                    borderTopStyle: 'solid',
                    borderBottomStyle: 'solid',
                    borderLeftColor: '#e74c3c',
                    borderRightColor: '#e74c3c',
                    borderTopColor: '#e74c3c',
                    borderBottomColor: '#e74c3c',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border-left: 8px ridge #8e44ad; border-right: 8px groove #16a085;',
                state: {
                    borderLeftWidth: '8px',
                    borderRightWidth: '8px',
                    borderTopWidth: '',
                    borderBottomWidth: '',
                    borderLeftStyle: 'ridge',
                    borderRightStyle: 'groove',
                    borderTopStyle: '',
                    borderBottomStyle: '',
                    borderLeftColor: '#8e44ad',
                    borderRightColor: '#16a085',
                    borderTopColor: '',
                    borderBottomColor: '',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border: 5px dotted #2980b9;',
                state: {
                    borderLeftWidth: '5px',
                    borderRightWidth: '5px',
                    borderTopWidth: '5px',
                    borderBottomWidth: '5px',
                    borderLeftStyle: 'dotted',
                    borderRightStyle: 'dotted',
                    borderTopStyle: 'dotted',
                    borderBottomStyle: 'dotted',
                    borderLeftColor: '#2980b9',
                    borderRightColor: '#2980b9',
                    borderTopColor: '#2980b9',
                    borderBottomColor: '#2980b9',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
            {
                style: 'border: 4px dashed rgba(255, 165, 0, 0.8);',
                state: {
                    borderLeftWidth: '4px',
                    borderRightWidth: '4px',
                    borderTopWidth: '4px',
                    borderBottomWidth: '4px',
                    borderLeftStyle: 'dashed',
                    borderRightStyle: 'dashed',
                    borderTopStyle: 'dashed',
                    borderBottomStyle: 'dashed',
                    borderLeftColor: 'rgba(255, 165, 0, 0.8)',
                    borderRightColor: 'rgba(255, 165, 0, 0.8)',
                    borderTopColor: 'rgba(255, 165, 0, 0.8)',
                    borderBottomColor: 'rgba(255, 165, 0, 0.8)',
                    borderTopLeftRadius: '',
                    borderTopRightRadius: '',
                    borderBottomLeftRadius: '',
                    borderBottomRightRadius: '',
                }
            },
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!_value.selector || !_value.lessCSS || !_value.lessCSS.lessAST || !_value.lessCSS.lessAST.ast[_value.selector])
            return;
        const actualAst = _value.lessCSS.lessAST.ast[_value.selector];
        if (!actualAst)
            return;
        let hasRuleBorderInAST = false;
        Object.keys(actualAst).forEach((prop) => {
            if (prop.startsWith('border'))
                hasRuleBorderInAST = true;
        });
        this.clear();
        if (hasRuleBorderInAST) {
            this._onIcaStateChange();
        }
    }
    clear() {
        this.borderLocked = false;
        this.borderRadiusLocked = false;
        this.borderLeft = undefined;
        this.borderRight = undefined;
        this.borderTop = undefined;
        this.borderBottom = undefined;
        this.borderLeftWidth = undefined;
        this.borderRightWidth = undefined;
        this.borderTopWidth = undefined;
        this.borderBottomWidth = undefined;
        this.borderLeftStyle = undefined;
        this.borderRightStyle = undefined;
        this.borderTopStyle = undefined;
        this.borderBottomStyle = undefined;
        this.borderLeftColor = undefined;
        this.borderRightColor = undefined;
        this.borderTopColor = undefined;
        this.borderBottomColor = undefined;
        this.borderTopLeftRadius = undefined;
        this.borderTopRightRadius = undefined;
        this.borderBottomLeftRadius = undefined;
        this.borderBottomRightRadius = undefined;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
                ${this.renderBorderGallery()}
                <div style=${this.showFull === 'false' ? 'display:none' : 'display:block'} >
                    ${this.renderBorder()}
                </div>
                <div style=${this.showFull === 'false' ? 'display:none' : 'display:block'} >
                    ${this.renderBorderRadius()}
                </div>
        `;
    }
    renderBorder() {
        return html `
            <h5 class="helper-group-title" >${this.msg.border}</h5>
            <div class="helper-group-lock">
                <input id="helper-border-lock" ?checked=${this.borderLocked} type="checkbox" @change=${this.handleChangeLockBorder}>
                <label for="helper-border-lock"> ${this.msg.all}</label>
                <i>${this.borderLocked ? collab_lock : collab_lock_open}</i>
            </div>

            <div class="group">

                <div class="group-edit">
                    <i data-tooltip="${this.msg.top}">${collab_border_top}</i>
                    <collab-ds-input-select-color-100554
                        prop="border-top"
                        _valueInput=${this.borderTopWidth}
                        _valueSelect=${this.borderTopStyle}
                        _valueColor=${convertColorToHex(this.borderTopColor || '')}
                        .arrayInputSelect=${this.tpMeasures} 
                        .arraySelect=${this.tpBorder} 
                        group="border"
                        @onchange="${(e) => this.handleChangeBorder(e)}"
                    ></collab-ds-input-select-color-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.left}" >${collab_border_left}</i>
                    <collab-ds-input-select-color-100554
                        prop="border-left"
                        _valueInput=${this.borderLeftWidth}
                        _valueSelect=${this.borderLeftStyle}
                        _valueColor=${convertColorToHex(this.borderLeftColor || '')}
                        .arrayInputSelect=${this.tpMeasures} 
                        .arraySelect=${this.tpBorder} 
                        group="border" 
                        @onchange="${(e) => this.handleChangeBorder(e)}"
                    ></collab-ds-input-select-color-100554>   
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.bottom}">${collab_border_bottom}</i>
                    <collab-ds-input-select-color-100554
                        prop="border-bottom"
                        _valueInput=${this.borderBottomWidth}
                        _valueSelect=${this.borderBottomStyle}
                        _valueColor=${convertColorToHex(this.borderBottomColor || '')}
                        .arrayInputSelect=${this.tpMeasures} 
                        .arraySelect=${this.tpBorder} 
                         group="border" 
                        @onchange="${(e) => this.handleChangeBorder(e)}"
                    ></collab-ds-input-select-color-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.right}">${collab_border_right}</i>
                    <collab-ds-input-select-color-100554
                        prop="border-right"
                        _valueInput=${this.borderRightWidth}
                        _valueSelect=${this.borderRightStyle}
                        _valueColor=${convertColorToHex(this.borderRightColor || '')}
                        .arrayInputSelect=${this.tpMeasures} 
                        .arraySelect=${this.tpBorder} 
                        group="border" 
                        @onchange="${(e) => this.handleChangeBorder(e)}"
                    ></collab-ds-input-select-color-100554>

                </div>
            </div>

        `;
    }
    renderBorderRadius() {
        return html `
            <h5 class="helper-group-title" >${this.msg.borderRadius}</h5>
                <div class="helper-group-lock">
                <input id="helper-border-radius-lock" ?checked=${this.borderRadiusLocked} type="checkbox" @change=${this.handleChangeLockBorderRadius}>
                <label for="helper-border-radius-lock"> ${this.msg.all}</label>
                <i>${this.borderRadiusLocked ? collab_lock : collab_lock_open}</i>
            </div>

            <div class="group">

                <div class="group-edit">
                    <i data-tooltip="${this.msg.topLeft}">${collab_border_topLeft}</i>
                    <collab-ds-input-range-100554
                        prop="border-top-left-radius"
                        value=${this.borderTopLeftRadius}
                        .arraySelect=${this.tpMeasures}  
                        group="radius"
                        @onchange="${(e) => this.handleChangeBorderRadius(e)}"
                    ></collab-ds-input-range-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.topRight}">${collab_border_topRight}</i>
                    <collab-ds-input-range-100554
                        prop="border-top-right-radius"
                        value=${this.borderTopRightRadius}
                        .arraySelect=${this.tpMeasures} 
                        group="radius"
                        @onchange="${(e) => this.handleChangeBorderRadius(e)}"
                    ></collab-ds-input-range-100554>    

                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.bottomLeft}">${collab_border_bottomLeft}</i>
                    <collab-ds-input-range-100554
                        prop="border-bottom-left-radius"
                        value=${this.borderBottomLeftRadius}
                        .arraySelect=${this.tpMeasures} 
                        group="radius"
                        @onchange="${(e) => this.handleChangeBorderRadius(e)}"
                    ></collab-ds-input-range-100554> 

                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.bottomRight}">${collab_border_bottomRight}</i>
                    <collab-ds-input-range-100554
                        prop="border-bottom-right-radius"
                        value=${this.borderBottomRightRadius}
                        .arraySelect=${this.tpMeasures} 
                        group="radius"
                        @onchange="${(e) => this.handleChangeBorderRadius(e)}"
                    ></collab-ds-input-range-100554> 
                </div>
            </div>

        `;
    }
    renderBorderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `<span style="${galleryItem.style}" @click=${() => { this.onGalleryClick(galleryItem); }} > Item</span>`;
        }))}
            </div>
        
        `;
    }
    handleChangeBorder(e) {
        if (this.timeonChangeBorder)
            window.clearTimeout(this.timeonChangeBorder);
        const el = e.detail.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(prop);
        this.timeonChangeBorder = window.setTimeout(() => {
            if (!this.borderLocked) {
                if (!convertedProp)
                    return;
                this[convertedProp] = el.value;
                this.setState();
                return;
            }
            this.borderInputs?.forEach((inp) => {
                if (inp === el)
                    return;
                inp.value = el.value;
            });
            this.borderBottomWidth = this.borderLeft = this.borderRight = this.borderTop = el.value;
            this.setState();
        }, 100);
    }
    handleChangeBorderRadius(e) {
        if (this.timeonChangeBorderRadius)
            window.clearTimeout(this.timeonChangeBorderRadius);
        const el = e.detail.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(prop);
        this.timeonChangeBorderRadius = window.setTimeout(() => {
            if (!this.borderRadiusLocked) {
                if (!convertedProp)
                    return;
                this[convertedProp] = el.value;
                this.setState();
                return;
            }
            this.borderRadiusInputs?.forEach((inp) => {
                if (inp === el)
                    return;
                inp.value = el.value;
            });
            this.borderBottomLeftRadius = this.borderBottomRightRadius = this.borderTopLeftRadius = this.borderTopRightRadius = el.value;
            this.setState();
        }, 100);
    }
    handleChangeLockBorderRadius() {
        if (!this.inputLockRadius)
            return;
        this.borderRadiusLocked = this.inputLockRadius.checked;
    }
    handleChangeLockBorder() {
        if (!this.inputLock)
            return;
        this.borderLocked = this.inputLock.checked;
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    setBorderValues() {
        const aux = {
            'border-bottom': (value) => { this.borderBottom = value; },
            'border-top': (value) => { this.borderTop = value; },
            'border-left': (value) => { this.borderLeft = value; },
            'border-right': (value) => { this.borderRight = value; },
        };
        this.borderInputs?.forEach((bdInp) => {
            const prop = bdInp.getAttribute('prop');
            if (!prop)
                return;
            aux[prop](bdInp.value);
        });
    }
    setState() {
        this.setBorderValues();
        const allBorder = [this.borderTop, this.borderLeft, this.borderBottom, this.borderRight];
        const areBordersAllEqual = allBorder.every(value => value === allBorder[0]);
        const areBorderPairsEqual = (this.borderTop === this.borderBottom) && (this.borderLeft === this.borderRight);
        const allBorderRadius = [this.borderBottomRightRadius, this.borderBottomLeftRadius, this.borderTopLeftRadius, this.borderTopRightRadius];
        const areBorderRadiussAllEqual = allBorderRadius.every(value => value === allBorderRadius[0]);
        const areBorderRadiusPairsEqual = (this.borderBottomLeftRadius === this.borderTopLeftRadius) && (this.borderBottomRightRadius === this.borderTopRightRadius);
        let borderValue;
        let borderRadiusValue;
        if (areBordersAllEqual)
            borderValue = this.borderTop;
        else if (areBorderPairsEqual)
            borderValue = `${this.borderTop} ${this.borderRight}`;
        else {
            borderValue = {
                borderTop: this.borderTop,
                borderRight: this.borderRight,
                borderBottom: this.borderBottom,
                borderLeft: this.borderLeft,
            };
        }
        if (areBorderRadiussAllEqual)
            borderRadiusValue = this.borderTopLeftRadius;
        else if (areBorderRadiusPairsEqual)
            borderRadiusValue = `${this.borderTopLeftRadius} ${this.borderTopRightRadius}`;
        else {
            borderRadiusValue = {
                borderTopLeftRadius: this.borderTopLeftRadius,
                borderTopRightRadius: this.borderTopRightRadius,
                borderBottomLeftRadius: this.borderBottomLeftRadius,
                borderBottomRightRadius: this.borderBottomRightRadius,
            };
        }
        this.checkBorderEquals();
        this.checkBorderRadiusEquals();
        this.updateBorder(borderValue);
        this.updateBorderRadius(borderRadiusValue);
    }
    updateBorderRadius(borderRadius) {
        if (borderRadius === undefined)
            return;
        setState(`less.${this.position}.emitter`, 'helper');
        const styles = getState(`less.${this.position}.lessCSS.styles`);
        if (typeof borderRadius === 'string') {
            styles.borderTopLeftRadius = styles.borderTopRightRadius = styles.borderBottomLeftRadius = styles.borderBottomRightRadius = '';
            styles.borderRadius = borderRadius;
        }
        else {
            styles.borderRadius = '';
            styles.borderBottomLeftRadius = borderRadius.borderBottomLeftRadius || '';
            styles.borderBottomRightRadius = borderRadius.borderBottomRightRadius || '';
            styles.borderTopLeftRadius = borderRadius.borderTopLeftRadius || '';
            styles.borderTopRightRadius = borderRadius.borderTopRightRadius || '';
        }
    }
    updateBorder(border) {
        if (border === undefined)
            return;
        setState(`less.${this.position}.emitter`, 'helper');
        const styles = getState(`less.${this.position}.lessCSS.styles`);
        styles.breakInside;
        if (typeof border === 'string') {
            styles.borderTop = styles.borderRight = styles.borderBottom = styles.borderLeft = '';
            styles.border = border;
        }
        else {
            styles.border = '';
            styles.borderTop = border.borderTop || '';
            styles.borderRight = border.borderRight || '';
            styles.borderBottom = border.borderBottom || '';
            styles.borderLeft = border.borderLeft || '';
        }
    }
    setValues(rule) {
        const borderProps = ['border-left-width', 'border-bottom-width', 'border-top-width', 'border-right-width', 'border-left-style', 'border-bottom-style', 'border-top-style', 'border-right-style', 'border-left-color', 'border-bottom-color', 'border-top-color', 'border-right-color'];
        const borderRadiusProps = ['border-top-right-radius', 'border-top-left-radius', 'border-bottom-left-radius', 'border-bottom-right-radius'];
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (borderRadiusProps.includes(propertyName)) {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const el = this.querySelector(`collab-ds-input-range-100554[prop="${propertyName}"]`);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                    if (el) {
                        el.defaultValue = propertyValue;
                        el.value = propertyValue;
                    }
                }
                if (borderProps.includes(propertyName)) {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                }
            }
            this.checkBorderEquals();
            this.checkBorderRadiusEquals();
        }
    }
    checkBorderEquals() {
        if ([this.borderBottomColor, this.borderTopColor, this.borderRightColor, this.borderLeftColor].every(borderColor => borderColor === this.borderBottomColor) &&
            [this.borderBottomStyle, this.borderTopStyle, this.borderRightStyle, this.borderLeftStyle].every(borderStyle => borderStyle === this.borderBottomStyle) &&
            [this.borderBottomWidth, this.borderTopWidth, this.borderRightWidth, this.borderLeftWidth].every(borderWidth => borderWidth === this.borderBottomWidth)) {
            this.borderLocked = true;
            if (this.inputLock)
                this.inputLock.checked = true;
        }
        else {
            this.borderLocked = false;
            if (this.inputLock)
                this.inputLock.checked = false;
        }
    }
    checkBorderRadiusEquals() {
        if ([this.borderBottomLeftRadius, this.borderBottomRightRadius, this.borderTopLeftRadius, this.borderTopRightRadius].every(borderRadius => borderRadius === this.borderTopRightRadius)) {
            this.borderRadiusLocked = true;
            if (this.inputLockRadius)
                this.inputLockRadius.checked = true;
        }
        else {
            this.borderRadiusLocked = false;
            if (this.inputLockRadius)
                this.inputLockRadius.checked = false;
        }
    }
    replaceTokens(cssText) {
        const tokens = this.state?.lessCSS?.lessAST.ast.root;
        if (!tokens)
            return cssText;
        for (const [token, { value }] of Object.entries(tokens)) {
            const tokenRegex = new RegExp(token, 'g');
            cssText = cssText.replace(tokenRegex, value);
        }
        return cssText;
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        ruleText = this.replaceTokens(ruleText);
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    async onGalleryClick(item) {
        this.borderLeftWidth = item.state.borderLeftWidth;
        this.borderRightWidth = item.state.borderRightWidth;
        this.borderTopWidth = item.state.borderTopWidth;
        this.borderBottomWidth = item.state.borderBottomWidth;
        this.borderLeftStyle = item.state.borderLeftStyle;
        this.borderRightStyle = item.state.borderRightStyle;
        this.borderTopStyle = item.state.borderTopStyle;
        this.borderBottomStyle = item.state.borderBottomStyle;
        this.borderLeftColor = item.state.borderLeftColor;
        this.borderRightColor = item.state.borderRightColor;
        this.borderTopColor = item.state.borderTopColor;
        this.borderBottomColor = item.state.borderBottomColor;
        this.borderTopLeftRadius = item.state.borderTopLeftRadius;
        this.borderTopRightRadius = item.state.borderTopRightRadius;
        this.borderBottomLeftRadius = item.state.borderBottomLeftRadius;
        this.borderBottomRightRadius = item.state.borderBottomRightRadius;
        await this.updateComplete;
        this.checkBorderEquals();
        this.checkBorderRadiusEquals();
        this.setState();
    }
};
__decorate([
    property()
], PluginStyleBorder.prototype, "showFull", void 0);
__decorate([
    propertyDataSource()
], PluginStyleBorder.prototype, "state", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "position", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderLocked", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderRadiusLocked", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderLeft", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderRight", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderTop", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderBottom", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderLeftWidth", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderRightWidth", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderTopWidth", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderBottomWidth", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderLeftStyle", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderRightStyle", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderTopStyle", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderBottomStyle", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderLeftColor", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderRightColor", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderTopColor", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderBottomColor", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderTopLeftRadius", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderTopRightRadius", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderBottomLeftRadius", void 0);
__decorate([
    property()
], PluginStyleBorder.prototype, "borderBottomRightRadius", void 0);
__decorate([
    query('#helper-border-radius-lock')
], PluginStyleBorder.prototype, "inputLockRadius", void 0);
__decorate([
    query('#helper-border-lock')
], PluginStyleBorder.prototype, "inputLock", void 0);
__decorate([
    queryAll('collab-ds-input-select-color-100554')
], PluginStyleBorder.prototype, "borderInputs", void 0);
__decorate([
    queryAll('collab-ds-input-range-100554')
], PluginStyleBorder.prototype, "borderRadiusInputs", void 0);
PluginStyleBorder = __decorate([
    customElement('plugin-style-border-100554')
], PluginStyleBorder);
export { PluginStyleBorder };
