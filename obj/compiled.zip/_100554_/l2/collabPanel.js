/// <mls fileReference="_100554_/l2/collabPanel.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, query } from 'lit/decorators.js';
import '/_100554_/l2/collabPanelItem.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let CollabPanel = class CollabPanel extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-panel-100554 {
  width: 97%;
  padding: 0.5rem;
  border-radius: 3px;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
collab-panel-100554 details {
  box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;
}
collab-panel-100554 summary {
  width: calc(100% - 15px);
  display: flex;
  user-select: none;
  text-transform: uppercase;
  font-weight: 600;
  cursor: pointer;
}
collab-panel-100554 paneltitle {
  width: calc(100% - 17px);
  display: block;
  padding-left: 1rem;
  padding-top: 1px;
}
collab-panel-100554 svg {
  fill: var(--text-primary-color);
}
collab-panel-100554 panelicon {
  width: 15px;
  display: block;
}
collab-panel-100554 collab-panel-content {
  display: flex;
  gap: 1rem;
  width: calc(100% - 35px);
  padding: 1rem;
  flex-wrap: wrap;
}
collab-panel-100554 collab-panel-item-100554.active {
  text-decoration: underline;
}
collab-panel-100554 collab-panel-item-100554 {
  display: block;
  min-width: 7em;
  min-height: 40px;
  cursor: pointer;
  padding-right: 2em;
}
collab-panel-100554 collab-panel-item-100554 collab-panel-item {
  display: flex;
  width: 100%;
  height: 100%;
  align-items: center;
  position: relative;
}
collab-panel-100554 collab-panel-item-100554 collab-panel-item-svg {
  display: flex;
  padding: 4px;
  align-items: center;
  justify-content: center;
}
collab-panel-100554 collab-panel-item-100554 collab-panel-item-svg svg {
  width: 22px;
  fill: var(--text-primary-color);
}
collab-panel-100554 collab-panel-item-100554 collab-panel-item-info {
  display: block;
  padding: 0.5rem 0;
  color: #6b6be6;
}
collab-panel-100554 collab-panel-item-100554 collab-panel-item-badge {
  position: absolute;
  top: 26px;
  left: -1px;
  background: var(--error-color);
  color: #fff;
  font-size: 0.7rem;
  padding: 0.2rem;
  border-radius: 50%;
  width: 1rem;
  display: flex;
  justify-content: center;
  align-items: center;
}
collab-panel-100554 collab-panel-item-100554 .loading {
  background-color: var(--bg-primary-color);
  background: linear-gradient(100deg, rgba(255, 255, 255, 0) 40%, rgba(255, 255, 255, 0.5) 50%, rgba(255, 255, 255, 0) 60%) var(--bg-primary-color);
  background-size: 200% 100%;
  background-position-x: 180%;
  animation: 1s loading ease-in-out infinite;
}
@keyframes loading {
  to {
    background-position-x: -20%;
  }
}
`);
        this.open = true;
        this.myData = [];
        this.minus = '<svg xmlns="http://www.w3.org/2000/svg" style="width:15px"  viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z"/></svg>';
        this.plus = '<svg xmlns="http://www.w3.org/2000/svg" style="width:15px" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg>';
    }
    //---------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    render() {
        if (!this.myData || this.myData.length === 0) {
            return html `<h3 style="margin-left:1rem">Not found plugins</h3>`;
        }
        const category = this.myData[0].category;
        if (!this.icon)
            this.icon = this.open ? unsafeHTML(this.minus) : unsafeHTML(this.plus);
        return html `
            <details open="${this.open}">
                <summary @click=${this.changeSummary}>
                    <paneltitle>${category}</paneltitle>
                    <panelicon>${this.icon}</panelicon>
                </summary>
                <collab-panel-content>
                    ${repeat(this.myData, ((key, idx) => key.widget + idx), ((item, index) => {
            return this.renderItem(item, index);
        }))}
                </collab-panel-content>
            </details>
        `;
    }
    renderItem(item, index) {
        return html `
            <collab-panel-item-100554 widget=${item.widget} mode=${item.mode}>
            </collab-panel-item-100554>
        `;
    }
    //---------IMPLEMENT-------------
    changeSummary() {
        this.icon = !this.detail?.open ? unsafeHTML(this.minus) : unsafeHTML(this.plus);
    }
};
__decorate([
    query('details')
], CollabPanel.prototype, "detail", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabPanel.prototype, "open", void 0);
__decorate([
    property({ reflect: true })
], CollabPanel.prototype, "icon", void 0);
CollabPanel = __decorate([
    customElement('collab-panel-100554')
], CollabPanel);
export { CollabPanel };
