/// <mls fileReference="_100554_/l2/collabNav4Menu.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { collab_bars, collab_bell, collab_chevron_down, collab_xmark } from '/_100554_/l2/collabIcons.js';
let CollabNav4Menu = class CollabNav4Menu extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-nav4-menu-100554 {
  font-family: Cambria, serif;
  font-size: 14px;
  display: block;
  font-weight: 400;
  background: var(--collab-nav-bg-3);
  height: 40px;
  box-shadow: 1px 1px 4px 0 rgba(0, 0, 0, 0.1);
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav {
  display: flex;
  height: 40px;
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab {
  display: flex;
  align-items: center;
  gap: var(--space-8);
  cursor: pointer;
  padding: 6px 12px;
  background: var(--collab-nav-bg-3);
  color: var(--text-primary-color);
  transition: all var(--transition-slow);
  border: none;
  border-bottom: 1px solid var(--bg-secondary-color);
  position: relative;
  z-index: 0;
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab svg {
  fill: currentColor;
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab:hover {
  background: var(--bg-secondary-color-lighter);
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .arrow {
  font-size: 10px;
  transition: transform 0.2s;
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab.active {
  border: 1px solid var(--grey-color);
  border-bottom: none;
  background: var(--bg-secondary-color-lighter);
  font-weight: var(--font-weight-bold);
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .icon {
  display: flex;
  align-items: center;
  font-size: var(--font-size-16);
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .text {
  font-size: 14px;
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .close-btn {
  display: flex;
  margin-left: 4px;
  background: transparent;
  border: none;
  color: var(--text-primary-color-lighter);
  cursor: pointer;
  font-size: var(--font-size-16);
  transition: color var(--transition-slow);
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab .close-btn:hover {
  color: var(--error-color);
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav .collab-nav4-menu-100554-tab.open .dropdown-btn .arrow {
  transform: rotate(180deg);
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav.onlyicon .collab-nav4-menu-100554-tab .text {
  display: none;
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav.onlyicon .collab-nav4-menu-100554-tab.active .text {
  display: inline;
}
collab-nav4-menu-100554 .collab-nav4-menu-100554-nav.fixed .collab-nav4-menu-100554-tab .close-btn {
  display: none;
}
collab-nav4-menu-100554 .dropdown-btn {
  border: 1px solid var(--collab-nav-bg-3);
  border-radius: 8px;
  margin: auto 1rem;
  height: 30px;
  width: 30px;
  cursor: pointer;
  background: var(--collab-nav-bg-3);
}
collab-nav4-menu-100554 .dropdown-btn svg {
  fill: var(--text-primary-color);
}
collab-nav4-menu-100554 .dropdown-menu {
  position: absolute;
  top: 42px;
  left: 10px;
  background: var(--collab-nav-bg-3);
  border: 1px solid var(--collab-nav-bg-3);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.15);
  border-radius: 6px;
  min-width: 300px;
  z-index: 10;
  padding: 4px 0;
}
collab-nav4-menu-100554 .dropdown-menu .dropdown-title {
  text-align: center;
  padding: 0.3rem;
  border-bottom: 1px solid var(--grey-color-light);
}
collab-nav4-menu-100554 .dropdown-menu .dropdown-title h3 {
  font-size: var(--font-size-16);
  margin: 0;
}
collab-nav4-menu-100554 .dropdown-menu .dropdown-item {
  height: 30px;
  padding: 8px 12px;
  cursor: pointer;
  transition: background 0.2s;
  display: flex;
  align-items: center;
  gap: 1rem;
}
collab-nav4-menu-100554 .dropdown-menu .dropdown-item:hover,
collab-nav4-menu-100554 .dropdown-menu .dropdown-item.selected {
  background: var(--bg-secondary-color-lighter);
  color: var(--collab-nav-color-active);
}
`);
        this.selectedIndex = 0;
        this.mode = 'full';
        this.options = [
            { text: 'Home', icon: collab_bars.strings[0].toString(), allowClose: true },
            { text: 'Config', icon: collab_bell.strings[0].toString(), allowClose: true },
            { text: 'Sair', icon: collab_bars.strings[0].toString(), allowClose: true },
        ];
        this.isDropdownOpen = false;
    }
    toggleDropdown() {
        this.isDropdownOpen = !this.isDropdownOpen;
    }
    handleSelect(index) {
        this.selectedIndex = index;
        this.isDropdownOpen = false;
        this.dispatchEvent(new CustomEvent('tab-selected', {
            detail: { index },
            bubbles: true,
            composed: true,
        }));
    }
    handleClose(e, index) {
        e.stopPropagation();
        this.isDropdownOpen = false;
        if (!this.options)
            return;
        const closed = this.options.splice(index, 1);
        this.requestUpdate();
        this.dispatchEvent(new CustomEvent('tab-closed', {
            detail: { index, tab: closed[0] },
            bubbles: true,
            composed: true,
        }));
    }
    render() {
        return html `
			${this.renderNav()}
		`;
    }
    renderNav() {
        return html `
		<nav class="collab-nav4-menu-100554-nav ${this.mode}">
        	<!-- Botão tipo "setinha do Chrome" -->
			<button class="dropdown-btn" @click=${this.toggleDropdown}>
				<span class="arrow">${collab_chevron_down}</span>
			</button>
			${this.options.map((tab, i) => {
            const isActive = i === this.selectedIndex;
            return html `
					<div
						class="collab-nav4-menu-100554-tab ${isActive ? 'active' : ''}"
						@click=${() => this.handleSelect(i)}
					>
						${tab.icon ? html `<span class="icon" .innerHTML=${tab.icon}></span>` : ''}
						${this.mode === 'full' || isActive ? html `<span class="text">${tab.text}</span>` : ''}
						${this.mode !== 'fixed' && tab.allowClose
                ? html `
									<button class="close-btn" @click=${(e) => this.handleClose(e, i)}>
										${collab_xmark}
									</button>
							  `
                : ''}
					</div>
				`;
        })}

		
		</nav>

		${this.isDropdownOpen
            ? html `
					<div class="dropdown-menu">
                        <div class="dropdown-title">
                            <h3>Guias abertas</h3>
                        </div>
						${this.options.map((tab, i) => {
                const isActive = i === this.selectedIndex;
                return html `
								<div class="dropdown-item ${isActive ? 'selected' : ''}" @click=${() => this.handleSelect(i)}>
									${unsafeHTML(tab.icon || '')}
									${tab.text}
								</div>
							`;
            })}
					</div>
			  `
            : ''}
	`;
    }
};
__decorate([
    property({ type: Number, reflect: true })
], CollabNav4Menu.prototype, "selectedIndex", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabNav4Menu.prototype, "mode", void 0);
__decorate([
    property()
], CollabNav4Menu.prototype, "options", void 0);
__decorate([
    state()
], CollabNav4Menu.prototype, "isDropdownOpen", void 0);
CollabNav4Menu = __decorate([
    customElement('collab-nav4-menu-100554')
], CollabNav4Menu);
export { CollabNav4Menu };
