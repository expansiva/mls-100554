/// <mls fileReference="_100554_/l2/collabNav4Menu.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { collab_bars, collab_bell, collab_chevron_down, collab_xmark } from '/_100554_/l2/collabIcons.js';
let CollabNav4Menu = class CollabNav4Menu extends StateLitElement {
    constructor() {
        super(...arguments);
        this.selectedIndex = 0;
        this.mode = 'full';
        this.options = [
            { text: 'Home', icon: collab_bars.strings[0].toString(), allowClose: true },
            { text: 'Config', icon: collab_bell.strings[0].toString(), allowClose: true },
            { text: 'Sair', icon: collab_bars.strings[0].toString(), allowClose: true },
        ];
        this.isDropdownOpen = false;
    }
    toggleDropdown() {
        this.isDropdownOpen = !this.isDropdownOpen;
    }
    handleSelect(index) {
        this.selectedIndex = index;
        this.isDropdownOpen = false;
        this.dispatchEvent(new CustomEvent('tab-selected', {
            detail: { index },
            bubbles: true,
            composed: true,
        }));
    }
    handleClose(e, index) {
        e.stopPropagation();
        this.isDropdownOpen = false;
        if (!this.options)
            return;
        const closed = this.options.splice(index, 1);
        this.requestUpdate();
        this.dispatchEvent(new CustomEvent('tab-closed', {
            detail: { index, tab: closed[0] },
            bubbles: true,
            composed: true,
        }));
    }
    render() {
        return html `
			${this.renderNav()}
		`;
    }
    renderNav() {
        return html `
		<nav class="collab-nav4-menu-100554-nav ${this.mode}">
        	<!-- Botão tipo "setinha do Chrome" -->
			<button class="dropdown-btn" @click=${this.toggleDropdown}>
				<span class="arrow">${collab_chevron_down}</span>
			</button>
			${this.options.map((tab, i) => {
            const isActive = i === this.selectedIndex;
            return html `
					<div
						class="collab-nav4-menu-100554-tab ${isActive ? 'active' : ''}"
						@click=${() => this.handleSelect(i)}
					>
						${tab.icon ? html `<span class="icon" .innerHTML=${tab.icon}></span>` : ''}
						${this.mode === 'full' || isActive ? html `<span class="text">${tab.text}</span>` : ''}
						${this.mode !== 'fixed' && tab.allowClose
                ? html `
									<button class="close-btn" @click=${(e) => this.handleClose(e, i)}>
										${collab_xmark}
									</button>
							  `
                : ''}
					</div>
				`;
        })}

		
		</nav>

		${this.isDropdownOpen
            ? html `
					<div class="dropdown-menu">
                        <div class="dropdown-title">
                            <h3>Guias abertas</h3>
                        </div>
						${this.options.map((tab, i) => {
                const isActive = i === this.selectedIndex;
                return html `
								<div class="dropdown-item ${isActive ? 'selected' : ''}" @click=${() => this.handleSelect(i)}>
									${unsafeHTML(tab.icon || '')}
									${tab.text}
								</div>
							`;
            })}
					</div>
			  `
            : ''}
	`;
    }
};
__decorate([
    property({ type: Number, reflect: true })
], CollabNav4Menu.prototype, "selectedIndex", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabNav4Menu.prototype, "mode", void 0);
__decorate([
    property()
], CollabNav4Menu.prototype, "options", void 0);
__decorate([
    state()
], CollabNav4Menu.prototype, "isDropdownOpen", void 0);
CollabNav4Menu = __decorate([
    customElement('collab-nav4-menu-100554')
], CollabNav4Menu);
export { CollabNav4Menu };
