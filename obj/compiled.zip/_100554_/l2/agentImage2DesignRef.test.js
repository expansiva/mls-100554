/// <mls shortName="agentImage2DesignRef" project="100554" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
