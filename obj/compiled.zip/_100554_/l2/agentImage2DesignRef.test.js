/// <mls fileReference="_100554_/l2/agentImage2DesignRef.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
