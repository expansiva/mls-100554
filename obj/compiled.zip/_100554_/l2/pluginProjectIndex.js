/// <mls fileReference="_100554_/l2/pluginProjectIndex.ts" enhancement="_100554_/l2/enhancementLit" />
// To improve system performance, avoid using imports, as this file is loaded during initialization.
import { PluginBaseIndex } from '/_100554_/l2/pluginBaseIndex.js';
export class PluginProjectIndex extends PluginBaseIndex {
    getMenus() {
        return [
        /*{
            category: 'Details',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectUsage'
        },
        {
            category: 'Details',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectConfig'
        },
        {
            category: 'Details',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectInfo'
        },
        {
            category: 'About',
            scope: ['l5Project'],
            priority: 1,
            auth: ['admin'],
            widget: '_100554_pluginProjectReadMe'
        },
        {
            category: 'Helpers',
            scope: ['l5Project'],
            priority: 1,
            auth: ['*'],
            widget: '_100554_pluginProjectFindFiles'
        },*/
        ];
    }
    getHooks() {
        return [];
    }
    getServices() {
        return [];
    }
}
export default new PluginProjectIndex();
