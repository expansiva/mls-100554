/// <mls fileReference="_100554_/l2/pluginAgentPlayground.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { loadChatPreferences, saveChatPreferences, getUserId, createThread } from '/_102025_/l2/collabMessagesHelper.js';
import { getThreadByName, listThreads, addMessage } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { getTemporaryContext, getAllSteps } from '/_102027_/l2/aiAgentHelper.js';
import { updateHTML } from '/_100554_/l2/collabDOMSync.js';
import { collab_trash } from '/_100554_/l2/collabIcons.js';
import { setState } from '/_102029_/l2/collabState.js';
import { loadAgent, executeBeforePrompt } from '/_102027_/l2/aiAgentOrchestration.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
import "/_100554_/l2/docMd.js";
let AgentTester = class AgentTester extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._agent = '';
        this.inError = false;
        this.agent = '';
        this.activeJudge = false;
        this.msgSelectGroup = false;
        this.activeGroup = false;
        this.combinations = [];
        this.groups = [];
        this.actualGrup = '';
        this.loading = false;
        this.mode = 'input';
        this.result = '';
        this.prompts = [];
        this.list = [];
        this.chatPreferences = {
            translationMode: 'icon',
            language: '',
            threadMaintenance: ''
        };
        this.inEdit = false;
        this.timeSave = 0;
        this.draggedItem = -1;
        this.dropTarget = -1;
        this.dropPosition = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.prompts = this.getPrompts();
        this.innerHTML = '';
        this.style.display = 'block';
    }
    disconnectedCallback() {
        setState('preview.pausePreview', false);
        super.disconnectedCallback();
    }
    async firstUpdated(changedProperties) {
        this.init();
        this.chatPreferences = loadChatPreferences();
        this.list = await listThreads();
    }
    render() {
        const aux = this.loading ? '' : 'none';
        return html `
<div class="overlay" style="display:${aux}">
<div style="display:flex; flex-direction:column">
<div style="display:flex; flex-direction:column; align-items:center; justify-content:center">
    <div class="spinner"></div>
    Running...
</div>

<button @click=${this.openInMessage} class="action-btn" style=" width:300px; margin: 1rem auto; color: var(--bg-primary-color); background: var(--active-color);">Open Message</button>
</div>
</div>
<div class="actions">
${this.renderHead()}
</div>
<div style="height: calc(100% - 85px);">
<div class="tab-header">
<div class="tab-group-left">
<button
class="tab-button ${this.mode === 'input' ? 'active' : ''}" @click=${() => this.selectTabInput()} >
Inputs
</button>
<button
class="tab-button ${this.mode === 'result' ? 'active' : ''}" @click=${() => this.selectTabResult()} >
Result
</button>
<button
class="tab-button ${this.mode === 'settings' ? 'active' : ''}" @click=${() => this.selectTabSettings()} >
Settings
</button>
</div>
</div>
<div class="tab-content">
${this.renderMode()}
</div>
</div>
`;
    }
    renderHead() {
        return html `
<div class="header">
<strong>Agent:</strong> ${this._agent}
<label style=" margin-left: 1rem; margin-top: 5px; display: flex; align-items: center; justify-content: center; font-weight: 600;">
    <input type="checkbox" .checked=${this.activeGroup}  @change=${this._onCheckboxChange} />
    Compare mode
</label>
</div>

<div style="display:flex; gap:1rem;align-items: center;">
${this.renderGroupSelector()}
<button class="action-btn" @click=${() => this.handlePlay()} title="play"><svg style="width: 13px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/></svg></button>
</div>
`;
    }
    renderMode() {
        switch (this.mode) {
            case 'input': return this.renderInputs();
            case 'result': return this.renderResult();
            case 'settings': return this.renderSettings();
            default: return this.renderInputs();
        }
    }
    renderInputs() {
        if (!this.prompts || this.prompts.length === 0)
            return html `
<div class="containerinputs">
<h3>No input found!</h3>
${this.renderButonAdd()}
</div>
`;
        return html `
${this.renderGroups()}
<div class="containerinputs containerdraganddrop">
${repeat(this.prompts, ((key) => key.type + Date.now()), ((p, idx) => { return this.renderPrompt(p, idx); }))}
${this.renderButonAdd()}
</div>
`;
    }
    renderGroups() {
        if (!this.activeGroup)
            return html ``;
        return html `
      <div class="group">
        <select @change=${this.handleSelectChange}>
          <option value="">-- Select a group --</option>
          ${repeat(this.groups, ((key) => key + 'sel'), ((g) => {
            return html `<option value=${g} ?selected=${this.actualGrup === g}>${g}</option>`;
        }))}
          
        </select>

        <button @click=${this.addGroup}>Add</button>
        <button @click=${this.removeGroup} ?disabled=${!this.actualGrup}>Del</button>
        <button @click=${this.setDefaultGroup} ?disabled=${this.actualGrup === 'A'}>Promote to production</button>
      </div>
    `;
    }
    renderGroupSelector() {
        if (!this.activeGroup)
            return html ``;
        return html `
      <div class="group-list">
        
        <label style="display: flex; align-items: center; justify-content: center; font-weight: 600;">
            <input type="checkbox" .checked=${this.activeJudge}  @change=${this._onCheckboxChangeJudge} />
            LLM judge
        </label>
            
        <div style="position:relative">
            <select id="selCompare" @change=${() => this.msgSelectGroup = false}>
            <option value="">-- Select to compare --</option>
            ${repeat(this.combinations, ((key) => key + 'comp'), ((g) => {
            return html `<option value=${g} ?selected=${this.actualGrup === g}>${g.replace(';', ' x ')}</option>`;
        }))}
            
            </select>
            <small style="color:red; position: absolute; top: 29px; left: 0;${this.msgSelectGroup ? '' : 'display:none'}">Select a comparison mode</small>
        </div>
      </div>
    `;
    }
    renderButonAdd() {
        return html `
<div style="display: flex; width: 99%; max-width: 900px; justify-content: flex-start; padding: .5rem; border-top: 1px solid #e0e0e0;">
<button class="action-btn dropdown-toggle" @click=${() => this.addPrompt('system')}><svg style="width: 14px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg> Message</button>
</div>
`;
    }
    renderPrompt(prompt, idx) {
        if (this.actualGrup && this.actualGrup !== prompt.group)
            return html ``;
        let pp = this.escape(prompt.content.trim());
        let content = prompt.type === 'doc' ? '<doc-md-100554 class="stl1">' + this.escape(prompt.content.trim()) + '</doc-md-100554>' : this.escape(prompt.content.trim());
        content = prompt.type !== 'doc' ? content : unsafeHTML(content);
        return html `
<details class="prompt ${prompt.type}" ?open=${prompt.openDetail}
@dragover=${(e) => this.handleDragOver(e, idx, e.currentTarget)}
@dragleave=${(e) => this.handleDragLeave(e, e.currentTarget)}
@drop=${(e) => this.handleDrop(e, e.currentTarget)}
>
<summary @click=${(e) => this.handleDetails(e, prompt)}>
${this.renderMove(idx)}
<div class="pheader">
<div class="type" style="display:flex; align-items: center;gap:.5rem">
${this.renderSelect(prompt)}
<span class="title">
${pp.substring(0, 50)}...
</span>
</div>
<div style="display:flex; gap:.5rem">
<div class="trash itenActions" @click="${(e) => { e.stopPropagation(); this.trashClick(idx); }}">${collab_trash}</div>
<div class="chevron">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
</div>
</div>
</div>
</summary>
<div>
<pre class="content" contenteditable="${prompt.type !== 'doc' ? 'true' : 'false'}" @blur="${(e) => this.promptEvent(e, idx)}" @paste=${this.handlePaste}>${content}</pre>
</div>
</details>
`;
    }
    renderMove(idx) {
        return html `
<div class="moveelement"
draggable="true"
@dragstart=${(e) => this.handleDragStart(e, idx)}
>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512" style="width:6px"><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512" style="width:6px"><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
</div>
`;
    }
    renderSelect(prompt) {
        return html `
<select .value=${prompt.type.trim()} @change=${(e) => this.updateSelect(e, prompt)}>
<option value="system">System</option>
<option value="human">Human</option>
<option value="ai">AI</option>
<option value="memory">Memory</option>
<option value="doc">Doc</option>
</select>
`;
    }
    renderResult() {
        if (typeof this.result !== 'string')
            return this.renderCompare();
        const aux = this.inError ? 'color:red' : '';
        return html `<button @click=${this.openInMessage} class="action-btn" style=" width:calc(100% - 50px); margin: 1rem auto; color: var(--bg-primary-color); background: var(--active-color);">Open Details</button> <pre class="result" style="${aux}"> ${this.escape(this.result)} </pre> `;
    }
    renderCompare() {
        if (typeof this.result === 'string')
            return html ``;
        return html `
      <div class="compare-wrap">
        ${this.result.map((text, idx) => html `
            <div class="pane">
              <div class="pane-header">Item ${idx + 1}</div>
              <div class="pane-content">${this.escape(text)}</div>
            </div>
          `)}
      </div>
    `;
    }
    renderSettings() {
        return html `
<div class="settings">
${this.renderListThread()}
</div>
`;
    }
    renderListThread() {
        return html `
<label>Thread:</label>
<select id="selectThread" @change=${this.handleThreadChange}>
<option value=""></option>
${repeat(this.list, ((key) => key), ((item) => {
            return html `<option value="${item.threadId}">${item.group}/ ${item.name}</option>`;
        }))}
</select>
`;
    }
    //---------IMPLEMENTATION--------
    init() {
        this.verifyProp();
    }
    verifyProp() {
        if (this.agent) {
            this._agent = this.agent;
            return;
        }
        const left = mls.actual[2].left;
        if (!left)
            return;
        const agentName = `_${left.project}_/l2/${left.folder ? left.folder + '/' : ''}${left.shortName}`;
        this._agent = agentName;
    }
    selectTabResult() {
        this.mode = 'result';
    }
    selectTabInput() {
        this.mode = 'input';
    }
    selectTabSettings() {
        this.mode = 'settings';
        setTimeout(() => {
            const select = this.renderRoot.querySelector('select#selectThread');
            if (select) {
                select.value = this.chatPreferences?.threadMaintenance ?? '';
            }
        }, 300);
    }
    updateSelect(e, prompt) {
        const el = e.target;
        if (!el)
            return;
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.type = el.value;
        });
        this.handleSave();
    }
    handleDetails(e, prompt) {
        let el = e.target;
        if (!el || ['select', 'option'].includes(el.tagName.toLocaleLowerCase()))
            return;
        if (el.tagName.toLocaleLowerCase() !== 'details')
            el = el.closest('details');
        if (!el)
            return;
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.openDetail = !el.open;
        });
    }
    addPrompt(type) {
        this.prompts = [
            ...this.prompts,
            {
                type,
                content: '',
                openDetail: false,
                group: this.actualGrup
            }
        ];
    }
    trashClick(idx) {
        this.prompts = this.prompts.filter((_, i) => i !== idx);
        this.handleSave();
    }
    promptEvent(e, activeTabIndex) {
        this.inEdit = true;
        const target = e.target;
        const newValue = this.getCleanPreContent(target);
        this.prompts = this.prompts.map((p, idx) => idx === activeTabIndex ? { ...p, content: newValue, openDetail: true } : p);
        this.handleSave();
    }
    getCleanPreContent(preElement) {
        const walker = document.createTreeWalker(preElement, NodeFilter.SHOW_COMMENT);
        const commentsToRemove = [];
        while (walker.nextNode()) {
            const node = walker.currentNode;
            commentsToRemove.push(node);
        }
        for (const comment of commentsToRemove) {
            comment.parentNode?.removeChild(comment);
        }
        return preElement.innerText.trim();
    }
    async handlePlay() {
        //this.loading = true;
        this.selectTabResult();
        this.msgSelectGroup = false;
        if (this.inEdit) {
            setTimeout(async () => {
                this.handlePlay();
            }, 1100);
            return;
        }
        try {
            const selectedGroups = this.selCompare && this.selCompare.value ? this.selCompare.value.split(';') : [];
            if (selectedGroups.length <= 0 && this.activeGroup) {
                this.msgSelectGroup = true;
                return;
            }
            if (selectedGroups.length <= 0 && !this.actualGrup) {
                const i = this.prompts.find((p) => p.type === 'memory');
                const message = i ? i.content : '';
                const response = await this._callAgent(this._agent, message, this.actualGrup);
                this.result = response;
            }
            else if (selectedGroups.length <= 0 && this.actualGrup) {
                const i = this.prompts.find((p) => p.type === 'memory' && this.actualGrup === p.group);
                const message = i ? i.content : '';
                const response = await this._callAgent(this._agent, message, this.actualGrup);
                this.result = response;
            }
            else if (selectedGroups.length > 0) {
                const arrayPromisse = [];
                selectedGroups.forEach((gp) => {
                    const i = this.prompts.find((p) => p.type === 'memory' && this.actualGrup === gp);
                    const message = i ? i.content : '';
                    arrayPromisse.push(this._callAgent(this._agent, message, gp));
                });
                const ret = await Promise.all(arrayPromisse);
                if (this.activeJudge) {
                    let [ret1, ret2] = ret;
                    ret1 = ret1.split('responded:')?.pop()?.trim() || '';
                    ret2 = ret2.split('responded:')?.pop()?.trim() || '';
                    const obj1 = JSON.parse(ret1);
                    const obj2 = JSON.parse(ret2);
                    const allSteps1 = getAllSteps(obj1.task.iaCompressed.nextSteps);
                    const allSteps2 = getAllSteps(obj2.task.iaCompressed.nextSteps);
                    const obj = {
                        title1: selectedGroups[0],
                        context1: JSON.stringify(allSteps1[allSteps1.length - 1]),
                        title2: selectedGroups[1],
                        context2: JSON.stringify(allSteps2[allSteps2.length - 1]),
                    };
                    this.result = await this._callAgent('_100554_/l2/agentJudge', JSON.stringify(obj), '');
                }
                else {
                    this.result = ret;
                }
            }
            this.selectTabResult();
        }
        catch (err) {
            this.result = `Error when testing agent: ${err.message}`;
            this.selectTabResult();
        }
        finally {
            this.loading = false;
        }
    }
    async handleSave(setDefault = false) {
        clearTimeout(this.timeSave);
        this.timeSave = window.setTimeout(() => {
            setState('preview.pausePreview', true);
            const aux = this.agent ? `agent="${this.agent}"` : '';
            let txt = `<plugin-agent-playground-100554 ${aux} style="display:none">`;
            this.prompts.forEach((p) => {
                txt = txt + ` <promptcustom type="${p.type}" group="${p.group}"> ${this.escapeAngleBrackets(p.content)} </promptcustom> `;
            });
            txt = txt + '</plugin-agent-playground-100554>';
            updateHTML(txt, false);
            this.inEdit = false;
            setTimeout(() => setState('preview.pausePreview', false), 2000);
        }, 500);
    }
    getPrompts() {
        const ret = [];
        Array.from(this.children).forEach((i) => {
            if (i.tagName.toLocaleLowerCase() !== 'promptcustom')
                return;
            const tp = i.getAttribute('type') || 'system';
            const group = i.getAttribute('group') || '';
            const cont = i.innerHTML.trim();
            if (group && !this.groups.includes(group))
                this.groups.push(group);
            ret.push({
                type: tp,
                content: cont,
                openDetail: false,
                group
            });
        });
        this.getPar(this.groups);
        if (!this.actualGrup && this.groups.length > 0) {
            this.actualGrup = 'A';
        }
        return ret;
    }
    handleThreadChange(e) {
        const target = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            threadMaintenance: target.value
        };
        saveChatPreferences(this.chatPreferences);
    }
    async _callAgent(agentName, message, group) {
        let pageName = mls.actual[mls.actualLevel].getFullName();
        if (mls.actualLevel === 2) {
            const info = mls.actual[2].left;
            if (!info)
                return `Agent "${agentName}" error: Not found file`;
            pageName = info.folder ? `_${info.project}_${info.folder}/${info.shortName}` : `${info.project}_${info.shortName}`;
        }
        let thread = await getThreadByName(pageName);
        if (!thread) {
            thread = await createThread(pageName, [], 'company');
        }
        if (!thread)
            return `Agent "${agentName}" error: Not found thread: ${pageName}`;
        const userId = getUserId();
        const threadId = thread.threadId;
        if (!userId)
            return `Agent "${agentName}" error: Not found userID`;
        let context;
        try {
            context = getTemporaryContext(threadId, userId, '@@' + agentName + ' ' + message);
            const now = new Date();
            const formattedDate = now.getFullYear().toString()
                + String(now.getMonth() + 1).padStart(2, '0')
                + String(now.getDate()).padStart(2, '0')
                + String(now.getHours() + 3).padStart(2, '0')
                + String(now.getMinutes()).padStart(2, '0')
                + String(now.getSeconds()).padStart(2, '0')
                + "." + Math.floor(1000 + Math.random() * 9000);
            if (!context.message.createAt)
                context.message.createAt = formattedDate;
        }
        catch (e) {
            this.inError = true;
            return `[pluginAgentPlayground] [getTemporaryContext] Agent "${agentName}" error: ${e.message}\n\n${JSON.stringify(context, null, 2)}`;
        }
        try {
            const agent = await loadAgent(agentName);
            context.isTest = true;
            setState('playgroundAgent.modeCompare', group);
            if (!agent)
                throw new Error('Not found agent:' + agentName);
            await executeBeforePrompt(agent, context);
            if (context.message)
                await addMessage({ ...context.message, footers: [] });
            setState('playgroundAgent.modeCompare', undefined);
            return `[pluginAgentPlayground] Agent "${agentName}" responded:\n${JSON.stringify(context, null, 2)}`;
        }
        catch (e) {
            this.inError = true;
            return `[pluginAgentPlayground] Agent "${agentName}" error: ${e.message}\n\n${JSON.stringify(context, null, 2)}`;
        }
    }
    escapeAngleBrackets(input) {
        return input
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
    escape(input) {
        return input
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>');
    }
    handleDragStart(event, idx) {
        event.stopPropagation();
        this.draggedItem = idx;
        const img = document.createElement('img');
        img.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMSIgaGVpZ2h0PSIxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4=';
        img.style.opacity = '0';
        event.dataTransfer?.setDragImage(img, 0, 0);
    }
    handleDragOver(event, idx, element) {
        event.stopPropagation();
        event.preventDefault();
        if (this.draggedItem < 0)
            return;
        let clientY = 'clientY' in event ? event.clientY : event.touches[0].clientY;
        const rect = element.getBoundingClientRect();
        const offsetY = clientY - rect.top;
        const height = rect.height;
        const details = element.closest('details');
        if (!details)
            return;
        if (offsetY < (height * 0.3) && details) {
            this.dropPosition = 'above';
            details.style.border = "";
            details.style.border = "";
            details.style.borderTop = "2px solid blue";
        }
        else if (offsetY > (height * 0.6) && details) {
            this.dropPosition = 'below';
            details.style.border = "";
            details.style.border = "";
            details.style.borderBottom = "2px solid blue";
        }
        this.dropTarget = idx;
    }
    handleDragLeave(event, element) {
        const details = element.closest('details');
        if (details)
            details.style.border = "";
        element.style.border = "";
    }
    handleDrop(event, element) {
        try {
            event.preventDefault();
            this.prompts = this.moveItemInArray();
        }
        catch (e) {
            console.info(e.message);
        }
        finally {
            element.style.border = "";
            const details = element.closest('details');
            if (details)
                details.style.border = "";
            this.draggedItem = -1;
            this.dropTarget = -1;
            this.dropPosition = null;
            setTimeout(() => { this.handleSave(); }, 500);
        }
    }
    moveItemInArray() {
        if (this.draggedItem < 0 || this.dropTarget < 0 || this.dropPosition === null || this.draggedItem === this.dropTarget) {
            return this.prompts;
        }
        const updatedArray = [...this.prompts];
        const item = updatedArray.splice(this.draggedItem, 1)[0];
        let insertIndex = this.dropTarget;
        if (this.dropPosition === 'below') {
            insertIndex += 1;
        }
        if (this.draggedItem < this.dropTarget) {
            insertIndex -= 1;
        }
        updatedArray.splice(insertIndex, 0, item);
        return updatedArray;
    }
    handlePaste(e) {
        e.preventDefault();
        const text = (e.clipboardData || window.clipboardData).getData('text');
        const selection = window.getSelection();
        if (!selection?.rangeCount)
            return;
        selection.deleteFromDocument();
        const range = selection.getRangeAt(0);
        range.insertNode(document.createTextNode(text));
        selection.collapseToEnd();
    }
    addGroup() {
        if (this.groups.length === 0) {
            this.prompts.forEach((p) => p.group = 'A');
            this.groups = ['A'];
            this.actualGrup = 'A';
        }
        else {
            const last = this.groups[this.groups.length - 1];
            const next = String.fromCharCode(last.charCodeAt(0) + 1);
            const filter = JSON.parse(JSON.stringify(this.prompts.filter((p) => p.group === 'A')));
            filter.forEach((i) => i.group = next);
            this.prompts = [...this.prompts, ...filter];
            this.groups = [...this.groups, next];
            this.getPar(this.groups);
        }
        setTimeout(() => { this.handleSave(true); }, 500);
    }
    changeGrups(arr, g1, g2) {
        return this.sortGroup(arr.map(item => {
            if (item.group === g1) {
                return { ...item, group: g2 };
            }
            if (item.group === g2) {
                return { ...item, group: g1 };
            }
            return item;
        }));
    }
    sortGroup(arr) {
        return [...arr].sort((a, b) => a.group.localeCompare(b.group));
    }
    setDefaultGroup() {
        this.prompts = this.changeGrups(this.prompts, 'A', this.actualGrup);
        this.actualGrup = 'A';
        setTimeout(() => { this.handleSave(true); }, 500);
    }
    removeGroup() {
        if (this.actualGrup) {
            let saveDefault = false;
            this.groups = this.groups.filter(g => g !== this.actualGrup);
            this.prompts = this.prompts.filter(g => g.group !== this.actualGrup);
            this.actualGrup = '';
            setTimeout(() => { this.handleSave(saveDefault); }, 500);
        }
    }
    handleSelectChange(e) {
        const target = e.target;
        this.actualGrup = target.value;
    }
    getPar(arr) {
        let ret = [];
        for (let i = 0; i < arr.length; i++) {
            for (let j = i + 1; j < arr.length; j++) {
                ret.push(`${arr[i]};${arr[j]}`);
            }
        }
        this.combinations = ret;
    }
    _onCheckboxChange(e) {
        const target = e.target;
        this.activeGroup = target.checked;
    }
    _onCheckboxChangeJudge(e) {
        const target = e.target;
        this.activeJudge = target.checked;
    }
    async openInDetails() {
        if (!this.result)
            return;
        const obj = JSON.parse(this.extractJsonString(this.result));
        if (!obj || !obj.message || !obj.task)
            return;
        const messageId2 = `${obj.message.threadId}/${obj.message.createAt}`;
        const el = document.createElement('collab-messages-task-info-102025');
        el.setAttribute('messageId', messageId2);
        el.setAttribute('taskId', obj.task.PK);
        el['task'] = obj.task;
        el['message'] = obj.message;
        el['restartPooling'] = true;
        el['isTest'] = true;
        openElementInServiceDetails(el);
    }
    extractJsonString(input) {
        const start = input.indexOf('{');
        const end = input.lastIndexOf('}');
        if (start === -1 || end === -1 || end < start) {
            throw new Error('JSON não encontrado na string');
        }
        return input.slice(start, end + 1);
    }
    async openInMessage() {
        let pageName = mls.actual[mls.actualLevel].getFullName();
        if (mls.actualLevel === 2) {
            const info = mls.actual[2].left;
            if (!info)
                return;
            pageName = info.folder ? `_${info.project}_${info.folder}/${info.shortName}` : `${info.project}_${info.shortName}`;
        }
        let thread = await getThreadByName(pageName);
        if (!thread) {
            return;
        }
        const threadId = thread.threadId;
        mls.events.fire([2], ['collabMessages'], JSON.stringify({ type: 'thread-open', threadId, taskId: '' }));
    }
};
__decorate([
    property({ type: String })
], AgentTester.prototype, "agent", void 0);
__decorate([
    query('.containerdraganddrop')
], AgentTester.prototype, "containerdraganddrop", void 0);
__decorate([
    query('#selCompare')
], AgentTester.prototype, "selCompare", void 0);
__decorate([
    state()
], AgentTester.prototype, "activeJudge", void 0);
__decorate([
    state()
], AgentTester.prototype, "msgSelectGroup", void 0);
__decorate([
    state()
], AgentTester.prototype, "activeGroup", void 0);
__decorate([
    state()
], AgentTester.prototype, "combinations", void 0);
__decorate([
    state()
], AgentTester.prototype, "groups", void 0);
__decorate([
    state()
], AgentTester.prototype, "actualGrup", void 0);
__decorate([
    state()
], AgentTester.prototype, "loading", void 0);
__decorate([
    state()
], AgentTester.prototype, "mode", void 0);
__decorate([
    state()
], AgentTester.prototype, "result", void 0);
__decorate([
    state()
], AgentTester.prototype, "prompts", void 0);
__decorate([
    state()
], AgentTester.prototype, "list", void 0);
__decorate([
    state()
], AgentTester.prototype, "chatPreferences", void 0);
__decorate([
    state()
], AgentTester.prototype, "actualTaskInDetails", void 0);
__decorate([
    state()
], AgentTester.prototype, "actualDetails", void 0);
AgentTester = __decorate([
    customElement('plugin-agent-playground-100554')
], AgentTester);
export { AgentTester };
