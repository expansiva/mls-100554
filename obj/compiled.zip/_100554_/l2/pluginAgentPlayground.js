/// <mls fileReference="_100554_/l2/pluginAgentPlayground.ts" group="other" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, repeat } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { loadChatPreferences, saveChatPreferences, getUserId, createThread } from '/_102025_/l2/collabMessagesHelper.js';
import { getThreadByName, listThreads } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { getTemporaryContext, getAllSteps } from '/_100554_/l2/aiAgentHelper.js';
import { updateHTML } from '/_100554_/l2/collabDOMSync.js';
import { collab_trash } from '/_100554_/l2/collabIcons.js';
import { setState } from '/_100554_/l2/collabState.js';
import { loadAgent, executeBeforePrompt } from '/_100554_/l2/aiAgentOrchestration.js';
import { openElementInServiceDetails } from '/_100554_/l2/libCommom.js';
let AgentTester = class AgentTester extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-agent-playground-100554{display:block;border:1px solid #ccc;padding:1rem;border-radius:8px;background:#f9f9f9;font-family:var(--font-family-primary);height:calc(100% - 40px);position:relative}plugin-agent-playground-100554 .compare-wrap{display:flex;flex-direction:row;align-items:stretch;height:100%;gap:0;overflow-x:auto;border:1px solid #ddd;border-radius:6px;background:#fafafa}plugin-agent-playground-100554 .compare-wrap .pane{display:flex;flex-direction:column;border-right:1px solid #ddd;background:white}plugin-agent-playground-100554 .compare-wrap .pane:last-child{border-right:none}plugin-agent-playground-100554 .compare-wrap .pane-header{padding:.5rem;font-weight:bold;font-size:.9rem;background:#f0f0f0;border-bottom:1px solid #ddd}plugin-agent-playground-100554 .compare-wrap .pane-content{flex:1 1 auto;padding:.75rem;overflow-y:auto;white-space:pre-wrap;word-break:break-word;line-height:1.5;font-size:.9rem}plugin-agent-playground-100554 .group-list{display:flex;align-items:center;justify-content:center;gap:.5rem}plugin-agent-playground-100554 .group-list select{padding:.4rem;border:1px solid #ccc;border-radius:4px;font-size:.95rem;outline:none}plugin-agent-playground-100554 .group{background:#fafafa;display:flex;flex-direction:row;gap:.5rem;align-items:center;justify-content:center;padding:1rem}plugin-agent-playground-100554 .group select{width:65%;padding:.4rem;border:1px solid #ccc;border-radius:4px;font-size:.95rem;outline:none}plugin-agent-playground-100554 .group button{padding:.4rem .8rem;font-size:.9rem;border:none;border-radius:4px;cursor:pointer;background:#007bff;color:white;transition:background .2s}plugin-agent-playground-100554 .group button:hover{background:#0056b3}plugin-agent-playground-100554 .group button:disabled{background:#ccc;cursor:not-allowed}plugin-agent-playground-100554 textarea{width:calc(100% - 1rem);height:calc(100% - 1rem);padding:.5rem;margin-top:.5rem;border-radius:4px;border:1px solid #ccc;font-family:monospace;resize:vertical}plugin-agent-playground-100554 .loader{margin-top:1rem;font-style:italic;color:#555}plugin-agent-playground-100554 .tab-header{display:flex;justify-content:space-between;border-bottom:1px solid #ccc;background-color:#f0f0f0;overflow:hidden;flex-shrink:0}plugin-agent-playground-100554 .tab-group-left{display:flex;overflow-x:auto;flex:1;min-width:0;scrollbar-width:thin}plugin-agent-playground-100554 .tab-group-left::-webkit-scrollbar{height:6px}plugin-agent-playground-100554 .tab-group-left::-webkit-scrollbar-thumb{background-color:var(--grey-color-darker);border-radius:4px}plugin-agent-playground-100554 .tab-group-right{display:flex;flex-shrink:0}plugin-agent-playground-100554 .tab-item{display:flex;align-items:center;position:relative}plugin-agent-playground-100554 .tab-delete{position:absolute;right:1rem;top:5px;background:transparent;border:none;color:var(--error-color);cursor:pointer;font-size:14px;margin-left:2px;padding:0 4px}plugin-agent-playground-100554 .tab-delete:hover{color:var(--error-color-hover)}plugin-agent-playground-100554 .tab-button{padding:10px 16px;cursor:pointer;background:none;border:none;border-right:1px solid #ddd;font-size:14px;transition:background-color .2s ease;display:flex;flex-direction:column}plugin-agent-playground-100554 .tab-button:hover{background-color:#e0e0e0}plugin-agent-playground-100554 .tab-button.active{background-color:#ffffff;font-weight:bold;border-bottom:2px solid #007bff}plugin-agent-playground-100554 .tab-content{position:relative;flex:1;padding:0;margin:0;background-color:#ffffff;display:flex;height:98%;flex-grow:1;overflow:auto;flex-direction:column}plugin-agent-playground-100554 textarea{resize:none;font-family:monospace;font-size:14px;box-sizing:border-box;background-color:#ffffff;color:#333;outline:none}plugin-agent-playground-100554 .header{display:flex;align-items:center}plugin-agent-playground-100554 .actions{display:flex;justify-content:space-between;padding:10px;gap:10px;background:#fafafa}plugin-agent-playground-100554 button.action-btn{position:relative;padding:8px 16px;cursor:pointer;background-color:#fff;color:#403f3f;box-shadow:rgba(0,0,0,0.046) 0 1px 2px 2px;border:none;border-radius:4px;font-size:14px}plugin-agent-playground-100554 .edit::before{content:' ';position:absolute;top:0;right:0;background-color:red;border-radius:50%;width:10px;height:10px}plugin-agent-playground-100554 button.action-btn:hover{opacity:.8}plugin-agent-playground-100554 .dropdown{position:relative;display:inline-block}plugin-agent-playground-100554 .dropdown .dropdown-toggle{position:relative}plugin-agent-playground-100554 .dropdown .dropdown-menu{display:none;position:absolute;background-color:var(--bg-primary-color);box-shadow:0 2px 8px rgba(0,0,0,0.15);z-index:99;min-width:200px;border-radius:4px;overflow:hidden;margin-top:0px}plugin-agent-playground-100554 .dropdown .dropdown-menu div{padding:8px 12px;cursor:pointer;color:var(--text-primary-color);font-size:var(--font-size-16)}plugin-agent-playground-100554 .dropdown .dropdown-menu div:hover{background-color:var(--bg-primary-color-hover)}plugin-agent-playground-100554 .dropdown:hover .dropdown-menu{display:block}plugin-agent-playground-100554 .settings{padding:1rem}plugin-agent-playground-100554 .settings input,plugin-agent-playground-100554 .settings select{display:flex;font-size:1rem;line-height:1.5;color:#000000;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none;height:25px}plugin-agent-playground-100554 .result{padding:1rem;overflow-y:auto}plugin-agent-playground-100554 .overlay{position:absolute;inset:0;background-color:rgba(0,0,0,0.4);display:flex;justify-content:center;align-items:center;z-index:10;font-size:18px;color:white;font-weight:bold}plugin-agent-playground-100554 .spinner{border:4px solid #434343;border-top:4px solid #ffffff;border-radius:50%;width:30px;height:30px;animation:spin 1s linear infinite;margin-right:12px}@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}plugin-agent-playground-100554 .containerinputs{display:flex;flex-direction:column;gap:.5rem;align-items:center;padding:1.7rem}plugin-agent-playground-100554 .containerinputs details{width:100%;max-width:900px;border:1px solid #e0e0e0;border-radius:8px;background-color:#fafafa;box-shadow:0 2px 8px rgba(0,0,0,0.05);font-family:'Inter',sans-serif;transition:all .3s ease}plugin-agent-playground-100554 .containerinputs details[open] .title{display:none}plugin-agent-playground-100554 .containerinputs details .itenActions{display:none}plugin-agent-playground-100554 .containerinputs details[open] .itenActions{display:block}plugin-agent-playground-100554 .containerinputs details .chevron{transition:transform .3s}plugin-agent-playground-100554 .containerinputs details[open] .chevron{transform:rotate(90deg)}plugin-agent-playground-100554 .containerinputs details .moveelement{display:none;gap:.1rem;align-items:center;justify-content:center;fill:#737373;cursor:grab;width:30px;position:absolute;left:-28px;z-index:9999}plugin-agent-playground-100554 .containerinputs details[open] .moveelement{display:none !important}plugin-agent-playground-100554 .containerinputs details summary{position:relative;cursor:pointer;padding:1rem;border-bottom:1px solid #e0e0e0;display:flex;align-items:center;justify-content:space-between}plugin-agent-playground-100554 .containerinputs details summary:hover .moveelement{display:flex}plugin-agent-playground-100554 .containerinputs details summary .trash{z-index:9999}plugin-agent-playground-100554 .containerinputs details summary .pheader{width:100%;display:flex;justify-content:space-between;align-items:center}plugin-agent-playground-100554 .containerinputs details summary .pheader .title{margin-left:1rem}plugin-agent-playground-100554 .containerinputs details summary .pheader .type select{appearance:none;padding:.4rem 1rem;font-size:.95rem;border:1px solid #ccc;border-radius:6px;background-color:white;transition:border .3s ease}plugin-agent-playground-100554 .containerinputs details summary .pheader .type select:focus{outline:none;border-color:#007bff}plugin-agent-playground-100554 .containerinputs details summary .pheader .trash{cursor:pointer}plugin-agent-playground-100554 .containerinputs details summary .pheader .trash svg{fill:#666;transition:fill .2s ease}plugin-agent-playground-100554 .containerinputs details summary .pheader .trash svg:hover{fill:#e74c3c}plugin-agent-playground-100554 .containerinputs details>div{padding:1rem}plugin-agent-playground-100554 .containerinputs details>div pre.content{width:calc(100% - 2rem);border:none;resize:vertical;padding:1rem;font-size:.95rem;font-family:'Fira Code',monospace;background-color:#fdfdfd;border-radius:6px;color:#333;box-shadow:inset 0 1px 2px rgba(0,0,0,0.05);line-height:1.5;word-break:break-word;white-space:pre-wrap}plugin-agent-playground-100554 .containerinputs details>div pre.content:focus{outline:none;background-color:#fff}`);
        this._agent = '';
        this.inError = false;
        this.agent = '';
        this.activeJudge = false;
        this.msgSelectGroup = false;
        this.activeGroup = false;
        this.combinations = [];
        this.groups = [];
        this.actualGrup = '';
        this.loading = false;
        this.mode = 'input';
        this.result = '';
        this.prompts = [];
        this.list = [];
        this.chatPreferences = {
            translationMode: 'icon',
            language: '',
            threadMaintenance: ''
        };
        this.inEdit = false;
        this.timeSave = 0;
        this.draggedItem = -1;
        this.dropTarget = -1;
        this.dropPosition = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this.prompts = this.getPrompts();
        this.innerHTML = '';
        this.style.display = 'block';
    }
    disconnectedCallback() {
        setState('preview.pausePreview', false);
        super.disconnectedCallback();
    }
    async firstUpdated(changedProperties) {
        this.init();
        this.chatPreferences = loadChatPreferences();
        this.list = await listThreads();
    }
    render() {
        const aux = this.loading ? '' : 'none';
        return html `
<div class="overlay" style="display:${aux}">
<div class="spinner"></div>
Running...
</div>
<div class="actions">
${this.renderHead()}
</div>
<div style="height: calc(100% - 85px);">
<div class="tab-header">
<div class="tab-group-left">
<button
class="tab-button ${this.mode === 'input' ? 'active' : ''}" @click=${() => this.selectTabInput()} >
Inputs
</button>
<button
class="tab-button ${this.mode === 'result' ? 'active' : ''}" @click=${() => this.selectTabResult()} >
Result
</button>
<button
class="tab-button ${this.mode === 'settings' ? 'active' : ''}" @click=${() => this.selectTabSettings()} >
Settings
</button>
</div>
</div>
<div class="tab-content">
${this.renderMode()}
</div>
</div>
`;
    }
    renderHead() {
        return html `
<div class="header">
<strong>Agent:</strong> ${this._agent}
<label style=" margin-left: 1rem; margin-top: 5px; display: flex; align-items: center; justify-content: center; font-weight: 600;">
    <input type="checkbox" .checked=${this.activeGroup}  @change=${this._onCheckboxChange} />
    Compare mode
</label>
</div>

<div style="display:flex; gap:1rem;align-items: center;">
${this.renderGroupSelector()}
<button class="action-btn" @click=${() => this.handlePlay()} title="play"><svg style="width: 13px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path d="M73 39c-14.8-9.1-33.4-9.4-48.5-.9S0 62.6 0 80L0 432c0 17.4 9.4 33.4 24.5 41.9s33.7 8.1 48.5-.9L361 297c14.3-8.7 23-24.2 23-41s-8.7-32.2-23-41L73 39z"/></svg></button>
</div>
`;
    }
    renderMode() {
        switch (this.mode) {
            case 'input': return this.renderInputs();
            case 'result': return this.renderResult();
            case 'settings': return this.renderSettings();
            default: return this.renderInputs();
        }
    }
    renderInputs() {
        if (!this.prompts || this.prompts.length === 0)
            return html `
<div class="containerinputs">
<h3>No input found!</h3>
${this.renderButonAdd()}
</div>
`;
        return html `
${this.renderGroups()}
<div class="containerinputs containerdraganddrop">
${repeat(this.prompts, ((key) => key.type + Date.now()), ((p, idx) => { return this.renderPrompt(p, idx); }))}
${this.renderButonAdd()}
</div>
`;
    }
    renderGroups() {
        if (!this.activeGroup)
            return html ``;
        return html `
      <div class="group">
        <select @change=${this.handleSelectChange}>
          <option value="">-- Select a group --</option>
          ${repeat(this.groups, ((key) => key + 'sel'), ((g) => {
            return html `<option value=${g} ?selected=${this.actualGrup === g}>${g}</option>`;
        }))}
          
        </select>

        <button @click=${this.addGroup}>Add</button>
        <button @click=${this.removeGroup} ?disabled=${!this.actualGrup}>Del</button>
        <button @click=${this.setDefaultGroup} ?disabled=${this.actualGrup === 'A'}>Promote to production</button>
      </div>
    `;
    }
    renderGroupSelector() {
        if (!this.activeGroup)
            return html ``;
        return html `
      <div class="group-list">
        
        <label style="display: flex; align-items: center; justify-content: center; font-weight: 600;">
            <input type="checkbox" .checked=${this.activeJudge}  @change=${this._onCheckboxChangeJudge} />
            LLM judge
        </label>
            
        <div style="position:relative">
            <select id="selCompare" @change=${() => this.msgSelectGroup = false}>
            <option value="">-- Select to compare --</option>
            ${repeat(this.combinations, ((key) => key + 'comp'), ((g) => {
            return html `<option value=${g} ?selected=${this.actualGrup === g}>${g.replace(';', ' x ')}</option>`;
        }))}
            
            </select>
            <small style="color:red; position: absolute; top: 29px; left: 0;${this.msgSelectGroup ? '' : 'display:none'}">Select a comparison mode</small>
        </div>
      </div>
    `;
    }
    renderButonAdd() {
        return html `
<div style="display: flex; width: 99%; max-width: 900px; justify-content: flex-start; padding: .5rem; border-top: 1px solid #e0e0e0;">
<button class="action-btn dropdown-toggle" @click=${() => this.addPrompt('system')}><svg style="width: 14px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg> Message</button>
</div>
`;
    }
    renderPrompt(prompt, idx) {
        if (this.actualGrup && this.actualGrup !== prompt.group)
            return html ``;
        let pp = this.escape(prompt.content.trim());
        return html `
<details class="prompt ${prompt.type}" ?open=${prompt.openDetail}
@dragover=${(e) => this.handleDragOver(e, idx, e.currentTarget)}
@dragleave=${(e) => this.handleDragLeave(e, e.currentTarget)}
@drop=${(e) => this.handleDrop(e, e.currentTarget)}
>
<summary @click=${(e) => this.handleDetails(e, prompt)}>
${this.renderMove(idx)}
<div class="pheader">
<div class="type" style="display:flex; align-items: center;gap:.5rem">
${this.renderSelect(prompt)}
<span class="title">
${pp.substring(0, 50)}...
</span>
</div>
<div style="display:flex; gap:.5rem">
<div class="trash itenActions" @click="${(e) => { e.stopPropagation(); this.trashClick(idx); }}">${collab_trash}</div>
<div class="chevron">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
</div>
</div>
</div>
</summary>
<div>
<pre class="content" contenteditable="true" @blur="${(e) => this.promptEvent(e, idx)}" @paste=${this.handlePaste}>${pp}</pre>
</div>
</details>
`;
    }
    renderMove(idx) {
        return html `
<div class="moveelement"
draggable="true"
@dragstart=${(e) => this.handleDragStart(e, idx)}
>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512" style="width:6px"><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512" style="width:6px"><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
</div>
`;
    }
    renderSelect(prompt) {
        return html `
<select .value=${prompt.type.trim()} @change=${(e) => this.updateSelect(e, prompt)}>
<option value="system">System</option>
<option value="human">Human</option>
<option value="ai">AI</option>
<option value="memory">Memory</option>
</select>
`;
    }
    renderResult() {
        if (typeof this.result !== 'string')
            return this.renderCompare();
        const aux = this.inError ? 'color:red' : '';
        return html `<button @click=${this.openInDetails} class="action-btn" style=" width:calc(100% - 50px); margin: 1rem auto; color: var(--bg-primary-color); background: var(--active-color);">Open Details</button> <pre class="result" style="${aux}"> ${this.escape(this.result)} </pre> `;
    }
    renderCompare() {
        if (typeof this.result === 'string')
            return html ``;
        return html `
      <div class="compare-wrap">
        ${this.result.map((text, idx) => html `
            <div class="pane">
              <div class="pane-header">Item ${idx + 1}</div>
              <div class="pane-content">${this.escape(text)}</div>
            </div>
          `)}
      </div>
    `;
    }
    renderSettings() {
        return html `
<div class="settings">
${this.renderListThread()}
</div>
`;
    }
    renderListThread() {
        return html `
<label>Thread:</label>
<select id="selectThread" @change=${this.handleThreadChange}>
<option value=""></option>
${repeat(this.list, ((key) => key), ((item) => {
            return html `<option value="${item.threadId}">${item.group}/ ${item.name}</option>`;
        }))}
</select>
`;
    }
    //---------IMPLEMENTATION--------
    init() {
        this.verifyProp();
    }
    verifyProp() {
        if (this.agent) {
            this._agent = this.agent;
            return;
        }
        const left = mls.actual[2].left;
        if (!left)
            return;
        const agentName = `_${left.project}_/l2/${left.folder ? left.folder + '/' : ''}${left.shortName}`;
        this._agent = agentName;
    }
    selectTabResult() {
        this.mode = 'result';
    }
    selectTabInput() {
        this.mode = 'input';
    }
    selectTabSettings() {
        this.mode = 'settings';
        setTimeout(() => {
            const select = this.renderRoot.querySelector('select#selectThread');
            if (select) {
                select.value = this.chatPreferences?.threadMaintenance ?? '';
            }
        }, 300);
    }
    updateSelect(e, prompt) {
        const el = e.target;
        if (!el)
            return;
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.type = el.value;
        });
        this.handleSave();
    }
    handleDetails(e, prompt) {
        let el = e.target;
        if (!el || ['select', 'option'].includes(el.tagName.toLocaleLowerCase()))
            return;
        if (el.tagName.toLocaleLowerCase() !== 'details')
            el = el.closest('details');
        if (!el)
            return;
        this.prompts.forEach((p) => {
            if (p.content === prompt.content && p.type === prompt.type)
                p.openDetail = !el.open;
        });
    }
    addPrompt(type) {
        this.prompts = [
            ...this.prompts,
            {
                type,
                content: '',
                openDetail: false,
                group: this.actualGrup
            }
        ];
    }
    trashClick(idx) {
        this.prompts = this.prompts.filter((_, i) => i !== idx);
        this.handleSave();
    }
    promptEvent(e, activeTabIndex) {
        this.inEdit = true;
        const target = e.target;
        const newValue = this.getCleanPreContent(target);
        this.prompts = this.prompts.map((p, idx) => idx === activeTabIndex ? { ...p, content: newValue, openDetail: true } : p);
        this.handleSave();
    }
    getCleanPreContent(preElement) {
        const walker = document.createTreeWalker(preElement, NodeFilter.SHOW_COMMENT);
        const commentsToRemove = [];
        while (walker.nextNode()) {
            const node = walker.currentNode;
            commentsToRemove.push(node);
        }
        for (const comment of commentsToRemove) {
            comment.parentNode?.removeChild(comment);
        }
        return preElement.innerText.trim();
    }
    async handlePlay() {
        this.loading = true;
        this.msgSelectGroup = false;
        if (this.inEdit) {
            setTimeout(async () => {
                this.handlePlay();
            }, 1100);
            return;
        }
        try {
            const selectedGroups = this.selCompare && this.selCompare.value ? this.selCompare.value.split(';') : [];
            if (selectedGroups.length <= 0 && this.activeGroup) {
                this.msgSelectGroup = true;
                return;
            }
            if (selectedGroups.length <= 0 && !this.actualGrup) {
                const i = this.prompts.find((p) => p.type === 'memory');
                const message = i ? i.content : '';
                const response = await this._callAgent(this._agent, message, this.actualGrup);
                this.result = response;
            }
            else if (selectedGroups.length <= 0 && this.actualGrup) {
                const i = this.prompts.find((p) => p.type === 'memory' && this.actualGrup === p.group);
                const message = i ? i.content : '';
                const response = await this._callAgent(this._agent, message, this.actualGrup);
                this.result = response;
            }
            else if (selectedGroups.length > 0) {
                const arrayPromisse = [];
                selectedGroups.forEach((gp) => {
                    const i = this.prompts.find((p) => p.type === 'memory' && this.actualGrup === gp);
                    const message = i ? i.content : '';
                    arrayPromisse.push(this._callAgent(this._agent, message, gp));
                });
                const ret = await Promise.all(arrayPromisse);
                if (this.activeJudge) {
                    let [ret1, ret2] = ret;
                    ret1 = ret1.split('responded:')?.pop()?.trim() || '';
                    ret2 = ret2.split('responded:')?.pop()?.trim() || '';
                    const obj1 = JSON.parse(ret1);
                    const obj2 = JSON.parse(ret2);
                    const allSteps1 = getAllSteps(obj1.task.iaCompressed.nextSteps);
                    const allSteps2 = getAllSteps(obj2.task.iaCompressed.nextSteps);
                    const obj = {
                        title1: selectedGroups[0],
                        context1: JSON.stringify(allSteps1[allSteps1.length - 1]),
                        title2: selectedGroups[1],
                        context2: JSON.stringify(allSteps2[allSteps2.length - 1]),
                    };
                    this.result = await this._callAgent('_100554_/l2/agentJudge', JSON.stringify(obj), '');
                }
                else {
                    this.result = ret;
                }
            }
            this.selectTabResult();
        }
        catch (err) {
            this.result = `Error when testing agent: ${err.message}`;
            this.selectTabResult();
        }
        finally {
            this.loading = false;
        }
    }
    async handleSave(setDefault = false) {
        clearTimeout(this.timeSave);
        this.timeSave = setTimeout(() => {
            setState('preview.pausePreview', true);
            const aux = this.agent ? `agent="${this.agent}"` : '';
            let txt = `<plugin-agent-playground-100554 ${aux} style="display:none">`;
            this.prompts.forEach((p) => {
                txt = txt + ` <promptcustom type="${p.type}" group="${p.group}"> ${this.escapeAngleBrackets(p.content)} </promptcustom> `;
            });
            txt = txt + '</plugin-agent-playground-100554>';
            updateHTML(txt, false);
            this.inEdit = false;
            setTimeout(() => setState('preview.pausePreview', false), 2000);
        }, 500);
    }
    getPrompts() {
        const ret = [];
        Array.from(this.children).forEach((i) => {
            if (i.tagName.toLocaleLowerCase() !== 'promptcustom')
                return;
            const tp = i.getAttribute('type') || 'system';
            const group = i.getAttribute('group') || '';
            const cont = i.innerHTML.trim();
            if (group && !this.groups.includes(group))
                this.groups.push(group);
            ret.push({
                type: tp,
                content: cont,
                openDetail: false,
                group
            });
        });
        this.getPar(this.groups);
        if (!this.actualGrup && this.groups.length > 0) {
            this.actualGrup = 'A';
        }
        return ret;
    }
    handleThreadChange(e) {
        const target = e.target;
        this.chatPreferences = {
            ...this.chatPreferences,
            threadMaintenance: target.value
        };
        saveChatPreferences(this.chatPreferences);
    }
    async _callAgent(agentName, message, group) {
        let pageName = mls.actual[mls.actualLevel].getFullName();
        if (mls.actualLevel === 2) {
            const info = mls.actual[2].left;
            if (!info)
                return `Agent "${agentName}" error: Not found file`;
            pageName = info.folder ? `_${info.project}_${info.folder}/${info.shortName}` : `${info.project}_${info.shortName}`;
        }
        let thread = await getThreadByName(pageName);
        if (!thread) {
            thread = await createThread(pageName, [], 'company');
        }
        if (!thread)
            return `Agent "${agentName}" error: Not found thread: ${pageName}`;
        const userId = getUserId();
        const threadId = thread.threadId;
        if (!userId)
            return `Agent "${agentName}" error: Not found userID`;
        let context;
        try {
            context = getTemporaryContext(threadId, userId, '@@' + agentName + ' ' + message);
        }
        catch (e) {
            this.inError = true;
            return `[pluginAgentPlayground] [getTemporaryContext] Agent "${agentName}" error: ${e.message}\n\n${JSON.stringify(context, null, 2)}`;
        }
        try {
            const agent = await loadAgent(agentName);
            context.modeSingleStep = true;
            setState('playgroundAgent.modeCompare', group);
            if (!agent)
                throw new Error('Not found agent:' + agentName);
            await executeBeforePrompt(agent, context);
            setState('playgroundAgent.modeCompare', undefined);
            return `[pluginAgentPlayground] Agent "${agentName}" responded:\n${JSON.stringify(context, null, 2)}`;
        }
        catch (e) {
            this.inError = true;
            return `[pluginAgentPlayground] Agent "${agentName}" error: ${e.message}\n\n${JSON.stringify(context, null, 2)}`;
        }
    }
    escapeAngleBrackets(input) {
        return input
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }
    escape(input) {
        return input
            .replace(/&lt;/g, '<')
            .replace(/&gt;/g, '>');
    }
    handleDragStart(event, idx) {
        event.stopPropagation();
        this.draggedItem = idx;
        const img = document.createElement('img');
        img.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMSIgaGVpZ2h0PSIxIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciLz4=';
        img.style.opacity = '0';
        event.dataTransfer?.setDragImage(img, 0, 0);
    }
    handleDragOver(event, idx, element) {
        event.stopPropagation();
        event.preventDefault();
        if (this.draggedItem < 0)
            return;
        let clientY = 'clientY' in event ? event.clientY : event.touches[0].clientY;
        const rect = element.getBoundingClientRect();
        const offsetY = clientY - rect.top;
        const height = rect.height;
        const details = element.closest('details');
        if (!details)
            return;
        if (offsetY < (height * 0.3) && details) {
            this.dropPosition = 'above';
            details.style.border = "";
            details.style.border = "";
            details.style.borderTop = "2px solid blue";
        }
        else if (offsetY > (height * 0.6) && details) {
            this.dropPosition = 'below';
            details.style.border = "";
            details.style.border = "";
            details.style.borderBottom = "2px solid blue";
        }
        this.dropTarget = idx;
    }
    handleDragLeave(event, element) {
        const details = element.closest('details');
        if (details)
            details.style.border = "";
        element.style.border = "";
    }
    handleDrop(event, element) {
        try {
            event.preventDefault();
            this.prompts = this.moveItemInArray();
        }
        catch (e) {
            console.info(e.message);
        }
        finally {
            element.style.border = "";
            const details = element.closest('details');
            if (details)
                details.style.border = "";
            this.draggedItem = -1;
            this.dropTarget = -1;
            this.dropPosition = null;
            setTimeout(() => { this.handleSave(); }, 500);
        }
    }
    moveItemInArray() {
        if (this.draggedItem < 0 || this.dropTarget < 0 || this.dropPosition === null || this.draggedItem === this.dropTarget) {
            return this.prompts;
        }
        const updatedArray = [...this.prompts];
        const item = updatedArray.splice(this.draggedItem, 1)[0];
        let insertIndex = this.dropTarget;
        if (this.dropPosition === 'below') {
            insertIndex += 1;
        }
        if (this.draggedItem < this.dropTarget) {
            insertIndex -= 1;
        }
        updatedArray.splice(insertIndex, 0, item);
        return updatedArray;
    }
    handlePaste(e) {
        e.preventDefault();
        const text = (e.clipboardData || window.clipboardData).getData('text');
        const selection = window.getSelection();
        if (!selection?.rangeCount)
            return;
        selection.deleteFromDocument();
        const range = selection.getRangeAt(0);
        range.insertNode(document.createTextNode(text));
        selection.collapseToEnd();
    }
    addGroup() {
        if (this.groups.length === 0) {
            this.prompts.forEach((p) => p.group = 'A');
            this.groups = ['A'];
            this.actualGrup = 'A';
        }
        else {
            const last = this.groups[this.groups.length - 1];
            const next = String.fromCharCode(last.charCodeAt(0) + 1);
            const filter = JSON.parse(JSON.stringify(this.prompts.filter((p) => p.group === 'A')));
            filter.forEach((i) => i.group = next);
            this.prompts = [...this.prompts, ...filter];
            this.groups = [...this.groups, next];
            this.getPar(this.groups);
        }
        setTimeout(() => { this.handleSave(true); }, 500);
    }
    changeGrups(arr, g1, g2) {
        return this.sortGroup(arr.map(item => {
            if (item.group === g1) {
                return { ...item, group: g2 };
            }
            if (item.group === g2) {
                return { ...item, group: g1 };
            }
            return item;
        }));
    }
    sortGroup(arr) {
        return [...arr].sort((a, b) => a.group.localeCompare(b.group));
    }
    setDefaultGroup() {
        this.prompts = this.changeGrups(this.prompts, 'A', this.actualGrup);
        this.actualGrup = 'A';
        setTimeout(() => { this.handleSave(true); }, 500);
    }
    removeGroup() {
        if (this.actualGrup) {
            let saveDefault = false;
            this.groups = this.groups.filter(g => g !== this.actualGrup);
            this.prompts = this.prompts.filter(g => g.group !== this.actualGrup);
            this.actualGrup = '';
            setTimeout(() => { this.handleSave(saveDefault); }, 500);
        }
    }
    handleSelectChange(e) {
        const target = e.target;
        this.actualGrup = target.value;
    }
    getPar(arr) {
        let ret = [];
        for (let i = 0; i < arr.length; i++) {
            for (let j = i + 1; j < arr.length; j++) {
                ret.push(`${arr[i]};${arr[j]}`);
            }
        }
        this.combinations = ret;
    }
    _onCheckboxChange(e) {
        const target = e.target;
        this.activeGroup = target.checked;
    }
    _onCheckboxChangeJudge(e) {
        const target = e.target;
        this.activeJudge = target.checked;
    }
    openInDetails() {
        if (!this.result)
            return;
        const obj = JSON.parse(this.extractJsonString(this.result));
        if (!obj || !obj.message || !obj.task)
            return;
        const messageId2 = `${obj.message.threadId}/${obj.message.createAt}`;
        const el = document.createElement('collab-messages-task-info-102025');
        el.setAttribute('messageId', messageId2);
        el.setAttribute('taskId', obj.task.PK);
        el['task'] = obj.task;
        el['message'] = obj.message;
        openElementInServiceDetails(el);
        /*const task = await this.getTaskUpdate(taskId, messageId, threadId);
        addOrUpdateTask(task);
        this.actualTask = task;
        this.actualMessage = message;

        const messageId2 = `${this.actualThread?.thread.threadId}/${this.actualMessage?.createAt}`
        const el = document.createElement('collab-messages-task-info-102025');
        el.setAttribute('messageId', messageId2);
        if (this.actualTask && this.actualTask.PK) el.setAttribute('taskId', this.actualTask.PK);
        (el as any)['task'] = this.actualTask;
        (el as any)['message'] = this.actualMessage;
        openElementInServiceDetails(el);*/
    }
    extractJsonString(input) {
        const start = input.indexOf('{');
        const end = input.lastIndexOf('}');
        if (start === -1 || end === -1 || end < start) {
            throw new Error('JSON não encontrado na string');
        }
        return input.slice(start, end + 1);
    }
};
__decorate([
    property({ type: String })
], AgentTester.prototype, "agent", void 0);
__decorate([
    query('.containerdraganddrop')
], AgentTester.prototype, "containerdraganddrop", void 0);
__decorate([
    query('#selCompare')
], AgentTester.prototype, "selCompare", void 0);
__decorate([
    state()
], AgentTester.prototype, "activeJudge", void 0);
__decorate([
    state()
], AgentTester.prototype, "msgSelectGroup", void 0);
__decorate([
    state()
], AgentTester.prototype, "activeGroup", void 0);
__decorate([
    state()
], AgentTester.prototype, "combinations", void 0);
__decorate([
    state()
], AgentTester.prototype, "groups", void 0);
__decorate([
    state()
], AgentTester.prototype, "actualGrup", void 0);
__decorate([
    state()
], AgentTester.prototype, "loading", void 0);
__decorate([
    state()
], AgentTester.prototype, "mode", void 0);
__decorate([
    state()
], AgentTester.prototype, "result", void 0);
__decorate([
    state()
], AgentTester.prototype, "prompts", void 0);
__decorate([
    state()
], AgentTester.prototype, "list", void 0);
__decorate([
    state()
], AgentTester.prototype, "chatPreferences", void 0);
AgentTester = __decorate([
    customElement('plugin-agent-playground-100554')
], AgentTester);
export { AgentTester };
