/// <mls shortName="agentCreateNewPrototypeOrganismFeedback" project="100554" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { getAgentStepByAgentName, } from "/_100554_/l2/aiAgentHelper.js";
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { selectLevel, openService } from '/_100554_/l2/libCommom.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    agent1Title: 'Agente (1/3)',
    agent1PromptAnalysis: 'Análise do prompt',
    agent1PromptDefs: 'Preparando arquivo de definição',
    agent2Title: 'Agente (2/3)',
    agent2RequirementAnalysis: 'Analisando arquivo de definição',
    agent2Prepare: 'Criando organismo',
    agent3Title: 'Agente (3/3)',
    agent3StyleAnalysis: 'Analisando style',
    agent3ImprovingStyle: 'Melhorando style do organismo',
    agent3SeePage: 'Ver organismo',
    nextStepsTitle: 'Próximos passos',
    nextStepsMessage: 'O organismo foi criado agora você pode utiliza-lo em suas paginas ou fazer alterações para melhora-lo.'
};
const message_en = {
    loading: 'Loading...',
    agent1Title: 'Agent (1/3)',
    agent1PromptAnalysis: 'Prompt analysis',
    agent1PromptDefs: 'Preparing definition file',
    agent2Title: 'Agent (2/3)',
    agent2RequirementAnalysis: 'Analyzing definition file',
    agent2Prepare: 'Creating organism',
    agent3Title: 'Agent (3/3)',
    agent3StyleAnalysis: 'Analyzing style',
    agent3ImprovingStyle: 'Improving organism style',
    agent3SeePage: 'See organism',
    nextStepsTitle: 'Next steps',
    nextStepsMessage: 'The organism has been created, now you can use it in your pages or make changes to improve it.'
};
const messages = {
    en: message_en,
    pt: message_pt
};
/// **collab_i18n_end**
let AgentCreateNewPrototypeOrganismFeedback100554 = class AgentCreateNewPrototypeOrganismFeedback100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`agent-create-new-prototype-organism-feedback-100554{display:block;padding:1rem;font-size:14px;font-family:'Inter',sans-serif}agent-create-new-prototype-organism-feedback-100554 .feedback-section h3{margin:0}agent-create-new-prototype-organism-feedback-100554 .feedback-section a{color:var(--active-color)}agent-create-new-prototype-organism-feedback-100554 .feedback-section a:hover{color:var(--active-color-hover)}agent-create-new-prototype-organism-feedback-100554 .feedback-section ul{list-style:none;margin-block-start:0}agent-create-new-prototype-organism-feedback-100554 .feedback-section ul li{padding:0}agent-create-new-prototype-organism-feedback-100554 .feedback-section ul li:last-child{margin-bottom:.5rem}agent-create-new-prototype-organism-feedback-100554 .feedback-section .loader{display:inline-block;width:8px;height:8px;border:2px solid #ccc;border-top:2px solid #333;border-radius:50%;animation:spin .6s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}`);
        this.msg = messages['en'];
        this.agent1Running = false;
        this.agent1Complete = false;
        this.agent2Running = false;
        this.agent2Complete = false;
        this.agent3Running = false;
        this.agent3Complete = false;
    }
    async firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        // this.task = await getTask('20250925174013.1001');
    }
    updated(_changedProperties) {
        super.updated(_changedProperties);
        if (_changedProperties.has('task')) {
            this.prepareState();
        }
    }
    prepareState() {
        this.prepareAgentCreateNewPrototypeOrganism1();
        this.prepareAgentCreateNewPrototypeOrganism2();
        this.prepareAgentGenerateStyle();
    }
    prepareAgentCreateNewPrototypeOrganism1() {
        if (!this.task)
            return;
        const agent1 = getAgentStepByAgentName(this.task, 'agentCreateNewPrototypeOrganism');
        if (!agent1)
            return;
        this.agent1Running = agent1.status === 'pending';
        if (agent1.status === 'completed') {
            this.agent1Complete = true;
        }
    }
    prepareAgentCreateNewPrototypeOrganism2() {
        if (!this.task)
            return;
        const agent2 = getAgentStepByAgentName(this.task, 'agentCreateNewPrototypeOrganism2');
        const agent3 = getAgentStepByAgentName(this.task, 'agentGenerateStyle');
        if (!agent2)
            return;
        this.agent2Running = agent2.status === 'pending';
        if (agent2.status === 'completed' || (agent3 && agent3.status === 'pending')) {
            this.agent2Complete = true;
        }
    }
    prepareAgentGenerateStyle() {
        if (!this.task)
            return;
        const agent3 = getAgentStepByAgentName(this.task, 'agentGenerateStyle');
        if (!agent3)
            return;
        this.agent3Running = agent3.status === 'pending';
        if (agent3.status === 'completed') {
            this.agent3Complete = true;
        }
    }
    openPage() {
        if (!this.task)
            return;
        const pageMemory = this.task?.iaCompressed?.longMemory;
        const { project, shortName, folder } = pageMemory;
        if (!project || !shortName)
            return;
        let data = '';
        if (folder) {
            data = `_${project}_${folder}/${shortName}`;
            mls.setActualModule(folder);
        }
        else
            data = `_${project}_${shortName}`;
        const keyToStorFile = mls.stor.getKeyToFiles(project, 2, shortName, folder, '.ts');
        const storFile = mls.stor.files[keyToStorFile];
        if (!storFile)
            return;
        mls.actual[3].setFullName(data);
        selectLevel(3);
        setTimeout(() => {
            openService('_100554_serviceOrganism', 'left', 3);
            openService('_100554_servicPreview', 'right', 3);
        }, 100);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
        <section class="feedback-section">
            <h3>${this.msg.agent1Title} ${this.agent1Running ? html `<span class="loader"></span>` : ''}</h3>
            <ul>
                <li>[ ${this.agent1Complete ? 'x' : ''} ] ${this.msg.agent1PromptAnalysis}</li>
                <li>[ ${this.agent1Complete ? 'x' : ''} ] ${this.msg.agent1PromptDefs}</li>
            </ul>

            <h3>${this.msg.agent2Title} ${this.agent2Running ? html `<span class="loader"></span>` : ''}</h3>
            <ul>
                <li>[ ${this.agent2Complete ? 'x' : ''} ] ${this.msg.agent2RequirementAnalysis}</li>
                <li>[ ${this.agent2Complete ? 'x' : ''} ] ${this.msg.agent2Prepare}</li>

            </ul>

            <h3>${this.msg.agent3Title} ${this.agent3Running ? html `<span class="loader"></span>` : ''}</h3>
            <ul>
                <li>[ ${this.agent3Complete ? 'x' : ''} ] ${this.msg.agent3StyleAnalysis}</li>
                <li>[ ${this.agent3Complete ? 'x' : ''} ] ${this.msg.agent3ImprovingStyle}
                    ${this.agent3Complete ? html `
                    <a
                        href="#"
                        @click=${(e) => {
            e.preventDefault();
            this.openPage();
        }} >
                        ${this.msg.agent3SeePage}
                    </a>` : ''}
                
                </li>
            </ul>

            <h3> ${this.msg.nextStepsTitle}</h3>
            <span>${this.msg.nextStepsMessage}</span>
        
        </section>
    `;
    }
};
__decorate([
    state()
], AgentCreateNewPrototypeOrganismFeedback100554.prototype, "task", void 0);
__decorate([
    state()
], AgentCreateNewPrototypeOrganismFeedback100554.prototype, "agent1Running", void 0);
__decorate([
    state()
], AgentCreateNewPrototypeOrganismFeedback100554.prototype, "agent1Complete", void 0);
__decorate([
    state()
], AgentCreateNewPrototypeOrganismFeedback100554.prototype, "agent2Running", void 0);
__decorate([
    state()
], AgentCreateNewPrototypeOrganismFeedback100554.prototype, "agent2Complete", void 0);
__decorate([
    state()
], AgentCreateNewPrototypeOrganismFeedback100554.prototype, "agent3Running", void 0);
__decorate([
    state()
], AgentCreateNewPrototypeOrganismFeedback100554.prototype, "agent3Complete", void 0);
AgentCreateNewPrototypeOrganismFeedback100554 = __decorate([
    customElement('agent-create-new-prototype-organism-feedback-100554')
], AgentCreateNewPrototypeOrganismFeedback100554);
export { AgentCreateNewPrototypeOrganismFeedback100554 };
