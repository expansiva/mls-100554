/// <mls fileReference="_100554_/l2/collabPreviewL3.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import '/_100554_/l2/collabL3EditText.js';
let CollabPreviewL3 = class CollabPreviewL3 extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-preview-l3-100554 {
  --id-name: ' ';
  position: relative;
  display: block;
}
collab-preview-l3-100554 collab-aux-overlay {
  position: absolute;
  border: 2px solid #4ae24a;
  background: rgba(74, 144, 226, 0.1);
  pointer-events: none;
  z-index: 1000;
  border-radius: 6px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.12);
  transition: all 0.15s ease;
}
collab-preview-l3-100554 collab-selected-overlay {
  position: absolute;
  border: 2px solid #4A90E2;
  background: rgba(74, 144, 226, 0.1);
  pointer-events: none;
  z-index: 1000;
  border-radius: 6px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.12);
  transition: all 0.15s ease;
}
collab-preview-l3-100554 .overlay-menu {
  position: absolute;
  transform: translateY(-110%);
  background: #fff;
  border: 1px solid #ddd;
  border-radius: 6px;
  padding: 4px 6px;
  display: flex;
  align-items: center;
  gap: 4px;
  z-index: 99999;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
}
collab-preview-l3-100554 .overlay-menu button {
  border: none;
  background: transparent;
  cursor: pointer;
  padding: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 4px;
  transition: background 0.2s;
  z-index: 99999;
}
collab-preview-l3-100554 .overlay-menu button:hover {
  background: #f0f0f0;
}
collab-preview-l3-100554 .overlay-menu svg {
  width: 16px;
  height: 16px;
  fill: #4A90E2;
}
`);
        this.init();
    }
    //------VARIABLES---------
    elOverlayHover;
    elOverlaySelected;
    //-------PUBLIC-----------
    setHover(el, active) {
        this._setHover(el, active);
    }
    selectElement(el) {
        this._selectElement(el);
    }
    //-----COMPONENT----------
    render() {
        return html ``;
    }
    //------FUNCTIONS---------
    init() {
        this.createOverlay();
        this.createOverlaySelected();
        this.addEdit();
        this.setEventsMouse();
    }
    setEventsMouse() {
        this.onmouseleave = () => { if (this.elOverlayHover)
            this.elOverlayHover.style.display = 'none'; };
    }
    createOverlay() {
        if (this.elOverlayHover && this.elOverlayHover.isConnected)
            return;
        const div = document.createElement("collab-aux-overlay");
        div.style.outlineOffset = '-2px';
        div.style.zIndex = '99999';
        div.style.display = 'none';
        this.appendChild(div);
        this.elOverlayHover = div;
    }
    createOverlaySelected() {
        if (this.elOverlaySelected && this.elOverlaySelected.isConnected)
            return;
        const div = document.createElement("collab-selected-overlay");
        div.style.outlineOffset = '-2px';
        div.style.display = 'none';
        this.appendChild(div);
        this.elOverlaySelected = div;
    }
    _setHover(el, active) {
        if (!this.elOverlayHover)
            this.createOverlay();
        if (!this.elOverlayHover)
            return;
        if (!el) {
            if (!active) {
                this.elOverlayHover.style.display = 'none';
            }
            return;
        }
        if (el.hasAttribute('clb_mode')) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        if (!active) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        const rect = el.getBoundingClientRect();
        this.elOverlayHover.style.display = 'block';
        this.elOverlayHover.style.top = `${(rect.top + window.scrollY) - 8}px`;
        this.elOverlayHover.style.left = `${rect.left + window.scrollX}px`;
        this.elOverlayHover.style.width = `${rect.width}px`;
        this.elOverlayHover.style.height = `${rect.height}px`;
    }
    _selectElement(el) {
        const els = this.querySelectorAll('*[clb_mode="edit"]');
        els.forEach((e) => e.removeAttribute('clb_mode'));
        if (!this.elOverlaySelected)
            this.createOverlaySelected();
        if (!this.elOverlaySelected)
            return;
        if (this.elOverlayHover)
            this.elOverlayHover.style.display = 'none';
        const rect = el.getBoundingClientRect();
        this.elOverlaySelected.style.display = 'block';
        this.elOverlaySelected.style.top = `${(rect.top + window.scrollY) - 8}px`;
        this.elOverlaySelected.style.left = `${rect.left + window.scrollX}px`;
        this.elOverlaySelected.style.width = `${rect.width}px`;
        this.elOverlaySelected.style.height = `${rect.height}px`;
        this.elOverlaySelected.style.setProperty("--id-name", `'${el.id}'`);
        el.setAttribute('clb_mode', 'edit');
    }
    addEdit() {
    }
};
CollabPreviewL3 = __decorate([
    customElement('collab-preview-l3-100554')
], CollabPreviewL3);
export { CollabPreviewL3 };
