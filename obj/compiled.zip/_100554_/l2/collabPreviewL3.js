/// <mls fileReference="_100554_/l2/collabPreviewL3.ts" enhancement="_blank" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import '/_100554_/l2/collabL3EditText.js';
let CollabPreviewL3 = class CollabPreviewL3 extends CollabLitElement {
    constructor() {
        super();
        this.init();
    }
    //-------PUBLIC-----------
    setHover(el, active) {
        this._setHover(el, active);
    }
    selectElement(el) {
        this._selectElement(el);
    }
    //-----COMPONENT----------
    render() {
        return html ``;
    }
    //------FUNCTIONS---------
    init() {
        this.createOverlay();
        this.createOverlaySelected();
        this.addEdit();
        this.setEventsMouse();
    }
    setEventsMouse() {
        this.onmouseleave = () => { if (this.elOverlayHover)
            this.elOverlayHover.style.display = 'none'; };
    }
    createOverlay() {
        if (this.elOverlayHover && this.elOverlayHover.isConnected)
            return;
        const div = document.createElement("collab-aux-overlay");
        div.style.outlineOffset = '-2px';
        div.style.zIndex = '99999';
        div.style.display = 'none';
        this.appendChild(div);
        this.elOverlayHover = div;
    }
    createOverlaySelected() {
        if (this.elOverlaySelected && this.elOverlaySelected.isConnected)
            return;
        const div = document.createElement("collab-selected-overlay");
        div.style.outlineOffset = '-2px';
        div.style.display = 'none';
        this.appendChild(div);
        this.elOverlaySelected = div;
    }
    _setHover(el, active) {
        if (!this.elOverlayHover)
            this.createOverlay();
        if (!this.elOverlayHover)
            return;
        if (!el) {
            if (!active) {
                this.elOverlayHover.style.display = 'none';
            }
            return;
        }
        if (el.hasAttribute('clb_mode')) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        if (!active) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        const rect = el.getBoundingClientRect();
        this.elOverlayHover.style.display = 'block';
        this.elOverlayHover.style.top = `${rect.top + window.scrollY}px`;
        this.elOverlayHover.style.left = `${rect.left + window.scrollX}px`;
        this.elOverlayHover.style.width = `${rect.width}px`;
        this.elOverlayHover.style.height = `${rect.height}px`;
    }
    _selectElement(el) {
        const els = this.querySelectorAll('*[clb_mode="edit"]');
        els.forEach((e) => e.removeAttribute('clb_mode'));
        if (!this.elOverlaySelected)
            this.createOverlaySelected();
        if (!this.elOverlaySelected)
            return;
        if (this.elOverlayHover)
            this.elOverlayHover.style.display = 'none';
        const rect = el.getBoundingClientRect();
        this.elOverlaySelected.style.display = 'block';
        this.elOverlaySelected.style.top = `${rect.top + window.scrollY}px`;
        this.elOverlaySelected.style.left = `${rect.left + window.scrollX}px`;
        this.elOverlaySelected.style.width = `${rect.width}px`;
        this.elOverlaySelected.style.height = `${rect.height}px`;
        this.elOverlaySelected.style.setProperty("--id-name", `'${el.id}'`);
        el.setAttribute('clb_mode', 'edit');
    }
    addEdit() {
    }
};
CollabPreviewL3 = __decorate([
    customElement('collab-preview-l3-100554')
], CollabPreviewL3);
export { CollabPreviewL3 };
