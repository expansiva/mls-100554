/// <mls fileReference="_100554_/l2/pluginCodeInsights.ts" enhancement="_100554_enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { state } from 'lit/decorators.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
import { getAllDefs } from '/_100554_/l2/libMindMap.js';
export class pluginCodeInsights extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-code-insights-100554{display:block;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;color:var(--text-primary-color);height:100%}plugin-code-insights-100554 .agent-box{max-width:820px;margin:10px auto;padding:.3rem;border-radius:18px}plugin-code-insights-100554 .svg-container{width:22px;margin:4px;display:inline-flex;fill:var(--text-primary-color)}plugin-code-insights-100554 header{display:flex;align-items:center;gap:12px;margin-bottom:24px;border-bottom:1px solid #ececec;padding-bottom:12px}plugin-code-insights-100554 header span{font-size:20px;font-weight:600;margin:0}plugin-code-insights-100554 icon svg{width:22px;height:22px;color:var(--text-primary-color);fill:var(--text-primary-color)}plugin-code-insights-100554 .layout{display:flex;height:100%;background:var(--bg-primary-color);overflow:hidden}plugin-code-insights-100554 .sidebar{width:220px;background:var(--bg-secondary-color-darker);padding:12px 8px;display:flex;flex-direction:column;gap:4px}plugin-code-insights-100554 .menu-item{display:flex;justify-content:space-between;align-items:center;padding:8px 10px;border-radius:8px;cursor:pointer;font-size:13px;color:var(--text-primary-color);transition:all .15s ease}plugin-code-insights-100554 .menu-item:hover{background:rgba(255,255,255,0.06);color:#fff}plugin-code-insights-100554 .menu-item.active{background:#1f2937;color:#fff}plugin-code-insights-100554 .menu-label{font-weight:500}plugin-code-insights-100554 .menu-count{background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:999px;font-size:11px}plugin-code-insights-100554 .content{flex:1;background:var(--bg-primary-color);padding:16px;overflow-y:auto}plugin-code-insights-100554 .file-list{list-style:none;margin:0;padding:0}plugin-code-insights-100554 .file-item{padding:10px 14px;border-radius:8px;font-size:13px;cursor:pointer;transition:background .15s ease}plugin-code-insights-100554 .file-item:hover{opacity:.8}plugin-code-insights-100554 .file-item:not(:last-child){margin-bottom:6px}plugin-code-insights-100554 .empty,plugin-code-insights-100554 .placeholder{color:#9ca3af;font-size:14px}plugin-code-insights-100554 .details-view{display:flex;flex-direction:column;gap:16px}plugin-code-insights-100554 .details-header{display:flex;align-items:center;gap:12px;padding-bottom:12px;border-bottom:1px solid #e5e7eb}plugin-code-insights-100554 .back-btn{background:none;border:none;cursor:pointer;font-size:13px;color:#6b7280;padding:4px 8px;border-radius:6px;transition:background .15s ease}plugin-code-insights-100554 .back-btn:hover{background:#f3f4f6}plugin-code-insights-100554 .file-title{font-weight:600;font-size:14px}plugin-code-insights-100554 .details-body{display:flex;flex-direction:column;gap:10px}plugin-code-insights-100554 .insight-card{background:#f9fafb;padding:10px 12px;border-radius:8px;font-size:13px;border:1px solid #f3f4f6}`);
        this.error = '';
        this.activeCategory = null;
        this.selectedFile = null;
    }
    firstUpdated() {
        this.loadDefs();
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        const propMode = changedProperties.get('mode');
    }
    render() {
        if (!this.element) {
            return html `<div class="empty">No code insights found</div>`;
        }
        const categories = Object.entries(this.element)
            .filter(([_, files]) => Object.keys(files).length > 0);
        return html `
        <div class="agent-box">
            ${this.renderHeader()}
            <div class="layout">
                <!-- SIDEBAR -->
                <aside class="sidebar">
                    ${categories.map(([category, files]) => html `
                        <div
                            class="menu-item ${this.activeCategory === category ? 'active' : ''}"
                            @click=${() => this.activeCategory = category}
                        >
                            <span class="menu-label">
                                ${this.formatCategory(category)}
                            </span>
                            <span class="menu-count">
                                ${Object.keys(files).length}
                            </span>
                        </div>
                    `)}
                </aside>

                <!-- CONTENT -->
                <section class="content">
                    ${this.activeCategory ? html `

                        ${!this.selectedFile ? html `

                            <!-- LISTA DE ARQUIVOS -->
                            <ul class="file-list">
                                ${Object.keys(this.element[this.activeCategory]).map(key => html `
                                    <li 
                                        class="file-item"
                                        @click=${() => this.onClickItem(this.activeCategory, key)}
                                    >
                                        ${key}
                                    </li>
                                `)}
                            </ul>

                        ` : html `

                            <!-- DETAIL VIEW -->
                            ${this.renderDetails()}

                        `}

                    ` : html `
                        <div class="placeholder">
                            Select a category
                        </div>
                    `}
                </section>

            </div>
        </div>
    `;
    }
    renderHeader() {
        return html `
            <header>
                <span class="svg-container">${pluginData.getSvg()}</span>
                <span>${pluginData.title}</span>
            </header>
        `;
    }
    renderDetails() {
        if (!this.activeCategory || !this.selectedFile)
            return html ``;
        const fileData = this.element?.[this.activeCategory][this.selectedFile];
        const insights = fileData?.defs.codeInsights?.[this.activeCategory] ?? [];
        return html `
        <div class="details-view">

            <div class="details-header">
                <button class="back-btn" @click=${this.closeDetails}>
                    ← Back
                </button>

                <div class="file-title">
                    ${this.selectedFile}
                </div>
            </div>

            <div class="details-body">
                ${insights.length ? insights.map((item) => html `
                    <div class="insight-card">
                        ${typeof item === 'string'
            ? item
            : JSON.stringify(item)}
                    </div>
                `) : html `
                    <div class="placeholder">
                        No items found
                    </div>
                `}
            </div>

        </div>
    `;
    }
    //-------IMPLEMENTATION-------
    formatCategory(name) {
        return name
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, s => s.toUpperCase());
    }
    async loadDefs() {
        this.allItens = await getAllDefs();
        const haveInsights = this.getWithCodeInsights();
        if (!haveInsights)
            return;
        this.element = this.groupCodeInsightsByCategory(haveInsights);
    }
    getWithCodeInsights() {
        if (!this.allItens)
            return;
        const itens = {};
        Object.keys(this.allItens).forEach((key) => {
            if (!this.allItens)
                return;
            const item = this.allItens[key];
            if (item.defs.codeInsights &&
                Object.keys(item.defs.codeInsights).length > 0) {
                itens[key] = item;
            }
        });
        return itens;
    }
    groupCodeInsightsByCategory(items) {
        const result = {
            todos: {},
            securityWarnings: {},
            unusedImports: {},
            deadCodeBlocks: {},
            accessibilityIssues: {},
            i18nWarnings: {},
            performanceHints: {}
        };
        Object.keys(items).forEach((keyMain) => {
            const item = items[keyMain];
            if (!item.defs.codeInsights)
                return;
            for (const key in result) {
                const values = item.defs.codeInsights[key];
                if (values?.length) {
                    result[key][keyMain.replace('.defs', '')] = item;
                }
            }
        });
        return result;
    }
    onClickItem(category, key) {
        // Preparado para futura implementação
        console.log('Clicked:', category, key);
        this.selectedFile = key;
        const f = mls.stor.files[key];
        if (!f)
            return;
        this.fireEvents('open', f);
    }
    closeDetails() {
        this.selectedFile = null;
    }
    async fireEvents(action, file, timeout = 0) {
        try {
            const params = {};
            await file.getOrCreateModel();
            params.action = action;
            params.level = file.level;
            params.project = file.project;
            params.shortName = file.shortName;
            params.extension = file.extension;
            params.folder = file.folder;
            params.position = 'left';
            if (['open'].includes(action)) {
                let name = `_${file.project}_${file.shortName}`;
                if (file.folder)
                    name = `_${file.project}_${file.folder}/${file.shortName}`;
                mls.actual[2].setFullName(name);
                mls.actual[2]['left'] = file;
            }
            mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), timeout);
        }
        catch (err) {
        }
    }
}
__decorate([
    state()
], pluginCodeInsights.prototype, "error", void 0);
__decorate([
    state()
], pluginCodeInsights.prototype, "allItens", void 0);
__decorate([
    state()
], pluginCodeInsights.prototype, "element", void 0);
__decorate([
    state()
], pluginCodeInsights.prototype, "activeCategory", void 0);
__decorate([
    state()
], pluginCodeInsights.prototype, "selectedFile", void 0);
if (!customElements.get('plugin-code-insights-100554')) {
    customElements.define('plugin-code-insights-100554', pluginCodeInsights);
}
export const pluginData = {
    title: "Code insights",
    getSvg() {
        return svg `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640"><!--!Font Awesome Free v7.2.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2026 Fonticons, Inc.--><path d="M320 64C334.7 64 348.2 72.1 355.2 85L571.2 485C577.9 497.4 577.6 512.4 570.4 524.5C563.2 536.6 550.1 544 536 544L104 544C89.9 544 76.8 536.6 69.6 524.5C62.4 512.4 62.1 497.4 68.8 485L284.8 85C291.8 72.1 305.3 64 320 64zM320 416C302.3 416 288 430.3 288 448C288 465.7 302.3 480 320 480C337.7 480 352 465.7 352 448C352 430.3 337.7 416 320 416zM320 224C301.8 224 287.3 239.5 288.6 257.7L296 361.7C296.9 374.2 307.4 384 319.9 384C332.5 384 342.9 374.3 343.8 361.7L351.2 257.7C352.5 239.5 338.1 224 319.8 224z"/></svg>
    `;
    }
};
