/// <mls fileReference="_100554_/l2/pluginCreateProjectLocalToDriver.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { gitHubLogin, gitLabLogin, isProviderConnected, gitlabIcon, githubIcon } from '/_100554_/l2/libProviders.js';
import { replaceTripleslashAndTag, createStorFile } from '/_100554_/l2/collabLibStor.js';
import { getLocalProjectName, isValidProjectName, setProjectDetails, deleteLastOpenedFiles } from '/_100554_/l2/libCommom.js';
import { collab_arrows_rotate } from '/_100554_/l2/collabIcons.js';
import { template_package, template_build, template_tsconfig, } from '/_100554_/l2/pluginNewProjectTemplate.js';
import '/_100554_/l2/pluginNewProjectLog.js';
/// **collab_i18n_start**
const message_pt = {
    github: 'GitHub',
    gitlab: 'GitLab',
    connect: 'Conectar',
    connected: 'Conectado',
    btnCancel: 'Cancelar',
    btnContinue: 'Continuar',
    btnRefreshOrg: 'Atualizar',
    step1Msg: `Percebemos que seu projeto ainda não está conectado a um gerenciador de versões. 
  Mas não se preocupe, isso é bem simples. 😉
  Basta fazer login com sua conta do GitHub ou GitLab (se ainda não fez) e depois clicar em Continuar.
  Assim, vamos iniciar o projeto diretamente no provedor que você escolher abaixo:`,
    step2Msg: 'Agora selecione a organização e o modo de atualização.',
    step3Msg: 'Finalmente, selecione a equipe e a visibilidade do projeto.',
    errorNeedConnect: 'Você precisa conectar sua conta do {provider} antes de continuar.',
    projectNameLabel: 'Nome do projeto',
    organizationLabel: 'Organização',
    visibilityLabel: 'Visibilidade do projeto',
    visibilityPublicOption: 'Público - Qualquer pessoa pode ver este repositório.',
    visibilityPrivateOption: 'Privado - Você escolhe quem pode ver.',
    teamLabel: 'Time',
    errorPrjNameInvalid: 'O nome do projeto só pode conter letras, números e _ , e deve começar com uma letra',
    errorPrjNameBlank: 'O nome do projeto deve ser preenchido',
    errorOrgNameBlank: 'A organização deve ser selecionada',
    log_init: "Processando",
    log_error: "Erro",
    log_ok: "Concluido",
    log_0: "Verificando repositório",
    log_1: "Criando repositório",
    log_2: "Criando arquivo de validação",
    log_3: "Criando projeto no collab.codes",
    log_4: "Configurando visibilidade do projeto",
    log_5: "Renomeando projeto",
    log_6: "Criando arquivo de configuração",
    log_7: "Projeto criado com sucesso!",
    log_8: "Criando arquivo inicial README.md",
    log_9: "Criando arquivo inicial package.json",
    log_10: "Criando arquivo inicial build.yml",
    log_11: "Criando arquivo inicial tsconfig.json",
    log_14: "Setando permissão ao action",
    log_15: "Setando variavel no action",
    log_16: "Renomeando arquivos locais",
    log_error_03: "Por favor espere, outro usuário esta utilizando o repositório.",
    log_error_04: "Existe um repositório, mas não foi possível validar o usuário",
    projectOk1: 'Projeto {project} criado com sucesso',
    projectOk2: 'Agora você pode salvar o seu projeto',
};
const message_en = {
    github: 'GitHub',
    gitlab: 'GitLab',
    connect: 'Connect',
    connected: 'Connected',
    btnCancel: 'Cancel',
    btnContinue: 'Continue',
    btnRefreshOrg: 'Refresh',
    step1Msg: `We noticed your project is not yet connected to a version manager. 
  Don't worry, it's very simple. 😉
  Just log in with your GitHub or GitLab account (if you haven't already) and then click Continue.
  This way, we will start the project directly in the provider you choose below:`,
    step2Msg: 'Now select the organization and the update mode.',
    step3Msg: 'Finally select the team and the visibility of the project.',
    errorNeedConnect: 'You need to connect your {provider} account before continuing.',
    projectNameLabel: 'Project name',
    organizationLabel: 'Organization',
    visibilityLabel: 'Project visibility',
    visibilityPublicOption: 'Public - Anyone can see this repository.',
    visibilityPrivateOption: 'Private - You choose who can see.',
    teamLabel: 'Team',
    errorPrjNameBlank: 'Project name must be filled in',
    errorPrjNameInvalid: 'The project name can only contain letters, numbers and _, and must start with a letter',
    errorOrgNameBlank: 'The organization must be selected',
    log_init: "Processing",
    log_error: "Error",
    log_ok: "Completed",
    log_0: "Verify repository",
    log_1: "Creating repository",
    log_2: "Creating validation file",
    log_3: "Creating project on collab.codes",
    log_4: "Setting project visibility",
    log_5: "Renaming project",
    log_6: "Creating configuration file",
    log_7: "Project created successfully!",
    log_8: "Creating initial README.md file",
    log_9: "Creating initial package.json file",
    log_10: "Creating initial build.yml file",
    log_11: "Creating initial tsconfig.json file",
    log_14: "Setting permission to action",
    log_15: "Setting variable in action",
    log_16: "Renaming local files",
    log_error_03: "Please wait, another user is creating; ",
    log_error_04: " There is a repository, but I was unable to validate the user",
    projectOk1: 'Project {project} created sucessfully',
    projectOk2: 'Now you can saving your project',
};
const messages = {
    en: message_en,
    pt: message_pt
};
/// **collab_i18n_end**
let PluginCreateProject = class PluginCreateProject extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-create-project-local-to-driver-100554 {
  display: block;
  font-family: var(--font-family-primary);
  color: var(--text-primary-color);
  font-size: var(--font-size-16);
}
plugin-create-project-local-to-driver-100554 .error-msg {
  color: var(--error-color);
  font-size: 0.9em;
}
plugin-create-project-local-to-driver-100554 input[type="text"].invalid,
plugin-create-project-local-to-driver-100554 textarea.invalid {
  border-color: var(--error-color);
}
plugin-create-project-local-to-driver-100554 .container-select {
  padding: 16px;
  font-family: var(--font-family-primary);
}
plugin-create-project-local-to-driver-100554 .container-select .banner {
  background: var(--bg-secondary-color-lighter);
  padding: 12px;
  border-radius: 8px;
  margin-bottom: 16px;
}
plugin-create-project-local-to-driver-100554 .container-select .providers {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
plugin-create-project-local-to-driver-100554 .container-select .provider {
  display: flex;
  align-items: center;
  gap: 8px;
  background: var(--bg-primary-color);
  border: 1px solid var(--grey-color);
  border-radius: 8px;
  padding: 8px;
}
plugin-create-project-local-to-driver-100554 .container-select .icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
}
plugin-create-project-local-to-driver-100554 .container-select .connected {
  color: var(--success-color);
  margin-left: 6px;
  font-size: 0.9em;
}
plugin-create-project-local-to-driver-100554 .container-select .connect-btn {
  margin-left: 8px;
  font-size: var(--font-size-12);
  padding: 4px 10px;
  border: 1px solid var(--text-secondary-color);
  border-radius: 6px;
  background: transparent;
  color: var(--text-secondary-color);
  cursor: pointer;
  transition: background-color var(--transition-normal), color var(--transition-normal), border-color var(--transition-normal);
}
plugin-create-project-local-to-driver-100554 .container-select .connect-btn:hover {
  background-color: var(--bg-secondary-color-lighter-hover);
  border-color: var(--text-secondary-color-hover);
  color: var(--text-secondary-color-hover);
}
plugin-create-project-local-to-driver-100554 .container-select .connect-btn:focus {
  outline: none;
  border-color: var(--text-secondary-color-focus);
  color: var(--text-secondary-color-focus);
}
plugin-create-project-local-to-driver-100554 .container-select .connect-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
  border-color: var(--text-secondary-color-disabled);
  color: var(--text-secondary-color-disabled);
}
plugin-create-project-local-to-driver-100554 .container-select .actions {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}
plugin-create-project-local-to-driver-100554 .actions {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
  gap: 12px;
}
plugin-create-project-local-to-driver-100554 .actions .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
plugin-create-project-local-to-driver-100554 .actions .cancel {
  background: var(--bg-secondary-color);
  border: none;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
}
plugin-create-project-local-to-driver-100554 .actions .continue {
  background: var(--active-color);
  color: #fff;
  border: none;
  padding: 6px 12px;
  border-radius: 6px;
  cursor: pointer;
}
plugin-create-project-local-to-driver-100554 .actions .continue:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
plugin-create-project-local-to-driver-100554 .container-create {
  padding: 16px;
  font-family: var(--font-family-primary);
}
plugin-create-project-local-to-driver-100554 .container-create input,
plugin-create-project-local-to-driver-100554 .container-create select {
  width: 100%;
}
plugin-create-project-local-to-driver-100554 .container-create label {
  font-size: var(--font-size-12);
}
plugin-create-project-local-to-driver-100554 .container-create input {
  display: block;
  width: 100%;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  margin: 0;
  box-sizing: border-box;
}
plugin-create-project-local-to-driver-100554 .container-create select {
  display: block;
  padding: 0.375rem 2.25rem 0.375rem 0.75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #212529;
  background-color: #fff;
  background-position: right 0.75rem center;
  background-size: 16px 12px;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  box-sizing: border-box;
  text-transform: none;
  margin: 0;
  word-wrap: normal;
}
plugin-create-project-local-to-driver-100554 .container-create .form-disabled {
  pointer-events: none;
  opacity: 0.5;
}
plugin-create-project-local-to-driver-100554 .container-create .orgs-select {
  display: flex;
  gap: 1rem;
}
plugin-create-project-local-to-driver-100554 .container-logs {
  margin-top: 1rem;
}
plugin-create-project-local-to-driver-100554 .container-logs .progress {
  display: flex;
  height: 1rem;
  overflow: hidden;
  font-size: 0.75rem;
  background-color: var(--grey-color-light);
  border-radius: 0.25rem;
  transition: width 0.6s ease;
  margin-bottom: 1rem;
}
plugin-create-project-local-to-driver-100554 .container-logs .progress > div {
  background-color: var(--success-color);
}
plugin-create-project-local-to-driver-100554 .container-logs .progress > div:not(plugin-create-project-local-to-driver-100554 .container-logs .progress > div.finished) {
  animation: progress-bar-stripes 1s linear infinite;
  background-image: linear-gradient(45deg, rgba(255, 255, 255, 0.15) 25%, transparent 25%, transparent 50%, rgba(255, 255, 255, 0.15) 50%, rgba(255, 255, 255, 0.15) 75%, transparent 75%, transparent);
  background-size: 1rem 1rem;
}
plugin-create-project-local-to-driver-100554 .container-logs .progress > div.error {
  background-color: var(--error-color);
  opacity: 0.7;
}
@keyframes progress-bar-stripes {
  0% {
    background-position: 1rem 0;
  }
  100% {
    background-position: 0 0;
  }
}
plugin-create-project-local-to-driver-100554 .container-logs .logs-container {
  min-height: 200px;
  margin-top: 2rem;
  background: #fcfcfc;
  padding: 2rem;
  border-radius: 20px;
}
`);
        this.msg = messages['pt'];
        this.githubConnected = true;
        this.gitlabConnected = false;
        this.errorMessage = null;
        this.actualOrgs = [];
        this.actualTeams = [];
        this.orgSelected = false;
        this.isLoadingOrgs = false;
        this.activeScenerie = 'select';
        this.logs = [];
        this.errorName = '';
        this.errorOrg = '';
        this.login = '';
        this.secret = '';
        this.orgName = '';
        this.projectLocalNumber = mls.stor.LOCALPROJECTNUMBER;
        this.newProjectName = getLocalProjectName() || `project${Date.now()}`;
        this.newProjectNumber = 102014;
        this.newProjectTeam = 'admin';
        this.newProjectVisibility = 'public';
        this.NEWREPONAME = 'mls-new';
        this.VALIDADEFILE = 'validate.json';
        this.drivers = {
            'github': 'GitHub',
            'gitlab': 'GitLab',
        };
        this.urls = {
            'github': 'https://github.com/',
            'gitlab': 'https://gitlab.com/',
        };
    }
    async firstUpdated(changedProperties) {
        super.updated(changedProperties);
        this.githubConnected = isProviderConnected('github');
        this.gitlabConnected = isProviderConnected('gitlab');
    }
    handleSelect(provider) {
        this.selectedProvider = provider;
    }
    handleConnect(provider) {
        if (provider === 'github') {
            gitHubLogin();
        }
        if (provider === 'gitlab') {
            gitLabLogin();
        }
    }
    async handleContinue() {
        this.errorMessage = '';
        if (!this.selectedProvider)
            return;
        const isConnected = this.selectedProvider === 'github'
            ? this.githubConnected
            : this.gitlabConnected;
        if (!isConnected) {
            const providerName = this.selectedProvider === 'github'
                ? this.msg.github
                : this.msg.gitlab;
            this.errorMessage = this.msg.errorNeedConnect.replace('{provider}', providerName);
            return;
        }
        this.isLoadingOrgs = true;
        await this.loadOrgsByDriver(this.selectedProvider);
        this.isLoadingOrgs = false;
        this.activeScenerie = 'form';
    }
    async loadOrgsByDriver(driver) {
        try {
            this.instanceDriver = mls.stor.others.getDriver(driver);
            if (!this.instanceDriver)
                throw new Error('Invalid driver instance');
            const userInfo = await this.instanceDriver.getUserInfo();
            if (!userInfo.login)
                throw new Error('Invalid user login');
            this.login = userInfo.login;
            this.actualOrgs = await this.getOrgsByUser(this.login);
        }
        catch (err) {
            // this.errorDriver = err.message;
            console.error(err.message);
        }
    }
    async getOrgsByUser(user) {
        if (!this.instanceDriver)
            throw new Error('Invalid driver instance');
        const orgs = await this.instanceDriver.getOrganizations(user);
        orgs.unshift({ id: user, name: user, avatarUrl: '', visibility: 'public' });
        return orgs;
    }
    onOrgChanged(e) {
        const value = e.target.value;
        this.orgName = value;
        if (this.login !== this.orgName) {
            const ref = this.actualOrgs.find((o) => o.id === value);
            if (!ref)
                throw new Error('Not found orgName');
            this.orgName = ref.name;
        }
        if (value) {
            this.loadTeamByOrg(value);
        }
        this.orgSelected = !!value;
    }
    async onRefreshOrgsClick(ev) {
        ev.preventDefault();
        this.actualOrgs = await this.getOrgsByUser(this.login);
        this.requestUpdate();
    }
    loadTeamByOrg(org) {
        this.actualTeams = ['admin'];
    }
    getLoginUser() {
        const userNameCollab = mls.getActualUser();
        return userNameCollab;
    }
    addLog(log) {
        this.logs.push(log);
        this.requestUpdate();
    }
    setProgress(nr) {
        if (!this.progress)
            return;
        this.progress.style.width = Math.ceil(nr) + '%';
    }
    setProgressError(enabled) {
        if (!this.progress)
            return;
        if (enabled)
            this.progress.classList.add('error');
        else
            this.progress.classList.remove('error');
    }
    setProgressFinished(finished) {
        if (!this.progress)
            return;
        if (finished)
            this.progress.classList.add('finished');
        else
            this.progress.classList.remove('finished');
    }
    changeStatusLastLog(status, msg) {
        const lastLog = this.logs[this.logs.length - 1];
        if (lastLog) {
            lastLog.status = status;
            lastLog.pre = status === 'finish' ? this.msg.log_ok : this.msg.log_error;
            if (msg)
                lastLog.log = msg;
            this.requestUpdate();
        }
    }
    getUniquePassword() {
        const height = Math.floor(Math.random() * (15 - 6 + 1)) + 6;
        const caracters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        const encoder = new TextEncoder();
        const data = encoder.encode(Date.now().toString() + Math.random());
        const hashBuffer = crypto.subtle.digestSync
            ? crypto.subtle.digestSync('SHA-256', data)
            : null;
        const bytes = hashBuffer ? new Uint8Array(hashBuffer) : crypto.getRandomValues(new Uint8Array(32));
        let password = '';
        for (let i = 0; i < height; i++) {
            const idx = bytes[i % bytes.length] % caracters.length;
            password += caracters[idx];
        }
        return password;
    }
    toogleForm(disabled) {
        if (this.form) {
            this.form.classList.toggle('form-disabled');
        }
    }
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    onCancelStep2() {
        this.orgSelected = false;
        this.actualOrgs = [];
        this.activeScenerie = 'select';
    }
    async tryItem(fc, log) {
        try {
            this.addLog({ pre: this.msg.log_init, log, status: "inprogress" });
            setTimeout(() => this.logsContainer?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 100);
            const rc = await fc();
            if (rc && rc.statusCode === 400) {
                this.changeStatusLastLog('error', 'Error statuscode 400');
                this.setProgressError(true);
                throw new Error('Error statuscode 400');
            }
            if (rc && rc.error) {
                const msg = log + ':' + rc.error;
                this.changeStatusLastLog('error', msg);
                this.setProgressError(true);
                throw new Error(rc.error);
            }
            this.changeStatusLastLog('finish');
            return rc;
        }
        catch (err) {
            const msg = log + ':' + err.message;
            this.changeStatusLastLog('error', msg);
            this.setProgressError(true);
            throw new Error(err.message);
        }
    }
    async setPermissionAction(org, repo) {
        if (this.selectedProvider === 'gitlab' || !this.instanceDriver)
            return;
        return await this.instanceDriver.setPermissionAction(org, repo, '');
    }
    async setVariableAction(org, repo, psw) {
        if (!this.instanceDriver)
            return;
        return await this.instanceDriver.addVariable2(org, repo, 'COLLAB_TOKEN', psw);
    }
    async createInitialReadMe(project) {
        const fileName = 'README.md';
        const content = `ReadMe: ${project}`;
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialBuildFile(project) {
        const fileName = '.github/workflows/build.yml';
        const content = template_build.template.trim().replace(/\[project\]/g, project.toString());
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialPackageFile(project) {
        const fileName = 'package.json';
        const content = template_package.template.replace(/\[project\]/g, project.toString()).trim();
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createInitialTSConfigFile(project) {
        const fileName = 'tsconfig.json';
        const content = template_tsconfig.template.trim();
        await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, fileName, content);
    }
    async createPrjInfo(project) {
        const now = new Date().toISOString();
        this.addTempObject(project, {
            fileInfo: [],
            importsMap: '',
            indexModules: '',
            repository_lastModified: now
        });
        const dt = mls.l5.getProjectSettings(project);
        if (!dt)
            return;
        mls.stor.projects[project] = {
            project,
            projectDependencies: [100554, 102020],
            projectDriver: dt.projectDriver,
            projectURL: dt.projectURL
        };
    }
    addTempObject(projectId, data) {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open("mlsDB", 1);
            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains("tempObjects")) {
                    db.createObjectStore("tempObjects");
                }
            };
            request.onsuccess = (event) => {
                const db = event.target.result;
                const tx = db.transaction("tempObjects", "readwrite");
                const store = tx.objectStore("tempObjects");
                const key = `Prj_${projectId}`;
                const obj = {
                    fileInfo: data.fileInfo ?? [],
                    importsMap: data.importsMap ?? "",
                    indexModules: data.indexModules ?? "",
                    key,
                    project: projectId,
                    repository_lastModified: data.repository_lastModified ?? new Date().toISOString(),
                };
                const putReq = store.put(obj);
                putReq.onsuccess = () => {
                    resolve(obj);
                };
                putReq.onerror = (e) => {
                    reject(e.target.error);
                };
            };
            request.onerror = (e) => {
                reject(e.target.error);
            };
        });
    }
    addFileInfoItem(projectId, newItem) {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open("mlsDB", 1);
            request.onsuccess = (event) => {
                const db = event.target.result;
                const tx = db.transaction("tempObjects", "readwrite");
                const store = tx.objectStore("tempObjects");
                const key = `Prj_${projectId}`;
                const getReq = store.get(key);
                getReq.onsuccess = () => {
                    let obj = getReq.result;
                    if (!obj) {
                        obj = {
                            fileInfo: [],
                            importsMap: "",
                            indexModules: "",
                            key,
                            project: projectId,
                            repository_lastModified: new Date().toISOString(),
                        };
                    }
                    obj.fileInfo = obj.fileInfo || [];
                    obj.fileInfo.push(newItem);
                    const putReq = store.put(obj);
                    putReq.onsuccess = () => resolve(obj);
                    putReq.onerror = (e) => reject(e.target.error);
                };
                getReq.onerror = (e) => reject(e.target.error);
            };
            request.onerror = (e) => reject(e.target.error);
        });
    }
    async migrateAllFiles(storFile, newProject, newShortName, newFolder, needCompile = true) {
        const ret = {};
        for await (let ext of ['.ts', '.html', '.less', '.test.ts', '.defs.ts', '.json']) {
            const key = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, ext);
            if (!mls.stor.files[key])
                continue;
            ret[key] = await this.migrateFile(mls.stor.files[key], newProject, newShortName, newFolder, false);
        }
        return ret;
    }
    async migrateFile(storFile, newProject, newShortName, newFolder, needCompile = true) {
        let source = await storFile.getContent();
        if (!source)
            throw new Error('[migrateFile] Impossible rename this file:' + storFile.shortName);
        if (!newFolder)
            newFolder = storFile.folder;
        if (storFile.level === 2) {
            source = replaceTripleslashAndTag(storFile, newProject, newShortName, newFolder, source);
        }
        const param = {
            shortName: newShortName,
            project: newProject,
            folder: newFolder,
            level: storFile.level,
            source: source,
            extension: storFile.extension,
            status: storFile.status === 'new' ? 'new' : 'renamed',
            fileInfo: {
                originalFolder: storFile.folder,
                originalProject: storFile.project,
                originalShortName: storFile.shortName
            }
        };
        const aux = param.level === 2 && param.shortName === 'designSystem';
        const file = await createStorFile(param, aux, aux, aux);
        if (file.level !== 2) {
            file.inLocalStorage = true;
        }
        await this.prepareToAddFileInfo(source.length, file);
        return file;
    }
    async prepareToAddFileInfo(length, file) {
        const shortPath = `l${file.level}/${file.folder ? file.folder + '/' : ''}${file.shortName}${file.extension}`;
        const data = {
            Length: length,
            shortPath,
            versionRef: file.versionRef
        };
        await this.addFileInfoItem(file.project, data);
    }
    async deleteOldFiles() {
        const filesToDeleteCache = new Set();
        const keys = Object.keys(mls.stor.files).filter((key) => key.startsWith(`${mls.stor.LOCALPROJECTNUMBER}_`));
        for (let key of keys) {
            const storFile = mls.stor.files[key];
            mls.editor.deleteModels(storFile.project, storFile.shortName, storFile.folder, true, storFile.level);
            await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
            const ext = storFile.extension.replace('.ts', '.js');
            let targetKey = `https://collab.codes/local/_${storFile.project}_${storFile.shortName}${ext}?v=`;
            if (storFile.folder)
                targetKey = `https://collab.codes/local/_${storFile.project}_${storFile.folder}/${storFile.shortName}${ext}?v=`;
            filesToDeleteCache.add(targetKey);
            delete mls.stor.files[key];
        }
        const cacheName = 'mls-v2';
        const cache = await caches.open(cacheName);
        const keysCache = await cache.keys();
        for (const request of keysCache) {
            for (const targetKey of filesToDeleteCache) {
                if (request.url.includes(targetKey)) {
                    await cache.delete(request);
                }
            }
        }
    }
    async migrateLocalFiles(oldProject, newProject) {
        await this.createPrjInfo(newProject);
        const keys = Object.keys(mls.stor.files).filter((key) => key.startsWith(`${oldProject}_`));
        const keyOldDesignSystem = `${oldProject}_2_designSystem`;
        const keysFiltered = keys.filter(file => file.startsWith(`${oldProject}_5_`) || /\.ts$/.test(file) && !/\.defs\.ts$/.test(file) && !/\.test\.ts$/.test(file));
        const keyDs = keysFiltered.find((key) => key.startsWith(keyOldDesignSystem));
        if (!keyDs)
            throw new Error('Project must be design system file');
        const storFileDs = mls.stor.files[keyDs];
        if (!storFileDs)
            throw new Error('Project must be design system file');
        const keysOrdened = keysFiltered
            .filter(file => file.trim().startsWith(`${oldProject}_2_`) && file.trim().endsWith(".ts") || !file.trim().startsWith(`${oldProject}_2_`))
            .sort((a, b) => {
            if (a === `${oldProject}_2_designSystem`)
                return -1;
            if (b === `${oldProject}_2_designSystem`)
                return 1;
            return a.localeCompare(b);
        });
        for (let key of keysOrdened) {
            const storFile = mls.stor.files[key];
            const newStorFiles = await this.migrateAllFiles(storFile, newProject, storFile.shortName, storFile.folder, true);
            for (let mode of Object.keys(newStorFiles)) {
                const obj = newStorFiles[mode];
                if (obj && !(obj instanceof Error)) {
                    const content = await obj.getContent();
                    if (typeof content === 'string') {
                        let newContent = '';
                        if (obj.level === 5 && obj.shortName === 'project' && obj.extension === '.json') {
                            newContent = content.replace(/\[org\]/g, this.orgName);
                            await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: newContent });
                        }
                        else {
                            newContent = await this.replaceSpecificProjectId(content, oldProject.toString(), newProject.toString());
                            await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: newContent });
                        }
                    }
                }
            }
        }
        await this.deleteOldFiles();
    }
    replaceSpecificProjectId(code, oldProjectId, newProjectId) {
        const regex = new RegExp(`(?<!\\d)${oldProjectId}(?!\\d)`, "g");
        return code.replace(regex, newProjectId);
    }
    async createProjecInCollab() {
        if (!this.selectedProvider) {
            throw new Error('Error on create project in collab: invalid provider');
        }
        const userNameCollab = this.getLoginUser();
        const param = {
            orgName: this.orgName,
            info: {
                projectDriver: this.drivers[this.selectedProvider],
                projectURL: `${this.urls[this.selectedProvider]}main/${this.orgName}/mls-new/`,
            },
            settings: {
                id: 0,
                name: this.newProjectName,
                owner: userNameCollab,
                userAuth: this.newProjectVisibility,
                archived_at: '',
                created_at: '',
                prj_dependencies: [100554],
                value: '',
                repository_secret: this.secret
            }
        };
        try {
            const res = await mls.api.cbeSaveNewPrj(param);
            return res;
        }
        catch (err) {
            throw new Error('Error on create project in collab' + err.message);
        }
    }
    validateForm() {
        let valid = true;
        this.errorMessage = '';
        this.errorOrg = '';
        this.errorName = '';
        const validName = isValidProjectName(this.newProjectName);
        if (!validName) {
            this.errorName = this.msg.errorPrjNameInvalid;
            valid = false;
        }
        if (!this.newProjectName.trim()) {
            this.errorName = this.msg.errorPrjNameBlank;
            valid = false;
        }
        if (!this.orgName.trim()) {
            this.errorOrg = this.msg.errorOrgNameBlank;
            valid = false;
        }
        return valid;
    }
    async onCreateProjectClickTest(e) {
        e.preventDefault();
        if (!this.validateForm())
            return;
        this.toogleForm(true);
        await this.updateComplete;
        this.logs = [];
        try {
            const rc = 'free';
            let percent = 7.69;
            let newPercent = 0;
            this.setProgressError(false);
            this.setProgressFinished(false);
            this.setProgress(newPercent);
            const simulateFc = async () => {
                await this.sleep(1000);
                return {
                    statusCode: 200,
                    error: ''
                };
            };
            await this.sleep(1000);
            if (rc === 'reuse')
                percent = 9.09;
            newPercent += percent;
            this.setProgress(newPercent);
            if (rc === 'error' || rc === 'wait') {
                const obj = {
                    'wait': this.msg.log_error_03,
                    'error': this.msg.log_error_04,
                };
                this.addLog({ pre: this.msg.log_error, log: obj[rc], status: "error" });
                return;
            }
            if (rc === 'free') {
                let orgName = this.orgName;
                if (this.login !== orgName) {
                    const ref = this.actualOrgs.find((o) => o.name === orgName);
                    if (!ref) {
                        this.changeStatusLastLog('error', 'Error not found org name');
                        this.setProgressError(true);
                        throw new Error('Error not found org name');
                    }
                }
                // createRepository
                await this.tryItem(simulateFc, `${this.msg.log_1}`);
                newPercent += percent;
                this.setProgress(newPercent);
                // createFileInRepo - validate
                await this.tryItem(simulateFc, `${this.msg.log_2}`);
                newPercent += percent;
                this.setProgress(newPercent);
            }
            this.secret = this.getUniquePassword();
            // createProjectInCollab
            await this.tryItem(simulateFc, `${this.msg.log_3}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // Alterando visibilidade
            await this.tryItem(simulateFc, `${this.msg.log_4}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // renomeando
            await this.tryItem(simulateFc, `${this.msg.log_5}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // adiconando permissao action
            await this.tryItem(simulateFc, `${this.msg.log_14}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // adicionando variavel action
            await this.tryItem(simulateFc, `${this.msg.log_15}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // criando readme
            await this.tryItem(simulateFc, `${this.msg.log_8}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // criando build file
            await this.tryItem(simulateFc, `${this.msg.log_10}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // criando package file
            await this.tryItem(simulateFc, `${this.msg.log_9}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // criando tsconfig file
            await this.tryItem(simulateFc, `${this.msg.log_11}`);
            newPercent += percent;
            this.setProgress(newPercent);
            // renomeando arquivos locais
            await this.tryItem(async () => await this.migrateLocalFiles(this.projectLocalNumber, this.newProjectNumber), this.msg.log_16);
            newPercent += percent;
            this.setProgress(newPercent);
            this.addLog({ pre: this.msg.log_ok, log: this.msg.log_7, status: "finish" });
            this.setProgressFinished(true);
            this.setProjectActual(this.newProjectNumber);
            this.setOrgActual(this.newProjectNumber);
            this.dispatchEvent(new CustomEvent('project-local-created', {
                bubbles: true,
                composed: true
            }));
        }
        catch (err) {
            this.toogleForm(false);
        }
    }
    async onCreateProjectClick(e) {
        e.preventDefault();
        if (!this.validateForm())
            return;
        this.toogleForm(true);
        this.logs = [];
        const userNameCollab = this.getLoginUser();
        if (!userNameCollab) {
            this.addLog({ pre: 'Error', log: 'User name not found', status: "error" });
            this.toogleForm(false);
            this.setProgressError(true);
            this.setProgressFinished(true);
            return;
        }
        try {
            let percent = 7.69;
            let newPercent = 0;
            this.setProgressError(false);
            this.setProgressFinished(false);
            this.setProgress(newPercent);
            const rc = await this.tryItem(async () => await this.instanceDriver?.verifyRepositoryNew(this.login, this.NEWREPONAME, userNameCollab), `${this.msg.log_0} ${this.NEWREPONAME}`);
            if (rc === 'reuse')
                percent = 9.09;
            newPercent += percent;
            this.setProgress(newPercent);
            if (rc === 'error' || rc === 'wait') {
                const obj = {
                    'wait': this.msg.log_error_03,
                    'error': this.msg.log_error_04,
                };
                this.addLog({ pre: this.msg.log_error, log: obj[rc], status: "error" });
                this.toogleForm(false);
                return;
            }
            if (rc === 'free') {
                let orgName = this.orgName;
                if (this.login !== orgName) {
                    const ref = this.actualOrgs.find((o) => o.name === orgName);
                    if (!ref) {
                        this.changeStatusLastLog('error', 'Error not found org name');
                        this.setProgressError(true);
                        throw new Error('Error not found org name');
                    }
                    orgName = ref.id;
                }
                await this.tryItem(async () => await this.instanceDriver?.createRepository(this.login, this.NEWREPONAME, orgName, 'new project in collab.codes', 'PUBLIC'), `${this.msg.log_1} ${this.NEWREPONAME} `);
                newPercent += percent;
                this.setProgress(newPercent);
                await this.tryItem(async () => await this.instanceDriver?.createFileInRepo(this.orgName, this.NEWREPONAME, this.VALIDADEFILE, `{ "users": [ "${userNameCollab}" ] }`), `${this.msg.log_2} ${this.VALIDADEFILE} `);
                newPercent += percent;
                this.setProgress(newPercent);
            }
            this.secret = this.getUniquePassword();
            this.newProjectNumber = await this.tryItem(this.createProjecInCollab.bind(this), `${this.msg.log_3}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            if (this.newProjectVisibility === 'private')
                await this.tryItem(async () => await this.instanceDriver?.changeVisibility(this.orgName, this.NEWREPONAME, 'PRIVATE'), `${this.msg.log_4}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            const newProjectName = `mls-${this.newProjectNumber}`;
            await this.tryItem(async () => await this.instanceDriver?.renameRepository(this.orgName, this.NEWREPONAME, newProjectName), `${this.msg.log_5}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.setPermissionAction(this.orgName, newProjectName), `${this.msg.log_14}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.setVariableAction(this.orgName, newProjectName, this.secret), `${this.msg.log_15}`);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialReadMe(this.newProjectNumber), this.msg.log_8);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialBuildFile(this.newProjectNumber), this.msg.log_10);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialPackageFile(this.newProjectNumber), this.msg.log_9);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.createInitialTSConfigFile(this.newProjectNumber), this.msg.log_11);
            newPercent += percent;
            this.setProgress(newPercent);
            await this.sleep(200);
            await this.tryItem(async () => await this.migrateLocalFiles(this.projectLocalNumber, this.newProjectNumber), this.msg.log_16);
            newPercent += percent;
            this.setProgress(newPercent);
            this.setProjectActual(this.newProjectNumber);
            this.setOrgActual(this.newProjectNumber);
            this.deleteLastOpenedFileOnLocalStorage();
            this.dispatchEvent(new CustomEvent('project-local-created', {
                bubbles: true,
                composed: true
            }));
        }
        catch (err) {
            this.toogleForm(false);
        }
        this.addLog({ pre: this.msg.log_ok, log: this.msg.log_7, status: "finish" });
        this.setProgressFinished(true);
    }
    setProjectActual(project) {
        mls.setActualProject(project);
        setProjectDetails(project);
    }
    setOrgActual(project) {
        if (!project)
            return;
        const orgIndex = mls.l5.getProjectOrgIndex(project);
        mls.l5.setActualOrg(orgIndex);
    }
    deleteLastOpenedFileOnLocalStorage() {
        deleteLastOpenedFiles(mls.stor.LOCALPROJECTNUMBER);
    }
    renderSelectProvider() {
        return html `
      <section class="container-select">
        <p class="banner">${this.msg.step1Msg}</p>

        <div class="providers">
          <label class="provider">
            <input
              type="radio"
              name="provider"
              .checked=${this.selectedProvider === 'github'}
              @change=${() => this.handleSelect('github')}
            />
            <span class="icon">
                ${githubIcon()}
            </span>
            <span>
              ${this.msg.github}
              ${this.githubConnected
            ? html `<span class="connected">(${this.msg.connected}) ✔️</span>`
            : html `<button type="button" class="connect-btn" @click=${() => this.handleConnect('github')}>${this.msg.connect}</button>`}
            </span>
          </label>

          <label class="provider">
            <input
              type="radio"
              name="provider"
              .checked=${this.selectedProvider === 'gitlab'}
              @change=${() => this.handleSelect('gitlab')}
            />
            <span class="icon">
              ${gitlabIcon()}
            </span>
            <span>
              ${this.msg.gitlab}
              ${this.gitlabConnected
            ? html `<span class="connected">(${this.msg.connected}) ✔️</span>`
            : html `<button type="button" class="connect-btn" @click=${() => this.handleConnect('gitlab')}>${this.msg.connect}</button>`}
            </span>
          </label>
        </div>

        <div class="actions">
          <button
            type="button"
            class="continue"
            ?disabled=${!this.selectedProvider || this.isLoadingOrgs}
            @click=${this.handleContinue}
          >
              ${this.isLoadingOrgs ? html `<span class="loader"></span>` : this.msg.btnContinue}
          </button>
        </div>

        ${this.errorMessage
            ? html `<p class="error-msg">${this.errorMessage}</p>`
            : null}
      </section>
    `;
    }
    renderCreateProject() {
        return html `
      <section class="container-create">
        <form>
        <div>
            <label>${this.msg.projectNameLabel}</label>
              <input 
              type="text" 
              .value=${this.newProjectName} 
              @input=${(e) => this.newProjectName = e.target.value} 
            />
            ${this.errorName
            ? html `<div class="error-msg">${this.errorName}</div>`
            : ''}
            
        </div>
        <div>
            <label>${this.msg.organizationLabel}</label>
            <div class="orgs-select">
                <select @change=${this.onOrgChanged}>
                    <option></option>
                    ${this.actualOrgs.map((org) => html `<option value="${org.id}">${org.name}</option>`)}
                </select>
                <button @click=${this.onRefreshOrgsClick}>${this.msg.btnRefreshOrg} ${collab_arrows_rotate}</button>
            </div>
            ${this.errorOrg
            ? html `<div class="error-msg">${this.errorOrg}</div>`
            : ''}
        </div>
        ${this.orgSelected ? html `
            <div>
                <label>${this.msg.teamLabel}</label>
                <select @change=${(e) => { this.newProjectTeam = e.target.value; }}>
                    ${this.actualTeams.map((team) => html `<option value="${team}">${team}</option>`)}
                </select>
            </div>
            <div>
                <label>${this.msg.visibilityLabel}</label>
                <select @change=${(e) => { this.newProjectVisibility = e.target.value; }}>
                    <option value="public">${this.msg.visibilityPublicOption}</option>
                    <option value="private">${this.msg.visibilityPrivateOption}</option>
                </select>
            </div>
        ` : ''}
        <div class="actions">
            <button
              type="button"
              class="cancel"
              @click=${this.onCancelStep2}
            >
            ${this.msg.btnCancel}
              
            </button>
            <button
              type="button"
              class="continue"
              @click=${this.onCreateProjectClick}
            >
            ${this.msg.btnContinue}
            </button>
          </div>
          </form>

          ${this.renderLogs()}


      </section>`;
    }
    renderLogs() {
        if (!this.logs || this.logs.length === 0)
            return html ``;
        return html `
        <div class="container-logs">
            <div class="progress">
                <div class="progress-line"></div>
            </div>
            ${this.logs.map((log) => html `<plugin-new-project-log-100554 status=${log.status} text=${log.pre}:${log.log}></plugin-new-project-log-100554>`)}
        </div>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.renderScenaries();
    }
    renderScenaries() {
        switch (this.activeScenerie) {
            case 'select':
                return this.renderSelectProvider();
            case 'form':
                return this.renderCreateProject();
            default:
                return html ``;
        }
    }
};
__decorate([
    state()
], PluginCreateProject.prototype, "selectedProvider", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "githubConnected", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "gitlabConnected", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "errorMessage", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "actualOrgs", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "actualTeams", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "orgSelected", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "isLoadingOrgs", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "activeScenerie", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "logs", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "errorName", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "errorOrg", void 0);
__decorate([
    query('.logs-container')
], PluginCreateProject.prototype, "logsContainer", void 0);
__decorate([
    query('.progress-line')
], PluginCreateProject.prototype, "progress", void 0);
__decorate([
    query('form')
], PluginCreateProject.prototype, "form", void 0);
PluginCreateProject = __decorate([
    customElement('plugin-create-project-local-to-driver-100554')
], PluginCreateProject);
export { PluginCreateProject };
