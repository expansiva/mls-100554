/// <mls fileReference="_100554_/l2/pluginCodelensFileReferences.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    noRefs: "Nenhuma referencia.",
    refFrom: "Referências do arquivo: ",
    prj: 'Projeto',
    shortname: 'Nome',
};
const message_en = {
    noRefs: "No references.",
    refFrom: "File References from",
    prj: 'Project',
    shortname: 'Shortname',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginCodelensFileReferences = class PluginCodelensFileReferences extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-codelens-file-references-100554 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-20);
}
`);
        this.msg = messages['en'];
        this.references = [];
        this.project = 0;
        this.shortName = '';
        this.position = 'left';
    }
    async firstUpdated() {
        this.references = [];
        if (!this.project || !this.shortName)
            return;
        this.getReferences(this.shortName, this.project);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<div>
            <span><b>${this.msg.refFrom}</b> _${this.project}_${this.shortName}</span>
            <br>
            ${this.references.length === 0 ? html `<span>${this.msg.noRefs}</span>` : ''}
            <ul>
                ${this.references.map((ref) => html `
                <li>
                    <a @click=${(e) => { this.handleClick(e, ref); }} href="#">
                        ${this.msg.prj}: ${ref.storFile.project} ${this.msg.shortname}: ${ref.storFile.shortName}  
                    </a> 
                </li>`)}
            </ul>
            

        </div>`;
    }
    handleClick(e, ref) {
        e.preventDefault();
        const cmdOpen = {
            action: 'open',
            level: 2,
            project: ref.storFile.project,
            shortName: ref.storFile.shortName,
            extension: ref.storFile.extension,
            folder: '',
            position: 'right'
        };
        mls.events.fire([2], ['FileAction'], JSON.stringify(cmdOpen), 0);
    }
    async getReferences(shortName, project) {
        const models = mls.editor.models[`_${project}_${shortName}`];
        if (!models || !models.ts || !models.ts.compilerResults)
            return [];
        return [];
    }
};
__decorate([
    property()
], PluginCodelensFileReferences.prototype, "references", void 0);
__decorate([
    property()
], PluginCodelensFileReferences.prototype, "project", void 0);
__decorate([
    property()
], PluginCodelensFileReferences.prototype, "shortName", void 0);
__decorate([
    property()
], PluginCodelensFileReferences.prototype, "position", void 0);
PluginCodelensFileReferences = __decorate([
    customElement('plugin-codelens-file-references-100554')
], PluginCodelensFileReferences);
export { PluginCodelensFileReferences };
