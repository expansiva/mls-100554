/// <mls fileReference="_100554_/l2/libProjectConfig.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
