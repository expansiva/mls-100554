// project/_102027_/l2/utils.ts
function convertFileNameToTag(info) {
  const { shortName, project, folder = "" } = info;
  const kebabName = shortName.replace(/([A-Z])/g, "-$1").toLowerCase();
  const baseName = `${kebabName}-${project}`;
  const folderPrefix = folder ? folder.replace(/([A-Z])/g, "-$1").toLowerCase().replace(/\//g, "--") + "--" : "";
  return `${folderPrefix}${baseName}`;
}
function setErrorOnModel(model, line, startColumn, endColumn, message, severity) {
  const lineIndent = getLineIndent(model, line);
  const markerOptions = {
    severity,
    message,
    startLineNumber: line,
    startColumn: startColumn + lineIndent,
    endLineNumber: line,
    endColumn: endColumn + lineIndent
  };
  monaco.editor.setModelMarkers(model, "markerSource", [markerOptions]);
}
function getLineIndent(model, lineNumber) {
  if (model) {
    var lineContent = model.getLineContent(lineNumber);
    var match = lineContent.match(/^\s*/);
    return match ? match[0].length : 0;
  }
  return 0;
}

// project/_102027_/l2/propiertiesLit.ts
function getPropierties(model) {
  let rc = [];
  rc = getPropiertiesByDecorators(model);
  rc = getMoreInfoInJsDoc(model, rc);
  return rc;
}
function getDefaultPropierties() {
  return [
    {
      propertyName: "class",
      propertyType: "string",
      sectionName: "principal",
      defaultValue: "",
      hint: "css classes"
    },
    {
      propertyName: "id",
      propertyType: "string",
      sectionName: "principal",
      defaultValue: "",
      pattern: "^[_a-zA-Z]\\w*$",
      hint: "identifier for javascript manipulation"
    }
  ];
}
function getPropiertiesByDecorators(model) {
  const decorators = model.compilerResults?.decorators;
  if (!decorators) return [];
  const rc = [];
  const objDecorators = JSON.parse(decorators);
  Object.entries(objDecorators).forEach((entrie) => {
    const item = entrie[1];
    if (item.type === "PropertyDeclaration") {
      const propertyName = item.parentName;
      item.decorators.forEach((decorator) => {
        if (decorator.text.startsWith("property(")) {
          const prop = {};
          const propertyType = getPropType(decorator.text)?.toLowerCase();
          prop["alias"] = getPropAttribute(decorator.text);
          prop.propertyName = propertyName;
          if (propertyType) prop.propertyType = propertyType;
          rc.push(prop);
        }
      });
    }
  });
  const defaultProps = getDefaultPropierties();
  return [...defaultProps, ...rc];
}
function getMoreInfoInJsDoc(model, propierties) {
  const devDoc = model.compilerResults?.devDoc;
  if (!devDoc) return propierties;
  const objDocs = JSON.parse(devDoc);
  const jsDocProps = getJSDocPropierties(objDocs);
  for (let i = 0; i < propierties.length; i++) {
    let prop = propierties[i];
    const propInPropsJsDoc = jsDocProps.find((_prop) => _prop.propertyName === prop.propertyName);
    prop.propertyName = prop["alias"] || prop.propertyName;
    delete prop["alias"];
    if (propInPropsJsDoc) {
      prop = {
        ...propInPropsJsDoc,
        ...prop
      };
      propierties[i] = prop;
    }
  }
  return propierties;
}
function getJSDocPropierties(objDocs) {
  const rc = [];
  for (const doc of objDocs) {
    if (doc.type !== "class") continue;
    const docMembersProp = doc.members.filter((m) => {
      const isProp = m.type === "property";
      let isLitProp = false;
      if (isProp) {
        const { modifiers } = m;
        isLitProp = isDecoratorProp(modifiers);
      }
      return isProp && isLitProp;
    });
    docMembersProp.forEach((prop) => {
      const propItem = {};
      const fieldType = getFieldTypeInfo(prop.tags);
      const sectionName = getSectionsTag(fieldType);
      const propType = getPropTypeTag(fieldType);
      propItem.hint = prop.comment;
      propItem.propertyName = prop.name;
      propItem.defaultValue = prop.initializerText || fieldType?.defaultValue || "";
      if (propType) propItem.propertyType = propType;
      if (sectionName) propItem.sectionName = sectionName;
      if (fieldType?.cols) propItem.cols = fieldType?.cols;
      if (fieldType?.rows) propItem.rows = fieldType?.rows;
      if (fieldType?.pattern) propItem.pattern = fieldType?.pattern;
      if (fieldType?.max) propItem.max = fieldType?.max;
      if (fieldType?.min) propItem.min = fieldType?.min;
      if (fieldType?.step) propItem.step = fieldType?.step;
      if (fieldType?.maxLength) propItem.maxLength = fieldType?.maxLength;
      if (propType === "list") {
        const itens = getItensByType(prop.initializerType);
        propItem.items = fieldType?.items || itens || [];
      }
      rc.push(propItem);
    });
  }
  return rc;
}
function getItensByType(initializerType) {
  if (!initializerType) return [];
  const regex = /"(.*?)"/g;
  const matches = initializerType.match(regex);
  if (matches) {
    const resultList = matches.map((match) => match.replace(/"/g, ""));
    return resultList;
  }
  return [];
}
function getPropType(propertyString) {
  const typeRegex = /type:\s*([A-Za-z]+)/;
  const match = propertyString.match(typeRegex);
  if (match && match.length > 1) {
    const typeProp = match[1];
    return typeProp;
  }
  return void 0;
}
function getPropAttribute(propertyString) {
  const typeRegex = /attribute:\s*['"]([^'"]+)['"]/;
  const match = propertyString.match(typeRegex);
  if (match && match.length > 1) {
    const attr = match[1];
    return attr;
  }
  return void 0;
}
function isDecoratorProp(modifiers) {
  if (!modifiers) return false;
  const searchStr = "@property(";
  for (const item of modifiers) {
    if (item.startsWith(searchStr)) return true;
  }
  return false;
}
function getFieldTypeInfo(tags) {
  const tag = tags.find((item) => item.tagName === "fieldType");
  if (!tag) return void 0;
  try {
    const rc = JSON.parse(tag.comment);
    return rc;
  } catch (err) {
    return void 0;
  }
}
function getSectionsTag(fieldType) {
  const defaultSection = "principal";
  if (!fieldType) return defaultSection;
  const { sectionName } = fieldType;
  if (!sectionName) return defaultSection;
  const valueFormated = sectionName.toLowerCase().trim();
  if (["principal", "optional", "advanced"].includes(valueFormated)) return valueFormated;
  return defaultSection;
}
function getPropTypeTag(fieldType) {
  const defaultType = "string";
  if (!fieldType) return defaultType;
  const { propertyType } = fieldType;
  if (!propertyType) return defaultType;
  const valueFormated = propertyType.toLowerCase().trim();
  if (["string", "number", "boolean", "list", "json"].includes(valueFormated)) return valueFormated;
  return defaultType;
}

// project/_102027_/l2/validateLit.ts
function validateTagName(modelTS) {
  if (!modelTS || !modelTS.storFile) return false;
  const { storFile, model } = modelTS;
  const { project, shortName, folder } = storFile;
  storFile.hasError = false;
  clearErrorsOnModel(model);
  if (!modelTS.compilerResults) return false;
  if (shortName === "enhancementLit" && project === 100554) return false;
  const decorators = JSON.parse(modelTS.compilerResults.decorators);
  if (!decorators) return false;
  const decoratorToCheck = "customElement";
  let rc = false;
  Object.entries(decorators).forEach((entrie) => {
    const decoratorInfo = entrie[1];
    if (!decoratorInfo || decoratorInfo.type !== "ClassDeclaration") return;
    decoratorInfo.decorators.forEach((_decorator) => {
      const decoratorInfo2 = getDecoratorClassInfo(_decorator.text);
      if (!decoratorInfo2 || decoratorInfo2.decoratorName !== decoratorToCheck) return;
      let correctTagName = convertFileNameToTag({ project, shortName, folder });
      if (correctTagName !== decoratorInfo2.tagName) {
        rc = true;
        setErrorOnModel(model, _decorator.line + 1, decoratorToCheck.length + 3, _decorator.text.length + 1, `Invalid web component tag name, the correct definition is: ${correctTagName}`, monaco.MarkerSeverity.Error);
        storFile.hasError = true;
      }
    });
  });
  return rc;
}
function validateRender(modelTS) {
  if (!modelTS || !modelTS.storFile) return false;
  const { storFile, model, compilerResults } = modelTS;
  const { project, shortName, folder } = storFile;
  storFile.hasError = false;
  clearErrorsOnModel(model);
  if (!compilerResults) return false;
  if (shortName.startsWith("enhancement")) return false;
  return verify(model, project, shortName, folder);
}
function getDecoratorClassInfo(decoratorString) {
  const regex = /(\w+)\(['"](.+?)['"]\)/;
  const match = decoratorString.match(regex);
  let result = void 0;
  if (match && match.length > 2) {
    const decoratorName = match[1];
    const tagName = match[2];
    result = {
      decoratorName,
      tagName
    };
  }
  return result;
}
function clearErrorsOnModel(model) {
  monaco.editor.setModelMarkers(model, "markerSource", []);
}
function verify(model, project, shortName, folder) {
  const lines = model.getLinesContent();
  const tag = convertFileNameToTag({ project, shortName, folder });
  const msgError = `Do not use the same component tag (${tag}) inside the rendering, possible looping`;
  let htmlCount = 0;
  let rc = false;
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];
    line = line.replace(/\/\/.*/, "");
    const lineInCommentBlock = isInCommentBlock(lines, i + 1);
    line = line.replace(/\s+/g, "");
    if (line.indexOf(`document.createElement('${tag}')`) >= 0 || line.indexOf(`document.createElement("${tag}")`) >= 0) {
      setErrorOnModel(model, i + 1, 0, line.length, msgError, monaco.MarkerSeverity.Warning);
      rc = true;
      break;
    }
    if (line.indexOf("html`") >= 0 && !lineInCommentBlock) htmlCount += 1;
    if (line.indexOf("`") >= 0 && line.indexOf("html`") === -1 && !lineInCommentBlock) htmlCount -= 1;
    if (htmlCount != 0) {
      if (line.indexOf("<" + tag) >= 0) {
        const column = model.getLineFirstNonWhitespaceColumn(i + 1);
        const length = model.getLineLength(i + 1);
        setErrorOnModel(model, i + 1, column, length, msgError, monaco.MarkerSeverity.Warning);
        rc = true;
        break;
      }
    }
  }
  return rc;
}
function isInCommentBlock(lines, lineNumber) {
  let countStartBlockComment = 0;
  let countEndBlockComment = 0;
  for (let i = 0; i <= lineNumber - 1; i++) {
    const line = lines[i];
    if (line.indexOf("/*") >= 0) countStartBlockComment += 1;
    if (line.indexOf("*/") >= 0 && i !== lineNumber - 1) countEndBlockComment += 1;
  }
  const isInBlockComment = countStartBlockComment > countEndBlockComment;
  return isInBlockComment;
}

// project/_102027_/l2/codeLensLit.ts
function setCodeLens(model1) {
  clearCodeLens(model1);
  const { model, compilerResults, storFile } = model1;
  if (!storFile || !model || !compilerResults) return;
  const { decorators } = compilerResults;
  if (storFile.shortName.startsWith("enhancement")) return;
  setCodeLensDecoratorClass(model, decorators);
  setCodeLensServiceDetails(model);
}
function clearCodeLens(model1) {
  for (let slineNr in model1.codeLens) {
    const codeLen = model1.codeLens[slineNr];
    if (codeLen[0].id === "helpAssistant") {
      mls.l2.codeLens.removeCodeLen(model1.model, Number.parseInt(slineNr));
    }
  }
}
function setCodeLensDecoratorClass(model, decorators) {
  const objDecorators = JSON.parse(decorators);
  Object.entries(objDecorators).forEach((entrie) => {
    const decoratorInfo = entrie[1];
    if (!decoratorInfo || decoratorInfo.type !== "ClassDeclaration") return;
    decoratorInfo.decorators.forEach((_decorator) => {
      if (_decorator.text.startsWith("customElement(")) {
        mls.l2.codeLens.addCodeLen(model, _decorator.line + 1, { id: "helpAssistant", title: `customElement`, jsComm: "", refs: "_100554_pluginCodelensCustomElement" });
      }
    });
  });
}
async function setCodeLensServiceDetails(model) {
  const lines = findLinesByText(model, "public details: IService");
  lines.forEach((line) => {
    mls.l2.codeLens.addCodeLen(model, line, { id: "helpAssistant", title: `serviceDetails`, jsComm: "", refs: "_100554_pluginCodelensServiceDetails" });
  });
}
function findLinesByText(model, textToFind) {
  const lines = [];
  if (!model) return lines;
  const lineCount = model.getLineCount();
  for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
    const lineText = model.getLineContent(lineNumber);
    if (lineText.includes(textToFind)) {
      lines.push(lineNumber);
    }
  }
  return lines;
}

// project/_102027_/l2/collabImport.ts
var moduleRegistry = /* @__PURE__ */ new Map();
var staticImports = /* @__PURE__ */ new Set();
var extensions = {
  ".defs.ts": ".defs.js",
  ".test.ts": ".test.js",
  ".ts": ".js"
};
async function collabImport(opts) {
  if (!opts.extension) opts.extension = ".ts";
  const moduleId = opts.folder ? `${opts.project}-${opts.folder}/${opts.shortName}` : `${opts.project}-/${opts.shortName}${extensions[opts.extension]}`;
  const { isDev, storFile } = await fileInDevelopment(opts);
  if (!isDev) {
    const url2 = getUrlFromFileInfo(opts, storFile ? storFile.versionRef : "", false);
    staticImports.add(moduleId);
    return import(
      /* @vite-ignore */
      url2
    );
  }
  const version = await getFileVersion(opts);
  const cached = moduleRegistry.get(moduleId);
  if (cached && cached.version === version && opts.shortName !== "designSystem") {
    return cached.modulePromise;
  }
  const url = getUrlFromFileInfo(opts, version, true);
  const modulePromise = import(
    /* @vite-ignore */
    url
  );
  moduleRegistry.set(moduleId, { version, modulePromise });
  return modulePromise;
}
async function fileInDevelopment(opts) {
  if (!opts.extension) opts.extension = ".ts";
  const keyToStorFile = mls.stor.getKeyToFiles(opts.project, 2, opts.shortName, opts.folder, opts.extension);
  const storFile = mls.stor.files[keyToStorFile];
  return { isDev: !!storFile?.inLocalStorage, storFile };
}
async function getFileVersion(opts) {
  if (!opts.extension) opts.extension = ".ts";
  const modelKey = mls.editor.getKeyModel(opts.project, opts.shortName, opts.folder, mls.actualLevel);
  const models = mls.editor.models[modelKey];
  if (!models) return "";
  const objExt = {
    ".defs.ts": "defs",
    ".test.ts": "test",
    ".ts": "ts"
  };
  const key = objExt[opts.extension];
  const modelByExt = models[key];
  if (!models || !modelByExt) return "";
  const crcActual = mls.common.crc.crc32(modelByExt.model.getValue()).toString(16);
  return crcActual === modelByExt.originalCRC ? "" : crcActual;
}
function getUrlFromFileInfo(opts, version, isDev) {
  if (!opts.extension) opts.extension = ".ts";
  if (opts.shortName === "designSystem" && opts.folder === "" && opts.extension === ".ts") {
    const base4 = opts.folder ? `/_${opts.project}_/l2/${opts.folder}/${opts.shortName}` : `/_${opts.project}_/l2/${opts.shortName}`;
    return `${base4}?t=${isDev ? Date.now() : version}`;
  }
  const base = opts.folder ? `/_${opts.project}_/l2/${opts.folder}/${opts.shortName}` : `/_${opts.project}_/l2/${opts.shortName}`;
  const base2 = version ? `${base}?t=${version}` : base;
  const base3 = opts.extension !== ".ts" ? `${base}${extensions[opts.extension]}` : base2;
  return base3;
}

// project/_102027_/l2/designSystemBase.ts
async function getTokens(project) {
  const fileName = `./_${project}_designSystem`;
  const instance = await collabImport({ folder: "", project, shortName: "designSystem" });
  if (!instance) throw new Error(`Invalid ds file: ${fileName}`);
  return instance.tokens || [];
}
async function getTokensLess(project, theme) {
  const tokens = await getTokens(project);
  const tokenByTheme = tokens.find((item) => item.themeName === theme);
  if (!tokenByTheme) throw new Error(`no find theme: ${theme}`);
  let tokensLess = "";
  tokensLess += Object.keys(tokenByTheme.color).map((key) => {
    let token = "";
    if (!key.startsWith("_dark-")) token = `@${key}: ${tokenByTheme.color[key]};`;
    return token;
  }).filter((item) => !!item).join("\n");
  tokensLess += "\n" + Object.keys(tokenByTheme.typography).map((key) => `@${key}: ${tokenByTheme.typography[key]};`).join("\n");
  tokensLess += "\n" + Object.keys(tokenByTheme.global).map((key) => `@${key}: ${tokenByTheme.global[key]};`).join("\n");
  return Promise.resolve(tokensLess);
}
async function compileLess(str) {
  return new Promise((resolve, reject) => {
    if (!str || str.trim().length < 1) resolve("");
    mls.l2.less.compile(str).then(async (css) => {
      resolve(css);
    }).catch((err) => {
      reject(new Error("Error LESS: " + err));
    });
  });
}
async function preCompileLess(project, less, theme) {
  const tokens = await getTokens(project);
  const prefix = ":root";
  try {
    less = removeTokensFromSource(less);
    const tokenInfo = tokens.find((item) => item.themeName === theme);
    if (!tokenInfo) return "";
    const allTokens = { ...tokenInfo.color, ...tokenInfo.typography, ...tokenInfo.global };
    const darkAndLight = getDarkAndLight(allTokens);
    const newLess = convertLessTokensToCss(less, darkAndLight["root"]);
    const tokensLess = await getTokensLess(project, theme);
    const res = await compileLess(`${newLess}
${tokensLess}`);
    return res;
  } catch (err) {
    throw new Error(`Error on pre compile tokens Less: ${err.message}`);
  }
}
function getDarkAndLight(allTokens) {
  const themes = {};
  Object.entries(allTokens).forEach((entry) => {
    const [key, value] = entry;
    const [theme] = key.split("-");
    let themeName = "root";
    if (theme === "_dark") themeName = "dark";
    if (!themes[themeName]) themes[themeName] = {};
    themes[themeName][key] = value;
  });
  return themes;
}
function convertLessTokensToCss(less, tokens) {
  const lessTokens = new Set(Object.keys(tokens));
  return less.replace(/@([a-zA-Z0-9-_]+)/g, (match, token, offset, fullText) => {
    if (!lessTokens.has(token)) {
      return match;
    }
    const beforeText = fullText.slice(0, offset);
    const insideMediaQuery = /@media\s*\([^{}]*$/.test(beforeText);
    const lessFunctions = [
      "lighten",
      "darken",
      "saturate",
      "desaturate",
      "fadein",
      "fadeout",
      "fade",
      "spin",
      "mix",
      "tint",
      "shade",
      "contrast",
      "ceil",
      "floor",
      "round",
      "abs",
      "sqrt",
      "pow",
      "mod",
      "min",
      "max",
      "escape",
      "e",
      "unit",
      "convert",
      "extract",
      "length"
    ];
    const insideLessFunction = new RegExp(`(${lessFunctions.join("|")})\\s*\\([^()]*$`, "i").test(beforeText);
    if (insideMediaQuery || insideLessFunction) {
      return match;
    }
    return `var(--${token})`;
  });
}
function removeTokensFromSource(src) {
  const regex = /\/\/Start Less Tokens[\s\S]*?\/\/End Less Tokens/g;
  return src.replace(regex, "");
}

// project/_102027_/l2/libCompileStyle.ts
async function compileStyleUsingMFile(modelStyle, theme = "Default") {
  const model = modelStyle.model;
  const { project, shortName, folder } = modelStyle.storFile;
  const keyToStorFileLess = mls.stor.getKeyToFiles(project, 2, shortName, folder, ".less");
  const storFileLess = mls.stor.files[keyToStorFileLess];
  if (!model || !storFileLess) return;
  let val = model.getValue();
  val = removeTokensFromSource2(val);
  val = removeCommentLines(val);
  try {
    return preCompileLess2(project, val, theme, modelStyle);
  } catch (err) {
    throw new Error(err.message);
  }
}
async function preCompileLess2(project, less, theme, modelStyle) {
  try {
    let newLess = await preCompileLess(project, less, theme);
    return newLess;
  } catch (e) {
    console.info(e);
    if (typeof e === "string") errorCompileLess(e);
    else if (e && e.message) errorCompileLess(e.message);
    else errorCompileLess(`Error: invalid less`);
    if (modelStyle && modelStyle.storFile) {
      modelStyle.storFile.hasError = true;
    }
    return "";
  }
}
function errorCompileLess(err) {
  const model = mls.editor.instances[mls.editor.activeInstance].getModel();
  if (!model || model.getLanguageId() !== "less") return;
  monaco.editor.setModelMarkers(model, "markerSource", []);
  const markers = [];
  const markerOptions = {
    severity: monaco.MarkerSeverity.Error,
    message: err,
    startLineNumber: 0,
    startColumn: 0,
    endLineNumber: 0,
    endColumn: 50
  };
  markers.push(markerOptions);
  monaco.editor.setModelMarkers(model, "markerSource", markers);
}
function removeTokensFromSource2(src) {
  const regex = /\/\/Start Less Tokens[\s\S]*?\/\/End Less Tokens/g;
  return src.replace(regex, "");
}
function removeCommentLines(text) {
  const lines = text.split("\n");
  const lineCount = lines.length - 1;
  const newLines = [];
  for (let lineNumber = 1; lineNumber <= lineCount; lineNumber++) {
    const lineContent = lines[lineNumber];
    if (!isCommentLine(lineContent)) {
      newLines.push(lineContent);
    }
  }
  const newContent = newLines.join("\n");
  return newContent;
}
function isCommentLine(line) {
  if (!line) return false;
  if (line.trim().startsWith("//")) {
    return true;
  }
  return line.trim().startsWith("/*") && line.trim().endsWith("*/");
}

// project/_102027_/l2/processCssLit.ts
async function injectStyle(modelTS, theme, enhancementName) {
  injectStyleWithoutShadowRoot(modelTS, theme, enhancementName);
}
async function injectStyleWithoutShadowRoot(modelTS, theme, enhancementName) {
  if (!modelTS) return;
  const modelStyle = mls.editor.getModels(modelTS.storFile.project, modelTS.storFile.shortName, modelTS.storFile.folder)?.style;
  if (!modelStyle) return;
  const css = await compileStyleUsingMFile(modelStyle, theme);
  if (!css) return;
  if (modelTS && modelTS.compilerResults) {
    const newJs = addLineInConstructor(modelTS.compilerResults.prodJS, `if(this.loadStyle) this.loadStyle(\`${css}\`);`, enhancementName);
    if (!newJs || newJs.indexOf("/// <mls") < 0) return;
    modelTS.compilerResults.prodJS = newJs;
    mls.stor.cache.clearObsoleteCache();
    modelTS.compilerResults.cacheVersion = generateCompactTimestamp();
    await delay(200);
    let { project, shortName, folder, extension } = modelTS.storFile;
    const version = modelTS.compilerResults.cacheVersion;
    extension = extension.replace(".ts", ".js");
    await mls.stor.cache.addIfNeed({ project, folder, shortName, version, content: newJs, extension });
  }
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function addLineInConstructor(code, lineToAdd, enhancementName) {
  const lines = code.split("\n");
  const lineEnhacement = lines.find((l) => l.trim().startsWith("/// <mls"));
  const hasEnhancementLit = (lineEnhacement || "").includes(enhancementName);
  if (!hasEnhancementLit) return code;
  let insideClass = false;
  let constructorIndex = -1;
  let superIndex = -1;
  let lineAlreadyExists = false;
  if (!code) return code;
  for (let i = 0; i < lines.length; i++) {
    const trimmedLine = lines[i].trim();
    if (trimmedLine.includes("class ") && trimmedLine.includes(" extends ")) {
      insideClass = true;
    }
    if (insideClass && trimmedLine.startsWith("constructor(")) {
      constructorIndex = i;
      for (let j = constructorIndex + 1; j < lines.length; j++) {
        if (lines[j].trim().startsWith("super(")) {
          superIndex = j;
          if (lines[j + 1] && lines[j + 1].trim() === lineToAdd.trim()) {
            lineAlreadyExists = true;
          }
          break;
        }
      }
      break;
    }
  }
  if (constructorIndex !== -1) {
    if (!lineAlreadyExists) {
      lines.splice(superIndex + 1, 0, `        ${lineToAdd}`);
    }
  } else {
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].trim().includes("class ") && lines[i].includes(" extends ")) {
        lines.splice(i + 1, 0, `    constructor() {`, `        super();`, `        ${lineToAdd}`, `    }`);
        break;
      }
    }
  }
  return lines.join("\n");
}
function generateCompactTimestamp() {
  const now = /* @__PURE__ */ new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");
  const milliseconds = String(now.getMilliseconds()).padStart(3, "0");
  return `${year}${month}${day}${hours}${minutes}${seconds}${milliseconds}`;
}

// project/_100554_/l2/enhancementLit.ts
var requires = [
  {
    type: "tspath",
    name: "lit",
    ref: "file://server/_102027_/l2/litElement.ts"
  },
  {
    type: "tspath",
    name: "lit/decorators.js",
    ref: "file://server/_102027_/l2/decorators.ts"
  },
  {
    type: "cdn",
    name: "lit",
    ref: "https://cdn.jsdelivr.net/gh/lit/dist@3/all/lit-all.min.js"
  },
  {
    type: "cdn",
    name: "lit/decorators.js",
    ref: "https://cdn.jsdelivr.net/npm/lit@3.0.0/decorators/+esm"
  }
];
var getDefaultHtmlExamplePreview = (modelTS) => {
  const { project, shortName, folder } = modelTS.storFile;
  const tag = convertFileNameToTag({ project, shortName, folder });
  return `<${tag}></${tag}>`;
};
var getDesignDetails = async (modelTS) => {
  return new Promise((resolve, reject) => {
    try {
      const ret = {
        defaultGroupName: "",
        defaultHtmlExamplePreview: getDefaultHtmlExamplePreview(modelTS),
        properties: getPropierties(modelTS),
        webComponentDependencies: []
      };
      resolve(ret);
    } catch (e) {
      reject(e);
    }
  });
};
var onAfterChange = async (modelTS) => {
  try {
    setCodeLens(modelTS);
    if (validateTagName(modelTS)) {
      mls.events.fireFileAction("statusOrErrorChanged", modelTS.storFile, "left");
      mls.events.fireFileAction("statusOrErrorChanged", modelTS.storFile, "right");
      return;
    }
    if (validateRender(modelTS)) {
      mls.events.fireFileAction("statusOrErrorChanged", modelTS.storFile, "left");
      mls.events.fireFileAction("statusOrErrorChanged", modelTS.storFile, "right");
      return;
    }
  } catch (e) {
    return e.message || e;
  }
};
var onAfterCompile = async (modelTS) => {
  await injectStyle(modelTS, "Default", "_100554_enhancementLit");
  return;
};

// project/_100554_/l2/enhancementLitService.ts
var requires2 = requires;
var getDefaultHtmlExamplePreview2 = (modelTS) => {
  return getDefaultHtmlExamplePreview(modelTS);
};
var getDesignDetails2 = (modelTS) => {
  return getDesignDetails(modelTS);
};
var onAfterChange2 = async (modelTS) => {
  return onAfterChange(modelTS);
};
var onAfterCompile2 = async (modelTS) => {
  return onAfterCompile(modelTS);
};
export {
  getDefaultHtmlExamplePreview2 as getDefaultHtmlExamplePreview,
  getDesignDetails2 as getDesignDetails,
  onAfterChange2 as onAfterChange,
  onAfterCompile2 as onAfterCompile,
  requires2 as requires
};
