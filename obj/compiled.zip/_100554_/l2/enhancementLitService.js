/// <mls fileReference="_100554_/l2/enhancementLitService.ts" enhancement="_blank" />
import { getDesignDetails as getDesignDetailsDefault, getDefaultHtmlExamplePreview as getDefaultHtmlExamplePreviewDefault, onAfterChange as onAfterChangeDefault, requires as requiresDefault, } from '/_100554_/l2/enhancementLit.js';
import { injectStyle, injectStyleAction } from '/_102027_/l2/processCssLit.js';
export const requires = requiresDefault;
export const getDefaultHtmlExamplePreview = (modelTS) => {
    return getDefaultHtmlExamplePreviewDefault(modelTS);
};
export const getDesignDetails = (modelTS) => {
    return getDesignDetailsDefault(modelTS);
};
export const onAfterChange = async (modelTS) => {
    return onAfterChangeDefault(modelTS);
};
export const onAfterCompile = async (modelTS) => {
    await injectStyle(modelTS, 'Default', '_100554_enhancementLitService');
    return;
};
export const onAfterCompileAction = async (sourceJS, sourceTS, css) => {
    return await injectStyleAction(sourceJS, sourceTS, css?.sourceLess || '', css?.sourceTokens || '', 'Default', '_100554_enhancementLitService');
};
