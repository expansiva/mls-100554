/// <mls fileReference="_100554_/l2/enhancementLitService.ts" enhancement="_blank" />
import { getDesignDetails as getDesignDetailsDefault, getDefaultHtmlExamplePreview as getDefaultHtmlExamplePreviewDefault, onAfterChange as onAfterChangeDefault, onAfterCompile as onAfterCompileDefault, requires as requiresDefault, } from '/_100554_/l2/enhancementLit.js';
export const requires = requiresDefault;
export const getDefaultHtmlExamplePreview = (modelTS) => {
    return getDefaultHtmlExamplePreviewDefault(modelTS);
};
export const getDesignDetails = (modelTS) => {
    return getDesignDetailsDefault(modelTS);
};
export const onAfterChange = async (modelTS) => {
    return onAfterChangeDefault(modelTS);
};
export const onAfterCompile = async (modelTS) => {
    return onAfterCompileDefault(modelTS);
};
