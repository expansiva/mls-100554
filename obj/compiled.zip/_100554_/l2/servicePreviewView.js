/// <mls fileReference="_100554_/l2/servicePreviewView.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property } from 'lit/decorators.js';
import { getTokensCss } from '/_102027_/l2/designSystemBase.js';
import { convertFileNameToTag, getPath } from '/_102027_/l2/utils.js';
import { createModel } from '/_102027_/l2/libModel.js';
import { getDependenciesByHtmlFile } from '/_102027_/l2/libCompile.js';
import { compileStyleUsingStorFile } from '/_102027_/l2/libCompileStyle.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { PreviewModeSinglePage } from '/_100554_/l2/previewModeSinglePage.js';
import { PreviewModeMinimum } from '/_100554_/l2/previewModeMinimum.js';
/// **collab_i18n_start**
const message_pt = {
    pageNotDefined: 'Página não definida',
    notFoundStorfile: 'Arquivo não encontrado',
    errorCompile: 'Erro ao compilar',
    configure: 'Configure seu HTML pela opção do editor!',
    width: 'Largura',
    height: 'Altura',
    msgSecurity: `<div>
  <h2>🛡️ Modo de Segurança</h2>
  <p>Atualmente, você está em <strong>modo de segurança</strong>. Isso significa que o seu código não foi carregado por precaução.</p>
  <p>Assim que você fizer sua primeira edição, o sistema sairá automaticamente desse modo e o código será carregado normalmente.</p>
</div>`
};
const message_en = {
    pageNotDefined: 'Page not defined',
    notFoundStorfile: 'Not found storfile',
    errorCompile: 'Error on compiling',
    configure: 'Configure your html by editor option!',
    width: 'Width',
    height: 'Height',
    msgSecurity: `<div>
<h2>🛡️ Safe Mode</h2>
<p>You are currently in <strong>safe mode</strong>. This means that your code has not been loaded as a precaution.</p>
<p>As soon as you make your first edit, the system will automatically exit this mode and the code will load normally.</p>
</div>`
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePreviewView = class ServicePreviewView extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-preview-view-100554 .error {
  padding: 1rem;
  color: var(--error-color);
  font-size: var(--font-size-20);
}
service-preview-view-100554 .error .error-list {
  color: var(--text-primary-color);
  font-size: var(--font-size-16);
}
service-preview-view-100554.mobile {
  width: 100%;
  height: 100vh;
  min-height: 700px;
  display: flex !important;
  flex-direction: column;
  align-items: center;
  padding-top: 0.5rem;
}
service-preview-view-100554.mobile .watchDesktop {
  position: absolute;
  background: white;
  box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 2px 2px;
  top: 3px;
  right: 46px;
  border-radius: 50%;
  width: 30px;
  height: 30px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
}
service-preview-view-100554.mobile .groupSetMobile {
  display: flex;
  width: 300px;
  gap: 0.8rem;
  justify-content: center;
  align-items: center;
  margin-bottom: 1rem;
}
service-preview-view-100554.mobile .groupSetMobile div {
  display: flex;
  flex-direction: column;
}
service-preview-view-100554.mobile .groupSetMobile label {
  font-size: 0.8rem;
  font-weight: bold;
}
service-preview-view-100554.mobile .groupSetMobile input {
  border: 1px solid #cac7c7;
  outline: none;
  width: 100px;
  height: 20px;
  border-radius: 5px;
}
service-preview-view-100554.mobile .phone {
  z-index: 1;
  padding: 0 0.5rem;
  border: 0.25rem solid #404040;
  border-radius: 1rem;
  display: flex;
  flex-direction: column;
  box-shadow: 0px 5px 3px 3px rgba(0, 0, 0, 0.3);
  background: white;
}
service-preview-view-100554.mobile .phone_mic {
  height: 0.25rem;
  width: 4rem;
  margin: 1rem auto;
  border-radius: 999rem;
  background-color: #505050;
}
service-preview-view-100554.mobile .phone_screen {
  position: relative;
  flex: 1 0 auto;
  border: 1px solid #505050;
  border-radius: 5px;
}
service-preview-view-100554.mobile .phone_screen iframe {
  border-radius: 5px;
}
service-preview-view-100554.mobile .phone_button {
  width: 1.5rem;
  height: 1.5rem;
  border: 2px solid #505050;
  border-radius: 50%;
  margin: 1rem auto;
}
service-preview-view-100554.mobile .scroll-custom::-webkit-scrollbar {
  width: 5px;
}
service-preview-view-100554.mobile .scroll-custom::-webkit-scrollbar-track {
  background: #ddd;
}
service-preview-view-100554.mobile .scroll-custom::-webkit-scrollbar-thumb {
  background: #666;
}
service-preview-view-100554.mobile .scroll-custom::scrollbar {
  width: 2px;
}
service-preview-view-100554.mobile .scroll-custom::scrollbar-track {
  background: #ddd;
}
service-preview-view-100554.mobile .scroll-custom::scrollbar-thumb {
  background: #666;
}
service-preview-view-100554.desktop {
  display: block;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
`);
        this.msg = messages['en'];
        this.file = undefined;
        this.models = undefined;
        this.page = '';
        this.mode = 'desktop';
        this.lang = 'en';
        this.level = '';
        this.isDsComponent = false;
        this.watch = true;
        this.stylechanged = '';
        this.actualtheme = 'Default';
        this.error = '';
        this.lastCompiledUrl = '';
        this.widthP = '300';
        this.heightP = '600';
        this.injected = false;
        this.pending = {};
        this.lastHTML = '';
        this.isService = false;
        this.timeShow = -1;
    }
    setEventsCollab() {
        mls.events.addListener(2, 'WidgetAction', this.onWidgetActionEvents.bind(this));
    }
    connectedCallback() {
        super.connectedCallback();
        this.setEventsCollab();
    }
    attributeChangedCallback(name, oldVal, newVal) {
        if (name === 'stylechanged') {
            if (newVal === 'true')
                this.addStyles();
            return;
        }
        super.attributeChangedCallback(name, oldVal, newVal);
    }
    render() {
        const lang = this.father && this.father.getMessageKey ? this.father.getMessageKey(messages) : 'en-us';
        this.msg = messages[lang];
        if (this.error !== '')
            return this.renderError();
        else
            return this.renderPreview();
    }
    renderError() {
        return html `<div class="error">${unsafeHTML(this.error)}</div>`;
    }
    renderPreview() {
        this.watch = this.father.watch;
        if (this.mode === 'mobile') {
            this.classList.remove('desktop');
            this.classList.add('mobile');
            return html ` 
                
                <div class="groupSetMobile">
                    <div>
                        <label>${this.msg.width}:</label>
                        <input type="number" value="300" @input="${this.changeWidthP}">
                    </div>
                    <div>
                        <label>${this.msg.height}:</label>
                        <input type="number" value="700" @input="${this.changeHeightP}">
                    </div>
                    </div> 
                <div class="phone" style="width:${this.widthP}px; height:${this.heightP}px">
                    <div class="phone_mic"></div>
                    <div class="phone_screen">
                        <iframe style="width:100%; height:100%; border:none; display:none"  src="/_100554_servicePreview" @load="${this.load}" ></iframe>
                    </div>
                    <div class="phone_button"></div>
                </div>
                
            `;
        }
        else {
            this.classList.add('desktop');
            this.classList.remove('mobile');
            return html `
            <iframe
                style="width:100%; height:100%; border:none; display:none" src="/_100554_servicePreview"
                @load="${this.load}" >
            
            </iframe>`;
        }
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('level')) {
            const oldLevel = changedProperties.get('level');
            if (!oldLevel)
                return;
            this.fireChangeICA();
        }
    }
    //-------- IMPLEMENTS---------
    onWidgetActionEvents(ev) {
        if (ev.level.toString() !== this.level)
            return;
        if (!ev.desc)
            return;
        const json = JSON.parse(ev.desc);
        if (json.op !== 'SelectWidget')
            return;
        this.selectIdinPreview(json.id, json.origin);
    }
    selectIdinPreview(id, origin) {
        if (!id)
            return;
        const iframe = this.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        if (origin !== 'editor')
            return;
        const el = this.findElementsStartingWithIca(id);
        if (!el)
            return;
        const ev = new CustomEvent('click', {
            detail: {
                origin,
            }
        });
        const ov = el.overlayRef;
        if (!ov)
            return;
        ov.dispatchEvent(ev);
    }
    findElementsStartingWithIca(id) {
        if (!id)
            return undefined;
        const iframe = this.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return undefined;
        const doc = iframe.contentDocument;
        let elements = [];
        function traverseShadowRoot(element) {
            if (element.tagName.toLowerCase().startsWith('ica')) {
                elements.push(element);
                return;
            }
            if (element.shadowRoot) {
                element.shadowRoot.querySelectorAll('*').forEach((item) => {
                    traverseShadowRoot(item);
                });
            }
            else {
                const children = Array.from(element.children);
                if (children.length > 0) {
                    children.forEach(child => traverseShadowRoot(child));
                }
            }
        }
        doc.body.querySelectorAll('*').forEach((item) => {
            traverseShadowRoot(item);
        });
        const newId = `ica_${id}`;
        const ret = elements.find((el) => el.id === newId);
        return ret;
    }
    fireChangeICA() {
        const iframe = this.querySelector('iframe');
        if (!iframe || !iframe.contentDocument)
            return;
        this.changeLevelIca(iframe.contentDocument.body);
    }
    changeLevelIca(el) {
        const isPage = el.isPage;
        let tagEl = el.tagName.toLowerCase();
        if (tagEl.startsWith('ica-') || isPage) {
            el.setAttribute('level', this.level);
        }
        for (const i of el.children) {
            this.changeLevelIca(i);
        }
    }
    async addStyles() {
        if (!this.file || !window.preview.iframe || !window.preview.iframe.contentDocument || !window.preview.iframe.contentWindow || !window.preview.iframe.contentDocument.head)
            return;
        const { project, shortName, folder } = this.file;
        const id = convertFileNameToTag({ project, shortName, folder });
        const oldStyle = window.preview.iframe.contentDocument.head.querySelector(`style[id=${id}]`);
        const newStyle = document.createElement('style');
        const newLess = await compileStyleUsingStorFile(shortName, project, folder, this.actualtheme);
        if (newLess) {
            newStyle.id = id;
            newStyle.textContent = newLess;
            if (window.preview.iframe.contentDocument !== null)
                window.preview.iframe.contentDocument.head.appendChild(newStyle);
            if (oldStyle)
                oldStyle.remove();
        }
        const tokens = await getTokensCss(project, this.actualtheme);
        this.mountTokens(tokens || '');
        this.stylechanged = 'false';
    }
    async load() {
        if (this.injected)
            return;
        this.injected = true;
        this.showLoader(true);
        const iframe = this.querySelector('iframe');
        const head = iframe.contentDocument?.querySelector('head');
        if (head) {
            const base = document.createElement('base');
            base.href = document.baseURI;
            head.appendChild(base);
        }
        await this.init(iframe);
        window.preview.iframe = iframe;
        const collabConsole = this.parentElement?.querySelector('collab-console-100554');
        collabConsole.scope = iframe.contentWindow;
    }
    async init(iframe) {
        try {
            this.father.setError('');
            this.setDevice(iframe);
            this.setTheme(iframe);
            //this.setMessage(iframe);
            await this.setMyFile();
            if (this.models &&
                (this.models.ts?.storFile.hasError ||
                    this.models.style?.storFile.hasError ||
                    this.models.html?.storFile.hasError)) {
                const trace = this.models?.ts?.compilerResults?.errors.map((err) => err.messageText).join('\n - ');
                const traceStyle = this.models?.style?.styleResults?.errors.map((err) => err.messageText).join('\n - ');
                this.error = this.msg.errorCompile + '\n' + `<div class="error-list"> ${trace ? `<b>TYPESCRIPT</b> <br> - ${trace}` : ''} <br><br> ${traceStyle ? `<b>LESS</b> <br> - ${traceStyle}` : ''} </div>`;
                this.showLoader(false);
                this.renderError();
                return;
            }
            if (!this.file) {
                this.error = this.msg.errorCompile + '\n' + `<div class="error-list"> - Not Found storFile </div>`;
                this.showLoader(false);
                this.renderError();
                return;
            }
            if (window.securityMode) {
                iframe.contentDocument.body.innerHTML = this.msg.msgSecurity;
                iframe.style.display = '';
                window.securityMode = false;
                this.showLoader(false);
                return;
            }
            await this.setHtml(iframe);
            iframe.style.display = '';
            const html = iframe.contentDocument?.querySelector('html');
            if (html) {
                html.lang = this.lang;
                html.style.overflow = 'hidden';
                html.style.height = '100%';
            }
            if (iframe.contentDocument) {
                iframe.contentDocument.body.style.overflowY = 'auto';
                iframe.contentDocument.body.style.overflowX = 'hidden';
                iframe.contentDocument.body.style.margin = '0';
                iframe.contentDocument.body.style.height = '100%';
                iframe.contentDocument.body.style.width = '100%';
                iframe.contentDocument.body.style.background = 'var(--bg-primary-color)';
                iframe.contentDocument.body.style.color = 'var(--text-primary-color)';
            }
            this.showLoader(false);
            this.dispatchEvent(new CustomEvent('preview-loaded', {
                detail: { shortName: this.file.shortName, project: this.file.project },
                bubbles: true,
                composed: true,
            }));
        }
        catch (e) {
            this.error = e.message;
            this.showLoader(false);
        }
    }
    setMessage(iframe) {
        if (!iframe.contentWindow)
            return;
        const originalFetch = iframe.contentWindow.fetch;
        iframe.contentWindow.fetch = (url, options) => {
            //  /exec /exec/ ateste/exec atest/exec/
            if (typeof url === "string" && url.indexOf("/exec") >= 0) {
                return new Promise((resolve, reject) => {
                    const id = crypto.randomUUID();
                    this.pending[id] = resolve;
                    const keys = Object.values(top.previewL1);
                    if (url.startsWith('/exec/') || url.startsWith('exec/')) {
                        keys[0].iframe.contentWindow?.postMessage({
                            type: "fetch-request",
                            id,
                            url,
                            options
                        }, "*");
                    }
                    else {
                        const server = url.split('/exec').filter(Boolean).shift() || '****';
                        if (!top.previewL1[server])
                            reject('Not found server');
                        top.previewL1[server].iframe.contentWindow?.postMessage({
                            type: "fetch-request",
                            id,
                            url,
                            options
                        }, "*");
                    }
                });
            }
            return originalFetch(url, options);
        };
        iframe.contentWindow.onmessage = (e) => {
            const data = e.data;
            if (data.type !== "fetch-response")
                return;
            const resolve = this.pending[data.id];
            if (!resolve)
                return;
            delete this.pending[data.id];
            resolve(new Response(data.body, {
                status: data.status,
                headers: data.headers
            }));
        };
    }
    setTheme(iframe) {
        const isLight = this.father.light;
        const html = iframe.contentDocument?.querySelector('html');
        const meta = iframe.contentDocument?.querySelector('meta[name="color-scheme"]');
        if (!isLight && html) {
            html.setAttribute('data-theme', 'dark');
            html.classList.add('dark');
        }
        if (meta)
            meta.remove();
        iframe.contentDocument?.body.classList.add(`theme-${this.actualtheme.toLowerCase()}`);
    }
    setDevice(iframe) {
        if (iframe.contentDocument)
            iframe.contentDocument.documentElement.setAttribute('data-device', this.mode);
    }
    async setMyFile() {
        if (!this.page || this.page === '')
            throw new Error(this.msg.pageNotDefined);
        const info = getPath(this.page);
        if (!info)
            throw new Error('[setMyFile] Not found path:' + this.page);
        const key = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, '.html');
        const file = mls.stor.files[key];
        const mkey = mls.editor.getKeyModel(info.project, info.shortName, file.folder, file.level);
        if (!mls.stor.files[key])
            throw new Error(this.msg.notFoundStorfile + ': ' + key);
        if (!mls.editor.models[mkey] && mls.actualLevel !== 7) {
            //await createAllModels(file);
            await this.createModel(file, '.less');
            await this.createModel(file, '.ts');
            await this.createModel(file, '.html');
        }
        if (!mls.editor.models[mkey] && mls.actualLevel !== 7)
            throw new Error(this.msg.notFoundStorfile + ': ' + mkey);
        this.file = mls.stor.files[key];
        this.models = mls.editor.models[mkey];
    }
    async createModel(base, ext) {
        if (ext === '.ts') {
            return await createModel(base, true, false);
        }
        const { project, shortName, folder, level } = base;
        const key = mls.stor.getKeyToFiles(project, base.level, shortName, folder, ext);
        let stor = mls.stor.files[key];
        if (stor) {
            await createModel(stor, true, false);
        }
        /*

        if (!stor) {

            const param: IReqCreateStorFile = {
                project,
                shortName,
                folder,
                level,
                extension: '.ts',
                source: '',
                status: 'new'
            }

            if (ext === '.less') {
                const templateLess = await getBaseTemplate({ folder, shortName, project, extension: '.less' }, 'enhancementStyle');
                return createStorFile({ ...param, extension: '.less', source: templateLess }, true, true, false)
            }

            if (ext === '.html') {
                const templateHTML = await getBaseTemplate({ folder, shortName, project, extension: '.html' });
                return createStorFile({ ...param, extension: '.html', source: templateHTML }, true, true, false)
            }


        } else {
            await createModel(stor, true, false);
        }*/
    }
    checkIfIsService() {
        if (!this.file || !this.models || !this.models.ts)
            return false;
        const txt = this.models.ts.model.getValue();
        if (txt.indexOf('extends ServiceBase') === -1)
            return false;
        return true;
    }
    async setHtml(iframe) {
        if (!iframe.contentDocument || !this.file)
            return;
        this.isService = this.checkIfIsService();
        const previewModuleName = await this.getPreviewConfigByProject(this.file.project);
        if (previewModuleName) {
            await this.modeByProjectConfig(iframe, previewModuleName);
        }
        else {
            await this.setHtml2(iframe);
        }
        mls.events.fire(mls.actualLevel, 'FineshPreview', JSON.stringify({}), 0);
    }
    async setHtml2(iframe) {
        if (!iframe.contentDocument || !this.file)
            return;
        let txt = await this.setHtmlByLevel();
        this.lastHTML = txt;
        iframe.contentDocument.body['service'] = this.father;
        let ret = await getDependenciesByHtmlFile(this.file, txt, this.actualtheme, true);
        const domVirtual = document.createElement('div');
        domVirtual.innerHTML = txt;
        const els = domVirtual.querySelectorAll('*');
        els.forEach((el) => el.setAttribute('mls_origin', 'true'));
        if (ret.errors.length > 0) {
            this.father.setError(`Error(${ret.errors.length}) when compiling:${ret.errors[0].error}`);
            console.log('Errors in compile:', JSON.stringify(ret.errors));
        }
        iframe.contentDocument.body.innerHTML = domVirtual.innerHTML;
        if (!mls.modePreview)
            mls.modePreview = 'singlePage';
        switch (mls.modePreview) {
            case 'minimum':
                await this.modeMinimum(ret, iframe);
                break;
            case 'singlePage':
                await this.modeSinglePage(ret, iframe);
                break;
            default:
                await this.modeMinimum(ret, iframe);
                break;
        }
        this.addGlobalCss(ret.globalCss);
    }
    async getPreviewConfigByProject(project) {
        if (!project)
            return;
        const url = `/_${project}_/l2/project.js`;
        try {
            const modulePrj = await import(url);
            if (!modulePrj || !modulePrj.projectConfig || !modulePrj.projectConfig.masterFrontEnd || !modulePrj.projectConfig.masterFrontEnd.preview)
                return;
            return modulePrj.projectConfig.masterFrontEnd.preview;
        }
        catch (err) {
            console.error('no find project config');
            return;
        }
    }
    async setHtmlByLevel() {
        let txt = await this.getFileContent();
        if (this.level === '3')
            txt = '<collab-preview-l3-100554>' + txt + '</collab-preview-l3-100554>';
        if (this.level === '4')
            txt = '<collab-preview-l4-100554>' + txt + '</collab-preview-l4-100554>';
        return txt;
    }
    async getFileContent() {
        let txt = '<h3>' + this.msg.configure + '</h3>';
        if (this.file)
            txt = await this.file.getContent();
        return txt;
    }
    async modeSinglePage(json, iframe) {
        if (!this.file)
            return;
        const c = new PreviewModeSinglePage(json, iframe, this.level, this.isService, this.file, this.models);
        await c.init();
    }
    async modeMinimum(json, iframe) {
        if (!this.file)
            return;
        const c = new PreviewModeMinimum(json, iframe, this.level, this.isService, this.file, this.models);
        await c.init();
    }
    async modeByProjectConfig(iframe, previewModuleName) {
        const module = await import(previewModuleName);
        const PreviewModule = module.default ?? Object.values(module)[0];
        if (!PreviewModule || !this.file)
            return;
        const c = new PreviewModule(iframe, this.level, this.isService, this.file);
        await c.init();
    }
    addGlobalCss(globalCss) {
        if (!globalCss)
            return;
        try {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentDocument)
                return;
            const oldStyle = iframe.contentDocument.querySelector('style#global_css');
            if (oldStyle)
                oldStyle.remove();
            const style = document.createElement('style');
            style.textContent = globalCss;
            style.id = 'global_css';
            style.type = "text/tailwindcss";
            iframe.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTokens: ' + e.message);
        }
    }
    mountTokens(tokens) {
        try {
            const iframe = window.preview.iframe;
            if (!iframe || !iframe.contentDocument)
                return;
            this.removeOlderTokens(iframe);
            const css = tokens || '';
            if (!css)
                return;
            const style = document.createElement('style');
            style.textContent = css;
            style.id = this.getIdTokens();
            iframe.contentDocument.head.appendChild(style);
        }
        catch (e) {
            console.info('Error mountTokens: ' + e.message);
        }
    }
    removeOlderTokens(ifr) {
        const id = this.getIdTokens();
        if (!ifr.contentDocument || !id)
            return;
        const st = ifr.contentDocument.head.querySelectorAll(`#${id}`);
        st.forEach((s) => s.remove());
    }
    getIdTokens() {
        if (!this.file)
            return 'ds_tokens';
        const { project } = this.file;
        return '_' + project + '_ds_tokens';
    }
    changeWidthP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 200)
            return;
        this.widthP = el.value;
    }
    changeHeightP(e) {
        const el = e.target;
        if (!el)
            return;
        if (el.value === '' || +el.value < 250)
            return;
        this.heightP = el.value;
    }
    showLoader(show) {
        if (this.timeShow)
            window.clearTimeout(this.timeShow);
        this.timeShow = window.setTimeout(() => {
            if (!this.father)
                return;
            if (show === false)
                this.father.updateLoadingToFalseIfNoTasksRunning();
            else
                this.father.loading = show;
        }, 200);
    }
    cleanTree() {
        let ret = '';
        const iframe = this.querySelector('iframe');
        if (!iframe)
            return '';
        const div = document.createElement('div');
        const divRet = document.createElement('div');
        const body = iframe.contentDocument?.body;
        if (!body)
            return ret;
        this.cleanTree2(div, body);
        this.cleanTree3(divRet, div);
        return divRet.innerHTML;
    }
    cleanTree2(father, element) {
        const tagname = element.tagName.toLowerCase();
        if (tagname.startsWith('ica-')) {
            let children = [...element.children];
            for (const child of children) {
                this.cleanTree2(father, child);
            }
        }
        else {
            const clone = element.cloneNode(false);
            father.appendChild(clone);
            let children = [];
            if (element.shadowRoot) {
                children = [...element.shadowRoot.children];
            }
            else {
                children = [...element.children];
            }
            for (const child of children) {
                this.cleanTree2(clone, child);
            }
        }
        return father;
    }
    cleanTree3(father, element) {
        let children = [...element.children];
        for (const child of children) {
            const tagname = child.tagName.toLowerCase();
            if (tagname.indexOf('-') > 0) {
                const clone = child.cloneNode(false);
                father.appendChild(clone);
                this.cleanTree3(clone, child);
            }
            else {
                this.cleanTree3(father, child);
            }
        }
    }
    fireTesting() {
        if (!this.file)
            return;
        let info = this.getTesting();
        const s = this.file.shortName;
        info.push(s);
        info = [...new Set(info)];
        this.setTesting(info);
        setTimeout(() => {
            info = this.getTesting();
            info = this.removerTesting(info, s);
            this.setTesting(info);
        }, 20000);
    }
    getTesting() {
        const sT = localStorage.getItem('iframeTesting') || '[]';
        let info = JSON.parse(sT);
        return info;
    }
    setTesting(info) {
        info = [...new Set(info)];
        localStorage.setItem('iframeTesting', JSON.stringify(info));
    }
    removerTesting(array, item) {
        return array.filter(str => str !== item);
    }
};
__decorate([
    property()
], ServicePreviewView.prototype, "father", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "page", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "mode", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "lang", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "level", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "isDsComponent", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "watch", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "stylechanged", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "actualtheme", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "error", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "lastCompiledUrl", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "widthP", void 0);
__decorate([
    property()
], ServicePreviewView.prototype, "heightP", void 0);
ServicePreviewView = __decorate([
    customElement('service-preview-view-100554')
], ServicePreviewView);
export { ServicePreviewView };
