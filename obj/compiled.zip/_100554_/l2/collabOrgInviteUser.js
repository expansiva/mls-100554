/// <mls fileReference="_100554_/l2/collabOrgInviteUser.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    fieldUsername: 'Usuário ou E-mail',
    fieldTeam: 'Time inicial',
    fieldTeamPlaceholder: 'Selecione um time',
    fieldCompText: 'Texto complementar',
    btnSubmit: 'Enviar convite',
    btnSubmitting: 'Enviando…',
    feedbackSuccess: 'Convite enviado com sucesso.',
    feedbackError: 'Erro ao enviar o convite.',
};
const message_en = {
    fieldUsername: 'Username or Email',
    fieldTeam: 'Initial Team',
    fieldTeamPlaceholder: 'Select a team',
    fieldCompText: 'Complementary Text',
    btnSubmit: 'Send invite',
    btnSubmitting: 'Sending…',
    feedbackSuccess: 'Invite sent successfully.',
    feedbackError: 'Failed to send invite.',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
let CollabOrgInviteUser = class CollabOrgInviteUser extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-org-invite-user-100554 {
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
}
collab-org-invite-user-100554 .invite-form {
  display: flex;
  flex-direction: column;
  gap: 16px;
}
collab-org-invite-user-100554 .form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
collab-org-invite-user-100554 .form-group label {
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
}
collab-org-invite-user-100554 .form-group input,
collab-org-invite-user-100554 .form-group select,
collab-org-invite-user-100554 .form-group textarea {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
  border: 1px solid var(--grey-color-dark);
  border-radius: 4px;
  padding: 8px 12px;
  box-sizing: border-box;
  width: 100%;
}
collab-org-invite-user-100554 .form-group input:hover,
collab-org-invite-user-100554 .form-group select:hover,
collab-org-invite-user-100554 .form-group textarea:hover {
  border-color: var(--grey-color-darker);
}
collab-org-invite-user-100554 .form-group input:focus,
collab-org-invite-user-100554 .form-group select:focus,
collab-org-invite-user-100554 .form-group textarea:focus {
  outline: none;
  border-color: var(--active-color);
}
collab-org-invite-user-100554 .form-group input:disabled,
collab-org-invite-user-100554 .form-group select:disabled,
collab-org-invite-user-100554 .form-group textarea:disabled {
  background-color: var(--bg-primary-color-disabled);
  color: var(--text-primary-color-disabled);
  cursor: not-allowed;
}
collab-org-invite-user-100554 .form-group textarea {
  resize: vertical;
}
collab-org-invite-user-100554 .feedback {
  font-size: var(--font-size-16);
  padding: 10px 14px;
  border-radius: 4px;
}
collab-org-invite-user-100554 .feedback.success {
  color: var(--success-color);
  background-color: var(--grey-color-lighter);
}
collab-org-invite-user-100554 .feedback.error {
  color: var(--error-color);
  background-color: var(--grey-color-lighter);
}
collab-org-invite-user-100554 .form-actions {
  display: flex;
  justify-content: flex-end;
}
collab-org-invite-user-100554 .btn-primary {
  padding: 8px 20px;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  background-color: var(--active-color);
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
collab-org-invite-user-100554 .btn-primary:hover:not(:disabled) {
  background-color: var(--active-color-hover);
}
collab-org-invite-user-100554 .btn-primary:disabled {
  background-color: var(--active-color-disabled);
  cursor: not-allowed;
}
`);
        this.teams = [];
        this.loading = false;
        this.status = 'idle';
        this.msg = messages['en'];
        this._usernameOrEmail = '';
        this._initialTeam = '';
        this._complementaryText = '';
    }
    _handleInput(field, e) {
        const target = e.target;
        if (field === 'username')
            this._usernameOrEmail = target.value;
        if (field === 'team')
            this._initialTeam = target.value;
        if (field === 'text')
            this._complementaryText = target.value;
        this.requestUpdate();
    }
    _handleSubmit(e) {
        e.preventDefault();
        this.dispatchEvent(new CustomEvent('invite-submit', {
            detail: {
                username_or_email: this._usernameOrEmail,
                initial_team: this._initialTeam,
                complementary_text: this._complementaryText,
            },
            bubbles: true,
            composed: true,
        }));
    }
    _renderFeedback() {
        if (this.status === 'success')
            return html `<div class="feedback success">${this.msg.feedbackSuccess}</div>`;
        if (this.status === 'error')
            return html `<div class="feedback error">${this.msg.feedbackError}</div>`;
        return html ``;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <form class="invite-form" @submit="${(e) => this._handleSubmit(e)}">

                <div class="form-group">
                    <label for="invite-username">${this.msg.fieldUsername}</label>
                    <input
                        id="invite-username"
                        type="text"
                        .value="${this._usernameOrEmail}"
                        ?disabled="${this.loading}"
                        @input="${(e) => this._handleInput('username', e)}"
                    />
                </div>

                <div class="form-group">
                    <label for="invite-team">${this.msg.fieldTeam}</label>
                    <select
                        id="invite-team"
                        .value="${this._initialTeam}"
                        ?disabled="${this.loading}"
                        @change="${(e) => this._handleInput('team', e)}"
                    >
                        <option value="">${this.msg.fieldTeamPlaceholder}</option>
                        ${this.teams.map((t) => html `
                            <option value="${t}">${t}</option>
                        `)}
                    </select>
                </div>

                <div class="form-group">
                    <label for="invite-text">${this.msg.fieldCompText}</label>
                    <textarea
                        id="invite-text"
                        rows="3"
                        .value="${this._complementaryText}"
                        ?disabled="${this.loading}"
                        @input="${(e) => this._handleInput('text', e)}"
                    ></textarea>
                </div>

                ${this._renderFeedback()}

                <div class="form-actions">
                    <button type="submit" class="btn-primary" ?disabled="${this.loading}">
                        ${this.loading ? this.msg.btnSubmitting : this.msg.btnSubmit}
                    </button>
                </div>

            </form>
        `;
    }
};
__decorate([
    property({ type: Array })
], CollabOrgInviteUser.prototype, "teams", void 0);
__decorate([
    property({ type: Boolean })
], CollabOrgInviteUser.prototype, "loading", void 0);
__decorate([
    property({ type: String })
], CollabOrgInviteUser.prototype, "status", void 0);
CollabOrgInviteUser = __decorate([
    customElement('collab-org-invite-user-100554')
], CollabOrgInviteUser);
export { CollabOrgInviteUser };
