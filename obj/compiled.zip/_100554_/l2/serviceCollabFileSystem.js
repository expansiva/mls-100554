/// <mls fileReference="_100554_/l2/serviceCollabFileSystem.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { FileSystemAccessAdapter } from '/_100554_/l2/collabFileSystemAccess.js';
import { CollabFileSystemSync } from '/_100554_/l2/collabFileSystemSync.js';
import { openElementInServiceDetails } from '/_102027_/l2/libCommom.js';
/// **collab_i18n_start**
const message_en = {
    title: 'Local FS',
    unsupported: 'Use a Chromium browser for local filesystem access.',
    noProject: 'No project selected.',
    linkTitle: 'Link a local folder',
    linkBody: "Pick an empty folder for this project. Don't reuse a folder that's a git working copy — sync manages files directly.",
    selectFolder: 'Select folder',
    connected: 'Connected',
    project: 'Project',
    folder: 'Folder',
    lastSync: 'Last sync',
    files: 'Files',
    never: 'never',
    changeFolder: 'Change',
    disconnect: 'Disconnect',
    scanChanges: 'Scan changes',
    scanHint: 'Scan to see what to pull or push.',
    scanning: 'Scanning…',
    clean: 'Clean. No changes.',
    rescan: 'Scan again',
    toPull: 'to pull',
    toPush: 'to push',
    conflictsLabel: 'conflict',
    groupBrowser: 'From browser — Pull to apply',
    groupDisk: 'From disk — Push to apply',
    groupConflict: 'Conflicts — kept on disk',
    groupSkipped: 'Skipped',
    bAdded: 'added',
    bChanged: 'changed',
    bDeleted: 'deleted',
    bNew: 'new',
    bConflict: 'conflict',
    bSkipped: 'skipped',
    pull: 'Pull',
    push: 'Push',
    pushBlocked: 'Push blocked. Pull to FS first.',
    confirmPullTitle: 'Pull to FS',
    confirmPushTitle: 'Push to Browser',
    cWrite: 'written to disk from the browser',
    cTrash: 'moved to .collab-fs-trash',
    cConflictKept: 'conflict(s) kept untouched',
    cKeepLocal: 'new local file(s) kept',
    cCreate: 'created in the browser',
    cUpdate: 'updated in the browser',
    cDelete: 'deleted in the browser',
    confirm: 'Confirm',
    cancel: 'Cancel',
    folderLinked: 'Folder linked. Scan to see changes.',
    pullCanceled: 'Pull canceled.',
    pushCanceled: 'Push canceled.',
    nothingToPull: 'Nothing to pull.',
    nothingToPush: 'Nothing to push.',
    disconnected: 'Folder disconnected.',
    killBrowser: 'Kill browser version',
    killFs: 'Kill FS version',
    viewDiff: 'View diff',
    resolvedKeepBrowser: 'Resolved. Browser version won.',
    resolvedKeepFs: 'Resolved. FS version won.',
    resWritten: 'written',
    resTrashed: 'trashed',
    resSkipped: 'skipped',
    resCreated: 'created',
    resUpdated: 'updated',
    resDeleted: 'deleted',
    pBrowser: 'Reading browser',
    pLocal: 'Reading local',
    pCompare: 'Comparing',
    pWrite: 'Writing local',
    pDelete: 'Removing local',
    pPush: 'Loading browser',
    pManifest: 'Updating manifest',
    mSelectFolder: 'Select folder',
    mScan: 'Scan changes',
    mPull: 'Pull to FS',
    mPush: 'Push to Browser',
    mAbout: 'About this content',
};
const message_pt = {
    title: 'Local FS',
    unsupported: 'Use um navegador Chromium para acessar o sistema de arquivos local.',
    noProject: 'Nenhum projeto selecionado.',
    linkTitle: 'Conectar uma pasta local',
    linkBody: 'Escolha uma pasta vazia para este projeto. Não reutilize uma pasta que seja um repositório git — a sincronização gerencia os arquivos diretamente.',
    selectFolder: 'Selecionar pasta',
    connected: 'Conectado',
    project: 'Projeto',
    folder: 'Pasta',
    lastSync: 'Última sync',
    files: 'Arquivos',
    never: 'nunca',
    changeFolder: 'Trocar',
    disconnect: 'Desconectar',
    scanChanges: 'Verificar mudanças',
    scanHint: 'Verifique para ver o que enviar ou trazer.',
    scanning: 'Verificando…',
    clean: 'Limpo. Sem mudanças.',
    rescan: 'Verificar de novo',
    toPull: 'p/ trazer',
    toPush: 'p/ enviar',
    conflictsLabel: 'conflito',
    groupBrowser: 'Do browser — Pull aplica',
    groupDisk: 'Do disco — Push aplica',
    groupConflict: 'Conflitos — mantidos no disco',
    groupSkipped: 'Ignorados',
    bAdded: 'novo',
    bChanged: 'alterado',
    bDeleted: 'removido',
    bNew: 'novo',
    bConflict: 'conflito',
    bSkipped: 'ignorado',
    pull: 'Pull',
    push: 'Push',
    pushBlocked: 'Push bloqueado. Faça Pull to FS primeiro.',
    confirmPullTitle: 'Pull to FS',
    confirmPushTitle: 'Push to Browser',
    cWrite: 'gravados no disco a partir do browser',
    cTrash: 'movidos para .collab-fs-trash',
    cConflictKept: 'conflito(s) mantidos intactos',
    cKeepLocal: 'arquivo(s) novo(s) locais mantidos',
    cCreate: 'criados no browser',
    cUpdate: 'atualizados no browser',
    cDelete: 'removidos no browser',
    confirm: 'Confirmar',
    cancel: 'Cancelar',
    folderLinked: 'Pasta conectada. Verifique as mudanças.',
    pullCanceled: 'Pull cancelado.',
    pushCanceled: 'Push cancelado.',
    nothingToPull: 'Nada para trazer.',
    nothingToPush: 'Nada para enviar.',
    disconnected: 'Pasta desconectada.',
    killBrowser: 'Matar versão do browser',
    killFs: 'Matar versão do FS',
    viewDiff: 'Ver diff',
    resolvedKeepBrowser: 'Resolvido. Venceu a versão do browser.',
    resolvedKeepFs: 'Resolvido. Venceu a versão do FS.',
    resWritten: 'gravados',
    resTrashed: 'p/ lixeira',
    resSkipped: 'ignorados',
    resCreated: 'criados',
    resUpdated: 'atualizados',
    resDeleted: 'removidos',
    pBrowser: 'Lendo browser',
    pLocal: 'Lendo local',
    pCompare: 'Comparando',
    pWrite: 'Gravando local',
    pDelete: 'Removendo local',
    pPush: 'Carregando browser',
    pManifest: 'Atualizando manifesto',
    mSelectFolder: 'Selecionar pasta',
    mScan: 'Verificar mudanças',
    mPull: 'Pull to FS',
    mPush: 'Push to Browser',
    mAbout: 'Sobre este conteúdo',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
const PREF_KEY = 'serviceCollabFileSystem100554';
const BROWSER_KINDS = ['browserOnly', 'browserModified', 'browserDeleted'];
const DISK_KINDS = ['diskOnly', 'localOnly', 'diskModified', 'diskDeleted'];
const CONFLICT_KINDS = ['bothModified', 'modified'];
const SKIPPED_KINDS = ['unsupported'];
let ServiceCollabFileSystem100554 = class ServiceCollabFileSystem100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-collab-file-system-100554 {
  display: block;
  height: 100%;
  overflow: auto;
  color: var(--text-primary-color);
  background: var(--bg-primary-color);
}
service-collab-file-system-100554 .collab-fs-shell {
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
  min-height: 0;
  padding: 0.75rem;
}
service-collab-file-system-100554 .collab-fs-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 0.75rem;
  border-bottom: 1px solid var(--bg-primary-color-focus);
  padding-bottom: 0.75rem;
}
service-collab-file-system-100554 h2,
service-collab-file-system-100554 h3,
service-collab-file-system-100554 p {
  margin: 0;
}
service-collab-file-system-100554 h2 {
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
}
service-collab-file-system-100554 h3 {
  overflow-wrap: anywhere;
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
  margin-bottom: 0.5rem;
}
service-collab-file-system-100554 .collab-fs-header p,
service-collab-file-system-100554 .collab-fs-muted {
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .collab-fs-muted.center {
  text-align: center;
  margin-top: 0.5rem;
}
service-collab-file-system-100554 .collab-fs-project-picker {
  flex: 0 0 auto;
  display: flex;
  flex-direction: column;
  gap: 0.2rem;
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .collab-fs-project-picker select {
  min-width: 7rem;
  border: 1px solid var(--bg-primary-color-focus);
  border-radius: 4px;
  padding: 0.25rem 0.45rem;
  background: var(--bg-secondary-color);
  color: var(--text-primary-color);
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 button {
  min-height: 2rem;
  border: 1px solid var(--bg-primary-color-focus);
  border-radius: 4px;
  padding: 0.35rem 0.6rem;
  background: var(--bg-secondary-color);
  color: var(--text-primary-color);
  cursor: pointer;
  font: inherit;
}
service-collab-file-system-100554 button:hover {
  border-color: var(--text-primary-color-lighter);
}
service-collab-file-system-100554 button:disabled {
  cursor: default;
  opacity: 0.55;
}
service-collab-file-system-100554 button.primary {
  background: #1f6feb;
  border-color: #1f6feb;
  color: #ffffff;
}
service-collab-file-system-100554 button.danger {
  border-color: #f85149;
  color: #f85149;
  background: transparent;
}
service-collab-file-system-100554 button.block {
  width: 100%;
}
service-collab-file-system-100554 button.icon {
  min-height: auto;
  border: none;
  background: transparent;
  color: var(--text-primary-color-lighter);
  padding: 0.15rem 0.3rem;
}
service-collab-file-system-100554 button .dir {
  font-weight: var(--font-weight-bold);
}
service-collab-file-system-100554 .collab-fs-firstrun {
  text-align: center;
  padding: 0.75rem 0.25rem;
}
service-collab-file-system-100554 .collab-fs-firstrun-icon {
  font-family: 'Font Awesome 6 Pro', 'FontAwesome';
  font-size: 1.8rem;
  color: var(--text-primary-color-lighter);
}
service-collab-file-system-100554 .collab-fs-firstrun-title {
  font-size: var(--font-size-12);
  font-weight: var(--font-weight-bold);
  margin: 0.5rem 0 0.35rem;
}
service-collab-file-system-100554 .collab-fs-firstrun button {
  margin-top: 0.85rem;
}
service-collab-file-system-100554 .collab-fs-connection {
  background: var(--bg-secondary-color);
  border-radius: 6px;
  padding: 0.5rem 0.65rem;
}
service-collab-file-system-100554 .collab-fs-connection-row {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .collab-fs-dot {
  flex: 0 0 auto;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #2ea043;
}
service-collab-file-system-100554 .collab-fs-connection-text {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
service-collab-file-system-100554 .collab-fs-connection-text .arrow {
  color: var(--text-primary-color-lighter);
}
service-collab-file-system-100554 .collab-fs-details-panel {
  margin-top: 0.6rem;
  border-top: 1px solid var(--bg-primary-color-focus);
  padding-top: 0.6rem;
}
service-collab-file-system-100554 .collab-fs-details-panel dl {
  margin: 0;
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .collab-fs-details-panel dl > div {
  display: flex;
  justify-content: space-between;
  gap: 0.5rem;
  padding: 0.15rem 0;
}
service-collab-file-system-100554 .collab-fs-details-panel dt {
  color: var(--text-primary-color-lighter);
}
service-collab-file-system-100554 .collab-fs-details-panel dd {
  margin: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
service-collab-file-system-100554 .collab-fs-details-actions {
  display: flex;
  gap: 0.5rem;
  margin-top: 0.6rem;
}
service-collab-file-system-100554 .collab-fs-details-actions button {
  flex: 1;
}
service-collab-file-system-100554 .collab-fs-scan-cta {
  display: flex;
  flex-direction: column;
}
service-collab-file-system-100554 .collab-fs-clean {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 0.5rem;
  background: var(--bg-secondary-color);
  border-radius: 6px;
  padding: 0.65rem 0.75rem;
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .collab-fs-metrics {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
service-collab-file-system-100554 .collab-fs-metrics > div {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  background: var(--bg-secondary-color);
  border-radius: 6px;
  padding: 0.4rem 0.25rem;
}
service-collab-file-system-100554 .collab-fs-metrics .num {
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
}
service-collab-file-system-100554 .collab-fs-metrics .lbl {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
}
service-collab-file-system-100554 .collab-fs-metrics .rescan {
  flex: 0 0 auto;
  font-size: var(--font-size-16);
}
service-collab-file-system-100554 .collab-fs-list {
  display: flex;
  flex-direction: column;
  min-height: 0;
  max-height: 55vh;
  overflow: auto;
}
service-collab-file-system-100554 .collab-fs-group-title {
  margin: 0.65rem 0 0.25rem;
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
}
service-collab-file-system-100554 .collab-fs-change {
  display: grid;
  grid-template-columns: 4.5rem minmax(0, 1fr) auto;
  align-items: center;
  gap: 0.5rem;
  width: 100%;
  min-height: 2.2rem;
  border-width: 0 0 1px 0;
  border-radius: 0;
  text-align: left;
  background: transparent;
}
service-collab-file-system-100554 .collab-fs-change.selected {
  background: var(--bg-secondary-color);
}
service-collab-file-system-100554 .collab-fs-change .path {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .collab-fs-change .warn {
  color: #f85149;
  font-style: normal;
}
service-collab-file-system-100554 .kind {
  border-radius: 4px;
  padding: 0.15rem 0.3rem;
  text-align: center;
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .kind.b-browser {
  background: #E6F1FB;
  color: #0C447C;
}
service-collab-file-system-100554 .kind.b-disk {
  background: #FAEEDA;
  color: #633806;
}
service-collab-file-system-100554 .kind.b-new {
  background: #EAF3DE;
  color: #173404;
}
service-collab-file-system-100554 .kind.b-conflict {
  background: #FCEBEB;
  color: #791F1F;
}
service-collab-file-system-100554 .kind.b-skip {
  background: #E6E8EB;
  color: #353A40;
}
service-collab-file-system-100554 .collab-fs-actions {
  display: flex;
  gap: 0.5rem;
  margin-top: 0.5rem;
}
service-collab-file-system-100554 .collab-fs-actions button {
  flex: 1;
}
service-collab-file-system-100554 .rescan-btn {
  margin-top: 0.5rem;
}
service-collab-file-system-100554 .collab-fs-confirm {
  background: var(--bg-secondary-color);
  border: 1px solid var(--bg-primary-color-focus);
  border-radius: 6px;
  padding: 0.75rem;
}
service-collab-file-system-100554 .collab-fs-confirm ul {
  margin: 0.25rem 0 0.75rem;
  padding-left: 1.1rem;
  font-size: var(--font-size-12);
}
service-collab-file-system-100554 .collab-fs-confirm li {
  padding: 0.1rem 0;
}
service-collab-file-system-100554 .collab-fs-confirm-actions {
  display: flex;
  gap: 0.5rem;
}
service-collab-file-system-100554 .collab-fs-confirm-actions button {
  flex: 1;
}
service-collab-file-system-100554 .collab-fs-notice {
  border-left: 3px solid #1f6feb;
  background: var(--bg-secondary-color);
  padding: 0.5rem 0.65rem;
  font-size: var(--font-size-12);
}
`);
        this.supported = true;
        this.busy = false;
        this.project = 0;
        this.projectOptions = [];
        this.folderName = '';
        this.statusMessage = '';
        this.progressMessage = '';
        this.changes = [];
        this.selectedPath = '';
        this.scanResult = null;
        this.scanned = false;
        this.detailsOpen = false;
        this.pendingConfirm = null;
        this.lastSyncAt = '';
        this.linkedFileCount = 0;
        this.msg = messages['en'];
        this.adapter = new FileSystemAccessAdapter();
        this.sync = new CollabFileSystemSync(this.adapter);
        this.handle = null;
        this.lastProgressAt = 0;
        this.details = {
            icon: '&#xf07b',
            state: 'foreground',
            position: 'left',
            tooltip: 'Local FS',
            visible: true,
            widget: '_100554_serviceCollabFileSystem',
            level: [5]
        };
        this.menu = {
            title: '',
            main: {},
            tabs: undefined,
            tools: {},
            onClickMain: this.onClickMain.bind(this),
        };
        this.msg = messages[this.getMessageKey(messages)];
        this.menu.main = {
            opSelectFolder: this.msg.mSelectFolder,
            opScan: this.msg.mScan,
            opPull: this.msg.mPull,
            opPush: this.msg.mPush,
            opAboutThis: this.msg.mAbout,
        };
        this.supported = this.adapter.isSupported();
        this.setEvents();
    }
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        await this.loadProjectHandle();
    }
    onServiceClick(visible, reinit, el) {
        if (!visible)
            return;
        void this.loadProjectHandle();
    }
    onClickMain(op) {
        if (op === 'opSelectFolder')
            void this.selectFolder();
        else if (op === 'opScan')
            void this.scan();
        else if (op === 'opPull')
            this.requestPull();
        else if (op === 'opPush')
            this.requestPush();
        else if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    render() {
        const m = this.msg;
        return html `
            <section class="collab-fs-shell">
                <header class="collab-fs-header">
                    <div>
                        <h2>${m.title}</h2>
                        <p>${this.renderHeaderStatus()}</p>
                    </div>
                    <label class="collab-fs-project-picker">
                        <span>${m.project}</span>
                        <select
                            .value=${String(this.project || '')}
                            @change=${(event) => this.onProjectChange(event)}
                            ?disabled=${this.busy || this.projectOptions.length <= 1}
                        >
                            ${this.projectOptions.length > 0
            ? this.projectOptions.map((project) => html `<option value=${String(project)} ?selected=${project === this.project}>mls-${project}</option>`)
            : html `<option value="">mls-${this.project || '-'}</option>`}
                        </select>
                    </label>
                </header>

                ${this.renderBody()}
                ${this.renderNotice()}
            </section>
        `;
    }
    renderBody() {
        if (!this.supported || !this.project)
            return html ``;
        if (!this.handle)
            return this.renderFirstRun();
        return html `
            ${this.renderConnection()}
            ${this.pendingConfirm
            ? this.renderConfirmPanel()
            : (this.scanned ? this.renderScanned() : this.renderScanCta())}
        `;
    }
    renderFirstRun() {
        const m = this.msg;
        return html `
            <div class="collab-fs-firstrun">
                <i class="collab-fs-firstrun-icon">&#xf07b;</i>
                <p class="collab-fs-firstrun-title">${m.linkTitle}</p>
                <p class="collab-fs-muted">${m.linkBody}</p>
                <button class="primary block" @click=${() => this.selectFolder()} ?disabled=${this.busy}>${m.selectFolder}</button>
            </div>
        `;
    }
    renderConnection() {
        const m = this.msg;
        return html `
            <div class="collab-fs-connection">
                <div class="collab-fs-connection-row">
                    <span class="collab-fs-dot"></span>
                    <span class="collab-fs-connection-text">mls-${this.project} <span class="arrow">&rarr;</span> ${this.folderName || '-'}</span>
                    <button class="icon" aria-label="${m.connected}" @click=${() => this.detailsOpen = !this.detailsOpen}>
                        ${this.detailsOpen ? '▴' : '▾'}
                    </button>
                </div>
                ${this.detailsOpen ? this.renderDetails() : html ``}
            </div>
        `;
    }
    renderDetails() {
        const m = this.msg;
        return html `
            <div class="collab-fs-details-panel">
                <dl>
                    <div><dt>${m.project}</dt><dd>mls-${this.project}</dd></div>
                    <div><dt>${m.folder}</dt><dd>${this.folderName || '-'}</dd></div>
                    <div><dt>${m.lastSync}</dt><dd>${this.formatLastSync()}</dd></div>
                    <div><dt>${m.files}</dt><dd>${this.scanResult?.browserCount ?? this.linkedFileCount}</dd></div>
                </dl>
                <div class="collab-fs-details-actions">
                    <button @click=${() => this.selectFolder()} ?disabled=${this.busy}>${m.changeFolder}</button>
                    <button class="danger" @click=${() => this.disconnect()} ?disabled=${this.busy}>${m.disconnect}</button>
                </div>
            </div>
        `;
    }
    renderScanCta() {
        const m = this.msg;
        return html `
            <div class="collab-fs-scan-cta">
                <button class="primary block" @click=${() => this.scan()} ?disabled=${this.busy}>
                    ${this.busy ? m.scanning : m.scanChanges}
                </button>
                <p class="collab-fs-muted center">${m.scanHint}</p>
            </div>
        `;
    }
    renderScanned() {
        const m = this.msg;
        if (this.changes.length === 0) {
            return html `
                <div class="collab-fs-clean">
                    <p>${m.clean}</p>
                    <button @click=${() => this.scan()} ?disabled=${this.busy}>${m.rescan}</button>
                </div>
            `;
        }
        const pull = this.sync.planPull(this.changes);
        const push = this.sync.planPush(this.changes);
        const pullCount = pull.write.length + pull.delete.length;
        const pushCount = push.create.length + push.update.length + push.delete.length;
        const pushBlocked = push.blocked.length > 0;
        return html `
            <div class="collab-fs-metrics">
                <div><span class="num">${pullCount}</span><span class="lbl">${m.toPull}</span></div>
                <div><span class="num">${pushCount}</span><span class="lbl">${m.toPush}</span></div>
                <div><span class="num">${pull.conflict.length}</span><span class="lbl">${m.conflictsLabel}</span></div>
            </div>

            <div class="collab-fs-actions">
                <button class="primary" @click=${() => this.requestPull()} ?disabled=${this.busy || pullCount === 0}>
                    <span class="dir">&darr;</span> ${m.pull} &middot; ${pullCount}
                </button>
                <button @click=${() => this.requestPush()} ?disabled=${this.busy || pushCount === 0 || pushBlocked}>
                    <span class="dir">&uarr;</span> ${m.push} &middot; ${pushCount}
                </button>
            </div>
            ${pushBlocked ? html `<p class="collab-fs-muted center">${m.pushBlocked}</p>` : html ``}
            <button class="block rescan-btn" @click=${() => this.scan()} ?disabled=${this.busy}>
                <span class="dir">&#x21BB;</span> ${m.rescan}
            </button>

            <div class="collab-fs-list">
                ${this.renderGroup(m.groupBrowser, BROWSER_KINDS)}
                ${this.renderGroup(m.groupDisk, DISK_KINDS)}
                ${this.renderGroup(m.groupConflict, CONFLICT_KINDS)}
                ${this.renderGroup(m.groupSkipped, SKIPPED_KINDS)}
            </div>
        `;
    }
    renderGroup(title, kinds) {
        const items = this.changes.filter((change) => kinds.includes(change.kind));
        if (items.length === 0)
            return html ``;
        return html `
            <p class="collab-fs-group-title">${title}</p>
            ${items.map((change) => html `
                <button
                    class="collab-fs-change ${this.selectedPath === change.path ? 'selected' : ''}"
                    @click=${() => this.openChangeDetails(change)}
                >
                    <span class="kind ${this.getBadgeClass(change.kind)}">${this.getBadgeLabel(change.kind)}</span>
                    <span class="path">${change.path}</span>
                    ${CONFLICT_KINDS.includes(change.kind) ? html `<i class="warn">&#x26A0;</i>` : html ``}
                </button>
            `)}
        `;
    }
    renderConfirmPanel() {
        const p = this.pendingConfirm;
        if (!p)
            return html ``;
        const m = this.msg;
        const title = p.kind === 'pull' ? m.confirmPullTitle : m.confirmPushTitle;
        const lines = p.kind === 'pull' ? this.pullConfirmLines(p.pull) : this.pushConfirmLines(p.push);
        return html `
            <div class="collab-fs-confirm">
                <h3>${title}</h3>
                <ul>${lines.map((line) => html `<li>${line}</li>`)}</ul>
                <div class="collab-fs-confirm-actions">
                    <button @click=${() => this.confirmCancel()} ?disabled=${this.busy}>${m.cancel}</button>
                    <button class="primary" @click=${() => this.confirmExecute()} ?disabled=${this.busy}>${m.confirm}</button>
                </div>
            </div>
        `;
    }
    pullConfirmLines(plan) {
        const m = this.msg;
        const lines = [`${plan.write.length} ${m.cWrite}`, `${plan.delete.length} ${m.cTrash}`];
        if (plan.conflict.length)
            lines.push(`${plan.conflict.length} ${m.cConflictKept}`);
        if (plan.keepLocal.length)
            lines.push(`${plan.keepLocal.length} ${m.cKeepLocal}`);
        return lines;
    }
    pushConfirmLines(plan) {
        const m = this.msg;
        return [`${plan.create.length} ${m.cCreate}`, `${plan.update.length} ${m.cUpdate}`, `${plan.delete.length} ${m.cDelete}`];
    }
    renderHeaderStatus() {
        const m = this.msg;
        if (!this.supported)
            return m.unsupported;
        if (this.busy)
            return this.progressMessage || this.statusMessage || m.scanning;
        if (!this.project)
            return m.noProject;
        if (this.folderName)
            return this.folderName;
        return m.linkTitle;
    }
    renderNotice() {
        if (!this.statusMessage || this.busy)
            return html ``;
        return html `<div class="collab-fs-notice">${this.statusMessage}</div>`;
    }
    getBadgeClass(kind) {
        if (BROWSER_KINDS.includes(kind))
            return 'b-browser';
        if (kind === 'diskOnly' || kind === 'localOnly')
            return 'b-new';
        if (kind === 'diskModified' || kind === 'diskDeleted')
            return 'b-disk';
        if (CONFLICT_KINDS.includes(kind))
            return 'b-conflict';
        return 'b-skip';
    }
    getBadgeLabel(kind) {
        const m = this.msg;
        if (kind === 'browserOnly')
            return m.bAdded;
        if (kind === 'diskOnly' || kind === 'localOnly')
            return m.bNew;
        if (kind === 'diskDeleted' || kind === 'browserDeleted')
            return m.bDeleted;
        if (kind === 'diskModified' || kind === 'browserModified')
            return m.bChanged;
        if (CONFLICT_KINDS.includes(kind))
            return m.bConflict;
        return m.bSkipped;
    }
    openChangeDetails(change) {
        this.selectedPath = change.path;
        const div = document.createElement('div');
        div.className = 'collab-fs-detail-page';
        div.style.padding = '0.75rem';
        div.appendChild(this.createDetailStyle());
        const title = document.createElement('h3');
        title.textContent = change.path;
        div.appendChild(title);
        const meta = document.createElement('div');
        meta.className = 'collab-fs-detail-meta';
        meta.textContent = this.getDetailText(change);
        div.appendChild(meta);
        if (this.isResolvable(change.kind)) {
            this.appendConflictResolution(div, change);
            this.openDetailsRight(div);
            return;
        }
        if (change.kind === 'unsupported') {
            this.appendMuted(div, change.message || 'Unsupported file.');
            this.openDetailsRight(div);
            return;
        }
        if (change.localContent === undefined && change.browserContent === undefined) {
            this.appendMuted(div, 'Diff not loaded. Scan used metadata for speed.');
            this.openDetailsRight(div);
            return;
        }
        if (change.localContent instanceof Blob || change.browserContent instanceof Blob) {
            this.appendMuted(div, 'Binary file. Text diff is not available.');
            this.openDetailsRight(div);
            return;
        }
        const localContent = typeof change.localContent === 'string' ? change.localContent : '';
        const browserContent = typeof change.browserContent === 'string' ? change.browserContent : '';
        this.openMonacoDiffRight(change, localContent, browserContent);
    }
    openMonacoDiffRight(change, localContent, browserContent) {
        const sourceOriginal = this.isDiskSideChange(change) ? browserContent : localContent;
        const sourceModified = this.isDiskSideChange(change) ? localContent : browserContent;
        this.openService('_100554_serviceHistories', 'right', 5);
        void mls.events.fire([5], ['HistoriesSelected'], JSON.stringify({
            project: this.project || this.getProject(),
            level: 5,
            shortName: 'collabFileSystem',
            folder: '',
            extension: this.getExtensionFromPath(change.path),
            position: 'left',
            hashOriginal: '',
            hashModified: '',
            sourceOriginal,
            sourceModified,
            language: this.getLanguageFromPath(change.path),
        }), 0);
    }
    isResolvable(kind) {
        return CONFLICT_KINDS.includes(kind) || kind === 'diskDeleted' || kind === 'browserDeleted';
    }
    appendConflictResolution(container, change) {
        const m = this.msg;
        const actions = document.createElement('div');
        actions.className = 'collab-fs-detail-actions';
        // "kill browser" keeps the disk version; "kill fs" keeps the browser version.
        const killBrowser = document.createElement('button');
        killBrowser.className = 'danger';
        killBrowser.textContent = m.killBrowser;
        killBrowser.addEventListener('click', () => void this.resolveConflict(change, 'disk'));
        actions.appendChild(killBrowser);
        const killFs = document.createElement('button');
        killFs.className = 'danger';
        killFs.textContent = m.killFs;
        killFs.addEventListener('click', () => void this.resolveConflict(change, 'browser'));
        actions.appendChild(killFs);
        container.appendChild(actions);
        if (typeof change.localContent === 'string' && typeof change.browserContent === 'string') {
            const wrap = document.createElement('div');
            wrap.className = 'collab-fs-detail-actions';
            const viewDiff = document.createElement('button');
            viewDiff.textContent = m.viewDiff;
            viewDiff.addEventListener('click', () => this.openMonacoDiffRight(change, change.localContent, change.browserContent));
            wrap.appendChild(viewDiff);
            container.appendChild(wrap);
        }
    }
    async resolveConflict(change, keep) {
        await this.runExclusive(async () => {
            const project = this.getProject();
            if (!project)
                throw new Error(this.msg.noProject);
            if (!this.handle)
                throw new Error('No folder selected.');
            if (!await this.adapter.ensurePermission(this.handle))
                throw new Error('Folder permission was not granted.');
            await this.sync.resolveConflict(project, this.handle, change.path, keep, this.reportProgress.bind(this));
            await this.scanCurrent();
            this.statusMessage = keep === 'browser' ? this.msg.resolvedKeepBrowser : this.msg.resolvedKeepFs;
        });
    }
    isDiskSideChange(change) {
        return change.kind === 'diskOnly' ||
            change.kind === 'diskModified' ||
            change.kind === 'diskDeleted' ||
            change.kind === 'localOnly';
    }
    getExtensionFromPath(path) {
        const known = ['.defs.ts', '.test.ts', '.tsx', '.ts', '.html', '.less', '.css', '.json', '.md', '.mjs', '.js', '.jsx', '.vue', '.sql', '.txt', '.style', '.svg'];
        return known.find((extension) => path.endsWith(extension)) || '.txt';
    }
    getLanguageFromPath(path) {
        const extension = this.getExtensionFromPath(path);
        if (extension === '.ts' || extension === '.tsx' || extension === '.defs.ts' || extension === '.test.ts')
            return 'typescript';
        if (extension === '.mjs' || extension === '.js' || extension === '.jsx')
            return 'javascript';
        if (extension === '.html' || extension === '.vue')
            return 'html';
        if (extension === '.less')
            return 'less';
        if (extension === '.css' || extension === '.style')
            return 'css';
        if (extension === '.json')
            return 'json';
        if (extension === '.md')
            return 'markdown';
        if (extension === '.sql')
            return 'sql';
        if (extension === '.svg')
            return 'xml';
        return 'text';
    }
    openDetailsRight(element) {
        this.openService('_100554_serviceDetail', 'right', 5);
        void openElementInServiceDetails(element);
    }
    createDetailStyle() {
        const style = document.createElement('style');
        style.textContent = `
            .collab-fs-detail-page {
                box-sizing: border-box;
                color: var(--text-primary-color, inherit);
                height: 100%;
                overflow: auto;
            }
            .collab-fs-detail-page h3 {
                margin: 0 0 0.5rem;
                overflow-wrap: anywhere;
                font-size: 1rem;
            }
            .collab-fs-detail-meta,
            .collab-fs-muted {
                color: var(--text-primary-color-lighter, #8b949e);
                font-size: 0.8rem;
            }
            .collab-fs-detail-actions {
                display: flex;
                gap: 0.5rem;
                margin-top: 0.75rem;
            }
            .collab-fs-detail-actions button {
                flex: 1;
                min-height: 2rem;
                border: 1px solid rgba(128, 128, 128, 0.4);
                border-radius: 4px;
                padding: 0.35rem 0.6rem;
                background: transparent;
                color: inherit;
                cursor: pointer;
                font: inherit;
            }
            .collab-fs-detail-actions button.danger {
                border-color: #f85149;
                color: #f85149;
            }
        `;
        return style;
    }
    appendMuted(container, text) {
        const p = document.createElement('p');
        p.className = 'collab-fs-muted';
        p.textContent = text;
        container.appendChild(p);
    }
    getDetailText(change) {
        if (change.kind === 'browserOnly')
            return 'Pull to FS creates this file locally.';
        if (change.kind === 'localOnly' || change.kind === 'diskOnly')
            return 'Push to Browser creates this file in the browser.';
        if (change.kind === 'diskDeleted')
            return 'Deleted on disk. Push to Browser deletes it in the browser too. Keep the browser version to restore it on disk instead.';
        if (change.kind === 'browserDeleted')
            return 'Browser deleted this file. Push is blocked until Pull to FS or conflict resolution.';
        if (change.kind === 'diskModified')
            return 'Push to Browser imports the local file.';
        if (change.kind === 'browserModified')
            return 'Browser changed this file. Push is blocked until Pull to FS.';
        if (change.kind === 'bothModified')
            return 'Both sides changed. Push is blocked for this conflict.';
        return 'Pull to FS replaces the local file with the browser version.';
    }
    async selectFolder() {
        await this.runExclusive(async () => {
            const project = this.getProject();
            if (!project)
                throw new Error(this.msg.noProject);
            if (!this.supported)
                throw new Error(this.msg.unsupported);
            const selectedHandle = await this.adapter.showDirectoryPicker();
            if (!await this.adapter.ensurePermission(selectedHandle))
                throw new Error('Folder permission was not granted.');
            const handle = await this.resolveSelectedProjectHandle(project, selectedHandle);
            if (!await this.adapter.ensurePermission(handle))
                throw new Error('Folder permission was not granted.');
            this.folderName = handle.name;
            this.reportProgress({ phase: 'local', current: 0, path: handle.name });
            const validation = await this.sync.validateFirstSync(project, handle, this.reportProgress.bind(this));
            if (!validation.empty)
                await this.sync.ensureManifest(project, handle, this.reportProgress.bind(this));
            if (selectedHandle.name === 'mls-base')
                await this.adapter.saveBaseHandle(selectedHandle);
            await this.adapter.saveHandle(project, handle);
            this.project = project;
            this.handle = handle;
            this.savePreferences(project, handle.name);
            this.resetScanState();
            this.detailsOpen = false;
            await this.refreshManifestInfo();
            this.statusMessage = this.msg.folderLinked;
        });
    }
    async disconnect() {
        await this.runExclusive(async () => {
            const project = this.getProject();
            if (project)
                await this.adapter.removeHandle(project);
            localStorage.removeItem(PREF_KEY);
            this.handle = null;
            this.folderName = '';
            this.detailsOpen = false;
            this.resetScanState();
            this.statusMessage = this.msg.disconnected;
        });
    }
    async scan() {
        await this.runExclusive(async () => {
            await this.scanCurrent();
            this.scanned = true;
        });
    }
    requestPull() {
        if (this.busy || !this.handle || !this.scanned)
            return;
        const plan = this.sync.planPull(this.changes);
        if (plan.write.length + plan.delete.length === 0) {
            this.statusMessage = this.msg.nothingToPull;
            return;
        }
        this.pendingConfirm = { kind: 'pull', pull: plan };
    }
    requestPush() {
        if (this.busy || !this.handle || !this.scanned)
            return;
        const plan = this.sync.planPush(this.changes);
        if (plan.blocked.length > 0) {
            this.statusMessage = this.msg.pushBlocked;
            return;
        }
        if (plan.create.length + plan.update.length + plan.delete.length === 0) {
            this.statusMessage = this.msg.nothingToPush;
            return;
        }
        this.pendingConfirm = { kind: 'push', push: plan };
    }
    confirmCancel() {
        const kind = this.pendingConfirm?.kind;
        this.pendingConfirm = null;
        this.statusMessage = kind === 'pull' ? this.msg.pullCanceled : this.msg.pushCanceled;
    }
    async confirmExecute() {
        const pending = this.pendingConfirm;
        if (!pending)
            return;
        this.pendingConfirm = null;
        if (pending.kind === 'pull')
            await this.runPull();
        else
            await this.runPush();
    }
    async runPull() {
        await this.runExclusive(async () => {
            const project = this.getProject();
            if (!project)
                throw new Error(this.msg.noProject);
            if (!this.handle)
                throw new Error('No folder selected.');
            if (!await this.adapter.ensurePermission(this.handle))
                throw new Error('Folder permission was not granted.');
            const result = await this.sync.pullToFs(project, this.handle, this.reportProgress.bind(this));
            await mls.events.fire([5], ['CollabFileSystem'], JSON.stringify({
                action: 'pullToFs',
                project,
                written: result.written,
                deleted: result.deleted,
                skipped: result.skipped,
            }), 0);
            await this.scanCurrent();
            const m = this.msg;
            this.statusMessage = `${result.written} ${m.resWritten} · ${result.deleted} ${m.resTrashed} · ${result.skipped} ${m.resSkipped}`;
        });
    }
    async runPush() {
        await this.runExclusive(async () => {
            const project = this.getProject();
            if (!project)
                throw new Error(this.msg.noProject);
            if (!this.handle)
                throw new Error('No folder selected.');
            if (!await this.adapter.ensurePermission(this.handle))
                throw new Error('Folder permission was not granted.');
            const result = await this.sync.pushToBrowser(project, this.handle, this.reportProgress.bind(this));
            await mls.events.fire([5], ['CollabFileSystem'], JSON.stringify({
                action: 'pushToBrowser',
                project,
                created: result.created,
                updated: result.updated,
                deleted: result.deleted,
                skipped: result.skipped,
            }), 0);
            await this.scanCurrent();
            const m = this.msg;
            this.statusMessage = `${result.created} ${m.resCreated} · ${result.updated} ${m.resUpdated} · ${result.deleted} ${m.resDeleted} · ${result.skipped} ${m.resSkipped}`;
        });
    }
    async scanCurrent() {
        const project = this.getProject();
        if (!project)
            throw new Error(this.msg.noProject);
        if (!this.handle)
            throw new Error('No folder selected.');
        if (!await this.adapter.ensurePermission(this.handle))
            throw new Error('Folder permission was not granted.');
        this.project = project;
        const result = await this.sync.scan(project, this.handle, this.reportProgress.bind(this));
        this.scanResult = result;
        this.changes = result.changes;
        this.selectedPath = this.changes[0]?.path || '';
        this.lastSyncAt = new Date().toISOString();
        this.statusMessage = '';
    }
    async loadProjectHandle(selectActualProject = false) {
        const previousProject = this.project;
        const project = this.resolveSelectedProject(selectActualProject);
        this.supported = this.adapter.isSupported();
        if (!this.supported) {
            this.statusMessage = this.msg.unsupported;
            return;
        }
        if (project !== previousProject)
            this.resetScanState();
        this.project = project;
        if (!project) {
            this.statusMessage = this.msg.noProject;
            return;
        }
        const handle = await this.getStoredProjectHandle(project);
        this.handle = handle;
        this.folderName = handle?.name || this.readPreferences(project)?.folderName || '';
        if (!handle) {
            this.resetScanState();
            return;
        }
        await this.refreshManifestInfo();
    }
    async onProjectChange(event) {
        const value = Number(event.target.value);
        if (!Number.isInteger(value) || value <= 0 || value === this.project)
            return;
        this.project = value;
        this.handle = null;
        this.folderName = '';
        this.detailsOpen = false;
        this.resetScanState();
        await this.loadProjectHandle();
    }
    resetScanState() {
        this.scanned = false;
        this.changes = [];
        this.scanResult = null;
        this.selectedPath = '';
        this.pendingConfirm = null;
        this.lastSyncAt = '';
        this.linkedFileCount = 0;
    }
    async refreshManifestInfo() {
        if (!this.handle)
            return;
        const manifest = await this.sync.readManifest(this.handle).catch(() => null);
        if (!manifest)
            return;
        this.lastSyncAt = manifest.lastSyncAt || '';
        this.linkedFileCount = Object.keys(manifest.files || {}).length;
    }
    formatLastSync() {
        if (!this.lastSyncAt)
            return this.msg.never;
        const date = new Date(this.lastSyncAt);
        if (Number.isNaN(date.getTime()))
            return this.msg.never;
        return date.toLocaleString();
    }
    async resolveSelectedProjectHandle(project, handle) {
        if (handle.name !== 'mls-base')
            return handle;
        return handle.getDirectoryHandle(`mls-${project}`, { create: true });
    }
    async getStoredProjectHandle(project) {
        const projectHandle = await this.adapter.getHandle(project);
        if (projectHandle)
            return projectHandle;
        const baseHandle = await this.adapter.getBaseHandle();
        if (!baseHandle || !await this.adapter.ensurePermission(baseHandle))
            return null;
        const expectedName = `mls-${project}`;
        const handle = await baseHandle.getDirectoryHandle(expectedName, { create: false }).catch(() => null);
        if (!handle)
            return null;
        await this.adapter.saveHandle(project, handle);
        this.savePreferences(project, handle.name);
        return handle;
    }
    getProject() {
        return this.project || mls.actualProject || 0;
    }
    resolveSelectedProject(selectActualProject = false) {
        const actualProject = mls.actualProject || 0;
        const options = this.getProjectOptions(actualProject);
        this.projectOptions = options;
        if (!actualProject)
            return 0;
        if (selectActualProject || !this.project || !options.includes(this.project))
            return actualProject;
        return this.project;
    }
    getProjectOptions(actualProject) {
        if (!actualProject)
            return [];
        try {
            const projects = mls.l5.getProjectDependencies(actualProject, true);
            const unique = projects.filter((project, index) => Number.isInteger(project) &&
                project > 0 &&
                projects.indexOf(project) === index);
            return [actualProject, ...unique.filter((project) => project !== actualProject)];
        }
        catch (err) {
            return [actualProject];
        }
    }
    savePreferences(project, folderName) {
        localStorage.setItem(PREF_KEY, JSON.stringify({ project, folderName, updatedAt: new Date().toISOString() }));
    }
    readPreferences(project) {
        const raw = localStorage.getItem(PREF_KEY);
        if (!raw)
            return null;
        try {
            const parsed = JSON.parse(raw);
            return parsed.project === project ? parsed : null;
        }
        catch (err) {
            return null;
        }
    }
    async runExclusive(action) {
        if (this.busy)
            return;
        this.busy = true;
        this.progressMessage = '';
        this.lastProgressAt = 0;
        try {
            await action();
        }
        catch (err) {
            this.statusMessage = err instanceof Error ? err.message : String(err);
        }
        finally {
            this.progressMessage = '';
            this.busy = false;
        }
    }
    reportProgress(progress) {
        const now = Date.now();
        if (now - this.lastProgressAt < 100 && progress.current !== progress.total)
            return;
        this.lastProgressAt = now;
        this.progressMessage = this.formatProgress(progress);
        this.statusMessage = this.progressMessage;
    }
    formatProgress(progress) {
        const m = this.msg;
        const count = progress.total ? `${progress.current}/${progress.total}` : `${progress.current}`;
        const path = progress.path ? ` - ${progress.path}` : '';
        if (progress.phase === 'browser')
            return `${m.pBrowser} ${count}${path}`;
        if (progress.phase === 'local')
            return `${m.pLocal} ${count}${path}`;
        if (progress.phase === 'compare')
            return `${m.pCompare} ${count}${path}`;
        if (progress.phase === 'write')
            return `${m.pWrite} ${count}${path}`;
        if (progress.phase === 'delete')
            return `${m.pDelete} ${count}${path}`;
        if (progress.phase === 'push')
            return `${m.pPush} ${count}${path}`;
        return `${m.pManifest} ${count}${path}`;
    }
    setEvents() {
        mls.events.addEventListener([5], ['ProjectSelected'], () => this.loadProjectHandle(true));
        mls.events.addEventListener([1, 2, 3, 4, 5, 6, 7], ['ToolBarSelected'], () => {
            if (this.visible === 'true')
                this.loadProjectHandle();
        });
    }
    showAboutThis() {
        const m = this.msg;
        const div = document.createElement('div');
        div.style.padding = '1rem';
        div.innerHTML = `
            <h3>${m.title}</h3>
            <ul>
                <li>${m.project}: mls-${this.project || '-'}</li>
                <li>${m.folder}: ${this.folderName || '-'}</li>
            </ul>
        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
};
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "supported", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "busy", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "project", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "projectOptions", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "folderName", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "statusMessage", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "progressMessage", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "changes", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "selectedPath", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "scanResult", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "scanned", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "detailsOpen", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "pendingConfirm", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "lastSyncAt", void 0);
__decorate([
    state()
], ServiceCollabFileSystem100554.prototype, "linkedFileCount", void 0);
ServiceCollabFileSystem100554 = __decorate([
    customElement('service-collab-file-system-100554')
], ServiceCollabFileSystem100554);
export { ServiceCollabFileSystem100554 };
