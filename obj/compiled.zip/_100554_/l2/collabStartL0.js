/// <mls fileReference="_100554_/l2/collabStartL0.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
const message_pt = {
  desc: "Descri\xE7\xE3o",
  news: "Novidades",
  inDevelopment: "Em desenvolvimento...",
  details1: "Sobre esse level",
  module1Title: "M\xF3dulo L0 - User: Descri\xE7\xE3o e Funcionalidades",
  module1Text: "O m\xF3dulo L0 \xE9 voltado para o usu\xE1rio geral da plataforma Collab.codes. Este m\xF3dulo oferece uma vis\xE3o geral dos projetos em que o usu\xE1rio est\xE1 envolvido, al\xE9m de permitir a gest\xE3o de autoridades, escolha de planos e personaliza\xE7\xE3o visual da ferramenta.",
  module1List1: "Visualizar e ver projetos: permite ao usu\xE1rio uma vis\xE3o geral e detalhada dos projetos em que est\xE1 envolvido, facilitando o acompanhamento do progresso",
  module1List2: "Dar autoridades a outros: oferece a op\xE7\xE3o de conceder diferentes n\xEDveis de autoridade a outros membros da equipe, como administrador, editor ou visualizador",
  module1List3: "Escolher o plano atual: permite ao usu\xE1rio selecionar o plano de assinatura mais adequado \xE0s suas necessidades e, se necess\xE1rio, incluir informa\xE7\xF5es de faturamento.",
  module1List4: "Selecionar prefer\xEAncias visuais: oferece op\xE7\xF5es para personalizar a apar\xEAncia da ferramenta, como temas, layout e configura\xE7\xF5es de exibi\xE7\xE3o.",
  module2Title: "Fluxo de Uso",
  module2List1: "O usu\xE1rio acessa o m\xF3dulo L0 e tem uma vis\xE3o geral dos projetos em que est\xE1 envolvido.",
  module2List2: "Se necess\xE1rio, concede autoridades a outros membros da equipe para facilitar a colabora\xE7\xE3o.",
  module2List3: "Escolhe o plano de assinatura que melhor atende \xE0s suas necessidades e inclui informa\xE7\xF5es de faturamento, se aplic\xE1vel..",
  module2List4: "Personaliza a interface da ferramenta de acordo com suas prefer\xEAncias visuais para uma experi\xEAncia de usu\xE1rio mais agrad\xE1vel.",
  moduleExplain: "O m\xF3dulo L0 serve como um hub central para o usu\xE1rio, permitindo uma gest\xE3o eficaz de projetos, equipes e prefer\xEAncias pessoais. \xC9 uma parte crucial para garantir que o usu\xE1rio tenha controle e visibilidade sobre todos os aspectos relevantes da plataforma."
};
const message_en = {
  desc: "Description",
  news: "News",
  inDevelopment: "In development...",
  details1: "About this level",
  module1Title: "Module L0 - User: Description and Features",
  module1Text: "The L0 module is designed for the general user of the Collab.codes platform. This module provides an overview of the projects the user is involved in, while enabling authority management, plan selection, and visual customization of the tool.",
  module1List1: "View and monitor projects: allows the user to have an overview and detailed insight into the projects they are involved in, facilitating progress tracking.",
  module1List2: "Grant authorities to others: offers the option to assign different levels of authority to other team members, such as administrator, editor, or viewer.",
  module1List3: "Select the current plan: enables the user to choose the subscription plan that best suits their needs and, if necessary, include billing information.",
  module1List4: "Choose visual preferences: provides options to customize the tool\u2019s appearance, such as themes, layout, and display settings.",
  module2Title: "Usage Flow",
  module2List1: "The user accesses the L0 module and gets an overview of the projects they are involved in.",
  module2List2: "If needed, grants authority to other team members to facilitate collaboration.",
  module2List3: "Selects the subscription plan that best meets their needs and includes billing information, if applicable.",
  module2List4: "Customizes the tool\u2019s interface according to their visual preferences for a more pleasant user experience.",
  moduleExplain: "The L0 module serves as a central hub for the user, enabling effective management of projects, teams, and personal preferences. It is a crucial part of ensuring that the user has control and visibility over all relevant aspects of the platform."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let CollabStartL0100554 = class extends StateLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-start-l0-100554 {
  line-height: 1.15;
  position: relative;
  height: 100%;
  overflow: auto;
  font-family: 'Cambria', serif;
  font-size: var(--font-size-16);
  font-weight: 400;
}
collab-start-l0-100554 details > summary {
  cursor: pointer;
  font-size: var(--font-size-20);
}
collab-start-l0-100554 .collab-codes-banner {
  margin-left: auto;
  margin-right: auto;
  display: block;
  width: 100%;
  max-width: 100%;
  position: relative;
}
collab-start-l0-100554 .collab-codes-banner img {
  width: 100% !important;
  height: auto !important;
}
collab-start-l0-100554 .collab-codes-link {
  display: flex;
  justify-content: center;
  gap: 2rem;
  padding: 2rem;
}
collab-start-l0-100554 .collab-codes-link button {
  cursor: pointer;
  background: none;
  border: none;
  text-decoration: underline;
  color: var(--active-color);
}
collab-start-l0-100554 .collab-codes-content {
  padding: 0 0.5rem;
  margin-left: auto;
  margin-right: auto;
  max-width: 800px;
  justify-content: center;
}
collab-start-l0-100554 .collab-codes-content details {
  margin-bottom: 1rem;
}
collab-start-l0-100554 .collab-codes-content details > div {
  padding-left: 1.5rem;
}
collab-start-l0-100554 .collab-codes-contents {
  justify-content: center;
}
collab-start-l0-100554 .collab-codes-contents details {
  margin-bottom: 1rem;
}
collab-start-l0-100554 .collab-codes-contents details > div {
  padding-left: 1.5rem;
}
collab-start-l0-100554 .separator {
  padding-top: 24px;
  padding-bottom: 10px;
  margin-top: 32px;
  margin-bottom: 14px;
  display: flex;
  justify-content: center;
}
collab-start-l0-100554 .separator > span {
  width: 4px;
  height: 4px;
  background-color: var(--text-primary-color);
  border-radius: 50%;
  display: inline-block;
  margin-right: 20px;
}
collab-start-l0-100554 h1 {
  line-height: 52px;
  font-size: 42px;
  font-weight: 700;
  font-style: normal;
}
collab-start-l0-100554 h2 {
  line-height: 30px;
  font-size: 24px;
  font-weight: 600;
  font-style: normal;
}
collab-start-l0-100554 h1,
collab-start-l0-100554 h2,
collab-start-l0-100554 h3,
collab-start-l0-100554 h4,
collab-start-l0-100554 h5,
collab-start-l0-100554 h6,
collab-start-l0-100554 h7 {
  letter-spacing: -0.011em;
}
collab-start-l0-100554 ol > li,
collab-start-l0-100554 ul > li {
  margin-top: 1em;
}
collab-start-l0-100554 span,
collab-start-l0-100554 p,
collab-start-l0-100554 li {
  line-height: 32px;
  font-size: 20px;
}
collab-start-l0-100554 .collab_marca {
  position: absolute;
  bottom: 10px;
  right: 20px;
  opacity: 0.2;
}
`);
    this.msg = messages["en"];
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
        <section class="collab-codes-start">
            <div class="collab-codes-banner">
                <img id="serviceStartL0ImageBanner" src="./l3/_100529_/images/startl0.avif" height="250" width="800" alt="banner">
            </div>
            <div class="collab-codes-content">
                <details id="serviceStartL0DetailsAbout" open="open">
                    <summary>${this.msg.details1}</summary>
                    <div>
                        <h1>${this.msg.module1Title}</h1>
                        <div>
                            <h2>${this.msg.desc}</h2>
                            <span>${this.msg.module1Text}
                                <ol>
                                    <li>${this.msg.module1List1}</li>
                                    <li>${this.msg.module1List2}</li>
                                    <li>${this.msg.module1List3}</li>
                                    <li>${this.msg.module1List4}</li>
                                </ol>
                            </span>
                        </div>
                        <div class="separator">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>
                            <h3>${this.msg.module2Title}</h3>
                            <ol>
                                <li>${this.msg.module2List1}</li>
                                <li>${this.msg.module2List2}</li>
                                <li>${this.msg.module2List3}</li>
                                <li>${this.msg.module2List4}</li>
                            </ol>
                            <span>${this.msg.moduleExplain}</span>
                        </div>
                    </div>
                </details>
                <details id="serviceStartL0DetailsNews" open="open">
                    <summary>${this.msg.news}</summary>
                    <div>
                        <span>${this.msg.inDevelopment}</span>
                    </div>
                </details>
            </div>
        </section>
        <img class="collab_marca" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==" height="140" width="140" alt="collab codes">
         `;
  }
};
CollabStartL0100554 = __decorateClass([
  customElement("collab-start-l0-100554")
], CollabStartL0100554);
export {
  CollabStartL0100554
};
