/// <mls fileReference="_100554_/l2/ateste2.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
const message_pt = {
  hello: "Hello world!"
};
let SimpleGreeting = class extends CollabLitElement {
  constructor() {
    super(...arguments);
    this.pending = {};
    this.frutas = [];
    this.name = "Roberto";
  }
  firstUpdated() {
    this.configFetch();
  }
  handleConfirm(e) {
    console.info(e.detail);
  }
  render() {
    return html`
        <div class="cls1">
            <button @click=${this.buscar}>Buscar</button>
            Frutas
            <ul>
                ${this.frutas.map((p) => html`<li>${p}</li>`)}
            </ul>
        </div>`;
  }
  buscar() {
    fetch("/produtos", {
      method: "GET",
      body: JSON.stringify({ user: "teste" })
    }).then(async (res) => {
      const json = await res.json();
      console.log("Resposta do servidor fake:", json);
      this.frutas = json.itens;
    });
  }
  configFetch() {
    if (!top.previewL1) return;
    console.info("Setou");
    window.fetch = (url, options) => {
      return new Promise((resolve) => {
        const id = crypto.randomUUID();
        this.pending[id] = resolve;
        top.previewL1.contentWindow.postMessage({
          type: "fetch-request",
          id,
          url,
          options
        }, "*");
      });
    };
    window.onmessage = (e) => {
      const data = e.data;
      if (data.type !== "fetch-response") return;
      const resolve = this.pending[data.id];
      if (!resolve) return;
      delete this.pending[data.id];
      resolve(new Response(data.body, {
        status: data.status,
        headers: data.headers
      }));
    };
  }
};
__decorateClass([
  property()
], SimpleGreeting.prototype, "frutas", 2);
__decorateClass([
  property()
], SimpleGreeting.prototype, "name", 2);
SimpleGreeting = __decorateClass([
  customElement("ateste2-100554")
], SimpleGreeting);
export {
  SimpleGreeting
};
