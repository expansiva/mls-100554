/// <mls fileReference="_100554_/l2/ateste2.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
//import { CollabLitElement } from '/_100554_/l2/l2/collabLitElement.js';
//import { CollabLitElement } from './l2/collabLitElement'
// colocar no console: mls.modePreview = 'minimum' 
const message_pt = {
    hello: 'Hello world!'
};
let SimpleGreeting = class SimpleGreeting extends CollabLitElement {
    pending = {};
    frutas = [];
    name = 'Roberto';
    firstUpdated() {
        this.configFetch();
    }
    handleConfirm(e) {
        console.info(e.detail);
    }
    render() {
        return html `
        <div class="cls1">
            <button @click=${this.buscar}>Buscar</button>
            Frutas
            <ul>
                ${this.frutas.map((p) => html `<li>${p}</li>`)}
            </ul>
        </div>`;
    }
    buscar() {
        fetch("/produtos", {
            method: "GET",
            body: JSON.stringify({ user: "teste" })
        }).then(async (res) => {
            const json = await res.json();
            console.log("Resposta do servidor fake:", json);
            this.frutas = json.itens;
        });
    }
    configFetch() {
        if (!top.previewL1)
            return;
        console.info('Setou');
        window.fetch = (url, options) => {
            return new Promise((resolve) => {
                const id = crypto.randomUUID();
                this.pending[id] = resolve;
                top.previewL1.contentWindow.postMessage({
                    type: "fetch-request",
                    id,
                    url,
                    options
                }, "*");
            });
        };
        window.onmessage = (e) => {
            const data = e.data;
            if (data.type !== "fetch-response")
                return;
            const resolve = this.pending[data.id];
            if (!resolve)
                return;
            delete this.pending[data.id];
            resolve(new Response(data.body, {
                status: data.status,
                headers: data.headers
            }));
        };
    }
};
__decorate([
    property()
], SimpleGreeting.prototype, "frutas", void 0);
__decorate([
    property()
], SimpleGreeting.prototype, "name", void 0);
SimpleGreeting = __decorate([
    customElement('ateste2-100554')
], SimpleGreeting);
export { SimpleGreeting };
