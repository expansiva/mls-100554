import { getTokensLess } from "/_100554_/l2/designSystemBase.js";
import { getState, setState } from "/_100554_/l2/collabState.js";
function systemAgentsAvailable() {
  return {
    type: "system",
    content: `## Agentes dispon\xEDveis:
${getAgentsList()}`
  };
}
function systemRagsAvailable() {
  return {
    type: "system",
    content: `## RAGs dispon\xEDveis:
${getRagsList()}`
  };
}
function addRAGAdditionalInformation(rags, prompts) {
  if (!rags || rags.length === 0) return;
  prompts.push({
    type: "system",
    content: `## Informa\xE7\xF5es complementares:
${rags.join("\n")}`
  });
}
function systemReturnJsonFormat() {
  return {
    type: "system",
    content: `
Voc\xEA deve retornar um array de objetos no formato JSON. Cada objeto representa uma subtarefa, com **apenas um dos seguintes formatos**:
\`\`\` json
[
  {
    "type": "agent",
    "agentName": string,
    "title": string,
    "prompt": string,
    "rags": string[] | null
  },
  {
    "type": "tool",
    "toolName": string,
    "title": string,
    "args": string
  },
  {
    "type": "clarification",
    "clarificationMessage": string,
    "htmlForm?": string
  },
  {
    "type": "result",
    "result": string
  }
]
\`\`\`
`
  };
}
function getAgentsList() {
  const listAgents = [
    { agent: "agentGeneratePrototype", description: "planejamento para a cria\xE7\xE3o de novos projetos, sites ou cria\xE7\xE3o de uma nova p\xE1gina" },
    { agent: "agentNewWidget", description: "cria\xE7\xE3o de novos componentes UI, web components, widgets, estes widgets podem futuramente serem incluidos em uma p\xE1gina html." },
    { agent: "agentPlannerNewAPI", description: "cria\xE7\xE3o de endpoints ou APIs, ser\xE1 pedido mais informa\xE7\xF5es ao usu\xE1rio se necess\xE1rio." },
    { agent: "agentSupportExternal", description: "suporte para usu\xE1rios externos. Executar rag1 antes de enviar o prompt." },
    { agent: "agentSupportInternal", description: "suporte para usu\xE1rios internos. Executar os RAGs rag1 e rag2 antes de enviar o prompt." },
    { agent: "agentGenerateDefs", description: "cria\xE7\xE3o e atualiza\xE7\xE3o do arquivo definition." }
  ];
  return `Agentes dispon\xEDveis:
${listAgents.map((item) => `\u2022	${item.agent}:${item.description}`).join("\n")}`;
}
function getRagsList() {
  return `
- rag1: base de conhecimento de suporte geral.
- rag2: base de conhecimento da empresa (documenta\xE7\xE3o interna).`;
}
;
async function systemToolsAvailable() {
  const tools = await getToolsList();
  return {
    type: "system",
    content: `## Tools dispon\xEDveis:
${tools}`
  };
}
async function getToolsList() {
  const tolls = await getListFilesStart("tool");
  return tolls.join("\n");
}
async function getListFilesStart(start) {
  const keys = Object.keys(mls.stor.files);
  const ret = [];
  for await (const k of keys) {
    try {
      if (k.indexOf(start) < 0) continue;
      const file = mls.stor.files[k];
      const path = `/_${file.project}_/l2/${file.shortName}`;
      if (file.extension !== ".ts" || !file.shortName.startsWith(start)) continue;
      if (start === "widget") {
        ret.push(file.shortName);
      } else {
        const mdl = await import(path);
        if (start === "tool") {
          const tool = mdl.createTool();
          ret.push(getDefTool(tool));
        } else {
          const agent = mdl.createAgent();
          ret.push(`${agent.agentName}: ${agent.agentDescription}`);
        }
      }
    } catch (e) {
      console.info("Erro get list with start: " + start + " in key:" + k);
    }
  }
  return ret;
}
function getDefTool(tool) {
  const argsList = Object.keys(tool.argsSchema || {}).map((arg) => `${arg}:${tool.argsSchema[arg].type} /* ${tool.argsSchema[arg].description} */`).join(", ");
  return `${tool.toolName}: ${tool.description} (args: ${argsList})`;
}
async function systemTokensLessInstruction() {
  const project = mls.actualProject;
  const theme = "Default";
  if (!project) throw new Error("Invalid Project");
  return {
    type: "system",
    content: "## LESS TOKENS - DESIGN SYSTEM \n\n" + await getTokensLess(project, theme) || ""
  };
}
async function getPromptByHtml(dt) {
  const groupMode = getState("playgroundAgent.modeCompare");
  if (!dt.project || !dt.shortName) {
    setState("playgroundAgent.modeCompare", void 0);
    throw new Error(`[getPromptByHtml]: incomplete parameters.`);
  }
  const keyFile = mls.stor.getKeyToFiles(dt.project, 2, dt.shortName, dt.folder, ".html");
  if (!mls.stor.files[keyFile]) {
    setState("playgroundAgent.modeCompare", void 0);
    throw new Error(`[getPromptByHtml]: not found stor.file ${keyFile}.`);
  }
  const content = await mls.stor.files[keyFile].getContent();
  if (!content) {
    setState("playgroundAgent.modeCompare", void 0);
    return [];
  }
  const el = document.createElement("div");
  el.innerHTML = content;
  const itens = el.querySelectorAll("promptcustom");
  const ret = [];
  let hasGroup = false;
  itens.forEach((item) => {
    const itemGroup = item.getAttribute("group");
    if (itemGroup) hasGroup = true;
  });
  itens.forEach((item) => {
    let cont = item.innerHTML;
    const tp = item.getAttribute("type");
    const itemGroup = item.getAttribute("group");
    if (tp === "memory" || tp === "prompt" || groupMode && groupMode !== itemGroup || !groupMode && hasGroup && itemGroup !== "A") return;
    cont = escape(cont);
    if (dt.data) {
      cont = clearGaps(cont);
      const keys = findKeys(cont);
      keys.forEach((key) => {
        if (!dt.data) return;
        const st = dt.data[key];
        if (st === void 0) return;
        const rp = `{{${key}}}`;
        cont = cont.replace(rp, st);
      });
    }
    ret.push({
      type: tp,
      content: cont
    });
  });
  setState("playgroundAgent.modeCompare", void 0);
  return ret;
}
function clearGaps(text) {
  return text.replace(/{{(.*?)}}/g, (_, content) => {
    return `{{${content.trim().replace(/\s+/g, "")}}}`;
  });
}
function findKeys(text) {
  const regex = /{{(.*?)}}/g;
  const resultados = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    resultados.push(match[1].trim());
  }
  return resultados;
}
function escape(input) {
  return input.replace(/&lt;/g, "<").replace(/&gt;/g, ">");
}
async function getSource(dt) {
  const keyFile = mls.stor.getKeyToFiles(dt.project, dt.level, dt.shortName, dt.folder, dt.extension);
  if (!mls.stor.files[keyFile]) throw new Error(`[getSource]: not found stor.file ${keyFile}.`);
  const rc = await mls.stor.files[keyFile].getContent();
  return rc;
}
export {
  addRAGAdditionalInformation,
  getListFilesStart,
  getPromptByHtml,
  getSource,
  systemAgentsAvailable,
  systemRagsAvailable,
  systemReturnJsonFormat,
  systemTokensLessInstruction,
  systemToolsAvailable
};
