/// <mls shortName="icaLitElementBase" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
export class IcaLitElementBase extends StateLitElement {
    constructor() {
        super(...arguments);
        this.mySymbol = 'fa-column';
        this.originalAttrs = [];
        //--------IMPLEMENTS-------------
        this.excludesProps = ['rendertype', 'level', 'style', 'id'];
    }
    //--------COMPONENT-----------------
    connectedCallback() {
        super.connectedCallback();
        const attrs = this.getAttributes();
        attrs.forEach((atr) => {
            if (atr.name.startsWith('.'))
                return;
            this.setAttribute(atr.name, atr.value);
        });
    }
    createRenderRoot() {
        return this;
    }
    getAttributes() {
        const language = this.closest('html')?.lang || 'en';
        const attributes = [];
        const attributeNames = this.getAttributeNames();
        for (let attrName of attributeNames) {
            if (this.excludesProps.includes(attrName))
                continue;
            let attrValue = this.getAttribute(attrName);
            if (attrName === 'idel')
                attrName = 'id';
            if (attrName === 'classel')
                attrName = 'class';
            if (attrValue !== null) {
                attributes.push({
                    name: attrName,
                    value: attrValue
                });
                this.originalAttrs.push({
                    name: attrName,
                    value: attrValue
                });
            }
        }
        const attrsByVariation = this.filterAttributes(attributes, language);
        return attrsByVariation;
    }
    filterAttributes(attributes, variation) {
        const variationSuffix = `-${variation.toLowerCase()}`; // -en
        const variationAttributes = attributes.filter(attr => attr.name.endsWith(variationSuffix));
        const nonVariationAttributes = attributes.filter(attr => {
            if (attr.name.includes('-') && attr.name.endsWith(variationSuffix))
                return false;
            const split = attr.name.split('-');
            if (split.length > 1)
                split.pop();
            const attrBase = split.join('-');
            return !attributes.some(a => a.name.startsWith(attrBase) && a !== attr && variationAttributes.includes(a));
        });
        let aux = [...nonVariationAttributes, ...variationAttributes];
        aux.forEach(attr => {
            const split = attr.name.split('-');
            if (split.length > 0) {
                const language = split.pop();
                if (language === variation)
                    attr.name = split.join('-');
            }
        });
        return aux;
    }
}
__decorate([
    property({ type: String })
], IcaLitElementBase.prototype, "level", void 0);
