const asis = {
  "meta": {
    "fileReference": "_100554_/l2/collabStore.ts",
    "componentType": "service",
    "componentScope": "editor",
    "group": "enhancement"
  },
  "asIs": {
    "semantic": {
      "generalDescription": "State for incrementing page hit counts",
      "businessCapabilities": [
        "Count page hits"
      ],
      "technicalCapabilities": [
        "Increment count on page access"
      ],
      "implementedFeatures": [
        "Export COUNTHITSPAGES constant"
      ]
    }
  }
};
export {
  asis
};
