"use strict";
/// <mls shortName="agentCreateNewPrototypeOrganism" project="100554" enhancement="_blank" folder="" />
