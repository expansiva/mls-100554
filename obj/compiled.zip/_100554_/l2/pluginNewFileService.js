/// <mls fileReference="_100554_/l2/pluginNewFileService.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { convertFileNameToTag } from "/_102027_/l2/utils.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
import { getMessageKey } from "/_100554_/l2/collabLitElement.js";
import { propertyDataSource } from "/_100554_/l2/collabDecorators.js";
import { createNewFile, changeTagName, changeClassName, changeWidget, getTemplateImport } from "/_100554_/l2/pluginNewFileBase.js";
import "/_100554_/l2/widgetTextCode.js";
const message_pt = {
  title: "Criar um service",
  description: "Criar um service, que ser\xE1 utilizado no sistema collab.\nUm service no collab.codes, permite a cria\xE7\xE3o de menus ap\xF3s selecionar o level, fica no nav2, com \xEDcones.\nAp\xF3s criar o arquivo use a intelig\xEAncia artificial para preparar o service.",
  project: "Projeto",
  shortName: "Nome",
  header: "Criar um service",
  btnCreate: "Criar arquivo",
  loading: "Criando arquivo...",
  error: "Nome do arquivo em branco ou invalido",
  errorServiceName: 'Nome do arquivo deve come\xE7ar com "service"'
};
const message_en = {
  title: "Create a service in Lit",
  description: "Create a service to be used in the Collab system.\nA service in collab.codes allows creating menus after selecting the level, placed in nav2 with icons.\nAfter creating the file, use artificial intelligence to prepare the service.",
  project: "Project",
  shortName: "ShortName",
  header: "Create a service in Lit",
  btnCreate: "Create file",
  loading: "Creating File...",
  error: "Blank or invalid file name",
  errorServiceName: 'File name must start with "service"'
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
const lang = getMessageKey(messages);
let msg = messages[lang];
const details = {
  title: msg.title,
  description: msg.description,
  tags: ["lit", "internal", "service"]
};
let PluginNewFileService = class extends StateLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file-service-100554 {
  width: 100%;
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
plugin-new-file-service-100554 widget-text-code-100554 {
  font-size: var(--font-size-12);
}
plugin-new-file-service-100554 button {
  background-color: var(--active-color);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: #fff;
  cursor: pointer;
}
plugin-new-file-service-100554 button:hover {
  background-color: var(--active-color-hover);
}
`);
    this.position = "left";
    this.loading = false;
    this.service = this.closest("service-detail-100554");
    this.template = `
import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase, IService, IToolbarContent, IServiceMenu } from '${getTemplateImport(100554, "serviceBase", "")}';

@customElement('[tagName]')
export class [className] extends ServiceBase {
    public details: IService = {
        icon: '&#xf15b',
        state: 'foreground',
        position: 'right',
        tooltip: 'Service Example',
        visible: true,
        widget: '[widgetName]',
        level: [5]
    }

    public onClickMain(op: string): void {
        if (this.menu.setMode) this.menu.setMode('initial');
    }

    public menu: IServiceMenu = {
        title: 'Example',
        main: {},
        tools: {},
        tabs: undefined,
        onClickMain: this.onClickMain.bind(this),
    }

    onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null) {

    }


    @property() 
    name: string = 'Somebody';

    render() {
        return html\`<p> Hello, \${ this.name } !</p>\`;
    }
}`;
    this.enhancement = `_100554_enhancementLitService`;
    this.groupName = `other`;
  }
  getTemplate() {
    let newExample = this.template;
    if (this.shortName && this.project && this.shortName) {
      const name2 = this.folder ? this.folder + "/" + this.shortName : this.shortName;
      newExample = changeTagName(newExample, convertFileNameToTag({ project: this.project, shortName: this.shortName, folder: this.folder }));
      newExample = changeClassName(newExample, this.project, this.shortName);
      newExample = changeWidget(newExample, this.project, name2);
    }
    const group = this.groupName && this.groupName != "other" ? ` groupName="${this.groupName}"` : "";
    const enhancement = this.enhancement ? this.enhancement : "_blank";
    const folder = this.folder ? `${this.folder}/` : "";
    const name = `_${this.project}_/l2/${folder}${this.shortName}.ts`;
    return `/// <mls fileReference="${name}" enhancement="${enhancement}"${group}/>
${newExample}
`;
  }
  async handleAddFile() {
    if (!this.project || !this.shortName) {
      this.service.setError(msg.error);
      return;
    }
    ;
    if (!this.shortName.startsWith("service")) {
      this.service.setError(msg.errorServiceName);
      return;
    }
    this.loading = true;
    try {
      await createNewFile({
        project: this.project,
        position: this.position,
        shortName: this.shortName,
        folder: this.folder,
        enhancement: this.enhancement,
        sourceTS: this.getTemplate(),
        openPreview: true
      });
    } catch (e) {
      this.loading = false;
    }
  }
  render() {
    return html`
            ${this.loading ? html`<div>${msg.loading}</div>` : html`   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>

                    <widget-text-code-100554 language="typescript" text="${this.getTemplate()}"></widget-text-code-100554>
                
                </div>`}
        `;
  }
};
__decorateClass([
  propertyDataSource()
], PluginNewFileService.prototype, "shortName", 2);
__decorateClass([
  propertyDataSource({ attribute: true })
], PluginNewFileService.prototype, "project", 2);
__decorateClass([
  propertyDataSource({ attribute: true })
], PluginNewFileService.prototype, "folder", 2);
__decorateClass([
  property()
], PluginNewFileService.prototype, "position", 2);
__decorateClass([
  property()
], PluginNewFileService.prototype, "loading", 2);
PluginNewFileService = __decorateClass([
  customElement("plugin-new-file-service-100554")
], PluginNewFileService);
export {
  PluginNewFileService,
  details
};
