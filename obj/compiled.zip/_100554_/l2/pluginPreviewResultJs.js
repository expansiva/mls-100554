/// <mls fileReference="_100554_/l2/pluginPreviewResultJs.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { property, query } from "lit/decorators.js";
import { PluginBaseModule } from "/_100554_/l2/pluginBaseModule.js";
import { getDependenciesByMFile } from "/_100554_/l2/libCompile.js";
const message_pt = {
  noItens: "Nenhum item ICA foi encontrado!"
};
const message_en = {
  noItens: "No ICA items were found!"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
class PluginPreviewResultJs extends PluginBaseModule {
  msg = messages["en"];
  _ed1;
  hasError = false;
  results = {
    errors: "",
    prodJS: "",
    configTS: "",
    libTS: "",
    jsonImport: ""
  };
  get confE() {
    return `l2_left`;
  }
  msize = "";
  editor;
  updated(changedProperties) {
    if (changedProperties.has("msize")) {
      this.editor?.setAttribute("msize", this.msize);
    }
  }
  createRenderRoot() {
    return this;
  }
  async firstUpdated() {
    this.createEditor();
    const actualFile = mls.actual[2].left;
    if (!actualFile) return;
    const { project, shortName, folder } = actualFile;
    this.setInitialModelProdJS(project, shortName, folder, "compiling...");
    await this.getCompileResults(project, shortName, folder);
    this.setInitialModelProdJS(project, shortName, folder, this.results.prodJS);
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`<mls-editor-100529></mls-editor-100529>`;
  }
  createEditor() {
    if (!this.editor || this._ed1) return;
    this._ed1 = monaco.editor.create(this.editor, mls.editor.conf[this.confE]);
    monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
      noImplicitAny: true
    });
    this._ed1.updateOptions({ readOnly: true });
    this.editor.mlsEditor = this._ed1;
  }
  async getCompileResults(project, shortName, folder) {
    const models = mls.editor.getModels(project, shortName, folder, 2);
    if (!models || !models.ts) return;
    if (models.ts.compilerResults && !models.ts.compilerResults.prodJS) models.ts.compilerResults.modelNeedCompile = true;
    await mls.l2.typescript.compile(models.ts);
    const errs = {
      Errors: models.ts.compilerResults?.errors || []
    };
    const libs = monaco.languages.typescript.typescriptDefaults.getExtraLibs();
    const libs2 = {};
    Object.keys(libs).forEach((key) => {
      libs2[key] = {
        version: libs[key].version
      };
    });
    this.hasError = errs.Errors.length > 0;
    const jsonImp = await getDependenciesByMFile(models);
    this.results = {
      prodJS: models.ts.compilerResults?.prodJS || "",
      errors: JSON.stringify(errs, null, 2),
      configTS: JSON.stringify(monaco.languages.typescript.typescriptDefaults.getCompilerOptions(), null, 2),
      libTS: JSON.stringify(libs2, null, 2),
      jsonImport: JSON.stringify(jsonImp, null, 2)
    };
  }
  setInitialModelProdJS(project, shortName, folder, src) {
    const model1 = this.createOrGetModel(project, shortName, folder, "javascript", src);
    if (!model1) return;
    if (this._ed1) this._ed1.setModel(model1);
  }
  getUri(shortFN) {
    return monaco.Uri.parse(`file://server/${shortFN}_results_js.ts`);
  }
  createOrGetModel(project, shortName, folder, editorType, src) {
    let name = folder ? `_${project}_${folder}_${shortName}` : `_${project}_${shortName}`;
    const uri = this.getUri(name);
    let modelResultJS = monaco.editor.getModel(uri);
    if (modelResultJS) {
      modelResultJS.setValue(src);
      return modelResultJS;
    }
    modelResultJS = monaco.editor.createModel(src, editorType, uri);
    return modelResultJS;
  }
}
__decorateClass([
  property({ type: String })
], PluginPreviewResultJs.prototype, "msize", 2);
__decorateClass([
  query("mls-editor-100529")
], PluginPreviewResultJs.prototype, "editor", 2);
if (!customElements.get("plugin-preview-result-js-100554")) {
  customElements.define("plugin-preview-result-js-100554", PluginPreviewResultJs);
}
export {
  PluginPreviewResultJs
};
