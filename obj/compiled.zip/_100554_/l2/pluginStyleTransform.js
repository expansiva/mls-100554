/// <mls fileReference="_100554_/l2/pluginStyleTransform.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, queryAll } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
import { getMessageKey } from '/_102029_/l2/collabLitElement.js';
import '/_100554_/l2/collabDsInputSelectColor.js';
import '/_100554_/l2/collabDsInputRange.js';
import '/_100554_/l2/collabDsInputSelectColor.js';
import '/_100554_/l2/collabDsInputRange.js';
/// **collab_i18n_start**
const message_pt = {
    advanced: 'Avançado',
    scaleX: 'Escala x',
    scaleY: 'Escala y',
    skewX: 'Inclinar x',
    skewY: 'Inclinar y',
    translateX: 'Transladar x',
    translateY: 'Transladar y',
    rotate: 'Rotacionar',
    description: 'Um plugin versátil para manter e aplicar propriedades de transformação CSS. Gerencie facilmente transformações de escala, rotação, inclinação e tradução para criar elementos de UI dinâmicos e interativos com precisão'
};
const message_en = {
    advanced: 'Advanced',
    scaleX: 'Scale x',
    scaleY: 'Scale y',
    skewX: 'Skew x',
    skewY: 'Skew Y',
    translateX: 'Translate x',
    translateY: 'Translate y',
    rotate: 'Rotate',
    description: 'A versatile plugin for maintaining and applying CSS transform properties. Easily manage scale, rotate, skew, and translate transformations to create dynamic and interactive UI elements with precision.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['transform'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStyleTransform = class PluginStyleTransform extends StateLitElement {
    constructor() {
        super(...arguments);
        this.showFull = 'true';
        this.position = 'left';
        this.msg = messages['en'];
        this.timeonChangeProp = -1;
        this.gallery = [
            {
                state: { transform: 'scale(1.5)' },
                style: 'transform: scale(1.5);'
            },
            {
                state: { transform: 'rotate(90deg)' },
                style: 'transform: rotate(90deg);'
            },
            {
                state: { transform: 'rotate(181deg)' },
                style: 'transform: rotate(181deg);'
            },
            {
                state: { transform: 'rotate(270deg)' },
                style: 'transform: rotate(270deg);'
            },
            {
                state: { transform: 'skew(50deg)' },
                style: 'transform: skew(50deg);'
            },
            {
                state: { transform: 'skew(50deg, -50deg)' },
                style: 'transform: skew(50deg, -50deg);'
            },
            {
                state: { transform: 'skew(-50deg, 0deg)' },
                style: 'transform: skew(-50deg, 0deg);'
            },
            {
                state: { transform: 'skew(-50deg, 50deg)' },
                style: 'transform: skew(-50deg, 50deg);'
            },
            {
                state: { transform: 'translateX(20px)' },
                style: 'transform: translateX(20px);'
            },
            {
                state: { transform: 'scale(0.75)' },
                style: 'transform: scale(0.75);'
            },
            {
                state: { transform: 'scaleX(1.2)' },
                style: 'transform: scaleX(1.2);'
            },
            {
                state: { transform: 'scaleX(1.8)' },
                style: 'transform: scaleX(1.8);'
            },
            {
                state: { transform: 'rotate(45deg)' },
                style: 'transform: rotate(45deg);'
            },
            {
                state: { transform: 'rotate(-45deg)' },
                style: 'transform: rotate(-45deg);'
            },
            {
                state: { transform: 'skewX(30deg)' },
                style: 'transform: skewX(30deg);'
            },
            {
                state: { transform: 'skewY(-15deg)' },
                style: 'transform: skewY(-15deg);'
            },
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!_value.selector || !_value.lessCSS || !_value.lessCSS.lessAST || !_value.lessCSS.lessAST.ast[_value.selector])
            return;
        const actualAst = _value.lessCSS.lessAST.ast[_value.selector];
        if (!actualAst)
            return;
        let hasRuleTransformInAST = false;
        Object.keys(actualAst).forEach((prop) => {
            if (prop === 'transform')
                hasRuleTransformInAST = true;
        });
        this.clear();
        if (hasRuleTransformInAST) {
            this._onIcaStateChange();
        }
    }
    clear() {
        this.transform = undefined;
        this.scaleX = undefined;
        this.scaleY = undefined;
        this.rotate = undefined;
        this.translateX = undefined;
        this.translateY = undefined;
        this.skewX = undefined;
        this.skewY = undefined;
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    setValues2() {
        const auxFilter = {
            scaleX: '',
            scaleY: '',
            rotate: '',
            translateX: '',
            translateY: '',
            skewX: '',
            skewY: '',
        };
        const filter = this.transform?.split(')') || [];
        filter.forEach((item) => {
            if (!item)
                return;
            const prop = item.substring(0, item.indexOf('(')).trim();
            item = item.substring(item.indexOf('('), item.length);
            if (prop.indexOf('scale') >= 0 || prop.indexOf('translate') >= 0 || prop.indexOf('skew') >= 0) {
                item.split(',').forEach((vl, index) => {
                    if (!vl)
                        return;
                    const num = vl.match(/[\.-\d]/g)?.join('');
                    const prefx = index === 0 ? 'X' : 'Y';
                    const hasprefix = prop.endsWith('X') || prop.endsWith('Y');
                    const key = hasprefix ? prop : prop + prefx;
                    if (auxFilter[key] !== undefined)
                        auxFilter[key] = num;
                });
            }
            else {
                const num = item.match(/[\.-\d]/g)?.join('');
                if (auxFilter[prop] !== undefined)
                    auxFilter[prop] = num;
            }
        });
        this.scaleX = auxFilter.scaleX;
        this.scaleY = auxFilter.scaleY;
        this.rotate = auxFilter.rotate;
        this.translateX = auxFilter.translateX;
        this.translateY = auxFilter.translateY;
        this.skewX = auxFilter.skewX;
        this.skewY = auxFilter.skewY;
    }
    setValues(rule) {
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (propertyName === 'transform') {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                }
            }
        }
        this.setValues2();
    }
    mountValue() {
        let value = '';
        if (this.scaleX || this.scaleY)
            value += 'scale(' + (this.scaleX ? this.scaleX : '1') + (this.scaleY ? ', ' + this.scaleY : '') + ') ';
        if (this.rotate)
            value += this.rotate ? 'rotate(' + this.rotate + 'deg) ' : '';
        if (this.translateX || this.translateY)
            value += 'translate(' + (this.translateX ? this.translateX + 'px' : '0px') + (this.translateY ? ', ' + this.translateY : ', 0') + 'px) ';
        if (this.skewX || this.skewY)
            value += 'skew(' + (this.skewX ? this.skewX + 'deg' : '0deg') + (this.skewY ? ', ' + this.skewY : ', 0') + 'deg) ';
        this.transform = value.trim();
        this.setState();
    }
    setState() {
        setState(`less.${this.position}.emitter`, 'helper');
        const styles = getState(`less.${this.position}.lessCSS.styles`);
        styles.transform = this.transform || '';
    }
    handleChange(e) {
        clearTimeout(this.timeonChangeProp);
        const el = e.detail ? e.detail.target : e.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        if (this.timeonChangeProp)
            window.clearTimeout(this.timeonChangeProp);
        this.timeonChangeProp = window.setTimeout(() => {
            this[prop] = el.value;
            this.mountValue();
        }, 100);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.showFull === 'true' ?
            html `
                    ${this.renderGallery()}
                    ${this.renderTransform()}

                ` :
            html `
                    ${this.renderGallery()}
                `}
        `;
    }
    renderTransform() {
        return html `
            <div class="group">
                <span>${this.msg.scaleX}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="scaleX" value=${this.scaleX} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.scaleY}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="scaleY" value=${this.scaleY} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.skewX}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="skewX" value=${this.skewX} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.skewY}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="skewY" value=${this.skewY} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.translateX}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="translateX" value=${this.translateX} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.translateY}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="translateY" value=${this.translateY} useSelect="false"></collab-ds-input-range-100554>
                </div>
                <span>${this.msg.rotate}</span>
                <div class="group-edit">
                    <collab-ds-input-range-100554 @onchange=${this.handleChange} prop="rotate" value=${this.rotate} useSelect="false"></collab-ds-input-range-100554>
                </div>
            </div>
        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `<h5 style="${galleryItem.style}" @click=${() => { this.onGalleryClick(galleryItem); }}>Item</h5>`;
        }))}
            </div>
        
        `;
    }
    async onGalleryClick(item) {
        this.transform = item.state.transform;
        this.setValues2();
        await this.updateComplete;
        this.setState();
    }
};
__decorate([
    property()
], PluginStyleTransform.prototype, "showFull", void 0);
__decorate([
    propertyDataSource()
], PluginStyleTransform.prototype, "state", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "position", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "transform", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "scaleX", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "scaleY", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "rotate", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "translateX", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "translateY", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "skewX", void 0);
__decorate([
    property()
], PluginStyleTransform.prototype, "skewY", void 0);
__decorate([
    queryAll('collab-ds-input-range-100554')
], PluginStyleTransform.prototype, "columnRuleInputs", void 0);
PluginStyleTransform = __decorate([
    customElement('plugin-style-transform-100554')
], PluginStyleTransform);
export { PluginStyleTransform };
