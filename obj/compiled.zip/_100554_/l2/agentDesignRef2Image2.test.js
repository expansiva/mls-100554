/// <mls shortName="agentDesignRef2Image2" project="100554" enhancement="_blank" folder="" />
export const integrations = [];
export const tests = [];
