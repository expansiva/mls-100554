/// <mls fileReference="_100554_/l2/agentDesignRef2Image2.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
