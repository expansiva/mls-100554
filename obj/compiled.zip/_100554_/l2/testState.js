/// <mls fileReference="_100554_/l2/testState.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { getState, setState, subscribe } from '/_102029_/l2/collabState.js';
//
// Test state handling in Lit. Usage:
//
// <test-state-100554 name="{{ui.testState}}"></test-state-100554>
// Use @propertyDataSource for read/write, or @propertyCompositeDataSource for read-only.
//
// From outside Lit, use the functions: 'setState', 'getState', 'subscribe'.
//
let TestState100554 = class TestState100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.name = 'value default';
    }
    render() {
        return html `
            <p>Hello, ${this.name}!</p>
            <input 
                type="text" 
                .value=${this.name}
                @change=${(e) => this.name = e.target.value}
            />
        `;
    }
};
__decorate([
    propertyDataSource()
], TestState100554.prototype, "name", void 0);
TestState100554 = __decorate([
    customElement('test-state-100554')
], TestState100554);
export { TestState100554 };
(window.parent || window).testState = {
    getName: () => { return getState('ui.testState'); },
    setName: (value) => { return setState('ui.testState', value); }
};
subscribe('*testState;ui.testState', (stateName, stateValue) => { console.log(`subscribe, name=${stateName}, value type=${typeof stateValue}, ${stateValue}`); }); // Removes older subscriptions with the exact same key — use '*' at the beginning to enforce uniqueness
console.log('Test the state functions in the console');
