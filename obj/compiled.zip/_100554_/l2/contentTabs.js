/// <mls fileReference="_100554_/l2/contentTabs.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let ContentTabs = class ContentTabs extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.navItems = [];
        this.contentItems = [];
        this.selectedIndex = 0;
    }
    connectedCallback() {
        super.connectedCallback();
        const div = document.createElement('div');
        div.innerHTML = this.innerHTML;
        this.innerHTML = '';
        this.navItems = Array.from(div.querySelectorAll('nav-item'));
        this.contentItems = Array.from(div.querySelectorAll('content-item'));
    }
    render() {
        return html `
            ${this.renderNav()}
            ${this.renderContent()}
        `;
    }
    renderNav() {
        if (this.navItems.length === 0)
            return '';
        return html `
        <nav class="content-tabs-100554-nav">
            ${this.navItems.map((item, i) => html `
                <nav-item class="content-tabs-100554-tab" ?selected=${this.selectedIndex === i} @click=${() => this.handleSelect(i)} >
                    ${item.innerHTML}
                </nav-item>
            `)}
        </nav>
        `;
    }
    renderContent() {
        if (this.contentItems.length === 0)
            return '';
        return html `
        <section class="content-tabs-100554-section">
        ${this.contentItems.map((content, i) => html `
            <content-item class="content-tabs-100554-content" ?active=${this.selectedIndex === i}>
              ${unsafeHTML(content.innerHTML)}
            </content-item>
          `)}
      </section>
        `;
    }
    handleSelect(index) {
        this.selectedIndex = index;
    }
};
__decorate([
    property({ type: Number, reflect: true })
], ContentTabs.prototype, "selectedIndex", void 0);
ContentTabs = __decorate([
    customElement('content-tabs-100554')
], ContentTabs);
export { ContentTabs };
