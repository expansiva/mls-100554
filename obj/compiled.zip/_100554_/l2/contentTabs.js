/// <mls fileReference="_100554_/l2/contentTabs.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html, unsafeHTML } from "lit";
import { customElement, property } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
let ContentTabs = class extends CollabLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`content-tabs-100554 .content-tabs-100554-nav {
  display: flex;
  gap: 8px;
}
content-tabs-100554 .content-tabs-100554-tab {
  cursor: pointer;
  padding: 6px 12px;
  border: 1px solid var(--bg-primary-color-lighter);
  background-color: var(--bg-primary-color-focus);
  border-bottom: 1px solid var(--bg-primary-color-lighter);
  border-radius: 4px 4px 0 0;
  color: var(--text-primary-color);
}
content-tabs-100554 .content-tabs-100554-tab[selected] {
  background: var(--bg-primary-color-lighter);
  border: 2px solid var(--bg-primary-color-focus);
  border-bottom: none;
  color: var(--text-secondary-color);
  font-weight: 600;
}
content-tabs-100554 .content-tabs-100554-section {
  border: 2px solid var(--bg-primary-color-lighter);
  border-radius: 0 6px 6px 6px;
  padding: 16px;
  margin-top: -2px;
  background: var(--bg-primary-color-lighter);
}
content-tabs-100554 .content-tabs-100554-content {
  display: block;
  border: 1px solid #ccc;
  padding: 12px;
  background-color: var(--bg-primary-color-lighter);
}
content-tabs-100554 .content-tabs-100554-content:not([active]) {
  display: none;
}
`);
    this.navItems = [];
    this.contentItems = [];
    this.selectedIndex = 0;
  }
  connectedCallback() {
    super.connectedCallback();
    const div = document.createElement("div");
    div.innerHTML = this.innerHTML;
    this.innerHTML = "";
    this.navItems = Array.from(div.querySelectorAll("nav-item"));
    this.contentItems = Array.from(div.querySelectorAll("content-item"));
  }
  render() {
    return html`
            ${this.renderNav()}
            ${this.renderContent()}
        `;
  }
  renderNav() {
    if (this.navItems.length === 0) return "";
    return html`
        <nav class="content-tabs-100554-nav">
            ${this.navItems.map(
      (item, i) => html`
                <nav-item class="content-tabs-100554-tab" ?selected=${this.selectedIndex === i} @click=${() => this.handleSelect(i)} >
                    ${item.innerHTML}
                </nav-item>
            `
    )}
        </nav>
        `;
  }
  renderContent() {
    if (this.contentItems.length === 0) return "";
    return html`
        <section class="content-tabs-100554-section">
        ${this.contentItems.map(
      (content, i) => html`
            <content-item class="content-tabs-100554-content" ?active=${this.selectedIndex === i}>
              ${unsafeHTML(content.innerHTML)}
            </content-item>
          `
    )}
      </section>
        `;
  }
  handleSelect(index) {
    this.selectedIndex = index;
  }
};
__decorateClass([
  property({ type: Number, reflect: true })
], ContentTabs.prototype, "selectedIndex", 2);
ContentTabs = __decorateClass([
  customElement("content-tabs-100554")
], ContentTabs);
export {
  ContentTabs
};
