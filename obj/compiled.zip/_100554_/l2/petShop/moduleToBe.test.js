/// <mls fileReference="_100554_/l2/petShop/moduleToBe.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
