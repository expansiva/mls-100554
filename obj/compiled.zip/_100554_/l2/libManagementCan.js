/// <mls fileReference="_100554_/l2/libManagementCan.ts" enhancement="_100554_enhancementLit" />
import { globalState } from "/_100554_/l2/collabState.js";
const activeWatchers = /* @__PURE__ */ new Map();
function initState(path, value) {
  let globalState2 = getState();
  const stateManager = getStateManager();
  if (!path) return;
  const keys = path.split(".");
  if (!globalState2) {
    globalState2 = {};
  }
  keys.forEach((key, index) => {
    if (!globalState2[key]) {
      globalState2[key] = index === keys.length - 1 ? value : {};
    } else if (index === keys.length - 1 && typeof globalState2[key] === "object" && typeof value === "object") {
      globalState2[key] = { ...globalState2[key], ...value };
    }
    globalState2 = globalState2[key];
  });
  function setNestedState(currentPath, data) {
    if (typeof data !== "object" || data === null) {
      stateManager.setState(currentPath, data);
      return;
    }
    if (Array.isArray(data)) {
      stateManager.setState(currentPath, data);
      return;
    }
    Object.entries(data).forEach(([key, val]) => {
      setNestedState(`${currentPath}.${key}`, val);
    });
  }
  setNestedState(path, value);
}
function setState(path, value) {
  const stateManager = getStateManager();
  stateManager.setState(path, value);
  return true;
}
async function waitingState(path, value, options) {
  const stateManager = getStateManager();
  const expected = normalizeValue(value);
  const timeout = options?.timeout ?? 0;
  const retryInterval = options?.retryInterval ?? 100;
  const startTime = Date.now();
  const initialValue = stateManager.getState(path);
  while (true) {
    const current = normalizeValue(stateManager.getState(path));
    if (current === expected) {
      return;
    }
    if (initialValue && initialValue !== current) {
      throw new Error(
        `Value for state invalid: path "${path}", expected "${expected}", got "${current}"`
      );
    }
    if (timeout > 0 && Date.now() - startTime >= timeout) {
      throw new Error(
        `Timeout waiting for state: path "${path}", expected "${expected}", got "${current}"`
      );
    }
    await delay(retryInterval);
  }
}
function waitForNonEmptyState(path, options) {
  const stateManager = getStateManager();
  const retryInterval = options?.retryInterval ?? 100;
  const timeout = options?.timeout;
  return new Promise((resolve, reject) => {
    try {
      const initial = normalizeValue(stateManager.getState(path));
      if (initial !== "" && initial !== void 0 && initial !== null) {
        resolve(String(initial));
        return;
      }
    } catch (e) {
      reject(e);
      return;
    }
    const interval = setInterval(() => {
      try {
        const current = normalizeValue(stateManager.getState(path));
        if (current !== "" && current !== void 0 && current !== null) {
          clearInterval(interval);
          if (timer) clearTimeout(timer);
          resolve(String(current));
        }
      } catch (e) {
        clearInterval(interval);
        if (timer) clearTimeout(timer);
        reject(e);
      }
    }, retryInterval);
    let timer;
    if (typeof timeout === "number") {
      timer = setTimeout(() => {
        clearInterval(interval);
        reject(new Error(`waitForNonEmptyState timeout after ${timeout}ms for path: ${path}`));
      }, timeout);
    }
  });
}
function watchState(path, expectedValue, options) {
  const stateManager = getStateManager();
  const expected = normalizeValue(expectedValue);
  const retryInterval = options?.retryInterval ?? 100;
  if (activeWatchers.has(path)) {
    clearInterval(activeWatchers.get(path));
    activeWatchers.delete(path);
  }
  const interval = setInterval(() => {
    const current = normalizeValue(stateManager.getState(path));
    if (current !== expected) {
      clearInterval(interval);
      activeWatchers.delete(path);
      throw new Error(
        `Watch failed: path "${path}" changed. Expected "${expected}", got "${current}"`
      );
    }
  }, retryInterval);
  activeWatchers.set(path, interval);
}
function unwatchState(path) {
  if (activeWatchers.has(path)) {
    clearInterval(activeWatchers.get(path));
    activeWatchers.delete(path);
  }
}
function clearWatchers() {
  for (const interval of activeWatchers.values()) {
    clearInterval(interval);
  }
  activeWatchers.clear();
}
async function verifyState(path, value, options) {
  try {
    await waitingState(path, value, options);
    return true;
  } catch {
    return false;
  }
}
function normalizeValue(val) {
  return typeof val === "object" ? JSON.stringify(val) : String(val);
}
function delay(ms) {
  return new Promise((res) => setTimeout(res, ms));
}
function getStateManager() {
  const stateManager = globalState.globalStateManagment;
  if (!stateManager) throw new Error("Invalid preview stateManagment");
  return stateManager;
}
function getState() {
  const state = globalState._ica;
  if (!state) throw new Error("Invalid preview stateManagment");
  return state;
}
export {
  clearWatchers,
  initState,
  setState,
  unwatchState,
  verifyState,
  waitForNonEmptyState,
  waitingState,
  watchState
};
