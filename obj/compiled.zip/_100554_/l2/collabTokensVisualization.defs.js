/// <mls fileReference="_100554_/l2/collabTokensVisualization.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/collabTokensVisualization.ts",
        "componentType": "molecule",
        "componentScope": "appFrontEnd",
        "group": "enhancement"
    },
    "references": {
        "imports": [
            {
                "ref": "lit",
                "dependencies": [
                    {
                        "name": "html"
                    },
                    {
                        "name": "css"
                    }
                ]
            },
            {
                "ref": "lit/decorators.js",
                "dependencies": [
                    {
                        "name": "customElement"
                    },
                    {
                        "name": "property"
                    }
                ]
            },
            {
                "ref": "/_102029_/l2/stateLitElement.js",
                "dependencies": [
                    {
                        "name": "StateLitElement"
                    }
                ]
            },
            {
                "ref": "/_102027_/l2/designSystemBase.js",
                "dependencies": [
                    {
                        "name": "getTokens"
                    },
                    {
                        "name": "IDesignSystemTokens"
                    }
                ]
            }
        ]
    },
    "asIs": {
        "semantic": {
            "generalDescription": "Visualization component for design system tokens",
            "businessCapabilities": [],
            "technicalCapabilities": [],
            "implementedFeatures": []
        }
    }
};
