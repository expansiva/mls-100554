/// <mls fileReference="_100554_/l2/wcAuxCommand.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WcAuxCommand100554 = class WcAuxCommand100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`wc-aux-command-100554 {
  font-family: Arial, Helvetica, sans-serif;
}
wc-aux-command-100554 ::-webkit-scrollbar {
  width: 5px;
}
wc-aux-command-100554 ::-webkit-scrollbar-thumb {
  background-color: #888;
  border-radius: 6px;
}
wc-aux-command-100554 ::-webkit-scrollbar-track {
  background-color: #f1f1f1;
}
wc-aux-command-100554 contentauxcommand {
  position: relative;
  display: none;
  flex-direction: column;
  padding: 1rem;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.06);
  border-radius: 5px;
  background-color: var(--surface-bg);
  color: var(--text-default);
  min-width: 150px;
  max-height: 350px;
  width: min-content;
  gap: 0.5rem;
  overflow-y: auto;
}
wc-aux-command-100554 contentauxcommand::before {
  content: '';
  position: absolute;
  top: 0px;
  left: 50%;
  transform: translateX(-50%);
  width: 12px;
  height: 6px;
  background: var(--surface-alt-bg-disabled);
  border: 1px solid #cccccc;
  clip-path: polygon(50% 0, 0 100%, 100% 100%);
  box-sizing: border-box;
}
wc-aux-command-100554 ul {
  display: flex;
  list-style: none;
  flex-direction: column;
  gap: 0.5rem;
  padding: 0px;
}
wc-aux-command-100554 li {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  gap: 0.5rem;
  cursor: pointer;
}
wc-aux-command-100554 li * {
  cursor: pointer;
}
wc-aux-command-100554 li blkicon {
  background-color: #eaeaea;
  border-radius: 5px;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
}
wc-aux-command-100554 li blkicon svg {
  width: 12px;
  fill: var(--text-default);
}
wc-aux-command-100554 li:hover {
  opacity: 0.6;
}
wc-aux-command-100554 li.headergroup:hover {
  opacity: 1;
}
wc-aux-command-100554 li.headergroup {
  color: var(--text-muted-disabled);
  font-weight: bold;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid var(--text-muted-disabled);
}
wc-aux-command-100554.active contentauxcommand {
  display: flex;
}
`);
        this.boundFireKeydown = () => { };
        this.itens = [];
    }
    //--------COMPONENT---------
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        this.boundFireKeydown = this.fireKeydown.bind(this);
        this.setDefinition();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('idElView')) {
            this.setDefinition();
        }
    }
    render() {
        return html ` 
            <contentauxcommand> 
            ${repeat(this.itens, ((item) => item.group), ((i, index) => this.renderGroup(i, index)))}
            </contentauxcommand>
        `;
    }
    renderGroup(item, idx) {
        return html `
            <ul>
                <li class="headergroup">${item.group}</li>
                ${repeat(item.itens, ((item) => item.value), ((i, index) => this.renderItem(i, index)))}
            </ul>
        `;
    }
    renderItem(item, idx) {
        return html `
            <li @click="${this.clickItem}" .item=${item}>
                ${item.icon ? unsafeHTML('<blkicon>' + item.icon + '</blkicon>') : ''}
                <label>${item.label}</label>
            </li>
        `;
    }
    //--------IMPLEMENTS-------
    setDefinition() {
        if (this.elView) {
            this.elView.removeEventListener('keydown', this.boundFireKeydown);
            this.elView = undefined;
        }
        this.elView = window[this.idElView];
        if (this.elView)
            this.elView.addEventListener('keydown', this.boundFireKeydown);
        this.onmouseleave = () => this.mouseLeave();
    }
    mouseLeave() {
        this.classList.remove('active');
    }
    fireKeydown(e) {
        if (e.key !== this.caracter) {
            this.classList.remove('active');
            return;
        }
        this.classList.add('active');
        const position = this.getElementPosition();
        if (!position || !this.elView)
            return;
        this.style.position = 'absolute';
        this.style.top = (position.y + 0) + 'px';
        this.style.left = position.x + 'px';
    }
    getElementPosition() {
        if (!this.elView)
            return undefined;
        const rect = this.elView.getBoundingClientRect();
        return { x: rect.left, y: rect.bottom };
    }
    clickItem(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'li') {
            el = el.closest('li');
        }
        if (!el || !el.item)
            return;
        this.classList.remove('active');
        const event = new CustomEvent('clickitem', {
            detail: el.item,
            bubbles: false,
            composed: false,
        });
        this.dispatchEvent(event);
    }
};
__decorate([
    property()
], WcAuxCommand100554.prototype, "idElView", void 0);
__decorate([
    property()
], WcAuxCommand100554.prototype, "caracter", void 0);
__decorate([
    property()
], WcAuxCommand100554.prototype, "itens", void 0);
WcAuxCommand100554 = __decorate([
    customElement('wc-aux-command-100554')
], WcAuxCommand100554);
export { WcAuxCommand100554 };
