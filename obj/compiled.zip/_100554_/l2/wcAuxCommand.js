/// <mls fileReference="_100554_/l2/wcAuxCommand.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WcAuxCommand100554 = class WcAuxCommand100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.boundFireKeydown = () => { };
        this.itens = [];
    }
    //--------COMPONENT---------
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        this.boundFireKeydown = this.fireKeydown.bind(this);
        this.setDefinition();
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('idElView')) {
            this.setDefinition();
        }
    }
    render() {
        return html ` 
            <contentauxcommand> 
            ${repeat(this.itens, ((item) => item.group), ((i, index) => this.renderGroup(i, index)))}
            </contentauxcommand>
        `;
    }
    renderGroup(item, idx) {
        return html `
            <ul>
                <li class="headergroup">${item.group}</li>
                ${repeat(item.itens, ((item) => item.value), ((i, index) => this.renderItem(i, index)))}
            </ul>
        `;
    }
    renderItem(item, idx) {
        return html `
            <li @click="${this.clickItem}" .item=${item}>
                ${item.icon ? unsafeHTML('<blkicon>' + item.icon + '</blkicon>') : ''}
                <label>${item.label}</label>
            </li>
        `;
    }
    //--------IMPLEMENTS-------
    setDefinition() {
        if (this.elView) {
            this.elView.removeEventListener('keydown', this.boundFireKeydown);
            this.elView = undefined;
        }
        this.elView = window[this.idElView];
        if (this.elView)
            this.elView.addEventListener('keydown', this.boundFireKeydown);
        this.onmouseleave = () => this.mouseLeave();
    }
    mouseLeave() {
        this.classList.remove('active');
    }
    fireKeydown(e) {
        if (e.key !== this.caracter) {
            this.classList.remove('active');
            return;
        }
        this.classList.add('active');
        const position = this.getElementPosition();
        if (!position || !this.elView)
            return;
        this.style.position = 'absolute';
        this.style.top = (position.y + 0) + 'px';
        this.style.left = position.x + 'px';
    }
    getElementPosition() {
        if (!this.elView)
            return undefined;
        const rect = this.elView.getBoundingClientRect();
        return { x: rect.left, y: rect.bottom };
    }
    clickItem(e) {
        let el = e.target;
        if (el.tagName.toLocaleLowerCase() !== 'li') {
            el = el.closest('li');
        }
        if (!el || !el.item)
            return;
        this.classList.remove('active');
        const event = new CustomEvent('clickitem', {
            detail: el.item,
            bubbles: false,
            composed: false,
        });
        this.dispatchEvent(event);
    }
};
__decorate([
    property()
], WcAuxCommand100554.prototype, "idElView", void 0);
__decorate([
    property()
], WcAuxCommand100554.prototype, "caracter", void 0);
__decorate([
    property()
], WcAuxCommand100554.prototype, "itens", void 0);
WcAuxCommand100554 = __decorate([
    customElement('wc-aux-command-100554')
], WcAuxCommand100554);
export { WcAuxCommand100554 };
