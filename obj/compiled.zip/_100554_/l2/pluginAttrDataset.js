/// <mls fileReference="_100554_/l2/pluginAttrDataset.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { property, state } from 'lit/decorators.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
/// **collab_i18n_start**
const message_pt = {
    msg: 'Em desenvolvimento'
};
const message_en = {
    msg: 'In development',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "Config attr dataset",
    getSvg() {
        return svg `
     <svg height="22px" width="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M448 80l0 48c0 44.2-100.3 80-224 80S0 172.2 0 128L0 80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6L448 288c0 44.2-100.3 80-224 80S0 332.2 0 288L0 186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6l0 85.9c0 44.2-100.3 80-224 80S0 476.2 0 432l0-85.9z"/></svg>
    `;
    }
};
export class PluginAttrDataSet extends PluginBaseModule {
    msg = messages['en'];
    expandedPaths = new Set();
    selectedPath = '';
    data = {};
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-attr-dataset-100554{font-family:var(--font-family-primary);padding:1rem;display:block;font-size:13px}plugin-attr-dataset-100554 h3{margin-top:.5rem}plugin-attr-dataset-100554 p{border:1px solid #ddd;border-radius:3px;margin:0px;padding:.3rem}plugin-attr-dataset-100554 button{padding:0 .3rem;background-color:var(--active-color);color:white;border:none;border-radius:2px;cursor:pointer}plugin-attr-dataset-100554 button:hover{opacity:.5}plugin-attr-dataset-100554 .tree{list-style:none;padding-left:15px;border-left:2px solid #ddd;margin-left:8px}plugin-attr-dataset-100554 .item{cursor:pointer;padding:4px;display:flex;align-items:center;position:relative}plugin-attr-dataset-100554 .toggle{width:12px;height:12px;display:inline-flex;justify-content:center;align-items:center;margin-right:8px;font-weight:bold;user-select:none;color:#555}plugin-attr-dataset-100554 .bullet{width:8px;height:8px;background-color:#555;border-radius:50%;display:inline-block}plugin-attr-dataset-100554 .selected{background-color:var(--grey-color-light);border-radius:4px}`);
        this.init();
    }
    //--------COMPONENT------------
    render() {
        // <style>${this.css}</style>
        return html `
            

            <h3>Item:</h3>
            <div style="display:flex; align-items: center; gap: .5rem; margin-bottom:1rem;">
                <p style="width:calc(100% - 45px)">${this.selectedPath || 'Nenhum item selecionado'}</p>
                <button style="width:30px; height: 26px;" @click="${this.setConfig}">ok</button>
            </div>

            <h3>State</h3>
            ${this.renderTree(this.data)}
    
        `;
    }
    renderTree(data, path = '') {
        return html `
            <ul class="tree">
                ${Object.entries(data).map(([key, value]) => { return this.renderTreeItem(path, key, value); })}
            </ul>
        `;
    }
    renderTreeItem(path, key, value) {
        const newPath = path ? `${path}.${key}` : key;
        const isExpandable = typeof value === 'object' && value !== null;
        const isExpanded = this.expandedPaths.has(newPath);
        const vString = isExpandable ? '' : value;
        return html `
            <li>
                <div class="item ${this.selectedPath === newPath ? 'selected' : ''}">
                    <span class="toggle" @click=${() => this.toggleExpand(newPath)}>
                    ${isExpandable ? html `<span class="bullet"></span>` : ''}
                    </span>
                    <span @click=${() => this.selectItem(newPath)}><strong>${key}:</strong> ${vString}</span>
                </div>
                ${isExpanded && isExpandable ? this.renderTree(value, newPath) : ''}
            </li>
        `;
    }
    //-------IMPLEMENTS-------------
    setConfig() {
        const evento = new CustomEvent('setconfig', {
            detail: { vl: `{{${this.selectedPath}}}` },
            bubbles: true,
            composed: true,
        });
        this.dispatchEvent(evento);
    }
    toggleExpand(path) {
        const newPaths = new Set(this.expandedPaths);
        if (newPaths.has(path)) {
            newPaths.delete(path);
        }
        else {
            newPaths.add(path);
        }
        this.expandedPaths = newPaths;
    }
    selectItem(path) {
        path = this.formatPath(path);
        this.selectedPath = path;
    }
    formatPath(path) {
        return path.replace(/(\.\d+)(?=\.|$)/g, match => `[${match.slice(1)}]`);
    }
    init() {
        const state = this.getState();
        this.data = state;
    }
    getState() {
        let preview = window.preview?.iframe;
        if (!preview) {
            preview = top?.preview?.iframe;
        }
        if (!preview) {
            return {};
        }
        return preview.contentWindow?._ica;
    }
    css = `
        plugin-attr-dataset-100554 {
            font-family: Arial, sans-serif;
            padding: 1rem;
            display: block;
            font-size: 13px;
        }

        plugin-attr-dataset-100554 h3{
            margin-top:.5rem
        }

        plugin-attr-dataset-100554 p{
            border:1px solid #ddd;
            border-radius:3px;
            margin:0px;
            padding:.3rem;
        }

        plugin-attr-dataset-100554 button {
            padding: 0 .3rem;
            background-color: #1890FF;
            color: white;
            border: none;
            border-radius: 2px;
            cursor: pointer;

        }

        plugin-attr-dataset-100554    button:hover {
            opacity: .5;

        }

        .tree {
            list-style: none;
            padding-left: 15px;
            border-left: 2px solid #ddd;
            margin-left: 8px;
        }
        .item {
            cursor: pointer;
            padding: 4px;
            display: flex;
            align-items: center;
            position: relative;
        }
        .toggle {
            width: 12px;
            height: 12px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            margin-right: 8px;
            font-weight: bold;
            user-select: none;
            color: #555;
        }
        .bullet {
            width: 8px;
            height: 8px;
            background-color: #555;
            border-radius: 50%;
            display: inline-block;
        }
        .selected {
            background-color: lightblue;
            border-radius: 4px;
        }
    `;
}
__decorate([
    state()
], PluginAttrDataSet.prototype, "expandedPaths", void 0);
__decorate([
    state()
], PluginAttrDataSet.prototype, "selectedPath", void 0);
__decorate([
    property({ type: Object })
], PluginAttrDataSet.prototype, "data", void 0);
if (!customElements.get('plugin-attr-dataset-100554')) {
    customElements.define('plugin-attr-dataset-100554', PluginAttrDataSet);
}
