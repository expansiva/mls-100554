/// <mls fileReference="_100554_/l2/collabOrgHome.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando organização…',
    again: 'Tentar novamente',
    error: 'Erro desconhecido',
    projects: 'Projetos',
    users: 'Usuários',
    teams: 'Times',
};
const message_en = {
    loading: 'Loading organization…',
    again: 'Try again',
    error: 'Unknown error',
    projects: 'Projects',
    users: 'Users',
    teams: 'Teams',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
const MOCK_ORG_DATA = {
    name: 'Collab Codes',
    description: 'Plataforma colaborativa de desenvolvimento low-code.',
    totalProjects: 42,
    totalUsers: 18,
    totalTeams: 5,
};
let CollabOrgHome = class CollabOrgHome extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-org-home-100554 {
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  color: var(--text-default);
  padding-top: 1rem;
}
collab-org-home-100554 .state-loading,
collab-org-home-100554 .state-error {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 48px 24px;
  color: var(--text-muted);
  font-size: var(--font-size-16);
}
collab-org-home-100554 .state-error {
  flex-direction: column;
  color: var(--status-error-text);
}
collab-org-home-100554 .state-error .error-icon {
  font-size: var(--font-size-24);
}
collab-org-home-100554 .state-error button {
  margin-top: 8px;
  padding: 6px 16px;
  background-color: var(--button-primary-bg);
  color: #ffffff;
  border: none;
  border-radius: 4px;
  font-size: var(--font-size-16);
  font-family: var(--font-family-primary);
  cursor: pointer;
}
collab-org-home-100554 .state-error button:hover {
  background-color: var(--button-primary-bg-hover);
}
collab-org-home-100554 .state-error button:focus {
  background-color: var(--button-primary-bg-focus);
  outline: none;
}
collab-org-home-100554 .spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid var(--border-subtle);
  border-top-color: var(--selected-border);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-org-home-100554 .org-card {
  display: flex;
  flex-direction: column;
  gap: 32px;
  max-width: 680px;
}
collab-org-home-100554 .org-header {
  display: flex;
  justify-content: center;
  flex-direction: column;
  gap: 8px;
}
collab-org-home-100554 .org-name {
  margin: 0;
  font-size: var(--font-size-24);
  font-family: var(--font-family-primary);
  color: var(--text-strong);
  display: flex;
  justify-content: center;
  font-weight: 700;
}
collab-org-home-100554 .org-description {
  display: flex;
  justify-content: center;
  margin: 0;
  font-size: var(--font-size-16);
  color: var(--text-muted);
}
collab-org-home-100554 .org-counters {
  display: flex;
  gap: 24px;
  flex-wrap: wrap;
}
collab-org-home-100554 .counter {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  background-color: var(--surface-bg);
  border: 1px solid var(--border-default);
  border-radius: 8px;
  padding: 20px 32px;
  min-width: 120px;
}
collab-org-home-100554 .counter-value {
  font-size: var(--font-size-24);
  font-weight: 700;
  color: var(--selected-text);
}
collab-org-home-100554 .counter-label {
  font-size: var(--font-size-12);
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.05em;
}
`);
        this.msg = messages['en'];
        this.project = 0;
        this._loading = false;
        this._error = '';
        this._data = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this._fetchOrg();
    }
    async _fetchOrg() {
        this._loading = true;
        this._error = '';
        this._data = null;
        this.requestUpdate();
        try {
            const idxOrg = mls.l5.getProjectOrgIndex(this.project) || -1;
            const orgName = mls.l5.getOrgsName()[idxOrg];
            const lastOrg = mls.stor.orgs[orgName];
            if (!lastOrg) {
                this._error = 'Not found organization';
                return;
            }
            this._data = {
                name: orgName,
                description: lastOrg.sett.description,
                totalProjects: lastOrg.sett.projects.length,
                totalUsers: lastOrg.sett.users.length,
                totalTeams: lastOrg.sett.teams.length,
            };
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : this.msg.error;
        }
        finally {
            this._loading = false;
            this.requestUpdate();
        }
    }
    _renderLoading() {
        return html `
            <div class="state-loading">
                <span class="spinner"></span>
                <span>${this.msg.loading}</span>
            </div>
        `;
    }
    _renderError() {
        return html `
            <div class="state-error">
                <span class="error-icon">⚠</span>
                <span>${this._error}</span>
                <button @click="${() => this._fetchOrg()}">${this.msg.again}</button>
            </div>
        `;
    }
    _renderData(data) {
        return html `
            <div class="org-card">
                <div class="org-header">
                    <h1 class="org-name">${data.name}</h1>
                    <p class="org-description">${data.description || 'no description'}</p>
                </div>
                <div class="org-counters">
                    <div class="counter">
                        <span class="counter-value">${data.totalProjects}</span>
                        <span class="counter-label">${this.msg.projects}</span>
                    </div>
                    <div class="counter">
                        <span class="counter-value">${data.totalUsers}</span>
                        <span class="counter-label">${this.msg.users}</span>
                    </div>
                    <div class="counter">
                        <span class="counter-value">${data.totalTeams}</span>
                        <span class="counter-label">${this.msg.teams}</span>
                    </div>
                </div>
            </div>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this._loading)
            return this._renderLoading();
        if (this._error)
            return this._renderError();
        if (this._data)
            return this._renderData(this._data);
        return html ``;
    }
};
__decorate([
    property({ type: Number })
], CollabOrgHome.prototype, "project", void 0);
CollabOrgHome = __decorate([
    customElement('collab-org-home-100554')
], CollabOrgHome);
export { CollabOrgHome };
