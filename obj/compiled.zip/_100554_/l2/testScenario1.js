/// <mls fileReference="_100554_/l2/testScenario1.ts" enhancement="_100554_/l2/enhancementLit" />
export function _100554_testScenario1_getScenaryDetails() {
    const html = document.createElement('wc-input-text-100554');
    return {
        description: 'Cenário 1',
        html
    };
}
