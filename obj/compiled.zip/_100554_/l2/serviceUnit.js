/// <mls fileReference="_100554_/l2/serviceUnit.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query, queryAll } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { getAllWebComponentsInSource } from '/_102027_/l2/libCompile.js';
import { convertTagToFileName, convertFileNameToTag } from '/_102027_/l2/utils.js';
import { loadPluginProject } from '/_102027_/l2/libCommom.js';
import('/_100554_/l2/collabPanel.js');
import { getPath } from '/_102027_/l2/utils.js';
/// **collab_i18n_start**
const message_pt = {
    installPlugin: 'Explore e adicione novos plug-ins',
};
const message_en = {
    installPlugin: 'Explore and add new plugins',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end** 
let ServiceUnit = class ServiceUnit extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-unit-100554 {
  display: block;
  font-family: var(--font-family-primary);
  box-sizing: border-box;
  font-size: var(--font-size-16);
  height: 100%;
  overflow: auto;
  padding-left: 10px;
}
`);
        this.baseProject = 100554;
        this.msg = messages['en'];
        this.activeTab = 'Explore';
        this.explories = [];
        this.myData = {};
        //---------SERVICE-------------
        this.details = {
            icon: '&#xf5da',
            state: 'foreground',
            position: 'left',
            tooltip: 'Unit',
            visible: true,
            widget: '_100554_serviceUnit',
            level: [5]
        };
        this.menu = {
            title: '',
            main: {
                opAboutThis: 'About this content',
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [{ text: 'Explore', icon: 'e521' }]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.lastLevel = 0;
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        this.activeTab = ETabs[index];
    }
    onServiceClick(visible, reinit, el) {
        if (this.visible && this.level !== this.lastLevel) {
            this.lastLevel = this.level;
        }
        if (this.visible) {
            this.refreshPlugins();
        }
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'nothing selected';
        switch (this.activeTab) {
            case 'Explore':
                name = this.explories[0].widget;
                break;
            default:
                name = 'nothing selected';
        }
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
    	

        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    //-------COMPONENT-----------
    async firstUpdated() {
        this.setMyData();
        await this.getExploreData();
        if (this.activeTab === 'Explore') {
            await this.updateComplete;
            if (this.firstDetails)
                this.firstDetails.click();
        }
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('activeTab') && !!changedProperties.get('activeTab')) {
            if (this.menu.setTabActive)
                this.menu.setTabActive(ETabs[this.activeTab]);
            if (this.activeTab === 'Explore') {
                await this.updateComplete;
                if (this.firstDetails)
                    this.firstDetails.click();
            }
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'Explore':
                return this.renderExplore();
            default:
                return html ``;
        }
    }
    renderExplore() {
        if (this.explories.length === 1) {
            return html `<div class="details" .data=${this.explories[0]} @click=${this.handleDetailExplorieClick}><div class="plugin-container"></div></div>`;
        }
        return html `<div>
                ${this.explories.map((explorie, index) => {
            return html `
                <details class="details" ?open=${index === 0} .data=${explorie} @click=${this.handleDetailExplorieClick}>
                    <summary>${explorie.category}</summary>
                    <div class="plugin-container"></div>
                </details>
            `;
        })}</div>`;
    }
    renderShowCase() {
        this.fireEventClose('In development: Details showcase');
        const project = mls.actualProject;
        if (!project)
            return '<div>No project selected</div<';
        const keyToFile = mls.stor.getKeyToFiles(project, 2, 'project', '', '.html');
        const file = mls.stor.files[keyToFile];
        if (!file)
            return html `<div>File 'project.html' dont's exist in selected project</div>`;
        this.loadHelpPage('project', project || 0);
        return html `<div style="overflow:auto;height:100%;" id="projectDiv"></div>`;
    }
    //----------IMPLEMENTATION----------
    refreshPlugins() {
        this.allContainers?.forEach((item) => {
            const plg = item.children[0];
            if (plg) {
                plg.setAttribute('mode', 'list');
            }
        });
    }
    fireEventClose(msg) {
        mls.events.fire(5, 'PluginDetails', JSON.stringify({
            htmlText: `<div>${msg}</div>`
        }), 0);
    }
    async handleDetailExplorieClick(e) {
        const target = e.target;
        const details = target.closest('.details');
        if (!details)
            return;
        const div = details.querySelector('div');
        if (!div || div.childElementCount > 0)
            return;
        const info = getPath(details.data.widget);
        if (!info)
            throw new Error('[handleDetailExplorieClick] Not found path:' + details.data.widget);
        const { folder, project, shortName } = info;
        await import(`/_${project}_/l2/${shortName}`);
        const pluginTag = convertFileNameToTag({ project, shortName, folder });
        const pluginEl = document.createElement(pluginTag);
        pluginEl.setAttribute('autoprepare', '');
        pluginEl.setAttribute('level', this.level.toString());
        pluginEl.setAttribute('position', this.position.toString());
        pluginEl.service = this;
        div.appendChild(pluginEl);
    }
    async getExploreData() {
        let project = mls.actualProject;
        this.explories = await loadPluginProject(project || 0, 'l5Explore');
    }
    async loadHelpPage(shortName, project) {
        const keyFile = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (storFile) {
            const content = await storFile.getContent();
            if (this.projectDiv && typeof content === 'string') {
                const allWcs = getAllWebComponentsInSource(content);
                console.info(allWcs);
                allWcs.forEach((wc) => {
                    const info = convertTagToFileName(wc);
                    if (info) {
                        const script = document.createElement('script');
                        script.type = 'module';
                        script.id = `_${info.project}_${info.shortName}`;
                        script.src = (`/_${info.project}_${info.shortName}`);
                        this.projectDiv?.appendChild(script);
                    }
                });
                const div = document.createElement('div');
                div.innerHTML = content;
                div.children[0].setAttribute('level', '7');
                this.projectDiv.innerHTML = '';
                this.projectDiv.appendChild(div);
            }
        }
    }
    async setMyData() {
        const prj = mls.actualProject;
        let array = await loadPluginProject(prj || 0, 'l5Project', false);
        array.forEach((item) => {
            const cat = item.category;
            if (!this.myData[cat])
                this.myData[cat] = [item];
            else
                this.myData[cat].push(item);
        });
        this.requestUpdate();
    }
};
__decorate([
    property()
], ServiceUnit.prototype, "activeTab", void 0);
__decorate([
    property({ type: Array })
], ServiceUnit.prototype, "explories", void 0);
__decorate([
    query('#projectDiv')
], ServiceUnit.prototype, "projectDiv", void 0);
__decorate([
    query('.details')
], ServiceUnit.prototype, "firstDetails", void 0);
__decorate([
    queryAll('.plugin-container')
], ServiceUnit.prototype, "allContainers", void 0);
ServiceUnit = __decorate([
    customElement('service-unit-100554')
], ServiceUnit);
export { ServiceUnit };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["Explore"] = 0] = "Explore";
    ETabs[ETabs["ShowCase"] = 1] = "ShowCase";
})(ETabs || (ETabs = {}));
