const asis = {
  "meta": {
    "fileReference": "_100554_/l2/collabStartL0.ts",
    "componentType": "molecule",
    "componentScope": "appFrontEnd",
    "languages": [
      "en",
      "pt"
    ],
    "group": "enhancement"
  },
  "references": {
    "imports": [
      {
        "ref": "lit",
        "dependencies": [
          {
            "name": "html",
            "type": "function"
          }
        ]
      },
      {
        "ref": "lit/decorators.js",
        "dependencies": [
          {
            "name": "customElement",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/stateLitElement.js",
        "dependencies": [
          {
            "name": "StateLitElement",
            "type": "class"
          }
        ]
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Module L0 - User: Description and Features",
      "businessCapabilities": [
        "Visualizar e ver projetos: permite ao usu\xE1rio uma vis\xE3o geral e detalhada dos projetos em que est\xE1 envolvido, facilitando o acompanhamento do progresso",
        "Dar autoridades a outros: oferece a op\xE7\xE3o de conceder diferentes n\xEDveis de autoridade a outros membros da equipe, como administrador, editor ou visualizador",
        "Escolher o plano atual: permite ao usu\xE1rio selecionar o plano de assinatura mais adequado \xE0s suas necessidades e, se necess\xE1rio, incluir informa\xE7\xF5es de faturamento.",
        "Selecionar prefer\xEAncias visuais: oferece op\xE7\xF5es para personalizar a apar\xEAncia da ferramenta, como temas, layout e configura\xE7\xF5es de exibi\xE7\xE3o.",
        "View and monitor projects: allows the user to have an overview and detailed insight into the projects they are involved in, facilitating progress tracking.",
        "Grant authorities to others: offers the option to assign different levels of authority to other team members, such as administrator, editor, or viewer.",
        "Select the current plan: enables the user to choose the subscription plan that best suits their needs and, if necessary, include billing information.",
        "Choose visual preferences: provides options to customize the tool\u2019s appearance, such as themes, layout, and display settings."
      ],
      "technicalCapabilities": [
        "Renders HTML with Lit"
      ],
      "implementedFeatures": [
        "O usu\xE1rio acessa o m\xF3dulo L0 e tem uma vis\xE3o geral dos projetos em que est\xE1 envolvido.",
        "Se necess\xE1rio, concede autoridades a outros membros da equipe para facilitar a colabora\xE7\xE3o.",
        "Escolhe o plano de assinatura que melhor atende \xE0s suas necessidades e inclui informa\xE7\xF5es de faturamento, se aplic\xE1vel..",
        "Personaliza a interface da ferramenta de acordo com suas prefer\xEAncias visuais para uma experi\xEAncia de usu\xE1rio mais agrad\xE1vel.",
        "The user accesses the L0 module and gets an overview of the projects they are involved in.",
        "If needed, grants authority to other team members to facilitate collaboration.",
        "Selects the subscription plan that best meets their needs and includes billing information, if applicable.",
        "Customizes the tool\u2019s interface according to their visual preferences for a more pleasant user experience."
      ]
    }
  }
};
export {
  asis
};
