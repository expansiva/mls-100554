/// <mls fileReference="_100554_/l2/collabInputSearch.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    search: "Procurar...",
};
const message_en = {
    search: 'Search...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabInputSearch = class CollabInputSearch extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.placeholder = '';
        this.value = '';
        this.focused = false;
    }
    firstUpdated() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.placeholder)
            this.placeholder = this.msg.search;
    }
    render() {
        const hasValue = this.value.length > 0;
        const wrapperClass = [
            'wrapper',
            this.focused ? 'focused' : '',
            hasValue ? 'has-value' : '',
        ].filter(Boolean).join(' ');
        return html `
            <div class=${wrapperClass} @click=${() => this.shadowRoot?.querySelector('input')?.focus()}>

                <!-- Search icon -->
                <span class="icon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2.2"
                    stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="7"/>
                    <line x1="16.5" y1="16.5" x2="22" y2="22"/>
                </svg>
                </span>

                <!-- Text input -->
                <input
                type="text"
                .value=${this.value}
                placeholder=${this.placeholder}
                aria-label="Search"
                @input=${this._onInput}
                @focus=${this._onFocus}
                @blur=${this._onBlur}
                @keydown=${this._onKeyDown}
                />

                <!-- Clear button -->
                ${hasValue ? html `
                <button class="clear-btn" @click=${this._clear} aria-label="Clear search" title="Clear">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2.5"
                        stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6"  y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
                ` : ''}

            </div>
        `;
    }
    _onInput(e) {
        this.value = e.target.value;
        this.dispatchEvent(new CustomEvent('search-input', { detail: this.value, bubbles: true, composed: true }));
    }
    _onFocus() { this.focused = true; }
    _onBlur() { this.focused = false; }
    _clear() {
        this.value = '';
        this.shadowRoot?.querySelector('input')?.focus();
        this.dispatchEvent(new CustomEvent('input', { detail: '', bubbles: true, composed: true }));
        this.dispatchEvent(new CustomEvent('search-clear', { bubbles: true, composed: true }));
    }
    _onKeyDown(e) {
        if (e.key === 'Escape')
            this._clear();
    }
};
__decorate([
    property({ type: String })
], CollabInputSearch.prototype, "placeholder", void 0);
__decorate([
    property({ type: String })
], CollabInputSearch.prototype, "value", void 0);
__decorate([
    state()
], CollabInputSearch.prototype, "focused", void 0);
CollabInputSearch = __decorate([
    customElement('collab-input-search-100554')
], CollabInputSearch);
export { CollabInputSearch };
