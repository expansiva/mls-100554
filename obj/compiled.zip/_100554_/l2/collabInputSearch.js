/// <mls fileReference="_100554_/l2/collabInputSearch.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    search: "Procurar...",
};
const message_en = {
    search: 'Search...',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CollabInputSearch = class CollabInputSearch extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-input-search-100554 {
  display: inline-flex;
  font-family: system-ui, sans-serif;
}
collab-input-search-100554 .wrapper {
  display: flex;
  align-items: center;
  gap: 6px;
  background: var(--bg-primary-color);
  border: 1.5px solid var(--bg-primary-color-darker-disabled);
  border-radius: 4px;
  padding: 6px 10px;
  cursor: text;
  transition: width 260ms cubic-bezier(0.4, 0, 0.2, 1), border-color 200ms, background 200ms, box-shadow 200ms;
  width: 160px;
  box-sizing: border-box;
  overflow: hidden;
}
collab-input-search-100554 .wrapper.focused {
  width: 300px;
  background: var(--bg-primary-color-darker);
  border-color: var(--active-color);
  box-shadow: 0 0 0 3px rgba(79, 142, 247, 0.15);
}
collab-input-search-100554 .wrapper.has-value {
  width: 300px;
}
collab-input-search-100554 .icon {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  color: var(--text-primary-color);
  transition: color 200ms;
}
collab-input-search-100554 .wrapper.focused .icon,
collab-input-search-100554 .wrapper.has-value .icon {
  color: var(--active-color);
}
collab-input-search-100554 input {
  border: none;
  outline: none;
  background: transparent;
  font-size: 14px;
  color: var(--text-primary-color);
  flex: 1;
  min-width: 0;
  caret-color: var(--active-color);
}
collab-input-search-100554 input::placeholder {
  color: #9aa0a6;
}
collab-input-search-100554 .clear-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  background: none;
  border: none;
  padding: 0;
  cursor: pointer;
  color: #9aa0a6;
  border-radius: 50%;
  width: 18px;
  height: 18px;
  transition: color 180ms, background 180ms;
}
collab-input-search-100554 .clear-btn:hover {
  color: #202124;
  background: #e8eaed;
}
`);
        this.msg = messages['en'];
        this.placeholder = '';
        this.value = '';
        this.focused = false;
    }
    firstUpdated() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.placeholder)
            this.placeholder = this.msg.search;
    }
    render() {
        const hasValue = this.value.length > 0;
        const wrapperClass = [
            'wrapper',
            this.focused ? 'focused' : '',
            hasValue ? 'has-value' : '',
        ].filter(Boolean).join(' ');
        return html `
            <div class=${wrapperClass} @click=${() => this.shadowRoot?.querySelector('input')?.focus()}>

                <!-- Search icon -->
                <span class="icon" aria-hidden="true">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                    stroke="currentColor" stroke-width="2.2"
                    stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="7"/>
                    <line x1="16.5" y1="16.5" x2="22" y2="22"/>
                </svg>
                </span>

                <!-- Text input -->
                <input
                type="text"
                .value=${this.value}
                placeholder=${this.placeholder}
                aria-label="Search"
                @input=${this._onInput}
                @focus=${this._onFocus}
                @blur=${this._onBlur}
                @keydown=${this._onKeyDown}
                />

                <!-- Clear button -->
                ${hasValue ? html `
                <button class="clear-btn" @click=${this._clear} aria-label="Clear search" title="Clear">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2.5"
                        stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"/>
                    <line x1="6"  y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
                ` : ''}

            </div>
        `;
    }
    _onInput(e) {
        this.value = e.target.value;
        this.dispatchEvent(new CustomEvent('search-input', { detail: this.value, bubbles: true, composed: true }));
    }
    _onFocus() { this.focused = true; }
    _onBlur() { this.focused = false; }
    _clear() {
        this.value = '';
        this.shadowRoot?.querySelector('input')?.focus();
        this.dispatchEvent(new CustomEvent('input', { detail: '', bubbles: true, composed: true }));
        this.dispatchEvent(new CustomEvent('search-clear', { bubbles: true, composed: true }));
    }
    _onKeyDown(e) {
        if (e.key === 'Escape')
            this._clear();
    }
};
__decorate([
    property({ type: String })
], CollabInputSearch.prototype, "placeholder", void 0);
__decorate([
    property({ type: String })
], CollabInputSearch.prototype, "value", void 0);
__decorate([
    state()
], CollabInputSearch.prototype, "focused", void 0);
CollabInputSearch = __decorate([
    customElement('collab-input-search-100554')
], CollabInputSearch);
export { CollabInputSearch };
