/// <mls fileReference="_100554_/l2/agentCompareAgents3.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
export function createAgent() {
    return {
        agentName: "agentCompareAgents3",
        agentProject: 100554,
        agentFolder: "",
        agentDescription: "New agent",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    if (!userPrompt || userPrompt.length < 5)
        throw new Error('invalid prompt');
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: [{
                    type: "system",
                    content: system1,
                }, {
                    type: "human",
                    content: context.message.content
                }],
            taskTitle: `Test 1`,
            threadId: context.message.threadId,
            userMessage: context.message.content,
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`(${agent.agentName})[beforePromptStep] args invalid`);
    let questionHumun = context.task?.iaCompressed?.longMemory['promptCompare'] || 'Which agent has the best answer?';
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: 1,
        systemPrompt: system1.replace('{{toCompare}}', args),
        humanPrompt: questionHumun
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    let intents = [];
    const output = payload.result;
    intents = await processOutput(context, output);
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...intents, updateStatus];
}
async function processOutput(context, output) {
    return [];
}
const system1 = `
<!-- modelType: code-->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

You are an objective evaluator comparing outputs from multiple AI agents.

Your task is to score the provided result from 0 to 100 based on the criteria below.

Evaluation Criteria:
1. Correctness – Does it solve the requested task correctly?
2. Completeness – Did it cover all requested requirements?
3. Quality – Is the output well-structured, maintainable, and clear?
4. Efficiency – Was the solution reasonably efficient / concise?
5. Robustness – Does it handle edge cases / avoid obvious flaws?

Instructions:
- Score each criterion from 0 to 100.
- Provide a short justification for each score.
- Provide a final weighted average score.
- Be strict and impartial.
- Focus only on the output quality, not style preferences unless relevant.

## Infos to Compare

{{toCompare}}

## Output format
You must return the object strictly as JSON
export type Output =
    {
        type: "flexible";
        result: Assessment;
    }

export type Assessment = {
    correctness: number,
    completeness: number,
    quality: number,
    efficiency: number,
    robustness: number,
    finalScore: number,
    summary: string //"short explanation"
}

`;
//#endregion 
