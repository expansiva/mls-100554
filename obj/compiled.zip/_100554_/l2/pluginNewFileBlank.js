/// <mls shortName="pluginNewFileBlank" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
import { getMessageKey } from "/_100554_/l2/collabLitElement.js";
import { propertyDataSource } from '/_100554_/l2/collabDecorators.js';
import { createNewFile } from "/_100554_/l2/pluginNewFileBase.js";
import '/_100554_/l2/widgetTextCode.js';
/// **collab_i18n_start**
const message_pt = {
    title: "Criar um arquivo em branco.",
    desc: "Criar um arquivo em branco em lit 3.",
    project: "Projeto",
    shortName: "Nome",
    header: "Arquivo em branco",
    btnCreate: 'Criar arquivo',
    loading: 'Criando arquivo...',
    error: 'Nome do arquivo em branco ou invalido'
};
const message_en = {
    title: "Create a blank file.",
    desc: "Create a blank file in Lit 3.",
    project: "Project",
    shortName: "ShortName",
    header: "Blank File",
    btnCreate: 'Create file',
    loading: 'Creating File...',
    error: 'Blank or invalid file name'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
let msg = messages[lang];
export const details = {
    title: msg.title,
    description: msg.desc,
    tags: ["lit", "html", "component"],
};
let PluginNewFileBlank = class PluginNewFileBlank extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-new-file-blank-100554{width:100%;display:block;font-family:var(--font-family-primary);font-size:var(--font-size-16);font-weight:var(--font-weight-normal);line-height:1.5;color:var(--text-primary-color);background-color:var(--bg-primary-color)}plugin-new-file-blank-100554 widget-text-code-100554{font-size:var(--font-size-12)}plugin-new-file-blank-100554 button{background-color:var(--active-color);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:#fff;cursor:pointer}plugin-new-file-blank-100554 button:hover{background-color:var(--active-color-hover)}`);
        this.position = 'left';
        this.loading = false;
        this.service = this.closest('service-detail-100554');
        this.template = ``;
        this.enhancement = `_100554_enhancementLit`;
        this.groupName = `other`;
    }
    getTemplate() {
        const group = this.groupName && this.groupName != 'other' ? ` groupName="${this.groupName}"` : '';
        const folder = this.folder ? ` folder="${this.folder}"` : '';
        const enhancement = '_blank';
        return `/// <mls shortName="${this.shortName}" project="${this.project}" enhancement="${enhancement}"${group}${folder} />\n${this.template}\n`;
        ;
    }
    async handleAddFile() {
        if (!this.project || !this.shortName) {
            this.service.setError(msg.error);
            return;
        }
        ;
        this.loading = true;
        try {
            await createNewFile({
                project: this.project,
                position: this.position,
                shortName: this.shortName,
                folder: this.folder,
                enhancement: this.enhancement,
                sourceTS: this.getTemplate(),
                openPreview: true
            });
        }
        catch (e) {
            this.loading = false;
        }
    }
    render() {
        return html `
            ${this.loading ?
            html `<div>${msg.loading}</div>`
            :
                html `   
                <div>
                    <h2>${msg.header} </h2>
                    <hr>
                    <div>
                        <span> <b>${msg.project}:</b> ${this.project}</span>
                        <span> <b>${msg.shortName}:</b> ${this.shortName}</span>    
                    </div>
                    <div style="margin-top:1rem;">
                        <button @click=${this.handleAddFile}>${msg.btnCreate}</button>
                    </div>
                    <widget-text-code-100554 language="typescript" text="${this.getTemplate()}"></widget-text-code-100554>
                </div>`}
        `;
    }
};
__decorate([
    propertyDataSource()
], PluginNewFileBlank.prototype, "shortName", void 0);
__decorate([
    propertyDataSource()
], PluginNewFileBlank.prototype, "folder", void 0);
__decorate([
    propertyDataSource({ attribute: true })
], PluginNewFileBlank.prototype, "project", void 0);
__decorate([
    property()
], PluginNewFileBlank.prototype, "position", void 0);
__decorate([
    property()
], PluginNewFileBlank.prototype, "loading", void 0);
PluginNewFileBlank = __decorate([
    customElement('plugin-new-file-blank-100554')
], PluginNewFileBlank);
export { PluginNewFileBlank };
