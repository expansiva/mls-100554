/// <mls fileReference="_100554_/l2/baseDriverTest.ts" enhancement="_blank" />
export class DriverIOBase {
}
