/// <mls fileReference="_100554_/l2/driverGithub.ts" enhancement="_100554_/l2/enhancementLit" />
import * as dL from '/_100554_/l2/driverLib.js';
let mKey = "";
export function init(initString) {
    mKey = atob(initString);
}
export class DriverGitHub extends mls.stor.others.DriverIOBase {
    constructor() {
        super();
        this.shortName = 'github';
        this.project = 100554;
        this.driverVersion = '1.0.0.3';
        this.lastSaveInfo = { commits: 0, skippedDeletions: [] };
        this.getContents = (project, fileInfos) => {
            return this._getContents(project, fileInfos);
        };
        this.setContents = (project, fileInfos, comments) => {
            return this._setContents(project, fileInfos, comments);
        };
        if (mls.istrace)
            console.info('gitDriver: ' + this.driverVersion);
        mKey = localStorage.getItem('keyGitHub') || mKey;
    }
    loadFilesInfo(project) {
        return this._loadFilesInfo(project);
    }
    getHistory(fileInfo) {
        return this._getHistory(fileInfo);
    }
    getHistoryContent(fileInfo, ref) {
        return this._getHistoryContent(fileInfo, ref);
    }
    getUrl(file) {
        return this._getUrl(file);
    }
    getVersionFromFiles(options) {
        return this.getVersionFromFilesIO(options);
    }
    checkBranchExistence(owner, repo, branchName) {
        throw this.checkBranchExistenceIO(owner, repo, branchName);
    }
    createNewBranch(option) {
        return this.createNewBranchIO(option);
    }
    createPullRequest(options) {
        return this.createPullRequestIO(options);
    }
    reviewPullRequest(options) {
        return this.reviewPullRequestIO(options);
    }
    listPullRequests(owner, repo) {
        return this.listPullRequestsIO(owner, repo);
    }
    listForks(owner, repo) {
        return this.listForksIO(owner, repo);
    }
    listBranches(owner, repo) {
        return this.listBranchesIO(owner, repo);
    }
    getUserInfo() {
        return this.getUserInfoIO();
    }
    getOrganizations(login) {
        return this.getOrganizationsIO(login);
    }
    createRepository(login, repo, organization, description, visibility) {
        return this.createRepositoryIO(login, repo, organization, description, visibility);
    }
    deleteRepository(repo, organization) {
        return this.deleteRepositoryIO(repo, organization);
    }
    createFork(login, repoOri, orgOri, orgDest) {
        return this.createForkIO(login, repoOri, orgOri, orgDest);
    }
    renameRepository(owner, repo, newName) {
        return this.renameRepositoryIO(owner, repo, newName);
    }
    createFileInRepo(owner, repo, path, content) {
        return this.createFileInRepoIO(owner, repo, path, content);
    }
    deleteFileInRepo(owner, repo, path) {
        throw new Error('Not implemented');
    }
    changeVisibility(owner, repo, visibility) {
        return this.changeVisibilityIO(owner, repo, visibility);
    }
    verifyRepositoryNew(owner, repo, user) {
        return this.verifyRepositoryNewIO(owner, repo, user);
    }
    verifyPermission(owner, repo, login) {
        return this.verifyPermissionIO(owner, repo, login);
    }
    setPermissionAction(owner, repo, login) {
        return this.setPermissionActionIO(owner, repo, login);
    }
    addVariable2(owner, repo, name, value) {
        return this.addVariableIO(owner, repo, name, value);
    }
    addVariable(name, value) {
        throw new Error('Not implemented');
        //return this.addVariableIO(name, value);
    }
    updateVariable(name, value) {
        return this.updateVariableIO(name, value);
    }
    listVariables() {
        return this.listVariablesIO();
    }
    delVariable(name) {
        return this.delVariableIO(name);
    }
    checkFork(ownerOrigin, repoOrigin, login) {
        return this.checkForkIO(ownerOrigin, repoOrigin, login);
    }
    syncFork(options) {
        return this.syncForkIO(options);
    }
    //---------IMPLEMENTS-----------
    _getUrl(file) {
        const { branch, owner, repo } = dL.getMyKeysBranch(file.project);
        if (!branch || !owner || !repo)
            return 'https://github.com/';
        let url = `https://github.com/${owner}/${repo}/blob/${branch}/l2/${file.shortName}${file.extension}`;
        if (file.folder)
            url = `https://github.com/${owner}/${repo}/blob/${branch}/l2/${file.folder}/${file.shortName}${file.extension}`;
        return url;
    }
    async _getContents(project, fileInfos) {
        try {
            return this.getContents2(fileInfos, []);
        }
        catch (e) {
            throw new Error('_getContents:' + e.message);
        }
    }
    async getContents2(fileInfos, father) {
        if (fileInfos.length <= 0)
            return father;
        const r = await this.getContent3(fileInfos[0]);
        father.push({
            fileInfo: fileInfos[0],
            content: r
        });
        if (fileInfos.length >= 1) {
            fileInfos.splice(0, 1);
            father = await this.getContents2(fileInfos, father);
        }
        return father;
    }
    getContent3(fileInfo) {
        return new Promise(async (resolve, reject) => {
            try {
                const auxLevel = fileInfo.level === 0 ? '' : `l${fileInfo.level}/`;
                const aux = fileInfo.folder === '' || fileInfo.folder.endsWith('/') ? '' : '/';
                const ext = fileInfo.extension ? fileInfo.extension : '.ts';
                const fileName = auxLevel + fileInfo.folder.replace(/\\/g, '/') + aux + fileInfo.shortName + ext;
                let ret = '';
                if (['.html', '.ts', '.test.ts', '.defs.ts', '.css', '.txt', '.json', '.md', '.js', '.less'].includes(ext)) {
                    ret = await this.getFilesIO(fileInfo.project, fileName);
                }
                else {
                    ret = await this.getFilesRestIO(fileInfo.project, fileInfo.versionRef, fileInfo.extension);
                }
                resolve(ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    async _setContents(project, fileInfos, comments) {
        const gen = this.processFiles(project, fileInfos, comments || "update git");
        try {
            for await (const event of gen) {
                window.messageSave = event;
            }
            return true;
        }
        catch (e) {
            throw new Error(e.message);
        }
    }
    async _setContentsOld(project, fileInfos, comments) {
        const ret = await this.processFiles(project, fileInfos, comments || 'update git');
        return true;
        /*try {
            
            return this.setContents2(fileInfos, comments);

        } catch (e: any) {

            throw new Error(e.message);

        }*/
    }
    async setContents2(fileInfos, comments) {
        if (fileInfos.length <= 0)
            return true;
        let ret = false;
        let add = [];
        let del = [];
        for await (const f of fileInfos) {
            const aux = f.folder === '' || f.folder.endsWith('/') ? '' : '/';
            const aux2 = f.extension.startsWith('.') ? '' : '.';
            const auxLevelPath = f.level === 0 ? '' : `l${f.level}/`;
            const path = `${auxLevelPath}` + f.folder.replace(/\\/g, '/') + aux + f.shortName + aux2 + f.extension;
            if (f.status === 'deleted') {
                del.push({ path });
            }
            else if (['changed', 'new', 'nochange'].includes(f.status)) {
                add = await this.setContentAddFile(f, path, add);
            }
            else if (f.status === 'renamed') {
                const info = f.getValueInfo ? await f.getValueInfo() : undefined;
                if (!info)
                    continue;
                const auxOld = !info.originalFolder || info.originalFolder.endsWith('/') ? '' : '/';
                const fileNameOld = `${auxLevelPath}` + (info.originalFolder || '').replace(/\\/g, '/') + auxOld + info.originalShortName + f.extension;
                add = await this.setContentAddFile(f, path, add);
                del.push({ path: fileNameOld });
            }
            else
                throw new Error('Status invalid');
        }
        try {
            ret = await this.saveMultipleFilesIO(fileInfos[0].project, add, del, comments);
            //await this.afterSave(fileInfos);
            return ret;
        }
        catch (e) {
            throw new Error('Error:' + e.message);
        }
    }
    async afterSave(fileInfos) {
        try {
            for await (const f of fileInfos) {
                if (f.onAction) {
                    await f.onAction('aftersave');
                }
            }
        }
        catch (e) {
            console.info('Erro onAftersave:' + e.message);
        }
    }
    async setContentAddFile(f, path, add) {
        let cont = await this.verifyAndGetContent(f);
        if (typeof cont !== 'string') {
            cont = await this.convertToBase64(cont, f);
        }
        else
            cont = dL.base64EncodeUnicode(cont); //btoa(cont);
        add.push({ path, content: cont });
        return add;
    }
    async verifyAndGetContent(fileInfo) {
        const oldV = fileInfo.inLocalStorage;
        fileInfo.inLocalStorage = true;
        if (fileInfo.getValueInfo) {
            const cont = (await fileInfo.getValueInfo()).content;
            fileInfo.inLocalStorage = oldV;
            if (cont)
                return cont;
        }
        const cont = await fileInfo.getContent();
        fileInfo.inLocalStorage = oldV;
        return cont;
    }
    async _loadFilesInfo(project) {
        return new Promise(async (resolve, reject) => {
            try {
                let projectDriver = 'mls';
                let projectURL = '';
                const obj = mls.l5.getProjectDetails(project);
                if (!obj || !obj.value)
                    throw new Error('Error loadFilesInfo getProjectDetails in:' + project);
                const json = JSON.parse(obj.value);
                if (!json)
                    throw new Error('Error loadFilesInfo getProjectDetails .value json in:' + project);
                if (!json.projectURL && json.l5_actionPrjSettings) {
                    projectDriver = json.l5_actionPrjSettings.projectDriver || 'mls';
                    projectURL = json.l5_actionPrjSettings.projectURL || '';
                }
                else if (json.projectURL) {
                    projectDriver = json.projectDriver || 'mls';
                    projectURL = json.projectURL || '';
                }
                else {
                    throw new Error('Error loadFilesInfo project info:' + project);
                }
                mls.stor.projects[project] = {
                    project,
                    projectDriver,
                    projectURL,
                };
                const ret = await this.getFilesRepo(project);
                resolve(ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    getFilesRepo(project) {
        return new Promise(async (resolve, reject) => {
            try {
                const data = await this.getFilesRepoIO(project);
                let ret = [];
                if (!data.data.repository.object)
                    resolve(ret);
                if (data.data.repository.object.entries.length <= 0)
                    resolve(ret);
                data.data.repository.object.entries.forEach((obj1) => {
                    ret = this.auxLoadFilesInfo2Reenter(obj1, ret);
                });
                resolve(ret);
            }
            catch (e) {
                reject(e);
            }
        });
    }
    auxLoadFilesInfo2Reenter(obj, arr) {
        if (!obj.object || !obj.object.entries) {
            if (obj.type === 'blob') {
                arr.push({
                    shortPath: 'l0/' + obj.name,
                    versionRef: obj.oid,
                    Length: obj.size,
                });
            }
            return (arr);
        }
        obj.object.entries.forEach((obj2) => {
            if (obj2.type === 'blob') {
                arr.push({
                    shortPath: obj2.path.startsWith('l') ? obj2.path : 'l0/' + obj2.path,
                    versionRef: obj2.oid,
                    Length: obj2.size,
                });
            }
            else {
                this.auxLoadFilesInfo2Reenter(obj2, arr);
            }
        });
        return (arr);
    }
    _getHistory(file) {
        return new Promise(async (resolve, reject) => {
            try {
                if (file.status === 'new')
                    resolve([]);
                let filename = file.shortName + (file.extension.startsWith('.') ? file.extension : '.' + file.extension);
                if (file.folder)
                    filename = file.folder + '/' + filename;
                const oid = file.versionRef;
                const data = await this.getHistoryIO(file.project, file.level.toString(), filename, oid);
                if (data.length <= 0)
                    resolve([]);
                const ret = [];
                data.forEach((i) => {
                    if (!i.node.file)
                        return;
                    const obj = {
                        authorName: i.node.author.name,
                        authorUrl: i.node.author.avatarUrl,
                        data: i.node.authoredDate,
                        ref: i.node.file.object.oid,
                        message: i.node.message,
                        additions: i.node.additions,
                        deletions: i.node.deletions,
                    };
                    ret.push(obj);
                });
                resolve(ret);
            }
            catch (e) {
                reject(e);
            }
        });
    }
    _getHistoryContent(file, ref) {
        return new Promise(async (resolve, reject) => {
            try {
                if (file.status === 'new')
                    resolve('');
                const ret = await this.getHistoryContentIO(file.project, ref);
                resolve(ret);
            }
            catch (e) {
                reject(e);
            }
        });
    }
    async fecthQl(query, variables) {
        try {
            this.verifyMKey();
            const info = {
                url: 'https://api.github.com/graphql',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Accept: 'application/json',
                    Authorization: 'bearer ' + mKey
                },
                query: query,
                variables: variables,
            };
            const dt = await dL.myFetchQL(info);
            if (dt.status === 401) {
                throw new Error(`Conecte no "gitHub", faça SignIn no "gitHub" para permitir salvar nos repositórios<br/>É importante salvar nos repositórios para permitir históricos e evitar perca de dados.`);
            }
            if (dt.status !== 200) {
                throw new Error('Erro status: ' + dt.status + '; ' + dt.ret.message);
            }
            if (dt.ret.errors) {
                throw new Error('Erro' + dt.ret.errors[0].message);
            }
            return dt;
        }
        catch (er) {
            throw new Error('fecthQl: ' + er.message);
        }
    }
    async filterExistingPaths(owner, repo, oid, paths) {
        if (paths.length <= 0)
            return { existing: [], skipped: [] };
        const aliases = paths.map((p, i) => `d${i}: object(expression: "${oid}:${p}") { oid }`);
        const q = `{
			repository(owner: "${owner}", name: "${repo}") {
				${aliases.join('\n\t\t\t\t')}
			}
		}`;
        const data = await this.fecthQl(q);
        const repository = data.ret.data && data.ret.data.repository;
        if (!repository)
            throw new Error('filterExistingPaths: repository not found');
        const existing = [];
        const skipped = [];
        paths.forEach((p, i) => {
            if (repository[`d${i}`])
                existing.push(p);
            else
                skipped.push(p);
        });
        return { existing, skipped };
    }
    async buildFileGroups(files, maxSizeBytes = 800 * 1024) {
        const groups = [];
        const singles = [];
        const deletions = [];
        let currentGroup = [];
        let currentSize = 0;
        const flushGroup = () => {
            if (currentGroup.length) {
                groups.push(currentGroup);
                currentGroup = [];
                currentSize = 0;
            }
        };
        for (const file of files) {
            // 🔥 DELETE nunca conta tamanho, vai pro grupo exclusivo de deleções
            if (file.status === 'deleted') {
                deletions.push(file);
                continue;
            }
            // pega conteúdo REAL que vai subir
            let cont = await this.verifyAndGetContent(file);
            if (typeof cont !== 'string') {
                cont = await this.convertToBase64(cont, file);
            }
            else {
                cont = dL.base64EncodeUnicode(cont);
            }
            const size = new Blob([cont]).size;
            // 🔥 arquivo grande → vira single
            if (size > maxSizeBytes) {
                flushGroup();
                singles.push([file]);
                continue;
            }
            // 🔥 se estourar o grupo atual, fecha ele
            if (currentSize + size > maxSizeBytes) {
                flushGroup();
            }
            currentGroup.push(file);
            currentSize += size;
        }
        flushGroup();
        // monta o retorno: grupo de deleções primeiro, depois groups, depois singles
        const result = [];
        if (deletions.length) {
            result.push({ type: 'group', files: deletions });
        }
        for (const g of groups) {
            result.push({ type: 'group', files: g });
        }
        for (const s of singles) {
            result.push({ type: 'single', files: s });
        }
        return result;
    }
    async *processFiles(project, files, coments) {
        this.verifyMKey();
        this.lastSaveInfo = { commits: 0, skippedDeletions: [] };
        const info = await dL.getMyKeysBranch(project, true);
        const fileGroups = await this.buildFileGroups(files);
        let contGroup = 1;
        const results = [];
        for (const groupItem of fileGroups) {
            // ================= GROUP (GraphQL batch) =================
            if (groupItem.type === 'group') {
                yield `start group-${contGroup} (${groupItem.files.length} files)`;
                try {
                    await this.setContents2(groupItem.files, `group-${contGroup}`);
                    yield `success group-${contGroup}`;
                    results.push({
                        type: 'group',
                        files: groupItem.files,
                        status: 'fulfilled'
                    });
                }
                catch (err) {
                    yield `error group`;
                    throw new Error(err?.message || err);
                }
                contGroup++;
                continue;
            }
            // ================= SINGLE (REST save/delete) =================
            for (const file of groupItem.files) {
                const folderAux = file.folder === "" || file.folder.endsWith("/") ? "" : "/";
                const extAux = file.extension.startsWith(".") ? "" : ".";
                const levelPath = file.level === 0 ? "" : `l${file.level}/`;
                const path = levelPath +
                    file.folder.replace(/\\/g, "/") +
                    folderAux +
                    file.shortName +
                    extAux +
                    file.extension;
                const fileName = `${file.folder ? file.folder + '/' : ''}${file.shortName}${file.extension}`;
                yield `start: ${fileName}`;
                try {
                    // -------- DELETE --------
                    if (file.status === 'deleted') {
                        await this.deleteFile({
                            token: mKey,
                            owner: info.owner,
                            repo: info.repo,
                            branch: info.branch,
                            path,
                            message: `delete: ${path}`
                        });
                    }
                    else {
                        // -------- UPDATE / NEW / RENAME --------
                        let cont = await this.verifyAndGetContent(file);
                        if (typeof cont !== "string") {
                            cont = await this.convertToBase64(cont, file);
                        }
                        else {
                            cont = dL.base64EncodeUnicode(cont);
                        }
                        await this.saveFile({
                            token: mKey,
                            owner: info.owner,
                            repo: info.repo,
                            branch: info.branch,
                            path,
                            content: cont,
                            message: `save: ${path}`,
                            file
                        });
                    }
                    yield `success: ${fileName}`;
                    this.lastSaveInfo.commits++;
                    results.push({
                        type: 'single',
                        file,
                        status: 'fulfilled'
                    });
                }
                catch (err) {
                    yield `error: ${fileName}`;
                    throw new Error(`Error in file ${file.shortName}: ${err?.message || err}`);
                }
            }
        }
        return results;
    }
    //-------------IO----------------
    async githubRequest(path, method, token, body) {
        return fetch(`https://api.github.com${path}`, {
            method,
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: 'bearer ' + mKey,
            },
            referrerPolicy: 'no-referrer',
            body: body ? JSON.stringify(body) : undefined,
        }).then(r => r.json());
    }
    async getSha(owner, repo, path, token) {
        const res = await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
            mode: 'cors',
            cache: 'no-cache',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                Authorization: 'bearer ' + mKey,
            },
            referrerPolicy: 'no-referrer'
        });
        if (res.status === 404)
            return null;
        return await res.json();
    }
    async saveFile(info) {
        const body = {
            message: info.message,
            branch: info.branch,
            content: info.content,
        };
        if (!['new', 'renamed'].includes(info.file.status)) {
            const sha = await this.getSha(info.owner, info.repo, info.path, info.token);
            body.sha = sha.sha;
        }
        return this.githubRequest(`/repos/${info.owner}/${info.repo}/contents/${info.path}`, "PUT", info.token, body);
    }
    async deleteFile({ token, owner, repo, path, message, branch = "main" }) {
        const existing = await this.getSha(owner, repo, path, token);
        if (!existing)
            throw new Error("File not found");
        await this.githubRequest(`/repos/${owner}/${repo}/contents/${path}`, "DELETE", token, {
            message,
            sha: existing.sha,
            force: true,
            branch,
        });
        return true;
    }
    async processFilesOld(project, files, coments) {
        const parallelLimit = 1;
        this.verifyMKey();
        const info = await dL.getMyKeysBranch(project, true);
        // Lista expandida de tarefas atômicas
        const expandedTasks = [];
        // ----- 1) EXPANSÃO -----
        for (const file of files) {
            let folderAux = file.folder === "" || file.folder.endsWith("/") ? "" : "/";
            const extAux = file.extension.startsWith(".") ? "" : ".";
            const levelPath = file.level === 0 ? "" : `l${file.level}/`;
            const newPath = levelPath +
                file.folder.replace(/\\/g, "/") +
                folderAux +
                file.shortName +
                extAux +
                file.extension;
            if (file.status === "deleted") {
                expandedTasks.push({ type: "delete", path: newPath, originalFile: file });
                continue;
            }
            if (file.status === "new" || file.status === "changed") {
                expandedTasks.push({ type: "update", path: newPath, originalFile: file });
                continue;
            }
            if (file.status === "renamed") {
                const oldInfo = await (file.getValueInfo?.() ?? undefined);
                if (!oldInfo)
                    continue;
                folderAux = oldInfo.originalFolder === "" || (oldInfo.originalFolder || '').endsWith("/") ? "" : "/";
                const oldPath = levelPath +
                    (oldInfo.originalFolder || '').replace(/\\/g, "/") +
                    folderAux +
                    oldInfo.originalShortName +
                    extAux +
                    file.extension;
                expandedTasks.push({ type: "delete", path: oldPath, originalFile: file });
                expandedTasks.push({ type: "update", path: newPath, originalFile: file });
                continue;
            }
            throw new Error(`Status invalid: ${file.status}`);
        }
        // ----- 2) FUNÇÕES ADIADAS -----
        const deferredTasks = expandedTasks.map(task => {
            return async () => {
                if (task.type === "delete") {
                    return this.deleteFile({
                        token: mKey,
                        owner: info.owner,
                        repo: info.repo,
                        branch: info.branch,
                        path: task.path,
                        message: `delete: ${task.path}` //coments
                    });
                }
                // update
                let cont = await this.verifyAndGetContent(task.originalFile);
                if (typeof cont !== "string") {
                    cont = await this.convertToBase64(cont, task.originalFile);
                }
                else {
                    cont = dL.base64EncodeUnicode(cont);
                }
                return this.saveFile({
                    token: mKey,
                    owner: info.owner,
                    repo: info.repo,
                    branch: info.branch,
                    path: task.path,
                    content: cont,
                    message: `save: ${task.path}`, //coments,
                    file: task.originalFile
                });
            };
        });
        // ----- 3) EXECUÇÃO EM BATCHES (interrompe ao 1º erro) -----
        const results = [];
        for (let i = 0; i < deferredTasks.length; i += parallelLimit) {
            const batchFns = deferredTasks.slice(i, i + parallelLimit);
            // executa o batch em paralelo
            const promises = batchFns.map(fn => fn());
            const settled = await Promise.allSettled(promises);
            // registrar e detectar erro
            for (let j = 0; j < settled.length; j++) {
                const idx = i + j;
                const file = expandedTasks[idx].originalFile;
                const s = settled[j];
                if (s.status === "fulfilled") {
                    results.push({ file, status: "fulfilled", value: s.value });
                }
                else {
                    results.push({ file, status: "rejected", reason: s.reason });
                    // 🔥 PARA TUDO → lança erro imediatamente
                    throw new Error(`Error in file ${file.shortName}: ${s.reason?.message || s.reason}`);
                }
            }
        }
        // ----- 4) Tudo OK -----
        return results;
    }
    syncForkIO(opt) {
        return new Promise(async (resolve, reject) => {
            if (!opt) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                if (!opt.branchDest)
                    opt.branchDest = 'main';
                let body = {};
                this.verifyMKey();
                const ret1 = await (await fetch(`https://api.github.com/repos/${opt.ownerOrigin}/${opt.repoOrigin}/git/refs/heads/${opt.branchOrigin}`, {
                    method: 'GET',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer'
                })).json();
                if (ret1 && ret1.message) {
                    reject(new Error(ret1.message));
                    return;
                }
                const sha = ret1.object.sha;
                if (!sha) {
                    resolve(false);
                    return;
                }
                body = {
                    sha: sha,
                    force: true
                };
                const ret2 = await fetch(`https://api.github.com/repos/${opt.ownerDest}/${opt.repoDest}/git/refs/heads/${opt.branchDest}`, {
                    method: 'PATCH',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify(body)
                });
                if (![200, 201, 204].includes(ret2.status)) {
                    resolve(false);
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    checkForkIO(ownerOrigin, repoOrigin, login) {
        return new Promise(async (resolve, reject) => {
            const query = `query {
						user(login: "${login}") {
							repositories(first: 100, isFork: true) {
								nodes {
									name
									nameWithOwner
									parent {
										nameWithOwner
									}
								}
							}
						}
					}`;
            this.fecthQl(query).then((data) => {
                try {
                    if (!data.ret || !data.ret.data.user || !data.ret.data.user.repositories || !data.ret.data.user.repositories.nodes)
                        resolve(false);
                    let ret = false;
                    const nameWithOwner = `${ownerOrigin}/${repoOrigin}`;
                    data.ret.data.user.repositories.nodes.forEach((n) => {
                        if (n.parent.nameWithOwner === nameWithOwner)
                            ret = true;
                    });
                    resolve(ret);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    delVariableIO(variable) {
        return new Promise(async (resolve, reject) => {
            if (!variable) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                const prj = mls.actualProject;
                if (!prj) {
                    reject(new Error('Not Found project!'));
                    return;
                }
                const info = await dL.getMyKeysBranch(prj);
                const retFetch = await fetch(`https://api.github.com/repos/${info.owner}/${info.repo}/actions/variables/${variable}`, {
                    method: 'DELETE',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                });
                if (retFetch.status === 401) {
                    throw new Error(`Conecte no "gitHub", faça SignIn no "gitHub" para permitir salvar nos repositórios<br/>É importante salvar nos repositórios para permitir históricos e evitar perca de dados.`);
                }
                if (retFetch.status === 404) {
                    resolve(false);
                    return;
                }
                if (retFetch.status === 403) {
                    resolve(false);
                    return;
                }
                const ret = await retFetch.json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    listVariablesIO() {
        return new Promise(async (resolve, reject) => {
            try {
                this.verifyMKey();
                const prj = mls.actualProject;
                if (!prj) {
                    reject(new Error('Not Found project!'));
                    return;
                }
                const info = await dL.getMyKeysBranch(prj);
                const retFetch = await fetch(`https://api.github.com/repos/${info.owner}/${info.repo}/actions/variables`, {
                    method: 'GET',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                });
                if (retFetch.status !== 200) {
                    reject(new Error('Not Found! : status:' + retFetch.status));
                    return;
                }
                const ret = await retFetch.json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                resolve(ret);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    updateVariableIO(variable, secret) {
        return new Promise(async (resolve, reject) => {
            if (!variable || !secret) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                const prj = mls.actualProject;
                if (!prj) {
                    reject(new Error('Not Found project!'));
                    return;
                }
                const info = await dL.getMyKeysBranch(prj);
                const body = {
                    name: variable,
                    value: secret
                };
                const retFetch = await fetch(`https://api.github.com/repos/${info.owner}/${info.repo}/actions/variables/${variable}`, {
                    method: 'PATCH',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify(body)
                });
                if (retFetch.status === 401) {
                    throw new Error(`Conecte no "gitHub", faça SignIn no "gitHub" para permitir salvar nos repositórios<br/>É importante salvar nos repositórios para permitir históricos e evitar perca de dados.`);
                }
                if (retFetch.status === 404) {
                    resolve(false);
                    return;
                }
                if (retFetch.status === 403) {
                    resolve(false);
                    return;
                }
                /*const ret = await retFetch.json();

                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }*/
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    addVariableIO(owner, repo, newVariable, secret) {
        return new Promise(async (resolve, reject) => {
            if (!newVariable || !secret) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                const body = {
                    name: newVariable,
                    value: secret
                };
                const retFetch = await fetch(`https://api.github.com/repos/${owner}/${repo}/actions/variables`, {
                    method: 'POST',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify(body)
                });
                if (retFetch.status === 401) {
                    throw new Error(`Connect to GitHub and sign in to GitHub to allow saving to the repositories. Saving to the repositories is important to maintain a history and prevent data loss.`);
                }
                if (retFetch.status === 404) {
                    resolve(false);
                    return;
                }
                if (retFetch.status === 403) {
                    resolve(false);
                    return;
                }
                const ret = await retFetch.json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    setPermissionActionIO(owner, repo, login) {
        return new Promise(async (resolve, reject) => {
            if (!repo || !owner) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                const url = `https://api.github.com/repos/${owner}/${repo}/actions/permissions/workflow`;
                const retFetch = await fetch(url, {
                    method: 'PUT',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    body: JSON.stringify({
                        enabled: true,
                        default_workflow_permissions: 'write',
                        allowed_actions: 'all',
                        can_approve_pull_request_reviews: true
                    }),
                    referrerPolicy: 'no-referrer',
                });
                if (retFetch.status === 409) {
                    throw new Error(`Required permission not available.An organization administrator needs to enable write permissions for GitHub Actions (Read and write) in the settings.`);
                }
                if (retFetch.status === 403) {
                    throw new Error(`You have to configure your repository - Settings -> Action -> General -> Workflow permissions and choose read and write permissions`);
                }
                if (![200, 204].includes(retFetch.status)) {
                    throw new Error(`Error: set permission action`);
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    verifyPermissionIO(owner, repo, login) {
        return new Promise(async (resolve, reject) => {
            if (!repo || !owner || !login) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                const retFetch = await fetch(`https://api.github.com/repos/${owner}/${repo}/collaborators/${login}/permission`, {
                    method: 'GET',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                });
                if (retFetch.status === 401) {
                    throw new Error(`Conecte no "gitHub", faça SignIn no "gitHub" para permitir salvar nos repositórios<br/>É importante salvar nos repositórios para permitir históricos e evitar perca de dados.`);
                }
                if (retFetch.status === 404) {
                    resolve({
                        create: false,
                        delete: false,
                        write: false,
                        read: false,
                    });
                    return;
                }
                if (retFetch.status === 403) {
                    resolve({
                        create: false,
                        delete: false,
                        write: false,
                        read: true,
                    });
                    return;
                }
                const ret = await retFetch.json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                if (!ret || !ret.user || !ret.user.permissions) {
                    reject(new Error('Not found your permissions'));
                    return;
                }
                const info = {
                    create: false,
                    delete: false,
                    write: false,
                    read: false,
                };
                if (ret.user.permissions.admin || ret.user.permissions.maintain) {
                    info.create = true;
                    info.delete = true;
                    info.write = true;
                    info.read = true;
                }
                else if (ret.user.permissions.push) {
                    info.create = false;
                    info.delete = false;
                    info.write = true;
                    info.read = true;
                }
                else if (ret.user.permissions.triage || ret.user.permissions.pull) {
                    info.create = false;
                    info.delete = false;
                    info.write = false;
                    info.read = true;
                }
                resolve(info);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    verifyRepositoryNewIO(owner, repo, user) {
        return new Promise(async (resolve, reject) => {
            if (!repo || !owner || !user) {
                reject(new Error('Information invalid!'));
                return;
            }
            // retorno
            // free: free to create the repository
            // reuse: The repository already exists for the user, you can reuse it
            // wait: Please wait, another user is creating; 
            // error: There is a repository, but I was unable to validate the user
            try {
                this.verifyMKey();
                const retRepo = await (await fetch(`https://api.github.com/repos/${owner}/${repo}`, {
                    method: 'GET',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                })).json();
                if (retRepo && retRepo.name && retRepo.name !== 'mls-new') {
                    resolve('free');
                    return;
                }
                if (retRepo.status === '401') {
                    throw new Error(`Conecte no "gitHub", faça SignIn no "gitHub" para permitir salvar nos repositórios<br/>É importante salvar nos repositórios para permitir históricos e evitar perca de dados.`);
                }
                if (retRepo && retRepo.message && retRepo.status === '404') {
                    resolve('free');
                    return;
                }
                const ret = await (await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/validate.json?ref=main`, {
                    method: 'GET',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                })).json();
                if (ret.status === '401') {
                    throw new Error(`Conecte no "gitHub", faça SignIn no "gitHub" para permitir salvar nos repositórios<br/>É importante salvar nos repositórios para permitir históricos e evitar perca de dados.`);
                }
                if (ret && ret.message && ret.status === '404') {
                    resolve('error');
                    return;
                }
                if (ret && ret.content) {
                    try {
                        const txt = atob(ret.content);
                        const js = JSON.parse(txt.trim());
                        if (!js.users) {
                            resolve('error');
                            return;
                        }
                        if (js.users.includes(user)) {
                            resolve('reuse');
                            return;
                        }
                        resolve('wait');
                        return;
                    }
                    catch {
                        resolve('error');
                        return;
                    }
                }
                resolve('free');
            }
            catch (err) {
                reject(err);
            }
        });
    }
    changeVisibilityIO(owner, repo, visibility) {
        return new Promise(async (resolve, reject) => {
            if (!repo || !owner) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                const body = {
                    private: visibility === 'PRIVATE'
                };
                const ret = await (await fetch(`https://api.github.com/repos/${owner}/${repo}`, {
                    method: 'PATCH',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify(body)
                })).json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    createFileInRepoIO(owner, repo, path, content) {
        return new Promise(async (resolve, reject) => {
            if (!repo || !owner) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                if (typeof (content) !== 'string')
                    throw new Error('Not implemented');
                content = dL.base64EncodeUnicode(content);
                const body = {
                    message: 'Add ' + path,
                    content
                };
                const ret = await (await fetch(`https://api.github.com/repos/${owner}/${repo}/contents/${path}`, {
                    method: 'PUT',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify(body)
                })).json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    renameRepositoryIO(owner, repo, newName) {
        return new Promise(async (resolve, reject) => {
            if (!repo || !owner || repo === newName) {
                reject(new Error('Information invalid!'));
                return;
            }
            const body = {
                name: newName
            };
            try {
                this.verifyMKey();
                const ret = await (await fetch(`https://api.github.com/repos/${owner}/${repo}`, {
                    method: 'PATCH',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify(body)
                })).json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    createForkIO(login, repoOri, orgOri, orgDest) {
        return new Promise(async (resolve, reject) => {
            if (!repoOri || !orgOri) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                let body = {};
                if (login !== orgDest) {
                    body.organization = orgDest;
                }
                const ret = await (await fetch(`https://api.github.com/repos/${orgOri}/${repoOri}/forks`, {
                    method: 'POST',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify(body)
                })).json();
                if (ret && ret.message) {
                    reject(new Error(ret.message));
                    return;
                }
                // Set option delete_branch_on_merge
                const ret2 = await (await fetch(`https://api.github.com/repos/${orgDest}/${repoOri}`, {
                    method: 'PATCH',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer',
                    body: JSON.stringify({ delete_branch_on_merge: true })
                })).json();
                if (ret2 && ret2.message) {
                    reject(new Error(ret.message));
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    deleteRepositoryIO(repo, organization) {
        return new Promise(async (resolve, reject) => {
            if (!repo || !organization) {
                reject(new Error('Information invalid!'));
                return;
            }
            try {
                this.verifyMKey();
                const ret = await fetch(`https://api.github.com/repos/${organization}/${repo}`, {
                    method: 'DELETE',
                    mode: 'cors',
                    cache: 'no-cache',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        Authorization: 'bearer ' + mKey,
                    },
                    referrerPolicy: 'no-referrer'
                });
                if (ret.status !== 204) {
                    reject(new Error('Error delete repository'));
                    return;
                }
                resolve(true);
            }
            catch (err) {
                reject(err);
            }
        });
    }
    createRepositoryIO(login, repo, organization, description, visibility) {
        return new Promise((resolve, reject) => {
            if (!repo || !organization) {
                reject(new Error('Information invalid!'));
                return;
            }
            if (!description)
                description = "This project was created using the Collabcodes";
            let q = '';
            if (login === organization) {
                q = `
				mutation {
					createRepository(input: {name: "${repo}", description: "${description.replace(/"/g, "'")}", visibility:${visibility}}) {
						repository {
							id
							name
							owner {
								login
							}
						}
					}
				}
				`;
            }
            else {
                q = `
				mutation {
					createRepository(input: {name: "${repo}", ownerId:"${organization}", description: "${description.replace(/"/g, "'")}", visibility:${visibility}}) {
						repository {
							id
							name
							owner {
								login
							}
						}
					}
				}
				`;
            }
            this.fecthQl(q).then(async (data) => {
                try {
                    if (!data.ret || !data.ret.data.createRepository || !data.ret.data.createRepository.repository || !data.ret.data.createRepository.repository.id)
                        reject(new Error('Erro not possible add repository'));
                    resolve(true);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getOrganizationsIO(login) {
        return new Promise(async (resolve, reject) => {
            if (!login) {
                reject(new Error('Login invalid!'));
                return;
            }
            const q = `
			{
				user(login: "${login}") {
					organizations(first: 100) {
						edges {
							node {
								name
								login
								avatarUrl
								id
							}
						}
					}
				}
			}
			`;
            this.fecthQl(q).then((data) => {
                try {
                    const orgs = [];
                    if (!data.ret || !data.ret.data.user || !data.ret.data.user.organizations || !data.ret.data.user.organizations.edges)
                        resolve(orgs);
                    data.ret.data.user.organizations.edges.forEach((i) => {
                        const info = {};
                        info.name = i.node.login;
                        info.id = i.node.id;
                        info.avatarUrl = i.node.avatarUrl;
                        info.visibility = 'public';
                        orgs.push(info);
                    });
                    resolve(orgs);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getUserInfoIO() {
        return new Promise(async (resolve, reject) => {
            const q = `
			{
				viewer {
					name
					login
					avatarUrl
				}
			}
			`;
            this.fecthQl(q).then((data) => {
                try {
                    const info = {};
                    if (!data.ret || !data.ret.data.viewer)
                        resolve(info);
                    info.name = data.ret.data.viewer.name;
                    info.login = data.ret.data.viewer.login;
                    info.avatarUrl = data.ret.data.viewer.avatarUrl;
                    resolve(info);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    listBranchesIO(owner, repo) {
        return new Promise(async (resolve, reject) => {
            const q = `
			{
                repository(owner:"${owner}", name:"${repo}") {
                refs(refPrefix: "refs/heads/", first: 100) {
                    edges {
                    node {
                        name
                    }
                    }
                    
                }
                }
            }
			`;
            this.fecthQl(q).then((data) => {
                try {
                    if (!data.ret ||
                        !data.ret.data.repository.refs ||
                        !data.ret.data.repository.refs.edges)
                        resolve([]);
                    const b = [];
                    data.ret.data.repository.refs.edges.forEach((i) => {
                        b.push(i.node);
                    });
                    resolve(b);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    listForksIO(owner, repo) {
        return new Promise(async (resolve, reject) => {
            //const info = await this.getMyKeysBranch(project);
            const q = `
			{
				repository(owner:"${owner}", name:"${repo}") {
					forks(first: 100) {
						edges {
							node {
								nameWithOwner
								defaultBranchRef{
									name

								}
								createdAt
							}
						}

					}
				}
			}
			`;
            this.fecthQl(q).then((data) => {
                try {
                    if (!data.ret ||
                        !data.ret.data.repository.forks ||
                        !data.ret.data.repository.forks.edges)
                        resolve([]);
                    const fk = [];
                    data.ret.data.repository.forks.edges.forEach((i) => {
                        fk.push(i.node);
                    });
                    resolve(fk);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    listPullRequestsIO(owner, repo) {
        return new Promise(async (resolve, reject) => {
            const qLastCommit = `{
					repository(owner:"${owner}", name:"${repo}") {
						pullRequests(states: OPEN, first: 100) {
							edges {
								node {
									id
									title
									body
									state
									url
									createdAt
									mergedAt
							    closedAt
									author {
										login
									}
								}
							}
						}
					}
				}`;
            this.fecthQl(qLastCommit).then((data) => {
                try {
                    if (!data.ret ||
                        !data.ret.data.repository.pullRequests ||
                        !data.ret.data.repository.pullRequests.edges)
                        resolve([]);
                    const pr = [];
                    data.ret.data.repository.pullRequests.edges.forEach((i) => {
                        pr.push(i.node);
                    });
                    resolve(pr);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    reviewPullRequestIO(options) {
        return new Promise(async (resolve, reject) => {
            try {
                let q = '';
                if (options.isApproved) {
                    q = `
					mutation {
						addPullRequestReview(input: {pullRequestId: "${options.idRequest}", event: APPROVE}) {
							pullRequestReview {
								id
								state
							}
						}
					}
				`;
                }
                else {
                    q = `
					mutation() {
							closePullRequest(input: {pullRequestId: "${options.idRequest}"}) {
								pullRequest {
									id
									state
								}
							}
						}
					`;
                }
                const data = await this.fecthQl(q);
                const ret = !data.ret.data || !data.ret.data.addPullRequestReview;
                resolve(!ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    createPullRequestIO(option) {
        return new Promise(async (resolve, reject) => {
            try {
                const project = mls.actualProject;
                if (!project)
                    throw new Error('Not set project actual');
                const uB = dL.getMyKeysBranch(project);
                const idProject = await this.getIdProjectIO(0, uB.owner, uB.repo);
                let head = uB.owner !== option.owner ? `${option.owner}:${option.branch}` : option.branch;
                const q = `
					mutation {
						createPullRequest(input: {
							baseRefName:"${uB.branch}",
							headRefName: "${head}",
							title: "${option.title.replace(/"/g, "'")}",
							body: "${option.description.replace(/"/g, "'")}",
							repositoryId: "${idProject}"
						}) {
							pullRequest {
								id
								url
							}
						}
					}
				`;
                const data = await this.fecthQl(q);
                const ret = !data.ret.data || !data.ret.data.createPullRequest || !data.ret.data.createPullRequest.pullRequest || !data.ret.data.createPullRequest.pullRequest || !data.ret.data.createPullRequest.pullRequest.id;
                resolve(!ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    createNewBranchIO(option) {
        return new Promise(async (resolve, reject) => {
            try {
                const idProject = await this.getIdProjectIO(0, option.owner, option.repo);
                let oid = await this.getOidLastCommitFromInfoIO(option.owner, option.repo, option.branch);
                let test = 0;
                if (!oid) {
                    while (test !== 2 && !oid) {
                        oid = await this.getOidLastCommitFromInfoIO(option.owner, option.repo, option.branch);
                        test++;
                        await this.sleep(200);
                    }
                }
                if (!oid) {
                    reject('Not found oid');
                    return;
                }
                const q = `
					mutation {
						 createRef(input: {repositoryId: "${idProject}", name: "refs/heads/${option.newBranch}", oid: "${oid}"}) {
							ref {
								id
								name
							}
						}
					}
				`;
                const data = await this.fecthQl(q);
                const ret = !data.ret.data || !data.ret.data.createRef || !data.ret.data.createRef.ref || !data.ret.data.createRef.ref.id;
                resolve(!ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    checkBranchExistenceIO(owner, repo, branchName) {
        return new Promise(async (resolve, reject) => {
            const qLastCommit = `{
					repository(owner:"${owner}", name:"${repo}") {
						ref(qualifiedName: "${branchName}") {
							id
						}
					}
				}`;
            this.fecthQl(qLastCommit).then((data) => {
                try {
                    if (!data.ret || !data.ret.data.repository || !data.ret.data.repository.ref || !data.ret.data.repository.ref.id)
                        resolve(false);
                    resolve(true);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getHistoryContentIO(project, oid) {
        return new Promise(async (resolve, reject) => {
            const info = await dL.getMyKeysBranch(project);
            const query = `
				query {
					repository(owner:"${info.owner}", name: "${info.repo}") {
						object(oid: "${oid}") {
							
							... on Blob {
								
								byteSize
								id
								oid
								text
								
							}	
						}	
					}
				}`;
            this.fecthQl(query).then((data) => {
                try {
                    if (!data.ret ||
                        !data.ret.data.repository.object || !data.ret.data.repository.object.text)
                        resolve('');
                    resolve(data.ret.data.repository.object.text);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getFilesIO(project, fileName) {
        return new Promise(async (resolve, reject) => {
            try {
                const info = dL.getMyKeysBranch(project);
                let ret = null;
                const q = `query {
					repository(owner:"${info.owner}", name:"${info.repo}") {
						object(expression: "HEAD:${fileName}") {	
							... on Blob {
								byteSize
								oid
								text
							}	
						}	
					}
				}`;
                const data = await this.fecthQl(q);
                if (!data.ret.data.repository || !data.ret.data.repository.object) {
                    reject(new Error('File not found:' + fileName));
                    return;
                }
                ret = data.ret.data.repository.object.text;
                resolve(ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    async getFilesRestIO(project, oid, extension) {
        const info = await dL.getMyKeysBranch(project);
        try {
            this.verifyMKey();
            const ret = await (await fetch(`https://api.github.com/repos/${info.owner}/${info.repo}/git/blobs/${oid}`, {
                method: 'GET',
                mode: 'cors',
                cache: 'no-cache',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                    Authorization: 'bearer ' + mKey,
                },
                referrerPolicy: 'no-referrer'
            })).json();
            const b64 = ret && ret.content ? ret.content : 'Erro';
            if (!b64 || b64 === 'Erro')
                return b64;
            const blob = await dL.base64ToBlob(b64, extension, oid);
            return blob;
        }
        catch (e) {
            return e.message;
        }
    }
    verifyMKey() {
        if (!mKey)
            throw new Error('Please connect to github!');
    }
    saveMultipleFilesIO(project, add, del, msg) {
        return new Promise(async (resolve, reject) => {
            try {
                const info = await dL.getMyKeysBranch(project, true);
                const oid = await this.getOidLastCommitIO(project);
                let delValid = del;
                if (del.length > 0) {
                    const check = await this.filterExistingPaths(info.owner, info.repo, oid, del.map((d) => d.path));
                    check.skipped.forEach((p) => console.info('[save] deleção ignorada (não existe no remoto):', p));
                    this.lastSaveInfo.skippedDeletions.push(...check.skipped);
                    delValid = del.filter((d) => check.existing.includes(d.path));
                }
                const aAdd = [];
                const aDel = [];
                add.forEach((i) => {
                    aAdd.push(`{path: "${i.path}", contents: "${i.content}"}`);
                });
                delValid.forEach((i) => {
                    aDel.push(`{path: "${i.path}"}`);
                });
                const auxAdd = aAdd.length > 0 ? `additions: [ 	${aAdd.join(', ')} ]` : '';
                const auxDel = aDel.length > 0 ? `deletions: [ 	${aDel.join(', ')} ]` : '';
                if (auxAdd === '' && auxDel === '') {
                    resolve(true);
                    return;
                }
                const q = `mutation {
					createCommitOnBranch(
						input: {
							fileChanges: {
								${auxAdd === '' ? '' : auxAdd + ', '}
								${auxDel}
							}, 
							branch: {
								repositoryNameWithOwner: "${info.owner}/${info.repo}", 
								branchName: "${info.branch}"
							}, 
							expectedHeadOid: "${oid}", 
							message: {headline: "${msg.replace(/"/g, "'")}", body: "${msg.replace(/"/g, "'")}"}
						}
					) {
						commit {
							abbreviatedOid
						}
					}
				}`;
                const data = await this.fecthQl(q);
                const ret = data.ret.data && data.ret.data.createCommitOnBranch && data.ret.data.createCommitOnBranch.commit && data.ret.data.createCommitOnBranch.commit.abbreviatedOid;
                if (ret)
                    this.lastSaveInfo.commits++;
                resolve(ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    getFilesRepoIO(project) {
        return new Promise(async (resolve, reject) => {
            try {
                const info = await dL.getMyKeysBranch(project);
                let aux = '';
                for (let i = 0; i < 4; i++) {
                    aux = aux + `
                        ... on TreeEntry{
                            object{
                                # Top-level.
                                ... on Tree {
                                    entries {
                                        name
                                        oid
                                        path
                                        type	
                                        size
                    
                    `;
                }
                for (let i = 0; i < 4; i++) {
                    aux = aux + `
                                }
                            }
                        }
                    }
                    `;
                }
                const q = `query repository {
					repository(owner:"${info.owner}", name:"${info.repo}") {
							object(expression: "HEAD:") {
								# Top-level.
								... on Tree {
									entries {
										name
										oid
										path
										type
										size	
										${aux}
							        }	
						        }
                            }
                        }		
					}`;
                const data = await this.fecthQl(q);
                resolve(data.ret);
            }
            catch (e) {
                reject(new Error(e.message));
            }
        });
    }
    getHistoryIO(project, nivel, fileName, oid) {
        return new Promise(async (resolve, reject) => {
            const info = await dL.getMyKeysBranch(project);
            const query = `
			query {
				repository(owner: "${info.owner}", name: "${info.repo}") {
					
					ref(qualifiedName: "main") {
						target {
							... on Commit {
								history(first: 20, path:"l${nivel}/${fileName}", before:"${oid}") {
									pageInfo {
										hasNextPage
										endCursor
									}
									edges {
										node {
											additions
              				deletions
											author{
												avatarUrl
												name
											}
											authoredDate
											message
											
											file(path:"l${nivel}/${fileName}"){
												object{
													... on Blob {
														oid

													}	
												}
											}
											
											
										}
									}
								}
							}
						}
					}
				}
			}`;
            this.fecthQl(query).then((data) => {
                try {
                    if (!data.ret ||
                        !data.ret.data.repository.ref || !data.ret.data.repository.ref.target ||
                        !data.ret.data.repository.ref.target.history.edges)
                        resolve([]);
                    resolve(data.ret.data.repository.ref.target.history.edges);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getVersionFromFilesIO(options) {
        return new Promise(async (resolve, reject) => {
            let auxStr = '';
            options.files.forEach((f) => {
                const aux = f.folder === '' || f.folder.endsWith('/') ? '' : '/';
                const aux2 = f.extension.startsWith('.') ? '' : '.';
                const auxLevelPath = f.level === 0 ? '' : `l${f.level}/`;
                const path = `${auxLevelPath}` + f.folder.replace(/\\/g, '/') + aux + f.shortName + aux2 + f.extension;
                const key = '_' + (mls.stor.getKeyToFiles(f.project, f.level, f.shortName, f.folder, f.extension).replace(/\./g, ''));
                auxStr = `
                    ${auxStr}
                    ${key}: object(expression: "${options.branchName}:${path}") {
                        ... on Blob {
                            oid
                        }
                    }
				`;
            });
            if (!auxStr)
                reject(new Error('Not found str'));
            const q = `
                query {
                    repository(owner: "${options.owner}", name: "${options.repo}") {
                        ${auxStr}
                    }
                }
			`;
            this.fecthQl(q).then((data) => {
                try {
                    if (!data.ret || !data.ret.data.repository)
                        resolve(undefined);
                    const ret = {};
                    options.files.forEach((f) => {
                        const keyv = mls.stor.getKeyToFiles(f.project, f.level, f.shortName, f.folder, f.extension);
                        const key = '_' + (keyv.replace(/\./g, ''));
                        if (data.ret.data.repository[key])
                            ret[keyv] = data.ret.data.repository[key].oid;
                    });
                    resolve(ret);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getOidLastCommitFromInfoIO(owner, repo, branch) {
        return new Promise(async (resolve, reject) => {
            const qLastCommit = `{
					repository(owner:"${owner}", name:"${repo}") {
						ref(qualifiedName: "${branch}") {
							target {
								... on Commit {
									history(first: 1) {
										nodes {
											oid
										}
									}
								}
							}
						}
					}
				}`;
            this.fecthQl(qLastCommit).then((data) => {
                try {
                    if (!data.ret ||
                        !data.ret.data.repository.ref ||
                        !data.ret.data.repository.ref.target.history.nodes)
                        resolve('');
                    const lastCommit = data.ret.data.repository.ref.target.history.nodes[0].oid;
                    resolve(lastCommit);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getIdProjectIO(project, owner = '', repo = '') {
        return new Promise(async (resolve, reject) => {
            let info;
            if (!project)
                info = { owner, repo };
            else
                info = await dL.getMyKeysBranch(project);
            const qLastCommit = `{
					repository(owner:"${info.owner}", name:"${info.repo}") {
						id
					}
				}`;
            this.fecthQl(qLastCommit).then((data) => {
                try {
                    if (!data.ret || !data.ret.data.repository || !data.ret.data.repository.id)
                        resolve('');
                    resolve(data.ret.data.repository.id);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    getOidLastCommitIO(project, getCurrentBranch = true) {
        return new Promise(async (resolve, reject) => {
            const info = await dL.getMyKeysBranch(project, getCurrentBranch);
            const qLastCommit = `{
					repository(owner:"${info.owner}", name:"${info.repo}") {
						ref(qualifiedName: "${info.branch}") {
							target {
								... on Commit {
									history(first: 1) {
										nodes {
											oid
										}
									}
								}
							}
						}
					}
				}`;
            this.fecthQl(qLastCommit).then((data) => {
                try {
                    if (!data.ret ||
                        !data.ret.data.repository.ref ||
                        !data.ret.data.repository.ref.target.history.nodes)
                        resolve('');
                    const lastCommit = data.ret.data.repository.ref.target.history.nodes[0].oid;
                    resolve(lastCommit);
                }
                catch (err) {
                    reject(err);
                }
            }).catch((e) => {
                reject(e);
            });
        });
    }
    async convertToBase64(content, file) {
        try {
            if (!content)
                throw new Error('Content invalid');
            let cont = await dL.fileToBase64(content);
            [, cont] = cont.split("base64,");
            return cont;
        }
        catch (e) {
            throw new Error('[convertToBase64]:' + (e.message || '') + ` file:${file.project}/${file.folder ? file.folder + '/' : ''}${file.shortName}${file.extension}`);
        }
    }
}
