/// <mls fileReference="_100554_/l2/collabProcessTest.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { TsTestAst } from "/_100554_/l2/tsTestAST.js";
let CollabProcessTest = class CollabProcessTest extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.script = '';
        this.labelError = '';
        this.labelOk = '';
    }
    render() {
        return html `
            <h3>Process Test</h3>
            <div style="display:flex; gap:.5rem">
                <div>
                    <label style="width: 145px;">Name func:</label>
                    <input id="iptnamefunc" type="text" @blur="${this.changeNameFunc}"></input>
                </div> 
                <div>
                    <label style="width: 163px;">Create integration:</label>
                    <input id="checkintegration" type="checkbox" ></input>
                </div>              
                <button @click="${this.onSave}">Save</button>
            </div>
            <div class="error"> ${this.labelError}</div>
            <div class="success"> ${this.labelOk}</div>
            <div>
                <textarea id="txtScript" .value="${this.script ? this.decodeHtmlEntities(decodeURIComponent(atob(this.script))) : ''}"spellcheck="false">
                </textarea>
            </div>
        

        `;
    }
    decodeHtmlEntities(str) {
        const textarea = document.createElement("textarea");
        textarea.innerHTML = str;
        return textarea.value;
    }
    // -------IMPLEMENTATION--------
    changeNameFunc(e) {
        if (!this.iptnamefunc || this.iptnamefunc.value == '') {
            this.labelError = 'The function name was not provided!';
            return;
        }
        if (!this.txtScript) {
            this.labelError = 'Not found script';
            return;
        }
        const vl = this.iptnamefunc?.value.trim();
        this.txtScript.value = this.txtScript.value.replace(/@funcname/g, vl);
    }
    async onSave() {
        if (!this.iptnamefunc || this.iptnamefunc.value == '') {
            this.labelError = 'The function name was not provided!';
            return;
        }
        if (!this.txtScript) {
            this.labelError = 'Not found script';
            return;
        }
        const args = this.parentElement.args;
        if (!args) {
            this.labelError = 'Not found args';
            return;
        }
        args.exe.functionName = this.iptnamefunc.value.trim();
        const params = this.createObjeTest(args.exe);
        this.addInEditor({ args: params, script: this.txtScript.value, integration: args.exe });
    }
    createObjeTest(info) {
        const ret = {
            functionName: info.functionName,
            params: []
        };
        const ex = {};
        Object.keys(info.schema).forEach((k) => {
            if (ex[k])
                return;
            ex[k] = info.schema[k].value;
            delete info.schema[k].value;
        });
        ret.params.push(ex);
        return ret;
    }
    addInEditor(params) {
        try {
            const editor = mls.services['100554_serviceSource_left']._ed1;
            if (!editor)
                throw new Error('Not found editor');
            const info = mls.actual[2].left;
            const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, 2);
            const model = mls.editor.models[key];
            if (!model || !model.test)
                throw new Error('Not found model');
            const testAST = new TsTestAst(model.test, editor);
            testAST.addTest(params.args, params.script);
            if (this.checkintegration && this.checkintegration.checked) {
                testAST.addIntegration(params.integration, '');
            }
            const sev = this.closest('service-detail-100554');
            if (!sev)
                return;
            sev.openService('_100554_servicePreview', 'right', sev.level);
        }
        catch (e) {
            console.info(e);
        }
    }
};
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "script", void 0);
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "labelError", void 0);
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "labelOk", void 0);
__decorate([
    query('#txtScript')
], CollabProcessTest.prototype, "txtScript", void 0);
__decorate([
    query('#iptnamefunc')
], CollabProcessTest.prototype, "iptnamefunc", void 0);
__decorate([
    query('#checkintegration')
], CollabProcessTest.prototype, "checkintegration", void 0);
CollabProcessTest = __decorate([
    customElement('collab-process-test-100554')
], CollabProcessTest);
export { CollabProcessTest };
