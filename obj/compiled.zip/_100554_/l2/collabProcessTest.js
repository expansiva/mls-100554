/// <mls fileReference="_100554_/l2/collabProcessTest.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
import { TsTestAst } from "/_100554_/l2/tsTestAST.js";
let CollabProcessTest = class extends CollabLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-process-test-100554 {
  display: block;
}
collab-process-test-100554 h3 {
  text-align: center;
}
collab-process-test-100554 .error {
  color: var(--error-color);
}
collab-process-test-100554 .success {
  color: var(--info-color);
}
collab-process-test-100554 button {
  background-color: var(--bg-secondary-color-lighter);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--grey-color);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: var(--text-primary-color);
  cursor: pointer;
}
collab-process-test-100554 button:hover {
  background-color: var(--grey-color-light);
}
collab-process-test-100554 .input-container {
  display: flex;
  gap: 1rem;
}
collab-process-test-100554 div {
  display: flex;
  gap: 0.5rem;
  align-items: center;
  justify-content: center;
}
collab-process-test-100554 div input[type="text"],
collab-process-test-100554 div textarea {
  display: block;
  width: calc(100% - 1.5rem - 1px);
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  font-weight: 400;
  line-height: 1.5;
  color: #212529;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
  outline: none;
}
collab-process-test-100554 textarea {
  margin-top: 1rem;
  border-radius: 2px;
  border: 1px solid var(--bg-primary-color-disabled);
  width: 500px;
  min-height: 250px;
  outline: none;
  padding: 0.3rem;
}
`);
    this.script = "";
    this.labelError = "";
    this.labelOk = "";
  }
  render() {
    return html`
            <h3>Process Test</h3>
            <div style="display:flex; gap:.5rem">
                <div>
                    <label style="width: 145px;">Name func:</label>
                    <input id="iptnamefunc" type="text" @blur="${this.changeNameFunc}"></input>
                </div> 
                <div>
                    <label style="width: 163px;">Create integration:</label>
                    <input id="checkintegration" type="checkbox" ></input>
                </div>              
                <button @click="${this.onSave}">Save</button>
            </div>
            <div class="error"> ${this.labelError}</div>
            <div class="success"> ${this.labelOk}</div>
            <div>
                <textarea id="txtScript" .value="${this.script ? this.decodeHtmlEntities(decodeURIComponent(atob(this.script))) : ""}"spellcheck="false">
                </textarea>
            </div>
        

        `;
  }
  decodeHtmlEntities(str) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = str;
    return textarea.value;
  }
  // -------IMPLEMENTATION--------
  changeNameFunc(e) {
    if (!this.iptnamefunc || this.iptnamefunc.value == "") {
      this.labelError = "The function name was not provided!";
      return;
    }
    if (!this.txtScript) {
      this.labelError = "Not found script";
      return;
    }
    const vl = this.iptnamefunc?.value.trim();
    this.txtScript.value = this.txtScript.value.replace(/@funcname/g, vl);
  }
  async onSave() {
    if (!this.iptnamefunc || this.iptnamefunc.value == "") {
      this.labelError = "The function name was not provided!";
      return;
    }
    if (!this.txtScript) {
      this.labelError = "Not found script";
      return;
    }
    const args = this.parentElement.args;
    if (!args) {
      this.labelError = "Not found args";
      return;
    }
    args.exe.functionName = this.iptnamefunc.value.trim();
    const params = this.createObjeTest(args.exe);
    this.addInEditor({ args: params, script: this.txtScript.value, integration: args.exe });
  }
  createObjeTest(info) {
    const ret = {
      functionName: info.functionName,
      params: []
    };
    const ex = {};
    Object.keys(info.schema).forEach((k) => {
      if (ex[k]) return;
      ex[k] = info.schema[k].value;
      delete info.schema[k].value;
    });
    ret.params.push(ex);
    return ret;
  }
  addInEditor(params) {
    try {
      const editor = mls.services["100554_serviceSource_left"]._ed1;
      if (!editor) throw new Error("Not found editor");
      const info = mls.actual[2].left;
      const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, 2);
      const model = mls.editor.models[key];
      if (!model || !model.test) throw new Error("Not found model");
      const testAST = new TsTestAst(model.test, editor);
      testAST.addTest(params.args, params.script);
      if (this.checkintegration && this.checkintegration.checked) {
        testAST.addIntegration(params.integration, "");
      }
      const sev = this.closest("service-detail-100554");
      if (!sev) return;
      sev.openService("_100554_servicePreview", "right", sev.level);
    } catch (e) {
      console.info(e);
    }
  }
};
__decorateClass([
  property({ type: String })
], CollabProcessTest.prototype, "script", 2);
__decorateClass([
  property({ type: String })
], CollabProcessTest.prototype, "labelError", 2);
__decorateClass([
  property({ type: String })
], CollabProcessTest.prototype, "labelOk", 2);
__decorateClass([
  query("#txtScript")
], CollabProcessTest.prototype, "txtScript", 2);
__decorateClass([
  query("#iptnamefunc")
], CollabProcessTest.prototype, "iptnamefunc", 2);
__decorateClass([
  query("#checkintegration")
], CollabProcessTest.prototype, "checkintegration", 2);
CollabProcessTest = __decorateClass([
  customElement("collab-process-test-100554")
], CollabProcessTest);
export {
  CollabProcessTest
};
