/// <mls fileReference="_100554_/l2/collabProcessTest.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { TsTestAst } from "/_100554_/l2/tsTestAST.js";
let CollabProcessTest = class CollabProcessTest extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-process-test-100554{display:block}collab-process-test-100554 h3{text-align:center}collab-process-test-100554 .error{color:var(--error-color)}collab-process-test-100554 .success{color:var(--info-color)}collab-process-test-100554 button{background-color:var(--bg-secondary-color-lighter);border-radius:8px;border:none;box-shadow:0 1px 3px 0 var(--grey-color);display:flex;flex-direction:row;justify-content:center;gap:.2rem;font-weight:700;align-items:center;height:40px;transition:height .3s cubic-bezier(.25, .1, .25, 1);padding:.5rem;color:var(--text-primary-color);cursor:pointer}collab-process-test-100554 button:hover{background-color:var(--grey-color-light)}collab-process-test-100554 .input-container{display:flex;gap:1rem}collab-process-test-100554 div{display:flex;gap:.5rem;align-items:center;justify-content:center}collab-process-test-100554 div input[type="text"],collab-process-test-100554 div textarea{display:block;width:calc(100% - 1.5rem - 1px);padding:.375rem .75rem;font-size:1rem;font-weight:400;line-height:1.5;color:#212529;background-color:#fff;background-clip:padding-box;border:1px solid #ced4da;-webkit-appearance:none;-moz-appearance:none;appearance:none;border-radius:.25rem;transition:border-color .15s ease-in-out,box-shadow .15s ease-in-out;outline:none}collab-process-test-100554 textarea{margin-top:1rem;border-radius:2px;border:1px solid var(--bg-primary-color-disabled);width:500px;min-height:250px;outline:none;padding:.3rem}`);
    }
    script = '';
    labelError = '';
    labelOk = '';
    txtScript;
    iptnamefunc;
    checkintegration;
    render() {
        return html `
            <h3>Process Test</h3>
            <div style="display:flex; gap:.5rem">
                <div>
                    <label style="width: 145px;">Name func:</label>
                    <input id="iptnamefunc" type="text" @blur="${this.changeNameFunc}"></input>
                </div> 
                <div>
                    <label style="width: 163px;">Create integration:</label>
                    <input id="checkintegration" type="checkbox" ></input>
                </div>              
                <button @click="${this.onSave}">Save</button>
            </div>
            <div class="error"> ${this.labelError}</div>
            <div class="success"> ${this.labelOk}</div>
            <div>
                <textarea id="txtScript" .value="${this.script ? this.decodeHtmlEntities(decodeURIComponent(atob(this.script))) : ''}"spellcheck="false">
                </textarea>
            </div>
        

        `;
    }
    decodeHtmlEntities(str) {
        const textarea = document.createElement("textarea");
        textarea.innerHTML = str;
        return textarea.value;
    }
    // -------IMPLEMENTATION--------
    changeNameFunc(e) {
        if (!this.iptnamefunc || this.iptnamefunc.value == '') {
            this.labelError = 'The function name was not provided!';
            return;
        }
        if (!this.txtScript) {
            this.labelError = 'Not found script';
            return;
        }
        const vl = this.iptnamefunc?.value.trim();
        this.txtScript.value = this.txtScript.value.replace(/@funcname/g, vl);
    }
    async onSave() {
        if (!this.iptnamefunc || this.iptnamefunc.value == '') {
            this.labelError = 'The function name was not provided!';
            return;
        }
        if (!this.txtScript) {
            this.labelError = 'Not found script';
            return;
        }
        const args = this.parentElement.args;
        if (!args) {
            this.labelError = 'Not found args';
            return;
        }
        args.exe.functionName = this.iptnamefunc.value.trim();
        const params = this.createObjeTest(args.exe);
        this.addInEditor({ args: params, script: this.txtScript.value, integration: args.exe });
    }
    createObjeTest(info) {
        const ret = {
            functionName: info.functionName,
            params: []
        };
        const ex = {};
        Object.keys(info.schema).forEach((k) => {
            if (ex[k])
                return;
            ex[k] = info.schema[k].value;
            delete info.schema[k].value;
        });
        ret.params.push(ex);
        return ret;
    }
    addInEditor(params) {
        try {
            const editor = mls.services['100554_serviceSource_left']._ed1;
            if (!editor)
                throw new Error('Not found editor');
            const info = mls.actual[2].left;
            const key = mls.editor.getKeyModel(info.project, info.shortName, info.folder, 2);
            const model = mls.editor.models[key];
            if (!model || !model.test)
                throw new Error('Not found model');
            const testAST = new TsTestAst(model.test, editor);
            testAST.addTest(params.args, params.script);
            if (this.checkintegration && this.checkintegration.checked) {
                testAST.addIntegration(params.integration, '');
            }
            const sev = this.closest('service-detail-100554');
            if (!sev)
                return;
            sev.openService('_100554_servicePreview', 'right', sev.level);
        }
        catch (e) {
            console.info(e);
        }
    }
};
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "script", void 0);
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "labelError", void 0);
__decorate([
    property({ type: String })
], CollabProcessTest.prototype, "labelOk", void 0);
__decorate([
    query('#txtScript')
], CollabProcessTest.prototype, "txtScript", void 0);
__decorate([
    query('#iptnamefunc')
], CollabProcessTest.prototype, "iptnamefunc", void 0);
__decorate([
    query('#checkintegration')
], CollabProcessTest.prototype, "checkintegration", void 0);
CollabProcessTest = __decorate([
    customElement('collab-process-test-100554')
], CollabProcessTest);
export { CollabProcessTest };
