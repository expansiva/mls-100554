import { MonacoDriver } from "/_100554_/l2/lessMonaco.js";
class LessAst {
  constructor(url, editor) {
    // Track the selector hierarchy
    this.stack = [];
    /**
     * parse a full LESS model (monaco editor)
     */
    this.parse = () => {
      const lines = this.monacoDriver.getLines(this.url);
      let lineNr = 0;
      for (const line of lines) {
        this.parseLine(++lineNr, line);
      }
    };
    /**
     * Parses a single line and updates the AST accordingly.
     */
    this.parseLine = (lineNr, line) => {
      line = line.replace(/(?<!:)\/\/.*|\/\*[\s\S]*?\*\//g, "");
      const tokenMatch = line.match(/^(@\S+)\s*:\s*(.+?)\s*;$/);
      if (tokenMatch) {
        const token = tokenMatch[1].trim();
        const value = tokenMatch[2].trim();
        this.ast.root[token] = {
          value,
          line: lineNr,
          column: line.indexOf(value)
        };
        return;
      }
      const selectorStartMatch = line.match(/^(.+?)\s*{\s*$/);
      if (selectorStartMatch) {
        const selector = selectorStartMatch[1].trim();
        const fullSelector = this.stack.length > 0 ? `${this.stack.join(" ")} ${selector}` : selector;
        this.stack.push(selector);
        if (!this.ast[fullSelector]) {
          this.ast[fullSelector] = {};
        }
        this.ast[fullSelector]._startLine = lineNr;
        return;
      }
      if (this.stack.length > 0) {
        const propertyMatch = line.trim().match(/^\s*(.+?)\s*:\s*(.+?)\s*;$/);
        if (propertyMatch) {
          const property = propertyMatch[1].trim();
          const value = propertyMatch[2].trim();
          const currentSelector = this.stack.join(" ");
          if (!this.ast[currentSelector]) {
            this.ast[currentSelector] = {};
          }
          this.ast[currentSelector][property] = {
            value,
            line: lineNr,
            column: this.findColumn(line, value) || line.lastIndexOf(value)
          };
          return;
        }
      }
      const selectorEndMatch = line.match(/^\s*}\s*$/);
      if (selectorEndMatch) {
        const currentSelector = this.stack.join(" ");
        if (this.ast[currentSelector]) {
          this.ast[currentSelector]._endLine = lineNr;
        }
        this.stack.pop();
      }
    };
    /**
     * Converts a full CSS selector back to the LESS format using "&" where appropriate.
     * - If the selector parts match a parent selector, it replaces the match with "&".
     * 
     * @param selector The CSS selector to convert to LESS format.
     * @returns The converted LESS format selector with "&" where possible.
     */
    this.selectorCSS2LESS = (selector) => {
      const parts = selector.split(" ");
      const result = [];
      for (const part of parts) {
        if (result.length > 0 && part.startsWith(result[result.length - 1])) {
          result.push("&" + part.substring(result[result.length - 1].length));
        } else {
          result.push(part);
        }
      }
      return result.join(" ");
    };
    // Converts a LESS selector with "&" to the full CSS format
    this.selectorLESS2CSS = (selector) => {
      return selector.replace(/&/g, this.stack.join(" "));
    };
    this.url = url;
    this.monacoDriver = new MonacoDriver(editor);
    this.ast = { root: {} };
    this.parse();
  }
  /**
   * Finds the column index where the given `value` starts in the provided `line`.
   *
   * This method calculates the precise position of the `value` in the string `line` 
   * after the first occurrence of a colon (`:`), considering any leading spaces. 
   * If the `value` is not found or the colon is absent, it returns undefined.
   *
   * @param {string} line - The line of text to be searched.
   * @param {string} value - The target string to locate within the `line`.
   * @returns {number} - The zero-based index of the starting position of `value` in `line`, 
   *                     or undefined if the colon or value is not found.
   *
   * @example
   * // Example 1:
   * const line = "        text-shadow: 3em -8em 3em;";
   * const value = "3em -8em 3em";
   * findColumn(line, value); // Returns: 23
   *
   * // Example 2:
   * const line = "        flex-wrap: wrap;";
   * const value = "wrap";
   * findColumn(line, value); // Returns: 21
   *
   * // Example 3:
   * const line = "invalid line without colon";
   * const value = "anything";
   * findColumn(line, value); // Returns: undefined
   */
  findColumn(line, value) {
    const colonIndex = line.indexOf(":");
    if (colonIndex === -1) return;
    const afterColon = line.slice(colonIndex + 1);
    const valueStartIndex = afterColon.indexOf(value);
    if (valueStartIndex === -1) return;
    return colonIndex + 1 + valueStartIndex;
  }
  /**
   * Lists all themes available in the AST.
   * Each theme is identified by its selector. If the selector has a `.`, the part after the dot is the theme name.
   * If no dot is present, the theme is named "default".
   * 
   * @returns An object where each key is a theme name (e.g., "default", "theme2") and each value is the corresponding selector.
   */
  listThemes() {
    const themes = {};
    for (const selector in this.ast) {
      if (selector === "root" || selector.includes(" ")) continue;
      const themeName = selector.includes(".") ? selector.split(".")[1] : "default";
      themes[themeName] = selector;
    }
    return themes;
  }
  /**
   * Adds a new theme to the specified component variation.
   * 
   * @param variation The name of the new theme variation (e.g., "theme3").
   * @returns `true` if the theme was added successfully, `false` otherwise.
   */
  addTheme(variation) {
    const themes = this.listThemes();
    const themeKeys = Object.keys(themes);
    if (themeKeys.length < 1) return false;
    let lastLine = 0;
    themeKeys.forEach((theme) => {
      const themeSelector = themes[theme];
      const themeData = this.ast[themeSelector];
      if (themeData && themeData._endLine !== void 0) {
        lastLine = Math.max(lastLine, themeData._endLine);
      }
    });
    const componentName = themes[themeKeys[0]].split(".")[0];
    const newThemeSelector = `${componentName}.${variation}`;
    if (this.ast[newThemeSelector]) {
      console.warn(`Theme '${variation}' already exists for ${componentName}.`);
      return false;
    }
    this.ast[newThemeSelector] = {
      _startLine: lastLine + 1,
      _endLine: lastLine + 2
    };
    this.monacoDriver.insertLine(this.url, lastLine + 1, ``);
    this.monacoDriver.insertLine(this.url, lastLine + 2, `${newThemeSelector} {`);
    this.monacoDriver.insertLine(this.url, lastLine + 3, `	// theme description`);
    this.monacoDriver.insertLine(this.url, lastLine + 4, `	display: inherit;`);
    this.monacoDriver.insertLine(this.url, lastLine + 5, `}`);
    this.monacoDriver.finishEdit(this.url);
    this.updateASTAfterInsertLine(lastLine, 5);
    return true;
  }
  /**
   * Deletes a theme from the specified component variation.
   * 
   * @param variation The name of the theme variation to delete (e.g., "theme2").
   * If `null`, deletes the "default" theme (the main component selector).
   * @returns `true` if the theme was deleted successfully, `false` otherwise.
   */
  deleteTheme(variation) {
    const { startLine, endLine, themeSelector } = this.getThemeRangeLines(variation);
    if (startLine === void 0 || endLine === void 0) return false;
    const linesToDelete = endLine - startLine + 1;
    this.monacoDriver.deleteLines(this.url, startLine, linesToDelete);
    delete this.ast[themeSelector];
    this.updateASTAfterInsertLine(startLine, -linesToDelete);
    return true;
  }
  /**
   * Retrieves the description comments for a specified theme.
   * 
   * @param variation The name of the theme variation (e.g., "theme2").
   *                  If `null`, retrieves the "default" theme.
   * @returns An array of comment lines that describe the theme, or an empty array if no comments are found.
   */
  getThemeDescription(variation) {
    const { startLine, endLine } = this.getThemeRangeLines(variation);
    if (startLine === void 0 || endLine === void 0) return [];
    const lines = this.monacoDriver.getLines(this.url);
    const themeLines = lines.slice(startLine, endLine);
    const description = [];
    for (const line of themeLines) {
      const trimmedLine = line.trim();
      if (!trimmedLine.startsWith("//")) break;
      description.push(trimmedLine.replace(/^\/\//, "").trim());
    }
    return description;
  }
  getThemeRangeLines(variation) {
    const themes = this.listThemes();
    const themeName = variation ?? "default";
    const themeSelector = themes[themeName];
    if (!themeSelector || !this.ast[themeSelector]) {
      console.warn(`Theme ${themeName} does not exist.`);
      return { startLine: void 0, endLine: void 0, themeSelector: "" };
    }
    const themeData = this.ast[themeSelector];
    return {
      startLine: themeData._startLine,
      endLine: themeData._endLine,
      themeSelector
    };
  }
  /**
   * Converts a kebab-case property name to camelCase, e.g., background-color to backgroundColor.
   * This ensures property names align with JavaScript/TypeScript conventions.
   */
  toCamelCaseProperty(property) {
    return property.replace(/-([a-z])/g, (_, char) => char.toUpperCase());
  }
  /**
   * Converts a camelCase property name to kebab-case, e.g., backgroundColor to background-color.
   * This ensures property names align with CSS/LESS conventions.
   */
  toKebabCaseProperty(property) {
    return property.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
  }
  getProperty(selector, property) {
    property = this.toKebabCaseProperty(property);
    const prop = this.ast[selector]?.[property];
    if (typeof prop === "number") return prop.toString();
    return typeof prop === "object" && prop !== null ? prop.value : void 0;
  }
  updateASTAfterInsertLine(lineNrInserted, linesInserted) {
    for (const selector in this.ast) {
      const selectorData = this.ast[selector];
      if (selectorData._startLine !== void 0 && selectorData._startLine > lineNrInserted) {
        selectorData._startLine += linesInserted;
      }
      if (selectorData._endLine !== void 0 && selectorData._endLine > lineNrInserted) {
        selectorData._endLine += linesInserted;
      }
      for (const property in selectorData) {
        const propData = selectorData[property];
        if (propData && typeof propData === "object" && propData.line > lineNrInserted) {
          propData.line += linesInserted;
        }
      }
    }
  }
  saveProperty(selector, property, newValue) {
    property = this.toKebabCaseProperty(property);
    const prop = this.ast[selector]?.[property];
    if (!prop) {
      if (!newValue) return false;
      let lineNr;
      if (!this.ast[selector]) {
        lineNr = this.insertSelector(selector) + 1;
      } else {
        lineNr = this.findLastLineInSelector(selector);
      }
      const parts = selector.split(" ");
      const indentation = "	".repeat(parts.length);
      this.ast[selector][property] = {
        value: newValue,
        line: lineNr,
        column: `${property}: `.length + indentation.length
      };
      this.updateASTAfterInsertLine(lineNr, 1);
      return this.monacoDriver.insertLine(this.url, lineNr, `${indentation}${property}: ${newValue};`);
    }
    if (typeof prop !== "object") return false;
    newValue = newValue?.split(";")[0] || "";
    if (!newValue) {
      if (!this.ast[selector][property]) return false;
      const lineNr = prop.line;
      delete this.ast[selector][property];
      this.updateASTAfterInsertLine(prop.line, -1);
      return this.monacoDriver.deleteLine(this.url, lineNr);
    }
    if (prop.value === newValue) return false;
    prop.value = newValue;
    if (!newValue.endsWith(";")) newValue = newValue + ";";
    return this.monacoDriver.updateLine(this.url, prop.line, prop.column + 1, newValue);
  }
  /**
   * Returns the last line number within a selector block. aka "}"
   */
  findLastLineInSelector(selectorLESS) {
    if (!this.ast[selectorLESS]) return 1;
    return this.ast[selectorLESS]._endLine || 1;
  }
  findInfoByLine(selectorLESS, lineNumber) {
    if (!this.ast[selectorLESS]) return void 0;
    const keyProps = Object.keys(this.ast[selectorLESS]);
    const key = keyProps.find((prop) => this.ast[selectorLESS][prop]?.line === lineNumber);
    if (!key) return void 0;
    return {
      key,
      value: this.ast[selectorLESS][key].value
    };
  }
  /**
   * Finds the most specific LESS selector path for a given line number in the source.
   * - This method searches the AST to determine the most specific selector block containing the specified line.
   * - It returns the full path of the most deeply nested selector in LESS format (e.g., `.cl1 .cl2 &:hover`).
   * 
   * ### Usage
   * This method is useful for identifying the exact selector block a line belongs to, especially
   * in scenarios where nested selectors exist in the LESS structure.
   * 
   * @param lineNr The line number to check for a corresponding selector.
   * @returns The most specific LESS selector path as a string if found; otherwise, `undefined`.
   */
  findSelectorByLine(lineNr) {
    let mostSpecificSelector = void 0;
    let maxDepth = -1;
    for (const selector in this.ast) {
      const selectorData = this.ast[selector];
      if (selectorData._startLine && selectorData._startLine <= lineNr && selectorData._endLine && selectorData._endLine >= lineNr) {
        const depth = selector.split(" ").length;
        if (depth > maxDepth) {
          maxDepth = depth;
          mostSpecificSelector = selector;
        }
      }
    }
    return mostSpecificSelector;
  }
  /**
   * Finds the start line of the first selector after the root in a JSON representation of a stylesheet.
   * 
   * @param json - A JSON object representing a stylesheet, where keys are selectors and values contain metadata.
   * @param tagName - The tag name to exclude from the search.
   * @returns The start line of the first selector after the root, or `null` if no such selector exists.
   */
  findFirstSelectorAfterRoot(ast) {
    const rootEndLine = ast.root?._endLine ?? 0;
    let closestSelector = null;
    for (const [key, value] of Object.entries(ast)) {
      if (key === "root") continue;
      if (value._startLine > rootEndLine) {
        if (!closestSelector || value._startLine < ast[closestSelector]._startLine) {
          closestSelector = key;
        }
      }
    }
    return closestSelector ? ast[closestSelector]._startLine : null;
  }
  /**
   * Inserts a new selector into the AST and the Monaco model if it does not exist.
   * - Example: If the AST only contains ".cl1" and `newSelectorLESS` is ".cl1 .cl2 &:hover",
   *   the function will:
   *   1. Check if ".cl1 .cl2" exists in the AST.
   *   2. If not, insert ".cl2" as a nested block within ".cl1".
   *   3. Then insert "&:hover" as a nested selector inside ".cl1 .cl2".
   * 
   * This function supports nested selectors by iteratively checking each level
   * and inserting any missing selectors in sequence.
   * 
   * @param newSelectorLESS The LESS selector to add to the AST and source code.
   * @result start line of the block
   */
  insertSelector(newSelectorLESS) {
    let startLine = 0;
    const parts = newSelectorLESS.split(" ");
    let currentSelector = "";
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      currentSelector = currentSelector ? `${currentSelector} ${part}` : part;
      if (!this.ast[currentSelector]) {
        let insertPoint = this.findLastLineInSelector(currentSelector.split(" ").slice(0, -1).join(" ") || "root");
        insertPoint = insertPoint > 0 ? insertPoint : startLine + 1;
        const indentation = "	".repeat(i);
        this.monacoDriver.insertLine(this.url, insertPoint, `${indentation}${part} {`);
        this.monacoDriver.insertLine(this.url, insertPoint + 1, `${indentation}}`);
        startLine = insertPoint;
        this.updateASTAfterInsertLine(startLine, 2);
        this.ast[currentSelector] = {
          _startLine: startLine,
          _endLine: startLine + 1
        };
      } else {
        startLine = this.findLastLineInSelector(currentSelector);
      }
    }
    return startLine;
  }
}
export {
  LessAst
};
