/// <mls fileReference="_100554_/l2/agentBotWeddingGifts.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/agentBotWeddingGifts.ts",
        "componentType": "agent",
        "componentScope": "editor",
        "languages": [
            "pt"
        ],
        "group": "enhancement"
    },
    "references": {
        "imports": [
            {
                "ref": "/_100554_/l2/aiAgentBase.js",
                "dependencies": [
                    {
                        "name": "IAgent",
                        "type": "interface"
                    },
                    {
                        "name": "svg_agent",
                        "type": "constant"
                    }
                ]
            },
            {
                "ref": "/_100554_/l2/aiPrompts.js",
                "dependencies": [
                    {
                        "name": "getPromptByHtml",
                        "type": "function"
                    }
                ]
            },
            {
                "ref": "/_100554_/l2/widgetQuestionsForClarification.js"
            },
            {
                "ref": "/_100554_/l2/aiAgentHelper.js",
                "dependencies": [
                    {
                        "name": "getNextInProgressStepByAgentName",
                        "type": "function"
                    },
                    {
                        "name": "notifyTaskChange",
                        "type": "function"
                    },
                    {
                        "name": "notifyThreadChange",
                        "type": "function"
                    },
                    {
                        "name": "updateStepStatus",
                        "type": "function"
                    }
                ]
            },
            {
                "ref": "/_102025_/l2/collabMessagesHelper.js",
                "dependencies": [
                    {
                        "name": "addMessage",
                        "type": "function"
                    }
                ]
            },
            {
                "ref": "/_100554_/l2/aiAgentOrchestration.js",
                "dependencies": [
                    {
                        "name": "startNewAiTask",
                        "type": "function"
                    },
                    {
                        "name": "executeNextStep",
                        "type": "function"
                    }
                ]
            }
        ]
    },
    "asIs": {
        "semantic": {
            "generalDescription": "Agent Bot, for gifts management",
            "businessCapabilities": [
                "Planning..."
            ],
            "technicalCapabilities": [
                "AI agent orchestration"
            ],
            "implementedFeatures": [
                "_beforePrompt",
                "_afterPrompt",
                "_installBot",
                "_beforeBot"
            ]
        }
    }
};
