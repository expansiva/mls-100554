/// <mls fileReference="_100554_/l2/pluginOrganismProperty.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
