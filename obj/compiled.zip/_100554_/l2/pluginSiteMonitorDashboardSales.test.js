/// <mls fileReference="_100554_/l2/pluginSiteMonitorDashboardSales.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
