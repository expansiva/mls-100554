var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
const message_pt = {
  inDev: "Em desenvolvimento!"
};
const message_en = {
  inDev: "In develpoment"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let PluginOrganisAdd = class extends CollabLitElement {
  render() {
    return html`In development`;
  }
};
PluginOrganisAdd = __decorateClass([
  customElement("plugin-organism-property-100554")
], PluginOrganisAdd);
export {
  PluginOrganisAdd
};
