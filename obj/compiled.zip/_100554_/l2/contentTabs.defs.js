"use strict";
/// <mls shortName="contentTabs" project="100554" enhancement="_blank" folder="" />
