/// <mls fileReference="_100554_/l2/pluginPageProperties.ts" enhancement="_100554_enhancementLit" />
import { html, repeat } from "lit";
import { PluginBaseModule } from "/_100554_/l2/pluginBaseModule.js";
const message_pt = {
  noItens: "Nenhum item ICA foi encontrado!"
};
const message_en = {
  noItens: "No ICA items were found!"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
class PluginPageProperties extends PluginBaseModule {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-page-properties-100554 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-normal);
  line-height: 1.5;
  color: var(--text-primary-color);
  background-color: var(--bg-primary-color);
}
`);
    this.msg = messages["en"];
    this.elementAttributes = [];
  }
  shouldUpdate(changedProperties) {
    super.shouldUpdate(changedProperties);
    this.setServicePreview();
    return true;
  }
  createRenderRoot() {
    return this;
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    this.getMyAttributes();
    if (this.elementAttributes && this.elementAttributes.length > 0) return this.createItens();
    return html`<h3 style="padding:1rem">${this.msg.noItens}<h3>`;
  }
  createItens() {
    const obj = html`
            <ul>
                ${repeat(
      this.elementAttributes,
      ((key, idx) => key.key + idx),
      ((item, index) => {
        return this.renderItem(item, index);
      })
    )}
            </ul>
        `;
    return obj;
  }
  renderItem(item, idx) {
    return html`
            <li>
                <span>${item.key}</span>
                <input type="text" value="${item.value}"></input>
            </li>
        `;
  }
  //-------- IMPLEMENTATION --------------
  forceUpdate() {
    this.requestUpdate();
  }
  setServicePreview() {
    if (this.servicePreview || !this.service) return;
    const nav3 = this.service.nav3Service;
    if (!nav3) return;
    const wc = nav3.getActiveInstance("right");
    if (!wc) return;
    if (wc.tagName.toLowerCase() === "service-preview-100554") {
      this.servicePreview = wc;
    }
  }
  getMyAttributes() {
    this.elementAttributes = [];
    if (!this.servicePreview || !this.servicePreview.serviceContent) return;
    const pvv = this.servicePreview.serviceContent.querySelector("service-preview-view-100554");
    if (!pvv || !pvv.shadowRoot) return;
    const iframe = pvv.shadowRoot.querySelector("iframe");
    if (!iframe || !iframe.contentDocument) return;
    const wcd = iframe.contentDocument.body.querySelector("wcd-toolbox-100554");
    if (!wcd) return;
    const parent = wcd.parentElement;
    if (!parent || !parent.info) return;
    const attrs = parent.info.element.getAtributtes();
    const ret = [];
    attrs.forEach((i) => {
      ret.push({
        key: i,
        value: parent.info.element.getAttribute(i)
      });
    });
    this.elementAttributes = ret;
  }
}
if (!customElements.get("plugin-page-properties-100554")) {
  customElements.define("plugin-page-properties-100554", PluginPageProperties);
}
export {
  PluginPageProperties
};
