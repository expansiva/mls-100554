/// <mls fileReference="_100554_/l2/servicePage.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { openService, saveOpenedFile } from '/_102027_/l2/libCommom.js';
import "/_100554_/l2/pluginPrototypeImprove.js";
import "/_100554_/l2/pluginExploreList.js";
import "/_100554_/l2/pluginPageNavigation.js";
/// **collab_i18n_start**
const message_pt = {
    detailsHint: 'Detalhes do objeto selecionado na página, - help , - ajustes widget como mutations (ica), - ajustes dinâmicos (wcd) , por favor selecione um item na página',
    selectPlugin: 'Por favor selecione um plugin IA',
    loading: 'Carregando...'
};
const message_en = {
    detailsHint: 'Details of the selected object on the page, - help , - widget settings like mutations (ica), - dynamic settings (wcd), please select an item on the page',
    selectPlugin: 'Please select a plugin IA',
    loading: 'Loading...'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServicePage100554 = class ServicePage100554 extends ServiceBase {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-page-100554 {
  display: block;
  overflow-y: auto !important;
  overflow-x: hidden !important;
  position: relative;
}
`);
        this.msg = messages['en'];
        this.activeTab = 'icNavigation';
        this.previousTabIndex = 1;
        this.path = '';
        //-------SERVICE---------------
        this.details = {
            icon: '&#xf15b',
            state: 'background',
            position: 'right',
            tooltip: 'Page',
            visible: true,
            widget: '_100554_servicePage',
            level: [5]
        };
        this.menu = {
            title: '',
            main: {
                opAboutThis: 'About this content',
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: -1,
                mode: 'compact',
                effect: 'slide',
                options: [
                    { text: 'Explore', icon: 'e521' },
                    { text: 'Navigation', icon: 'f041' },
                    { text: 'Improve', icon: 'f5dc' },
                ]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
            onClickTabsNavigation: this.onClickTabsNavigation.bind(this),
        };
        this.previousTab = 'icNavigation';
        mls.events.addListener(4, 'FileAction', this.onFileAction.bind(this));
        mls.events.addListener(4, 'L4EditEvents', this.onL4EditEvents.bind(this));
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabsNavigation(index, oldEl, newEl) {
        this.activeTab = ESceneries[index];
        if (this.activeTab === 'icNavigation') {
            const el = this.querySelector('plugin-page-navigation-100554');
            if (el && el.firstUpdated)
                el.firstUpdated();
        }
    }
    onClickTabs(index) {
        if (this.menu && this.menu.tabNavigate && this.menu.tabs?.selected !== undefined) {
            this.activeTab = ESceneries[index];
            const previousIndex = this.menu.tabs.previous !== undefined ? this.menu.tabs.previous : this.menu.tabs.selected;
            const oldTab = this.querySelector(`.tab-index-${previousIndex}`);
            const newTab = this.querySelector(`.tab-index-${index}`);
            this.previousTabIndex = index;
            this.menu.tabNavigate(index, oldTab, newTab);
        }
    }
    onServiceClick(visible, reinit, el) {
        if (!visible)
            return;
        if (this.activeTab === 'icNavigation') {
            const el = this.querySelector('plugin-page-navigation-100554');
            if (el && el.firstUpdated)
                el.firstUpdated();
        }
        const tab = this.getAttribute('tab');
        if (tab &&
            tab === 'navigation' &&
            this.activeTab !== 'icNavigation' &&
            this.menu &&
            this.menu.setTabActive &&
            this.menu.onClickTabs &&
            this.menu.tabBack) {
            this.removeAttribute('tab');
            if (ESceneries[this.activeTab] > ESceneries.icNavigation) {
                this.menu.tabBack();
            }
            else
                this.menu.setTabActive(ESceneries.icNavigation);
        }
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'nothing selected';
        switch (this.activeTab) {
            case 'icExplorer':
                name = 'plugin-explore-list-100554';
                break;
            case 'icNavigation':
                name = 'plugin-page-navigation-100554';
                break;
            case 'icImprove':
                name = 'plugin-prototype-improve-100554';
                break;
            default:
                name = 'nothing selected';
        }
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
		

        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    //-------COMPONENT--------------
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(ESceneries.icExplorer);
        setTimeout(() => { if (this.menu.setTabActive)
            this.menu.setTabActive(ESceneries.icNavigation); }, 50);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        return html `
            <div>
                <div class="tab-content tab-index-${ESceneries.icExplorer}" style="display:none" >
                    ${this.renderExplorer()}
                </div>
                <div class="tab-content tab-index-${ESceneries.icNavigation}" style="display:none">
                    ${this.renderNavigation()}
                </div>
                <div class="tab-content tab-index-${ESceneries.icImprove}" style="display:none">
                    ${this.renderImprove()}
                </div>
            </div>
  `;
    }
    renderNavigation() {
        return html `<plugin-page-navigation-100554 @item-selected=${this.onSelectItemNavigation}></plugin-page-navigation-100554>`;
    }
    renderExplorer() {
        return html `<plugin-explore-list-100554 autoprepare="true" .service=${this}></plugin-explore-list-100554>`;
    }
    renderImprove() {
        return html `<plugin-prototype-improve-100554></plugin-prototype-improve-100554>`;
    }
    onFileAction(ev) {
        if (ev.level !== 4 || (ev.type !== 'FileAction'))
            return;
        if (this.menu && this.menu.tabNavigate) {
            const oldTab = this.querySelector(`.tab-index-${this.menu.tabs?.selected}`);
            const newTab = this.querySelector(`.tab-index-${ESceneries.icNavigation}`);
            this.menu.tabNavigate(ESceneries.icNavigation, oldTab, newTab);
        }
    }
    onSelectItemNavigation() {
        if (this.menu && this.menu.tabNavigate) {
            const oldTab = this.querySelector(`.tab-index-${this.menu.tabs?.selected}`);
            const newTab = this.querySelector(`.tab-index-${ESceneries.icImprove}`);
            this.menu.tabNavigate(ESceneries.icImprove, oldTab, newTab);
        }
    }
    onL4EditEvents(ev) {
        if (!ev.desc || ev.level !== 4)
            return;
        const info = JSON.parse(ev.desc);
        if (!info || !info.action || !info.position || info.position === 'left')
            return;
        switch (info.action) {
            case ('openL3'):
                this.onOpenL3(info);
                break;
            default: '';
        }
    }
    onOpenL3(info) {
        if (!info.folder || !info.project || !info.shortName)
            return;
        const { folder, project, shortName } = info;
        const fullName = folder ? `_${project}_${folder}/${shortName}` : `_${project}_${shortName}`;
        mls.actual[3].setFullName(fullName);
        saveOpenedFile(project, 3, fullName);
        // selectLevel(3);
        setTimeout(() => { openService('_100554_serviceOrganism', 'left', 3, { "tab": "navigation" }); }, 500);
    }
};
__decorate([
    property()
], ServicePage100554.prototype, "activeTab", void 0);
__decorate([
    state()
], ServicePage100554.prototype, "previousTabIndex", void 0);
__decorate([
    state()
], ServicePage100554.prototype, "path", void 0);
ServicePage100554 = __decorate([
    customElement('service-page-100554')
], ServicePage100554);
export { ServicePage100554 };
var ESceneries;
(function (ESceneries) {
    ESceneries[ESceneries["icExplorer"] = 0] = "icExplorer";
    ESceneries[ESceneries["icNavigation"] = 1] = "icNavigation";
    ESceneries[ESceneries["icImprove"] = 2] = "icImprove";
})(ESceneries || (ESceneries = {}));
