/// <mls fileReference="_100554_/l2/pluginBaseModule.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
