/// <mls fileReference="_100554_/l2/pluginLessPseudo.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
