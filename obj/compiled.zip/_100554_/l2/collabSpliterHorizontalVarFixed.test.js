/// <mls fileReference="_100554_/l2/collabSpliterHorizontalVarFixed.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
