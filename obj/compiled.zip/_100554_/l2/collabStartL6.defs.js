const asis = {
  "meta": {
    "fileReference": "_100554_/l2/collabStartL6.ts",
    "componentType": "molecule",
    "componentScope": "appFrontEnd",
    "languages": [
      "en",
      "pt"
    ],
    "group": "enhancement"
  },
  "references": {
    "imports": [
      {
        "ref": "lit",
        "dependencies": [
          {
            "name": "html",
            "type": "function"
          }
        ]
      },
      {
        "ref": "lit/decorators.js",
        "dependencies": [
          {
            "name": "customElement",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/stateLitElement.js",
        "dependencies": [
          {
            "name": "StateLitElement",
            "type": "class"
          }
        ]
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Module L6 - Owner: Features",
      "businessCapabilities": [
        "Dashboard de Projetos: Vis\xE3o geral de todos os projetos, seu status e m\xE9tricas relevantes.",
        "Dashboard do Uso do Aplicativo: M\xE9tricas de uso do aplicativo, como n\xFAmero de usu\xE1rios ativos, funil de convers\xE3o, etc",
        "Dashboard do Custo de Desenvolvimento: Informa\xE7\xF5es financeiras relacionadas ao custo de desenvolvimento do projeto.",
        "Dashboard do Custo de Hospedagem: Custos associados \xE0 infraestrutura e hospedagem do aplicativo.",
        "Project Dashboard: Overview of all projects, their status, and relevant metrics.",
        "Application Usage Dashboard: Metrics related to app usage, such as the number of active users, conversion funnel, etc.",
        "Development Cost Dashboard: Financial information about the project\u2019s development costs.",
        "Hosting Cost Dashboard: Costs associated with the application\u2019s infrastructure and hosting."
      ],
      "technicalCapabilities": [],
      "implementedFeatures": [
        "Fluxo de Uso",
        "Exemplos de Prompts para Iniciar Projetos via IA",
        "Usage Flow",
        "Examples of Prompts to Start Projects via AI"
      ]
    }
  }
};
export {
  asis
};
