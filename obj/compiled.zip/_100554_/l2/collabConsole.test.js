/// <mls fileReference="_100554_/l2/collabConsole.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
