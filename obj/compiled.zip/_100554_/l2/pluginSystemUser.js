/// <mls fileReference="_100554_/l2/pluginSystemUser.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
/// **collab_i18n_start**
const message_pt = {
    develpoment: 'Em desenvolvimento',
    alterarLabel: 'Alterar',
};
const message_en = {
    develpoment: 'In Develpoment',
    alterarLabel: 'Change',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const pluginData = {
    title: "User Preferencies",
    getSvg() {
        return svg `
        <svg width="22px" height="22px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M224 256A128 128 0 1 0 224 0a128 128 0 1 0 0 256zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512l388.6 0c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304l-91.4 0z"/></svg>
    `;
    }
};
let PluginSystemLanguage100554 = class PluginSystemLanguage100554 extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.autoPrepare = false;
        this.consoleEnabled = false;
    }
    firstUpdated() {
        if (!this.autoPrepare)
            return;
        this.prepare();
    }
    async prepare() {
        await this.init();
    }
    async init() {
        const collabConsole = document.querySelector('collab-console');
        if (collabConsole) {
            const show = collabConsole.getAttribute('show') === 'true';
            this.consoleEnabled = show;
        }
    }
    onChangeConsoleEnabled() {
        const collabConsole = document.querySelector('collab-console');
        if (collabConsole && this.inputConsole) {
            collabConsole.setAttribute('show', `${this.inputConsole.checked ? 'true' : 'false'}`);
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<div style="display:flex;align-items:center;">
            <label for="console-input"> Enable develpoment console</label>
            <input @change=${this.onChangeConsoleEnabled} .checked=${this.consoleEnabled} id="console-input" style="cursor:pointer;" type="checkbox"></input>
        </div>`;
    }
};
__decorate([
    property({ type: Boolean })
], PluginSystemLanguage100554.prototype, "autoPrepare", void 0);
__decorate([
    property({ type: Boolean })
], PluginSystemLanguage100554.prototype, "consoleEnabled", void 0);
__decorate([
    query('#console-input')
], PluginSystemLanguage100554.prototype, "inputConsole", void 0);
PluginSystemLanguage100554 = __decorate([
    customElement('plugin-system-user-100554')
], PluginSystemLanguage100554);
export { PluginSystemLanguage100554 };
