/// <mls fileReference="_100554_/l2/serviceDashboard.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { getConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { loadPluginProject } from '/_102027_/l2/libCommom.js';
import '/_100554_/l2/collabTiles.js';
let ServiceDashboard100554 = class ServiceDashboard100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        this.msize = '';
        this.cssBreakPoint = '';
        this.activeTab = 'Icon1';
        //------SERVICE----------
        this.details = {
            icon: '&#xf201',
            state: 'foreground',
            position: 'left',
            tooltip: 'Dashboard',
            visible: true,
            widget: '_100554_serviceDashboard',
            level: [6]
        };
        this.menu = {
            title: '',
            main: {
                opAboutThis: 'About this content',
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: [
                    { text: 'Example 1', icon: 'f0e8' },
                    { text: 'Example 2', icon: 'f0e8' },
                ]
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.refreshTimeOut = 0;
        //------------IMPLEMENTATION---------------
        this.pluginsDash1 = [];
        this.pluginsDash2 = [];
        this.baseProject = 100554;
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        this.activeTab = ESceneries[index];
    }
    onServiceClick(visible, reinit, el) {
        if (!visible) {
            const el = this.shadowRoot?.querySelector('collab-tiles-100554');
            if (!el)
                return;
            const config = el.getAttribute('config');
            if (config === 'close' || !el.onlyclose)
                return;
            el.onlyclose();
        }
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'collab-tiles-100554';
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
		

        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    //---------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    firstUpdated() {
        this.loadAndSetPlugins();
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible)
                return;
            const [w, h] = this.msize.split(',');
            if (w && +w < 800)
                this.cssBreakPoint = 'break-800';
            else if (w && +w > 800)
                this.cssBreakPoint = '';
            if (this.refreshTimeOut)
                window.clearTimeout(this.refreshTimeOut);
            this.refreshTimeOut = window.setTimeout(() => {
                this.shadowRoot?.querySelectorAll('collab-tiles-item-100554 collabtileitemcontent').forEach((item) => {
                    Array.from(item.children).forEach((plugin) => {
                        const root = plugin.shadowRoot || plugin;
                        root.querySelectorAll('wc-chart-100554').forEach((chart) => {
                            if (chart.myChart && chart.myChart.resize)
                                chart.myChart.resize();
                        });
                    });
                });
            }, 500);
        }
    }
    render() {
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'Example1':
                return this.renderIcon1();
            case 'Example2':
                return this.renderIcon2();
            default:
                return html ``;
        }
    }
    renderIcon1() {
        if (this.pluginsDash1.length <= 0)
            return html `<h3 style="padding:2rem">Not found plugins</h3>`;
        return html `<collab-tiles-100554 .tilesItens=${this.pluginsDash1} example="1" class="${this.cssBreakPoint}"></collab-tiles-100554>`;
    }
    renderIcon2() {
        if (this.pluginsDash2.length <= 0)
            return html `<h3 style="padding:2rem">Not found plugins</h3>`;
        return html `<collab-tiles-100554 .tilesItens=${this.pluginsDash2} example="2" class="${this.cssBreakPoint}"></collab-tiles-100554>`;
    }
    async loadAndSetPlugins() {
        const prj = mls.actualProject;
        if (!prj)
            return;
        const dash = "l6Dashboard";
        const arry = await loadPluginProject(prj, dash);
        const config = await getConfigProject(prj);
        arry.forEach((i, index) => {
            const item = {
                title: 'Tile_' + index,
                plugin: i.widget,
                position: '2 2',
                index: '99',
                enabled: 'true',
                widgetConfig: ''
            };
            const infoPlugin = this.getInfoPlugin(config, i.widgetConfig, i.widget, i.category);
            item.position = infoPlugin.pos;
            item.index = infoPlugin.index;
            item.enabled = infoPlugin.enabled;
            item.widgetConfig = infoPlugin.widgetConfig;
            switch (i.category) {
                case 'Examples 1': {
                    this.pluginsDash1.push(item);
                    break;
                }
                case 'Examples 2': {
                    this.pluginsDash2.push(item);
                    break;
                }
                default: '';
            }
        });
        this.pluginsDash1.sort((a, b) => {
            return Number(a.index) - Number(b.index);
        });
        this.pluginsDash2.sort((a, b) => {
            return Number(a.index) - Number(b.index);
        });
        this.requestUpdate();
    }
    getInfoPlugin(config, widgetConfig, widget, cat) {
        const ret = { index: '99', enabled: 'true', pos: '2 2', widgetConfig: '' };
        if (!config || !widgetConfig || !cat)
            return ret;
        const plugin = config.plugins;
        widgetConfig = '_' + widgetConfig.replace('2_', '').replace('.ts', '');
        ret.widgetConfig = widgetConfig;
        if (!plugin[widgetConfig] || !plugin[widgetConfig][widget] || !plugin[widgetConfig][widget]["l6Dashboard"] || !plugin[widgetConfig][widget]["l6Dashboard"][cat])
            return ret;
        const pos = plugin[widgetConfig][widget]["l6Dashboard"][cat].replace('tile', '').trim();
        const a = pos.split(' ');
        if (a.length < 3)
            ret.pos = a.join(' ');
        else {
            ret.index = a.pop();
            ret.pos = a.join(' ');
        }
        ret.enabled = plugin[widgetConfig][widget].enabled;
        return ret;
    }
};
__decorate([
    property()
], ServiceDashboard100554.prototype, "msize", void 0);
__decorate([
    property()
], ServiceDashboard100554.prototype, "cssBreakPoint", void 0);
__decorate([
    property()
], ServiceDashboard100554.prototype, "activeTab", void 0);
ServiceDashboard100554 = __decorate([
    customElement('service-dashboard-100554')
], ServiceDashboard100554);
export { ServiceDashboard100554 };
var ESceneries;
(function (ESceneries) {
    ESceneries[ESceneries["Example1"] = 0] = "Example1";
    ESceneries[ESceneries["Example2"] = 1] = "Example2";
})(ESceneries || (ESceneries = {}));
