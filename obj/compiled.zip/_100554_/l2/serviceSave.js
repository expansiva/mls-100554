/// <mls fileReference="_100554_/l2/serviceSave.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { collab_branch } from '/_100554_/l2/collabIcons.js';
import { undoFile, removeNewStorFilesWithTemplateDefault } from '/_102027_/l2/libStor.js';
import { initServiceSaveaddBranch } from '/_100554_/l2/saveAddBranch.js';
import { getMyKeysBranch, calculateTotalStringSize } from '/_102027_/l2/libCommom.js';
import { getConfigProject, updateConfigProject } from '/_102027_/l2/libProjectConfig.js';
import { readProjectTypescriptAndCompile } from '/_102027_/l2/libModel.js';
import '/_100554_/l2/pluginCreateProjectLocalToDriver.js';
initServiceSaveaddBranch();
/// **collab_i18n_start**
const message_pt = {
    openPullrequest: 'Pull request Abertos',
    needComment: 'Precisa de um comentario para o pullrequest',
    updateChanges: 'Atualizar alterações',
    comments: 'Comentários',
    update: 'Atualizar',
    fileChanges: 'Alterações de arquivos',
    noItemsToSave: 'Sem itens para salvar.',
    msgPullRequest: 'Este projeto utiliza pull requests, todas as alterações serão salvas no branch do seu usuário, para criar um pull request clique no botão',
    createPullRequest: "Criar pull request",
    create: 'Criar',
    cancel: 'Cancelar',
    title: 'Titulo',
    errorCreatePull: 'Erro ao tentar criar pull request',
    msgBlockAll: 'Você não tem acesso a este repositorio, por fvor entre em contato com o admin do projeto',
    msgBlock: 'Você não tem acesso de escrita neste repositorio, caso deseje criar um fork clique no botão abaixo',
    pullrequestOk: 'Pull request realizado com sucesso',
    msgAllSynced: 'Tudo já está sincronizado — pull request desnecessário (os arquivos deletados já não existem no repositório remoto).',
    errorVerify: 'Foi encontrado arquivos com erros',
    obsVerify: 'O salvamento só será permitido se não houver arquivos com erros ou se a verificação for cancelada!',
    msgTotFile: 'Tamanho total dos arquivos selecionados:',
    msgErroTotFile: 'Excedeu o tamanho total permitido',
    msgErrorFilesSelected: 'Arquivos com erro foram selecionados, deseja realmente continuar?',
    sync: 'Sinc',
    msgSync: 'Deseja realmente sincronizar? Suas alterações do projeto [prj] serão todas perdidas.',
    select: 'Selecionar',
    selected: 'Selecionado'
};
const message_en = {
    openPullrequest: 'Open pull requests',
    needComment: 'Need a comment for the pullrequest',
    updateChanges: 'Update Changes',
    comments: 'Comments',
    update: 'Update',
    fileChanges: 'File Changes',
    noItemsToSave: 'No items to save',
    msgPullRequest: 'This project uses pull requests, all changes will be saved in your user\'s branch, to create a pull request click the button',
    createPullRequest: "Create pull request",
    create: 'Create',
    cancel: 'Cancel',
    title: 'Title',
    errorCreatePull: 'Error when trying to create pull request',
    msgBlockAll: 'You do not have access to this repository, please contact the project admin',
    msgBlock: 'You do not have write access to this repository, if you wish to create a fork click the button below',
    pullrequestOk: 'Pull request completed successfully',
    msgAllSynced: 'Everything is already in sync — pull request not needed (the deleted files no longer exist in the remote repository).',
    errorVerify: 'Files with errors were found',
    obsVerify: 'Saving will only be allowed if there are no files with errors, or the check is cancelled!',
    msgTotFile: 'Total size of selected files:',
    msgErroTotFile: 'Exceeded the total size allowed',
    msgErrorFilesSelected: 'Files with errors are selected, do you really want to continue?',
    sync: 'Sync',
    msgSync: 'Do you really want to synchronize? All your project [prj] changes will be lost.',
    select: 'Select',
    selected: 'Selected'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceSave = class ServiceSave extends ServiceBase {
    createRenderRoot() {
        return this;
    }
    get currentProject() {
        return this.selectedProject !== undefined ? this.selectedProject : mls.actualProject;
    }
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-save-100554 {
  font-family: var(--font-family-primary);
  font-size: var(--font-size-20);
  display: block;
  overflow-y: auto;
}
service-save-100554 .errorLocal {
  text-decoration: line-through;
  color: red;
}
service-save-100554 button.btn-service-save {
  background-color: var(--surface-alt-bg);
  border-radius: 8px;
  border: none;
  box-shadow: 0px 1px 3px 0px var(--border-subtle);
  display: flex;
  flex-direction: row;
  justify-content: center;
  gap: 0.2rem;
  font-weight: 700;
  align-items: center;
  height: 40px;
  transition: height 0.3s cubic-bezier(0.25, 0.1, 0.25, 1);
  padding: 0.5rem;
  color: var(--text-default);
  cursor: pointer;
}
service-save-100554 button.btn-service-save:hover {
  background-color: var(--surface-alt-bg);
}
service-save-100554 .header-save {
  display: flex;
  gap: 1rem;
  font-size: 0.95rem;
  border-bottom: 1px solid #e2e1e1;
  padding-bottom: 0.5rem;
  position: relative;
}
service-save-100554 .block-scenery {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 1rem;
  margin-top: 1rem;
}
service-save-100554 .block-scenery button {
  display: flex;
  justify-content: center;
  align-items: center;
  margin: 0px;
  padding: 10px;
  height: 30px;
  background: #007bff;
  color: #fff;
}
service-save-100554 sectionsave {
  padding: 1rem;
  display: block;
}
@media (max-width: 544px) {
  service-save-100554 sectionsave {
    flex-direction: column;
  }
}
service-save-100554 sectionsave #btn_save:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
service-save-100554 sectionsave .btnSave:hover {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}
service-save-100554 sectionsave .btnSave {
  display: inline-block;
  color: #212529;
  text-align: center;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  background-color: transparent;
  border: 1px solid transparent;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
service-save-100554 sectionsave .mt-3,
service-save-100554 sectionsave .my-3 {
  margin-top: 1rem !important;
}
service-save-100554 sectionsave .form-control {
  display: block;
  width: 98%;
  height: calc(1.5em + 0.75rem + 2px);
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
service-save-100554 sectionsave .btnSave-primary {
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
}
service-save-100554 sectionsave button,
service-save-100554 sectionsave input,
service-save-100554 sectionsave optgroup,
service-save-100554 sectionsave select,
service-save-100554 sectionsave textarea {
  margin: 0;
  font-family: inherit;
  font-size: inherit;
  line-height: inherit;
}
service-save-100554 sectionsave h4 {
  margin-bottom: 0rem;
}
service-save-100554 sectionsaveheader {
  margin-top: 0.5rem;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 40px;
  border-bottom: 1px solid #dee2e6 !important;
  font-weight: bold;
  font-size: 1rem;
}
service-save-100554 sectionnosave {
  margin-top: 5px;
  display: flex;
  justify-content: center;
  align-items: center;
}
service-save-100554 sectionsave {
  display: block;
}
service-save-100554 sectionsave > ul {
  margin-top: 0.5rem;
  margin-left: 0;
  padding-left: 0px !important;
  list-style: none;
}
service-save-100554 sectionsave li ul {
  list-style: none;
  padding-left: 1rem !important;
}
service-save-100554 sectionsave li ul {
  display: none;
}
service-save-100554 sectionsave li.open > ul {
  display: block;
}
service-save-100554 sectionsave li {
  font-size: 14px;
}
service-save-100554 sectionsave li > div {
  display: flex;
  flex-direction: row;
  gap: 0.5rem;
  user-select: none;
}
service-save-100554 sectionsave li > div input,
service-save-100554 sectionsave li > div label {
  cursor: pointer;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 0.5rem;
}
service-save-100554 sectionsave .fatv.fa-caret-righttv {
  width: 10px;
  padding: 0;
  cursor: pointer;
}
service-save-100554 sectionsave .fatv.fa-caret-righttv.rotate svg {
  transform: rotate(90deg);
}
service-save-100554 .fa-clock:hover,
service-save-100554 .fa-undo:hover,
service-save-100554 .fa-clone:hover,
service-save-100554 .fa-file-pen:hover,
service-save-100554 .fa-trash:hover {
  filter: invert(39%) sepia(22%) saturate(4456%) hue-rotate(194deg) brightness(103%) contrast(101%);
}
`);
        this.myMessage = messages['en'];
        this.mainowner = '';
        this.mainrepo = '';
        this.mainbranch = '';
        this.owner = '';
        this.repo = '';
        this.branch = '';
        this.scenery = 'save';
        this.exceededLimit = false;
        this.freeToSave = { ts: false, less: false, hasDS: false };
        this.isFreeToSave = false;
        this.selectedProject = undefined;
        this.itens = undefined;
        //@property() otherProjects: number[] = [];
        this.otherProjects = {};
        this.error = '';
        this.totFileSize = '';
        //---------SERVICE-------------
        this.details = {
            icon: '&#xf0c7',
            state: 'background',
            position: 'left',
            tooltip: 'Save',
            visible: true,
            widget: '_100554_serviceSave',
            level: [5]
        };
        this.menu = {
            title: '',
            main: {},
            tabs: undefined,
            tools: {},
            onClickMain: this.onClickMain.bind(this),
        };
        this.onLevelchange = async (ev) => {
            if (!ev.desc)
                return;
            const data = JSON.parse(ev.desc);
            if (data.to === 5)
                this.verifyExitFileChanged();
        };
        this.onMLSEvents = async (ev) => {
            if (ev.type !== 'FileAction')
                return;
            const fileAction = JSON.parse(ev.desc);
            if (!['changed', 'delete', 'new', 'rename'].includes(fileAction.action))
                return;
            this.scenery = 'save';
            if (this.isServiceVisible()) {
                this.init();
            }
            this.toogleBadge(true, '_100554_serviceSave');
        };
        this.onFreeToSave = async (ev) => {
            if (ev.type !== 'ProjectCompilationComplete')
                return;
            const v = JSON.parse(ev.desc);
            if (v.tsFree === false) {
                this.setError(this.myMessage.errorVerify);
                return;
            }
            else if (v.tsFree) {
                this.freeToSave.ts = true;
            }
            if (v.lessFree === false) {
                this.setError(this.myMessage.errorVerify);
                return;
            }
            else if (v.lessFree) {
                this.freeToSave.less = true;
            }
            this.isFreeToSave = this.freeToSave.hasDS ? this.freeToSave.ts && this.freeToSave.less : this.freeToSave.ts;
        };
        this.oIcon = {
            nochange: { icon: 'fa-file-pen', title: 'Edited' },
            changed: { icon: 'fa-file-pen', title: 'Edited' },
            renamed: { icon: 'fa-clone', title: 'Renamed' },
            deleted: { icon: 'fa-xmark', title: 'Deleted' },
            new: { icon: 'fa-plus', title: 'New' }
        };
        this.fromToExtension = {
            '.ts': 'ts',
            '.less': 'style',
            '.html': 'html',
            '.test.ts': 'test',
            '.defs.ts': 'defs'
        };
        this.timeSumTotal = 0;
        this.forceSaveL5ProjectFile = false;
        this.arrayRollback = [];
        this.inSaving = false;
        this.isRemovedFork = false;
        this.STORAGE_KEY = '_100554_serviceInit';
        readProjectTypescriptAndCompile(this.currentProject, '', true);
        this.setEvents();
        this.setError('');
    }
    onClickMain(op) {
        if (op === 'opBranch')
            this.showBranche();
        if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onServiceClick(visible, reinit) {
        if (visible && reinit) {
            setTimeout(() => this.setError(''), 500);
            this.updateList();
        }
        else if (visible && !reinit) {
            setTimeout(() => this.setError(''), 500);
            this.updateList();
        }
    }
    // -------------- EVENTS -------------------
    async setEvents() {
        mls.events.addListener(2, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(3, 'FileAction', this.onMLSEvents.bind(this));
        mls.events.addListener(5, 'ProjectSelected', (ev) => { this.init(); });
        mls.events.addListener(5, 'ProjectCompilationComplete', this.onFreeToSave.bind(this));
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['LevelChanged'], this.onLevelchange.bind(this));
    }
    isServiceVisible() {
        return this.visible === 'true';
    }
    verifyExitFileChanged() {
        if (!mls.stor.files)
            return;
        const array = Object.keys(mls.stor.files);
        let exist = false;
        for (let i of array) {
            const f = mls.stor.files[i];
            if (!f)
                continue;
            if (f.project === this.currentProject && f.status !== 'nochange')
                exist = true;
            if (exist)
                break;
        }
        if (!exist)
            return;
        this.toogleBadge(true, '_100554_serviceSave');
    }
    // ------------- WEBCOMPONENT -------------
    connectedCallback() {
        super.connectedCallback();
        this.init();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.myMessage = messages[lang];
        if (this.currentProject === mls.stor.LOCALPROJECTNUMBER) {
            return html `<plugin-create-project-local-to-driver-100554
            
            @project-local-created=${() => { this.init(); }}
            ></plugin-create-project-local-to-driver-100554>`;
        }
        if (this.error !== '') {
            setTimeout(() => this.error = '', 3000);
            return html `${unsafeHTML(this.error)}`;
        }
        if (this.scenery !== 'save') {
            return this.renderBlockScenery();
        }
        if (this.itens) {
            return html `
                ${this.renderHeader()}
                ${this.renderItens()}
                ${this.renderOthersProjects()}
            `;
        }
        else if (Object.keys(this.otherProjects).length > 0) {
            return html `
                ${this.renderHeader()}
                ${this.renderOthersProjects()}
            `;
        }
        else {
            return html `
                ${this.renderHeader()}
                ${this.renderNoItens()}
            `;
        }
    }
    renderBlockScenery() {
        if (this.scenery === 'blockAll') {
            return html `<h4 style="margin-top:1rem; text-align:center">${this.myMessage.msgBlockAll}</h4>`;
        }
        return html `
            <h4 style="margin-top:1rem; text-align:center">${this.myMessage.msgBlock}</h4>
            <div class="block-scenery">
                <button class="btn-service-save" @click="${this.createFork}">
                    <svg width="16" height="16" fill="#fff" viewBox="0 0 16 16" version="1.1" width="16" height="16" aria-hidden="true"><path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path></svg>
                    Fork
                </button>
            </div>
        `;
    }
    renderHeader() {
        return html `
            <div class="header-save">
                <div>
                    <span style="font-weight:600">Owner:</span>
                    <span>${this.owner}</span>
                </div>
                <div>
                    <span style="font-weight:600">Repo:</span>
                    <span>${this.repo}</span>
                </div>
                <div>
                    <span style="font-weight:600">Branch:</span>
                    <span>${this.branch}</span>
                </div>

                <button class="btn-service-save" style=" justify-content: center; align-items: center; margin: 0px; padding: 5px; height: 23px; " title="${this.myMessage.sync}" @click="${() => { this.forceSync(); }}">
                    ${collab_branch} ${this.myMessage.sync}
                </button>

                <button class="btn-service-save" style=" display: none; justify-content: center; align-items: center; margin: 0px; padding: 5px; height: 23px; " @click="${() => { if (this.menu.setMenuActive)
            this.menu.setMenuActive('opBranch'); }}">
                    ${collab_branch} Change
                </button>
            </div>
        `;
    }
    renderNoItens() {
        return html `
        <sectionnosave style="padding:1rem">
            <span>${unsafeHTML(this.myMessage.noItemsToSave)}</span>
        </sectionnosave>
    `;
    }
    renderOthersProjects() {
        //this.filterOtherProject();
        return html `
        <sectionsave>
            <ul>
                ${repeat(Object.keys(this.otherProjects), ((key) => key), ((k, index) => { return this.renderOthersProjectsItens(+k); }))}
            </ul>
        </sectionsave>`;
    }
    renderOthersProjectsItens(project) {
        const isDependency = this.getActualProjectDependencies().includes(project);
        return html `
        <li style="cursor: pointer;">
            <div style="cursor: pointer;">
                <span @click="${this.openMeList}" class="fatv fa-caret-righttv" style="cursor: pointer;">
                    <svg xmlns="http://www.w3.org/2000/svg" style="fill: var(--collab-text-primary-color);"  height="1em" viewBox="0 0 256 512"><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/></svg>
                </span>
                <input type="checkbox" disabled style="cursor: not-allowed;">
                <label style="cursor: pointer;">${project}</label>
                ${isDependency ? html `
                    <span class="link-select-project" style="cursor:pointer; margin-left:8px; font-size:12px; text-decoration:underline; color:#7678a6;" @click="${(e) => this.selectProject(e, project)}">
                        ${this.selectedProject === project ? this.myMessage.selected : this.myMessage.select}
                    </span>
                ` : ''}
            </div>
            <ul>
                    ${repeat(Object.keys(this.otherProjects[project]), ((item) => 'other' + project + item), ((i, indexI) => { return this.renderItensOtherProjects(project, i); }))}
                </ul>
        </li> `;
    }
    renderItensOtherProjects(project, path) {
        const itens = this.otherProjects[project][path];
        return html `
        <li style="cursor: pointer;">
            <div style="cursor: pointer;">
                <span @click="${this.openMeList}" class="fatv fa-caret-righttv" style="cursor: pointer;">
                    <svg xmlns="http://www.w3.org/2000/svg" style="fill: var(--collab-text-primary-color);"  height="1em" viewBox="0 0 256 512"><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/></svg>
                </span>
                <input type="checkbox" disabled style="cursor: not-allowed;">
                <label style="cursor: pointer;">${path}</label>
                
            </div>
            <ul>
                ${repeat(itens, ((item) => 'other' + project + path + item), ((i, indexI) => {
            return html `<li><div><span></span><input type="checkbox" disabled style="cursor: not-allowed;">
                <label style="cursor: pointer;">${i}</label></div></li>`;
        }))}
            </ul>
        </li> 
        `;
    }
    renderItens() {
        const keys = Object.keys(this.itens || {});
        return html `
            <sectionsave>
                <div id="Save_menu_action" style="display:flex;">
                    <div style="width:100%;" >
                        <h4 class="mt-3">${this.myMessage.comments}:</h4>
                        <div style="display:flex; gap:1rem; align-items:center;">
                            <textarea id="commitMessage" class="form-control" style="max-width:600px;" maxlength="50"></textarea>
                            <button id="btn_save" ${'' /* ?disabled=${!this.isFreeToSave} */} class="btn-service-save btnSave btn-sm btnSave-primary" @click="${this.onSave}">${this.myMessage.update}</button>
                        </div>
                        <small style="font-size:12px;font-weight:bold">*${this.myMessage.obsVerify}</small>
                    </div>
                </div>
                <h4 class="mt-3" data-mlsline="23">${this.myMessage.fileChanges}</h4>
                <small style="font-size:12px; display:none">${this.totFileSize ? this.totFileSize : this.myMessage.msgTotFile}</small> 
                <ul>
                    ${repeat(keys, ((key) => key), ((k, index) => { return this.renderProject(k, index); }))}
                </ul>
            </sectionsave>
        `;
    }
    renderProject(project, index) {
        if (!this.itens)
            return html ``;
        const keys = Object.keys(this.itens[+project]);
        return html `
            <li class="open">
                <div>
                    <span class="fatv fa-caret-righttv rotate" @click="${this.openMeList}">
                        <svg xmlns="http://www.w3.org/2000/svg" style="fill: var(--collab-text-primary-color);"  height="1em" viewBox="0 0 256 512"><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/></svg>
                    </span>
                    <input type="checkbox" id="l0-${index}" @click="${this.clickSetValueAllChilds}">
                    <label for="l0-${index}">${project}</label>
                </div>
                <ul>
                    ${repeat(keys, ((key) => key), ((k, indexl) => { return this.renderLevels(k, project, index, indexl); }))}
                </ul>
            </li>
        `;
    }
    renderLevels(level, project, indexP, index) {
        if (!this.itens)
            return html ``;
        const objP = this.itens[+project];
        let item = objP[+level];
        const keys = Object.keys(item);
        return html `
            <li class="open">
                <div>
                    <span class="fatv fa-caret-righttv rotate" @click="${this.openMeList}" > 
                        <svg xmlns="http://www.w3.org/2000/svg" style="fill: var(--collab-text-primary-color);"  height="1em" viewBox="0 0 256 512"><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/></svg>
                    </span>
                    <input type = "checkbox" id = "l1-${indexP}-${index}" @click="${this.clickSetValueAllChilds}"/>
                    <label for= "l1-${indexP}-${index}" > l${level} </label>
                </div>
                <ul>
                    ${repeat(keys, ((item) => item), ((i, indexF) => { return this.renderFilesDefault(i, level, project, indexP, index, indexF); }))}
                </ul>
            </li>
        `;
    }
    renderFilesDefault(file, level, project, indexPP, indexP, index) {
        if (!this.itens)
            return html ``;
        const objP = this.itens[+project];
        const fileInfo = objP[+level];
        let itens = fileInfo[file];
        let forceError = itens.filter((i) => i.file.hasError === true).length > 0;
        itens = itens.sort((a, b) => a.text.localeCompare(b.text));
        return html `
            <li class="">
                <div>
                    <span class="fatv fa-caret-righttv" @click="${this.openMeList}" > 
                        <svg xmlns="http://www.w3.org/2000/svg" style="fill: var(--collab-text-primary-color);"  height="1em" viewBox="0 0 256 512"><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/><path d="M246.6 278.6c12.5-12.5 12.5-32.8 0-45.3l-128-128c-9.2-9.2-22.9-11.9-34.9-6.9s-19.8 16.6-19.8 29.6l0 256c0 12.9 7.8 24.6 19.8 29.6s25.7 2.2 34.9-6.9l128-128z"/></svg>
                    </span>
                    <input type = "checkbox" ${'' /* ?disabled=${forceError} */} id = "l2-${indexPP}-${indexP}-${index}" @click="${this.clickSetValueAllChilds}"/>
                    <label for= "l2-${indexPP}-${indexP}-${index}" > ${file} </label>
                </div>
                <ul>
                    ${repeat(itens, ((item) => item), ((i, indexI) => { return this.renderItem(i, indexPP, indexP, index, indexI, forceError); }))}
                </ul>
            </li>
        `;
    }
    renderItem(item, indexP, indexL, indexM, index, forceError) {
        return html `
            <li style="padding-left: 1.1rem;" class="${item.errorLocal || item.modelIsDispose ? 'errorLocal' : ''}">
                <div style="align-items: center;">
                    ${item.disabled || item.onlyFather || item.errorLocal /*|| forceError*/ || item.modelIsDispose
            ? html `<input type="checkbox" id="l3-${indexP}-${indexL}-${indexM}-${index}" disabled onlyStatusFather="${item.onlyFather}" @click="${this.clickVerifyStatusFather}" .instance=${item.file}>`
            : html `<input type="checkbox" id="l3-${indexP}-${indexL}-${indexM}-${index}" onlyStatusFather="${item.onlyFather}" @click="${this.clickVerifyStatusFather}" .instance=${item.file}>`}
                    <label for= "l3-${indexP}-${indexL}-${indexM}-${index}" data-tooltip="${item.text}" title="${item.text}">
                        ${item.file.extension} 
                        ${unsafeHTML(item.span)}
                    </label>
                    ${this.renderAuxActionsItem(item)}
                    
                </div>
            </li>
        `;
    }
    renderAuxActionsItem(item) {
        if (item.errorLocal)
            return html ``;
        if (['new', 'rename'].includes(item.file.status)) {
            return html `
                <span class="mls-gpbtnslider-item fa fa-undo" title="undo" @click="${(e) => this.undoFile(e.target, item.file)}" style="font-size: 13px; color: #7678a6; margin-left: 2px; height: 17px; display:flex; align-items:center; cursor:pointer"></span> 
            `;
        }
        else {
            return html `
            <span @click="${this.clickHistory}" .item=${item} style="font-size: 13px; color: #7678a6; margin-left: 2px; height: 17px; display:flex; align-items:center; cursor:pointer" class="mls-gpbtnslider-item fa-regular fa-clock" title="History"></span>
            <span class="mls-gpbtnslider-item fa fa-undo" title="undo" @click="${(e) => this.undoFile(e.target, item.file)}" style="font-size: 13px; color: #7678a6; margin-left: 2px; height: 17px; display:flex; align-items:center; cursor:pointer"></span>
            `;
        }
    }
    //-------- IMPLEMENTATION --------
    async clickHistory(e) {
        try {
            e.stopPropagation();
            let el = e.target;
            if (!el.classList.contains('fa-clock')) {
                el = el.closest('.fa-clock');
            }
            if (!el.item)
                return;
            mls.events.fire([5], 'HistoriesSelected', JSON.stringify({ action: "loader", position: 'left', }), 0);
            //this.showLoader(true);
            const f = el.item.file;
            const h = await f.getHistory();
            if (!h || h.length <= 0) {
                //this.showLoader(false);
                return;
            }
            const obj = {
                project: f.project,
                shortName: f.shortName,
                extension: f.extension,
                position: 'left',
                level: f.level,
                folder: f.folder,
                hashOriginal: h[0].ref,
                hashModified: 'local',
                renderSideBySide: true,
            };
            mls.events.fire([5], 'HistoriesSelected', JSON.stringify(obj), 0);
            //this.showLoader(false);
        }
        catch (err) {
            //this.showLoader(false);
            this.setError(err.message);
        }
    }
    async init(isSetInfoProject = true) {
        this.showLoader(true);
        await removeNewStorFilesWithTemplateDefault();
        this.totFileSize = `${this.myMessage.msgTotFile} 0B`;
        this.scenery = 'save';
        if (isSetInfoProject)
            await this.initInfoProject();
        await this.setInfos();
        this.showLoader(false);
    }
    async initInfoProject() {
        const prj = this.currentProject;
        if (!prj || prj === mls.stor.LOCALPROJECTNUMBER)
            return;
        const info = getMyKeysBranch(prj);
        if (!info)
            return;
        this.branch = info.branch;
        this.owner = info.owner;
        this.repo = info.repo;
        this.mainbranch = info.branch;
        this.mainowner = info.owner;
        this.mainrepo = info.repo;
    }
    showLoader(loader) {
        this.loading = loader;
    }
    showBranche() {
        this.menu.title = 'Branchs';
        if (this.menu.updateTitle)
            this.menu.updateTitle();
        const div = document.createElement('div');
        const el = document.createElement('save-add-branch-100554');
        el.callBack = (obj) => {
            if (obj.nameWithOwner) {
                const ret = obj.nameWithOwner.split('/');
                this.owner = ret[0];
                this.repo = ret[1];
                this.branch = obj.defaultBranchRef.name;
            }
            else {
                this.branch = obj.name;
            }
            if (this.menu.setMenuActive)
                this.menu.setMenuActive('initial');
            this.requestUpdate();
        };
        div.appendChild(el);
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    async setInfos() {
        try {
            const objProjects = {};
            const filesKeys = Object.keys(mls.stor.files);
            this.otherProjects = await this.getOtherProjects();
            for (const fKey of filesKeys) {
                const file = mls.stor.files[fKey];
                if (!file ||
                    (!file.inLocalStorage && file.status !== 'deleted') ||
                    file.project === 0 ||
                    file.project !== this.currentProject)
                    continue;
                const obj = this.setProjectLevelShortName(objProjects, file.project, file.level, file.folder, file.shortName);
                obj.push(await this.configItem(file));
            }
            if (Object.keys(objProjects).length > 0) {
                this.itens = objProjects;
            }
            else {
                this.itens = undefined;
                this.toogleBadge(false, '_100554_serviceSave');
            }
        }
        catch (e) {
            this.itens = undefined;
            this.error = e.message;
            this.setError(e.message);
        }
    }
    getActualProjectDependencies() {
        if (!mls.actualProject)
            return [];
        const details = mls.l5.getProjectDetails(mls.actualProject);
        const ret = [...(details?.prj_dependencies || [])];
        ret.push(mls.actualProject);
        return ret;
    }
    selectProject(e, project) {
        e.stopPropagation();
        this.selectedProject = this.selectedProject === project ? undefined : project;
        this.init();
    }
    async getOtherProjects() {
        let dt = await mls.stor.localDB.getKeysWithPrefix('File_');
        dt = dt.filter((t) => t.indexOf(`_${this.currentProject}_`) < 0);
        const info = {};
        dt.forEach((i) => {
            const file = mls.stor.localDB.parseKeyToFile(i);
            if (!file || file.project === 0)
                return;
            const name = `${file.folder ? file.folder + '/' : ''}${file.shortName}`;
            if (info[file.project]) {
                if (info[file.project][name]) {
                    info[file.project][name].push(file.extension);
                }
                else {
                    info[file.project][name] = [file.extension];
                }
            }
            else {
                info[file.project] = { [name]: [file.extension] };
            }
        });
        return info;
    }
    setProjectLevelShortName(obj, prj, level, folder, shortname) {
        if (!obj[prj])
            obj[prj] = { [level]: {} };
        const pj = obj[prj];
        if (!pj[level])
            pj[level] = {};
        const l = pj[level];
        const key = folder ? folder + '/' + shortname : shortname;
        if (!l[key])
            l[key] = [];
        return l[key];
    }
    async configItem(item) {
        let mountText = item.shortName + item.extension;
        let disabled = false;
        let errorLocal = false;
        let onlyFather = false;
        let span = `<span style = "font-size: 12px; color: #7678a6; margin-left: 5px;" class="fa ${this.oIcon[item.status].icon}" title = "${this.oIcon[item.status].title}" > </span>`;
        if (item.hasError && item.status !== 'deleted') {
            span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px; height: 16px;" class="fa fa-bug" title="Error"></span>';
            //disabled = true; // arquivos com erro agora podem ser selecionados; onSave pede confirmação
        }
        /*if (item.isLocalVersionOutdated) {
            span = '<span style="font-size: 12px; color: #ff0000; margin-left: 5px;" class="fa fa-unbalanced" title="Version block"></span>';
            disabled = true;
        }*/
        if (item.status === 'renamed' && item.getValueInfo) {
            const itemNew = await item.getValueInfo();
            mountText = `${itemNew.originalShortName + item.extension} to ${mountText} `;
            disabled = true;
            onlyFather = true;
        }
        errorLocal = !(await mls.stor.localDB.existFile({ project: item.project, extension: item.extension, shortName: item.shortName, folder: item.folder, level: item.level }));
        if (errorLocal)
            span = '<span> Error: the file does not exist in the database<span>';
        let modelIsDispose = false;
        const models = mls.editor.getModels(item.project, item.shortName, item.folder, item.level);
        const ext = this.fromToExtension[item.extension];
        const model = models ? models[ext] : undefined;
        if (models && model && model.model.isDisposed()) {
            modelIsDispose = true;
            span = '<span> Error: The model is invalid. <span>';
        }
        return {
            file: item,
            text: mountText,
            span: span,
            onlyFather,
            disabled: disabled,
            errorLocal,
            modelIsDispose
        };
    }
    openMeList(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        const li = el.closest('li');
        if (!li)
            return;
        li.classList.toggle('open');
        const fa = li.querySelector('.fa-caret-righttv');
        if (fa)
            fa.classList.toggle('rotate');
    }
    clickSetValueAllChilds(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.setValueAllChilds(el);
        //clearTimeout(this.timeSumTotal);
        //this.timeSumTotal = setTimeout(() => this.sumTotalSize(), 300);
    }
    setValueAllChilds(el) {
        const father = el.closest('li');
        if (!father)
            return;
        const subList = father.querySelector('ul');
        if (!subList)
            return;
        const all = subList.querySelectorAll('input');
        all.forEach((i) => {
            const onlyStatusFather = i.getAttribute('onlyStatusFather') === 'true';
            if (i.disabled && !onlyStatusFather)
                return;
            i.checked = el.checked;
        });
        if (all.length === 1 && all[0].disabled)
            el.checked = false;
    }
    clickVerifyStatusFather(e) {
        e.stopPropagation();
        const el = e.target;
        if (!el)
            return;
        this.verifyStatusFather(el);
        //clearTimeout(this.timeSumTotal);
        //this.timeSumTotal = setTimeout(() => this.sumTotalSize(), 300);
    }
    async sumTotalSize() {
        const array = this.getAllFileToSave(this);
        let txt = '';
        for await (const file of array) {
            if (file.status !== 'deleted') {
                txt = txt + '\n' + await file.getContent();
            }
        }
        const ret = calculateTotalStringSize(txt, 1000000);
        this.exceededLimit = ret.exceededLimit;
        this.totFileSize = `${this.myMessage.msgTotFile} ${ret.sizeFormatted}`;
    }
    verifyStatusFather(el) {
        const father = el.closest('ul');
        if (!father)
            return;
        const grandfather = father.closest('li');
        if (!grandfather)
            return;
        const inpMain = grandfather.querySelector('input');
        if (!inpMain)
            return;
        if (el.checked) {
            inpMain.checked = true;
            return;
        }
        let needDisable = true;
        const all = father.querySelectorAll('input');
        all.forEach((i) => {
            if (i.checked)
                needDisable = false;
        });
        if (needDisable)
            inpMain.checked = false;
    }
    async updateList() {
        try {
            this.showLoader(true);
            this.backChecked();
            this.fireEventsDetails();
            await this.setInfos();
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
        }
    }
    async fireOnPullrequest(e) {
        try {
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            this.showLoader(true);
            const driver = mls.stor.others.getDefaultDriver(prj);
            const opt = {
                owner: this.owner,
                repo: this.repo,
                branch: this.branch,
                title: 'Pull request',
                description: 'Pull request'
            };
            const ret = await driver.createPullRequest(prj, opt);
            if (!ret)
                throw new Error('Error Pull request');
            this.showLoader(false);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error fireOnPullrequest');
        }
    }
    async createFork(e) {
        try {
            e.stopPropagation();
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            this.showLoader(true);
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            if (!info || !info.login) {
                const user = await driver.getUserInfo();
                info.login = user.login;
                this.setLocalHIstoryCurrentInfoDriver(user.login);
            }
            const ret = await driver.createFork(info.login, info.repo, info.owner, info.login);
            if (!ret)
                throw new Error('Error create fork');
            this.owner = info.login;
            this.repo = info.repo;
            this.branch = 'main';
            this.setLocalHIstoryCurrentInfoDriver();
            this.init(false);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error onCreateFork');
        }
    }
    //Sempre que salvar vai gerar um novo branch no usuario e solicitar um pullrequest.
    async onSave(e) {
        if (this.inSaving)
            return;
        this.inSaving = true;
        const oldOwner = this.owner;
        const oldRepo = this.repo;
        const oldBranch = this.branch;
        try {
            e.stopPropagation();
            const el = e.target;
            if (!el) {
                this.inSaving = false;
                return;
            }
            if (this.exceededLimit) {
                this.inSaving = false;
                this.setError(this.myMessage.msgErroTotFile);
                return;
            }
            const father = el.closest('sectionsave');
            if (!father) {
                this.inSaving = false;
                return;
            }
            const txt = father.querySelector('textarea');
            if (!txt.value) {
                throw new Error(this.myMessage.needComment);
            }
            this.showLoader(true);
            if (mls.l5.actualOrg === undefined)
                throw new Error('No organization selected');
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            const actualOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
            const config = await getConfigProject(prj, true);
            if (!config)
                throw new Error('Not found config file in this project');
            const configOrg = config.orgName;
            if (actualOrg !== configOrg) {
                config.orgName = actualOrg;
                await updateConfigProject(prj, config);
                this.forceSaveL5ProjectFile = true;
            }
            const msg = txt.value;
            const array = this.getAllFileToSave(father);
            if (array.some((f) => f.hasError && f.status !== 'deleted')) {
                if (!window.confirm(this.myMessage.msgErrorFilesSelected)) {
                    this.inSaving = false;
                    this.showLoader(false);
                    return;
                }
            }
            this.verifyNeedSelectDS(array);
            this.freeToSaveProjectAndDs(array);
            this.arrayRollback = array;
            this.isRemovedFork = false;
            this.loadingFeedBack = `Checking repository...`;
            await this.fireCreateForkOrUpdate();
            //console.info('gerou o fork');
            await this.fireCreateNewBranch();
            //console.info('gerou o branche');
            await this.onSavenewPullrequest(array, msg);
            //console.info('gerou o push');
            const driver = mls.stor.others.getDefaultDriver(prj);
            const saveInfo = driver.lastSaveInfo;
            const hasCommits = !saveInfo || saveInfo.commits > 0;
            if (hasCommits) {
                this.loadingFeedBack = `Generating a pull request...`;
                await this.firePullrequest(msg);
                //console.info('gerou o pullrequest');
            }
            this.backChecked();
            await this.afterSave(array);
            txt.value = '';
            this.clearLocalHIstoryCurrentInfoDriver();
            this.inSaving = false;
            this.owner = oldOwner;
            this.repo = oldRepo;
            this.branch = oldBranch;
            this.totFileSize = `${this.myMessage.msgTotFile} 0B`;
            await this.setInfos();
            this.fireEvents();
            const msgEnd = hasCommits ? this.myMessage.pullrequestOk : this.myMessage.msgAllSynced;
            window.collabMessages.add(msgEnd, 'information', { timeToClose: 5000, autoClose: true });
            this.showLoader(false);
        }
        catch (err) {
            this.inSaving = false;
            this.owner = oldOwner;
            this.repo = oldRepo;
            this.branch = oldBranch;
            this.arrayRollback.forEach((i) => {
                if (!i.inLocalStorage)
                    i.inLocalStorage = true;
            });
            this.error = err.message;
            this.setError(err.message);
            this.backChecked();
            this.showLoader(false);
            console.info('Error onSave:', err);
        }
    }
    verifyNeedSelectDS(array) {
        return;
        if (!this.freeToSave.hasDS)
            return;
        const has = array.filter((a) => a.project === this.currentProject && a.shortName === 'designSystem' && a.extension === '.ts' && a.folder === '').length > 0;
        if (!has)
            throw new Error('Design system needs to be saved along with upcoming changes!');
    }
    async afterSave(fileInfos) {
        try {
            for await (const f of fileInfos) {
                if (f.onAction) {
                    await f.onAction('aftersave');
                }
            }
        }
        catch (e) {
            console.info('Erro onAftersave:' + e.message);
        }
    }
    async onSavenewPullrequest(ar, msg) {
        if (ar.length <= 0)
            return;
        try {
            const arrSet = [];
            ar.forEach((i) => {
                i.inLocalStorage = false;
                if (!i.onAction)
                    i.onAction = (action) => {
                        return this.afterUpdate(i);
                    };
                arrSet.push(i);
            });
            let father = this;
            let currentFile = 0;
            let _value;
            Object.defineProperty(window, "messageSave", {
                get() {
                    return _value;
                },
                set(newValue) {
                    const oldValue = _value;
                    _value = newValue;
                    let aux = newValue;
                    if (newValue.startsWith('success')) {
                        currentFile++;
                        aux = '';
                    }
                    father.loadingFeedBack = `FILES(${arrSet.length})<br>${aux}`;
                },
                configurable: true
            });
            if (arrSet.length > 0) {
                await mls.stor.setContents(arrSet, msg);
            }
            return;
        }
        catch (e) {
            //this.error = e.message;
            //this.setError(e.message);
            throw new Error(e.message + ' in: onSavenewPullrequest');
        }
    }
    async fireCreateForkOrUpdate() {
        try {
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            const user = await driver.getUserInfo();
            info.login = user.login;
            const isForkExist = await driver.checkForkIO(this.owner, this.repo, info.login);
            if (!isForkExist) {
                //console.info('criou um novo fork');
                const ret = await driver.createFork(info.login, this.repo, this.owner, info.login);
                if (!ret)
                    throw new Error('Error create fork');
                this.owner = info.login;
                this.branch = 'main';
            }
            else {
                //console.info('atualizou fork');
                const opt = {
                    repoOrigin: this.repo,
                    ownerOrigin: this.owner,
                    branchOrigin: 'main',
                    repoDest: this.repo,
                    ownerDest: info.login,
                    branchDest: 'main',
                };
                const ret = await driver.syncFork(prj, opt);
                if (!ret)
                    throw new Error('Error sync fork');
                this.owner = info.login;
            }
        }
        catch (e) {
            if (!this.isRemovedFork) {
                await this.removeFork();
                return;
            }
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error fireCreateForkOrUpdate: ' + e.message);
            throw new Error(e.message + ' in: fireCreateForkOrUpdate');
        }
    }
    async removeFork() {
        try {
            this.isRemovedFork = true;
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            const user = await driver.getUserInfo();
            info.login = user.login;
            const isForkExist = await driver.checkForkIO(this.owner, this.repo, info.login);
            if (!isForkExist)
                throw new Error('removeFork: Not found fork for delet');
            await driver.deleteRepository(this.repo, info.login);
            console.info('deletou o fork');
            await this.fireCreateForkOrUpdate();
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error removeFork: ' + e.message);
            throw new Error(e.message + ' in: removeFork');
        }
    }
    async fireCreateNewBranch() {
        try {
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            const driver = mls.stor.others.getDefaultDriver(prj);
            const user = await driver.getUserInfo();
            const login = user.login;
            const newBranch = login + '_' + Date.now().toString();
            const ret = await driver.createNewBranch({ owner: this.owner, repo: this.repo, branch: this.branch, newBranch: newBranch });
            if (!ret)
                throw new Error('Error create Branch');
            this.branch = newBranch;
            this.setLocalHIstoryCurrentInfoDriver();
        }
        catch (err) {
            throw new Error(err.message + ' in: fireCreateNewBranch');
        }
    }
    async firePullrequest(msg) {
        try {
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            const driver = mls.stor.others.getDefaultDriver(prj);
            const opt = {
                owner: this.owner,
                repo: this.repo,
                branch: this.branch,
                title: msg,
                description: msg
            };
            const ret = await driver.createPullRequest(prj, opt);
            if (!ret)
                throw new Error('Error Pull request');
        }
        catch (err) {
            throw new Error(err.message + ' in: firePullrequest');
        }
    }
    //Manter para no futuro implementarmos o modo de salvar direto no repo.
    async onSave_withOutPullRequest(e) {
        try {
            e.stopPropagation();
            const el = e.target;
            if (!el)
                return;
            const father = el.closest('sectionsave');
            if (!father)
                return;
            this.showLoader(true);
            if (mls.l5.actualOrg === undefined)
                throw new Error('No organization selected');
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            const actualOrg = Object.keys(mls.stor.orgs)[mls.l5.actualOrg];
            const config = await getConfigProject(prj, true);
            if (!config)
                throw new Error('Not found config file in this project');
            const configOrg = config.orgName;
            if (actualOrg !== configOrg) {
                config.orgName = actualOrg;
                await updateConfigProject(prj, config);
                this.forceSaveL5ProjectFile = true;
            }
            const txt = father.querySelector('textarea');
            const array = this.getAllFileToSave(father);
            const msg = txt ? txt.value : '';
            setTimeout(async () => {
                try {
                    this.setLocalHIstoryCurrentInfoDriver();
                    const p = await this.veriFyPermission();
                    if (p.read && !p.write) {
                        this.scenery = 'block';
                        this.showLoader(false);
                        this.requestUpdate();
                        return;
                    }
                    else if (!p.read && !p.write) {
                        this.scenery = 'blockAll';
                        this.showLoader(false);
                        this.requestUpdate();
                        return;
                    }
                    //await this.verifyVersionBlock(array);
                    await this.onSave_old(array, msg);
                    await this.setInfos();
                    this.fireEvents();
                    this.showLoader(false);
                }
                catch (e) {
                    this.error = e.message;
                    this.setError(e.message);
                    this.showLoader(false);
                }
            }, 500);
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
            this.showLoader(false);
            console.info('Error onSave');
        }
    }
    backChecked() {
        const els = this.querySelectorAll('input[type="checkbox"]:checked');
        Array.from(els).forEach((i) => i.checked = false);
    }
    async veriFyPermission() {
        try {
            const prj = this.currentProject;
            if (!prj)
                throw new Error('Not found project actual');
            const info = this.getLocalHIstoryCurrentInfoDriver();
            const driver = mls.stor.others.getDefaultDriver(prj);
            if (!info || !info.login) {
                const user = await driver.getUserInfo();
                info.login = user.login;
                this.setLocalHIstoryCurrentInfoDriver(user.login);
            }
            const p = driver.verifyPermission(info.owner, info.repo, info.login);
            return p;
        }
        catch (e) {
            throw new Error(e.message);
        }
    }
    clearLocalHIstoryCurrentInfoDriver() {
        const prj = this.currentProject;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        if (info[prj])
            delete info[prj];
        localStorage.setItem('InfoCurrentDriver', JSON.stringify(info));
    }
    setLocalHIstoryCurrentInfoDriver(user = undefined) {
        const prj = this.currentProject;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        info[prj] = {
            owner: this.owner,
            repo: this.repo,
            branch: this.branch,
            login: user ? user : info.login
        };
        localStorage.setItem('InfoCurrentDriver', JSON.stringify(info));
    }
    getLocalHIstoryCurrentInfoDriver() {
        const prj = this.currentProject;
        if (!prj)
            throw new Error('Not found project actual');
        let str = localStorage.getItem('InfoCurrentDriver');
        if (!str)
            str = '{}';
        const info = JSON.parse(str);
        if (info[prj])
            return info[prj];
        return {};
    }
    getAllFileToSave(father) {
        const ar = [];
        if (this.forceSaveL5ProjectFile) {
            const allChecks = father.querySelectorAll('input[type="checkbox"][onlyStatusFather]');
            allChecks.forEach((item) => {
                if (item.instance
                    && item.instance.level === 5
                    && item.instance.shortName === 'project'
                    && item.instance.extension === '.json') {
                    item.checked = true;
                }
            });
            this.forceSaveL5ProjectFile = false;
        }
        const els = father.querySelectorAll('input[type="checkbox"][onlyStatusFather]:checked');
        els.forEach((el) => {
            if (el.instance) {
                ar.push(el.instance);
                const info = el.instance;
                if (info.extension === '.ts' && info.status === 'deleted') {
                    const key = mls.stor.getKeyToFiles(info.project, info.level, info.shortName, info.folder, '.html');
                    const fl = mls.stor.files[key];
                    if (!fl || fl.status === 'new')
                        return;
                    fl.status = 'deleted';
                    ar.push(fl);
                }
            }
        });
        const unics = Array.from(new Map(ar.map(item => [`${item.project}_${item.shortName}_${item.folder}_${item.extension}`, item])).values());
        return unics;
    }
    async onSave_old(ar, msg) {
        if (ar.length <= 0)
            return;
        try {
            let versionBLock = 0;
            const arrSet = [];
            ar.forEach((i) => {
                if (i.isLocalVersionOutdated && !['new', 'deleted'].includes(i.status)) {
                    versionBLock++;
                    return;
                }
                i.inLocalStorage = false;
                if (!i.onAction)
                    i.onAction = (action) => this.afterUpdate(i);
                arrSet.push(i);
            });
            if (arrSet.length > 0) {
                await mls.stor.setContents(arrSet, msg);
                await this.uppVersionAfterSave(arrSet);
                await this.afterSave(arrSet);
                this.fireEvents(800);
            }
            if (versionBLock > 0) {
                window.collabMessages.add(`File ${versionBLock} was changed in server, file was not save`, 'information');
            }
            return;
        }
        catch (e) {
            this.error = e.message;
            this.setError(e.message);
        }
    }
    async afterUpdate(storFile) {
        const mmodel = mls.editor.getModels(storFile.project, storFile.shortName, storFile.folder);
        storFile.inLocalStorage = false;
        if (storFile.status === 'deleted') {
            await this.deleteFile(storFile);
            return;
        }
        if (storFile.status === 'renamed' && mmodel && mmodel.ts) {
            mmodel.ts.originalProject = undefined;
            mmodel.ts.originalShortName = undefined;
            mmodel.ts.originalCRC = mls.common.crc.crc32(mmodel.ts.model.getValue()).toString(16);
        }
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        storFile.status = 'nochange';
    }
    async uppVersionAfterSave(array) {
        try {
            const driver = mls.stor.others.getDefaultDriver(this.currentProject);
            if (!driver || !driver.getVersionFromFiles)
                return;
            const info = await driver.getVersionFromFiles(this.currentProject, this.owner, this.repo, this.branch, array);
            if (!info)
                return;
            for await (const a of array) {
                const key = mls.stor.getKeyToFiles(a.project, a.level, a.shortName, a.folder, a.extension);
                if (!mls.stor.files[key] || !info[key])
                    continue;
                mls.stor.files[key].versionRef = info[key];
                mls.stor.files[key].isLocalVersionOutdated = false;
                mls.stor.files[key].newVersionRefIfOutdated = undefined;
                await mls.stor.localStor.setContent(mls.stor.files[key], { contentType: 'string', content: null });
            }
        }
        catch (e) {
            console.info(e);
            return;
        }
    }
    async deleteFile(storFile) {
        await mls.stor.localStor.setContent(storFile, { contentType: 'string', content: null });
        if (storFile.inLocalStorage) {
            await mls.stor.cache.setContent(storFile, null);
            mls.editor.deleteModels(storFile.project, storFile.shortName, storFile.folder, true, storFile.level);
        }
        const keyFiles = mls.stor.getKeyToFiles(storFile.project, storFile.level, storFile.shortName, storFile.folder, storFile.extension);
        delete mls.stor.files[keyFiles];
    }
    fireEvents(time = 0) {
        const params = {};
        params.action = 'projectListChanged';
        params.level = 5;
        params.project = this.currentProject;
        params.position = this.position;
        mls.events.fire([5], ['FileAction'], JSON.stringify(params), time);
        this.fireEventsDetails();
    }
    fireEventsDetails() {
        this.isFreeToSave = false;
        this.freeToSave = { ts: false, less: false, hasDS: false };
        const key = mls.stor.getKeyToFiles(this.currentProject, 2, 'designSystem', '', '.ts');
        const file = mls.stor.files[key];
        let aux = '';
        /*if (file && file.inLocalStorage) {
            this.freeToSave.hasDS = true;
            aux = '<plugin-verify--plugin-verify-error-design-system-100555 autoPrepare="true"></plugin-verify--plugin-verify-error-design-system-100555>'
        }*/
        const options = {
            shortName: undefined,
            project: undefined,
            htmlText: '<plugin-git--plugin-pullrequest-100555 autoPrepare="true"></plugin-git--plugin-pullrequest-100555><plugin-verify--plugin-verify-error-100555 autoPrepare="true"></plugin-verify--plugin-verify-error-100555>' + aux
        };
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify(options), 0);
    }
    freeToSaveProjectAndDs(arr) {
        return;
        const keyDS = mls.stor.getKeyToFiles(this.currentProject, 2, 'designSystem', '', '.ts');
        const keyPrj = mls.stor.getKeyToFiles(this.currentProject, 2, 'project', '', '.ts');
        const fileDS = mls.stor.files[keyDS];
        const filePrj = mls.stor.files[keyPrj];
        if (!fileDS || !filePrj)
            throw new Error('[freeToSaveProjectAndDs]: Not found files');
        if (fileDS.status !== 'new' && filePrj.status !== 'new')
            return;
        const findDS = arr.find((f) => f.shortName === fileDS.shortName && f.folder === fileDS.folder && f.project === fileDS.project && f.extension === '.ts');
        const findPrj = arr.find((f) => f.shortName === filePrj.shortName && f.folder === filePrj.folder && f.project === filePrj.project && f.extension === '.ts');
        if (!findDS || !findPrj)
            throw new Error('The project and designerSystem files must be saved.');
    }
    async undoFile(item, storFile) {
        await undoFile(storFile);
        const el = item.closest('li');
        el.classList.add('errorLocal');
        el.innerHTML = `<div style="align-items: center;">
                    <input type="checkbox" onlystatusfather="false" disabled>
                    <label>
                        ${storFile.extension} Undo File.
                    </label>
                </div>`;
        //if (el) el.remove();
        //this.itens = this.removeFileByInfoImmutable(this.itens || {}, storFile);
        /*setTimeout(async () => {
            await this.setInfos();
            //this.backChecked();
            this.requestUpdate();
        }, 500);*/
    }
    removeFileByInfoImmutable(data, targetFile) {
        let changed = false;
        const newData = {};
        for (const levelKey in data) {
            const level = data[levelKey];
            let levelChanged = false;
            const newLevel = {};
            for (const subLevelKey in level) {
                const ifile = level[subLevelKey];
                let ifileChanged = false;
                const newIfile = {};
                for (const fileKey in ifile) {
                    const items = ifile[fileKey];
                    const found = items.some(item => item.file.shortName === targetFile.shortName && item.file.folder === targetFile.folder && item.file.level === targetFile.level
                    // troque aqui se não for "id"
                    );
                    if (!found) {
                        newIfile[fileKey] = items; // mantém
                    }
                    else {
                        ifileChanged = true; // removido
                        changed = true;
                    }
                }
                if (Object.keys(newIfile).length > 0) {
                    newLevel[subLevelKey] = ifileChanged ? newIfile : ifile;
                }
                else {
                    levelChanged = true; // subnível ficou vazio
                    changed = true;
                }
            }
            if (Object.keys(newLevel).length > 0) {
                newData[levelKey] = levelChanged ? newLevel : level;
            }
            else {
                changed = true; // nível ficou vazio
            }
        }
        // se nada mudou, retorna o mesmo objeto (referência)
        return changed ? newData : data;
    }
    async forceSync() {
        const conf = window.confirm(this.myMessage.msgSync.replace('[prj]', (this.currentProject || 0).toString()));
        if (!conf)
            return;
        const obj = Object.values(mls.stor.files).filter((s) => s.status !== 'nochange' && s.project === this.currentProject);
        if (!obj || obj.length === 0)
            return;
        this.showLoader(true);
        try {
            for (const file of obj) {
                await undoFile(file);
            }
            const data = this.getAllUserOpenedFiles();
            if (data[this.currentProject || 0])
                delete data[this.currentProject || 0];
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
            this.showLoader(false);
            window.location.reload();
        }
        catch (e) {
            this.showLoader(false);
            this.error = e.message || 'Erro to sync';
        }
    }
    getAllUserOpenedFiles() {
        const raw = localStorage.getItem(this.STORAGE_KEY);
        return raw ? JSON.parse(raw) : {};
    }
};
__decorate([
    state()
], ServiceSave.prototype, "freeToSave", void 0);
__decorate([
    property()
], ServiceSave.prototype, "isFreeToSave", void 0);
__decorate([
    property()
], ServiceSave.prototype, "selectedProject", void 0);
__decorate([
    property()
], ServiceSave.prototype, "itens", void 0);
__decorate([
    property()
], ServiceSave.prototype, "otherProjects", void 0);
__decorate([
    property()
], ServiceSave.prototype, "error", void 0);
__decorate([
    property()
], ServiceSave.prototype, "totFileSize", void 0);
ServiceSave = __decorate([
    customElement('service-save-100554')
], ServiceSave);
export { ServiceSave };
