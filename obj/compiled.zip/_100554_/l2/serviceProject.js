/// <mls fileReference="_100554_/l2/serviceProject.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, query, queryAll } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { collab_user } from '/_100554_/l2/collabIcons.js';
import { getAllWebComponentsInSource } from '/_102027_/l2/libCompile.js';
import { convertTagToFileName, convertFileNameToTag, getPath } from '/_102027_/l2/utils.js';
import { loadPluginProject } from '/_102027_/l2/libCommom.js';
import('/_100554_/l2/collabPanel.js');
/// **collab_i18n_start**
const message_pt = {
    installPlugin: 'Explore e adicione novos plug-ins',
};
const message_en = {
    installPlugin: 'Explore and add new plugins',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceProject100554 = class ServiceProject100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-project-100554 {
  display: block;
  font-family: var(--font-family-primary);
  box-sizing: border-box;
  font-size: var(--font-size-16);
  height: 100%;
  overflow: auto;
  padding-left: 10px;
}
service-project-100554 .buttons-container {
  display: flex;
  justify-content: center;
  margin-top: 1rem;
  margin-bottom: 1rem;
}
service-project-100554 .buttons-container button {
  background-color: var(--info-color);
  color: #fff;
}
service-project-100554 .panel {
  display: block;
  padding: 1rem;
}
service-project-100554 .panel .panel-container {
  display: flex;
  flex-direction: row;
  gap: 1rem;
}
service-project-100554 .panel .panel-container-item {
  display: flex;
  align-items: center;
  cursor: pointer;
  gap: 0.5rem;
}
service-project-100554 .panel .panel-container-item:hover span {
  text-decoration: underline;
  color: var(--active-color);
}
service-project-100554 .panel .panel-container-item:hover svg {
  fill: var(--active-color);
}
service-project-100554 .plugin-container {
  list-style: none;
  padding-top: 10px;
  padding-inline-start: 0px;
}
service-project-100554 .plugin-container li {
  padding: 10px 0;
  font-size: var(--font-size-16);
}
service-project-100554 .plugin-container li details > summary {
  cursor: pointer;
  font-size: var(--font-size-16);
  font-weight: var(--font-weight-bold);
}
service-project-100554 .plugin-container .plugins-list {
  grid-auto-rows: 1fr;
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(49%, 1fr));
  gap: 20px;
}
service-project-100554 .plugin-container .plugins-list .plugin {
  margin-left: 1rem;
  padding: 1rem;
  margin-top: 1rem;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  border: 1px solid var(--grey-color);
  border-radius: 3px;
  cursor: pointer;
}
service-project-100554 .plugin-container .plugins-list .plugin:hover {
  border-color: var(--grey-color-darker);
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-title {
  display: inline-block;
  vertical-align: top;
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-title h3 {
  font-weight: var(--font-weight-normal);
  color: var(--info-color);
  margin: 0;
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info {
  margin-bottom: 10px;
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info > div {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  align-items: center;
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info .owner span {
  color: var(--text-primary-color-lighter);
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info .owner svg {
  fill: var(--text-primary-color-lighter);
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info .plugin-status > div {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-right: 3px;
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info .plugin-status.active > div {
  background-color: green;
  animation: pulse 1.5s infinite;
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info .plugin-status.inactive > div {
  background-color: red;
}
service-project-100554 .plugin-container .plugins-list .plugin .plugin-info > p {
  font-size: var(--font-size-16);
}
@keyframes pulse {
  0% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.2);
    opacity: 0.7;
  }
  100% {
    transform: scale(1);
    opacity: 1;
  }
}
`);
        this.baseProject = 100554;
        this.msg = messages['en'];
        this.activeTab = 'Explore';
        this.explories = [];
        this.myData = {};
        //--------SERVICE---------
        this.lastActiveTabByLevel = {
            5: ETabsL5.ShowCase,
            4: ETabs.Explore,
            3: ETabs.Explore,
            2: ETabs.Explore,
            1: ETabs.Explore,
        };
        this.details = {
            icon: '&#xf542',
            state: 'foreground',
            position: 'left',
            tooltip: 'Project',
            visible: true,
            widget: '_100554_serviceProject',
            level: [5]
        };
        this.menu = {
            title: '',
            main: {
                opAboutThis: 'About this content',
            },
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: 0,
                options: this.getMenuTabsByLevel()
            },
            tools: {},
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.lastLevel = 0;
        this.pluginsList = [
            { prjID: 1, name: "SEO Optimizer", description: "Melhore o posicionamento do seu site nos mecanismos de busca, ajustando as práticas recomendadas de SEO de forma automatizada e eficaz.", category: "SEO", status: "active" },
            { prjID: 3, name: "Social Media Integration", description: "Integre facilmente plataformas de redes sociais ao seu site, permitindo que os usuários compartilhem conteúdo e conectem suas contas.", category: "Social Media", status: "active" },
            { prjID: 4, name: "E-commerce Solution", description: "Gerencie sua loja online com este plugin robusto, que permite controle completo sobre inventário, vendas e integração de pagamentos.", category: "E-commerce", status: "active" },
            { prjID: 6, name: "Gallery Manager", description: "Crie, organize e gerencie galerias de imagens no seu site, oferecendo uma experiência visual personalizada e otimizada para seus visitantes.", category: "Media", status: "active" },
            { prjID: 9, name: "Custom CSS Editor", description: "Personalize o design do seu site com um editor de CSS integrado, permitindo edições diretas no estilo das suas páginas sem a necessidade de ferramentas externas.", category: "Design", status: "active" },
            { prjID: 11, name: "Email Marketing Integration", description: "Integre serviços de marketing por e-mail diretamente ao seu site, facilitando o envio de newsletters e campanhas personalizadas para sua audiência.", category: "Marketing", status: "active" },
            { prjID: 15, name: "Image Optimizer", description: "Otimize automaticamente as imagens do seu site para melhorar a performance, garantindo tempos de carregamento mais rápidos sem perder qualidade.", category: "Media", status: "active" },
            { prjID: 17, name: "Knowledge Base", description: "Crie e organize uma base de conhecimento completa para seus usuários, permitindo fácil acesso a artigos de ajuda e documentação técnica.", category: "Content", status: "inactive" },
            { prjID: 20, name: "Newsletter Subscription", description: "Permita que os visitantes do seu site se inscrevam facilmente em newsletters, mantendo-os atualizados sobre novidades e promoções de maneira automatizada.", category: "Marketing", status: "active" },
            { prjID: 22, name: "Payment Gateway Integration", description: "Integre uma ampla variedade de gateways de pagamento ao seu site, garantindo uma experiência de checkout segura e fácil para seus clientes.", category: "E-commerce", status: "inactive" },
            { prjID: 24, name: "Related Posts", description: "Exiba posts relacionados ao final de cada artigo, aumentando o engajamento dos usuários ao manter o interesse em conteúdos similares.", category: "Content", status: "inactive" },
            { prjID: 26, name: "SEO Friendly URLs", description: "Gere URLs otimizadas para SEO automaticamente, melhorando o posicionamento do seu site nos mecanismos de busca e facilitando a indexação de conteúdo.", category: "SEO", status: "inactive" },
            { prjID: 27, name: "Social Sharing Buttons", description: "Adicione botões de compartilhamento social aos seus posts, facilitando para os visitantes a divulgação de conteúdo em suas redes sociais preferidas.", category: "Social Media", status: "active" },
            { prjID: 28, name: "Theme Customizer", description: "Personalize facilmente a aparência do seu site com este plugin, que oferece uma interface simples para ajustar cores, fontes e layout.", category: "Design", status: "inactive" },
            { prjID: 30, name: "Video Embedder", description: "Incorpore vídeos diretamente nas suas postagens sem complicações, permitindo que você adicione conteúdo multimídia de maneira rápida e eficaz.", category: "Media", status: "inactive" },
        ];
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    onClickTabs(index) {
        if (mls.actualLevel === 5) {
            this.activeTab = ETabsL5[index];
        }
        else {
            this.activeTab = ETabs[index];
        }
    }
    getMenuTabsByLevel() {
        if (!this.level)
            return [];
        if (!this.position) {
            return [
                { text: 'Explore', icon: 'e521' }
            ];
        }
        if (this.level === 5) {
            return [
                { text: 'ShowCase', icon: 'f5da' },
                { text: 'Admin', icon: 'f508' },
                { text: 'Plugins', icon: 'f1e6' },
            ];
        }
        if (this.level === 2 && this.position === 'right') {
            return [
                { text: 'Explore', icon: 'e521' }
            ];
        }
        return [
            { text: 'Explore', icon: 'e521' },
            { text: 'ShowCase', icon: 'f5da' }
        ];
    }
    onServiceClick(visible, reinit, el) {
        if (visible && this.level !== this.lastLevel) {
            this.lastLevel = this.level;
            this.updateIconsByLevel();
        }
        if (visible) {
            this.refreshPlugins();
            this.requestUpdate();
        }
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'nothing selected';
        switch (this.activeTab) {
            case 'Explore':
                name = 'service-project-100554';
                break;
            case 'ShowCase':
                name = 'project.html';
                break;
            case 'Admin':
                name = 'collab-panel-100554';
                break;
            case 'Plugins':
                name = 'service-project-100554';
                break;
            default:
                name = `nothing selected`;
        }
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
		

        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    //----------COMPONENT-----------
    async firstUpdated() {
        this.setMyData();
        await this.getExploreData();
        if (this.activeTab === 'Explore') {
            await this.updateComplete;
            if (this.firstDetails)
                this.firstDetails.click();
        }
    }
    async updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('activeTab') && !!changedProperties.get('activeTab')) {
            if (this.menu.setTabActive && mls.actualLevel === 5)
                this.menu.setTabActive(ETabsL5[this.activeTab]);
            else if (this.menu.setTabActive)
                this.menu.setTabActive(ETabs[this.activeTab]);
            if (this.activeTab === 'Explore') {
                await this.updateComplete;
                if (this.firstDetails)
                    this.firstDetails.click();
            }
        }
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            ${this.renderContent()}
        `;
    }
    renderContent() {
        switch (this.activeTab) {
            case 'Explore':
                return this.renderExplore();
            case 'ShowCase':
                return this.renderShowCase();
            case 'Admin':
                return this.renderAdmin();
            case 'Plugins':
                return this.renderPlugin();
            default:
                return html ``;
        }
    }
    renderExplore() {
        return html `<div>
                ${this.explories.map((explorie, index) => {
            return html `
                        <details ?open=${index === 0} .data=${explorie} @click=${this.handleDetailExplorieClick}>
                            <summary>${explorie.category}</summary>
                            <div class="plugin-container"></div>
                        </details>
                    `;
        })}</div>`;
    }
    renderShowCase() {
        this.fireEventClose('<modules-100554></modules-100554>');
        const project = mls.actualProject;
        if (!project)
            return '<div>No project selected</div<';
        const keyToFile = mls.stor.getKeyToFiles(project, 2, 'project', '', '.html');
        const file = mls.stor.files[keyToFile];
        if (!file)
            return html `<div>File 'project.html' dont's exist in selected project</div>`;
        this.loadHelpPage('project', project || 0);
        return html `<div style="overflow:auto;height:100%;" id="projectDiv"></div>`;
    }
    renderAdmin() {
        this.fireEventClose('Select a plugin');
        const keys = Object.keys(this.myData);
        return html `
        <div>
            ${repeat(keys, ((key, idx) => key + idx), ((item, index) => {
            return this.renderPanel(item, index);
        }))}
        </div>
        `;
    }
    renderPlugin() {
        this.fireEventClose('In development: Details plugins');
        const groupedPlugins = this.groupPluginsByCategory(this.pluginsList);
        const sortedCategories = Object.keys(groupedPlugins).sort();
        return html `

        <ul class="plugin-container">
            ${sortedCategories.map(category => html `
                <li class="headerCategory">
                    <details open ">
                        <summary>${category}</summary>
                            <div class="plugins-list">
                            ${groupedPlugins[category].map(plugin => html `
                                <div
                                    plugin-id="${plugin.prjID}"
                                    class="${plugin.status === 'active' ? 'plugin active' : 'plugin'}"                                
                                >
                                    <div class= "plugin-title">
                                        <h3>${plugin.name}</h3>
                                    </div>
                                    <div class="plugin-info">    
                                        <p>${plugin.description}</p>
                                        <div>
                                            <div class="owner">
                                                <i>${collab_user}</i>
                                                <span>CollabTeam</span>
                                            </div>
                                            <div class="${plugin.status === 'active' ? 'plugin-status active' : 'plugin-status inactive'}">
                                                <div></div>
                                                <span>${plugin.status === 'active' ? 'Enabled' : 'Disabled'}</span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            `)}
                        </div>
                        
                    </details>
                </li>        
            `)}
        </ul>
        <div class="buttons-container">
            <button @click=${this.handleAddNewPlugin}>${this.msg.installPlugin}</button>
        </div>
    `;
    }
    renderPanel(key, index) {
        return html `
            <collab-panel-100554 .myData=${this.myData[key]}></collab-panel-100554>
        `;
    }
    //-------IMPLEMENTATION-----------
    refreshPlugins() {
        this.allContainers?.forEach((item) => {
            const plg = item.children[0];
            if (plg) {
                plg.setAttribute('mode', 'list');
            }
        });
    }
    updateIconsByLevel() {
        if (!this.menu || !this.menu.refresh || !this.menu.tabs || !this.menu.setTabActive)
            return;
        const menu = this.getMenuTabsByLevel();
        this.menu.tabs.options = menu;
        this.menu.refresh();
        if (this.menu.setTabActive) {
            this.menu.setTabActive(this.lastActiveTabByLevel[this.level]);
        }
    }
    fireEventClose(msg) {
        mls.events.fire(5, 'PluginDetails', JSON.stringify({
            htmlText: `<div>${msg}</div>`
        }), 0);
    }
    async handleDetailExplorieClick(e) {
        const target = e.target;
        const details = target.closest('details');
        if (!details)
            return;
        const div = details.querySelector('div');
        if (!div || div.childElementCount > 0)
            return;
        const info = getPath(details.data.widget);
        if (!info)
            throw new Error('[] Not found path:' + details.data.widget);
        const { folder, project, shortName } = info;
        await import(`/_${project}_/l2/${shortName}`);
        const pluginTag = convertFileNameToTag({ project, shortName, folder });
        const pluginEl = document.createElement(pluginTag);
        pluginEl.setAttribute('autoprepare', '');
        pluginEl.setAttribute('level', this.level.toString());
        pluginEl.setAttribute('position', this.position.toString());
        pluginEl.service = this;
        div.appendChild(pluginEl);
    }
    async getExploreData() {
        let project = mls.actualProject;
        this.explories = await loadPluginProject(project || 0, 'l5Explore');
    }
    handleAddNewPlugin() {
        alert('In Develpoment');
    }
    groupPluginsByCategory(plugins) {
        return plugins.reduce((acc, plugin) => {
            if (!acc[plugin.category]) {
                acc[plugin.category] = [];
            }
            acc[plugin.category].push(plugin);
            return acc;
        }, {});
    }
    async loadHelpPage(shortName, project) {
        const keyFile = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (storFile) {
            const content = await storFile.getContent();
            if (this.projectDiv && typeof content === 'string') {
                const allWcs = getAllWebComponentsInSource(content);
                allWcs.forEach((wc) => {
                    const info = convertTagToFileName(wc);
                    if (info) {
                        const script = document.createElement('script');
                        script.type = 'module';
                        script.id = `_${info.project}_${info.shortName}`;
                        script.src = (`/_${info.project}_${info.shortName}`);
                        this.projectDiv?.appendChild(script);
                    }
                });
                const div = document.createElement('div');
                div.innerHTML = content;
                div.children[0].setAttribute('level', '7');
                this.projectDiv.innerHTML = '';
                this.projectDiv.appendChild(div);
            }
        }
    }
    async setMyData() {
        const prj = mls.actualProject;
        let array = await loadPluginProject(prj || 0, 'l5Project', false);
        array.forEach((item) => {
            const cat = item.category;
            if (!this.myData[cat])
                this.myData[cat] = [item];
            else
                this.myData[cat].push(item);
        });
        this.requestUpdate();
    }
};
__decorate([
    property()
], ServiceProject100554.prototype, "activeTab", void 0);
__decorate([
    property({ type: Array })
], ServiceProject100554.prototype, "explories", void 0);
__decorate([
    query('#projectDiv')
], ServiceProject100554.prototype, "projectDiv", void 0);
__decorate([
    query('details')
], ServiceProject100554.prototype, "firstDetails", void 0);
__decorate([
    queryAll('.plugin-container')
], ServiceProject100554.prototype, "allContainers", void 0);
ServiceProject100554 = __decorate([
    customElement('service-project-100554')
], ServiceProject100554);
export { ServiceProject100554 };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["Explore"] = 0] = "Explore";
    ETabs[ETabs["ShowCase"] = 1] = "ShowCase";
    ETabs[ETabs["Admin"] = 2] = "Admin";
    ETabs[ETabs["Plugins"] = 3] = "Plugins";
})(ETabs || (ETabs = {}));
var ETabsL5;
(function (ETabsL5) {
    ETabsL5[ETabsL5["ShowCase"] = 0] = "ShowCase";
    ETabsL5[ETabsL5["Admin"] = 1] = "Admin";
    ETabsL5[ETabsL5["Plugins"] = 2] = "Plugins";
    ETabsL5[ETabsL5["Explore"] = 3] = "Explore";
})(ETabsL5 || (ETabsL5 = {}));
