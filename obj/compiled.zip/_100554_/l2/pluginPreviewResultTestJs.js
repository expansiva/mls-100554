/// <mls fileReference="_100554_/l2/pluginPreviewResultTestJs.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
/// **collab_i18n_start**
const message_pt = {};
const message_en = {};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let PluginPreviewResultJs = class PluginPreviewResultJs extends PluginBaseModule {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.hasError = false;
        this.results = {
            errors: '',
            prodJS: '',
        };
        this.msize = '';
    }
    get confE() { return `l2_left`; }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            this.editor?.setAttribute('msize', this.msize);
        }
    }
    createRenderRoot() {
        return this;
    }
    async firstUpdated() {
        this.createEditor();
        const actualFile = mls.actual[2].left;
        if (!actualFile)
            return;
        const { project, shortName, folder } = actualFile;
        this.setInitialModelProdTestJS(project, shortName, folder, 'compiling...');
        await this.getCompileResults(project, shortName, folder);
        this.setInitialModelProdTestJS(project, shortName, folder, this.results.prodJS);
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `<mls-editor-100529></mls-editor-100529>`;
    }
    createEditor() {
        if (!this.editor || this._ed1)
            return;
        this._ed1 = monaco.editor.create(this.editor, mls.editor.conf[this.confE]);
        monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
            noImplicitAny: true
        });
        this._ed1.updateOptions({ readOnly: true });
        this.editor.mlsEditor = this._ed1;
    }
    async getCompileResults(project, shortName, folder) {
        const models = mls.editor.getModels(project, shortName, folder, 2);
        // const models = mls.editor.models[`_${project}_${shortName}`]
        if (!models || !models.test)
            return;
        if (models.test.compilerResults && !models.test.compilerResults.prodJS)
            models.test.compilerResults.modelNeedCompile = true;
        await mls.l2.typescript.compile(models.test);
        const errs = {
            Errors: models.test.compilerResults?.errors || []
        };
        this.hasError = errs.Errors.length > 0;
        this.results = {
            prodJS: models.test.compilerResults?.prodJS || '',
            errors: JSON.stringify(errs, null, 2),
        };
    }
    setInitialModelProdTestJS(project, shortName, folder, src) {
        const model1 = this.createOrGetModel(project, shortName, folder, 'javascript', src);
        if (!model1)
            return;
        if (this._ed1)
            this._ed1.setModel(model1);
    }
    getUri(shortFN) {
        return monaco.Uri.parse(`file://server/${shortFN}_results_test_js.ts`);
    }
    createOrGetModel(project, shortName, folder, editorType, src) {
        let name = folder ? `_${project}_${folder}_${shortName}` : `_${project}_${shortName}`;
        const uri = this.getUri(name);
        let modelResultJS = monaco.editor.getModel(uri);
        if (modelResultJS) {
            modelResultJS.setValue(src);
            return modelResultJS;
        }
        modelResultJS = monaco.editor.createModel(src, editorType, uri);
        return modelResultJS;
    }
};
__decorate([
    property({ type: String })
], PluginPreviewResultJs.prototype, "msize", void 0);
__decorate([
    query('mls-editor-100529')
], PluginPreviewResultJs.prototype, "editor", void 0);
PluginPreviewResultJs = __decorate([
    customElement('plugin-preview-result-test-js-100554')
], PluginPreviewResultJs);
export { PluginPreviewResultJs };
