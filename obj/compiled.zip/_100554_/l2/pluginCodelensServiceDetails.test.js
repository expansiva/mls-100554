/// <mls fileReference="_100554_/l2/pluginCodelensServiceDetails.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
