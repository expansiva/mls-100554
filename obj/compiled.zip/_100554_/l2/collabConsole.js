/// <mls fileReference="_100554_/l2/collabConsole.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let CollabConsole100554 = class CollabConsole100554 extends StateLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-console-100554 {
  font-family: monospace;
  background: var(--bg-primary-color-lighter-focus);
  color: var(--text-primary-color);
  padding: 10px;
  max-height: 300px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  font-size: var(--font-size-12);
  box-shadow: 0px -1px 10px -4px;
}
collab-console-100554 .log {
  margin: 0;
  padding: 5px 0;
}
collab-console-100554 .warn {
  color: var(--warning-color-focus);
}
collab-console-100554 .error {
  color: var(--error-color);
}
collab-console-100554 .info {
  color: var(--info-color-hover);
}
`);
        this.logs = [];
        this.height = '200px';
        this.mode = 'disabled';
        this.scope = window;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('logs')) {
            this.scrollTop = this.scrollHeight;
        }
        if (changedProperties.has('scope')) {
            this.logs = [];
            this.changeMode(this.mode);
        }
        if (changedProperties.has('mode')) {
            this.changeMode(this.mode);
        }
    }
    changeMode(mode) {
        if (mode === 'enabled') {
            this.interceptConsole();
        }
        else if (this.oldLog) {
            this.scope.console.log = this.oldLog;
        }
    }
    interceptConsole() {
        this.oldLog = console.log;
        let _scope = this.scope;
        let _this = this;
        let t0 = performance.now();
        _scope.console.log = function newLog(message, ...args) {
            _scope.console["collab"](message, args);
        };
        _scope.console["collab"] = function newLog(message, ...args) {
            const t2 = performance.now();
            const ms = Math.round(t2 - t0);
            t0 = t2;
            const newMessage = '[' + ms.toString().padStart(3) + 'ms] ' + (message ? message : "");
            let obj = {};
            Error.captureStackTrace(obj, newLog);
            console.groupCollapsed(newMessage);
            console.info(message);
            console.trace();
            console.groupEnd();
            _this.addLog.bind(_this)('log', message);
        };
    }
    addLog(type, args) {
        const message = typeof args === 'object' ? JSON.stringify(args) : String(args);
        this.logs = [...this.logs, { type, message }];
    }
    render() {
        this.style.height = this.height;
        return html `
      <div class="log-container">
        ${this.logs.map(log => html `
            <div class="log ${log.type}">
              [${log.type.toUpperCase()}] ${log.message}
            </div>
          `)}
      </div>
    `;
    }
};
__decorate([
    state()
], CollabConsole100554.prototype, "logs", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "height", void 0);
__decorate([
    property({ type: String })
], CollabConsole100554.prototype, "mode", void 0);
__decorate([
    property()
], CollabConsole100554.prototype, "scope", void 0);
CollabConsole100554 = __decorate([
    customElement('collab-console-100554')
], CollabConsole100554);
export { CollabConsole100554 };
