/// <mls fileReference="_100554_/l2/collabConsole.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import { StateLitElement } from "/_100554_/l2/stateLitElement.js";
let CollabConsole100554 = class extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`collab-console-100554 {
  font-family: monospace;
  background: var(--bg-primary-color-lighter-focus);
  color: var(--text-primary-color);
  padding: 10px;
  max-height: 300px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 1rem;
  font-size: var(--font-size-12);
  box-shadow: 0px -1px 10px -4px;
}
collab-console-100554 .log {
  margin: 0;
  padding: 5px 0;
}
collab-console-100554 .warn {
  color: var(--warning-color-focus);
}
collab-console-100554 .error {
  color: var(--error-color);
}
collab-console-100554 .info {
  color: var(--info-color-hover);
}
`);
    }
  logs = [];
  height = "200px";
  mode = "disabled";
  scope = window;
  oldLog;
  updated(changedProperties) {
    super.updated(changedProperties);
    if (changedProperties.has("logs")) {
      this.scrollTop = this.scrollHeight;
    }
    if (changedProperties.has("scope")) {
      this.logs = [];
      this.changeMode(this.mode);
    }
    if (changedProperties.has("mode")) {
      this.changeMode(this.mode);
    }
  }
  changeMode(mode) {
    if (mode === "enabled") {
      this.interceptConsole();
    } else if (this.oldLog) {
      this.scope.console.log = this.oldLog;
    }
  }
  interceptConsole() {
    this.oldLog = console.log;
    let _scope = this.scope;
    let _this = this;
    let t0 = performance.now();
    _scope.console.log = function newLog(message, ...args) {
      _scope.console["collab"](message, args);
    };
    _scope.console["collab"] = function newLog(message, ...args) {
      const t2 = performance.now();
      const ms = Math.round(t2 - t0);
      t0 = t2;
      const newMessage = "[" + ms.toString().padStart(3) + "ms] " + (message ? message : "");
      let obj = {};
      Error.captureStackTrace(obj, newLog);
      console.groupCollapsed(newMessage);
      console.info(message);
      console.trace();
      console.groupEnd();
      _this.addLog.bind(_this)("log", message);
    };
  }
  addLog(type, args) {
    const message = typeof args === "object" ? JSON.stringify(args) : String(args);
    this.logs = [...this.logs, { type, message }];
  }
  render() {
    this.style.height = this.height;
    return html`
      <div class="log-container">
        ${this.logs.map(
      (log) => html`
            <div class="log ${log.type}">
              [${log.type.toUpperCase()}] ${log.message}
            </div>
          `
    )}
      </div>
    `;
  }
};
__decorateClass([
  state()
], CollabConsole100554.prototype, "logs", 2);
__decorateClass([
  property({ type: String })
], CollabConsole100554.prototype, "height", 2);
__decorateClass([
  property({ type: String })
], CollabConsole100554.prototype, "mode", 2);
__decorateClass([
  property()
], CollabConsole100554.prototype, "scope", 2);
CollabConsole100554 = __decorateClass([
  customElement("collab-console-100554")
], CollabConsole100554);
export {
  CollabConsole100554
};
