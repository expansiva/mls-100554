/// <mls fileReference="_100554_/l2/agentCompareAgentsClarification.ts" enhancement="_100554_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let AgentToBeConceptual2Clarification = class AgentToBeConceptual2Clarification extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.entitiesCount = 0;
        this.rulesCount = 0;
        this.capabilitiesCount = 0;
        this.suggestions = [];
    }
    firstUpdated(changed) {
    }
    updated(changed) {
    }
    /* ---------------------------
     * Render
     * --------------------------- */
    render() {
        return html `
            <div class="container">

                
                    ${this.suggestions.map((s, idx) => {
            let aux = `<input type="text" id="ipt${idx}" class="valueIpt"/>`;
            if (idx > 0)
                aux = `<textarea type="text" id="ipt${idx}" class="valueIpt"/></textarea>`;
            return html `
                            <div class="card">
                                <div class="body">
                                    <div class="title">${s}</div>
                                    ${unsafeHTML(aux)}
                                </div>
                            </div>
                        `;
        })}
                

                <div class="content">
                    ${this.renderContentSuggestions()}
                </div>

            </div>
        `;
    }
    renderContentSuggestions() {
        return html `
        <div class="suggestions">

            <div class="actions">
                <button type="button" class="action-btn cancel" @click=${() => { this.onAction('cancel'); }}>Cancel</button>
                <button type="button" class="action-btn continue" @click=${() => { this.onAction('continue'); }} >Continue</button>
            </div>
    
        </div>
    `;
    }
    onAction(action) {
        const inputs = this.querySelectorAll('.valueIpt');
        const args = {
            agentNames: [],
            promptUser: '',
            promptCompare: '',
        };
        Array.from(inputs).forEach((i) => {
            const ipt = i;
            if (ipt.id === 'ipt0' && ipt.value !== '') {
                args.agentNames = ipt.value.trim().split(',') || [];
            }
            if (ipt.id === 'ipt1' && ipt.value !== '') {
                args.promptUser = ipt.value.trim();
            }
            if (ipt.id === 'ipt2' && ipt.value !== '') {
                args.promptCompare = ipt.value.trim();
            }
        });
        const value = JSON.stringify(args);
        this.dispatchEvent(new CustomEvent('clarification-finish', {
            detail: {
                value,
                action
            },
            bubbles: true,
            composed: true
        }));
    }
};
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "entitiesCount", void 0);
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "rulesCount", void 0);
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "capabilitiesCount", void 0);
__decorate([
    property({ type: Array })
], AgentToBeConceptual2Clarification.prototype, "suggestions", void 0);
AgentToBeConceptual2Clarification = __decorate([
    customElement('agent-compare-agents-clarification-100554')
], AgentToBeConceptual2Clarification);
export { AgentToBeConceptual2Clarification };
