/// <mls fileReference="_100554_/l2/agentCompareAgentsClarification.ts" enhancement="_100554_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let AgentToBeConceptual2Clarification = class AgentToBeConceptual2Clarification extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`agent-compare-agents-clarification-100554 {
  display: block;
  font-family: var(--font-family-primary);
  overflow: hidden;
  height: 100%;
}
agent-compare-agents-clarification-100554 .container {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--bg-primary-color);
  min-height: 0;
  overflow: hidden;
  container-type: inline-size;
}
agent-compare-agents-clarification-100554 .content {
  position: relative;
  flex: 1;
  overflow: auto;
}
agent-compare-agents-clarification-100554 .content:has(.editorEntities),
agent-compare-agents-clarification-100554 .content:has(.editorRules),
agent-compare-agents-clarification-100554 .content:has(.editorCapabilities) {
  display: flex;
  min-height: 0;
}
agent-compare-agents-clarification-100554 .content .suggestions {
  padding: 1rem;
}
agent-compare-agents-clarification-100554 .card {
  position: relative;
  gap: var(--space-16);
  padding: var(--space-16);
  border-radius: 10px;
  background: var(--bg-primary-color-darker);
  border: 1px solid var(--grey-color);
  transition: all var(--transition-normal);
  cursor: pointer;
  margin-bottom: 1rem;
}
agent-compare-agents-clarification-100554 .card:hover {
  background: var(--bg-primary-color-hover);
}
agent-compare-agents-clarification-100554 .card.selected {
  border-color: var(--active-color);
}
agent-compare-agents-clarification-100554 .card input {
  width: 100%;
}
agent-compare-agents-clarification-100554 .card textarea {
  width: 100%;
  height: 100px;
}
agent-compare-agents-clarification-100554 .body {
  display: flex;
  flex-direction: column;
  gap: var(--space-8);
}
agent-compare-agents-clarification-100554 .title {
  font-weight: var(--font-weight-bold);
}
agent-compare-agents-clarification-100554 .desc {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-lighter);
}
agent-compare-agents-clarification-100554 .actions {
  display: flex;
  justify-content: flex-end;
  gap: var(--space-16);
  margin-top: var(--space-16);
}
agent-compare-agents-clarification-100554 .actions .action-btn {
  min-width: 120px;
  font-size: var(--font-size-16);
  font-weight: 500;
  border-radius: var(--space-8);
  padding: var(--space-8);
  border: none;
  cursor: pointer;
  transition: background var(--transition-slow), color var(--transition-slow);
  outline: none;
}
agent-compare-agents-clarification-100554 .actions .action-btn.cancel {
  background: var(--bg-secondary-color);
  color: var(--text-primary-color);
}
agent-compare-agents-clarification-100554 .actions .action-btn.cancel:hover {
  background: var(--bg-secondary-color-hover);
}
agent-compare-agents-clarification-100554 .actions .action-btn.continue {
  background: var(--active-color);
  color: #fff;
}
agent-compare-agents-clarification-100554 .actions .action-btn.continue:hover {
  background: var(--active-color-hover);
}
`);
        this.entitiesCount = 0;
        this.rulesCount = 0;
        this.capabilitiesCount = 0;
        this.suggestions = [];
    }
    firstUpdated(changed) {
    }
    updated(changed) {
    }
    /* ---------------------------
     * Render
     * --------------------------- */
    render() {
        return html `
            <div class="container">

                
                    ${this.suggestions.map((s, idx) => {
            let aux = `<input type="text" id="ipt${idx}" class="valueIpt"/>`;
            if (idx > 0)
                aux = `<textarea type="text" id="ipt${idx}" class="valueIpt"/></textarea>`;
            return html `
                            <div class="card">
                                <div class="body">
                                    <div class="title">${s}</div>
                                    ${unsafeHTML(aux)}
                                </div>
                            </div>
                        `;
        })}
                

                <div class="content">
                    ${this.renderContentSuggestions()}
                </div>

            </div>
        `;
    }
    renderContentSuggestions() {
        return html `
        <div class="suggestions">

            <div class="actions">
                <button type="button" class="action-btn cancel" @click=${() => { this.onAction('cancel'); }}>Cancel</button>
                <button type="button" class="action-btn continue" @click=${() => { this.onAction('continue'); }} >Continue</button>
            </div>
    
        </div>
    `;
    }
    onAction(action) {
        const inputs = this.querySelectorAll('.valueIpt');
        const args = {
            agentNames: [],
            promptUser: '',
            promptCompare: '',
        };
        Array.from(inputs).forEach((i) => {
            const ipt = i;
            if (ipt.id === 'ipt0' && ipt.value !== '') {
                args.agentNames = ipt.value.trim().split(',') || [];
            }
            if (ipt.id === 'ipt1' && ipt.value !== '') {
                args.promptUser = ipt.value.trim();
            }
            if (ipt.id === 'ipt2' && ipt.value !== '') {
                args.promptCompare = ipt.value.trim();
            }
        });
        const value = JSON.stringify(args);
        this.dispatchEvent(new CustomEvent('clarification-finish', {
            detail: {
                value,
                action
            },
            bubbles: true,
            composed: true
        }));
    }
};
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "entitiesCount", void 0);
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "rulesCount", void 0);
__decorate([
    property({ type: Number })
], AgentToBeConceptual2Clarification.prototype, "capabilitiesCount", void 0);
__decorate([
    property({ type: Array })
], AgentToBeConceptual2Clarification.prototype, "suggestions", void 0);
AgentToBeConceptual2Clarification = __decorate([
    customElement('agent-compare-agents-clarification-100554')
], AgentToBeConceptual2Clarification);
export { AgentToBeConceptual2Clarification };
