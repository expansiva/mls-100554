/// <mls fileReference="_100554_/l2/pluginEditStyleAST.ts" enhancement="_100554_enhancementLit" />
class LessAST {
  model;
  selected = null;
  blocks = /* @__PURE__ */ new Map();
  rules;
  constructor(model) {
    this.model = model;
    this.reparse();
  }
  // ====== API pública ======
  select(selector) {
    this.reparse();
    const blk = this.blocks.get(selector);
    if (!blk) return null;
    this.selected = selector;
    this.rules = this.getRules(selector);
    return true;
  }
  setRule(property, value) {
    if (!this.selected) throw new Error("Nenhum seletor selecionado.");
    this.reparse();
    const blk = this.blocks.get(this.selected);
    if (!blk) throw new Error(`Seletor '${this.selected}' n\xE3o encontrado.`);
    const lines = this.model.getValue().split(/\r?\n/);
    const propRegex = new RegExp(`^\\s*${this.escape(property)}\\s*:\\s*(.*?);?\\s*$`);
    let propLineIdx = null;
    for (let i = blk.start + 1; i < blk.end; i++) {
      const noComments = this.stripComments(lines[i]);
      if (propRegex.test(noComments)) {
        propLineIdx = i;
        break;
      }
    }
    const indentMatch = lines[blk.start].match(/^(\s*)/);
    const indent = (indentMatch ? indentMatch[1] : "") + "    ";
    const newLine = `${indent}${property}: ${value};`;
    if (propLineIdx !== null) {
      lines[propLineIdx] = newLine;
    } else {
      lines.splice(blk.start + 1, 0, newLine);
    }
    this.model.setValue(lines.join("\n"));
  }
  addSelector(selector, rules = {}) {
    this.ensureSelectorPath(selector);
    if (this.select(selector)) {
      for (const [k, v] of Object.entries(rules)) this.setRule(k, v);
    }
  }
  removeSelector(selector) {
    this.reparse();
    const blk = this.blocks.get(selector);
    if (!blk) return;
    const lines = this.model.getValue().split(/\r?\n/);
    lines.splice(blk.start, blk.end - blk.start + 1);
    this.model.setValue(lines.join("\n"));
    if (this.selected === selector) this.selected = null;
  }
  getRules(selector) {
    this.reparse();
    const blk = this.blocks.get(selector);
    const out = {};
    if (!blk) return out;
    const lines = this.model.getValue().split(/\r?\n/);
    let depth = 0;
    for (let i = blk.start + 1; i < blk.end; i++) {
      const stripped = this.stripComments(lines[i]).trim();
      if (!stripped) continue;
      if (stripped.endsWith("{")) {
        depth++;
        continue;
      }
      if (stripped === "}") {
        depth--;
        continue;
      }
      if (depth === 0) {
        const m = stripped.match(/^([a-zA-Z-]+)\s*:\s*(.+?);?$/);
        if (m) out[m[1]] = m[2];
      }
    }
    return out;
  }
  exportSelectorGroupStrict(baseSelector) {
    this.reparse();
    baseSelector = baseSelector.trim();
    if (!baseSelector) return "";
    const parts = baseSelector.split(/\s+/);
    if (parts.length < 2) {
      if (!this.blocks.has(baseSelector)) return "";
      const rules = this.getRules(baseSelector);
      const props = Object.entries(rules).map(([k, v]) => `	${k}: ${v};`).join("\n");
      return `${baseSelector} {
${props}
}`;
    }
    const parent = parts.slice(0, -1).join(" ");
    const leaf = parts[parts.length - 1];
    const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const allowedLeafPattern = new RegExp(
      `^${escapeRegExp(leaf)}(?::{1,2}[^\\s>+~]+|\\[[^\\]]+\\]|[.#][^\\s>+~]+)*$`
    );
    const matches = [];
    for (const [selector, blk] of this.blocks) {
      if (!selector.startsWith(parent + " ")) continue;
      const relative = selector.slice(parent.length + 1);
      if (!allowedLeafPattern.test(relative)) continue;
      matches.push({ selector, start: blk.start });
    }
    matches.sort((a, b) => a.start - b.start);
    const out = [];
    out.push(`${parent} {`);
    for (const { selector } of matches) {
      const relative = selector.slice(parent.length + 1);
      out.push(`	${relative} {`);
      const rules = this.getRules(selector);
      for (const [prop, val] of Object.entries(rules)) {
        out.push(`		${prop}: ${val};`);
      }
      out.push(`	}`);
    }
    out.push(`}`);
    return out.join("\n");
  }
  // ====== Internos ======
  reparse() {
    this.blocks.clear();
    const lines = this.model.getValue().split(/\r?\n/);
    const stack = [];
    const path = [];
    for (let i = 0; i < lines.length; i++) {
      const line = this.stripComments(lines[i]);
      const open = line.match(/^\s*(.+?)\s*\{\s*$/);
      if (open) {
        const sel = open[1].trim();
        path.push(sel);
        const full = path.join(" ");
        stack.push({ selector: full, start: i });
        this.blocks.set(full, { start: i, end: i });
        continue;
      }
      if (/^\s*}\s*$/.test(line)) {
        const last = stack.pop();
        if (last) {
          const blk = this.blocks.get(last.selector);
          if (blk) this.blocks.set(last.selector, { start: blk.start, end: i });
          path.pop();
        }
      }
    }
  }
  ensureSelectorPath(selector) {
    this.reparse();
    const parts = selector.trim().split(/\s+/);
    if (!parts.length) return;
    let parentParts = [];
    let lines = this.model.getValue().split(/\r?\n/);
    for (let i = 0; i < parts.length; i++) {
      const curPath = [...parentParts, parts[i]].join(" ");
      if (!this.blocks.has(curPath)) {
        let insertAt = lines.length;
        if (parentParts.length > 0) {
          const parentBlk = this.blocks.get(parentParts.join(" "));
          insertAt = parentBlk ? parentBlk.end : lines.length;
        }
        const indent = "	".repeat(i);
        const blockLines = [`${indent}${parts[i]} {`, `${indent}}`];
        lines.splice(insertAt, 0, ...blockLines);
        this.model.setValue(lines.join("\n"));
        this.reparse();
        lines = this.model.getValue().split(/\r?\n/);
      }
      parentParts.push(parts[i]);
    }
  }
  stripComments(s) {
    return s.replace(/(?<!:)\/\/.*|\/\*[\s\S]*?\*\//g, "");
  }
  escape(s) {
    return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
}
export {
  LessAST
};
