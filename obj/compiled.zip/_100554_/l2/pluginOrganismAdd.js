/// <mls fileReference="_100554_/l2/pluginOrganismAdd.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, state, query } from "lit/decorators.js";
import { executeAgentByFile } from "/_100554_/l2/aiAgentHelper.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
const message_pt = {
  noItens: "Nenhum item foi encontrado!",
  msg1: "Describe the new element to add inside the organism (e.g., button, text, nav).",
  msg2: 'Type what to create inside the organism, like "add button" or "add text".',
  project: "Projeto",
  module: "Modulo",
  organism: "Organismo",
  btn: "Implementar com IA",
  promptPlaceholder: "Escreva seu prompt..."
};
const message_en = {
  noItens: "No items were found!",
  msg1: "Describe the new element to add inside the organism (e.g., button, text, nav).",
  msg2: 'Type what to create inside the organism, like "add button" or "add text".',
  project: "Project",
  module: "Module",
  organism: "Organism",
  btn: "Implement with IA",
  promptPlaceholder: "Write your prompt..."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
let PluginOrganisAdd = class extends CollabLitElement {
  constructor() {
    super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-organism-add-100554 {
  display: block;
  padding: var(--space-16);
  font-size: var(--font-size-16);
}
plugin-organism-add-100554 form-container {
  background: var(--bg-primary-color);
  color: var(--text-primary-color);
  padding: 20px 24px;
}
plugin-organism-add-100554 .form-group {
  display: flex;
  flex-direction: column;
  margin-bottom: 14px;
}
plugin-organism-add-100554 .form-group label {
  font-size: var(--font-size-16);
  margin-bottom: 6px;
}
plugin-organism-add-100554 .form-group small {
  font-size: var(--font-size-12);
  color: var(--text-primary-color-disabled);
}
plugin-organism-add-100554 .form-group input,
plugin-organism-add-100554 .form-group textarea,
plugin-organism-add-100554 .form-group select {
  padding: 8px 10px;
  border: 1px solid var(--grey-color);
  border-radius: 6px;
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
}
plugin-organism-add-100554 .form-group input:disabled {
  color: var(--text-primary-color);
}
plugin-organism-add-100554 .form-group input:focus,
plugin-organism-add-100554 .form-group textarea:focus,
plugin-organism-add-100554 .form-group select:focus {
  border-color: var(--active-color-focus);
  box-shadow: 0 0 0 2px rgba(74, 144, 226, 0.2);
}
plugin-organism-add-100554 .form-group textarea {
  resize: vertical;
  min-height: 60px;
}
plugin-organism-add-100554 .btn-save {
  width: 100%;
  padding: 10px;
  background: var(--active-color);
  color: #fff;
  font-size: var(--font-size-16);
  font-weight: 500;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.2s;
}
plugin-organism-add-100554 .btn-save:hover {
  background: var(--active-color-hover);
}
`);
    this.msg = messages["en"];
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    const { project, path } = mls.actual[3];
    const info = mls.l2.getPath(`_${project}_${path}`);
    return html`
            <div class="form-container">

                <div class="form-group">
                    <label for="project">${this.msg.project}</label>
                    <input type="text" disabled .value="${mls.actualProject}"/>
                </div>

                <div class="form-group">
                    <label for="module">${this.msg.module}</label>
                    <input type="text" disabled .value="${info.folder}"/>
                </div>

                <div class="form-group">
                    <label for="organism">${this.msg.organism}</label>
                    <input type="text" disabled .value="${info.shortName}"/>
                </div>

                <div class="form-group">
                    <label for="prompt">Prompt</label>
                    <textarea id="iptPrompt" placeholder=${this.msg.promptPlaceholder}></textarea>
                    <div style=" display: flex ; flex-direction: column;">
                        <small>${this.msg.msg1}</small>
                        <small>${this.msg.msg2}</small>
                    </div>
                </div>

                <button class="btn-save" @click=${this.createFile}>${this.msg.btn}</button>
            </div>
        
        `;
  }
  async createFile() {
    try {
      this.showLoad(true);
      if (!this.iptPrompt || !this.iptPrompt.value) {
        throw new Error("Enter the prompt");
      }
      const path = mls.actual[3].getFullName();
      if (!path) throw new Error("Not found path");
      const info = mls.l2.getPath(path);
      const key = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, ".ts");
      if (!mls.stor.files[key]) throw new Error("Not found storFile");
      const pp = { page: path, prompt: this.iptPrompt.value, position: "left" };
      await this.fireImprove(mls.stor.files[key], JSON.stringify(pp));
      mls.events.fireFileAction("statusOrErrorChanged", mls.stor.files[key], "left", 0);
      this.iptPrompt.value = "";
      this.showLoad(false);
    } catch (e) {
      this.showError("[createFile]" + e.message);
      this.showLoad(false);
    }
  }
  async fireImprove(file, prompt) {
    await executeAgentByFile("agentImprovePrototypeOrganism", prompt, file);
  }
  showLoad(active) {
    setTimeout(() => {
      if (!this.service) return;
      this.service.loading = active;
    }, 500);
  }
  showError(msg) {
    if (!this.service) return;
    this.service.setError(msg);
  }
};
__decorateClass([
  state()
], PluginOrganisAdd.prototype, "service", 2);
__decorateClass([
  query("#iptModule")
], PluginOrganisAdd.prototype, "iptModule", 2);
__decorateClass([
  query("#iptOrganism")
], PluginOrganisAdd.prototype, "iptOrganism", 2);
__decorateClass([
  query("#iptPrompt")
], PluginOrganisAdd.prototype, "iptPrompt", 2);
PluginOrganisAdd = __decorateClass([
  customElement("plugin-organism-add-100554")
], PluginOrganisAdd);
export {
  PluginOrganisAdd
};
