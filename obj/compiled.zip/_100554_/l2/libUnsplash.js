/// <mls fileReference="_100554_/l2/libUnsplash.ts" enhancement="_100554_enhancementLit" />
const clientId = "UEmilNZzuDCesxf1L__2J4T18vdlj6jHMsdeFet3WTQ";
const cache = /* @__PURE__ */ new Map();
const CACHE_DURATION = 1e3 * 60 * 5;
async function getImages(query, actualPage, perPage) {
  const cacheKey = `${query}-${actualPage}-${perPage}`;
  const cached = cache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_DURATION) {
    return cached.data;
  }
  try {
    const encodedQuery = encodeURIComponent(query);
    const url = `https://api.unsplash.com/search/photos?query=${encodedQuery}&page=${actualPage}&per_page=${perPage}&client_id=${clientId}`;
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Erro HTTP: ${response.status}`);
    }
    const rateRemaining = response.headers.get("x-ratelimit-remaining");
    const rateReset = response.headers.get("x-ratelimit-reset");
    if (rateRemaining && +rateRemaining <= 2) {
      console.warn(`\u26A0\uFE0F Aproximando do limite da API (restam ${rateRemaining} requisi\xE7\xF5es). Reset: ${new Date(+rateReset * 1e3).toLocaleTimeString()}`);
    }
    const data = await response.json();
    const result = {
      currentPage: actualPage,
      totalPages: data.total_pages,
      totalResults: data.total,
      perPage,
      images: data.results
    };
    cache.set(cacheKey, {
      timestamp: Date.now(),
      data: result
    });
    return result;
  } catch (error) {
    console.error("Erro ao buscar imagens do Unsplash:", error);
    return {
      currentPage: actualPage,
      totalPages: 0,
      totalResults: 0,
      perPage,
      images: []
    };
  }
}
export {
  getImages
};
