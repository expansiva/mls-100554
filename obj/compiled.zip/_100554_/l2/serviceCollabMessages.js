/// <mls fileReference="_100554_/l2/serviceCollabMessages.ts" enhancement="_100554_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, } from 'lit';
import { customElement, property, query, state } from 'lit/decorators.js';
import { ServiceBase } from '/_100554_/l2/serviceBase.js';
import { setEnvironment } from '/_102036_/l2/environmentContract.js';
import { collabEnvironment } from '/_100554_/l2/collabMessagesEnvironment.js';
import { loadNotificationPreferences } from '/_102025_/l2/collabMessagesHelper.js';
import { checkIfNotificationUnread, listenToThreadEvents } from '/_102025_/l2/collabMessagesSyncNotifications.js';
import { getThread } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { loadLastTab } from "/_102025_/l2/collabMessagesHelper.js";
import { openService } from "/_102027_/l2/libCommom.js";
import '/_102025_/l2/collabMessages.js';
import '/_102025_/l2/collabMessagesSettingsGeral.js';
import '/_100554_/l2/pluginFindTask.js';
/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Conectar',
    alertMsgTitle: 'Ative as notificações',
    alertMsgBody: 'Para não perder mensagens importantes, permita notificações no navegador.',
    moments: 'Moments',
    apps: 'Apps'
};
const message_en = {
    loading: 'Loading...',
    crm: 'CRM',
    tasks: 'Tasks',
    docs: 'Docs',
    connect: 'Connect',
    alertMsgTitle: 'Enable notifications',
    alertMsgBody: 'To avoid missing important messages, allow notifications in your browser.',
    moments: 'Moments',
    apps: 'Apps'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let ServiceCollabMessages = class ServiceCollabMessages extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-collab-messages-100554 {
  display: block;
  position: relative;
  overflow: hidden !important;
}
`);
        this.msg = messages['en'];
        this.activeTab = '';
        this.msize = '';
        this.threadToOpen = '';
        this.taskToOpen = '';
        this.lastLevel = -1;
        this.details = {
            icon: '&#xf086',
            state: 'background',
            position: 'right',
            tooltip: 'Messages',
            visible: true,
            widget: '_100554_serviceCollabMessages',
            level: [0, 1, 2, 3, 4, 5, 6, 7]
        };
        this.menu = {
            title: '',
            main: {
                // opReset: { text: 'Reset onboarding', icon: 'f2ea' },
                opSettings2: { text: 'Settings', icon: 'f085' },
                opFindTask: { text: 'Find Task', icon: 'f002' },
                opAboutThis: 'About this content',
            },
            tools: {},
            tabs: {
                group: 'Mode',
                type: 'onlyicon',
                selected: ETabs.Loading,
                options: [
                    { text: this.msg.crm, icon: 'f095' },
                    { text: this.msg.tasks, icon: 'f0ae' },
                    { text: this.msg.connect, icon: 'f0c1' },
                    { text: this.msg.moments, icon: 'f1ea' },
                    { text: this.msg.apps, icon: 'f58d' },
                ]
            },
            onClickMain: this.onClickMain.bind(this),
            onClickTabs: this.onClickTabs.bind(this),
        };
        this.isFirstEnter = true;
    }
    onClickTabs(index) {
        if (this.activeTab === ETabs[index]) {
            this.activeTab = 'Loading';
            setTimeout(() => {
                this.activeTab = ETabs[index];
            }, 0);
            return;
        }
        ;
        this.activeTab = ETabs[index];
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        if (op === 'opSettings2')
            this.openSettings2();
        if (op === 'opFindTask')
            this.openFindTask();
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            this.configureByLevel();
        }
    }
    async connectedCallback() {
        super.connectedCallback();
        this.setEvents();
        this.bootstrapCollabMessages();
    }
    disconnectedCallback() {
        this.removeEvents();
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.checkNotificationPending();
    }
    updated(changedProperties) {
        if (changedProperties.has('msize')) {
            if (!this.visible || !this.collabMessagesEl)
                return;
            const [w, h] = this.msize.split(',');
            this.collabMessagesEl.style.height = `${h}px`;
        }
        super.updated(changedProperties);
    }
    render() {
        return html `<collab-messages-102025 
            .activeTab=${this.activeTab} 
            .threadToOpen=${this.threadToOpen}
            .taskToOpen=${this.taskToOpen}
         ></collab-messages-102025>`;
    }
    bootstrapCollabMessages() {
        setEnvironment(collabEnvironment);
        this.initNotificationIfEnabled();
    }
    async initNotificationIfEnabled() {
        try {
            let preferences = loadNotificationPreferences();
            if (preferences !== 'granted' && Notification.permission !== 'granted')
                return;
            listenToThreadEvents();
        }
        catch (err) {
            console.error('Error on listen notifications' + err.message);
        }
    }
    setEvents() {
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['collabMessages'], this.onCollabEventsCollabMessages.bind(this));
        window.addEventListener('thread-notification', this.onThreadReceivedNotification.bind(this));
    }
    removeEvents() {
        mls.events.removeEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['collabMessages'], this.onCollabEventsCollabMessages.bind(this));
        window.removeEventListener('thread-notification', this.onThreadReceivedNotification.bind(this));
    }
    async checkNotificationPending() {
        const hasPendingMessages = await checkIfNotificationUnread();
        this.toogleBadge(hasPendingMessages, '_100554_serviceCollabMessages');
    }
    onThreadReceivedNotification(e) {
        const customEvent = e;
        this.toogleBadge(customEvent.detail, '_100554_serviceCollabMessages');
    }
    openSettings2() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(-1);
        if (this.menu.setMode) {
            const settings = document.createElement('collab-messages-settings-geral-102025');
            settings['serviceBase'] = this;
            this.menu.setMode('page', settings);
        }
        return true;
    }
    openFindTask() {
        if (this.menu.setTabActive)
            this.menu.setTabActive(-1);
        if (this.menu.setMode) {
            const settings = document.createElement('plugin-find-task-100554');
            settings['serviceBase'] = this;
            this.menu.setMode('page', settings);
        }
        return true;
    }
    changeDisplayMenu(show) {
        if (!this.nav3Menu)
            return;
        const item = this.nav3Menu?.querySelector('li[data-key="4"]');
        if (!item)
            return;
        if (show)
            item.style.display = 'inline-flex';
        else
            item.style.display = 'none';
    }
    configureByLevel() {
        if (!this.menu || !this.menu.tabs || !this.menu.setTabActive)
            return;
        this.changeDisplayMenu(this.level === 7);
        if (this.isFirstEnter) {
            this.isFirstEnter = false;
            let lastActive = ETabs[loadLastTab()];
            lastActive = lastActive === ETabs.APPS && this.level !== 7 ? ETabs.CONNECT : lastActive;
            this.menu.setTabActive(lastActive);
        }
        if (this.level !== 7 && this.activeTab === 'APPS') {
            this.menu.setTabActive(ETabs.CONNECT);
        }
        this.lastLevel = this.level;
    }
    async onCollabEventsCollabMessages(ev) {
        if (!ev.desc)
            return;
        this.threadToOpen = '';
        this.taskToOpen = '';
        try {
            const data = JSON.parse(ev.desc);
            if (data.type === 'thread-open') {
                if (!data.threadId)
                    return;
                const thread = await getThread(data.threadId);
                if (!thread)
                    return;
                if (data.taskId)
                    this.taskToOpen = data.taskId;
                openService('_100554_serviceCollabMessages', 'left', ev.level);
                const group = thread.group;
                this.threadToOpen = thread.threadId;
                if (group !== this.activeTab)
                    this.activeTab = group;
            }
        }
        catch (err) {
            console.error(err.message);
        }
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'nothing selected';
        switch (this.activeTab) {
            case 'CRM':
                name = 'collab-messages-chat-102025';
                break;
            case 'TASK':
                name = 'collab-messages-tasks-102025';
                break;
            case 'APPS':
                name = 'collab-messages-apps-102025';
                break;
            case 'MOMENTS':
                name = 'collab-messages-moments-102025';
                break;
            case 'CONNECT':
                name = 'collab-messages-chat-102025';
                break;
            default:
                name = 'nothing selected';
        }
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
};
__decorate([
    property()
], ServiceCollabMessages.prototype, "activeTab", void 0);
__decorate([
    property()
], ServiceCollabMessages.prototype, "msize", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "threadToOpen", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "taskToOpen", void 0);
__decorate([
    state()
], ServiceCollabMessages.prototype, "lastLevel", void 0);
__decorate([
    query('collab-messages-102025')
], ServiceCollabMessages.prototype, "collabMessagesEl", void 0);
ServiceCollabMessages = __decorate([
    customElement('service-collab-messages-100554')
], ServiceCollabMessages);
export { ServiceCollabMessages };
var ETabs;
(function (ETabs) {
    ETabs[ETabs["CRM"] = 0] = "CRM";
    ETabs[ETabs["TASK"] = 1] = "TASK";
    ETabs[ETabs["CONNECT"] = 2] = "CONNECT";
    ETabs[ETabs["MOMENTS"] = 3] = "MOMENTS";
    ETabs[ETabs["APPS"] = 4] = "APPS";
    ETabs[ETabs["Add"] = 5] = "Add";
    ETabs[ETabs["Loading"] = 6] = "Loading";
})(ETabs || (ETabs = {}));
