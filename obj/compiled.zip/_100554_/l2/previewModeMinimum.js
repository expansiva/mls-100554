/// <mls fileReference="_100554_/l2/previewModeMinimum.ts" enhancement="_100554_/l2/enhancementLit" />
import * as util from '/_100554_/l2/previewModeUtil';
export class PreviewModeMinimum {
    constructor(_j, _i, _l, _s, _f, _m) {
        this.isService = false;
        this.models = undefined;
        this.file = undefined;
        this.json = _j;
        this.ifr = _i;
        this.level = _l;
        this.isService = _s;
        this.file = _f;
        this.models = _m;
    }
    async init() {
        if (!this.json || !this.ifr || !this.file)
            return;
        util.mountJSImporMap(this.json, this.ifr);
        this.mountJS(this.json, this.ifr);
        util.mountCSS(this.ifr);
        util.mountTokens(this.json.tokens || '', this.file);
    }
    mountJS(info, ifr) {
        function loadScripts(scripts) {
            const loadScript = (src) => {
                return new Promise((resolve, reject) => {
                    const script = document.createElement('script');
                    script.type = 'module';
                    script.id = src.replace('/', '');
                    script.src = src;
                    script.onload = resolve;
                    script.onerror = reject;
                    ifr.contentDocument?.body.appendChild(script);
                });
            };
            let nextScript = Promise.resolve();
            for (const script of scripts) {
                nextScript = nextScript.then(() => loadScript(script));
            }
            return nextScript;
        }
        try {
            if (info.importsJs.length <= 0 || !ifr.contentDocument)
                return;
            util.addJsReference(ifr, this.level || '2');
            loadScripts(info.importsJs).then(() => {
                if (!this.file || !this.isService)
                    return;
                util.simulateService(info, ifr, this.file);
            });
        }
        catch (e) {
            console.info('Error mountJS: ' + e.message);
        }
    }
}
