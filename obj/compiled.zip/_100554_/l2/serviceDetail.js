/// <mls fileReference="_100554_/l2/serviceDetail.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, query, state } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { getAllWebComponentsInSource } from '/_102027_/l2/libCompile.js';
import { convertTagToFileName, convertFileNameToTag, getPath } from '/_102027_/l2/utils.js';
let ServiceDetail100554 = class ServiceDetail100554 extends ServiceBase {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`service-detail-100554 {
  display: block;
}
`);
        this.msize = '';
        this.widget = '';
        this.typeRender = 'default';
        this.plugin = {};
        this.handlePluginDetails = (ev) => this.onPluginDetails(ev);
        this.handleMonacoEvents = (ev) => this.onMonacoEvents(ev);
        this.handleFileAction = (ev) => this.onFileActionReceived(ev);
        this.eventsSubscribed = false;
        //-------SERVICE------------
        this.details = {
            icon: '&#xf059',
            state: 'background',
            position: 'right',
            tooltip: 'Detail',
            visible: true,
            widget: '_100554_serviceDetail',
            level: [1, 2, 3, 4, 5, 6, 7],
            customConfiguration: {
                7: {
                    visible: false
                }
            }
        };
        this.menu = {
            title: '',
            main: {
                opAboutThis: 'About this content',
            },
            tabs: undefined,
            tools: {},
            onClickMain: this.onClickMain.bind(this),
        };
    }
    connectedCallback() {
        super.connectedCallback();
        // Only the instance the nav3 mounted as the Detail service listens to the global events. A host
        // created by hand (e.g. the runtime's nav3 "Detail" tab) lives inside ANOTHER service's container
        // (serviceClientApp): its openMe() would click THAT service's nav2 item and pull the app back over
        // the studio Detail — so actions opening the Detail seemed to do nothing until the tab was closed.
        if (this.isNav3DetailService())
            this.setEvents();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeEvents();
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    updateContentPluginWithElement(element) {
        const tag = element.tagName.toLocaleLowerCase();
        if (tag.indexOf('-')) {
            const info = convertTagToFileName(tag);
            if (info) {
                this.plugin = {
                    project: info.project,
                    shortName: info.folder ? `${info.folder}/${info.shortName}` : info.shortName
                };
            }
        }
        this._updateContentPluginWithElement(element);
    }
    clear() {
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        Array.from(this.contentPlugin.children).forEach((i) => {
            if (i.level !== mls.actualLevel)
                i.style.display = "none";
        });
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        const name = this.plugin.project ? `_${this.plugin.project}_${this.plugin.shortName}` : 'nothing selected';
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
                <li><button>Open</button></li>
            </ul>
		

        `;
        div.onclick = (e) => {
            let el = e.target;
            if (el.tagName.toLocaleLowerCase() === 'button' || (el.parentElement && el.parentElement.tagName.toLocaleLowerCase() === 'button')) {
                const keyFile = mls.stor.getKeyToFiles(this.plugin.project, 2, this.plugin.shortName, '', '.ts');
                const storFile = mls.stor.files[keyFile];
                if (!storFile)
                    return;
                this.selectLevel(2);
                this.fireEvents('open', storFile, {});
            }
        };
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    onServiceClick(visible, reinit, el) {
        if (!this.contentPlugin || reinit)
            return;
        Array.from(this.contentPlugin.children).forEach((child) => {
            if (child.tagName.startsWith('PLUGIN-')) {
                child.setAttribute('msize', this.msize);
            }
            child.style.display = 'none';
        });
    }
    //----------COMPONENT------------------
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
        this.onWidgetChanged();
    }
    updated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (changedProperties.has('widget')) {
            this.onWidgetChanged();
        }
        if (changedProperties.has('msize')) {
            if (!this.visible || !this.contentPlugin)
                return;
            Array.from(this.contentPlugin.children).forEach((child) => {
                if (child.tagName.startsWith('PLUGIN-')) {
                    child.setAttribute('msize', this.msize);
                }
            });
        }
    }
    render() {
        return this.renderDefault();
    }
    renderDefault() {
        return html `<div style="overflow:auto;height: calc(100% - 2rem);padding:1rem" id="contentPlugin"></div>`;
    }
    //----------IMPLEMENTS-------------------
    isNav3DetailService() {
        const dataService = this.closest('collab-nav-3-service')?.getAttribute('data-service') || '';
        return /serviceDetail$/.test(dataService);
    }
    setEvents() {
        if (this.eventsSubscribed)
            return;
        this.eventsSubscribed = true;
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['PluginDetails'], this.handlePluginDetails);
        mls.events.addListener(2, 'MonacoAction', this.handleMonacoEvents);
        mls.events.addListener(2, 'FileAction', this.handleFileAction);
    }
    removeEvents() {
        if (!this.eventsSubscribed)
            return;
        this.eventsSubscribed = false;
        mls.events.removeEventListener(undefined, undefined, this.handlePluginDetails);
        mls.events.removeEventListener(undefined, undefined, this.handleMonacoEvents);
        mls.events.removeEventListener(undefined, undefined, this.handleFileAction);
    }
    onMonacoEvents(ev) {
        if (!ev.desc)
            return;
        const args = JSON.parse(ev.desc);
        if (!args)
            return;
        const { action, position } = args;
        if (position === this.position)
            return;
        if (action !== 'helpAssistant')
            return;
        if (!args.codeLenCommand?.refs)
            return;
        this.openMe();
        mls.actual[0].setFullName(args.codeLenCommand.refs);
        const { project, path } = mls.actual[0];
        if (!path || !project)
            return;
        const info = {
            project,
            shortName: path,
        };
        this.showPluginContent(info);
    }
    async onFileActionReceived(ev) {
        if (!ev.desc)
            return;
        const params = JSON.parse(ev.desc);
        if (params.action !== 'fileReference')
            return;
        const info = {
            project: 100554,
            shortName: 'pluginCodelensFileReferences',
            htmlText: `<plugin-codelens-file-references-100554 project=${params.project} shortname=${params.shortName} position=${params.position}></plugin-codelens-file-references-100554>`
        };
        this.openMe();
        this.showPluginContent(info);
    }
    onPluginDetails(ev) {
        if (!ev.desc)
            throw new Error('Error on PluginDetails event, invalid desc');
        //if (ev.level !== this.level) return;
        this.openMe();
        if (this.menu && this.menu.closeMenu)
            this.menu.closeMenu();
        const data = JSON.parse(ev.desc);
        this.showPluginContent(data);
    }
    onWidgetChanged() {
        if (this.widget) {
            const path = getPath(this.widget);
            if (!path)
                throw new Error('[onWidgetChanged] Not found path:' + this.widget);
            const { project, shortName, folder } = path;
            const tag = convertFileNameToTag({ project, shortName, folder });
            const info = {
                project,
                shortName,
                htmlText: `<${tag}></${tag}>`
            };
            this.showPluginContent(info);
        }
    }
    async showPluginContent(info) {
        // show htmlText or plugin html
        if (!info.project || !info.shortName) {
            if (!info.htmlText)
                throw new Error(`Error on PluginDetails events, invalid data: ${info.project} ${info.shortName}`);
        }
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        this.plugin = info;
        const storBase = getPath(`_${info.project}_/${info.shortName}`);
        if (!storBase)
            throw new Error('[showPluginContent] Not found path:' + `_${info.project}_/${info.shortName}`);
        const plugin = info.htmlText ? 'any' : `_${storBase.project}_${storBase.folder ? storBase.folder + '/' : ''}${storBase.shortName}`;
        const content = info.htmlText ? info.htmlText : await this.getHtmlFromPlugin(storBase);
        this.updateContentPluginWithScripts(plugin, content, info.arguments);
    }
    async getHtmlFromPlugin(info) {
        const keyFile = mls.stor.getKeyToFiles(info.project, 2, info.shortName, info.folder, '.html');
        const storFile = mls.stor.files[keyFile];
        if (!storFile) {
            const tag = convertFileNameToTag(info);
            return `<${tag} autoprepare='s'></${tag}>`;
            //return 'Not found storFile:' + JSON.stringify(info);
        }
        const content = await storFile.getContent();
        if (typeof content !== 'string')
            return `Error on content of ${keyFile}`;
        return content;
    }
    updateContentPluginWithScripts(ori, content, args) {
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        const ori1 = ori.replace(/\//g, '--');
        Array.from(this.contentPlugin.children).forEach((i) => i.style.display = "none");
        let el = this.contentPlugin.querySelector('#' + ori1 + mls.actualLevel);
        if (!el) {
            el = document.createElement('div');
            el.id = ori1 + mls.actualLevel;
            this.setContentinEl(el, content, args);
            el.style.cssText = ' width: 100%; height: 100%;';
            return;
        }
        if (ori1 === 'any') {
            el.innerHTML = '';
            this.setContentinEl(el, content, args);
            el.style.cssText = ' width: 100%; height: 100%;';
            return;
        }
        el.style.display = '';
        el.args = args;
    }
    _updateContentPluginWithElement(element) {
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        Array.from(this.contentPlugin.children).forEach((i) => i.style.display = "none");
        let el = this.contentPlugin.querySelector('#' + element.tagName.toLowerCase());
        if (!el) {
            el = document.createElement('div');
            el.id = element.tagName.toLowerCase();
        }
        el.style.display = 'block';
        el.style.height = '100%';
        this.setContentElement(el, element);
    }
    setContentElement(el, elementToAdd) {
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        const allWcs = getAllWebComponentsInSource(elementToAdd.outerHTML);
        el.innerHTML = '';
        allWcs.forEach((wc) => {
            // Already registered — a second <script type="module"> for the same widget re-runs its
            // top-level code (a fresh fetch/evaluation), and `customElements.define` throws on the
            // tag it already owns (NotSupportedError). No API to re-register, so skip is the only move.
            if (customElements.get(wc))
                return;
            const info = convertTagToFileName(wc);
            if (info) {
                const script = document.createElement('script');
                script.type = 'module';
                script.id = `_${info.project}_${info.shortName}`;
                script.src = (`/_${info.project}_/l2/${info.folder ? info.folder + '/' : ''}${info.shortName}`);
                el.appendChild(script);
            }
        });
        el.appendChild(elementToAdd);
        this.contentPlugin.appendChild(el);
    }
    setContentinEl(el, content, args) {
        if (!this.contentPlugin)
            throw new Error('Error on serviceDetail, contentPlugin is null');
        const allWcs = getAllWebComponentsInSource(content);
        el.innerHTML = content;
        el.args = args;
        allWcs.forEach((wc) => {
            // Already registered — a second <script type="module"> for the same widget re-runs its
            // top-level code (a fresh fetch/evaluation), and `customElements.define` throws on the
            // tag it already owns (NotSupportedError). No API to re-register, so skip is the only move.
            if (customElements.get(wc))
                return;
            const info = convertTagToFileName(wc);
            if (info) {
                const script = document.createElement('script');
                script.type = 'module';
                script.id = `_${info.project}_${info.shortName}`;
                script.src = (`/_${info.project}_/l2/${info.folder ? info.folder + '/' : ''}${info.shortName}`);
                el.appendChild(script);
            }
        });
        Array.from(el.children).forEach((child) => {
            if (child.tagName.startsWith('PLUGIN-')) {
                child.setAttribute('msize', this.msize);
            }
        });
        this.contentPlugin.appendChild(el);
    }
    fireEvents(action, file, info, timeout = 0) {
        const params = {};
        params.action = action;
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = '.ts';
        params.folder = file.folder;
        params.position = 'left';
        if (info && info.shortName) {
            params.newshortName = info.shortName;
            params.newProject = info.project;
            params.newfolder = file.folder;
        }
        if (['open'].includes(action)) {
            mls.actual[2].setFullName(`_${file.project}_${file.shortName}`);
            mls.actual[2]['left'] = {
                project: file.project,
                shortName: file.shortName,
                extension: '.ts',
                folder: file.folder,
            };
        }
        mls.events.fire([2], ['FileAction'], JSON.stringify(params), timeout);
    }
};
__decorate([
    property({ type: String })
], ServiceDetail100554.prototype, "msize", void 0);
__decorate([
    property({ type: String })
], ServiceDetail100554.prototype, "widget", void 0);
__decorate([
    state()
], ServiceDetail100554.prototype, "typeRender", void 0);
__decorate([
    query('#contentPlugin')
], ServiceDetail100554.prototype, "contentPlugin", void 0);
ServiceDetail100554 = __decorate([
    customElement('service-detail-100554')
], ServiceDetail100554);
export { ServiceDetail100554 };
