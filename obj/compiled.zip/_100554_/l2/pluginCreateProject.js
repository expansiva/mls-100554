/// <mls fileReference="_100554_/l2/pluginCreateProject.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, property, state } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
import { createAllFiles } from "/_100554_/l2/collabLibStor.js";
import { createConfigFile } from "/_100554_/l2/libProjectConfig.js";
import { createModel } from "/_100554_/l2/collabLibModel.js";
import { addMessage, createThread } from "/_102025_/l2/collabMessagesHelper.js";
import { getThreadByName } from "/_102025_/l2/collabMessagesIndexedDB.js";
import { setProjectDetails, checkIfHasLocalProject, setLocalProjectName, isValidProjectName } from "/_100554_/l2/libCommom.js";
import {
  template_ds,
  template_l2Project
} from "/_100554_/l2/pluginNewProjectTemplate.js";
const message_pt = {
  createProjectTitle: "Criar projeto",
  createProjectHelper: "Por favor escolha o tipo de projeto abaixo e pressione continuar.",
  labelName: "Nome do projeto",
  optionBlank: "Projeto em branco",
  optionPrompt: "Iniciar com prompt",
  promptPlaceholder: "Digite seu prompt aqui...",
  banner: `Seu projeto de teste ser\xE1 criado aqui no navegador. \u{1F60A}
Ele n\xE3o ter\xE1 controle de vers\xE3o, backup ou compartilhamento, mas voc\xEA pode explorar e testar tudo localmente \xE0 vontade.
Quando estiver pronto, poder\xE1 salvar o projeto no GitHub, GitLab ou em outro reposit\xF3rio, de acordo com o seu plano.
\u26A0\uFE0F Aten\xE7\xE3o: use apenas para testes. N\xE3o utilize em produ\xE7\xE3o antes de salvar e fazer backup.`,
  btnCancel: "Cancelar",
  btnCreate: "Criar projeto",
  errorPrjNameBlank: "O nome do projeto deve ser preenchido",
  errorPrjNameInvalid: "O nome do projeto s\xF3 pode conter letras, n\xFAmeros e _ , e deve come\xE7ar com uma letra",
  errorPrjPrompt: "O prompt deve ser preenchido",
  alreadyHasProjectLocal: "Um projeto de teste j\xE1 existe, n\xE3o \xE9 poss\xEDvel criar outro.",
  projectOk1: "Projeto local criado com sucesso",
  projectOk2: "Agora voc\xEA pode come\xE7ar a alterar seu novo projeto",
  btnContinue: "Continuar"
};
const message_en = {
  createProjectTitle: "Create project",
  createProjectHelper: "Please choose your project type below and press continue.",
  labelName: "Project name",
  optionBlank: "Blank project",
  optionPrompt: "Start with prompt",
  promptPlaceholder: "Type your prompt here...",
  banner: `Your test project will be created right here in the browser. \u{1F60A}
It won't have version control, backup, or sharing, but you can freely explore and test everything locally.
When you're ready, you can save the project to GitHub, GitLab, or another repository, depending on your plan.
\u26A0\uFE0F Warning: for testing only. Do not use in production before saving and creating a backup.`,
  btnCancel: "Cancel",
  btnCreate: "Create Project",
  errorPrjNameBlank: "Project name must be filled in",
  errorPrjNameInvalid: "The project name can only contain letters, numbers and _, and must start with a letter",
  errorPrjPrompt: "Prompt must be filled in",
  alreadyHasProjectLocal: "A test project already exists, you cannot create another one.",
  projectOk1: "Local project created successfully",
  projectOk2: "Now you can start editing your new project",
  btnContinue: "Continue"
};
const messages = {
  en: message_en,
  pt: message_pt
};
let PluginCreateProject = class extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-create-project-100554 {
  display: block;
  font-family: var(--font-family-primary);
  color: var(--text-primary-color);
  padding: var(--space-24);
}
plugin-create-project-100554 h2 {
  font-size: var(--font-size-24);
  margin-bottom: var(--space-16);
}
plugin-create-project-100554 p {
  font-size: var(--font-size-16);
  margin-bottom: var(--space-24);
  color: var(--text-primary-color-lighter);
}
plugin-create-project-100554 label {
  display: block;
  margin-bottom: var(--space-8);
  font-weight: var(--font-weight-bold);
}
plugin-create-project-100554 label input[type="text"] {
  width: 100%;
  padding: var(--space-8);
  margin-top: var(--space-8);
  border: 1px solid var(--grey-color);
  border-radius: 4px;
  font-size: var(--font-size-16);
}
plugin-create-project-100554 input[type="text"].invalid,
plugin-create-project-100554 textarea.invalid {
  border-color: var(--error-color);
}
plugin-create-project-100554 .error {
  font-size: var(--font-size-12);
  color: var(--error-color);
  margin-bottom: var(--space-16);
}
plugin-create-project-100554 .options {
  margin-bottom: var(--space-16);
}
plugin-create-project-100554 .options label {
  display: flex;
  align-items: center;
  gap: var(--space-8);
  margin-bottom: var(--space-8);
  font-weight: var(--font-weight-normal);
}
plugin-create-project-100554 textarea {
  width: 100%;
  min-height: 100px;
  padding: var(--space-8);
  border: 1px solid var(--grey-color);
  border-radius: 4px;
  margin-bottom: var(--space-24);
  font-size: var(--font-size-16);
  resize: vertical;
}
plugin-create-project-100554 .banner {
  background-color: var(--bg-secondary-color-lighter);
  border: 1px solid var(--grey-color);
  padding: var(--space-16);
  margin-bottom: var(--space-16);
  border-radius: 4px;
  font-size: var(--font-size-16);
  white-space: pre-wrap;
}
plugin-create-project-100554 .banner pre {
  white-space: break-spaces;
}
plugin-create-project-100554 .actions {
  display: flex;
  gap: var(--space-16);
}
plugin-create-project-100554 .actions button {
  padding: var(--space-8) var(--space-16);
  border-radius: 4px;
  border: 1px solid var(--grey-color);
  font-size: var(--font-size-16);
  cursor: pointer;
  transition: background var(--transition-normal);
}
plugin-create-project-100554 .actions button:hover {
  background: var(--bg-primary-color-hover);
}
plugin-create-project-100554 .actions button.primary {
  background: var(--active-color);
  color: white;
  border: none;
}
plugin-create-project-100554 .actions button.primary:hover {
  background: var(--active-color-hover);
}
plugin-create-project-100554 .actions button .loader {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid #ccc;
  border-top: 2px solid #333;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
plugin-create-project-100554 .container-success {
  padding: 1rem;
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  color: var(--text-primary-color);
}
plugin-create-project-100554 .container-success > div {
  text-align: center;
}
plugin-create-project-100554 .container-success .success-icon {
  display: inline-block;
  width: 8em;
  height: 8em;
  font-size: 20px;
  border-radius: 50%;
  border: 4px solid #8ae95b;
  background-color: var(--bg-primary-color);
  position: relative;
  overflow: hidden;
  transform-origin: center;
  animation: showSuccess 180ms ease-in-out;
  transform: scale(1);
}
plugin-create-project-100554 .container-success .success-icon__tip,
plugin-create-project-100554 .container-success .success-icon__long {
  display: block;
  position: absolute;
  height: 4px;
  background-color: #8ae95b;
  border-radius: 10px;
}
plugin-create-project-100554 .container-success .success-icon__tip {
  width: 2.4em;
  top: 4.3em;
  left: 1.4em;
  transform: rotate(45deg);
  animation: tipInPlace 300ms ease-in-out;
  animation-fill-mode: forwards;
  animation-delay: 180ms;
  visibility: hidden;
}
plugin-create-project-100554 .container-success .success-icon__long {
  width: 4em;
  transform: rotate(-45deg);
  top: 3.7em;
  left: 2.75em;
  animation: longInPlace 140ms ease-in-out;
  animation-fill-mode: forwards;
  visibility: hidden;
  animation-delay: 540ms;
}
@keyframes showSuccess {
  from {
    transform: scale(0);
  }
  to {
    transform: scale(1);
  }
}
@keyframes tipInPlace {
  from {
    width: 0em;
    top: 0em;
    left: -1.6em;
  }
  to {
    width: 2.4em;
    top: 4.3em;
    left: 1.4em;
    visibility: visible;
  }
}
@keyframes longInPlace {
  from {
    width: 0em;
    top: 5.1em;
    left: 3.2em;
  }
  to {
    width: 4em;
    top: 3.7em;
    left: 2.75em;
    visibility: visible;
  }
}
`);
    }
  msg = messages["pt"];
  currentScenario = "select";
  projectName = "";
  projectType = "prompt";
  projectPrompt = "";
  errorName = "";
  errorPrompt = "";
  alreadyHasProjectLocal = false;
  isLoading = false;
  projectCreatedSucessfully = false;
  projectNumber = mls.stor.LOCALPROJECTNUMBER;
  agentName = "agentGeneratePrototype";
  firstUpdated(changedProperties) {
    super.firstUpdated(changedProperties);
    this.alreadyHasProjectLocal = checkIfHasLocalProject();
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
      <section class="plugin-create-project-100554">
        ${this.renderScenario()}
      </section>
    `;
  }
  renderScenario() {
    switch (this.currentScenario) {
      case "select":
        return this.renderSelect();
    }
  }
  renderSelect() {
    if (this.alreadyHasProjectLocal) {
      return html`
        <div>
            ${this.msg.alreadyHasProjectLocal}
        </div>
      `;
    }
    if (this.projectCreatedSucessfully) {
      return html`
        ${this.renderProjectCreatedOk()}
      `;
    }
    return html`
      <h2>${this.msg.createProjectTitle}</h2>
      <p>${this.msg.createProjectHelper}</p>

      <label>
        ${this.msg.labelName}
        <input 
          type="text" 
          .value=${this.projectName} 
          @input=${(e) => this.projectName = e.target.value} 
        />
      </label>
       ${this.errorName ? html`<div class="error">${this.errorName}</div>` : ""}
        
      <div class="options">
        <label>
          <input 
            type="radio" 
            name="projectType" 
            value="prompt"
            ?checked=${this.projectType === "prompt"}
            @change=${() => this.projectType = "prompt"}
          />
          ${this.msg.optionPrompt}
        </label>

        <label>
          <input 
            type="radio" 
            name="projectType" 
            value="blank"
            ?checked=${this.projectType === "blank"}
            @change=${() => this.projectType = "blank"}
          />
          ${this.msg.optionBlank}
        </label>


      </div>

      ${this.projectType === "prompt" ? html`
        <textarea 
          placeholder=${this.msg.promptPlaceholder}
          .value=${this.projectPrompt}
          @input=${(e) => this.projectPrompt = e.target.value}
        ></textarea>
        ${this.errorPrompt ? html`<div class="error">${this.errorPrompt}</div>` : ""}
      ` : ""}

      <div class="banner">
        <pre>${this.msg.banner}</pre>
      </div>

      <div class="actions">
        <button @click=${this.handleCancel}>${this.msg.btnCancel}</button>
        <button
          class="primary"
          @click=${this.handleCreate}
          ?disabled=${this.isLoading}
          >
            ${this.isLoading ? html`<span class="loader"></span>` : this.msg.btnCreate}
        </button>
      </div>
    `;
  }
  renderProjectCreatedOk() {
    return html`
      <div class="container-success">
            <div class="text-center">
                <div class="success-icon">
                    <div class="success-icon__tip"></div>
                    <div class="success-icon__long"></div>
                </div>
                <h1>${this.msg.projectOk1}</h1>
                <h5 class="text-muted">${this.msg.projectOk2}</h5>
            </div>
            <div class="actions">
                <button
                  type="button"
                  class="continue"
                  @click=${() => {
      window.location.reload();
    }}
                >${this.msg.btnContinue}</button>
            </div>
        </div>
    
    `;
  }
  handleCancel() {
    console.log("Cancel clicked");
  }
  validateForm() {
    let valid = true;
    this.errorName = "";
    this.errorPrompt = "";
    const validName = isValidProjectName(this.projectName);
    if (!validName) {
      this.errorName = this.msg.errorPrjNameInvalid;
      valid = false;
    }
    if (!this.projectName.trim()) {
      this.errorName = this.msg.errorPrjNameBlank;
      valid = false;
    }
    if (this.projectType === "prompt" && !this.projectPrompt.trim()) {
      this.errorPrompt = this.msg.errorPrjPrompt;
      valid = false;
    }
    return valid;
  }
  async handleCreate() {
    if (!this.validateForm()) {
      console.warn("Form invalid");
      return;
    }
    this.isLoading = true;
    try {
      await this.createFiles();
    } catch (err) {
      console.info(err.message);
    } finally {
      this.isLoading = false;
    }
  }
  setProjectActual(project) {
    mls.setActualProject(project);
    setProjectDetails(project);
  }
  async createFiles() {
    await this.createInitialProject(this.projectNumber);
    await this.createInitialDSFile(this.projectNumber);
    await this.createInitialConfigL5File(this.projectNumber);
    this.setProjectActual(this.projectNumber);
    setLocalProjectName(this.projectName);
    if (this.projectType === "prompt") {
      const threadProjectName = `_${this.projectNumber}_${this.projectName}`;
      let thread = await getThreadByName(threadProjectName);
      if (!thread) {
        thread = await createThread(threadProjectName, [], "company");
      }
      const messageForAgent = `@@${this.agentName} ${this.projectPrompt}`;
      if (!thread) {
        throw new Error("No find thread, try again");
      }
      await addMessage(thread.threadId, messageForAgent);
      mls.events.fire([mls.actualLevel], "collabMessages", JSON.stringify({ threadId: thread.threadId, taskId: "last", type: "thread-open" }));
    }
    this.projectCreatedSucessfully = true;
  }
  async createInitialProject(project) {
    const fileName = "project";
    const content = template_l2Project.template.trim().replace(/\[project\]/g, project.toString());
    await this.createNewFileL2(fileName, content);
    const key = mls.stor.getKeyToFiles(project, 2, fileName, "", ".ts");
    const storFile = mls.stor.files[key];
    if (!storFile) throw new Error("Invalid stor file");
    createModel(storFile, true, true);
  }
  async createInitialConfigL5File(project) {
    await createConfigFile(project);
  }
  async createInitialDSFile(project) {
    const fileName = "designSystem";
    const content = template_ds.template.trim().replace(/\[project\]/g, project.toString());
    await this.createNewFileL2(fileName, content);
    const key = mls.stor.getKeyToFiles(project, 2, fileName, "", ".ts");
    const storFile = mls.stor.files[key];
    if (!storFile) throw new Error("Invalid stor file");
    createModel(storFile, true, true);
  }
  async createNewFileL2(shortName, content) {
    const folder = "";
    const enhancement = "_blank";
    const param = {
      shortName,
      project: this.projectNumber,
      folder,
      enhancement,
      level: 2,
      tsSource: content
    };
    await createAllFiles(param, false, false);
  }
};
__decorateClass([
  property({ type: String })
], PluginCreateProject.prototype, "currentScenario", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "projectName", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "projectType", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "projectPrompt", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "errorName", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "errorPrompt", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "alreadyHasProjectLocal", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "isLoading", 2);
__decorateClass([
  state()
], PluginCreateProject.prototype, "projectCreatedSucessfully", 2);
PluginCreateProject = __decorateClass([
  customElement("plugin-create-project-100554")
], PluginCreateProject);
export {
  PluginCreateProject
};
