/// <mls fileReference="_100554_/l2/pluginCreateProject.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { createAllFiles } from '/_102027_/l2/libStor.js';
import { createConfigFile } from '/_100554_/l2/libProjectConfig.js';
import { createModel } from '/_102027_/l2/libModel.js';
import { addMessage, createThread } from '/_102025_/l2/collabMessagesHelper.js';
import { getThreadByName } from '/_102025_/l2/collabMessagesIndexedDB.js';
import { setProjectDetails, checkIfHasLocalProject, setLocalProjectName, isValidProjectName } from '/_102027_/l2/libCommom.js';
import { template_ds, template_l2Project } from '/_100554_/l2/pluginNewProjectTemplate.js';
/// **collab_i18n_start**
const message_pt = {
    createProjectTitle: 'Criar projeto',
    createProjectHelper: 'Por favor escolha o tipo de projeto abaixo e pressione continuar.',
    labelName: 'Nome do projeto',
    optionBlank: 'Projeto em branco',
    optionPrompt: 'Iniciar com prompt',
    promptPlaceholder: 'Digite seu prompt aqui...',
    banner: `Seu projeto de teste será criado aqui no navegador. 😊
Ele não terá controle de versão, backup ou compartilhamento, mas você pode explorar e testar tudo localmente à vontade.
Quando estiver pronto, poderá salvar o projeto no GitHub, GitLab ou em outro repositório, de acordo com o seu plano.
⚠️ Atenção: use apenas para testes. Não utilize em produção antes de salvar e fazer backup.`,
    btnCancel: 'Cancelar',
    btnCreate: 'Criar projeto',
    errorPrjNameBlank: 'O nome do projeto deve ser preenchido',
    errorPrjNameInvalid: 'O nome do projeto só pode conter letras, números e _ , e deve começar com uma letra',
    errorPrjPrompt: 'O prompt deve ser preenchido',
    alreadyHasProjectLocal: 'Um projeto de teste já existe, não é possível criar outro.',
    projectOk1: 'Projeto local criado com sucesso',
    projectOk2: 'Agora você pode começar a alterar seu novo projeto',
    btnContinue: 'Continuar',
};
const message_en = {
    createProjectTitle: 'Create project',
    createProjectHelper: 'Please choose your project type below and press continue.',
    labelName: 'Project name',
    optionBlank: 'Blank project',
    optionPrompt: 'Start with prompt',
    promptPlaceholder: 'Type your prompt here...',
    banner: `Your test project will be created right here in the browser. 😊
It won't have version control, backup, or sharing, but you can freely explore and test everything locally.
When you're ready, you can save the project to GitHub, GitLab, or another repository, depending on your plan.
⚠️ Warning: for testing only. Do not use in production before saving and creating a backup.`,
    btnCancel: 'Cancel',
    btnCreate: 'Create Project',
    errorPrjNameBlank: 'Project name must be filled in',
    errorPrjNameInvalid: 'The project name can only contain letters, numbers and _, and must start with a letter',
    errorPrjPrompt: 'Prompt must be filled in',
    alreadyHasProjectLocal: 'A test project already exists, you cannot create another one.',
    projectOk1: 'Local project created successfully',
    projectOk2: 'Now you can start editing your new project',
    btnContinue: 'Continue',
};
const messages = {
    en: message_en,
    pt: message_pt
};
/// **collab_i18n_end**
let PluginCreateProject = class PluginCreateProject extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['pt']; // default pt
        this.currentScenario = 'select';
        this.projectName = '';
        this.projectType = 'prompt';
        this.projectPrompt = '';
        this.errorName = '';
        this.errorPrompt = '';
        this.alreadyHasProjectLocal = false;
        this.isLoading = false;
        this.projectCreatedSucessfully = false;
        this.projectNumber = mls.stor.LOCALPROJECTNUMBER;
        this.agentName = 'agentGeneratePrototype';
    }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        this.alreadyHasProjectLocal = checkIfHasLocalProject();
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <section class="plugin-create-project-100554">
        ${this.renderScenario()}
      </section>
    `;
    }
    renderScenario() {
        switch (this.currentScenario) {
            case 'select':
                return this.renderSelect();
        }
    }
    renderSelect() {
        if (this.alreadyHasProjectLocal) {
            return html `
        <div>
            ${this.msg.alreadyHasProjectLocal}
        </div>
      `;
        }
        if (this.projectCreatedSucessfully) {
            return html `
        ${this.renderProjectCreatedOk()}
      `;
        }
        return html `
      <h2>${this.msg.createProjectTitle}</h2>
      <p>${this.msg.createProjectHelper}</p>

      <label>
        ${this.msg.labelName}
        <input 
          type="text" 
          .value=${this.projectName} 
          @input=${(e) => this.projectName = e.target.value} 
        />
      </label>
       ${this.errorName
            ? html `<div class="error">${this.errorName}</div>`
            : ''}
        
      <div class="options">
        <label>
          <input 
            type="radio" 
            name="projectType" 
            value="prompt"
            ?checked=${this.projectType === 'prompt'}
            @change=${() => this.projectType = 'prompt'}
          />
          ${this.msg.optionPrompt}
        </label>

        <label>
          <input 
            type="radio" 
            name="projectType" 
            value="blank"
            ?checked=${this.projectType === 'blank'}
            @change=${() => this.projectType = 'blank'}
          />
          ${this.msg.optionBlank}
        </label>


      </div>

      ${this.projectType === 'prompt' ? html `
        <textarea 
          placeholder=${this.msg.promptPlaceholder}
          .value=${this.projectPrompt}
          @input=${(e) => this.projectPrompt = e.target.value}
        ></textarea>
        ${this.errorPrompt ? html `<div class="error">${this.errorPrompt}</div>` : ''}
      ` : ''}

      <div class="banner">
        <pre>${this.msg.banner}</pre>
      </div>

      <div class="actions">
        <button @click=${this.handleCancel}>${this.msg.btnCancel}</button>
        <button
          class="primary"
          @click=${this.handleCreate}
          ?disabled=${this.isLoading}
          >
            ${this.isLoading ? html `<span class="loader"></span>` : this.msg.btnCreate}
        </button>
      </div>
    `;
    }
    renderProjectCreatedOk() {
        return html `
      <div class="container-success">
            <div class="text-center">
                <div class="success-icon">
                    <div class="success-icon__tip"></div>
                    <div class="success-icon__long"></div>
                </div>
                <h1>${this.msg.projectOk1}</h1>
                <h5 class="text-muted">${this.msg.projectOk2}</h5>
            </div>
            <div class="actions">
                <button
                  type="button"
                  class="continue"
                  @click=${() => { window.location.reload(); }}
                >${this.msg.btnContinue}</button>
            </div>
        </div>
    
    `;
    }
    handleCancel() {
        console.log("Cancel clicked");
    }
    validateForm() {
        let valid = true;
        this.errorName = '';
        this.errorPrompt = '';
        const validName = isValidProjectName(this.projectName);
        if (!validName) {
            this.errorName = this.msg.errorPrjNameInvalid;
            valid = false;
        }
        if (!this.projectName.trim()) {
            this.errorName = this.msg.errorPrjNameBlank;
            valid = false;
        }
        if (this.projectType === 'prompt' && !this.projectPrompt.trim()) {
            this.errorPrompt = this.msg.errorPrjPrompt;
            valid = false;
        }
        return valid;
    }
    async handleCreate() {
        if (!this.validateForm()) {
            console.warn("Form invalid");
            return;
        }
        this.isLoading = true;
        try {
            await this.createFiles();
        }
        catch (err) {
            console.info(err.message);
        }
        finally {
            this.isLoading = false;
        }
    }
    setProjectActual(project) {
        mls.setActualProject(project);
        setProjectDetails(project);
    }
    async createFiles() {
        await this.createInitialProject(this.projectNumber);
        await this.createInitialDSFile(this.projectNumber);
        await this.createInitialConfigL5File(this.projectNumber);
        this.setProjectActual(this.projectNumber);
        setLocalProjectName(this.projectName);
        if (this.projectType === 'prompt') {
            const threadProjectName = `_${this.projectNumber}_${this.projectName}`;
            let thread = await getThreadByName(threadProjectName);
            if (!thread) {
                thread = await createThread(threadProjectName, [], 'company');
            }
            const messageForAgent = `@@${this.agentName} ${this.projectPrompt}`;
            if (!thread) {
                throw new Error('No find thread, try again');
            }
            await addMessage(thread.threadId, messageForAgent);
            mls.events.fire([mls.actualLevel], 'collabMessages', JSON.stringify({ threadId: thread.threadId, taskId: 'last', type: 'thread-open' }));
        }
        this.projectCreatedSucessfully = true;
    }
    async createInitialProject(project) {
        const fileName = 'project';
        const content = template_l2Project.template.trim().replace(/\[project\]/g, project.toString());
        await this.createNewFileL2(fileName, content);
        const key = mls.stor.getKeyToFiles(project, 2, fileName, '', '.ts');
        const storFile = mls.stor.files[key];
        if (!storFile)
            throw new Error('Invalid stor file');
        createModel(storFile, true, true);
    }
    async createInitialConfigL5File(project) {
        await createConfigFile(project);
    }
    async createInitialDSFile(project) {
        const fileName = 'designSystem';
        const content = template_ds.template.trim().replace(/\[project\]/g, project.toString());
        await this.createNewFileL2(fileName, content);
        const key = mls.stor.getKeyToFiles(project, 2, fileName, '', '.ts');
        const storFile = mls.stor.files[key];
        if (!storFile)
            throw new Error('Invalid stor file');
        createModel(storFile, true, true);
    }
    async createNewFileL2(shortName, content) {
        const folder = '';
        const enhancement = '_blank';
        const param = {
            shortName: shortName,
            project: this.projectNumber,
            folder,
            enhancement,
            level: 2,
            tsSource: content
        };
        await createAllFiles(param, false, false);
    }
};
__decorate([
    property({ type: String })
], PluginCreateProject.prototype, "currentScenario", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "projectName", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "projectType", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "projectPrompt", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "errorName", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "errorPrompt", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "alreadyHasProjectLocal", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "isLoading", void 0);
__decorate([
    state()
], PluginCreateProject.prototype, "projectCreatedSucessfully", void 0);
PluginCreateProject = __decorate([
    customElement('plugin-create-project-100554')
], PluginCreateProject);
export { PluginCreateProject };
