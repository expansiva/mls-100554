/// <mls fileReference="_100554_/l2/collabEditMd.ts" enhancement="_blank" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, css, LitElement } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
export function initEditorQuillMD() {
    return true;
}
let CollabEditMd = class CollabEditMd extends LitElement {
    constructor() {
        super(...arguments);
        this.value = "";
        this.opened = false;
        this.openedToolbar = false;
        this.id = '';
    }
    set cbFinishEdit(fc) {
        this.cbFinishFc = fc;
    }
    get text() { return this.editor.value() || ''; }
    firstUpdated(changedProperties) {
        super.firstUpdated(changedProperties);
        if (!window.easymdeLoaded) {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/easymde/dist/easymde.min.js';
            script.onload = () => {
                window.easymdeLoaded = true;
                this.initEditor();
            };
            document.head.appendChild(script);
        }
        else {
            this.initEditor();
        }
    }
    initEditor(cb) {
        this.easyMDE = window['EasyMDE'];
        this._initEditor(cb);
    }
    onOpenedChanged(value) {
        this.openedToolbar = value;
        if (!this.containerEditor)
            return;
        const toolbar = this.containerEditor.querySelector('.editor-toolbar');
        toolbar.classList.toggle('d-none', !this.openedToolbar);
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            this.editor?.value(this.value);
        }
    }
    _initEditor(cb) {
        if (!this.containerQuillEditor)
            return;
        this.containerQuillEditor.value = this.value;
        this.editor = new this.easyMDE({
            element: this.containerQuillEditor,
            placeholder: "Type here...",
            status: false,
            autoDownloadFontAwesome: false
        });
        this.editor.value(this.value);
        this.editor.togglePreview();
        this.onOpenedChanged(this.getAttribute('opened') === 'true');
        if (cb)
            cb();
    }
    onEditClick() {
        if (this.iconFinish)
            this.iconFinish.style.display = '';
        if (this.iconEdit)
            this.iconEdit.style.display = 'none';
        const isPreviewActive = this.editor.isPreviewActive();
        if (isPreviewActive)
            this.editor.togglePreview();
        this.onOpenedChanged(true);
    }
    onFinishClick() {
        if (this.iconEdit)
            this.iconEdit.style.display = '';
        if (this.iconFinish)
            this.iconFinish.style.display = 'none';
        const isPreviewActive = this.editor.isPreviewActive();
        if (!isPreviewActive)
            this.editor.togglePreview();
        if (this.cbFinishFc)
            this.cbFinishFc(this.text);
        this.onOpenedChanged(false);
    }
    render() {
        return html `
            <div class="editor-md-container">
                <div class="doc-section">
                    <div class="doc-section-icons" style="display: block;">
                        <i class="fa fa-check" style="display: none;" @click=${() => { this.onFinishClick(); }}></i>
                        <i class="fa fa-pencil" @click=${() => { this.onEditClick(); }}></i>
                    </div>
                </div>
                <div style="flex: 1;">
                    <textarea class="md-section-editor"></textarea>
                </div>
            </div>
        `;
    }
};
CollabEditMd.styles = css `
    .editor-md-container{
        display:flex;
    }
    .doc-section-editor {
        flex: 1;
        height: 100%;

    }
    .doc-section {
        display: flex;
    
        .doc-section-icons {
            display: flex;
            flex-direction: column;
            color: #000;
            cursor: pointer;
            margin-right: 10px;
            i{
                display:block;
            }
        }      
    }
    
    .d-none {
        display: none!important;
    }

    .fa.fa-bold {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M0 64C0 46.3 14.3 32 32 32l48 0 16 0 128 0c70.7 0 128 57.3 128 128c0 31.3-11.3 60.1-30 82.3c37.1 22.4 62 63.1 62 109.7c0 70.7-57.3 128-128 128L96 480l-16 0-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l16 0 0-160L48 96 32 96C14.3 96 0 81.7 0 64zM224 224c35.3 0 64-28.7 64-64s-28.7-64-64-64L112 96l0 128 112 0zM112 288l0 128 144 0c35.3 0 64-28.7 64-64s-28.7-64-64-64l-32 0-112 0z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-italic {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 384 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M128 64c0-17.7 14.3-32 32-32l192 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-58.7 0L160 416l64 0c17.7 0 32 14.3 32 32s-14.3 32-32 32L32 480c-17.7 0-32-14.3-32-32s14.3-32 32-32l58.7 0L224 96l-64 0c-17.7 0-32-14.3-32-32z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-header.fa-heading {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M0 64C0 46.3 14.3 32 32 32l48 0 48 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-16 0 0 112 224 0 0-112-16 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l48 0 48 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-16 0 0 144 0 176 16 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-48 0-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l16 0 0-144-224 0 0 144 16 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-48 0-48 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l16 0 0-176L48 96 32 96C14.3 96 0 81.7 0 64z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-quote-left {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M0 216C0 149.7 53.7 96 120 96l8 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-8 0c-30.9 0-56 25.1-56 56l0 8 64 0c35.3 0 64 28.7 64 64l0 64c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64l0-32 0-32 0-72zm256 0c0-66.3 53.7-120 120-120l8 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-8 0c-30.9 0-56 25.1-56 56l0 8 64 0c35.3 0 64 28.7 64 64l0 64c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64l0-32 0-32 0-72z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-list-ul {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M64 144a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM192 64c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L192 64zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zm0 160c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-288 0zM64 464a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm48-208a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-list-ol {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M24 56c0-13.3 10.7-24 24-24l32 0c13.3 0 24 10.7 24 24l0 120 16 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-80 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l16 0 0-96-8 0C34.7 80 24 69.3 24 56zM86.7 341.2c-6.5-7.4-18.3-6.9-24 1.2L51.5 357.9c-7.7 10.8-22.7 13.3-33.5 5.6s-13.3-22.7-5.6-33.5l11.1-15.6c23.7-33.2 72.3-35.6 99.2-4.9c21.3 24.4 20.8 60.9-1.1 84.7L86.8 432l33.2 0c13.3 0 24 10.7 24 24s-10.7 24-24 24l-88 0c-9.5 0-18.2-5.6-22-14.4s-2.1-18.9 4.3-25.9l72-78c5.3-5.8 5.4-14.6 .3-20.5zM224 64l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32zm0 160l256 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-256 0c-17.7 0-32-14.3-32-32s14.3-32 32-32z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    
    .fa.fa-link {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 640 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M579.8 267.7c56.5-56.5 56.5-148 0-204.5c-50-50-128.8-56.5-186.3-15.4l-1.6 1.1c-14.4 10.3-17.7 30.3-7.4 44.6s30.3 17.7 44.6 7.4l1.6-1.1c32.1-22.9 76-19.3 103.8 8.6c31.5 31.5 31.5 82.5 0 114L422.3 334.8c-31.5 31.5-82.5 31.5-114 0c-27.9-27.9-31.5-71.8-8.6-103.8l1.1-1.6c10.3-14.4 6.9-34.4-7.4-44.6s-34.4-6.9-44.6 7.4l-1.1 1.6C206.5 251.2 213 330 263 380c56.5 56.5 148 56.5 204.5 0L579.8 267.7zM60.2 244.3c-56.5 56.5-56.5 148 0 204.5c50 50 128.8 56.5 186.3 15.4l1.6-1.1c14.4-10.3 17.7-30.3 7.4-44.6s-30.3-17.7-44.6-7.4l-1.6 1.1c-32.1 22.9-76 19.3-103.8-8.6C74 372 74 321 105.5 289.5L217.7 177.2c31.5-31.5 82.5-31.5 114 0c27.9 27.9 31.5 71.8 8.6 103.9l-1.1 1.6c-10.3 14.4-6.9 34.4 7.4 44.6s34.4 6.9 44.6-7.4l1.1-1.6C433.5 260.8 427 182 377 132c-56.5-56.5-148-56.5-204.5 0L60.2 244.3z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    
    .fa.fa-image {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M448 80c8.8 0 16 7.2 16 16l0 319.8-5-6.5-136-176c-4.5-5.9-11.6-9.3-19-9.3s-14.4 3.4-19 9.3L202 340.7l-30.5-42.7C167 291.7 159.8 288 152 288s-15 3.7-19.5 10.1l-80 112L48 416.3l0-.3L48 96c0-8.8 7.2-16 16-16l384 0zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zm80 192a48 48 0 1 0 0-96 48 48 0 1 0 0 96z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-eye {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 576 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M288 80c-65.2 0-118.8 29.6-159.9 67.7C89.6 183.5 63 226 49.4 256c13.6 30 40.2 72.5 78.6 108.3C169.2 402.4 222.8 432 288 432s118.8-29.6 159.9-67.7C486.4 328.5 513 286 526.6 256c-13.6-30-40.2-72.5-78.6-108.3C406.8 109.6 353.2 80 288 80zM95.4 112.6C142.5 68.8 207.2 32 288 32s145.5 36.8 192.6 80.6c46.8 43.5 78.1 95.4 93 131.1c3.3 7.9 3.3 16.7 0 24.6c-14.9 35.7-46.2 87.7-93 131.1C433.5 443.2 368.8 480 288 480s-145.5-36.8-192.6-80.6C48.6 356 17.3 304 2.5 268.3c-3.3-7.9-3.3-16.7 0-24.6C17.3 208 48.6 156 95.4 112.6zM288 336c44.2 0 80-35.8 80-80s-35.8-80-80-80c-.7 0-1.3 0-2 0c1.3 5.1 2 10.5 2 16c0 35.3-28.7 64-64 64c-5.5 0-10.9-.7-16-2c0 .7 0 1.3 0 2c0 44.2 35.8 80 80 80zm0-208a128 128 0 1 1 0 256 128 128 0 1 1 0-256z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-columns {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zm64 64l0 256 160 0 0-256L64 160zm384 0l-160 0 0 256 160 0 0-256z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-arrows-alt  {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M200 32L56 32C42.7 32 32 42.7 32 56l0 144c0 9.7 5.8 18.5 14.8 22.2s19.3 1.7 26.2-5.2l40-40 79 79-79 79L73 295c-6.9-6.9-17.2-8.9-26.2-5.2S32 302.3 32 312l0 144c0 13.3 10.7 24 24 24l144 0c9.7 0 18.5-5.8 22.2-14.8s1.7-19.3-5.2-26.2l-40-40 79-79 79 79-40 40c-6.9 6.9-8.9 17.2-5.2 26.2s12.5 14.8 22.2 14.8l144 0c13.3 0 24-10.7 24-24l0-144c0-9.7-5.8-18.5-14.8-22.2s-19.3-1.7-26.2 5.2l-40 40-79-79 79-79 40 40c6.9 6.9 17.2 8.9 26.2 5.2s14.8-12.5 14.8-22.2l0-144c0-13.3-10.7-24-24-24L312 32c-9.7 0-18.5 5.8-22.2 14.8s-1.7 19.3 5.2 26.2l40 40-79 79-79-79 40-40c6.9-6.9 8.9-17.2 5.2-26.2S209.7 32 200 32z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-arrows-alt  {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M200 32L56 32C42.7 32 32 42.7 32 56l0 144c0 9.7 5.8 18.5 14.8 22.2s19.3 1.7 26.2-5.2l40-40 79 79-79 79L73 295c-6.9-6.9-17.2-8.9-26.2-5.2S32 302.3 32 312l0 144c0 13.3 10.7 24 24 24l144 0c9.7 0 18.5-5.8 22.2-14.8s1.7-19.3-5.2-26.2l-40-40 79-79 79 79-40 40c-6.9 6.9-8.9 17.2-5.2 26.2s12.5 14.8 22.2 14.8l144 0c13.3 0 24-10.7 24-24l0-144c0-9.7-5.8-18.5-14.8-22.2s-19.3-1.7-26.2 5.2l-40 40-79-79 79-79 40 40c6.9 6.9 17.2 8.9 26.2 5.2s14.8-12.5 14.8-22.2l0-144c0-13.3-10.7-24-24-24L312 32c-9.7 0-18.5 5.8-22.2 14.8s-1.7 19.3 5.2 26.2l40 40-79 79-79-79 40-40c6.9-6.9 8.9-17.2 5.2-26.2S209.7 32 200 32z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-question-circle {
        display:inline-block;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M256 512A256 256 0 1 0 256 0a256 256 0 1 0 0 512zM169.8 165.3c7.9-22.3 29.1-37.3 52.8-37.3l58.3 0c34.9 0 63.1 28.3 63.1 63.1c0 22.6-12.1 43.5-31.7 54.8L280 264.4c-.2 13-10.9 23.6-24 23.6c-13.3 0-24-10.7-24-24l0-13.5c0-8.6 4.6-16.5 12.1-20.8l44.3-25.4c4.7-2.7 7.6-7.7 7.6-13.1c0-8.4-6.8-15.1-15.1-15.1l-58.3 0c-3.4 0-6.4 2.1-7.5 5.3l-.4 1.2c-4.4 12.5-18.2 19-30.6 14.6s-19-18.2-14.6-30.6l.4-1.2zM224 352a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-check {
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 448 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M438.6 105.4c12.5 12.5 12.5 32.8 0 45.3l-256 256c-12.5 12.5-32.8 12.5-45.3 0l-128-128c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0L160 338.7 393.4 105.4c12.5-12.5 32.8-12.5 45.3 0z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .fa.fa-pencil {
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'><!--!Font Awesome Free 6.5.1 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d='M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1v32c0 8.8 7.2 16 16 16h32zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z'/></svg>");
        background-repeat: no-repeat;
        width: 15px;
        height: 15px;
        background-position-y: center;
    }

    .CodeMirror {
      font-family: monospace;
      height: 300px;
      color: #000;
      direction: ltr
    }

    .CodeMirror-lines {
        padding: 4px 0
    }

    .CodeMirror pre.CodeMirror-line,
    .CodeMirror pre.CodeMirror-line-like {
        padding: 0 4px
    }

    .CodeMirror-gutter-filler,
    .CodeMirror-scrollbar-filler {
        background-color: #fff
    }

    .CodeMirror-gutters {
        border-right: 1px solid #ddd;
        background-color: #f7f7f7;
        white-space: nowrap
    }

    .CodeMirror-linenumber {
        padding: 0 3px 0 5px;
        min-width: 20px;
        text-align: right;
        color: #999;
        white-space: nowrap
    }

    .CodeMirror-guttermarker {
        color: #000
    }

    .CodeMirror-guttermarker-subtle {
        color: #999
    }

    .CodeMirror-cursor {
        border-left: 1px solid #000;
        border-right: none;
        width: 0
    }

    .CodeMirror div.CodeMirror-secondarycursor {
        border-left: 1px solid silver
    }

    .cm-fat-cursor .CodeMirror-cursor {
        width: auto;
        border: 0 !important;
        background: #7e7
    }

    .cm-fat-cursor div.CodeMirror-cursors {
        z-index: 1
    }

    .cm-fat-cursor .CodeMirror-line::selection,
    .cm-fat-cursor .CodeMirror-line>span::selection,
    .cm-fat-cursor .CodeMirror-line>span>span::selection {
        background: 0 0
    }

    .cm-fat-cursor .CodeMirror-line::-moz-selection,
    .cm-fat-cursor .CodeMirror-line>span::-moz-selection,
    .cm-fat-cursor .CodeMirror-line>span>span::-moz-selection {
        background: 0 0
    }

    .cm-fat-cursor {
        caret-color: transparent
    }

    @-moz-keyframes blink {
        50% {
            background-color: transparent
        }
    }

    @-webkit-keyframes blink {
        50% {
            background-color: transparent
        }
    }

    @keyframes blink {
        50% {
            background-color: transparent
        }
    }

    .cm-tab {
        display: inline-block;
        text-decoration: inherit
    }

    .CodeMirror-rulers {
        position: absolute;
        left: 0;
        right: 0;
        top: -50px;
        bottom: 0;
        overflow: hidden
    }

    .CodeMirror-ruler {
        border-left: 1px solid #ccc;
        top: 0;
        bottom: 0;
        position: absolute
    }

    .cm-s-default .cm-header {
        color: #00f
    }

    .cm-s-default .cm-quote {
        color: #090
    }

    .cm-negative {
        color: #d44
    }

    .cm-positive {
        color: #292
    }

    .cm-header,
    .cm-strong {
        font-weight: 700
    }

    .cm-em {
        font-style: italic
    }

    .cm-link {
        text-decoration: underline
    }

    .cm-strikethrough {
        text-decoration: line-through
    }

    .cm-s-default .cm-keyword {
        color: #708
    }

    .cm-s-default .cm-atom {
        color: #219
    }

    .cm-s-default .cm-number {
        color: #164
    }

    .cm-s-default .cm-def {
        color: #00f
    }

    .cm-s-default .cm-variable-2 {
        color: #05a
    }

    .cm-s-default .cm-type,
    .cm-s-default .cm-variable-3 {
        color: #085
    }

    .cm-s-default .cm-comment {
        color: #a50
    }

    .cm-s-default .cm-string {
        color: #a11
    }

    .cm-s-default .cm-string-2 {
        color: #f50
    }

    .cm-s-default .cm-meta {
        color: #555
    }

    .cm-s-default .cm-qualifier {
        color: #555
    }

    .cm-s-default .cm-builtin {
        color: #30a
    }

    .cm-s-default .cm-bracket {
        color: #997
    }

    .cm-s-default .cm-tag {
        color: #170
    }

    .cm-s-default .cm-attribute {
        color: #00c
    }

    .cm-s-default .cm-hr {
        color: #999
    }

    .cm-s-default .cm-link {
        color: #00c
    }

    .cm-s-default .cm-error {
        color: red
    }

    .cm-invalidchar {
        color: red
    }

    .CodeMirror-composing {
        border-bottom: 2px solid
    }

    div.CodeMirror span.CodeMirror-matchingbracket {
        color: #0b0
    }

    div.CodeMirror span.CodeMirror-nonmatchingbracket {
        color: #a22
    }

    .CodeMirror-matchingtag {
        background: rgba(255, 150, 0, .3)
    }

    .CodeMirror-activeline-background {
        background: #e8f2ff
    }

    .CodeMirror {
        position: relative;
        overflow: hidden;
        background: #fff
    }

    .CodeMirror-scroll {
        overflow: scroll !important;
        margin-bottom: -50px;
        margin-right: -50px;
        padding-bottom: 50px;
        height: 100%;
        outline: 0;
        position: relative;
        z-index: 0
    }

    .CodeMirror-sizer {
        position: relative;
        border-right: 50px solid transparent
    }

    .CodeMirror-gutter-filler,
    .CodeMirror-hscrollbar,
    .CodeMirror-scrollbar-filler,
    .CodeMirror-vscrollbar {
        position: absolute;
        z-index: 6;
        display: none;
        outline: 0
    }

    .CodeMirror-vscrollbar {
        right: 0;
        top: 0;
        overflow-x: hidden;
        overflow-y: scroll
    }

    .CodeMirror-hscrollbar {
        bottom: 0;
        left: 0;
        overflow-y: hidden;
        overflow-x: scroll
    }

    .CodeMirror-scrollbar-filler {
        right: 0;
        bottom: 0
    }

    .CodeMirror-gutter-filler {
        left: 0;
        bottom: 0
    }

    .CodeMirror-gutters {
        position: absolute;
        left: 0;
        top: 0;
        min-height: 100%;
        z-index: 3
    }

    .CodeMirror-gutter {
        white-space: normal;
        height: 100%;
        display: inline-block;
        vertical-align: top;
        margin-bottom: -50px
    }

    .CodeMirror-gutter-wrapper {
        position: absolute;
        z-index: 4;
        background: 0 0 !important;
        border: none !important
    }

    .CodeMirror-gutter-background {
        position: absolute;
        top: 0;
        bottom: 0;
        z-index: 4
    }

    .CodeMirror-gutter-elt {
        position: absolute;
        cursor: default;
        z-index: 4
    }

    .CodeMirror-gutter-wrapper ::selection {
        background-color: transparent
    }

    .CodeMirror-gutter-wrapper ::-moz-selection {
        background-color: transparent
    }

    .CodeMirror-lines {
        cursor: text;
        min-height: 1px
    }

    .CodeMirror pre.CodeMirror-line,
    .CodeMirror pre.CodeMirror-line-like {
        -moz-border-radius: 0;
        -webkit-border-radius: 0;
        border-radius: 0;
        border-width: 0;
        background: 0 0;
        font-family: inherit;
        font-size: inherit;
        margin: 0;
        white-space: pre;
        word-wrap: normal;
        line-height: inherit;
        color: inherit;
        z-index: 2;
        position: relative;
        overflow: visible;
        -webkit-tap-highlight-color: transparent;
        -webkit-font-variant-ligatures: contextual;
        font-variant-ligatures: contextual
    }

    .CodeMirror-wrap pre.CodeMirror-line,
    .CodeMirror-wrap pre.CodeMirror-line-like {
        word-wrap: break-word;
        white-space: pre-wrap;
        word-break: normal
    }

    .CodeMirror-linebackground {
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        z-index: 0
    }

    .CodeMirror-linewidget {
        position: relative;
        z-index: 2;
        padding: .1px
    }

    .CodeMirror-rtl pre {
        direction: rtl
    }

    .CodeMirror-code {
        outline: 0
    }

    .CodeMirror-gutter,
    .CodeMirror-gutters,
    .CodeMirror-linenumber,
    .CodeMirror-scroll,
    .CodeMirror-sizer {
        -moz-box-sizing: content-box;
        box-sizing: content-box
    }

    .CodeMirror-measure {
        position: absolute;
        width: 100%;
        height: 0;
        overflow: hidden;
        visibility: hidden
    }

    .CodeMirror-cursor {
        position: absolute;
        pointer-events: none
    }

    .CodeMirror-measure pre {
        position: static
    }

    div.CodeMirror-cursors {
        visibility: hidden;
        position: relative;
        z-index: 3
    }

    div.CodeMirror-dragcursors {
        visibility: visible
    }

    .CodeMirror-focused div.CodeMirror-cursors {
        visibility: visible
    }

    .CodeMirror-selected {
        background: #d9d9d9
    }

    .CodeMirror-focused .CodeMirror-selected {
        background: #d7d4f0
    }

    .CodeMirror-crosshair {
        cursor: crosshair
    }

    .CodeMirror-line::selection,
    .CodeMirror-line>span::selection,
    .CodeMirror-line>span>span::selection {
        background: #d7d4f0
    }

    .CodeMirror-line::-moz-selection,
    .CodeMirror-line>span::-moz-selection,
    .CodeMirror-line>span>span::-moz-selection {
        background: #d7d4f0
    }

    .cm-searching {
        background-color: #ffa;
        background-color: rgba(255, 255, 0, .4)
    }

    .cm-force-border {
        padding-right: .1px
    }

    @media print {
        .CodeMirror div.CodeMirror-cursors {
            visibility: hidden
        }
    }

    .cm-tab-wrap-hack:after {
        content: ''
    }

    span.CodeMirror-selectedtext {
        background: 0 0
    }

    .EasyMDEContainer {
        display: block
    }

    .CodeMirror-rtl pre {
        direction: rtl
    }

    .EasyMDEContainer.sided--no-fullscreen {
        display: flex;
        flex-direction: row;
        flex-wrap: wrap
    }

    .EasyMDEContainer .CodeMirror {
        box-sizing: border-box;
        height: auto;
        border: 1px solid #ced4da;
        border-bottom-left-radius: 4px;
        border-bottom-right-radius: 4px;
        padding: 10px;
        font: inherit;
        z-index: 0;
        word-wrap: break-word
    }

    .EasyMDEContainer .CodeMirror-scroll {
        cursor: text
    }

    .EasyMDEContainer .CodeMirror-fullscreen {
        background: #fff;
        position: fixed !important;
        top: 50px;
        left: 0;
        right: 0;
        bottom: 0;
        height: auto;
        z-index: 8;
        border-right: none !important;
        border-bottom-right-radius: 0 !important
    }

    .EasyMDEContainer .CodeMirror-sided {
        width: 50% !important
    }

    .EasyMDEContainer.sided--no-fullscreen .CodeMirror-sided {
        border-right: none !important;
        border-bottom-right-radius: 0;
        position: relative;
        flex: 1 1 auto
    }

    .EasyMDEContainer .CodeMirror-placeholder {
        opacity: .5
    }

    .EasyMDEContainer .CodeMirror-focused .CodeMirror-selected {
        background: #d9d9d9
    }

    .editor-toolbar {
        position: relative;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        -o-user-select: none;
        user-select: none;
        padding: 9px 10px;
        border-top: 1px solid #ced4da;
        border-left: 1px solid #ced4da;
        border-right: 1px solid #ced4da;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px
    }

    .editor-toolbar.fullscreen {
        width: 100%;
        height: 50px;
        padding-top: 10px;
        padding-bottom: 10px;
        box-sizing: border-box;
        background: #fff;
        border: 0;
        position: fixed;
        top: 0;
        left: 0;
        opacity: 1;
        z-index: 9
    }

    .editor-toolbar.fullscreen::before {
        width: 20px;
        height: 50px;
        background: -moz-linear-gradient(left, #fff 0, rgba(255, 255, 255, 0) 100%);
        background: -webkit-gradient(linear, left top, right top, color-stop(0, #fff), color-stop(100%, rgba(255, 255, 255, 0)));
        background: -webkit-linear-gradient(left, #fff 0, rgba(255, 255, 255, 0) 100%);
        background: -o-linear-gradient(left, #fff 0, rgba(255, 255, 255, 0) 100%);
        background: -ms-linear-gradient(left, #fff 0, rgba(255, 255, 255, 0) 100%);
        background: linear-gradient(to right, #fff 0, rgba(255, 255, 255, 0) 100%);
        position: fixed;
        top: 0;
        left: 0;
        margin: 0;
        padding: 0
    }

    .editor-toolbar.fullscreen::after {
        width: 20px;
        height: 50px;
        background: -moz-linear-gradient(left, rgba(255, 255, 255, 0) 0, #fff 100%);
        background: -webkit-gradient(linear, left top, right top, color-stop(0, rgba(255, 255, 255, 0)), color-stop(100%, #fff));
        background: -webkit-linear-gradient(left, rgba(255, 255, 255, 0) 0, #fff 100%);
        background: -o-linear-gradient(left, rgba(255, 255, 255, 0) 0, #fff 100%);
        background: -ms-linear-gradient(left, rgba(255, 255, 255, 0) 0, #fff 100%);
        background: linear-gradient(to right, rgba(255, 255, 255, 0) 0, #fff 100%);
        position: fixed;
        top: 0;
        right: 0;
        margin: 0;
        padding: 0
    }

    .EasyMDEContainer.sided--no-fullscreen .editor-toolbar {
        width: 100%
    }

    .editor-toolbar .easymde-dropdown,
    .editor-toolbar button {
        background: 0 0;
        display: inline-block;
        text-align: center;
        text-decoration: none !important;
        height: 30px;
        margin: 0;
        padding: 0;
        border: 1px solid transparent;
        border-radius: 3px;
        cursor: pointer
    }

    .editor-toolbar button {
        font-weight: 700;
        min-width: 30px;
        padding: 0 6px;
        white-space: nowrap
    }

    .editor-toolbar button.active,
    .editor-toolbar button:hover {
        background: #fcfcfc;
        border-color: #95a5a6
    }

    .editor-toolbar i.separator {
        display: inline-block;
        width: 0;
        border-left: 1px solid #d9d9d9;
        border-right: 1px solid #fff;
        color: transparent;
        text-indent: -10px;
        margin: 0 6px
    }

    .editor-toolbar button:after {
        font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
        font-size: 65%;
        vertical-align: text-bottom;
        position: relative;
        top: 2px
    }

    .editor-toolbar button.heading-1:after {
        content: "1"
    }

    .editor-toolbar button.heading-2:after {
        content: "2"
    }

    .editor-toolbar button.heading-3:after {
        content: "3"
    }

    .editor-toolbar button.heading-bigger:after {
        content: "▲"
    }

    .editor-toolbar button.heading-smaller:after {
        content: "▼"
    }

    .editor-toolbar.disabled-for-preview button:not(.no-disable) {
        opacity: .6;
        pointer-events: none
    }

    @media only screen and (max-width:700px) {
        .editor-toolbar i.no-mobile {
            display: none
        }
    }

    .editor-statusbar {
        padding: 8px 10px;
        font-size: 12px;
        color: #959694;
        text-align: right
    }

    .EasyMDEContainer.sided--no-fullscreen .editor-statusbar {
        width: 100%
    }

    .editor-statusbar span {
        display: inline-block;
        min-width: 4em;
        margin-left: 1em
    }

    .editor-statusbar .lines:before {
        content: 'lines: '
    }

    .editor-statusbar .words:before {
        content: 'words: '
    }

    .editor-statusbar .characters:before {
        content: 'characters: '
    }

    .editor-preview-full {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        z-index: 7;
        overflow: auto;
        display: none;
        box-sizing: border-box
    }

    .editor-preview-side {
        position: fixed;
        bottom: 0;
        width: 50%;
        top: 50px;
        right: 0;
        z-index: 9;
        overflow: auto;
        display: none;
        box-sizing: border-box;
        border: 1px solid #ddd;
        word-wrap: break-word
    }

    .editor-preview-active-side {
        display: block
    }

    .EasyMDEContainer.sided--no-fullscreen .editor-preview-active-side {
        flex: 1 1 auto;
        height: auto;
        position: static
    }

    .editor-preview-active {
        display: block
    }

    .editor-preview {
        padding: 10px;
        background: #fafafa
    }

    .editor-preview>p {
        margin-top: 0
    }

    .editor-preview pre {
        background: #eee;
        margin-bottom: 10px
    }

    .editor-preview table td,
    .editor-preview table th {
        border: 1px solid #ddd;
        padding: 5px
    }

    .cm-s-easymde .cm-tag {
        color: #63a35c
    }

    .cm-s-easymde .cm-attribute {
        color: #795da3
    }

    .cm-s-easymde .cm-string {
        color: #183691
    }

    .cm-s-easymde .cm-header-1 {
        font-size: calc(1.375rem + 1.5vw)
    }

    .cm-s-easymde .cm-header-2 {
        font-size: calc(1.325rem + .9vw)
    }

    .cm-s-easymde .cm-header-3 {
        font-size: calc(1.3rem + .6vw)
    }

    .cm-s-easymde .cm-header-4 {
        font-size: calc(1.275rem + .3vw)
    }

    .cm-s-easymde .cm-header-5 {
        font-size: 1.25rem
    }

    .cm-s-easymde .cm-header-6 {
        font-size: 1rem
    }

    .cm-s-easymde .cm-header-1,
    .cm-s-easymde .cm-header-2,
    .cm-s-easymde .cm-header-3,
    .cm-s-easymde .cm-header-4,
    .cm-s-easymde .cm-header-5,
    .cm-s-easymde .cm-header-6 {
        margin-bottom: .5rem;
        line-height: 1.2
    }

    .cm-s-easymde .cm-comment {
        background: rgba(0, 0, 0, .05);
        border-radius: 2px
    }

    .cm-s-easymde .cm-link {
        color: #7f8c8d
    }

    .cm-s-easymde .cm-url {
        color: #aab2b3
    }

    .cm-s-easymde .cm-quote {
        color: #7f8c8d;
        font-style: italic
    }

    .editor-toolbar .easymde-dropdown {
        position: relative;
        background: linear-gradient(to bottom right, #fff 0, #fff 84%, #333 50%, #333 100%);
        border-radius: 0;
        border: 1px solid #fff
    }

    .editor-toolbar .easymde-dropdown:hover {
        background: linear-gradient(to bottom right, #fff 0, #fff 84%, #333 50%, #333 100%)
    }

    .easymde-dropdown-content {
        display: block;
        visibility: hidden;
        position: absolute;
        background-color: #f9f9f9;
        box-shadow: 0 8px 16px 0 rgba(0, 0, 0, .2);
        padding: 8px;
        z-index: 2;
        top: 30px
    }

    .easymde-dropdown:active .easymde-dropdown-content,
    .easymde-dropdown:focus .easymde-dropdown-content,
    .easymde-dropdown:focus-within .easymde-dropdown-content {
        visibility: visible
    }

    .easymde-dropdown-content button {
        display: block
    }

    span[data-img-src]::after {
        content: '';
        background-image: var(--bg-image);
        display: block;
        max-height: 100%;
        max-width: 100%;
        background-size: contain;
        height: 0;
        padding-top: var(--height);
        width: var(--width);
        background-repeat: no-repeat
    }

    .CodeMirror .cm-spell-error:not(.cm-url):not(.cm-comment):not(.cm-tag):not(.cm-word) {
        background: rgba(255, 0, 0, .15)
    }

    `;
__decorate([
    property({ type: String, reflect: true })
], CollabEditMd.prototype, "value", void 0);
__decorate([
    property({ type: Boolean })
], CollabEditMd.prototype, "opened", void 0);
__decorate([
    query('.editor-md-container')
], CollabEditMd.prototype, "containerEditor", void 0);
__decorate([
    query('.md-section-editor')
], CollabEditMd.prototype, "containerQuillEditor", void 0);
__decorate([
    query('.fa-check')
], CollabEditMd.prototype, "iconFinish", void 0);
__decorate([
    query('.fa-pencil')
], CollabEditMd.prototype, "iconEdit", void 0);
CollabEditMd = __decorate([
    customElement('collab-edit-md-100554')
], CollabEditMd);
export { CollabEditMd };
