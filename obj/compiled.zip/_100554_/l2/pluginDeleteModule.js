/// <mls fileReference="_100554_/l2/pluginDeleteModule.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html } from "lit";
import { customElement, state, property } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
import { removeModule } from "/_100554_/l2/projectAST.js";
import { removeTokensTheme } from "/_100554_/l2/designSystemBase.js";
import { deleteFile } from "/_100554_/l2/collabLibStor.js";
const message_pt = {
  btnDelete: "Deletar",
  lblConfirm: "Digite o nome do m\xF3dulo para confirmar:",
  lblFiles: "Arquivos a serem deletados:",
  errInvalid: "Nome do m\xF3dulo incorreto",
  deletedFeedback: "Os arquivos foram marcados para dele\xE7\xE3o e est\xE3o prontos para salvar e fazer pull request."
};
const message_en = {
  btnDelete: "Delete",
  lblConfirm: "Type the module name to confirm:",
  lblFiles: "Files to be deleted:",
  errInvalid: "Wrong module name",
  deletedFeedback: "Files have been marked for deletion and are ready to save and create a pull request."
};
const messages = {
  "pt": message_pt,
  "en": message_en
};
let PluginDeleteModule = class extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`plugin-delete-module-100554 {
  display: block;
  padding: 1rem;
}
plugin-delete-module-100554 .plugin-delete-module-container {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}
plugin-delete-module-100554 input {
  margin-top: 0.2rem;
  width: 300px;
  display: block;
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 6px;
}
plugin-delete-module-100554 input.invalid {
  border-color: var(--error-color);
  background: #ffe6e6;
}
plugin-delete-module-100554 .error-msg {
  font-size: 0.9rem;
  color: var(--error-color);
}
plugin-delete-module-100554 .feedback-msg {
  padding: 0.5rem 1rem;
  color: var(--text-primary-color);
  border-radius: 4px;
  font-size: 0.9rem;
}
plugin-delete-module-100554 button {
  padding: 0.6rem 1rem;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  background: var(--error-color);
  color: white;
  font-weight: bold;
  transition: opacity 0.2s;
  width: 150px;
}
plugin-delete-module-100554 button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
plugin-delete-module-100554 details summary {
  cursor: pointer;
}
plugin-delete-module-100554 details ul {
  list-style: none;
}
plugin-delete-module-100554 details ul li {
  margin-bottom: 0.2rem;
}
plugin-delete-module-100554 details ul {
  margin: 0.5rem 0;
  padding-left: 1.2rem;
}
`);
    }
  msg = messages["en"];
  moduleName = "travel";
  project = "102009";
  filesToDelete = [];
  confirmInput = "";
  isDeleting = false;
  isDeleted = false;
  feedbackMsg = "";
  async firstUpdated(changedProperties) {
    super.firstUpdated(changedProperties);
    this.filesToDelete = this.getFilesModule();
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    const isValid = this.confirmInput.trim() === this.moduleName;
    if (this.isDeleted) {
      return html`  <div class="plugin-delete-module-container">${this.feedbackMsg ? html`<div class="feedback-msg">${this.feedbackMsg}</div>` : ""}</div>`;
    }
    return html`
      <div class="plugin-delete-module-container">

        <label>
          ${this.msg.lblConfirm}
          <input 
            type="text" 
            class=${isValid || this.confirmInput === "" ? "" : "invalid"}
            .value=${this.confirmInput}
            @input=${(e) => this.confirmInput = e.target.value}
            placeholder=${this.moduleName}
          />
        </label>
        ${!isValid && this.confirmInput !== "" ? html`
          <div class="error-msg">${this.msg.errInvalid}</div>
        ` : ""}

        <details>
          <summary>${this.msg.lblFiles} (${this.filesToDelete.length})</summary>
          <ul>
            ${this.filesToDelete.slice().sort((a, b) => a.shortName.localeCompare(b.shortName)).map((file) => html`
                <li>${this.getFileKey(file)}</li>
              `)}
          </ul>
        </details>

        ${this.feedbackMsg ? html`<div class="feedback-msg">${this.feedbackMsg}</div>` : ""}
        <button 
          style="${this.isDeleted ? "display:none" : "display:block"}"
          ?disabled=${!isValid || this.isDeleting}
          @click=${this.handleDelete}>
          ${this.isDeleting ? "..." : this.msg.btnDelete}
        </button>
      </div>
    `;
  }
  getFilesModule() {
    return Object.values(mls.stor.files).filter(
      (file) => file.project === +this.project && (file.folder === this.moduleName || file.folder.split("/").shift() === this.moduleName)
    );
  }
  getFileKey(file) {
    return file.folder ? `_${file.project}_${file.folder}/${file.shortName}${file.extension}` : `_${file.project}_${file.shortName}${file.extension}`;
  }
  async handleDelete() {
    if (this.confirmInput.trim() !== this.moduleName) return;
    this.isDeleting = true;
    this.feedbackMsg = "";
    try {
      await this.removeTokensIfNeeded(+this.project, this.moduleName);
      await this.deleteAllFiles(this.filesToDelete);
      await removeModule(+this.project, this.moduleName, true);
      this.filesToDelete = [];
      this.confirmInput = "";
      this.feedbackMsg = this.msg.deletedFeedback;
      this.isDeleted = true;
    } catch (err) {
      console.error("Error deleting module:", err);
    } finally {
      this.isDeleting = false;
    }
  }
  async deleteAllFiles(files) {
    for await (let stor of files) {
      await deleteFile(stor);
    }
  }
  async removeTokensIfNeeded(project, moduleName) {
    const shortName = "designSystem";
    const folder = "";
    const key = mls.stor.getKeyToFiles(project, 2, shortName, folder, ".ts");
    const storFile = mls.stor.files[key];
    if (!storFile) return;
    await removeTokensTheme(project, moduleName);
  }
};
__decorateClass([
  property()
], PluginDeleteModule.prototype, "moduleName", 2);
__decorateClass([
  property()
], PluginDeleteModule.prototype, "project", 2);
__decorateClass([
  state()
], PluginDeleteModule.prototype, "filesToDelete", 2);
__decorateClass([
  state()
], PluginDeleteModule.prototype, "confirmInput", 2);
__decorateClass([
  state()
], PluginDeleteModule.prototype, "isDeleting", 2);
__decorateClass([
  state()
], PluginDeleteModule.prototype, "isDeleted", 2);
__decorateClass([
  state()
], PluginDeleteModule.prototype, "feedbackMsg", 2);
PluginDeleteModule = __decorateClass([
  customElement("plugin-delete-module-100554")
], PluginDeleteModule);
export {
  PluginDeleteModule
};
