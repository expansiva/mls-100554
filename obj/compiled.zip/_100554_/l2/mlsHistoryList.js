/// <mls fileReference="_100554_/l2/mlsHistoryList.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html, unsafeHTML } from "lit";
import { customElement, property } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
let MlsHistoryList = class extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`mls-history-list-100554 ul {
  list-style: none;
  padding-inline-start: 0;
}
mls-history-list-100554 ul details {
  cursor: pointer;
  margin-bottom: 4px;
  line-height: 2em;
}
mls-history-list-100554 ul details summary {
  border-bottom: 1px solid var(--grey-color-dark);
  background: var(--bg-secondary-color-lighter);
  outline: none;
  user-select: none;
}
mls-history-list-100554 ul .historie-item {
  display: flex;
  cursor: pointer;
  line-height: 3em;
  position: relative;
  padding-left: 2rem;
  gap: 1rem;
  align-items: center;
}
mls-history-list-100554 ul .historie-item.active {
  background: var(--grey-color-light);
}
mls-history-list-100554 ul .historie-item .historie-lines {
  width: 70px;
}
mls-history-list-100554 ul .historie-item .historie-additions {
  font-weight: bold;
  color: var(--success-color);
}
mls-history-list-100554 ul .historie-item .historie-deletions {
  font-weight: bold;
  color: var(--error-color);
}
mls-history-list-100554 ul .historie-item img {
  cursor: pointer;
  width: 30px;
  height: 30px;
  background-size: cover;
  background-position: top center;
  border-radius: 50%;
}
mls-history-list-100554 ul .historie-item:hover {
  background-color: var(--bg-secondary-color-lighter);
}
`);
    }
  project = 100554;
  shortName = "mlsStartL2";
  position = "left";
  folder = "";
  level = 2;
  extension = ".ts";
  loading = true;
  error = "";
  data = [];
  async connectedCallback() {
    super.connectedCallback();
    await this.getListHistory();
    this.loading = false;
  }
  async getListHistory() {
    try {
      const key = mls.stor.getKeyToFiles(this.project, this.level, this.shortName, this.folder, this.extension);
      const storFile = mls.stor.files[key];
      const historie = await storFile.getHistory();
      const data = this.createJson(historie);
      this.data = data;
    } catch (e) {
      this.error = `
            <div style="width:80%; padding:20px; border:1px solid #eee; border-left-width:5px; border-radius: 3px; margin:10px auto; border-left-color: #d9534f; background-color: rgba(217, 83, 79, 0.1); ">
                <strong style="color:#d9534f;">Error</strong>- 
                ${e}
            </div>`;
    }
  }
  attributeChangedCallback(name, oldVal, newVal) {
    super.attributeChangedCallback(name, oldVal, newVal);
    if (name === "msize") {
      const [width, height] = newVal.split(",");
      this.style.height = height + "px";
    }
  }
  createJson(gitObj) {
    if (!gitObj) return [];
    const today = /* @__PURE__ */ new Date();
    gitObj.forEach((item, index) => {
      const itemDate = new Date(item.data);
      const yesterday = new Date((/* @__PURE__ */ new Date()).setDate(today.getDate() - 1));
      if (today.toDateString() === itemDate.toDateString()) item.offsetDay = 0;
      if (yesterday.toDateString() === itemDate.toDateString()) item.offsetDay = 1;
      if (index === 0) item.firstItem = true;
      item.offsetWeek = this.getWeekOffet(itemDate, today);
      item.offsetMonth = today.getMonth() - itemDate.getMonth();
      item.offsetYear = today.getFullYear() - itemDate.getFullYear();
      item.index = this.findFirstInFilters(item);
      const filterTitle = this.filters[item.index].title;
      item.title = filterTitle.replace("{year}", itemDate.getFullYear().toString()).replace("{month}", `${itemDate.getFullYear()}-${("00" + (itemDate.getMonth() + 1)).slice(-2)}`);
    });
    return this.createJson2(gitObj);
  }
  createJson2(gitObj) {
    const ret = [];
    const ret2 = {};
    const objLocal = {};
    objLocal.title = "Local Changes";
    const localAuthor = localStorage.getItem("loginUser") || "unknow";
    const localItem = {
      author: localAuthor,
      authorUrl: "",
      dateAm: "",
      hash: "local",
      time: "",
      type: "item",
      linesDeleted: void 0,
      linesInserted: void 0
    };
    objLocal.type = "title";
    objLocal.itens = [];
    objLocal.itens.push(localItem);
    ret.push(objLocal);
    gitObj.forEach((item) => {
      if (ret2[item.title]) ret2[item.title].push(item);
      else ret2[item.title] = [item];
    });
    Object.keys(ret2).forEach((keys) => {
      const obj = {};
      ret.push(obj);
      ret2[keys].forEach((item, index) => {
        if (index === 0) {
          obj.title = item.title;
          obj.itens = [];
          obj.type = "title";
        }
        const dataItem = new Date(item.data);
        const dataFormat = this.formatDate(dataItem);
        const objItem = {
          author: item.authorName,
          time: dataFormat,
          dateAm: "",
          hash: item.ref,
          authorUrl: item.authorUrl,
          type: "item",
          linesDeleted: item.deletions,
          linesInserted: item.additions
        };
        obj.itens.push(objItem);
        obj.open = false;
      });
    });
    return ret;
  }
  filters = [
    {
      title: "Today",
      maxOffsetDays: 1
    },
    {
      title: "Yesterday",
      maxOffsetDays: 2
    },
    {
      title: "This week",
      maxOffsetWeek: 1
    },
    {
      title: "Last week",
      maxOffsetWeek: 2
    },
    {
      title: "This month",
      maxOffsetMonth: 1
    },
    {
      title: "In {month}",
      maxOffsetMonth: 11
    },
    {
      title: "In {year}"
    }
  ];
  findFirstInFilters(item) {
    for (let i = 0; i < this.filters.length; i++) {
      const it = this.filters[i];
      if (it.maxOffsetDays && item.offsetDay < it.maxOffsetDays || it.maxOffsetWeek && item.offsetWeek < it.maxOffsetWeek || it.maxOffsetMonth && item.offsetMonth < it.maxOffsetMonth && item.offsetYear === 0) {
        return i;
      }
    }
    return this.filters.length - 1;
  }
  getWeekOffet(dateStr, dateEnd) {
    const date1a = dateStr;
    const date2a = dateEnd;
    const dt = new Date(date1a.getFullYear(), 0, 1);
    const w1 = Math.ceil(((date1a - dt) / 864e5 + dt.getDay() + 1) / 7);
    const w2 = Math.ceil(((date2a - dt) / 864e5 + dt.getDay() + 1) / 7);
    return w2 - w1;
  }
  formatDate(dateValue) {
    const dataFormat = dateValue.getFullYear() + "-" + ("00" + (dateValue.getMonth() + 1)).slice(-2) + "-" + ("00" + dateValue.getDate()).slice(-2) + "  " + ("00" + dateValue.getHours()).slice(-2) + ":" + ("00" + dateValue.getMinutes()).slice(-2) + ":" + ("00" + dateValue.getSeconds()).slice(-2);
    return dataFormat;
  }
  handleClick(a) {
    const target = a.target;
    const li = target.closest("li");
    if (!li) return;
    this.querySelectorAll("li").forEach((l) => l.classList.remove("active"));
    li.classList.add("active");
    const hashModified = li.getAttribute("hash") || "";
    let nextLi = li.nextElementSibling;
    if (!nextLi) {
      const actualUl = li.closest("ul");
      const nextParentUl = actualUl?.closest("li");
      const nextUlLi = nextParentUl?.nextElementSibling;
      const nextUl = nextUlLi?.querySelector("ul");
      if (nextUl) nextLi = nextUl.children[0];
    }
    let hashOriginal = "";
    if (nextLi) hashOriginal = nextLi.getAttribute("hash") || "";
    const obj = {
      project: this.project,
      shortName: this.shortName,
      extension: this.extension,
      position: this.position,
      level: this.level,
      folder: this.folder,
      hashOriginal,
      hashModified
    };
    mls.events.fire([2], "HistoriesSelected", JSON.stringify(obj), 0);
  }
  render() {
    if (this.error !== "") {
      const obj = unsafeHTML(this.error);
      this.error = "";
      return obj;
    }
    return html`
      <div>
        ${this.loading ? html`<p>Loading...</p>` : html`
        <div>
          <ul>
                ${this.data.map((itemT) => html`
                    <li class="historie-title">
                        <details>
                            <summary>${itemT.title}</summary>
                            <div>
                                <ul>
                                    ${itemT.itens.map((itemH) => html`
                                        <li class="historie-item" hash="${itemH.hash}" @click="${this.handleClick}">
                                            <svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"/></svg>
                                            <span>${itemH.time}</span>
                                            <div class="historie-lines" style="${itemH.linesInserted === void 0 ? "display:none" : "display:inline-flex"}">
                                                <span class='historie-additions'>+${itemH.linesInserted}</span>
                                                <span class='historie-deletions'>-${itemH.linesDeleted}</span>
                                            </div>
                                            ${itemH.authorUrl ? html`<img src="${itemH.authorUrl}" alt="${itemH.author}"></img>` : html`<svg xmlns="http://www.w3.org/2000/svg" height="1em" viewBox="0 0 448 512"><!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. --><path d="M448 80v48c0 44.2-100.3 80-224 80S0 172.2 0 128V80C0 35.8 100.3 0 224 0S448 35.8 448 80zM393.2 214.7c20.8-7.4 39.9-16.9 54.8-28.6V288c0 44.2-100.3 80-224 80S0 332.2 0 288V186.1c14.9 11.8 34 21.2 54.8 28.6C99.7 230.7 159.5 240 224 240s124.3-9.3 169.2-25.3zM0 346.1c14.9 11.8 34 21.2 54.8 28.6C99.7 390.7 159.5 400 224 400s124.3-9.3 169.2-25.3c20.8-7.4 39.9-16.9 54.8-28.6V432c0 44.2-100.3 80-224 80S0 476.2 0 432V346.1z"/></svg>`} 
                                            <span>${itemH.author}</span>
                                        </li>
                                    `)}
                                </ul>
                            </div>
                        </details>
                    </li>
                `)}
          </ul>
          
        </div>
        `}
      </div>
    `;
  }
};
__decorateClass([
  property({ type: Number })
], MlsHistoryList.prototype, "project", 2);
__decorateClass([
  property({ type: String })
], MlsHistoryList.prototype, "shortName", 2);
__decorateClass([
  property({ type: String })
], MlsHistoryList.prototype, "position", 2);
__decorateClass([
  property({ type: String })
], MlsHistoryList.prototype, "folder", 2);
__decorateClass([
  property({ type: Number })
], MlsHistoryList.prototype, "level", 2);
__decorateClass([
  property({ type: String })
], MlsHistoryList.prototype, "extension", 2);
__decorateClass([
  property({ type: Boolean })
], MlsHistoryList.prototype, "loading", 2);
MlsHistoryList = __decorateClass([
  customElement("mls-history-list-100554")
], MlsHistoryList);
export {
  MlsHistoryList
};
