/// <mls fileReference="_100554_/l2/collabInit.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement } from 'lit/decorators.js';
async function getLocalProjectDeps() {
    const lib = await import('/_102027_/l2/libCommom.js');
    if (!lib || !lib.getLocalProjectDependencies)
        return [];
    const dependencies = lib.getLocalProjectDependencies();
    if (!dependencies.length)
        return [];
    return dependencies;
}
let on1CompileMonaco = true;
export async function initCompileMonaco(project) {
    if (!on1CompileMonaco)
        return true;
    try {
        // Monaco is loaded by the shell and may still be downloading when collab init runs.
        const monacoReady = window.monacoReady;
        if (monacoReady)
            await monacoReady;
        await mls.editor.InitMonaco();
        let depsActualProject = mls.l5.getProjectDependencies(project, false);
        if (project === mls.stor.LOCALPROJECTNUMBER)
            depsActualProject = await getLocalProjectDeps();
        const deps = [project, ...depsActualProject];
        for await (let prj of deps) {
            if ([100529, 100131].includes(prj))
                continue;
            const prjModel = mls.editor.getModels(prj, '', '', 2);
            if ((!prjModel || !prjModel.ts) && prj !== mls.stor.LOCALPROJECTNUMBER) {
                const info = await mls.stor.localDB.readPrjInfo(prj);
                if (info.indexModules)
                    mls.editor.createModelProjectDefinition(prj, info.indexModules);
            }
        }
        on1CompileMonaco = false;
    }
    catch (err) {
        throw new Error(err.message);
    }
    return true;
}
let CollabInit = class CollabInit extends LitElement {
    constructor() {
        super(...arguments);
        this.actualProject = 0;
        this.firstAccessLevels = Object.fromEntries(Array.from({ length: 8 }, (_, i) => [i, true]));
        this.levelHandlers = {
            2: this.onLevelChangedToL2.bind(this),
        };
        this.flags = {
            'en-US': './l3/_100529_/images/estados-unidos.png',
            'pt-BR': './l3/_100529_/images/brasil.png',
        };
        this.FILEL6 = 'projects';
        this.FILEL5 = 'modules';
        this.anonymousServices = {
            services: [
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                ';_100554_serviceDetail,',
            ]
        };
    }
    /**
     * Indicates if the user is anonymous based on the cookie loginUser
     * @returns `true` if the user is anonymous; otherwise, `false`.
     */
    get isAnonymous() {
        const cookieUser = mls.api.common.getCookie('loginUser');
        return cookieUser === 'anonymous' || !cookieUser;
    }
    /**
     * Retrieves the avatar URL from the `avatarUrl` attribute.
     * @returns The URL of the avatar, or an empty string if not defined.
     */
    get avatarUrl() {
        return this.getAttribute('avatarUrl') || '';
    }
    /**
     * Retrieves the base Project from the `baseProject` attribute.
     * @returns The URL of the avatar, or an empty string if not defined.
     */
    get baseProject() {
        return +(this.getAttribute('baseProject') || 100554);
    }
    /**
     * Lit lifecycle method called after the component is first updated.
     * Initializes the component's configuration.
     */
    firstUpdated() {
        this.init();
    }
    render() {
        return html ``;
    }
    /**
     * Initializes the system life cycle.
     * To show logs using: https://collab.codes/?traceLifeCycle=true
     */
    async init() {
        this.setDrivers();
        const language = this.setAndGetBaseUrl();
        this.setHTMLLang(language);
        this.initCoachMark();
        this.setTheme();
        this.setTokensCss();
        await this.loadProjectBase();
        this.actualProject = await this.setProjectActual();
        this.setOrgActual(this.actualProject);
        await this.loadLastProject();
        await this.setEventsModel();
        await this.setLastOpenedFiles();
        await this.setDefaultFiles();
        await this.setLastModule();
        this.showMessagesIfNeeded();
        const services = await this.getServices();
        this.setEvents();
        this.enableNav(this.avatarUrl, language, services, this.isAnonymous);
    }
    async setEventsModel() {
        try {
            await import('/_102027_/l2/libModel.js');
        }
        catch (e) {
        }
    }
    setEvents() {
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['LevelChanged'], this.onLevelChanged.bind(this));
    }
    onLevelChanged(ev) {
        if (!ev.desc)
            return;
        const data = JSON.parse(ev.desc);
        const handler = this.levelHandlers[data.to];
        if (handler)
            handler(data);
    }
    onLevelChangedToL2(data) {
        if (!this.firstAccessLevels[2])
            return;
        this.firstAccessLevels[2] = false;
    }
    /**
     * Loads and sets up collaboration drivers asynchronously.
     */
    async setDrivers() {
        if (window.traceLifeCycle)
            console.info('loading: drivers collab');
        await this.instanceDriverGitHub();
        await this.instanceDriverGitLab();
    }
    /**
     * Instantiates and registers the GitHub collaboration driver asynchronously.
     */
    async instanceDriverGitHub() {
        if (window.traceLifeCycle)
            console.info('loading: driver github');
        const { DriverGitHub } = await import('/_100554_/l2/driverGithub.js');
        const instanceGitHub = new DriverGitHub();
        const driverInstanceGitHub = mls.stor.others.getDriver('github');
        if (!driverInstanceGitHub)
            mls.stor.others.addDriver(instanceGitHub, 'github');
    }
    /**
     * Instantiates and registers the GitLab collaboration driver asynchronously.
     */
    async instanceDriverGitLab() {
        if (window.traceLifeCycle)
            console.info('loading: driver gitlab');
        const { DriverGitLab } = await import('/_100554_/l2/driverGitlab.js');
        const instanceGitLab = new DriverGitLab();
        const driverInstanceGitLab = mls.stor.others.getDriver('gitlab');
        if (!driverInstanceGitLab)
            mls.stor.others.addDriver(instanceGitLab, 'gitlab');
    }
    /**
     * Sets the base URL for the project and retrieves the user's language.
     * @returns The user's language (e.g., 'en-US', 'pt-BR').
     */
    setAndGetBaseUrl() {
        if (window.traceLifeCycle)
            console.info('setting: baseUrl');
        const language = this.getUserLanguageOrDefault();
        const base = document.head.querySelector('base');
        if (!base)
            return language;
        const lastHref = base.href;
        const parts = lastHref.split('/');
        parts.pop();
        parts.pop();
        const newHref = parts.join('/') + '/' + language.split('-')[0] + '/';
        base.href = newHref;
        return language;
    }
    /**
     * Retrieves the user's preferred language or defaults to 'en-US'.
     * @returns The user's language.
     */
    getUserLanguageOrDefault() {
        const navigatorLanguage = this.getNavigatorLanguage();
        const acceptLanguages = ['en-US', 'pt-BR'];
        const defaultLang = acceptLanguages.includes(navigatorLanguage) ? navigatorLanguage : 'en-US';
        let rcLanguage = defaultLang;
        const userSettings = localStorage.getItem('userSettings');
        if (userSettings) {
            const data = JSON.parse(userSettings);
            if (data.language && acceptLanguages.includes(data.language)) {
                rcLanguage = data.language;
            }
        }
        return rcLanguage;
    }
    /**
     * Retrieves the browser's language setting.
     * @returns The browser's language.
     */
    getNavigatorLanguage() {
        const lg = navigator.language ? navigator.language : '';
        return lg;
    }
    /**
     * Sets the `lang` attribute of the HTML `<html>` element.
     * @param lang The language code to set (e.g., 'en-US').
     */
    setHTMLLang(lang) {
        if (window.traceLifeCycle)
            console.info('setting: htmlLang');
        const htmlEl = document.documentElement;
        if (htmlEl)
            htmlEl.lang = lang;
    }
    async initCoachMark() {
        try {
            const module = await import('/_100554_/l2/collabManagerCoachMarks.js');
            if (!module || !module.initManagerCoachMark || typeof module.initManagerCoachMark !== 'function')
                return;
            module.initManagerCoachMark();
        }
        catch (err) {
            console.error('Error on listen initCoachMark' + err.message);
        }
    }
    /**
     * Sets the theme for the application based on user settings or OS preferences.
     */
    setTheme() {
        if (window.traceLifeCycle)
            console.info('setting: theme');
        const theme = this.getTheme();
        const htmlEl = document.documentElement;
        if (theme === 'dark' && htmlEl) {
            htmlEl.setAttribute('data-theme', 'dark');
            htmlEl.classList.add('dark');
        }
    }
    /**
     * Retrieves the theme from user settings or defaults to the OS preference.
     * @returns The theme ('dark' or 'light').
     */
    getTheme() {
        let theme = localStorage.getItem('_100554_serviceUserSettings_theme');
        if (!theme || theme === 'default') {
            theme = this.getUserThemeOS();
        }
        return theme;
    }
    /**
     * Retrieves the user's OS theme preference.
     * @returns The OS theme preference ('dark' or 'light').
     */
    getUserThemeOS() {
        const isDarkMode = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        return isDarkMode ? 'dark' : 'light';
    }
    /**
     * Sets CSS tokens for light and dark themes by retrieving data from a cache.
     */
    async setTokensCss() {
        if (window.traceLifeCycle)
            console.info('setting: tokens');
        try {
            const module = await import('/_102027_/l2/designSystemBase.js');
            if (!module || !module.getTokensCss || typeof module.getTokensCss !== 'function')
                return;
            const tokensCss = await module.getTokensCss(this.baseProject, 'Default');
            const style = document.createElement('style');
            style.textContent = tokensCss;
            style.id = 'collab-tokens';
            document.head.appendChild(style);
        }
        catch (err) {
            console.error('Error on listen initCoachMark' + err.message);
        }
    }
    /**
     * Configures navigation settings, including avatar and status, for the collaboration interface.
     * @param avatarUrl The URL of the avatar.
     * @param language The user's language.
     * @param isAnonymous Indicates whether the user is anonymous.
     */
    enableNav(avatarUrl, language, services, isAnonymous) {
        if (window.traceLifeCycle)
            console.info('enableNav: collab-nav-1');
        const collabNav1 = document.querySelector('collab-nav-1');
        if (!collabNav1)
            return;
        //if (avatarUrl) collabNav1.changeIconToImage(7, avatarUrl, { text: language, img: this.flags[language] });
        if (avatarUrl)
            collabNav1.changeIconToImage(7, avatarUrl);
        const state = isAnonymous ? 'anonymous' : 'enabled';
        if (window.traceLifeCycle)
            console.info(`setting: status collab-nav-1 : ${state}`);
        collabNav1.services = services;
        collabNav1.setAttribute('status', state);
    }
    /**
     * Retrieves the last selected project ID from localStorage.
     * @returns The last selected project ID as a number, or `undefined` if not found.
     */
    async getLastProjectSelected() {
        if (window.traceLifeCycle)
            console.info('getLastProjectSelected');
        try {
            const lib = await import('/_102027_/l2/libCommom.js');
            if (!lib || !lib.getProjectDetails || !lib.setProjectDetails)
                return;
            const info = lib.getProjectDetails();
            const lastPrj = info ? info.project : this.baseProject;
            lib.setProjectDetails(lastPrj);
            return lastPrj;
        }
        catch (err) {
            console.error(err.message);
            return undefined;
        }
    }
    /**
     * Sets the actual project in the `mls` structure based on the last selected project.
     * @returns The last selected project ID as a number, or `undefined` if not found.
     */
    async setProjectActual() {
        if (window.traceLifeCycle)
            console.info('setProjectActual');
        const project = await this.getLastProjectSelected();
        mls.setActualProject(project ? project : this.baseProject);
        return project;
    }
    /**
     * Sets the current organization in the `mls` structure based on the provided project ID.
     * @param project The project ID to determine the organization index.
     */
    setOrgActual(project) {
        if (window.traceLifeCycle)
            console.info(`setOrgActual for project: ${project}`);
        if (!project && !this.baseProject)
            return;
        const orgIndex = mls.l5.getProjectOrgIndex(project || this.baseProject);
        mls.l5.setActualOrg(orgIndex);
    }
    /**
     * Asynchronously loads the base project information if it is not already loaded.
     * Utilizes the `mls.stor.server.loadProjectInfoIfNeeded` method with the base project ID.
     * @returns A promise that resolves when the base project information is loaded.
     */
    async loadProjectBase() {
        if (window.traceLifeCycle)
            console.info(`loadProjectBase: ${this.baseProject}`);
        await mls.stor.server.loadProjectInfoIfNeeded(this.baseProject);
    }
    /**
     * Loads the information of the last accessed project if it exists.
     * If the `actualProject` is defined, it attempts to load the project's information
     * from the server using the `loadProjectInfoIfNeeded` method.
     *
     * Optionally logs the lifecycle trace if the global `traceLifeCycle` is enabled.
     *
     * @returns A promise that resolves when the project information has been loaded.
     */
    async loadLastProject() {
        try {
            if (window.traceLifeCycle)
                console.info(`loadLastProject: ${this.actualProject}`);
            if (!this.actualProject)
                return;
            const depsActualProject = mls.l5.getProjectDependencies(this.actualProject, false);
            const deps = [this.actualProject, ...depsActualProject];
            for await (let prj of deps) {
                if (this.actualProject && this.actualProject !== mls.stor.LOCALPROJECTNUMBER)
                    await mls.stor.server.loadProjectInfoIfNeeded(prj);
            }
            if (this.actualProject === mls.stor.LOCALPROJECTNUMBER) {
                const localProjectImports = await getLocalProjectDeps();
                for await (let depPrj of localProjectImports) {
                    await mls.stor.server.loadProjectInfoIfNeeded(depPrj);
                }
            }
            initCompileMonaco(this.actualProject);
        }
        catch (e) {
            console.info('[loadLastProject] Error:' + e.message || 'Invalid project');
        }
    }
    async setLastOpenedFiles() {
        if (!this.actualProject)
            return;
        try {
            const lib = await import('/_102027_/l2/libCommom.js');
            if (!lib || !lib.getLastOpenedFiles)
                return;
            const lastFiles = lib.getLastOpenedFiles(this.actualProject);
            Object.entries(lastFiles).forEach(([levelStr, value]) => {
                const level = +levelStr;
                const actual = mls.actual[level];
                if (!actual)
                    return;
                if (typeof value === 'string') {
                    actual.setFullName(value);
                    return;
                }
                if (level === 2 && typeof value === 'object' && value !== null) {
                    this.restoreSideFile(value.left, level, 'left', actual);
                    this.restoreSideFile(value.right, level, 'right', actual);
                }
            });
        }
        catch (err) {
            console.error(err.message);
        }
    }
    async setDefaultFiles() {
        if (!this.actualProject)
            return;
        try {
            const lib = await import('/_102027_/l2/libCommom.js');
            if (!lib || !lib.findStorFileInProjectsOrDeps)
                return;
            const defaultL6 = lib.findStorFileInProjectsOrDeps(this.actualProject, 2, this.FILEL6, '', '.ts');
            const defaultL5 = lib.findStorFileInProjectsOrDeps(this.actualProject, 2, this.FILEL5, '', '.ts');
            if (defaultL6)
                mls.actual[6].setFullName(`_${defaultL6.project}_${defaultL6.shortName}`);
            if (defaultL5)
                mls.actual[5].setFullName(`_${defaultL5.project}_${defaultL5.shortName}`);
        }
        catch (err) {
            console.error(err.message);
        }
    }
    restoreSideFile(filename, level, side, actual) {
        if (!filename)
            return;
        const path = this.getPath(filename);
        if (!path)
            throw new Error('[restoreSideFile] Not found path:' + filename);
        const key = mls.stor.getKeyToFiles(path.project, level, path.shortName, path.folder, '.ts');
        const file = mls.stor.files[key];
        if (!file)
            return;
        actual[side] = file;
    }
    getPath(fileName) {
        return mls.actual[0].setFullName(fileName).getStorFileBase();
    }
    async setLastModule() {
        if (!this.actualProject)
            return;
        try {
            const lib = await import('/_102027_/l2/libCommom.js');
            if (!lib || !lib.getLastModule)
                return;
            const modules = lib.getLastModule();
            if (!modules || !modules[+this.actualProject])
                return;
            mls.setActualModule(modules[+this.actualProject]);
        }
        catch (err) {
            console.error(err.message);
        }
    }
    /**
     * Checks for the presence of a `<collab-sticky-notification>` element on the page.
     * If found, it invokes the `show()` method on the element to display notifications.
     */
    showMessagesIfNeeded() {
        const collabMessages = document.querySelector('collab-sticky-notification');
        if (collabMessages)
            collabMessages.show();
    }
    /**
     * Retrieves a list of services for the current project, either for anonymous users or regular users.
     * If the user is anonymous, it returns the `anonymousServices`. Otherwise, it loads project-specific
     * services by fetching and sorting the available menu actions for different levels and positions (Left/Right).
     *
     * @returns A promise that resolves to an object containing an array of services, sorted by priority.
     * The services are categorized by levels and positions (Left/Right) and are returned as a semicolon-separated
     * string for each level.
     */
    async getServices() {
        if (window.traceLifeCycle)
            console.info(`init getServices`);
        if (this.isAnonymous) {
            if (window.traceLifeCycle)
                console.info(`getServices: Anonymous`);
            return this.anonymousServices;
        }
        // Build project list in priority order (highest priority first)
        const projectList = [];
        const isLocalProject = this.actualProject === mls.stor.LOCALPROJECTNUMBER;
        // 1. Actual project (highest priority) — the local project has no services of its own
        if (this.actualProject && !isLocalProject) {
            projectList.push(this.actualProject);
        }
        // 2. Actual project dependencies
        if (this.actualProject) {
            const dependencies = isLocalProject
                ? await getLocalProjectDeps()
                : mls.l5.getProjectDependencies(this.actualProject, false);
            if (dependencies && dependencies.length > 0) {
                for (const dep of dependencies) {
                    if (!projectList.includes(dep)) {
                        projectList.push(dep);
                    }
                }
            }
        }
        // 3. Base project (lowest priority)
        if (this.baseProject && !projectList.includes(this.baseProject)) {
            projectList.push(this.baseProject);
        }
        if (window.traceLifeCycle)
            console.info(`getServices using index project: ${this.actualProject}, priority order: ${projectList.join(' > ')}`);
        for (const prj of projectList) {
            await mls.plugin.loadAll(prj, false);
        }
        const levels = [0, 1, 2, 3, 4, 5, 6, 7];
        const rc = {
            0: { Left: [], Right: [] },
            1: { Left: [], Right: [] },
            2: { Left: [], Right: [] },
            3: { Left: [], Right: [] },
            4: { Left: [], Right: [] },
            5: { Left: [], Right: [] },
            6: { Left: [], Right: [] },
            7: { Left: [], Right: [] },
        };
        const positions = ['Left', 'Right'];
        levels.forEach((level) => {
            positions.forEach((position) => {
                // Services override by SHORTNAME (not full path): a higher-priority project
                // service replaces the base/Studio one with the same shortName, regardless of
                // folder (e.g. _102020_aura/services/servicePreview overrides _100554_servicePreview).
                // Consequence (by design): two different services sharing a shortName collide —
                // the shortName is the service identity.
                const addedShortNames = new Set();
                // Iterate in priority order: actualProject > dependencies > baseProject
                for (const prjNumber of projectList) {
                    const scope = `l${level}Services${position}`;
                    const services = mls.plugin.getAllMenuActions(prjNumber, { scope });
                    const sorted = services.sort((a, b) => (a.priority || 1) - (b.priority || 1));
                    for (const service of sorted) {
                        if (service && service.widget) {
                            const info = mls.actual[0].setFullName(service.widget);
                            const path = info.path;
                            if (!path)
                                continue;
                            const shortName = info.getStorFileBase()?.shortName || path.split('/').pop() || path;
                            // Only add if no widget with the same shortName was already added by a higher priority project
                            if (!addedShortNames.has(shortName)) {
                                addedShortNames.add(shortName);
                                rc[level][position].push(service.widget);
                            }
                            else {
                                if (window.traceLifeCycle) {
                                    console.info(`getServices: skipping ${service.widget} (project ${prjNumber}), '${shortName}' already provided by higher priority project`);
                                }
                            }
                        }
                    }
                }
            });
        });
        const rc2 = ['', '', '', '', '', '', '', ''];
        Object.entries(rc).forEach((entry) => {
            const [level, value] = entry;
            const left = value.Left.join(',');
            const right = value.Right.join(',');
            rc2[+level] = left + ';' + right;
        });
        return {
            services: rc2,
        };
    }
};
CollabInit = __decorate([
    customElement('collab-init-100554')
], CollabInit);
export { CollabInit };
