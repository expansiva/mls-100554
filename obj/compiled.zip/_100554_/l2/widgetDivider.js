/// <mls fileReference="_100554_/l2/widgetDivider.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
let WcDivider100554 = class WcDivider100554 extends StateLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`widget-divider-100554 {
  display: block;
}
widget-divider-100554 hr {
  display: block;
  border: 0;
  text-align: center;
  overflow: visible;
  margin-top: 20px;
  margin-bottom: 20px;
  height: auto;
}
widget-divider-100554 hr:before {
  font-family: var(--font-family-primary);
  font-weight: 400;
  font-style: italic;
  font-size: var(--font-size-40);
  letter-spacing: 0.6em;
  content: attr(data-text);
  display: inline-block;
  margin-left: 0.6em;
  color: var(--text-primary-color);
  position: relative;
  top: -10px;
}
`);
    }
    createRenderRoot() {
        return this;
    }
    render() {
        return html `<hr data-text=${this.text || '...'}></hr>`;
    }
};
__decorate([
    property()
], WcDivider100554.prototype, "text", void 0);
WcDivider100554 = __decorate([
    customElement('widget-divider-100554')
], WcDivider100554);
export { WcDivider100554 };
