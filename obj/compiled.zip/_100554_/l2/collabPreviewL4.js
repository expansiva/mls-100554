/// <mls fileReference="_100554_/l2/collabPreviewL4.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
import { convertTagToFileName } from '/_102027_/l2/utils';
import '/_100554_/l2/collabL3EditText.js';
let CollabPreviewL4 = class CollabPreviewL4 extends CollabLitElement {
    constructor() {
        super();
        this.observer = new ResizeObserver(() => {
            if (!this.elOverlaySelected)
                return;
            this.caculetePosSelected(this.elOverlaySelected.el);
        });
        this.init();
    }
    //-----COMPONENT----------
    disconnectedCallback() {
        if (this.observer)
            this.observer.disconnect();
        super.disconnectedCallback();
    }
    render() {
        return html ``;
    }
    //-------PUBLIC-----------
    setHover(elId, active) {
        this._setHover(elId, active);
    }
    selectElement(elId) {
        this._selectElement(elId);
    }
    //------FUNCTIONS---------
    init() {
        this.createOverlay();
        this.createOverlaySelected();
        this.setEventsMouse();
        this.observer.observe(document.body);
    }
    setEventsMouse() {
        const allItens = Array.from(this.querySelectorAll('*[mls_origin]')).filter((el) => el.tagName.toLocaleLowerCase().indexOf('organism-') >= 0);
        this.onmouseleave = () => { if (this.elOverlayHover)
            this.elOverlayHover.style.display = 'none'; };
        allItens.forEach((el) => {
            if (!el)
                return;
            el.onmouseover = () => this._setHover(el.id, true);
        });
    }
    createOverlay() {
        if (this.elOverlayHover && this.elOverlayHover.isConnected)
            return;
        const div = document.createElement("collab-aux-overlay");
        div.style.outlineOffset = '-2px';
        div.style.zIndex = '99999';
        div.style.display = 'block';
        this.appendChild(div);
        this.elOverlayHover = div;
    }
    createOverlaySelected() {
        if (this.elOverlaySelected && this.elOverlaySelected.isConnected)
            return;
        const div = document.createElement("collab-selected-overlay");
        div.style.outlineOffset = '-2px';
        div.style.display = 'block';
        div.onmouseover = () => {
            if (this.elOverlayHover)
                this.elOverlayHover.style.display = 'none';
        };
        const menu = document.createElement("div");
        menu.id = 'menu';
        menu.className = 'overlay-menu';
        menu.style.display = 'none';
        menu.onmouseover = () => {
            if (this.elOverlayHover)
                this.elOverlayHover.style.display = 'none';
        };
        const edit = document.createElement("button");
        edit.title = 'Edit';
        edit.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free v6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M362.7 19.3L314.3 67.7 444.3 197.7l48.4-48.4c25-25 25-65.5 0-90.5L453.3 19.3c-25-25-65.5-25-90.5 0zm-71 71L58.6 323.5c-10.4 10.4-18 23.3-22.2 37.4L1 481.2C-1.5 489.7 .8 498.8 7 505s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L421.7 220.3 291.7 90.3z"/></svg>`;
        edit.onclick = (e) => this.editEl(e);
        menu.appendChild(edit);
        this.appendChild(div);
        this.appendChild(menu);
        this.elOverlaySelected = div;
        this.elMenuOverlay = menu;
    }
    _setElement(el) {
        const els = this.querySelectorAll('*[clb_mode="edit"]');
        els.forEach((e) => e.removeAttribute('clb_mode'));
        if (this.elOverlayHover)
            this.elOverlayHover.style.display = 'none';
        if (!this.elOverlaySelected)
            this.createOverlaySelected();
        if (!this.elOverlaySelected)
            return;
        this.caculetePosSelected(el);
        el.setAttribute('clb_mode', 'edit');
        const param = {
            'position': 'right',
            'action': 'select',
            'id': el.id
        };
        mls.events.fire(4, 'L4EditEvents', JSON.stringify(param));
    }
    _setHover(elId, active) {
        if (!elId)
            return;
        if (!this.elOverlayHover)
            this.createOverlay();
        if (!this.elOverlayHover)
            return;
        const el = this.querySelector('#' + elId);
        this.elOverlayHover.style.display = 'none';
        if (!el) {
            if (!active) {
                this.elOverlayHover.style.display = 'none';
            }
            return;
        }
        if (el.hasAttribute('clb_mode')) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        if (!active) {
            this.elOverlayHover.style.display = 'none';
            return;
        }
        const rect = el.getBoundingClientRect();
        this.elOverlayHover.style.display = 'block';
        this.elOverlayHover.style.top = `${rect.top + window.document.body.scrollTop}px`;
        this.elOverlayHover.style.left = `${rect.left + window.document.body.scrollLeft}px`;
        this.elOverlayHover.style.width = `${rect.width}px`;
        this.elOverlayHover.style.height = `${rect.height}px`;
        this.elOverlayHover.onclick = (e) => {
            e.stopPropagation();
            if (this.elOverlayHover)
                this.elOverlayHover.style.display = 'none';
            this._setElement(el);
        };
    }
    caculetePosSelected(el) {
        if (!this.elOverlaySelected || !el)
            return;
        const rect = el.getBoundingClientRect();
        this.elOverlaySelected.style.display = 'block';
        this.elOverlaySelected.style.top = `${rect.top + window.document.body.scrollTop}px`;
        this.elOverlaySelected.style.left = `${rect.left + window.document.body.scrollLeft}px`;
        this.elOverlaySelected.style.width = `${rect.width}px`;
        this.elOverlaySelected.style.height = `${rect.height}px`;
        this.elOverlaySelected.style.setProperty("--id-name", `'${el.tagName.toLocaleLowerCase()}'`);
        this.elOverlaySelected.el = el;
        if (this.elMenuOverlay) {
            const menuHeight = 31;
            this.elMenuOverlay.style.display = "flex";
            this.elMenuOverlay.style.top = (rect.top + window.document.body.scrollTop - 1) + "px";
            this.elMenuOverlay.style.left = (rect.left + +window.document.body.scrollLeft + 4) + "px";
            if (rect.top < menuHeight) {
                this.elMenuOverlay.style.top = (rect.bottom + window.document.body.scrollTop + menuHeight + 12) + "px";
            }
        }
    }
    _selectElement(elId) {
        const els = this.querySelectorAll('*[clb_mode="edit"]');
        els.forEach((e) => e.removeAttribute('clb_mode'));
        if (!this.elOverlaySelected)
            this.createOverlaySelected();
        if (!this.elOverlaySelected)
            return;
        const el = this.querySelector('#' + elId);
        if (!el)
            return;
        this._setElement(el);
    }
    editEl(e) {
        if (!this.elOverlaySelected || !this.elOverlaySelected.el)
            return;
        const fileInfo = convertTagToFileName(this.elOverlaySelected.el.tagName.toLowerCase());
        if (!fileInfo)
            return;
        const { folder, project, shortName } = fileInfo;
        const param = {
            'position': 'right',
            'action': 'openL3',
            folder,
            project,
            shortName
        };
        mls.events.fire(4, 'L4EditEvents', JSON.stringify(param));
        /*mls.actual[3].setFullName(folder ? `_${project}_${folder}/${shortName}` : `_${project}_${shortName}`);
        selectLevel(3);
        setTimeout(() => {
            console.info('time')
            openService('_100554_serviceOrganism', 'left', 3, { "tab": "navigation" });
        }, 100)*/
    }
};
CollabPreviewL4 = __decorate([
    customElement('collab-preview-l4-100554')
], CollabPreviewL4);
export { CollabPreviewL4 };
