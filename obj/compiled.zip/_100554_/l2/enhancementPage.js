// project/_100554_/l2/enhancementPage.ts
var description = "Use this enhancement for pages";
var example = ``;
var requires = [];
var getExample = (project, shortname) => {
  let newExample = example;
  return newExample;
};
var getDesignDetails = (modelTS) => {
  return new Promise((resolve, reject) => {
    try {
      const ret = {};
      ret.defaultHtmlExamplePreview = "<h1>Simple page</h1>";
      ret.properties = [];
      ret.webComponentDependencies = [];
      ret["servicePreviewDefault"] = "_100554_servicePreview";
      resolve(ret);
    } catch (e) {
      reject(e);
    }
  });
};
var prepareAdd = (prompt) => {
  const aiHeader = ``;
  const aiBody = prompt;
  const aiDelimiter = ":::";
  const sourceTS = "";
  const ret = { sourceTS, aiHeader, aiBody, aiDelimiter };
  return ret;
};
var onAfterChange = async (modelTS) => {
  try {
    return;
  } catch (e) {
    return e.message || e;
  }
};
var getPromptDefault = () => {
  return ``;
};
var onAfterCompile = async (modelTS) => {
  return;
};
export {
  description,
  example,
  getDesignDetails,
  getExample,
  getPromptDefault,
  onAfterChange,
  onAfterCompile,
  prepareAdd,
  requires
};
