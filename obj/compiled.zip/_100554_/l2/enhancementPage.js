/// <mls fileReference="_100554_/l2/enhancementPage.ts" enhancement="_blank" />
export const description = "Use this enhancement for pages";
export const example = ``;
export const requires = [];
export const getExample = (project, shortname) => {
    let newExample = example;
    return newExample;
};
export const getDesignDetails = (modelTS) => {
    return new Promise((resolve, reject) => {
        try {
            const ret = {};
            ret.defaultHtmlExamplePreview = '<h1>Simple page</h1>';
            ret.properties = [];
            ret.webComponentDependencies = [];
            ret['servicePreviewDefault'] = '_100554_servicePreview';
            resolve(ret);
        }
        catch (e) {
            reject(e);
        }
    });
};
export const prepareAdd = (prompt) => {
    const aiHeader = ``;
    const aiBody = prompt;
    const aiDelimiter = ':::';
    const sourceTS = '';
    const ret = { sourceTS, aiHeader, aiBody, aiDelimiter };
    return ret;
};
export const onAfterChange = async (modelTS) => {
    try {
        return;
    }
    catch (e) {
        return e.message || e;
    }
};
export const getPromptDefault = () => {
    return ``;
};
export const onAfterCompile = async (modelTS) => {
    return;
};
