/// <mls fileReference="_100554_/l2/servicePreviewL1ListServer.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state, query } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { getPath } from '/_102027_/l2/utils.js';
import "/_100554_/l2/collabConsoleL1.js";
let ServicePreviewL1ListServer = class ServicePreviewL1ListServer extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`service-preview-l1-list-server-100554 {
  position: relative;
  display: block;
  margin: 0;
  background: linear-gradient(180deg, #071022 0%, #081726 100%);
  color: #e6eef6;
  width: 100%;
  height: 100%;
  font-family: Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;
}
service-preview-l1-list-server-100554 .wrap {
  max-width: 980px;
  padding: 24px;
}
service-preview-l1-list-server-100554 header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 18px;
}
service-preview-l1-list-server-100554 h1 {
  font-size: 20px;
  margin: 0;
  letter-spacing: 0.2px;
}
service-preview-l1-list-server-100554 p.lead {
  margin: 0;
  color: #9aa6b2;
  font-size: 13px;
}
service-preview-l1-list-server-100554 .list {
  display: grid;
  gap: 12px;
}
service-preview-l1-list-server-100554 .server {
  display: flex;
  align-items: center;
  gap: 18px;
  padding: 14px;
  border-radius: 10px;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0.02), rgba(255, 255, 255, 0.01));
  box-shadow: 0 6px 18px rgba(2, 6, 23, 0.6);
  border: 1px solid rgba(255, 255, 255, 0.03);
}
service-preview-l1-list-server-100554 .server-main {
  display: flex;
  align-items: center;
  gap: 14px;
  flex: 1;
  min-width: 0;
}
service-preview-l1-list-server-100554 .thumb {
  width: 56px;
  height: 56px;
  border-radius: 8px;
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.02), rgba(0, 0, 0, 0.12));
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 600;
  color: #9aa6b2;
  font-size: 14px;
  border: 1px solid rgba(255, 255, 255, 0.03);
}
service-preview-l1-list-server-100554 .thumb svg {
  width: 30px !important;
  height: 30px !important;
  fill: white;
}
service-preview-l1-list-server-100554 .meta {
  min-width: 0;
}
service-preview-l1-list-server-100554 .meta .name {
  font-weight: 600;
  font-size: 15px;
  margin-bottom: 4px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
service-preview-l1-list-server-100554 .meta .desc {
  font-size: 13px;
  color: #9aa6b2;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
service-preview-l1-list-server-100554 .status {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 220px;
  justify-content: flex-end;
}
service-preview-l1-list-server-100554 .badge {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 600;
  color: #062024;
}
service-preview-l1-list-server-100554 .badge--on {
  background: linear-gradient(90deg, rgba(22, 163, 74, 0.15), rgba(22, 163, 74, 0.06));
  color: #16a34a;
  border: 1px solid rgba(22, 163, 74, 0.18);
}
service-preview-l1-list-server-100554 .badge--restart {
  background: linear-gradient(90deg, rgba(144, 163, 22, 0.15), rgba(158, 163, 22, 0.06));
  color: #16a34a;
  border: 1px solid rgba(156, 163, 22, 0.18);
}
service-preview-l1-list-server-100554 .badge--off {
  background: linear-gradient(90deg, rgba(239, 68, 68, 0.06), rgba(239, 68, 68, 0.02));
  color: #ef4444;
  border: 1px solid rgba(239, 68, 68, 0.12);
}
service-preview-l1-list-server-100554 .controls {
  display: flex;
  gap: 8px;
  margin-left: 12px;
}
service-preview-l1-list-server-100554 button.btn {
  appearance: none;
  border: 0;
  padding: 8px 10px;
  border-radius: 8px;
  font-size: 13px;
  cursor: pointer;
  font-weight: 600;
  background: rgba(255, 255, 255, 0.03);
  color: #9aa6b2;
  transition: transform 0.12s ease, box-shadow 0.12s ease, background 0.12s ease;
  display: inline-flex;
  gap: 8px;
  align-items: center;
}
service-preview-l1-list-server-100554 button.btn:active {
  transform: translateY(1px) scale(0.998);
}
service-preview-l1-list-server-100554 button.btn:focus {
  outline: 2px solid rgba(6, 182, 212, 0.14);
  box-shadow: 0 4px 18px rgba(6, 182, 212, 0.06);
}
service-preview-l1-list-server-100554 button.btn--primary {
  background: linear-gradient(90deg, rgba(6, 182, 212, 0.12), rgba(6, 182, 212, 0.06));
  color: #06b6d4;
  border: 1px solid rgba(6, 182, 212, 0.08);
}
service-preview-l1-list-server-100554 button.btn--danger {
  background: linear-gradient(90deg, rgba(239, 68, 68, 0.06), rgba(239, 68, 68, 0.02));
  color: #ef4444;
  border: 1px solid rgba(239, 68, 68, 0.06);
}
service-preview-l1-list-server-100554 .icon {
  width: 14px;
  height: 14px;
  display: inline-block;
  vertical-align: middle;
  opacity: 0.95;
}
@media (max-width: 700px) {
  service-preview-l1-list-server-100554 .server {
    flex-direction: column;
    align-items: stretch;
  }
  service-preview-l1-list-server-100554 .status {
    justify-content: space-between;
    min-width: 0;
    margin-top: 10px;
  }
  service-preview-l1-list-server-100554 .controls {
    margin-left: 0;
    justify-content: flex-end;
  }
}
service-preview-l1-list-server-100554 .spinner {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.08);
  border-top-color: rgba(255, 255, 255, 0.28);
  animation: spin 0.9s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
service-preview-l1-list-server-100554 .modal-backdrop {
  position: absolute;
  inset: 0;
  display: none;
  align-items: center;
  justify-content: center;
  background: rgba(2, 6, 23, 0.6);
  z-index: 40;
}
service-preview-l1-list-server-100554 .modal-backdrop.show {
  display: flex;
}
service-preview-l1-list-server-100554 .modal {
  width: min(720px, 92%);
  background: linear-gradient(180deg, #071226, #061424);
  border-radius: 12px;
  padding: 18px;
  border: 1px solid rgba(255, 255, 255, 0.03);
  box-shadow: 0 12px 40px rgba(2, 6, 23, 0.7);
}
service-preview-l1-list-server-100554 .modal iframe {
  width: 100%;
  height: 500px;
}
service-preview-l1-list-server-100554 .modal h3 {
  margin: 0 0 8px 0;
  font-size: 18px;
}
service-preview-l1-list-server-100554 .modal p {
  margin: 0 0 12px 0;
  color: #9aa6b2;
  font-size: 13px;
}
service-preview-l1-list-server-100554 .modal .close {
  float: right;
}
`);
        this.cacheBuild = {};
        this.iframes = {};
        this.servers = {};
        this.listItens = [];
        this.init();
    }
    //--------COMPONENT----------
    render() {
        return html `
        <div class="wrap">
            ${this.renderHeader()}
            ${this.renderList()}
        </div>
        <div id="modal" class="modal-backdrop" role="dialog" aria-modal="true" aria-hidden="true">
            <div class="modal" role="document">
                <button class="btn close" id="closeModal" aria-label="Fechar" @click=${this.handleCloseView}>Close</button>
                <h3 id="modalTitle">Server Details</h3>
                <p id="modalBody">Server information...</p>
                <div id="viewServer">
                </div>
            </div>
        </div>
        <div id="iframesContent" style="display:none">
        </div>
        `;
    }
    renderHeader() {
        return html `
        <header>
            <div>
                <h1>Servers</h1>
                <p class="lead">List of servers with status and quick actions (Power On/Off, Restart, View)</p>
            </div>
        </header>
        `;
    }
    renderList() {
        return html `
        <main>
            <div class="list" id="serverList" aria-live="polite">
                ${repeat(this.listItens, ((key) => key.server), ((k, index) => { return this.renderItem(k, index); }))}
            </div>
        </main>
        `;
    }
    renderItem(item, idx) {
        const n = item.icon ? unsafeHTML(item.icon) : `SV${idx + 1}`;
        return html `
        <div class="server" data-status="off" data-path="${item.server}">
            <div class="server-main">
                <div class="thumb">${n}</div>
                <div class="meta">
                    <div class="name">${item.name}</div>
                    <div class="desc">File: ${item.server}</div>
                </div>
            </div>

            <div class="status">
                <div class="badge badge--off">
                    <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.6"/></svg>
                    Off
                </div>

                <div class="controls">
                    <button class="btn btn--primary btn-power" title="Desligar/ligar" @click=${this.handleClickPower}>
                        <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 2v6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M5.5 8.5a7 7 0 1013 0" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
                        Power
                    </button>

                    <button class="btn btn--danger btn-restart" title="Restart"  @click=${this.handleClickRestart} >
                        <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M21 12a9 9 0 11-9-9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
                        Restart
                    </button>

                    <button class="btn btn--primary btn-view" title="Visualizar" @click=${this.handleClickView} >
                        <svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>
                        View
                    </button>
                </div>
            </div>
        </div>
        `;
    }
    //---------IMPLEMENTS-------------
    async init() {
        const url = `/_${mls.actualProject}_/l2/project`;
        const m = await import(url);
        const array = [];
        if (m.modules) {
            m.modules.forEach((s, index) => {
                if (!s.pathServer)
                    return;
                array.push({
                    name: s.name || 'S' + (index + 1),
                    server: s.pathServer || 'null',
                    icon: s.icon
                });
            });
        }
        this.listItens = array;
        await this.loadEsbuild();
    }
    async loadEsbuild() {
        if (mls.esbuild) {
            this.esbuild = mls.esbuild;
        }
        else if (!mls.esbuildInLoad)
            await this.initializeEsBuild();
    }
    async initializeEsBuild() {
        mls.esbuildInLoad = true;
        const url = 'https://unpkg.com/esbuild-wasm@0.14.54/esm/browser.min.js';
        if (!this.esbuild) {
            this.esbuild = await import(url);
            await this.esbuild.initialize({
                wasmURL: "https://unpkg.com/esbuild-wasm@0.14.54/esbuild.wasm"
            });
            mls.esbuild = this.esbuild;
            mls.esbuildInLoad = false;
        }
    }
    handleClickPower(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const server = btn.closest('.server');
        if (!server)
            return;
        const path = server.getAttribute('data-path');
        if (!path)
            return;
        const current = server.getAttribute('data-status');
        if (current === 'on') {
            server.setAttribute('data-status', 'off');
        }
        else {
            server.setAttribute('data-status', 'on');
        }
        this.refreshRow(path, server);
    }
    handleClickRestart(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const server = btn.closest('.server');
        if (!server)
            return;
        const path = server.getAttribute('data-path');
        if (!path)
            return;
        if (server.getAttribute('data-status') !== 'on')
            return;
        server.setAttribute('data-status', 'restarting');
        this.refreshRow(path, server);
    }
    handleClickView(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const server = btn.closest('.server');
        if (!server)
            return;
        const path = server.getAttribute('data-path');
        if (!path)
            return;
        const modal = this.querySelector('#modal');
        if (!modal)
            return;
        if (!this.viewServer)
            return;
        this.viewServer.innerHTML = '';
        this.viewServer.appendChild(this.iframes[path]);
        modal.classList.add('show');
        modal.setAttribute('aria-hidden', 'false');
    }
    handleCloseView(ev) {
        const btn = ev.target.closest('button');
        if (!btn)
            return;
        const modal = btn.closest('#modal');
        if (!modal)
            return;
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
    }
    refreshRow(path, row) {
        const status = row.getAttribute('data-status');
        const badge = row.querySelector('.badge');
        const restartBtn = row.querySelector('.btn-restart');
        badge.innerHTML = `<svg class="icon" viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.6"/></svg>`;
        if (status === 'on') {
            badge.classList.remove('badge--off', 'badge--restart');
            badge.classList.add('badge--on');
            badge.innerHTML += ' On';
            restartBtn.disabled = false;
            restartBtn.removeAttribute('aria-disabled');
            this.onServer(path, row);
        }
        else if (status === 'off') {
            badge.classList.remove('badge--on', 'badge--restart');
            badge.classList.add('badge--off');
            badge.innerHTML += ' Off';
            restartBtn.disabled = true;
            restartBtn.setAttribute('aria-disabled', 'true');
            this.offServer(path);
        }
        else if (status === 'restarting') {
            badge.classList.remove('badge--on', 'badge--off');
            badge.classList.add('badge--restart');
            badge.innerHTML = '<span class="spinner" aria-hidden="true"></span> Restarting';
            restartBtn.disabled = true;
            restartBtn.setAttribute('aria-disabled', 'true');
            this.restartServer(path, row);
        }
    }
    onServer(path, server) {
        if (!this.iframes[path]) {
            this.createServer(path, server);
            return;
        }
        const i = this.iframes[path];
        if (!i.contentWindow)
            return;
        i.contentWindow.onmessage = async (e) => {
            const data = e.data;
            console.info('message', data);
            const res = {
                type: "fetch-response",
                id: data.id,
                body: '',
                status: 200,
                headers: { "Content-Type": "application/json" }
            };
            if (data.type === "fetch-request") {
                const method = 'exec'; // data.url.split('/').filter(Boolean).join('_');
                if (i && i.contentWindow[method]) {
                    const exec = i.contentWindow[method];
                    const strJson = data.options && data.options.body ? data.options.body : '{}';
                    const resposta = await exec(JSON.parse(strJson));
                    res.body = JSON.stringify(resposta);
                    if (window.preview.iframe && window.preview.iframe.contentWindow)
                        window.preview.iframe.contentWindow.postMessage(res, "*");
                }
            }
        };
    }
    offServer(path) {
        if (!this.iframes[path])
            return;
        const i = this.iframes[path];
        if (!i.contentWindow)
            return;
        i.contentWindow.onmessage = () => undefined;
    }
    restartServer(path, server) {
        if (this.iframes[path]) {
            this.iframes[path].remove();
            delete this.iframes[path];
        }
        this.createServer(path, server);
    }
    createServer(path, server) {
        if (this.iframes[path])
            return;
        this.iframes[path] = document.createElement('iframe');
        this.iframes[path].src = '/_100554_servicePreviewL1';
        this.iframes[path].onload = () => {
            try {
                this.setHTml(path, this.iframes[path]);
                this.onServer(path, server);
                server.setAttribute('data-status', 'on');
                this.refreshRow(path, server);
            }
            catch (e) {
                server.setAttribute('data-status', 'off');
                this.refreshRow(path, server);
            }
        };
        this.iframes[path].setAttribute('sandbox', 'allow-scripts allow-same-origin');
        this.servers = {};
        Object.keys(this.iframes).forEach((key) => {
            const f = this.listItens.find((i) => i.server === key);
            if (f)
                this.servers[f.name] = this.iframes[key];
        });
        top.previewL1 = this.servers;
        if (this.iframesContent)
            this.iframesContent.appendChild(this.iframes[path]);
    }
    async setHTml(path, iframe) {
        if (!iframe.contentDocument)
            return;
        const info = getPath(path);
        if (!info)
            throw new Error('[setHTml] Not found path:' + path);
        const key = mls.stor.getKeyToFiles(info.project, 1, info.shortName, info.folder, '.ts');
        if (!mls.stor.files[key])
            throw new Error('[setHTml]: Not found stor');
        const actualFile = mls.stor.files[key];
        let txt = `<collab-console-l1-100554 file="${path}"></collab-console-l1-100554>
        <style>
            html{
                height:100%;
            }
            body{
                height: calc(100% - 34px);
            }
        </style>`;
        iframe.contentDocument.body.innerHTML = txt;
        let name = `/_${actualFile.project}_${actualFile.shortName}`;
        if (actualFile.folder)
            name = `/_${actualFile.project}_${actualFile.folder}/${actualFile.shortName}`;
        const ret = {
            errors: [],
            importsJs: ["/_100554_collabConsoleL1", name],
            importsMap: ['"lit": "https://cdn.jsdelivr.net/gh/lit/dist@3/all/lit-all.min.js"', '"lit/decorators.js": "https://cdn.jsdelivr.net/npm/lit@3.0.0/decorators/+esm"']
        };
        if (ret.errors.length > 0)
            throw new Error(`[setHTml]: Error(${ret.errors.length}) when compiling:${ret.errors[0].error}`);
        const bundle = this.cacheBuild[path] ? this.cacheBuild[path] : await this.compileWithEsbuild(ret, actualFile);
        if (!bundle)
            throw new Error(`[setHTml]: Build returned empty result`);
        if (!this.cacheBuild[path])
            this.cacheBuild[path] = bundle;
        this.mountJSImporMap(ret, iframe);
        this.mountJSBundle(bundle, iframe);
    }
    async compileWithEsbuild(info, storFile) {
        try {
            if (!this.esbuild) {
                console.warn("esbuild not loaded");
                return null;
            }
            const virtualFiles = await this.getVirtualFiles(storFile);
            let entryCode = Object.keys(mls.stor.files).map((p, i) => {
                const sf = mls.stor.files[p];
                if (!sf || sf.level !== 1 || sf.extension != '.ts' || sf.project !== storFile.project)
                    return '';
                const verify = `/_${sf.project}_${sf.folder ? sf.folder + '/' : ''}${sf.shortName}`;
                const name = './' + (sf.folder ? sf.folder + '/' : '') + sf.shortName + '.js';
                const aux = info.importsJs.includes(verify) ? `Object.assign(window, m${i});` : '';
                return `import * as m${i} from "${name}";
                ${aux} 
                `;
            }).join("\n").trim();
            const result = await this.esbuild.build({
                stdin: {
                    contents: entryCode,
                    sourcefile: "virtual-entry.ts",
                    resolveDir: "/",
                },
                bundle: true,
                write: false,
                format: "esm",
                loader: { ".ts": "ts" },
                plugins: [this.getVirtualFilesPlugin(virtualFiles)]
            });
            if (!result.outputFiles || !result.outputFiles[0])
                return null;
            return result.outputFiles[0].text;
        }
        catch (err) {
            console.error("esbuild error:", err);
            return null;
        }
    }
    async getVirtualFiles(storFile) {
        let files = {};
        for (const [name, f] of Object.entries(mls.stor.files)) {
            if (!f || f.project !== storFile.project || f.level !== 1 || f.extension !== '.ts')
                continue;
            const name = ((f.folder ? f.folder + '/' + f.shortName : f.shortName) + '.js').toLocaleLowerCase();
            if (files[name])
                continue;
            files[name] = await f.getContent();
        }
        return files;
    }
    getVirtualFilesPlugin(files) {
        return {
            name: "virtual-files",
            setup(build) {
                // Resolver imports relativos
                build.onResolve({ filter: /^(\.|\/)/ }, (args) => {
                    if (args.importer.split('/').length >= 3) {
                        const importer = args.importer;
                        const base = "file://" + importer;
                        const resolvedURL = new URL(args.path, base);
                        let resolved = resolvedURL.pathname;
                        // adiciona extensão se faltar
                        if (!resolved.endsWith(".ts") && !resolved.endsWith(".js")) {
                            resolved += ".js";
                        }
                        return {
                            path: resolved,
                            namespace: "vfs",
                        };
                    }
                    else {
                        const resolved = new URL(args.path, "file://" + args.resolveDir + "/").pathname;
                        return { path: resolved.endsWith(".ts") || resolved.endsWith(".js") ? resolved : resolved + ".js", namespace: "vfs" };
                    }
                });
                // Retornar conteúdo dos arquivos da memória
                build.onLoad({ filter: /\.(ts|js)$/, namespace: "vfs" }, (args) => {
                    const path = (args.path.replace(/^\/+/, "").trim()).toLocaleLowerCase(); // remove /
                    const content = files[path];
                    if (!content) {
                        console.warn("Arquivo não encontrado no virtual FS:", path);
                        return { contents: "", loader: "ts" };
                    }
                    return { contents: content, loader: "ts" };
                });
            }
        };
    }
    mountJSImporMap(info, ifr) {
        try {
            if (info.importsMap.length <= 0 || !ifr.contentDocument)
                return;
            const js = '{"imports": { ' + info.importsMap.join(',\n') + '} }';
            const script = document.createElement('script');
            script.type = 'importmap';
            script.textContent = js;
            ifr.contentDocument.head.appendChild(script);
        }
        catch (e) {
            console.info('Error mountJSImporMap: ' + e.message);
            return;
        }
    }
    mountJSBundle(jsCode, ifr) {
        try {
            if (!ifr.contentDocument)
                return;
            const script = document.createElement('script');
            script.type = "module";
            script.textContent = jsCode;
            ifr.contentDocument.body.appendChild(script);
            const scriptBase = document.createElement('script');
            scriptBase.type = "module";
            scriptBase.src = "/_100554_collabConsoleL1";
            ifr.contentDocument.body.appendChild(scriptBase);
        }
        catch (e) {
            console.info('Error mountJSBundle: ' + e.message);
        }
    }
};
__decorate([
    state()
], ServicePreviewL1ListServer.prototype, "listItens", void 0);
__decorate([
    query("#viewServer")
], ServicePreviewL1ListServer.prototype, "viewServer", void 0);
__decorate([
    query("#iframesContent")
], ServicePreviewL1ListServer.prototype, "iframesContent", void 0);
ServicePreviewL1ListServer = __decorate([
    customElement('service-preview-l1-list-server-100554')
], ServicePreviewL1ListServer);
export { ServicePreviewL1ListServer };
