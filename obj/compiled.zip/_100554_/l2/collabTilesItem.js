/// <mls fileReference="_100554_/l2/collabTilesItem.ts" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { convertFileNameToTag } from '/_102027_/l2/utils';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let CollabTilesItem = class CollabTilesItem extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-tiles-item-100554{position:relative}collab-tiles-item-100554 collabtileitemresize{content:' ';bottom:0px;right:0px;width:10px;height:10px;background:#fff;border-radius:50%;box-shadow:0 0 4px 1px rgba(57,76,96,0.15),0 0 0 1px rgba(43,59,74,0.3);position:absolute;transform:translate(40%, 40%);cursor:se-resize}collab-tiles-item-100554 collabtileenabled{top:0px;left:0px;width:18px;height:18px;background:#fff;border-radius:50%;position:absolute;transform:translate(-40%, -40%);box-shadow:0 0 4px 1px rgba(57,76,96,0.15),0 0 0 1px rgba(43,59,74,0.3);cursor:pointer;display:flex;justify-content:center;align-items:center;color:#000}@-webkit-keyframes enter{0%{opacity:0;top:-10px}5%{opacity:1;top:0px}50.9%{opacity:1;top:0px}55.9%{opacity:0;top:10px}}@keyframes enter{0%{opacity:0;top:-10px}5%{opacity:1;top:0px}50.9%{opacity:1;top:0px}55.9%{opacity:0;top:10px}}@-moz-keyframes enter{0%{opacity:0;top:-10px}5%{opacity:1;top:0px}50.9%{opacity:1;top:0px}55.9%{opacity:0;top:10px}}collab-tiles-item-100554 .loader{position:absolute;left:50%;top:50%;background:#00000029;padding:1rem;border-radius:5px;transform:translate(-50%, -50%)}collab-tiles-item-100554 .square{background:white;width:15px;height:15px;float:left;top:-10px;margin-right:5px;margin-top:5px;position:relative;opacity:0;-webkit-animation:enter 6s infinite;animation:enter 6s infinite}collab-tiles-item-100554 .enter{top:0px;opacity:1}collab-tiles-item-100554 .square:nth-child(1){-webkit-animation-delay:1.8s;-moz-animation-delay:1.8s;animation-delay:1.8s}collab-tiles-item-100554 .square:nth-child(2){-webkit-animation-delay:2.1s;-moz-animation-delay:2.1s;animation-delay:2.1s}collab-tiles-item-100554 .square:nth-child(3){-webkit-animation-delay:2.4s;-moz-animation-delay:2.4s;animation-delay:2.4s;background:#7e70d2}collab-tiles-item-100554 .square:nth-child(4){-webkit-animation-delay:.9s;-moz-animation-delay:.9s;animation-delay:.9s}collab-tiles-item-100554 .square:nth-child(5){-webkit-animation-delay:1.2s;-moz-animation-delay:1.2s;animation-delay:1.2s}collab-tiles-item-100554 .square:nth-child(6){-webkit-animation-delay:1.5s;-moz-animation-delay:1.5s;animation-delay:1.5s}collab-tiles-item-100554 .square:nth-child(8){-webkit-animation-delay:.3s;-moz-animation-delay:.3s;animation-delay:.3s}collab-tiles-item-100554 .square:nth-child(9){-webkit-animation-delay:.6s;-moz-animation-delay:.6s;animation-delay:.6s}collab-tiles-item-100554 .clear{clear:both}collab-tiles-item-100554 .last{margin-right:0}`);
        this.startX = 0;
        this.startY = 0;
        this.startWidth = 0;
        this.startHeight = 0;
        this.position = '';
        this.plugin = '';
        this.index = '';
        this.edit = '';
        this.mode = 'loading';
    }
    //---------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (this.edit === 'true' && this.collabtileitemresize) {
            this.collabtileitemresize.addEventListener('dragstart', this.initDragging.bind(this));
            this.collabtileitemresize.addEventListener('drag', this.doDragging.bind(this));
            this.collabtileitemresize.addEventListener('dragend', this.stopDragging.bind(this));
        }
    }
    render() {
        if (!this.myinfo)
            return;
        this.style.display = '';
        if (this.edit !== 'true' && this.myinfo.enabled === 'false')
            this.style.display = 'none';
        const [r, c] = this.myinfo.position ? this.myinfo.position.split(' ') : ['2', '2'];
        this.style.gridRow = 'span ' + r;
        this.style.gridColumn = 'span ' + c;
        this.onclick = () => this.clickPlugin();
        this.loadingPlugin();
        let aux = '';
        if (this.edit === 'true')
            aux = this.renderResize();
        return html `
            <div style="${this.mode !== 'loading' ? 'display:none;' : 'position:relative; width:100%; height:100%;background: #ececec;'}">
                <div class="loader">
                    <div class="square"></div>
                    <div class="square"></div>
                    <div class="square last"></div>
                    <div class="square clear"></div>
                    <div class="square"></div>
                    <div class="square last"></div>
                    <div class="square clear"></div>
                    <div class="square "></div>
                    <div class="square last"></div>
                </div>
            </div>
            <collabtileitemcontent style="${this.mode !== 'plugin' ? 'display:none;' : 'height:100%; width:100%;overflow:hidden;'}">
            </collabtileitemcontent>
            ${aux}

        `;
    }
    renderResize() {
        let title = 'activate';
        let aux = '+';
        if (this.myinfo && this.myinfo.enabled !== 'false') {
            aux = '-';
            title = 'disable';
        }
        return html `
            <collabtileenabled title="${title}" @click="${this.setEnabled}">${unsafeHTML(aux)}</collabtileenabled>
            <collabtileitemresize draggable="true">
            </collabtileitemresize>
        `;
    }
    //-----------IMPLEMENTS-----------
    setEnabled() {
        if (!this.myinfo)
            return;
        this.myinfo.enabled = this.myinfo.enabled === 'true' ? 'false' : 'true';
        this.requestUpdate();
    }
    async loadingPlugin() {
        const infoPathPlugin = mls.l2.getPath(this.plugin);
        await import('/' + `_${infoPathPlugin.project}_/l2/${infoPathPlugin.shortName}`);
        const tag = convertFileNameToTag(infoPathPlugin);
        this.elPlugin = document.createElement(tag);
        this.elPlugin.setAttribute('dashboardindex', this.index);
        this.setPlugin();
    }
    async setPlugin() {
        const el = this.querySelector('collabtileitemcontent');
        if (!el || !this.elPlugin)
            return;
        el.innerHTML = '';
        el.appendChild(this.elPlugin);
        if (this.elPlugin.prepare)
            await this.elPlugin.prepare();
        this.mode = 'plugin';
    }
    clickPlugin() {
        if (!this.plugin || this.edit === 'true')
            return;
        mls.actual[0].setFullName(this.plugin);
        mls.events.fire(mls.actualLevel, 'PluginDetails', JSON.stringify({
            shortName: mls.actual[0].path,
            project: mls.actual[0].project
        }), 0);
    }
    initDragging(e) {
        if (!this.collabtileitemresize)
            return;
        if (!document.defaultView)
            return;
        this.startX = e.clientX;
        this.startY = e.clientY;
        this.startWidth = parseInt(document.defaultView.getComputedStyle(this).width, 10);
        this.startHeight = parseInt(document.defaultView.getComputedStyle(this).height, 10);
    }
    doDragging(e) {
        if (!this.collabtileitemresize)
            return;
        let col = (this.startWidth + e.clientX - this.startX);
        let row = (this.startHeight + e.clientY - this.startY);
        this.style.width = col + 'px';
        this.style.height = row + 'px';
    }
    stopDragging(e) {
        if (!this.collabtileitemresize)
            return;
        let col = Number.parseInt(this.style.width);
        let row = Number.parseInt(this.style.height);
        if (!col || !row)
            return;
        if (col < 0)
            col = col * -1;
        if (row < 0)
            row = row * -1;
        col = Math.round(col / 100);
        row = Math.round(row / 100);
        this.style.gridArea = '';
        this.style.gridRow = 'span ' + row;
        this.style.gridColumn = 'span ' + col;
        this.style.width = '';
        this.style.height = '';
        if (this.myinfo)
            this.myinfo.position = row + ' ' + col;
    }
};
__decorate([
    property({ type: String, reflect: true })
], CollabTilesItem.prototype, "position", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabTilesItem.prototype, "plugin", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabTilesItem.prototype, "index", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabTilesItem.prototype, "edit", void 0);
__decorate([
    property({ type: String, reflect: true })
], CollabTilesItem.prototype, "mode", void 0);
__decorate([
    query('collabtileitemresize')
], CollabTilesItem.prototype, "collabtileitemresize", void 0);
CollabTilesItem = __decorate([
    customElement('collab-tiles-item-100554')
], CollabTilesItem);
export { CollabTilesItem };
