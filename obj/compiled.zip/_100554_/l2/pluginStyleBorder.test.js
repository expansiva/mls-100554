/// <mls fileReference="_100554_/l2/pluginStyleBorder.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
