/// <mls fileReference="_100554_/l2/pluginCodeInsights.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
