/// <mls fileReference="_100554_/l2/collabOrgProjects.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    activeProjects: 'Projetos Ativos',
    archivedProjects: 'Projetos Arquivados',
    searchPlaceholder: 'Buscar projetos...',
    viewProject: 'Ver projeto',
    noResults: 'Nenhum projeto encontrado.',
    loading: 'Carregando...',
    error: 'Erro ao carregar projetos.',
};
const message_en = {
    activeProjects: 'Active Projects',
    archivedProjects: 'Archived Projects',
    searchPlaceholder: 'Search projects...',
    viewProject: 'View project',
    noResults: 'No projects found.',
    loading: 'Loading...',
    error: 'Failed to load projects.',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
/// **collab_i18n_end**
let CollabOrgProjects = class CollabOrgProjects extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-org-projects-100554 {
  display: block;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
}
collab-org-projects-100554 .container {
  display: flex;
  flex-direction: column;
  gap: 24px;
  max-width: 640px;
  margin: 0 auto;
  padding: 24px 16px;
}
collab-org-projects-100554 .search-input {
  width: 100%;
  padding: 8px 12px;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-16);
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
collab-org-projects-100554 .section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
collab-org-projects-100554 .section-title {
  font-size: var(--font-size-20);
  font-family: var(--font-family-primary);
  margin: 0;
}
collab-org-projects-100554 .project-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 8px;
}
collab-org-projects-100554 .project-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border: 1px solid #e0e0e0;
  border-radius: 4px;
}
collab-org-projects-100554 .project-name {
  font-size: var(--font-size-16);
}
collab-org-projects-100554 .btn-view {
  padding: 6px 14px;
  font-family: var(--font-family-primary);
  font-size: var(--font-size-12);
  background-color: #1976d2;
  color: #fff;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
collab-org-projects-100554 .btn-view:hover {
  background-color: #1565c0;
}
collab-org-projects-100554 .state-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 12px;
  padding: 48px 24px;
  color: var(--text-primary-color-lighter);
  font-size: var(--font-size-16);
}
collab-org-projects-100554 .spinner {
  display: inline-block;
  width: 20px;
  height: 20px;
  border: 3px solid var(--grey-color);
  border-top-color: var(--active-color);
  border-radius: 50%;
  animation: spin 0.7s linear infinite;
}
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
collab-org-projects-100554 .feedback {
  font-size: var(--font-size-16);
  padding: 10px 14px;
  border-radius: 4px;
}
collab-org-projects-100554 .feedback.error {
  color: var(--error-color);
  background-color: var(--grey-color-lighter);
}
collab-org-projects-100554 .no-results {
  font-size: var(--font-size-16);
  color: var(--text-primary-color-lighter);
  margin: 0;
}
`);
        this.project = 0;
        this.msg = messages['en'];
        this.projects = [];
        this.searchQuery = '';
        this._loading = false;
        this._error = '';
    }
    connectedCallback() {
        super.connectedCallback();
        this.fetchProjects();
    }
    async fetchProjects() {
        this._loading = true;
        this._error = '';
        this.requestUpdate();
        try {
            const idxOrg = mls.l5.getProjectOrgIndex(this.project) || -1;
            const orgName = mls.l5.getOrgsName()[idxOrg];
            const lastOrg = mls.stor.orgs[orgName];
            if (!lastOrg) {
                this._error = 'Not found organization';
                return;
            }
            this.projects = lastOrg.sett.projects;
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : 'Unknown error';
        }
        finally {
            this._loading = false;
            this.requestUpdate();
        }
    }
    handleSearch(e) {
        const input = e.target;
        this.searchQuery = input.value;
        this.requestUpdate();
    }
    handleViewProject(project) {
        mls.setActualProject(project.id);
        const orgIndex = mls.l5.getProjectOrgIndex(project.id);
        mls.l5.setActualOrg(orgIndex);
        window.location.reload();
    }
    getFiltered(archived) {
        const query = this.searchQuery.toLowerCase();
        return this.projects.filter((p) => (p.archived_at !== '' || !archived) &&
            p.name.toLowerCase().includes(query));
    }
    renderProjectList(items) {
        if (items.length === 0) {
            return html `<p class="no-results">${this.msg.noResults}</p>`;
        }
        return html `
            <ul class="project-list">
                ${items.map((p) => html `
                    <li class="project-item">
                        <span class="project-name">${p.name}(${p.id})</span>
                        <button class="btn-view" @click=${() => this.handleViewProject(p)}>
                            ${this.msg.viewProject}
                        </button>
                    </li>
                `)}
            </ul>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this._loading) {
            return html `
                <div class="state-loading">
                    <span class="spinner"></span>
                    <span>${this.msg.loading}</span>
                </div>
            `;
        }
        if (this._error) {
            return html `<div class="feedback error">${this.msg.error}</div>`;
        }
        const active = this.getFiltered(false);
        const archived = this.getFiltered(true);
        return html `
            <div class="container">
                <input
                    class="search-input"
                    type="text"
                    placeholder=${this.msg.searchPlaceholder}
                    .value=${this.searchQuery}
                    @input=${this.handleSearch}
                />

                <section class="section">
                    <h2 class="section-title">${this.msg.activeProjects}</h2>
                    ${this.renderProjectList(active)}
                </section>

                <section class="section">
                    <h2 class="section-title">${this.msg.archivedProjects}</h2>
                    ${this.renderProjectList(archived)}
                </section>
            </div>
        `;
    }
};
__decorate([
    property({ type: Number })
], CollabOrgProjects.prototype, "project", void 0);
CollabOrgProjects = __decorate([
    customElement('collab-org-projects-100554')
], CollabOrgProjects);
export { CollabOrgProjects };
