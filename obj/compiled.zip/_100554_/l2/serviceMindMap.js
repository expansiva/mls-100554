/// <mls fileReference="_100554_/l2/serviceMindMap.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { ServiceBase } from '/_102027_/l2/serviceBase.js';
import { getMindMapByStorFile, setMindMapVariable } from '/_102027_/l2/libMindMap.js';
import '/_100554_/l2/widgetMindMapL4.js';
let ServiceMindMap100554 = class ServiceMindMap100554 extends ServiceBase {
    constructor() {
        super();
        this.actualFile = {};
        //-------SERVICE------------
        this.details = {
            icon: '&#xf5dc',
            state: 'background',
            position: 'right',
            tooltip: 'Mind map',
            visible: true,
            widget: '_100554_serviceMindMap',
            level: [1, 2, 3, 4, 5, 6, 7]
        };
        this.menu = {
            title: '',
            main: {
                opAboutThis: 'About this content',
            },
            tabs: undefined,
            tools: {},
            onClickMain: this.onClickMain.bind(this),
        };
        this.setEvents();
    }
    onClickMain(op) {
        if (op === 'opAboutThis')
            this.showAboutThis();
        else if (this.menu.setMode)
            this.menu.setMode('initial');
    }
    showAboutThis() {
        const div = document.createElement('div');
        div.style.padding = '1rem';
        let name = 'collab-tiles-100554';
        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
            </ul>
		

        `;
        if (this.menu.setMode)
            this.menu.setMode('page', div);
        return true;
    }
    onServiceClick(visible, reinit, el) {
        if (visible) {
            if (this.actualFile[mls.actualLevel]) {
                setMindMapVariable([]);
                this.configure();
            }
        }
    }
    //---------------EVENTS----------------
    setEvents() {
        mls.events.addEventListener([2, 4], ['FileAction'], this.onMLSFileActionMindmap.bind(this));
    }
    async onMLSFileActionMindmap(ev) {
        try {
            if (![2, 4].includes(ev.level) || (ev.type !== 'FileAction') || !ev.desc)
                return;
            const fileAction = JSON.parse(ev.desc);
            const eventsValid = ['open'];
            if (fileAction.position === this.position ||
                !eventsValid.includes(fileAction.action))
                return;
            const key = mls.stor.getKeyToFiles(fileAction.project, 2, fileAction.shortName, fileAction.folder, '.ts');
            if (!mls.stor.files[key])
                return;
            this.actualFile[mls.actualLevel] = mls.stor.files[key];
            this.configure();
            // if (ev.level === 4) this.openMe();
        }
        catch (e) {
            console.info(e);
        }
    }
    //----------COMPONENT------------------
    firstUpdated(_changedProperties) {
        super.firstUpdated(_changedProperties);
    }
    render() {
        return this.renderDefault();
    }
    renderDefault() {
        const currentPage = this.actualFile[mls.actualLevel] ? this.actualFile[mls.actualLevel].shortName : "unknown";
        //if (!this.dataJson) return html`No valid defs found in this ${currentPage}`;
        return html `<widget-mind-map-l4-100554 .mapState=${this.dataJson} currentpage="${currentPage}"></widget-mind-map-l4-100554>`;
    }
    //----------IMPLEMENTS-------------------
    async configure() {
        try {
            this.dataJson = this.actualFile ? await getMindMapByStorFile(this.actualFile[mls.actualLevel]) : undefined;
        }
        catch (e) {
            this.dataJson = undefined;
        }
    }
};
__decorate([
    property({ type: String })
], ServiceMindMap100554.prototype, "dataJson", void 0);
ServiceMindMap100554 = __decorate([
    customElement('service-mind-map-100554')
], ServiceMindMap100554);
export { ServiceMindMap100554 };
