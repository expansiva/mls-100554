/// <mls fileReference="_100554_/l2/lessMonaco.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/lessMonaco.ts",
        "componentType": "tool",
        "componentScope": "editor",
        "group": "enhancement"
    },
    "asIs": {
        "semantic": {
            "generalDescription": "class to interface with monaco models",
            "businessCapabilities": [],
            "technicalCapabilities": [
                "getLines",
                "insertLine",
                "deleteLine",
                "deleteLines",
                "updateLine",
                "finishEdit"
            ],
            "implementedFeatures": [
                "getLines",
                "insertLine",
                "deleteLine",
                "deleteLines",
                "updateLine",
                "finishEdit"
            ]
        }
    }
};
