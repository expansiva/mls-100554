/// <mls fileReference="_100554_/l2/pluginBase.ts" enhancement="_100554_enhancementLit" />
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
import { customElement, property } from "lit/decorators.js";
let PluginBase = class extends CollabLitElement {
  scope = "";
};
__decorateClass([
  property({ type: String })
], PluginBase.prototype, "scope", 2);
PluginBase = __decorateClass([
  customElement("plugin-base-100554")
], PluginBase);
export {
  PluginBase
};
