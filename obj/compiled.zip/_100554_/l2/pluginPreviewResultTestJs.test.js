/// <mls fileReference="_100554_/l2/pluginPreviewResultTestJs.test.ts" enhancement="_blank" />
export const integrations = [];
export const tests = [];
