/// <mls fileReference="_100554_/l2/testCoachMarks.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from '/_100554_/l2/collabPageElement.js';
import { customElement } from 'lit/decorators.js';
import { addCoachMark } from '/_100554_/l2/coachMarks.js';
let TestCoachMarks100554 = class TestCoachMarks100554 extends CollabPageElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`test-coach-marks-100554 a {
  border: 0 none;
  outline: 0;
  text-decoration: none;
}
test-coach-marks-100554 strong {
  font-weight: bold;
}
test-coach-marks-100554 p {
  margin: 0.75rem 0 0;
}
test-coach-marks-100554 h1 {
  font-size: 0.75rem;
  font-weight: normal;
  margin: 0;
  padding: 0;
}
test-coach-marks-100554 input,
test-coach-marks-100554 button {
  border: 0 none;
  outline: 0 none;
}
test-coach-marks-100554 button {
  background-color: #666;
  color: #fff;
}
test-coach-marks-100554 button:hover,
test-coach-marks-100554 button:focus {
  background-color: #555;
}
test-coach-marks-100554 img,
test-coach-marks-100554 .basket-module,
test-coach-marks-100554 .basket-labels,
test-coach-marks-100554 .basket-product {
  width: 100%;
}
test-coach-marks-100554 input,
test-coach-marks-100554 button,
test-coach-marks-100554 .basket,
test-coach-marks-100554 .basket-module,
test-coach-marks-100554 .basket-labels,
test-coach-marks-100554 .item,
test-coach-marks-100554 .price,
test-coach-marks-100554 .quantity,
test-coach-marks-100554 .subtotal,
test-coach-marks-100554 .basket-product,
test-coach-marks-100554 .product-image,
test-coach-marks-100554 .product-details {
  float: left;
}
test-coach-marks-100554 .price:before,
test-coach-marks-100554 .subtotal:before,
test-coach-marks-100554 .subtotal-value:before,
test-coach-marks-100554 .total-value:before,
test-coach-marks-100554 .promo-value:before {
  content: "R$";
}
test-coach-marks-100554 .hide {
  display: none;
}
test-coach-marks-100554 main {
  clear: both;
  font-size: 0.75rem;
  margin: 0 auto;
  overflow: hidden;
  padding: 1rem 0;
  width: 960px;
}
test-coach-marks-100554 .basket,
test-coach-marks-100554 aside {
  padding: 0 1rem;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
test-coach-marks-100554 .basket {
  width: 70%;
}
test-coach-marks-100554 .basket-module {
  color: #111;
}
test-coach-marks-100554 label {
  display: block;
  margin-bottom: 0.3125rem;
}
test-coach-marks-100554 .promo-code-field {
  border: 1px solid #ccc;
  padding: 0.5rem;
  text-transform: uppercase;
  transition: all 0.2s linear;
  width: 48%;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
  -moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
  -o-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}
test-coach-marks-100554 .promo-code-field:hover,
test-coach-marks-100554 .promo-code-field:focus {
  border: 1px solid #999;
}
test-coach-marks-100554 .promo-code-cta {
  border-radius: 4px;
  font-size: 0.625rem;
  margin-left: 0.625rem;
  padding: 0.6875rem 1.25rem 0.625rem;
}
test-coach-marks-100554 .basket-labels {
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  margin-top: 1.625rem;
}
test-coach-marks-100554 ul {
  list-style: none;
  margin: 0;
  padding: 0;
}
test-coach-marks-100554 li {
  color: #111;
  display: inline-block;
  padding: 0.625rem 0;
}
test-coach-marks-100554 li.price:before,
test-coach-marks-100554 li.subtotal:before {
  content: "";
}
test-coach-marks-100554 .item {
  width: 55%;
}
test-coach-marks-100554 .price,
test-coach-marks-100554 .quantity,
test-coach-marks-100554 .subtotal {
  width: 15%;
}
test-coach-marks-100554 .subtotal {
  text-align: right;
}
test-coach-marks-100554 .remove {
  bottom: 1.125rem;
  float: right;
  position: absolute;
  right: 0;
  text-align: right;
  width: 45%;
}
test-coach-marks-100554 .remove button {
  background-color: transparent;
  color: #777;
  float: none;
  text-decoration: underline;
  text-transform: uppercase;
}
test-coach-marks-100554 .item-heading {
  padding-left: 4.375rem;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
test-coach-marks-100554 .basket-product {
  border-bottom: 1px solid #ccc;
  padding: 1rem 0;
  position: relative;
}
test-coach-marks-100554 .product-image {
  width: 35%;
}
test-coach-marks-100554 .product-details {
  width: 65%;
}
test-coach-marks-100554 .product-frame {
  border: 1px solid #aaa;
}
test-coach-marks-100554 .product-details {
  padding: 0 1.5rem;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
test-coach-marks-100554 .quantity-field {
  background-color: #ccc;
  border: 1px solid #aaa;
  border-radius: 4px;
  font-size: 0.625rem;
  padding: 2px;
  width: 3.75rem;
}
test-coach-marks-100554 aside {
  float: right;
  position: relative;
  width: 30%;
}
test-coach-marks-100554 .summary {
  background-color: #eee;
  border: 1px solid #aaa;
  padding: 1rem;
  position: fixed;
  width: 250px;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}
test-coach-marks-100554 .summary-total-items {
  color: #666;
  font-size: 0.875rem;
  text-align: center;
}
test-coach-marks-100554 .summary-subtotal,
test-coach-marks-100554 .summary-total {
  border-top: 1px solid #ccc;
  border-bottom: 1px solid #ccc;
  clear: both;
  margin: 1rem 0;
  overflow: hidden;
  padding: 0.5rem 0;
}
test-coach-marks-100554 .subtotal-title,
test-coach-marks-100554 .subtotal-value,
test-coach-marks-100554 .total-title,
test-coach-marks-100554 .total-value,
test-coach-marks-100554 .promo-title,
test-coach-marks-100554 .promo-value {
  color: #111;
  float: left;
  width: 50%;
}
test-coach-marks-100554 .summary-promo {
  -webkit-transition: all 0.3s ease;
  -moz-transition: all 0.3s ease;
  -o-transition: all 0.3s ease;
  transition: all 0.3s ease;
}
test-coach-marks-100554 .promo-title {
  float: left;
  width: 70%;
}
test-coach-marks-100554 .promo-value {
  color: #8b0000;
  float: left;
  text-align: right;
  width: 30%;
}
test-coach-marks-100554 .summary-delivery {
  padding-bottom: 3rem;
}
test-coach-marks-100554 .subtotal-value,
test-coach-marks-100554 .total-value {
  text-align: right;
}
test-coach-marks-100554 .total-title {
  font-weight: bold;
  text-transform: uppercase;
}
test-coach-marks-100554 .summary-checkout {
  display: block;
}
test-coach-marks-100554 .checkout-cta {
  display: block;
  float: none;
  font-size: 0.75rem;
  text-align: center;
  text-transform: uppercase;
  padding: 0.625rem 0;
  width: 100%;
}
test-coach-marks-100554 .summary-delivery-selection {
  background-color: #ccc;
  border: 1px solid #aaa;
  border-radius: 4px;
  display: block;
  font-size: 0.625rem;
  height: 34px;
  width: 100%;
}
@media screen and (max-width: 640px) {
  test-coach-marks-100554 aside,
  test-coach-marks-100554 .basket,
  test-coach-marks-100554 .summary,
  test-coach-marks-100554 .item,
  test-coach-marks-100554 .remove {
    width: 100%;
  }
  test-coach-marks-100554 .basket-labels {
    display: none;
  }
  test-coach-marks-100554 .basket-module {
    margin-bottom: 1rem;
  }
  test-coach-marks-100554 .item {
    margin-bottom: 1rem;
  }
  test-coach-marks-100554 .product-image {
    width: 40%;
  }
  test-coach-marks-100554 .product-details {
    width: 60%;
  }
  test-coach-marks-100554 .price,
  test-coach-marks-100554 .subtotal {
    width: 33%;
  }
  test-coach-marks-100554 .quantity {
    text-align: center;
    width: 34%;
  }
  test-coach-marks-100554 .quantity-field {
    float: none;
  }
  test-coach-marks-100554 .remove {
    bottom: 0;
    text-align: left;
    margin-top: 0.75rem;
    position: relative;
  }
  test-coach-marks-100554 .remove button {
    padding: 0;
  }
  test-coach-marks-100554 .summary {
    margin-top: 1.25rem;
    position: relative;
  }
}
@media screen and (min-width: 641px) and (max-width: 960px) {
  test-coach-marks-100554 aside {
    padding: 0 1rem 0 0;
  }
  test-coach-marks-100554 .summary {
    width: 28%;
  }
}
@media screen and (max-width: 960px) {
  test-coach-marks-100554 main {
    width: 100%;
  }
  test-coach-marks-100554 .product-details {
    padding: 0 1rem;
  }
}
`);
    }
    initPage() {
        this.setCoach();
    }
    setCoach() {
        const btn = document.querySelector('#setCoachMark');
        if (!btn)
            return;
        btn.onclick = () => {
            const json = {
                key: "venda10",
                transparency: "normal",
                fontSize: "1.3em",
                timeClose: 10,
                steps: [
                    {
                        elementRef: "#promo-code",
                        text: "Insira aqui seu codigo promocional 2",
                        position: "top",
                        marginV: -25,
                        arrow: "down",
                        duration: 1,
                        autoClose: true
                    },
                    {
                        text: `<iframe width="560" height="315" src="https://www.youtube.com/embed/4zyORrpBDFc?si=JHVZAfJ-Uj6ebM9r" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
                        positionNoRef: 'bottom-centerr',
                    },
                    {
                        elementRef: ".checkout-cta",
                        text: "Clique aqui para fechar a compra 2",
                        position: "left",
                        marginH: -20,
                        arrow: "right",
                        animation: "shake",
                        timeAnimation: 1000,
                        loopAni: true
                    },
                    {
                        elementRef: "#showqtd",
                        text: "Quantidade do item 2",
                        position: "right",
                        marginH: 5,
                        marginV: -5,
                        arrow: "left"
                    }
                ]
            };
            addCoachMark(json);
        };
    }
};
TestCoachMarks100554 = __decorate([
    customElement('test-coach-marks-100554')
], TestCoachMarks100554);
export { TestCoachMarks100554 };
