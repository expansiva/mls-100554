/// <mls fileReference="_100554_/l2/testCoachMarks.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabPageElement } from '/_100554_/l2/collabPageElement.js';
import { customElement } from 'lit/decorators.js';
import { addCoachMark } from '/_100554_/l2/coachMarks.js';
let TestCoachMarks100554 = class TestCoachMarks100554 extends CollabPageElement {
    initPage() {
        this.setCoach();
    }
    setCoach() {
        const btn = document.querySelector('#setCoachMark');
        if (!btn)
            return;
        btn.onclick = () => {
            const json = {
                key: "venda10",
                transparency: "normal",
                fontSize: "1.3em",
                timeClose: 10,
                steps: [
                    {
                        elementRef: "#promo-code",
                        text: "Insira aqui seu codigo promocional 2",
                        position: "top",
                        marginV: -25,
                        arrow: "down",
                        duration: 1,
                        autoClose: true
                    },
                    {
                        text: `<iframe width="560" height="315" src="https://www.youtube.com/embed/4zyORrpBDFc?si=JHVZAfJ-Uj6ebM9r" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>`,
                        positionNoRef: 'bottom-centerr',
                    },
                    {
                        elementRef: ".checkout-cta",
                        text: "Clique aqui para fechar a compra 2",
                        position: "left",
                        marginH: -20,
                        arrow: "right",
                        animation: "shake",
                        timeAnimation: 1000,
                        loopAni: true
                    },
                    {
                        elementRef: "#showqtd",
                        text: "Quantidade do item 2",
                        position: "right",
                        marginH: 5,
                        marginV: -5,
                        arrow: "left"
                    }
                ]
            };
            addCoachMark(json);
        };
    }
};
TestCoachMarks100554 = __decorate([
    customElement('test-coach-marks-100554')
], TestCoachMarks100554);
export { TestCoachMarks100554 };
