// project/_102027_/l2/propiertiesLit.ts
function getPropierties(model) {
  let rc = [];
  rc = getPropiertiesByDecorators(model);
  rc = getMoreInfoInJsDoc(model, rc);
  return rc;
}
function getDefaultPropierties() {
  return [
    {
      propertyName: "class",
      propertyType: "string",
      sectionName: "principal",
      defaultValue: "",
      hint: "css classes"
    },
    {
      propertyName: "id",
      propertyType: "string",
      sectionName: "principal",
      defaultValue: "",
      pattern: "^[_a-zA-Z]\\w*$",
      hint: "identifier for javascript manipulation"
    }
  ];
}
function getPropiertiesByDecorators(model) {
  const decorators = model.compilerResults?.decorators;
  if (!decorators) return [];
  const rc = [];
  const objDecorators = JSON.parse(decorators);
  Object.entries(objDecorators).forEach((entrie) => {
    const item = entrie[1];
    if (item.type === "PropertyDeclaration") {
      const propertyName = item.parentName;
      item.decorators.forEach((decorator) => {
        if (decorator.text.startsWith("property(")) {
          const prop = {};
          const propertyType = getPropType(decorator.text)?.toLowerCase();
          prop["alias"] = getPropAttribute(decorator.text);
          prop.propertyName = propertyName;
          if (propertyType) prop.propertyType = propertyType;
          rc.push(prop);
        }
      });
    }
  });
  const defaultProps = getDefaultPropierties();
  return [...defaultProps, ...rc];
}
function getMoreInfoInJsDoc(model, propierties) {
  const devDoc = model.compilerResults?.devDoc;
  if (!devDoc) return propierties;
  const objDocs = JSON.parse(devDoc);
  const jsDocProps = getJSDocPropierties(objDocs);
  for (let i = 0; i < propierties.length; i++) {
    let prop = propierties[i];
    const propInPropsJsDoc = jsDocProps.find((_prop) => _prop.propertyName === prop.propertyName);
    prop.propertyName = prop["alias"] || prop.propertyName;
    delete prop["alias"];
    if (propInPropsJsDoc) {
      prop = {
        ...propInPropsJsDoc,
        ...prop
      };
      propierties[i] = prop;
    }
  }
  return propierties;
}
function getJSDocPropierties(objDocs) {
  const rc = [];
  for (const doc of objDocs) {
    if (doc.type !== "class") continue;
    const docMembersProp = doc.members.filter((m) => {
      const isProp = m.type === "property";
      let isLitProp = false;
      if (isProp) {
        const { modifiers } = m;
        isLitProp = isDecoratorProp(modifiers);
      }
      return isProp && isLitProp;
    });
    docMembersProp.forEach((prop) => {
      const propItem = {};
      const fieldType = getFieldTypeInfo(prop.tags);
      const sectionName = getSectionsTag(fieldType);
      const propType = getPropTypeTag(fieldType);
      propItem.hint = prop.comment;
      propItem.propertyName = prop.name;
      propItem.defaultValue = prop.initializerText || fieldType?.defaultValue || "";
      if (propType) propItem.propertyType = propType;
      if (sectionName) propItem.sectionName = sectionName;
      if (fieldType?.cols) propItem.cols = fieldType?.cols;
      if (fieldType?.rows) propItem.rows = fieldType?.rows;
      if (fieldType?.pattern) propItem.pattern = fieldType?.pattern;
      if (fieldType?.max) propItem.max = fieldType?.max;
      if (fieldType?.min) propItem.min = fieldType?.min;
      if (fieldType?.step) propItem.step = fieldType?.step;
      if (fieldType?.maxLength) propItem.maxLength = fieldType?.maxLength;
      if (propType === "list") {
        const itens = getItensByType(prop.initializerType);
        propItem.items = fieldType?.items || itens || [];
      }
      rc.push(propItem);
    });
  }
  return rc;
}
function getItensByType(initializerType) {
  if (!initializerType) return [];
  const regex = /"(.*?)"/g;
  const matches = initializerType.match(regex);
  if (matches) {
    const resultList = matches.map((match) => match.replace(/"/g, ""));
    return resultList;
  }
  return [];
}
function getPropType(propertyString) {
  const typeRegex = /type:\s*([A-Za-z]+)/;
  const match = propertyString.match(typeRegex);
  if (match && match.length > 1) {
    const typeProp = match[1];
    return typeProp;
  }
  return void 0;
}
function getPropAttribute(propertyString) {
  const typeRegex = /attribute:\s*['"]([^'"]+)['"]/;
  const match = propertyString.match(typeRegex);
  if (match && match.length > 1) {
    const attr = match[1];
    return attr;
  }
  return void 0;
}
function isDecoratorProp(modifiers) {
  if (!modifiers) return false;
  const searchStr = "@property(";
  for (const item of modifiers) {
    if (item.startsWith(searchStr)) return true;
  }
  return false;
}
function getFieldTypeInfo(tags) {
  const tag = tags.find((item) => item.tagName === "fieldType");
  if (!tag) return void 0;
  try {
    const rc = JSON.parse(tag.comment);
    return rc;
  } catch (err) {
    return void 0;
  }
}
function getSectionsTag(fieldType) {
  const defaultSection = "principal";
  if (!fieldType) return defaultSection;
  const { sectionName } = fieldType;
  if (!sectionName) return defaultSection;
  const valueFormated = sectionName.toLowerCase().trim();
  if (["principal", "optional", "advanced"].includes(valueFormated)) return valueFormated;
  return defaultSection;
}
function getPropTypeTag(fieldType) {
  const defaultType = "string";
  if (!fieldType) return defaultType;
  const { propertyType } = fieldType;
  if (!propertyType) return defaultType;
  const valueFormated = propertyType.toLowerCase().trim();
  if (["string", "number", "boolean", "list", "json"].includes(valueFormated)) return valueFormated;
  return defaultType;
}

// project/_100554_/l2/enhancementAgent.ts
var requires = [];
var getDesignDetails = async (modelTS) => {
  return {
    defaultGroupName: "",
    defaultHtmlExamplePreview: "",
    properties: getPropierties(modelTS),
    webComponentDependencies: []
  };
};
var onAfterChange = async (modelTS) => {
};
var onAfterCompile = async (modelTS) => {
  await injectSourceInJs(modelTS);
};
var onAfterCompileAction = async (sourceJS, sourceTS) => {
  return injectSourceInJsAction(sourceJS, sourceTS);
};
async function injectSourceInJs(modelTS) {
  if (!modelTS || !modelTS.compilerResults) return;
  let sourceJS = modelTS.compilerResults.prodJS;
  const sourceTS = modelTS.model.getValue();
  sourceJS = removeRegionsIntoJS(sourceJS);
  sourceJS = injectRegionsIntoTemplate({ sourceTS, sourceJS, warnUnusedRegions: true });
  let { project, shortName, folder, extension } = modelTS.storFile;
  const version = modelTS.compilerResults.cacheVersion;
  extension = extension.replace(".ts", ".js");
  modelTS.compilerResults.prodJS = sourceJS;
  const url = await mls.stor.cache.addIfNeed({ project, folder, shortName, version, content: sourceJS, extension });
  modelTS.compilerResults.trace.push(`enhancementAgent, updated JS, cache url:${url}`);
}
async function injectSourceInJsAction(js, ts) {
  let sourceJS = removeRegionsIntoJS(js);
  sourceJS = injectRegionsIntoTemplate({ sourceTS: ts, sourceJS, warnUnusedRegions: true });
  return sourceJS;
}
function injectRegionsIntoTemplate(args) {
  const regions = /* @__PURE__ */ new Map();
  let currentRegion = null;
  const lines = args.sourceTS.split("\n");
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trimStart();
    if (trimmed.startsWith("//#region")) {
      const match = line.match(/\/\/\s*#region\s+([\w-]+)/);
      if (!match) {
        throw new Error(`Invalid //#region syntax at line ${i + 1}`);
      }
      const name = match[1];
      if (currentRegion !== null) {
        throw new Error(`Nested //#region "${name}" inside "${currentRegion}" at line ${i + 1}`);
      }
      if (regions.has(name)) {
        throw new Error(`Duplicate //#region "${name}" at line ${i + 1}`);
      }
      currentRegion = name;
      regions.set(name, "");
      continue;
    }
    if (trimmed.startsWith("//#endregion")) {
      if (currentRegion === null) {
        throw new Error(`Unexpected //#endregion at line ${i + 1}`);
      }
      currentRegion = null;
      continue;
    }
    if (currentRegion !== null) {
      if (line.includes("`")) {
        throw new Error(
          `Invalid character \` inside //#region "${currentRegion}". Regions injected into JS templates must not contain backticks.`
        );
      }
      regions.set(currentRegion, regions.get(currentRegion) + line + "\n");
    }
  }
  if (currentRegion !== null) {
    throw new Error(`Unclosed //#region "${currentRegion}" at end of file`);
  }
  const used = /* @__PURE__ */ new Set();
  const result = args.sourceJS.replace(/\[\[([\w-]+)\]\]/g, (full, name) => {
    if (!regions.has(name)) {
      throw new Error(`Placeholder [[${name}]] not found in source regions`);
    }
    used.add(name);
    return regions.get(name).trimEnd();
  });
  if (args.warnUnusedRegions) {
    for (const name of regions.keys()) {
      if (!used.has(name)) {
        console.warn(`Warning: //#region ${name} defined but not used`);
      }
    }
  }
  return result;
}
function removeRegionsIntoJS(sourceJS) {
  return sourceJS.replace(
    /\/\/\s*#region[\s\S]*?\/\/\s*#endregion/g,
    ""
  );
}
export {
  getDesignDetails,
  onAfterChange,
  onAfterCompile,
  onAfterCompileAction,
  requires
};
