/// <mls fileReference="_100554_/l2/pluginStylePadding.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, query, queryAll } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { getState, setState } from '/_102029_/l2/collabState.js';
import { getMessageKey } from '/_102029_/l2/collabLitElement.js';
import '/_100554_/l2/collabDsInputSelectColor.js';
import '/_100554_/l2/collabDsInputRange.js';
import { collab_lock, collab_lock_open, collab_padding_bottom, collab_padding_top, collab_padding_left, collab_padding_right, } from '/_100554_/l2/collabIcons.js';
/// **collab_i18n_start**
const message_pt = {
    all: 'Group',
    padding: 'Padding',
    top: 'Superior',
    left: 'Esquerda',
    bottom: 'Inferior',
    right: 'Direita',
    description: 'Este plugin permite ajustar preenchimentos de maneira simples e intuitiva. Ideal para desenvolvedores que buscam precisão no espaçamento dos elementos, ele facilita a definição de distâncias internas e externas para garantir um layout consistente e bem estruturado.'
};
const message_en = {
    all: 'Group',
    padding: 'Padding',
    top: 'Top',
    left: 'Left',
    bottom: 'Bottom',
    right: 'Right',
    description: 'This plugin enables easy and intuitive adjustments paddings. Ideal for developers seeking precise element spacing, it streamlines the setup of inner and outer distances to ensure a consistent and well-structured layout.'
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
export const tags = ['padding*'];
export function getDescription() {
    const lang = getMessageKey(messages);
    return messages[lang].description;
}
let PluginStylePadding = class PluginStylePadding extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.position = 'left';
        this.showFull = 'true';
        this.paddingLocked = false;
        this.tpMeasures = ['px', 'em', 'rem', 'vh', 'vw', 'vmin', 'vmax', 'ex', 'ch', 'auto'];
        this.timeonChangePadding = -1;
        this.gallery = [
            { style: 'padding: 10px', state: { paddingBottom: '10px', paddingTop: '10px', paddingLeft: '10px', paddingRight: '10px' } },
            { style: 'padding: 10px 0', state: { paddingBottom: '10px', paddingTop: '10px', paddingLeft: '0', paddingRight: '0' } },
            { style: 'padding: 0 10px', state: { paddingBottom: '0', paddingTop: '0', paddingLeft: '10px', paddingRight: '10px' } },
            { style: 'padding-left: 10px', state: { paddingBottom: '', paddingTop: '', paddingLeft: '10px', paddingRight: '' } },
            { style: 'padding-right: 10px', state: { paddingBottom: '', paddingTop: '', paddingLeft: '', paddingRight: '10px' } },
            { style: 'padding-top: 10px', state: { paddingBottom: '', paddingTop: '10px', paddingLeft: '', paddingRight: '' } },
            { style: 'padding-bottom: 10px', state: { paddingBottom: '10px', paddingTop: '', paddingLeft: '', paddingRight: '' } },
        ];
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        if (_value.emitter === 'helper')
            return;
        if (!_value.selector || !_value.lessCSS || !_value.lessCSS.lessAST || !_value.lessCSS.lessAST.ast[_value.selector])
            return;
        const actualAst = _value.lessCSS.lessAST.ast[_value.selector];
        if (!actualAst)
            return;
        let hasRulePaddingInAST = false;
        Object.keys(actualAst).forEach((prop) => {
            if (prop.startsWith('padding'))
                hasRulePaddingInAST = true;
        });
        this.clear();
        if (hasRulePaddingInAST) {
            this._onIcaStateChange();
        }
    }
    clear() {
        this.paddingLeft = undefined;
        this.paddingRight = undefined;
        this.paddingTop = undefined;
        this.paddingBottom = undefined;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `

        ${this.showFull === 'true' ?
            html `
                ${this.renderGallery()}
                ${this.renderPadding()}
            ` :
            html `
                ${this.renderGallery()}
            `}
        `;
    }
    renderPadding() {
        return html `
            <h5 class="helper-group-title" >${this.msg.padding}</h5>
                <div class="helper-group-lock">
                <input id="helper-padding-lock" ?checked=${this.paddingLocked} type="checkbox" @change=${this.handleChangeLockPadding}>
                <label for="helper-padding-lock"> ${this.msg.all}</label>
                <i>${this.paddingLocked ? collab_lock : collab_lock_open}</i>
            </div>

            <div class="group">

                <div class="group-edit">
                    <i data-tooltip="${this.msg.top}">${collab_padding_top}</i>
                    <collab-ds-input-range-100554
                        prop="padding-top"
                        value=${this.paddingTop}
                        .arraySelect=${this.tpMeasures}  
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554>
                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.left}">${collab_padding_left}</i>
                    <collab-ds-input-range-100554
                        prop="padding-left"
                        value=${this.paddingLeft}
                        .arraySelect=${this.tpMeasures} 
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554>    

                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.bottom}">${collab_padding_bottom}</i>
                    <collab-ds-input-range-100554
                        prop="padding-bottom"
                        value=${this.paddingBottom}
                        .arraySelect=${this.tpMeasures} 
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554> 

                </div>

                <div class="group-edit">
                    <i data-tooltip="${this.msg.right}">${collab_padding_right}</i>
                    <collab-ds-input-range-100554
                        prop="padding-right"
                        value=${this.paddingRight}
                        .arraySelect=${this.tpMeasures} 
                        group="padding"
                        @onchange="${(e) => this.handleChangePadding(e)}"
                    ></collab-ds-input-range-100554> 
                </div>
            </div>

        `;
    }
    renderGallery() {
        return html `
            <div class="gallery">
                ${repeat(this.gallery, ((key) => key), ((galleryItem, index) => {
            return html `
                <div class="box" @click=${() => { this.onGalleryClick(galleryItem); }}>
                    <div style="${galleryItem.style}">
                        <span></span>
                    </div>
                </div>`;
        }))}
            </div>
        
        `;
    }
    _onIcaStateChange() {
        if (!this.state || !this.state.lessCSS)
            return;
        const rule = this.findCSSRuleInIframe(this.state.lessCSS.selector);
        if (!rule)
            return;
        this.setValues(rule);
    }
    handleChangePadding(e) {
        clearTimeout(this.timeonChangePadding);
        const el = e.detail.target;
        const prop = el.getAttribute('prop');
        if (!prop)
            return;
        const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(prop);
        if (this.timeonChangePadding)
            window.clearTimeout(this.timeonChangePadding);
        this.timeonChangePadding = window.setTimeout(() => {
            if (!this.paddingLocked) {
                if (!convertedProp)
                    return;
                this[convertedProp] = el.value;
                this.setState();
                return;
            }
            this.paddingInputs?.forEach((inp) => {
                if (inp === el)
                    return;
                inp.value = el.value;
            });
            this.paddingBottom = this.paddingLeft = this.paddingRight = this.paddingTop = el.value;
            this.setState();
        }, 100);
    }
    handleChangeLockPadding() {
        if (!this.inputLockP)
            return;
        this.paddingLocked = this.inputLockP.checked;
    }
    setState() {
        const allPadding = [this.paddingTop, this.paddingLeft, this.paddingBottom, this.paddingRight];
        const arePaddingsAllEqual = allPadding.every(value => value === allPadding[0]);
        const arePaddingPairsEqual = (this.paddingTop === this.paddingBottom) && (this.paddingLeft === this.paddingRight);
        let paddingValue;
        if (arePaddingsAllEqual)
            paddingValue = this.paddingTop;
        else if (arePaddingPairsEqual)
            paddingValue = `${this.paddingTop} ${this.paddingRight}`;
        else {
            paddingValue = {
                paddingTop: this.paddingTop,
                paddingRight: this.paddingRight,
                paddingBottom: this.paddingBottom,
                paddingLeft: this.paddingLeft,
            };
        }
        this.updatePadding(paddingValue);
    }
    updatePadding(padding) {
        setState(`less.${this.position}.emitter`, 'helper');
        const styles = getState(`less.${this.position}.lessCSS.styles`);
        if (typeof padding === 'string') {
            styles.paddingTop = styles.paddingRight = styles.paddingBottom = styles.paddingLeft = '';
            styles.padding = padding;
        }
        else {
            styles.padding = '';
            this.paddingTop = styles.paddingTop = padding.paddingTop || '';
            this.paddingRight = styles.paddingRight = padding.paddingRight || '';
            this.paddingBottom = styles.paddingBottom = padding.paddingBottom || '';
            this.paddingLeft = styles.paddingLeft = padding.paddingLeft || '';
        }
    }
    setValues(rule) {
        if (rule.style) {
            for (let i = 0; i < rule.style.length; i++) {
                const propertyName = rule.style[i];
                if (propertyName.startsWith('padding-')) {
                    const propertyValue = rule.style.getPropertyValue(propertyName);
                    const el = this.querySelector(`collab-ds-input-range-100554[prop="${propertyName}"]`);
                    const convertedProp = this.state?.lessCSS?.lessAST.toCamelCaseProperty(propertyName);
                    if (!convertedProp)
                        return;
                    this[convertedProp] = propertyValue;
                    if (el)
                        el.defaultValue = propertyValue;
                }
            }
            this.checkPaddingEquals();
        }
    }
    checkPaddingEquals() {
        if ([this.paddingBottom, this.paddingLeft, this.paddingRight, this.paddingTop].every(padding => padding === this.paddingBottom)) {
            this.paddingLocked = true;
            if (this.inputLockP)
                this.inputLockP.checked = true;
        }
        else {
            this.paddingLocked = false;
            if (this.inputLockP)
                this.inputLockP.checked = false;
        }
    }
    findCSSRuleInIframe(ruleSelector) {
        const json = this.state?.lessCSS?.lessAST.ast[ruleSelector];
        if (!json)
            return null;
        const properties = Object.entries(json)
            .filter(([key]) => !key.startsWith('_'))
            .sort(([, a], [, b]) => a.line - b.line);
        let ruleText = properties.map(([key, item]) => `${key}: ${item.value};`).join(' ');
        const selector = ruleSelector;
        const cssStyleSheet = new CSSStyleSheet();
        const ruleIndex = cssStyleSheet.insertRule(`${selector} { ${ruleText} }`, 0);
        const cssStyleRule = cssStyleSheet.cssRules[ruleIndex];
        return cssStyleRule;
    }
    onGalleryClick(item) {
        this.paddingBottom = item.state.paddingBottom;
        this.paddingTop = item.state.paddingTop;
        this.paddingLeft = item.state.paddingLeft;
        this.paddingRight = item.state.paddingRight;
        this.checkPaddingEquals();
        this.setState();
    }
};
__decorate([
    propertyDataSource()
], PluginStylePadding.prototype, "state", void 0);
__decorate([
    property()
], PluginStylePadding.prototype, "position", void 0);
__decorate([
    property()
], PluginStylePadding.prototype, "showFull", void 0);
__decorate([
    property()
], PluginStylePadding.prototype, "paddingLocked", void 0);
__decorate([
    property()
], PluginStylePadding.prototype, "paddingLeft", void 0);
__decorate([
    property()
], PluginStylePadding.prototype, "paddingRight", void 0);
__decorate([
    property()
], PluginStylePadding.prototype, "paddingTop", void 0);
__decorate([
    property()
], PluginStylePadding.prototype, "paddingBottom", void 0);
__decorate([
    query('#helper-padding-lock')
], PluginStylePadding.prototype, "inputLockP", void 0);
__decorate([
    queryAll('collab-ds-input-range-100554[group="padding"]')
], PluginStylePadding.prototype, "paddingInputs", void 0);
PluginStylePadding = __decorate([
    customElement('plugin-style-padding-100554')
], PluginStylePadding);
export { PluginStylePadding };
