/// <mls fileReference="_100554_/l2/pluginProjectFindFiles.ts" enhancement="_100554_enhancementLit" />
import { html, svg } from 'lit';
import { PluginBaseModule } from '/_100554_/l2/pluginBaseModule.js';
/// **collab_i18n_start**
const message_pt = {
    btnSearch: 'Pesquisar',
    lblSearch: 'Texto a pesquisar (texto ou regex):',
    lblChoice: 'Selecionar tipo de arquivo:',
    lblTotal: 'Total arquivos encontrados:',
};
const message_en = {
    btnSearch: 'Search',
    lblSearch: 'Text to search (text or regex):',
    lblChoice: 'Select file type:',
    lblTotal: 'Total files found:',
};
const messages = {
    'pt': message_pt,
    'en': message_en
};
/// **collab_i18n_end**
export class PluginProjectFindFiles extends PluginBaseModule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`plugin-project-find-files-100554{background-color:var(--bg-primary-color);color:var(--text-primary-color)}plugin-project-find-files-100554 .svg-container{width:22px;margin:4px;display:inline-flex}plugin-project-find-files-100554 .body{margin:1em}plugin-project-find-files-100554 [name="fileType"]{margin-top:.2em;margin-bottom:1.5em;display:block}plugin-project-find-files-100554 [name="searchText"]{margin:.2em;display:block;width:20em;padding:.5em;border:1px solid var(--text-primary-color);border-radius:4px}plugin-project-find-files-100554 button{display:block;margin:2em;padding:.5em 1em;border:1px solid var(--text-primary-color);background-color:var(--bg-secondary-color);color:var(--text-primary-color);cursor:pointer;border-radius:4px}plugin-project-find-files-100554 button:hover{background-color:var(--bg-secondary-color-hover)}`);
        this.msg = messages['en'];
        this.matchedFiles = [];
        this.usingRegex = false;
        this.progressValue = 0;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.style.display = 'block';
        this.style.width = '100%';
        this.style.height = '100%';
        if (this.scope !== "dashboard")
            return html ``;
        return html `
            <div class="plugin-container">
                ${this.renderHeader()}
                ${this.renderBody()}
            </div>
        `;
    }
    renderHeader() {
        return html `
            <header>
                <span class="svg-container">${pluginData.getSvg()}</span>
                <span>${pluginData.title}</span>
            </header>
        `;
    }
    renderBody() {
        return html `
            <div class="body">
                <label for="fileType">${this.msg.lblChoice}</label>
                <select name="fileType">
                    <option value=".ts">.ts - typescript</option>
                    <option value=".html">.html - page</option>
                    <option value=".less">.less - style</option>
                </select>

                <div style="margin-top: 10px;">
                    <label for="searchText">${this.msg.lblSearch}</label>
                    <input name="searchText" type="text" />
                    <button @click="${this.onSearch}">${this.msg.btnSearch}</button>
                </div>

                <progress value="${this.progressValue}" max="100"></progress>
                <p>${this.msg.lblTotal} ${this.matchedFiles.length}, regex:${this.usingRegex}</p>
                <ul>
                    ${this.matchedFiles
            .slice()
            .sort((a, b) => a.localeCompare(b))
            .map(file => html `<li>${file}</li>`)}
                </ul>
            </div>
        `;
    }
    async onSearch() {
        const fileType = this.querySelector('[name="fileType"]').value;
        const searchText = this.querySelector('[name="searchText"]').value;
        const project = mls.actualProject;
        const files = Object.entries(mls.stor.files)
            .filter(([, file]) => file.project === project && file.extension === fileType)
            .map(([key]) => key);
        await this.searchFiles(files, searchText);
    }
    async searchFiles(files, searchText) {
        this.matchedFiles = [];
        this.progressValue = 0;
        let filesProcessed = 0;
        let regex = null;
        this.usingRegex = false;
        try {
            if (searchText.startsWith('/') && searchText.endsWith('/')) {
                const pattern = searchText.slice(1, -1);
                regex = new RegExp(pattern);
                this.usingRegex = true;
            }
            else {
                regex = null;
            }
        }
        catch {
            regex = null;
        }
        const promises = files.map(async (file) => {
            const fileContent = await mls.stor.files[file].getContent("");
            if (typeof fileContent === 'string') {
                const lines = fileContent.split('\n');
                const found = lines.some(line => {
                    if (regex) {
                        return regex.test(line);
                    }
                    else {
                        return line.includes(searchText);
                    }
                });
                if (found) {
                    this.matchedFiles.push(file);
                }
            }
            filesProcessed++;
            this.progressValue = (filesProcessed / files.length) * 100;
            this.requestUpdate();
        });
        await Promise.all(promises);
    }
}
if (!customElements.get('plugin-project-find-files-100554')) {
    customElements.define('plugin-project-find-files-100554', PluginProjectFindFiles);
}
export const pluginData = {
    title: "Find in Files",
    getSvg() {
        return svg `
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 110.94 122.88"><title>lookup</title><path fill="currentColor" d="M19.26,40.53a2.74,2.74,0,0,1-2.59-2.82,2.69,2.69,0,0,1,2.59-2.82H63.41A2.72,2.72,0,0,1,66,37.71a2.68,2.68,0,0,1-2.58,2.82ZM79.41,66a24.82,24.82,0,0,1,20.78,38.41l10.75,11.71-7.42,6.77-10.36-11.4A24.82,24.82,0,1,1,79.41,66Zm13.2,11.62a18.66,18.66,0,1,0,5.47,13.2,18.66,18.66,0,0,0-5.47-13.2Zm-73.32-22a2.73,2.73,0,0,1-2.58-2.82A2.68,2.68,0,0,1,19.29,50H41.37A2.74,2.74,0,0,1,44,52.84a2.68,2.68,0,0,1-2.58,2.82ZM82.76,17.14H92a6.64,6.64,0,0,1,6.61,6.61V55.18c-.2,2.07-5.27,2.1-5.7,0V23.75a.92.92,0,0,0-.94-.94H82.73V55.18c-.49,1.88-4.72,2.16-5.67,0V6.61a.92.92,0,0,0-.94-.94H6.58a1,1,0,0,0-.68.27,1,1,0,0,0-.26.67V85.18a1,1,0,0,0,.26.67,1,1,0,0,0,.68.27H43.36c2.86.29,3,5.23,0,5.67H21.5v10.53a.92.92,0,0,0,.94.94H43.36c2.07.23,2.74,4.94,0,5.67H22.48a6.62,6.62,0,0,1-6.61-6.61V91.79H6.61a6.49,6.49,0,0,1-4.66-2A6.56,6.56,0,0,1,0,85.18V6.61A6.49,6.49,0,0,1,2,2,6.55,6.55,0,0,1,6.61,0H76.16a6.51,6.51,0,0,1,4.66,2,6.54,6.54,0,0,1,1.94,4.66V17.14ZM19.26,25.4a2.74,2.74,0,0,1-2.59-2.82,2.69,2.69,0,0,1,2.59-2.82H63.41A2.73,2.73,0,0,1,66,22.58a2.69,2.69,0,0,1-2.58,2.82Z"/></svg>
    `;
    }
};
