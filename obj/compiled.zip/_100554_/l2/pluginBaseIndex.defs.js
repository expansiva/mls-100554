/// <mls fileReference="_100554_/l2/pluginBaseIndex.defs.ts" enhancement="_blank" />
// Do not change – automatically generated code. 
export const asis = {
    "meta": {
        "fileReference": "_100554_/l2/pluginBaseIndex.ts",
        "componentType": "other",
        "componentScope": "editor",
        "devFidelity": "scaffold"
    },
    "asIs": {
        "semantic": {
            "generalDescription": "Abstract base class for plugin indexing.",
            "technicalCapabilities": [
                "Defines structure for plugin menus",
                "Defines structure for plugin hooks",
                "Defines structure for plugin services"
            ],
            "implementedFeatures": [
                "PluginBaseIndex abstract class"
            ],
            "businessCapabilities": [],
            "constraints": [
                "Abstract class",
                "Default export is 'disabled'"
            ]
        }
    }
};
