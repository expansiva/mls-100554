/// <mls fileReference="_100554_/l2/collabDecorators.ts" enhancement="_100554_enhancementLit" />
import { property } from "lit/decorators.js";
import { getState, setState } from "/_100554_/l2/collabState.js";
function propertyCompositeDataSource(options) {
  return (proto, propName) => {
    property(options)(proto, propName);
    const attributeName = options?.attribute && typeof options.attribute === "string" ? String(options.attribute) : String(propName);
    Object.defineProperty(proto, propName, {
      get() {
        const attributeValue = getAttributeValueWithVariation.call(this, attributeName);
        if (attributeValue && attributeValue.includes("{{")) {
          return parseCompositeData.call(this, attributeValue, attributeName, options, "", false);
        }
        if (this[`_${attributeName}`] !== void 0) return this[`_${attributeName}`];
        if (typeof this[`_${attributeName}`] === "object" || Array.isArray(this[`_${attributeName}`])) return this[`_${attributeName}`];
        return attributeValue;
      },
      set(value) {
        if (typeof value === "string" && value.includes("{{")) {
          this[`_${attributeName}`] = parseCompositeData.call(this, value, attributeName, options, "", true);
        } else {
          this[`_${attributeName}`] = value;
        }
        this.requestUpdate();
      }
    });
    const parseCompositeData = function(templateStr, attributeName2, options2, value, add) {
      const pattern = /\{\{(.*?)\}\}/g;
      let match;
      let composedData = templateStr;
      if (add && options2 && options2.reflect) {
        const attributeValue = getAttributeValueWithVariation.call(this, attributeName2);
        if (attributeValue !== value) this.setAttribute(attributeName2, value);
      }
      let notifications = [];
      while (match = pattern.exec(templateStr)) {
        const stateKey = match[1].trim();
        if (add) {
          notifications.push(stateKey);
        }
        const resolvedValue = getState(stateKey) || "";
        composedData = composedData.replace(match[0], resolvedValue);
      }
      if (notifications.length > 0) {
        prepareForNotification.call(this, attributeName2, notifications);
      }
      return composedData;
    };
  };
}
function propertyDataSource(options) {
  return (proto, propName) => {
    property(options)(proto, propName);
    const attributeName = options?.attribute && typeof options.attribute === "string" ? String(options.attribute) : String(propName);
    Object.defineProperty(proto, propName, {
      get() {
        const attributeValue = this.hasAttribute(attributeName) ? this.getAttribute(attributeName) : "";
        if (typeof attributeValue === "string" && attributeValue && attributeValue.includes("{{") && attributeValue.includes("}}")) {
          const stateKey = attributeValue.replace(/[{{}}]/g, "").trim();
          const stateValue = getState(stateKey);
          if (options?.type === Boolean) {
            if (typeof stateValue === "boolean") return stateValue;
            if (typeof stateValue === "string") return stateValue === "true" || stateValue === "";
            return Boolean(stateValue);
          }
          let aux = stateValue ? stateValue.toString() : "";
          if (typeof stateValue === "object") aux = JSON.stringify(stateValue);
          if (options?.type === String) return stateValue ? aux : stateValue;
          if (options?.type === Array && typeof stateValue === "string") return JSON.parse(stateValue);
          return stateValue;
        }
        if (options?.type === Boolean) {
          if (this.hasAttribute(attributeName) && attributeValue !== "false" || attributeValue === "true") return true;
          if (attributeValue === "false" || attributeValue === void 0) return false;
          if (typeof attributeValue === "boolean") return attributeValue;
          return Boolean(attributeValue);
        }
        if (this[`_${attributeName}`] !== void 0) return this[`_${attributeName}`];
        return attributeValue;
      },
      set(value) {
        if (options?.type === Number && typeof value === "number" && isNaN(value)) {
          const attributeValue = this.hasAttribute(attributeName) ? this.getAttribute(attributeName) : "";
          if (typeof attributeValue === "string" && attributeValue.startsWith("{{") && attributeValue.endsWith("}}")) {
            if (options?.reflect) {
              const attributeValueR = this.hasAttribute(attributeName) ? this.getAttribute(attributeName) : "";
              if (attributeValueR !== value) this.setAttribute(attributeName, value);
            }
            const stateKey = attributeValue.replace(/[{{}}]/g, "").trim();
            prepareForNotification.call(this, attributeName, [stateKey]);
            this[`_${attributeName}`] = value;
            setState(stateKey, value);
          } else {
            this[`_${attributeName}`] = value;
          }
          this.requestUpdate();
          return;
        }
        if (options?.type === Boolean && typeof value === "boolean") {
          const attributeValue = this.hasAttribute(attributeName) ? this.getAttribute(attributeName) : "";
          if (typeof attributeValue === "string" && attributeValue.startsWith("{{") && attributeValue.endsWith("}}")) {
            if (options?.reflect) {
              const attributeValueR = this.hasAttribute(attributeName) ? this.getAttribute(attributeName) : "";
              if (attributeValueR !== value) this.setAttribute(attributeName, value);
            }
            const stateKey = attributeValue.replace(/[{{}}]/g, "").trim();
            prepareForNotification.call(this, attributeName, [stateKey]);
            this[`_${attributeName}`] = value;
            setState(stateKey, value);
          } else {
            this[`_${attributeName}`] = value;
          }
          this.requestUpdate();
          return;
        }
        if (typeof value === "string" && value.startsWith("{{") && value.endsWith("}}")) {
          if (options?.reflect) {
            const attributeValue = this.hasAttribute(attributeName) ? this.getAttribute(attributeName) : "";
            if (attributeValue !== value) this.setAttribute(attributeName, value);
          }
          const stateKey = value.replace(/[{{}}]/g, "").trim();
          prepareForNotification.call(this, attributeName, [stateKey]);
          this[`_${attributeName}`] = getState(stateKey);
        } else if (options?.type === Object && (typeof value === "string" && ((value.startsWith("[") || value.startsWith("{")) && (value.endsWith("]") || value.endsWith("}"))))) {
          this[`_${attributeName}`] = JSON.parse(value);
        } else {
          const attributeValue = this.hasAttribute(attributeName) ? this.getAttribute(attributeName) : "";
          if (typeof attributeValue === "string" && attributeValue.includes("{{") && attributeValue.includes("}}")) {
            const dynamicKey = attributeValue.replace(/[{{}}]/g, "").trim();
            this[`_${attributeName}`] = value;
            setState(dynamicKey, value);
          } else this[`_${attributeName}`] = value;
        }
        this.requestUpdate();
      }
    });
  };
}
function prepareForNotification(attributeName, path) {
  if (typeof this.updateStateKeys !== "function") return;
  this.updateStateKeys(attributeName, path);
}
function getAttributeValueWithVariation(key) {
  const htmlLang = document.documentElement.lang;
  const lang = htmlLang.toLowerCase();
  const actualVariation = this.globalVariation || 0;
  const languageByVariation = lang;
  const languageByVariationSimilar = languageByVariation.split("-")[0];
  const defaultValue = this.getAttribute(key);
  if (actualVariation === 0) return defaultValue;
  const keyVariation = `${key}-${languageByVariation}`;
  const keyVariationSimilar = `${key}-${languageByVariationSimilar}`;
  let variationValue = this.getAttribute(keyVariation);
  if (!variationValue) variationValue = this.getAttribute(keyVariationSimilar);
  return variationValue || defaultValue;
}
export {
  propertyCompositeDataSource,
  propertyDataSource
};
