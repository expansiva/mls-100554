const projectConfig = {};
const FILENAME = "project";
const LEVEL = 5;
const EXTENSION = ".json";
async function clearLocalChanges(project) {
  if (project === void 0) return;
  const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, "", EXTENSION);
  let configFile = mls.stor.files[key];
  if (!configFile) return;
  const config = await getConfigProject(project, true);
  if (!config) return;
  await mls.stor.localStor.setContent(configFile, {
    contentType: "string",
    content: null
  });
  configFile.inLocalStorage = false;
}
async function getConfigProject(project, ignoreLocalChanges = false) {
  if (project === void 0) return void 0;
  const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, "", EXTENSION);
  let configFile = mls.stor.files[key];
  if (!configFile) return void 0;
  if (!projectConfig[project] || ignoreLocalChanges) {
    const lastStatus = configFile.inLocalStorage;
    if (ignoreLocalChanges && configFile.status !== "new") {
      configFile.inLocalStorage = false;
    }
    const content = await configFile.getContent();
    configFile.inLocalStorage = lastStatus;
    if (!content || typeof content !== "string") return void 0;
    const config = JSON.parse(content);
    projectConfig[project] = {
      config,
      versionRef: configFile.versionRef
    };
  }
  return projectConfig[project].config;
}
async function updateConfigProject(project, newConfig) {
  const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, "", EXTENSION);
  projectConfig[project].config = newConfig;
  const configFile = mls.stor.files[key];
  if (!configFile) throw new Error("No config file!");
  await mls.stor.localStor.setContent(configFile, {
    contentType: "string",
    content: JSON.stringify(newConfig, null, 2)
  });
}
async function updateConfigProjectPlugins(project, newPlugins) {
  const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, "", EXTENSION);
  projectConfig[project].config.plugins = newPlugins;
  const configFile = mls.stor.files[key];
  if (!configFile) throw new Error("No config file!");
  await mls.stor.localStor.setContent(configFile, {
    contentType: "string",
    content: JSON.stringify(projectConfig[project].config, null, 2)
  });
}
async function createConfigFile(project) {
  if (project === void 0) throw new Error("Invalid project");
  const key = mls.stor.getKeyToFiles(project, LEVEL, FILENAME, "", EXTENSION);
  let configFile = mls.stor.files[key];
  if (configFile) throw new Error("config file already exists");
  const config = await _createConfigFile(project);
  if (!projectConfig[project]) {
    projectConfig[project] = {
      config,
      versionRef: ""
    };
  }
  projectConfig[project].config = config;
  return projectConfig[project].config;
}
async function _createConfigFile(project) {
  const newConfig = {
    orgName: "[org]",
    designSystems: [
      {
        dsIndex: "0",
        dsName: "localDesignSystem",
        widgetIOName: "_100554_configDsDefault"
      }
    ],
    languages: [
      {
        language: "en",
        name: "English",
        path: "/"
      }
    ],
    plugins: {},
    reasons: {},
    services: [],
    links: [],
    servicesConfigEnabled: false
  };
  const content = JSON.stringify(newConfig);
  const params = {
    project,
    level: LEVEL,
    shortName: FILENAME,
    extension: EXTENSION,
    versionRef: "0",
    folder: ""
  };
  const file = await mls.stor.addOrUpdateFile(params);
  if (!file) throw new Error("invalid file");
  file.status = "new";
  const fileInfo = {
    content,
    contentType: "string"
  };
  await mls.stor.localStor.setContent(file, fileInfo);
  return newConfig;
}
export {
  clearLocalChanges,
  createConfigFile,
  getConfigProject,
  projectConfig,
  updateConfigProject,
  updateConfigProjectPlugins
};
