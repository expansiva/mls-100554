var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __decorateClass = (decorators, target, key, kind) => {
  var result = kind > 1 ? void 0 : kind ? __getOwnPropDesc(target, key) : target;
  for (var i = decorators.length - 1, decorator; i >= 0; i--)
    if (decorator = decorators[i])
      result = (kind ? decorator(target, key, result) : decorator(result)) || result;
  if (kind && result) __defProp(target, key, result);
  return result;
};
import { html, repeat } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { CollabLitElement } from "/_100554_/l2/collabLitElement.js";
import { collab_trash } from "/_100554_/l2/collabIcons.js";
import { updateHTML } from "/_100554_/l2/collabDOMSync.js";
let CollabFCATree = class extends CollabLitElement {
  constructor() {
    super(...arguments);
    this.prompts = [];
    this.inputs = [];
    this.user = { userId: "", threads: [] };
    this.inLoader = true;
    this.models = [
      { k: "gpt-4.1-nano", v: "cost" },
      { k: "reasoner", v: "reasoner" },
      { k: "image", v: "image" },
      { k: "code", v: "code" },
      { k: "gpt-4.1-mini", v: "executor" },
      { k: "writer", v: "writer" },
      { k: "grok-2-latest", v: "latency" },
      { k: "translate", v: "translate" }
    ];
  }
  //--------------COMPONENT---------------
  firstUpdated() {
    this.loadPrompts();
  }
  render() {
    return html`
            <div class="containerLoading" style="${this.inLoader ? "" : "display:none"}">
                <div class="loading-container">
                    <div class="spinner"></div>
                    <p>Loading...</p>
                </div>
            </div>

            <div class="header" style="${this.inLoader ? "display:none" : ""}">
                <div class="groupInputs">
                    <div>
                        <label>Agent name:</label>
                        <input type="text" value="agentJohn" id="agentName"></input>
                    </div>
                    <div>
                        <label>Thread:</label>
                        ${this.renderThreads()}
                    </div>
                    <div>
                        <label>UserId:</label>
                        <input type="text" id="userId" .value="${this.user.userId}"></input>
                    </div>
                </div>
                <div style=" margin-top: 16px;">
                    ${this.renderModels()}
                    <button @click="${this.saveHTML}">Save</button>
                    <button style="background-color: #348e0f;" @click="${this.start}">Start</button>
                </div>
            </div>
            <details style="${this.inLoader ? "display:none" : ""}">
                <summary> Prompts </summary>
                <div class="container">
                    ${repeat(this.prompts, ((key) => key.type + Date.now()), ((p, idx) => {
      return this.renderPrompt(p, idx);
    }))}
                </div>
                <button style="background-color: #348e0f;" @click="${this.addMessage}">
                    Add Message
                </button>
            </details>
            <details style="${this.inLoader ? "display:none" : ""}">
                <summary> Inputs </summary>
                <div class="container">
                    ${repeat(this.inputs, ((key) => key.text + Date.now()), ((i) => {
      return this.renderInput(i);
    }))}
                </div>
            </details>
            <hr/>
            <details open style="${this.inLoader ? "display:none" : ""}">
                <summary> Output </summary>
                <div id="result">
                </div>
            </details>
        `;
  }
  renderPrompt(prompt, idx) {
    let pp = prompt.content.trim();
    if (idx === 0 && this.selModels) {
      pp = `//* <!-- modelType: ${this.selModels.value} -->
${pp}`;
    }
    return html`
            <div class="prompt ${prompt.type}">
                <div class="pheader">
                    <div class="type">
                        ${this.renderSelect(prompt)}
                    </div>
                    <div class="trash" @click="${() => this.trashClick(prompt)}">${collab_trash}</div>
                </div>
                <textarea class="content" @blur="${(e) => this.promptEvent(e, prompt)}">${pp}</textarea>
            </div>
        `;
  }
  renderSelect(prompt) {
    return html`
            <select .value=${prompt.type.trim()} @change=${(e) => this.updateSelect(e, prompt)}>
                <option value="system">System</option>
                <option value="human">Human</option>
                <option value="ai">AI</option>
            </select>
        `;
  }
  renderInput(ipt) {
    return html`
            <div class="input">
                <label>${ipt.text}</label>
                <input type="text" .info="${ipt}" @blur="${(e) => this.inputEvent(e, ipt)}" .value="${ipt.value}" placeholder="Enter variable value..."></input>
            </div>
        `;
  }
  renderModels() {
    return html`
            <select class="model" id="selModels" @change=${(e) => this.requestUpdate()}>
                ${repeat(this.models, ((key) => key.k), ((i) => html`<option value="${i.v}">${i.k}</option>`))}
            </select>
        `;
  }
  renderThreads() {
    return html`
            <select id="threadId">
                ${repeat(this.user.threads, ((key) => key), ((i) => html`<option value="${i}">${i}</option>`))}
            </select>
        `;
  }
  //------------IMPLEMENTS--------------
  async loadPrompts() {
    const myPP = [];
    const myIp = [];
    Array.from(this.children).forEach((c) => {
      const tp = c.getAttribute("type");
      const pp = c.innerHTML;
      if (!tp || !pp) return;
      const p = {
        type: tp,
        content: pp
      };
      c.remove();
      const placeholders = this.getPlaceholders(p.content);
      placeholders.forEach((i) => myIp.push({ text: i, value: "" }));
      myPP.push(p);
    });
    const info = await this.getIdUSer();
    this.user = info;
    this.prompts = myPP;
    this.inputs = myIp;
    this.inLoader = false;
  }
  getPlaceholders(text) {
    const regex = /{{\s*[^}]+?\s*}}/g;
    return text.match(regex) || [];
  }
  async getIdUSer() {
    let ret = {
      userId: "",
      threads: []
    };
    const info = await mls.api.msgGetUserUpdate({ userId: "" });
    ret.userId = info.user.userId || "";
    ret.threads = info.user.threads || [];
    return ret;
  }
  trashClick(pp) {
    const myPP = [];
    const myIp = [];
    this.prompts.forEach((p, idx) => {
      if (p.content !== pp.content || p.type !== pp.type) {
        myPP.push({ ...p });
        const placeholders = this.getPlaceholders(p.content);
        placeholders.forEach((i) => myIp.push({ text: i, value: "" }));
      }
    });
    this.prompts = myPP;
    this.inputs = myIp;
  }
  addMessage() {
    const myPP = [...this.prompts];
    myPP.push({
      type: "system",
      content: ""
    });
    this.prompts = myPP;
  }
  promptEvent(e, prompt) {
    const el = e.target;
    if (!el) return;
    const myIp = [];
    this.prompts.forEach((p) => {
      if (p.content === prompt.content && p.type === prompt.type) p.content = el.value;
      const placeholders = this.getPlaceholders(p.content);
      placeholders.forEach((i) => myIp.push({ text: i, value: "" }));
    });
    this.inputs = myIp;
  }
  updateSelect(e, prompt) {
    const el = e.target;
    if (!el) return;
    this.prompts.forEach((p) => {
      if (p.content === prompt.content && p.type === prompt.type) p.type = el.value;
    });
  }
  inputEvent(e, ipt) {
    const el = e.target;
    if (!el) return;
    this.inputs.forEach((i) => {
      if (i.text === ipt.text) i.value = el.value;
    });
  }
  async start() {
    if (!this.result) {
      console.info("not found result");
      return;
    }
    if (!this.agentName || !this.agentName.value) {
      this.result.innerHTML = "Not found agentName";
      return;
    }
    if (!this.threadId || !this.threadId.value) {
      this.result.innerHTML = "Not found threadId";
      return;
    }
    if (!this.userId || !this.userId.value) {
      this.result.innerHTML = "Not found userId";
      return;
    }
    const myPP = this.prompts.map((obj) => ({ ...obj }));
    myPP.forEach((p, idx) => {
      this.inputs.forEach((i) => {
        p.content = p.content.replace(i.text, i.value);
      });
      if (idx === 0 && this.selModels) {
        p.content = `<!-- modelType: ${this.selModels.value} -->
${p.content}`;
      }
    });
    try {
      this.inLoader = true;
      const args = {
        action: "addMessageAI",
        threadId: this.threadId.value,
        userId: this.userId.value,
        taskTitle: "Custom: " + this.agentName.value,
        userMessage: "Custom: " + this.agentName.value,
        agentName: this.agentName.value,
        inputAI: myPP
      };
      const value = await mls.api.msgAddMessageAI(args);
      this.result.innerText = JSON.stringify(value, null, 2);
      console.info(value);
      this.inLoader = false;
    } catch (e) {
      this.inLoader = false;
      this.result.innerText = e;
    }
  }
  saveHTML() {
    let txt = "<ai-agent-custom-100554>";
    this.prompts.forEach((p) => {
      txt = txt + `
            <promptcustom type="${p.type}">
                ${p.content}
            </promptcustom>
            `;
    });
    txt = txt + "</ai-agent-custom-100554>";
    updateHTML(txt);
  }
};
__decorateClass([
  query("#agentName")
], CollabFCATree.prototype, "agentName", 2);
__decorateClass([
  query("#threadId")
], CollabFCATree.prototype, "threadId", 2);
__decorateClass([
  query("#userId")
], CollabFCATree.prototype, "userId", 2);
__decorateClass([
  query("#result")
], CollabFCATree.prototype, "result", 2);
__decorateClass([
  query("#selModels")
], CollabFCATree.prototype, "selModels", 2);
__decorateClass([
  property({ reflect: true })
], CollabFCATree.prototype, "prompts", 2);
__decorateClass([
  property({ reflect: true })
], CollabFCATree.prototype, "inputs", 2);
__decorateClass([
  property({ reflect: true })
], CollabFCATree.prototype, "user", 2);
__decorateClass([
  property({ reflect: true })
], CollabFCATree.prototype, "inLoader", 2);
CollabFCATree = __decorateClass([
  customElement("ai-agent-custom-100554")
], CollabFCATree);
export {
  CollabFCATree
};
