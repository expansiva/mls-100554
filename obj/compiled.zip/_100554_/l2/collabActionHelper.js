/// <mls fileReference="_100554_/l2/collabActionHelper.ts" enhancement="_100554_enhancementLit" />
export const ambient = "";
export async function callBackend(config, req) {
    const response = await fetch('/api/bridge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ module: config.module, organism: config.organism, action: config.action, req })
    });
    if (!response.ok)
        throw new Error('Backend error');
    return response.json();
}
export function getExecutionContext() {
    return {
        user: {
            userId: "123",
            name: "John",
            rules: ["admin"]
        },
        authority: [],
        tenantId: "xyz",
        io: {},
        correlationId: Math.random().toString(36)
    };
}
const TRACE_LIMIT = 100;
export function addOrganismTrace(trace) {
    let win = window;
    if (win.parent)
        win = win.parent;
    if (!win.traceOrganism)
        win.traceOrganism = [];
    win.traceOrganism.push(trace);
    if (win.traceOrganism.length > TRACE_LIMIT) {
        win.traceOrganism = win.traceOrganism.slice(-TRACE_LIMIT);
    }
}
export function getOrganismTraces() {
    let win = window;
    if (win.parent)
        win = win.parent;
    return win.traceOrganism || [];
}
function genId() {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 8)}`;
}
export async function traceOrganismAction(config, req, exec) {
    const start = performance.now();
    const ctx = getExecutionContext();
    let status = "ok";
    let details;
    try {
        const result = await exec(ctx);
        return result;
    }
    catch (err) {
        status = "error";
        details = err;
        throw err;
    }
    finally {
        const duration = performance.now() - start;
        addOrganismTrace({
            traceId: genId(),
            correlationId: ctx.correlationId,
            layer: "organism",
            module: config.module,
            origem: config.organism,
            action: config.action,
            result: "Action executed",
            status,
            details,
            durationMs: duration,
            timestamp: new Date().toISOString()
        });
    }
}
export function withInstrumentation(meta, handler) {
    return (req) => traceOrganismAction(meta, req, (ctx) => handler(req, ctx));
}
export function CollabAction(meta, handler) {
    return withInstrumentation(meta, handler);
}
