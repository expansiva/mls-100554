/// <mls fileReference="_100554_/l2/pluginExamplesIndex.ts" enhancement="_100554_/l2/enhancementLit" />
import { PluginBaseIndex } from '/_100554_/l2/pluginBaseIndex.js';
export class PluginExamplesIndex extends PluginBaseIndex {
    getMenus() {
        return [
            {
                category: 'Examples 1',
                scope: ['l6Dashboard'],
                priority: 1,
                auth: ['admin', 'editor'],
                widget: '_100554_pluginSiteMonitorDashboardErrors'
            },
            {
                category: 'Examples 1',
                scope: ['l6Dashboard'],
                auth: ['admin', 'editor'],
                widget: '_100554_pluginSiteMonitorDashboardActiveUsers'
            },
            {
                category: 'Examples 1',
                scope: ['l6Dashboard'],
                auth: ['admin', 'editor'],
                widget: '_100554_pluginSiteMonitorDashboardExpenses'
            },
            {
                category: 'Examples 1',
                scope: ['l6Dashboard'],
                auth: ['admin', 'author'],
                widget: '_100554_pluginSiteMonitorDashboardRegionalLatency'
            },
            {
                category: 'Examples 1',
                scope: ['l6Dashboard'],
                auth: ['admin', 'author'],
                widget: '_100554_pluginSiteMonitorDashboardResponseTime'
            },
            {
                category: 'Examples 1',
                scope: ['l6Dashboard'],
                auth: ['admin', 'author'],
                widget: '_100554_pluginSiteMonitorDashboardSales'
            },
            {
                category: 'Examples 2',
                scope: ['l6Dashboard'],
                auth: ['admin', 'author'],
                widget: '_100554_pluginSiteMonitorDashboardRegionalLatency'
            },
            {
                category: 'Examples 2',
                scope: ['l6Dashboard'],
                auth: ['admin', 'author'],
                widget: '_100554_pluginSiteMonitorDashboardResponseTime'
            },
            {
                category: 'Examples 2',
                scope: ['l6Dashboard'],
                auth: ['admin', 'author'],
                widget: '_100554_pluginSiteMonitorDashboardSales'
            },
            {
                category: 'Examples 2',
                scope: ['l6Dashboard'],
                auth: ['admin', 'author'],
                widget: '_100554_pluginSiteMonitorDashboardSpikes'
            },
        ];
    }
    getHooks() {
        return [];
    }
    getServices() {
        return [];
    }
}
export default new PluginExamplesIndex();
