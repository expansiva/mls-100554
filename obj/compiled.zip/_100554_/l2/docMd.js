/// <mls fileReference="_100554_/l2/docMd.ts" enhancement="_100554_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let DocMd = class DocMd extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`doc-md-100554 {
  display: block;
}
doc-md-100554 .preview {
  font-family: system-ui, sans-serif;
  font-size: 15px;
  line-height: 1.7;
  color: #1a1a1a;
}
doc-md-100554 .preview h1,
doc-md-100554 .preview h2,
doc-md-100554 .preview h3,
doc-md-100554 .preview h4,
doc-md-100554 .preview h5,
doc-md-100554 .preview h6 {
  margin: 1.2em 0 0.4em;
  font-weight: 600;
  line-height: 1.3;
}
doc-md-100554 .preview h1 {
  font-size: 2em;
  border-bottom: 2px solid #e5e7eb;
  padding-bottom: 0.3em;
}
doc-md-100554 .preview h2 {
  font-size: 1.5em;
  border-bottom: 1px solid #e5e7eb;
  padding-bottom: 0.2em;
}
doc-md-100554 .preview h3 {
  font-size: 1.25em;
}
doc-md-100554 .preview h4 {
  font-size: 1.1em;
}
doc-md-100554 .preview p {
  margin: 0.6em 0;
}
doc-md-100554 .preview strong {
  font-weight: 700;
}
doc-md-100554 .preview em {
  font-style: italic;
}
doc-md-100554 .preview del {
  text-decoration: line-through;
  color: #6b7280;
}
doc-md-100554 .preview a {
  color: #2563eb;
  text-decoration: none;
}
doc-md-100554 .preview a:hover {
  text-decoration: underline;
}
doc-md-100554 .preview ul,
doc-md-100554 .preview ol {
  margin: 0.6em 0;
  padding-left: 1.5em;
}
doc-md-100554 .preview li {
  margin: 0.2em 0;
}
doc-md-100554 .preview blockquote {
  margin: 0.8em 0;
  padding: 0.6em 1em;
  border-left: 4px solid #6366f1;
  background: #f5f3ff;
  color: #4b5563;
  border-radius: 0 6px 6px 0;
}
doc-md-100554 .preview blockquote p {
  margin: 0;
}
doc-md-100554 .preview code {
  font-family: 'Fira Code', 'Cascadia Code', monospace;
  font-size: 0.875em;
  background: #f3f4f6;
  padding: 0.15em 0.4em;
  border-radius: 4px;
  color: #d946ef;
}
doc-md-100554 .preview pre {
  background: #1e1e2e;
  color: #cdd6f4;
  border-radius: 8px;
  padding: 1em 1.2em;
  overflow-x: auto;
  margin: 0.8em 0;
}
doc-md-100554 .preview pre code {
  background: none;
  color: inherit;
  padding: 0;
  font-size: 0.9em;
}
doc-md-100554 .preview table {
  border-collapse: collapse;
  width: 100%;
  margin: 0.8em 0;
  font-size: 0.95em;
}
doc-md-100554 .preview th,
doc-md-100554 .preview td {
  border: 1px solid #e5e7eb;
  padding: 0.5em 0.8em;
  text-align: left;
}
doc-md-100554 .preview th {
  background: #f9fafb;
  font-weight: 600;
}
doc-md-100554 .preview tr:nth-child(even) td {
  background: #f9fafb;
}
doc-md-100554 .preview hr {
  border: none;
  border-top: 2px solid #e5e7eb;
  margin: 1.2em 0;
}
doc-md-100554 .preview img {
  max-width: 100%;
  border-radius: 6px;
}
doc-md-100554 .preview input[type='checkbox'] {
  margin-right: 0.4em;
  accent-color: #6366f1;
}
`);
        this._html = '';
    }
    connectedCallback() {
        this.oriHtml = this.innerHTML;
        this.innerHTML = '';
        super.connectedCallback();
    }
    firstUpdated() {
        this.init();
    }
    render() {
        console.info(this._html);
        return html `
            <div class="preview">${unsafeHTML(this._html)}</div>

        `;
    }
    async _importMarked() {
        const url = 'https://cdn.jsdelivr.net/npm/marked@17.0.4/lib/marked.esm.js';
        const mod = await import(url);
        this._marked = mod.marked;
    }
    async _parse() {
        if (!this._marked)
            return;
        this.style.display = '';
        this._html = await this._marked(this.oriHtml);
    }
    async init() {
        await this._importMarked();
        this._parse();
    }
};
__decorate([
    state()
], DocMd.prototype, "_html", void 0);
DocMd = __decorate([
    customElement('doc-md-100554')
], DocMd);
export { DocMd };
