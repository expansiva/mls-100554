/// <mls fileReference="_100554_/l2/docMd.ts" enhancement="_100554_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, unsafeHTML } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let DocMd = class DocMd extends CollabLitElement {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`doc-md-100554 {
  display: block;
}
doc-md-100554.stl1 {
  --font-sans: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  --font-mono: "JetBrains Mono", "Fira Code", "Cascadia Code", monospace;
  --color-bg: #ffffff;
  --color-bg-secondary: #f7f7f5;
  --color-bg-tertiary: #f0efed;
  --color-bg-code: #f4f3f1;
  --color-bg-warning: #faeeda;
  --color-bg-info: #e6f1fb;
  --color-text: #1a1a18;
  --color-text-secondary: #5a5a56;
  --color-text-tertiary: #9a9a94;
  --color-border: rgba(0, 0, 0, 0.09);
  --color-border-strong: rgba(0, 0, 0, 0.15);
  --color-accent: #c96442;
  --radius-sm: 5px;
  --radius-md: 8px;
  --radius-lg: 12px;
}
@media (prefers-color-scheme: dark) {
  doc-md-100554.stl1 :root {
    --color-bg: #1a1a18;
    --color-bg-secondary: #222220;
    --color-bg-tertiary: #2a2a28;
    --color-bg-code: #252523;
    --color-text: #e8e8e4;
    --color-text-secondary: #a0a09a;
    --color-text-tertiary: #6a6a64;
    --color-border: rgba(255, 255, 255, 0.07);
    --color-border-strong: rgba(255, 255, 255, 0.13);
    --color-accent: #e07a5a;
  }
}
doc-md-100554.stl1 *,
doc-md-100554.stl1 *::before,
doc-md-100554.stl1 *::after {
  box-sizing: border-box;
}
doc-md-100554.stl1 body {
  background: var(--color-bg);
  color: var(--color-text);
  font-family: var(--font-sans);
  font-size: 16px;
  font-weight: 400;
  line-height: 1.75;
  -webkit-font-smoothing: antialiased;
  margin: 0;
  padding: 0;
}
doc-md-100554.stl1 article {
  max-width: 680px;
  margin: 0 auto;
  padding: 3rem 1.75rem 6rem;
}
doc-md-100554.stl1 h1,
doc-md-100554.stl1 h2,
doc-md-100554.stl1 h3,
doc-md-100554.stl1 h4,
doc-md-100554.stl1 h5,
doc-md-100554.stl1 h6 {
  font-family: var(--font-sans);
  font-weight: 500;
  line-height: 1.3;
  color: var(--color-text);
  margin: 2.2rem 0 0.65rem;
}
doc-md-100554.stl1 h1 {
  font-size: 2rem;
  letter-spacing: -0.025em;
  margin-top: 0;
  margin-bottom: 1.5rem;
  background: linear-gradient(130deg, var(--color-text) 50%, var(--color-text-secondary) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
}
doc-md-100554.stl1 h1::after {
  content: '';
  display: block;
  margin-top: 0.55rem;
  width: 2.2rem;
  height: 2.5px;
  background: var(--color-accent);
  border-radius: 99px;
}
doc-md-100554.stl1 h2 {
  font-size: 1.15rem;
  padding: 0.5rem 1rem;
  background: var(--color-bg-secondary);
  border-left: 2.5px solid var(--color-accent);
  border-radius: 0 var(--radius-md) var(--radius-md) 0;
  margin-top: 2.8rem;
}
doc-md-100554.stl1 h3 {
  font-size: 1.05rem;
}
doc-md-100554.stl1 h3::before {
  content: '# ';
  color: var(--color-accent);
  font-weight: 400;
  font-size: 0.9em;
  opacity: 0.8;
}
doc-md-100554.stl1 h4 {
  font-size: 1rem;
  color: var(--color-text-secondary);
}
doc-md-100554.stl1 h5,
doc-md-100554.stl1 h6 {
  font-size: 0.78rem;
  color: var(--color-text-tertiary);
  text-transform: uppercase;
  letter-spacing: 0.09em;
}
doc-md-100554.stl1 p {
  margin: 0 0 1rem;
}
doc-md-100554.stl1 a {
  color: #185fa5;
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-thickness: 0.5px;
}
@media (prefers-color-scheme: dark) {
  doc-md-100554.stl1 a {
    color: #85b7eb;
  }
}
doc-md-100554.stl1 a:hover {
  opacity: 0.72;
}
doc-md-100554.stl1 strong {
  font-weight: 500;
}
doc-md-100554.stl1 em {
  font-style: italic;
  color: var(--color-text-secondary);
}
doc-md-100554.stl1 code {
  font-family: var(--font-mono);
  font-size: 0.84em;
  background: var(--color-bg-code);
  color: var(--color-accent);
  padding: 0.15em 0.42em;
  border-radius: var(--radius-sm);
  border: 0.5px solid var(--color-border-strong);
}
doc-md-100554.stl1 pre {
  background: var(--color-bg-secondary);
  border: 0.5px solid var(--color-border-strong);
  border-radius: var(--radius-lg);
  padding: 1.25rem 1.4rem;
  overflow-x: auto;
  margin: 1.25rem 0;
  line-height: 1.65;
  position: relative;
}
doc-md-100554.stl1 pre::before {
  content: '';
  position: absolute;
  top: 14px;
  left: 14px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #ff5f57;
  box-shadow: 14px 0 0 #febc2e, 28px 0 0 #28c840;
  opacity: 0.6;
}
doc-md-100554.stl1 pre code {
  background: none;
  border: none;
  padding: 0;
  font-size: 0.875rem;
  color: var(--color-text);
  display: block;
  margin-top: 1.1rem;
}
doc-md-100554.stl1 blockquote {
  margin: 1.25rem 0;
  padding: 0.85rem 1.25rem;
  border-left: 2.5px solid var(--color-accent);
  background: var(--color-bg-secondary);
  border-radius: 0 var(--radius-md) var(--radius-md) 0;
  color: var(--color-text-secondary);
  font-style: italic;
}
doc-md-100554.stl1 blockquote blockquote {
  margin: 0.5rem 0 0;
  background: var(--color-bg-tertiary);
}
doc-md-100554.stl1 blockquote p {
  margin: 0;
}
doc-md-100554.stl1 ul,
doc-md-100554.stl1 ol {
  padding-left: 1.4rem;
  margin: 0.25rem 0 1rem;
}
doc-md-100554.stl1 li {
  margin: 0.22rem 0;
  line-height: 1.7;
}
doc-md-100554.stl1 ul li::marker {
  color: var(--color-accent);
  content: "– ";
}
doc-md-100554.stl1 ol li::marker {
  color: var(--color-text-tertiary);
  font-size: 0.9em;
}
doc-md-100554.stl1 li > ul,
doc-md-100554.stl1 li > ol {
  margin: 0.15rem 0;
}
doc-md-100554.stl1 hr {
  border: none;
  border-top: 0.5px solid var(--color-border-strong);
  margin: 2rem 0;
}
doc-md-100554.stl1 img {
  max-width: 100%;
  height: auto;
  border-radius: var(--radius-lg);
  border: 0.5px solid var(--color-border);
  display: block;
  margin: 1.25rem 0;
}
doc-md-100554.stl1 .table-wrap {
  overflow-x: auto;
  margin: 1.5rem 0;
  border-radius: var(--radius-lg);
  border: 0.5px solid var(--color-border-strong);
}
doc-md-100554.stl1 table {
  width: 100%;
  border-collapse: collapse;
  font-size: 0.9rem;
}
doc-md-100554.stl1 thead {
  background: var(--color-bg-tertiary);
}
doc-md-100554.stl1 thead tr {
  border-bottom: 1px solid var(--color-border-strong);
}
doc-md-100554.stl1 th {
  font-weight: 500;
  font-size: 0.72rem;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  color: var(--color-text-tertiary);
  padding: 0.7rem 1.2rem;
  text-align: left;
  white-space: nowrap;
}
doc-md-100554.stl1 td {
  padding: 0.65rem 1.2rem;
  border-bottom: 0.5px solid var(--color-border);
  vertical-align: top;
}
doc-md-100554.stl1 td:first-child {
  font-weight: 500;
}
doc-md-100554.stl1 tbody tr:last-child td {
  border-bottom: none;
}
doc-md-100554.stl1 tbody tr:hover td {
  background: var(--color-bg-secondary);
}
doc-md-100554.stl1 ::selection {
  background: rgba(55, 138, 221, 0.18);
}
doc-md-100554.stl1 ::-webkit-scrollbar {
  width: 5px;
  height: 5px;
}
doc-md-100554.stl1 ::-webkit-scrollbar-track {
  background: transparent;
}
doc-md-100554.stl1 ::-webkit-scrollbar-thumb {
  background: var(--color-border-strong);
  border-radius: 99px;
}
doc-md-100554.stl2 {
  font-family: system-ui, sans-serif;
  font-size: 15px;
  line-height: 1.7;
  color: #1a1a1a;
}
doc-md-100554.stl2 h1,
doc-md-100554.stl2 h2,
doc-md-100554.stl2 h3,
doc-md-100554.stl2 h4,
doc-md-100554.stl2 h5,
doc-md-100554.stl2 h6 {
  margin: 1.2em 0 0.4em;
  font-weight: 600;
  line-height: 1.3;
}
doc-md-100554.stl2 h1 {
  font-size: 2em;
  border-bottom: 2px solid #e5e7eb;
  padding-bottom: 0.3em;
}
doc-md-100554.stl2 h2 {
  font-size: 1.5em;
  border-bottom: 1px solid #e5e7eb;
  padding-bottom: 0.2em;
}
doc-md-100554.stl2 h3 {
  font-size: 1.25em;
}
doc-md-100554.stl2 h4 {
  font-size: 1.1em;
}
doc-md-100554.stl2 p {
  margin: 0.6em 0;
}
doc-md-100554.stl2 strong {
  font-weight: 700;
}
doc-md-100554.stl2 em {
  font-style: italic;
}
doc-md-100554.stl2 del {
  text-decoration: line-through;
  color: #6b7280;
}
doc-md-100554.stl2 a {
  color: #2563eb;
  text-decoration: none;
}
doc-md-100554.stl2 a:hover {
  text-decoration: underline;
}
doc-md-100554.stl2 ul,
doc-md-100554.stl2 ol {
  margin: 0.6em 0;
  padding-left: 1.5em;
}
doc-md-100554.stl2 li {
  margin: 0.2em 0;
}
doc-md-100554.stl2 blockquote {
  margin: 0.8em 0;
  padding: 0.6em 1em;
  border-left: 4px solid #6366f1;
  background: #f5f3ff;
  color: #4b5563;
  border-radius: 0 6px 6px 0;
}
doc-md-100554.stl2 blockquote p {
  margin: 0;
}
doc-md-100554.stl2 code {
  font-family: 'Fira Code', 'Cascadia Code', monospace;
  font-size: 0.875em;
  background: #f3f4f6;
  padding: 0.15em 0.4em;
  border-radius: 4px;
  color: #d946ef;
}
doc-md-100554.stl2 pre {
  background: #1e1e2e;
  color: #cdd6f4;
  border-radius: 8px;
  padding: 1em 1.2em;
  overflow-x: auto;
  margin: 0.8em 0;
}
doc-md-100554.stl2 pre code {
  background: none;
  color: inherit;
  padding: 0;
  font-size: 0.9em;
}
doc-md-100554.stl2 table {
  border-collapse: collapse;
  width: 100%;
  margin: 0.8em 0;
  font-size: 0.95em;
}
doc-md-100554.stl2 th,
doc-md-100554.stl2 td {
  border: 1px solid #e5e7eb;
  padding: 0.5em 0.8em;
  text-align: left;
}
doc-md-100554.stl2 th {
  background: #f9fafb;
  font-weight: 600;
}
doc-md-100554.stl2 tr:nth-child(even) td {
  background: #f9fafb;
}
doc-md-100554.stl2 hr {
  border: none;
  border-top: 2px solid #e5e7eb;
  margin: 1.2em 0;
}
doc-md-100554.stl2 img {
  max-width: 100%;
  border-radius: 6px;
}
doc-md-100554.stl2 input[type='checkbox'] {
  margin-right: 0.4em;
  accent-color: #6366f1;
}
doc-md-100554.stl3 html,
doc-md-100554.stl3 body,
doc-md-100554.stl3 div,
doc-md-100554.stl3 span,
doc-md-100554.stl3 applet,
doc-md-100554.stl3 object,
doc-md-100554.stl3 iframe,
doc-md-100554.stl3 h1,
doc-md-100554.stl3 h2,
doc-md-100554.stl3 h3,
doc-md-100554.stl3 h4,
doc-md-100554.stl3 h5,
doc-md-100554.stl3 h6,
doc-md-100554.stl3 p,
doc-md-100554.stl3 blockquote,
doc-md-100554.stl3 pre,
doc-md-100554.stl3 a,
doc-md-100554.stl3 abbr,
doc-md-100554.stl3 acronym,
doc-md-100554.stl3 address,
doc-md-100554.stl3 big,
doc-md-100554.stl3 cite,
doc-md-100554.stl3 code,
doc-md-100554.stl3 del,
doc-md-100554.stl3 dfn,
doc-md-100554.stl3 em,
doc-md-100554.stl3 img,
doc-md-100554.stl3 ins,
doc-md-100554.stl3 kbd,
doc-md-100554.stl3 q,
doc-md-100554.stl3 s,
doc-md-100554.stl3 samp,
doc-md-100554.stl3 small,
doc-md-100554.stl3 strike,
doc-md-100554.stl3 strong,
doc-md-100554.stl3 sub,
doc-md-100554.stl3 sup,
doc-md-100554.stl3 tt,
doc-md-100554.stl3 var,
doc-md-100554.stl3 b,
doc-md-100554.stl3 u,
doc-md-100554.stl3 i,
doc-md-100554.stl3 center,
doc-md-100554.stl3 dl,
doc-md-100554.stl3 dt,
doc-md-100554.stl3 dd,
doc-md-100554.stl3 ol,
doc-md-100554.stl3 ul,
doc-md-100554.stl3 li,
doc-md-100554.stl3 fieldset,
doc-md-100554.stl3 form,
doc-md-100554.stl3 label,
doc-md-100554.stl3 legend,
doc-md-100554.stl3 table,
doc-md-100554.stl3 caption,
doc-md-100554.stl3 tbody,
doc-md-100554.stl3 tfoot,
doc-md-100554.stl3 thead,
doc-md-100554.stl3 tr,
doc-md-100554.stl3 th,
doc-md-100554.stl3 td,
doc-md-100554.stl3 article,
doc-md-100554.stl3 aside,
doc-md-100554.stl3 canvas,
doc-md-100554.stl3 details,
doc-md-100554.stl3 embed,
doc-md-100554.stl3 figure,
doc-md-100554.stl3 figcaption,
doc-md-100554.stl3 footer,
doc-md-100554.stl3 header,
doc-md-100554.stl3 hgroup,
doc-md-100554.stl3 menu,
doc-md-100554.stl3 nav,
doc-md-100554.stl3 output,
doc-md-100554.stl3 ruby,
doc-md-100554.stl3 section,
doc-md-100554.stl3 summary,
doc-md-100554.stl3 time,
doc-md-100554.stl3 mark,
doc-md-100554.stl3 audio,
doc-md-100554.stl3 video {
  margin: 0;
  padding: 0;
  border: 0;
  font: inherit;
  font-size: 100%;
  vertical-align: baseline;
}
doc-md-100554.stl3 html {
  line-height: 1;
}
doc-md-100554.stl3 ol,
doc-md-100554.stl3 ul {
  list-style: none;
}
doc-md-100554.stl3 table {
  border-collapse: collapse;
  border-spacing: 0;
}
doc-md-100554.stl3 caption,
doc-md-100554.stl3 th,
doc-md-100554.stl3 td {
  text-align: left;
  font-weight: normal;
  vertical-align: middle;
}
doc-md-100554.stl3 q,
doc-md-100554.stl3 blockquote {
  quotes: none;
}
doc-md-100554.stl3 q:before,
doc-md-100554.stl3 q:after,
doc-md-100554.stl3 blockquote:before,
doc-md-100554.stl3 blockquote:after {
  content: "";
  content: none;
}
doc-md-100554.stl3 a img {
  border: none;
}
doc-md-100554.stl3 article,
doc-md-100554.stl3 aside,
doc-md-100554.stl3 details,
doc-md-100554.stl3 figcaption,
doc-md-100554.stl3 figure,
doc-md-100554.stl3 footer,
doc-md-100554.stl3 header,
doc-md-100554.stl3 hgroup,
doc-md-100554.stl3 main,
doc-md-100554.stl3 menu,
doc-md-100554.stl3 nav,
doc-md-100554.stl3 section,
doc-md-100554.stl3 summary {
  display: block;
}
doc-md-100554.stl3 * {
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
doc-md-100554.stl3 html {
  font-size: 16px;
  line-height: 1.6em;
  -webkit-text-size-adjust: 100%;
}
doc-md-100554.stl3 body {
  background-color: #fff;
  color: #545454;
  font-family: "Raleway", sans-serif;
  text-rendering: optimizeLegibility;
  max-width: 46em;
  margin: 2em auto;
  padding: 1.6em 3.15em;
}
doc-md-100554.stl3 h1 {
  font-family: "Raleway", sans-serif;
  font-weight: 700;
  color: #333;
  font-size: 1.6em;
  line-height: 1.3em;
  margin-bottom: 0.78571em;
}
doc-md-100554.stl3 h2 {
  font-family: "Raleway", sans-serif;
  font-weight: 600;
  color: #333;
  font-size: 1.3em;
  line-height: 1em;
  margin-top: 2em;
  margin-bottom: 0.6em;
}
doc-md-100554.stl3 h3 {
  font-family: "Raleway", sans-serif;
  font-weight: 600;
  color: #333;
  font-size: 1.15em;
  line-height: 1em;
  margin-top: 1em;
  margin-bottom: 0.6em;
}
doc-md-100554.stl3 h4 {
  font-family: "Raleway", sans-serif;
  font-weight: 500;
  color: #333;
  font-size: 1em;
  line-height: 1em;
  margin-top: 1em;
  margin-bottom: 0.6em;
}
doc-md-100554.stl3 p {
  margin-bottom: 1.57143em;
  hyphens: auto;
}
doc-md-100554.stl3 b,
doc-md-100554.stl3 strong {
  font-family: "Raleway", sans-serif;
  font-weight: 700;
}
doc-md-100554.stl3 i,
doc-md-100554.stl3 em {
  font-family: "Raleway", sans-serif;
  font-style: italic;
}
doc-md-100554.stl3 u {
  text-decoration: none;
  background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0) 50%, #e06e73 50%);
  background-repeat: repeat-x;
  background-size: 2px 2px;
  background-position: 0 1.05em;
}
doc-md-100554.stl3 s {
  color: #878787;
}
doc-md-100554.stl3 a {
  color: #e74c3c;
  text-decoration: none;
}
doc-md-100554.stl3 img {
  max-width: 100%;
  height: auto;
}
doc-md-100554.stl3 blockquote {
  display: block;
  margin-left: -1em;
  padding-left: 0.8em;
  border-left: 0.2em solid #e74c3c;
  background-color: transparent;
}
doc-md-100554.stl3 hr {
  height: 1px;
  border: 0;
  background-color: #dedede;
  margin: 0.7em auto 0.7em;
}
doc-md-100554.stl3 ul li {
  text-indent: -0.45em;
}
doc-md-100554.stl3 ul li:before {
  content: "•";
  color: #e74c3c;
  display: inline-block;
  margin-right: 0.3em;
  font-size: 1.5em;
  vertical-align: middle;
}
doc-md-100554.stl3 ul ul {
  margin-left: 1.25714em;
}
doc-md-100554.stl3 ol li {
  text-indent: -1.45em;
}
doc-md-100554.stl3 ol ol {
  margin-left: 1.25714em;
}
doc-md-100554.stl3 ul,
doc-md-100554.stl3 ol {
  margin-bottom: 1.5em;
}
doc-md-100554.stl3 ul ul,
doc-md-100554.stl3 ul ol,
doc-md-100554.stl3 ol ul,
doc-md-100554.stl3 ol ol {
  margin-bottom: 0;
}
doc-md-100554.stl3 ol {
  counter-reset: ol;
}
doc-md-100554.stl3 ol li {
  counter-increment: ol;
}
doc-md-100554.stl3 ol li:before {
  content: counter(ol) ".";
  color: #e06e73;
  text-align: right;
  display: inline-block;
  min-width: 1em;
  margin-right: 0.5em;
}
doc-md-100554.stl3 ol li p {
  display: inline;
}
doc-md-100554.stl3 code {
  display: inline;
  background: #fcfcfc;
  border: 1px solid #dedede;
  border-radius: 0.3em;
  padding: 0.2em 0.5em;
  font-family: "Fira Code Retina", monospace;
  font-size: 0.7em;
}
doc-md-100554.stl3 pre {
  display: block;
  background: transparent;
  padding: 0;
  margin: 0;
}
doc-md-100554.stl3 pre code {
  display: block;
  width: 100%;
  line-height: 1.45em;
  padding: 1.2em 1em;
  margin: 0 0 1.5em;
}
doc-md-100554.stl3 .hljs {
  padding: 0;
}
doc-md-100554.stl3 input[type="checkbox"] {
  position: relative;
  width: 1rem;
  height: 1rem;
  background: white;
  -webkit-appearance: none;
  border: 1px solid #ccc;
  border-radius: 0.2em;
  margin: 0.2em 0.5em 0em -1.7em;
  margin-bottom: 0.5em;
  display: block;
  float: left;
  page-break-after: avoid;
}
doc-md-100554.stl3 input[type="checkbox"]:checked::before {
  display: block;
  content: '✓';
  display: initial;
  font-size: 1.1em;
  font-weight: bold;
  color: #e06e73;
  position: absolute;
  left: 0.1em;
  bottom: -0.2em;
}
doc-md-100554.stl3 input[type="checkbox"] ~ label {
  display: block;
  width: 100%;
  margin-bottom: 0.1em;
}
doc-md-100554.stl3 ul li input[type="checkbox"] {
  font: none;
}
doc-md-100554.stl3 ul li input[type="checkbox"] ~ label {
  display: inline-block;
  width: auto;
  margin-bottom: 0.1em;
  margin-left: 0.5em;
}
doc-md-100554.stl3 table {
  width: calc(100% + 3em);
  margin-bottom: 1.5em;
  margin-left: -1.5em;
}
doc-md-100554.stl3 table tr {
  border-bottom: 1px solid #dedede;
}
doc-md-100554.stl3 table th {
  font-weight: 700;
}
doc-md-100554.stl3 table td,
doc-md-100554.stl3 table th {
  vertical-align: top;
  padding: 0.2em 1.5em;
  font-size: 0.95em;
}
doc-md-100554.stl3 thead tr {
  border-bottom: 4px double #dedede;
}
`);
    }
    _html = '';
    _marked;
    oriHtml;
    connectedCallback() {
        this.oriHtml = this.innerHTML;
        this.innerHTML = '';
        super.connectedCallback();
    }
    firstUpdated() {
        this.init();
    }
    render() {
        return html `
            <div class="preview">${unsafeHTML(this._html)}</div>

        `;
    }
    async _importMarked() {
        const url = 'https://cdn.jsdelivr.net/npm/marked@17.0.4/lib/marked.esm.js';
        const mod = await import(url);
        this._marked = mod.marked;
    }
    async _parse() {
        if (!this._marked)
            return;
        this.style.display = '';
        this._html = await this._marked(this.oriHtml);
    }
    async init() {
        await this._importMarked();
        this._parse();
    }
};
__decorate([
    state()
], DocMd.prototype, "_html", void 0);
DocMd = __decorate([
    customElement('doc-md-100554')
], DocMd);
export { DocMd };
