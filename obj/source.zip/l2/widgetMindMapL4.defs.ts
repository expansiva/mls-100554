/// <mls fileReference="_100554_/l2/widgetMindMapL4.defs.ts" enhancement="_blank" />

// Do not change – automatically generated code. 

export const asis: mls.defs.AsIs = {
  "meta": {
    "fileReference": "_100554_/l2/widgetMindMapL4.ts",
    "componentType": "molecule",
    "componentScope": "appFrontEnd",
    "group": "enhancement"
  },
  "references": {
    "imports": [
      {
        "ref": "lit",
        "dependencies": [
          {
            "name": "html"
          }
        ]
      },
      {
        "ref": "lit/decorators.js",
        "dependencies": [
          {
            "name": "customElement"
          },
          {
            "name": "property"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/collabDecorators.js",
        "dependencies": [
          {
            "name": "propertyDataSource"
          },
          {
            "name": "propertyCompositeDataSource"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/stateLitElement.js",
        "dependencies": [
          {
            "name": "StateLitElement"
          }
        ]
      },
      {
        "ref": "mls.stor.IFileInfo",
        "dependencies": [
          {
            "name": "IFileInfo"
          }
        ]
      },
      {
        "ref": "mls.editor.ModelType",
        "dependencies": [
          {
            "name": "ModelType"
          }
        ]
      }
    ],
    "statesRO": [
      "db.product.name",
      "db.product",
      "db"
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Canvas-based mind map widget for project visualization",
      "businessCapabilities": [],
      "technicalCapabilities": [],
      "implementedFeatures": []
    }
  }
}
    