/// <mls fileReference="_100554_/l2/pluginStyleColumn.defs.ts" enhancement="_blank" />

// Do not change – automatically generated code. 

export const asis: mls.defs.AsIs = {
  "meta": {
    "fileReference": "_100554_/l2/pluginStyleColumn.ts",
    "componentType": "pluginUI",
    "componentScope": "appFrontEnd",
    "languages": [
      "en",
      "pt"
    ],
    "group": "enhancement"
  },
  "references": {
    "webComponents": [
      "collab-ds-input-select-color-100554",
      "collab-ds-input-range-100554"
    ],
    "imports": [
      {
        "ref": "lit",
        "dependencies": [
          {
            "name": "html",
            "type": "function"
          },
          {
            "name": "repeat",
            "type": "function"
          }
        ]
      },
      {
        "ref": "lit/decorators.js",
        "dependencies": [
          {
            "name": "customElement",
            "type": "?",
            "purpose": "decorator"
          },
          {
            "name": "property",
            "type": "?",
            "purpose": "decorator"
          },
          {
            "name": "queryAll",
            "type": "?",
            "purpose": "decorator"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/stateLitElement.js",
        "dependencies": [
          {
            "name": "StateLitElement",
            "type": "class"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/collabDecorators.js",
        "dependencies": [
          {
            "name": "propertyDataSource",
            "type": "?",
            "purpose": "decorator"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/collabState.js",
        "dependencies": [
          {
            "name": "getState",
            "type": "function"
          },
          {
            "name": "setState",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/collabLitElement.js",
        "dependencies": [
          {
            "name": "getMessageKey",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/collabDsInputSelectColor.js",
        "dependencies": [
          {
            "name": "CollabDsInputSelectColor",
            "type": "class"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/lessCSS.js",
        "dependencies": [
          {
            "name": "ICSSState",
            "type": "interface"
          }
        ]
      },
      {
        "ref": "/_102027_/l2/libCommom.js",
        "dependencies": [
          {
            "name": "convertColorToHex",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/collabDsInputSelectColor.js"
      },
      {
        "ref": "/_100554_/l2/collabDsInputRange.js"
      },
      {
        "ref": "/_100554_/l2/collabDsInputSelectColor.js"
      },
      {
        "ref": "/_100554_/l2/collabDsInputRange.js"
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "This plugin allows for easy and efficient creation and adjustment of text columns. It lets you set the number of columns, spacing between them, and other formatting details, providing an organized layout and enhancing readability.",
      "businessCapabilities": [
        "create and adjust text columns",
        "define the number of columns",
        "set spacing between columns",
        "adjust formatting details"
      ],
      "technicalCapabilities": [
        "uses Lit library",
        "custom element",
        "state management",
        "CSS manipulation"
      ],
      "implementedFeatures": [
        "columnsCount",
        "columnsWidth",
        "columnsGap",
        "columnsRule",
        "columnSpan",
        "breakInside"
      ]
    }
  }
}
    