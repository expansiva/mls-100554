/// <mls fileReference="_100554_/l2/widgetEmbedsSocialMedia.defs.ts" enhancement="_blank" />

// Do not change – automatically generated code. 

export const asis: mls.defs.AsIs = {
  "meta": {
    "fileReference": "_100554_/l2/widgetEmbedsSocialMedia.ts",
    "componentType": "molecule",
    "componentScope": "appFrontEnd",
    "group": "enhancement"
  },
  "references": {
    "webComponents": [
      "widget-embeds-social-media-100554"
    ],
    "imports": [
      {
        "ref": "lit",
        "dependencies": [
          {
            "name": "html",
            "type": "function"
          },
          {
            "name": "css",
            "type": "function"
          },
          {
            "name": "LitElement",
            "type": "class"
          }
        ]
      },
      {
        "ref": "lit/decorators.js",
        "dependencies": [
          {
            "name": "customElement",
            "type": "function"
          },
          {
            "name": "property",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/collabDecorators.js",
        "dependencies": [
          {
            "name": "propertyDataSource",
            "type": "function"
          },
          {
            "name": "propertyCompositeDataSource",
            "type": "function"
          }
        ]
      },
      {
        "ref": "/_102029_/l2/stateLitElement.js",
        "dependencies": [
          {
            "name": "StateLitElement",
            "type": "class"
          }
        ]
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "Widget for embedding social media content",
      "businessCapabilities": [
        "Embeds YouTube videos",
        "Embeds Twitter tweets"
      ],
      "technicalCapabilities": [
        "Renders iframes for YouTube",
        "Loads Twitter widgets script",
        "Handles URL parsing"
      ],
      "implementedFeatures": [
        "YouTube embed generation",
        "Twitter embed generation"
      ]
    }
  }
}
    