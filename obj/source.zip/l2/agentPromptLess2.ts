/// <mls shortName="agentPromptLess2" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { AgentBase, IAgentBase } from './_100554_iaAgentBase';

export class agentPromptLess2 extends AgentBase implements IAgentBase {

    public task: mls.msg.TaskData | undefined;
    public visibility: 'public' | 'private' = 'private';

    public getPrompt(prompt: string | undefined): mls.msg.IAMessageInputType[] {
        return this.getMyImputs(prompt || '');
    }

    public async afterPrompt(payload: mls.msg.AIPayload[] | null | undefined): Promise<void> {
        return this._afterPrompt(payload);
    }

    //---------IMPLEMENTS-------------

    private async _afterPrompt(payload: mls.msg.AIPayload[] | null | undefined): Promise<void> {

    }

    private getMyImputs(prompt: string): mls.msg.IAMessageInputType[] {

        return [
            {
                type: 'system',
                content: `
Você é responsável por criar os estilos ".less" para a estrutura abaixo.
Use as classes como referência. Estilos devem ser organizados, claros e responsivos. O escopo é local ao componente {component tag}.
`
            },
            {
                type: 'system',
                content: `HTML base (compacto, sem conteúdo):{htmlBase}`
            },
            {
                type: 'system',
                content: `
O less gerado deve inserido dentro da tag do componente.
Tambem é possivel ter variaçoẽs desse less, que deverá ser definido da seguinte forma:

\`\`\` less
{component tag}.[variationName] {{}}
\`\`\` 

Less Atual, com tokens que devem ser utilizados sempre que possível:

\`\`\` less
{component tag}{{}}

//Start Less Tokens
@text-primary-color-lighter: #535353;
@text-primary-color-lighter-hover: #5f5f5f;
@text-primary-color-lighter-focus: #4a4a4a;
@text-primary-color-lighter-disabled: #696969;
@text-primary-color: #403f3f;
@text-primary-color-hover: #4b4a4a;
@text-primary-color-focus: #353434;
@text-primary-color-disabled: #525151;
@text-primary-color-darker: #000000;
@text-primary-color-darker-hover: #1a1a1a;
@text-primary-color-darker-focus: #0d0d0d;
@text-primary-color-darker-disabled: #262626;
@text-secondary-color-lighter: #408EC8;
@text-secondary-color-lighter-hover: #4a9adb;
@text-secondary-color-lighter-focus: #377bb0;
@text-secondary-color-lighter-disabled: #629fd2;
@text-secondary-color: #1C91CD;
@text-secondary-color-hover: #2a9edb;
@text-secondary-color-focus: #1786b7;
@text-secondary-color-disabled: #55b4e1;
@text-secondary-color-darker: #0F6FA9;
@text-secondary-color-darker-hover: #1b7bb5;
@text-secondary-color-darker-focus: #0c6495;
@text-secondary-color-darker-disabled: #3a9ec1;
@bg-primary-color-lighter: #ffffff;
@bg-primary-color-lighter-hover: #f2f2f2;
@bg-primary-color-lighter-focus: #e6e6e6;
@bg-primary-color-lighter-disabled: #d9d9d9;
@bg-primary-color: #ffffff;
@bg-primary-color-hover: #f2f2f2;
@bg-primary-color-focus: #e6e6e6;
@bg-primary-color-disabled: #d9d9d9;
@bg-primary-color-darker: #fafafa;
@bg-primary-color-darker-hover: #f5f5f5;
@bg-primary-color-darker-focus: #eeeeee;
@bg-primary-color-darker-disabled: #e0e0e0;
@bg-secondary-color-lighter: #F9F9F9;
@bg-secondary-color-lighter-hover: #f4f4f4;
@bg-secondary-color-lighter-focus: #efefef;
@bg-secondary-color-lighter-disabled: #eaeaea;
@bg-secondary-color: #E6E6E6;
@bg-secondary-color-hover: #d9d9d9;
@bg-secondary-color-focus: #cccccc;
@bg-secondary-color-disabled: #bfbfbf;
@bg-secondary-color-darker: #C0C0C0;
@bg-secondary-color-darker-hover: #b3b3b3;
@bg-secondary-color-darker-focus: #a6a6a6;
@bg-secondary-color-darker-disabled: #999999;
@grey-color-lighter: #F9FAFB;
@grey-color-light: #F2F2F2;
@grey-color: #E6E6E6;
@grey-color-dark: #D3D3D3;
@grey-color-darker: #C0C0C0;
@error-color: #FF4D4F;
@error-color-hover: #ff6666;
@error-color-focus: #e63e3e;
@error-color-disabled: #ff9999;
@success-color: #52C41A;
@success-color-hover: #66d93f;
@success-color-focus: #4ca610;
@success-color-disabled: #8cd78e;
@warning-color: #FAAD14;
@warning-color-hover: #fbbd34;
@warning-color-focus: #e09a0e;
@warning-color-disabled: #fdd55e;
@info-color: #0a6dc9;
@info-color-hover: #1b7edb;
@info-color-focus: #006ab3;
@info-color-disabled: #66a8e1;
@active-color: #1890FF;
@active-color-hover: #1a99ff;
@active-color-focus: #0e80cc;
@active-color-disabled: #66b3ff;
@link-color: #1890FF;
@link-color-hover: #1a99ff;
@link-color-focus: #0e80cc;
@link-color-disabled: #66b3ff;
@font-base-unit: .25rem;
@font-family-primary: 'Charlie Display', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
@font-family-secondary: serif;
@font-size-12: calc(@font-base-unit * 3);
@font-size-16: calc(@font-base-unit * 4);
@font-size-20: calc(@font-base-unit * 5);
@font-size-24: calc(@font-base-unit * 6);
@font-size-40: calc(@font-base-unit * 10);
@font-size-48: calc(@font-base-unit * 12);
@font-size-64: calc(@font-base-unit * 16);
@line-height-base-unit: 1;
@line-height-small: calc(@line-height-base-unit * 1.1);
@line-height-medium: calc(@line-height-base-unit * 1.3);
@line-height-large: calc(@line-height-base-unit * 1.5);
@font-weight-lighter: 100;
@font-weight-light: 200;
@font-weight-normal: 400;
@font-weight-bold: 700;
@font-weight-bolder: 900;
@breakpoint-small: 544px;
@breakpoint-medium: 768px;
@breakpoint-large: 1012px;
@transition-slow: 0.2s;
@transition-normal: 0.3s;
@transition-fast: 0.5s;
@space-base-unit: 0.25rem;
@space-8: calc(@space-base-unit * 2);
@space-16: calc(@space-base-unit * 4);
@space-24: calc(@space-base-unit * 6);
@space-32: calc(@space-base-unit * 8);
@space-40: calc(@space-base-unit * 10);
@space-48: calc(@space-base-unit * 12);
@space-64: calc(@space-base-unit * 16);
//EndLess Tokens
\`\`\`
`
            },
            {
                type: 'human',
                content: prompt || ''
            },
        ]

    }

}