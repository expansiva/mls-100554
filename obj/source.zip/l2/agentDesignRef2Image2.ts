/// <mls shortName="agentDesignRef2Image2" project="100554" enhancement="_blank" />

import { IAgent, svg_agent } from './_100554_aiAgentBase';
import { getPromptByHtml } from './_100554_aiPrompts';
import {
    getNextInProgressStepByAgentName,
    updateStepStatus,
    updateTaskTitle,
} from "./_100554_aiAgentHelper";

import { startNewAiTask, executeNextStep } from "./_100554_aiAgentOrchestration";

const agentName = "agentDesignRef2Image2";

export function createAgent(): IAgent {
    return {
        agentName,
        avatar_url: svg_agent,
        agentDescription: "DesignRef 2 Image",
        visibility: "public",
        scope: [],
        async beforePrompt(context: mls.msg.ExecutionContext): Promise<void> {
            return _beforePrompt(context);
        },
        async afterPrompt(context: mls.msg.ExecutionContext): Promise<void> {
            return _afterPrompt(context);
        },
    }
};

const _beforePrompt = async (context: mls.msg.ExecutionContext): Promise<void> => {

    const taskTitle = "Creating";
    if (!context || !context.message) throw new Error(`[${agentName}.beforePrompt] Invalid context`);
    if (!context.task) {
        const inputs = await getPrompts(context.message.content);
        await startNewAiTask(
            agentName,
            taskTitle,
            context.message.content,
            context.message.threadId,
            context.message.senderId,
            inputs,
            context,
            _afterPrompt
        ).catch((err) => {
            throw new Error(err.message)
        });
    }
}

const _afterPrompt = async (context: mls.msg.ExecutionContext): Promise<void> => {
    if (!context || !context.message || !context.task) throw new Error(`[${agentName}.afterPrompt] Invalid context`);
    const step: mls.msg.AIAgentStep | null = getNextInProgressStepByAgentName(context.task, agentName);
    if (!step) throw new Error(`[${agentName}.afterPrompt] No pending interaction found.`);
    context = await updateStepStatus(context, step.stepId, "completed");
    if (!context.task) throw new Error(`[${agentName}.afterPrompt]Invalid context task`);
    context.task = await updateTaskTitle(context.task, "Hero Image created");

    const stepIdPayLoad = step.interaction?.payload?.[0]?.stepId || -1;
    if (stepIdPayLoad > 0) {
      context = await updateStepStatus(context, stepIdPayLoad, "completed");
    }
    await executeNextStep(context);
}

async function getPrompts(data: string): Promise<mls.msg.IAMessageInputType[]> {
    const dataPrompt = {
        userPrompt: JSON.stringify(data)
    };
    const rc = await getPromptByHtml({ folder: '', project: 100554, shortName: agentName, data: dataPrompt });
    return rc;
}

