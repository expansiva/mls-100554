/// <mls fileReference="_100554_/l2/previewModeMinimum.defs.ts" enhancement="_blank" />

// Do not change – automatically generated code. 

export const asis: mls.defs.AsIs = {
  "meta": {
    "fileReference": "_100554_/l2/previewModeMinimum.ts",
    "componentType": "tool",
    "componentScope": "editor",
    "group": "enhancement"
  },
  "references": {
    "imports": [
      {
        "ref": "/_102027_/l2/libCompile",
        "dependencies": [
          {
            "name": "IJSONDependence",
            "type": "interface"
          }
        ]
      },
      {
        "ref": "/_100554_/l2/previewModeUtil"
      }
    ]
  },
  "asIs": {
    "semantic": {
      "generalDescription": "PreviewModeMinimum class",
      "businessCapabilities": [],
      "technicalCapabilities": [
        "Mount JS import map",
        "Mount JS scripts",
        "Mount CSS",
        "Mount tokens",
        "Simulate service"
      ],
      "implementedFeatures": [
        "init",
        "mountJS"
      ]
    }
  }
}
    