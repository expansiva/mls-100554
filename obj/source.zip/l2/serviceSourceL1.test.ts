/// <mls shortName="serviceSourceL1" project="100554" enhancement="_blank" />
				
import { ICANTest, ICANIntegration, ICANSchema  } from './_100554_tsTestAST'; 

export const integrations: ICANIntegration[] = []; 
export const tests: ICANTest[] = [];