/// <mls shortName="wcdAddItemUnsplash" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, css } from 'lit';
import { customElement } from 'lit/decorators.js';
import { collab_unsplash } from './_100554_collabIcons';
import { CollabLitElement } from "./_100554_collabLitElement";

/// **collab_i18n_start**
const message_pt = {
    unsplash: 'Adicionar uma imagem do Unsplash',
}
const message_en = {
    unsplash: 'Add an imagem from Unsplash',
}
type MessageType = typeof message_en;
const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**

@customElement('wcd-add-item-unsplash-100554')
export class WcdAddItemUnsplash100554 extends CollabLitElement {

    private msg: MessageType = messages['en'];

    static styles = css``;

    createRenderRoot() {
        return this;
    }

    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html`
        <button @keydown=${this.handleKeyDown} @click=${this.handleClick} data-tooltip=${this.msg.unsplash} ><span>${collab_unsplash}</span></button>

    `;
    }

    private async handleClick(e: MouseEvent) {
        e.stopPropagation();
        this.showHelper();
    }

    private async handleKeyDown(e: KeyboardEvent) {
        e.stopPropagation();
        if (e.key === 'Enter') {
            this.handleClick(new MouseEvent('click'));
        }
    }

    private showHelper() {
        if (!window.wcdState) throw new Error('Invalid window.wcdState');
        if (!window.wcdState.myParent) throw new Error('Invalid window.wcdState.myParent');

        window.wcdState.myParent.onclick = null;
        window.wcdState.myParent.setIconsWcdToolbox(
            [
                {
                    name: 'backButton'
                },
                {
                    name: '_100554_wcdDialogImageUnsplash',
                    args: '',
                    position: 'p-l1',
                    level: [2],
                    toolboxOptions: { background: '#fff', border: 'none' }
                },

            ],
            false,
            'size'
        );

    }

}
