/// <mls shortName="cssTokens" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, css, svg, repeat, TemplateResult } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement'
import { getDSInstance, DesignSystemIO, ITokenInfo } from './_100554_libDesignSystem';

/// **collab_i18n_start**
const message_pt = {

}

const message_en = {

}

type MessageType = typeof message_en;

const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**


@customElement('css-tokens-100554')
export class PluginCssTokens extends CollabLitElement {

    private msg: MessageType = messages['en'];

    @property({ type: Boolean }) autoPrepare: boolean = false;

    @property() position: 'left' | 'right' = 'left';

    @property() level: number = 0;

    @property() filter: string = '';

    @property() theme: string = 'Default';

    @property() tokens: Record<string, Record<string, Record<string, string>>> = {};

    private dsInstance: DesignSystemIO | undefined;

    private async initDsInstance() {
        const { project } = mls.actual[5];
        if (project === undefined) throw new Error('No project selected!');
        this.dsInstance = await getDSInstance(project, 0);
        if (!this.dsInstance) return;
        await this.dsInstance.init();
    }

    private async getTokensColor() {
        await this.initDsInstance();
        if (!this.dsInstance || !this.dsInstance.tokens) return '';
        if (!this.dsInstance) return '';
        const resumeTokensByTheme = this.dsInstance.tokens.list[this.theme];
        if (!resumeTokensByTheme) return undefined;
        const tokensColorKeys = Object.keys(resumeTokensByTheme.color);
        const res = tokensColorKeys.filter((key) => !key.startsWith('_dark') && key.startsWith(this.filter)).map((key2) => {
            return {
                key: key2,
                value: resumeTokensByTheme.color[key2]
            }
        })
        return this.groupColorsByState(res);
    }

    private groupColorsByState(items: { key: string, value: string }[]) {
        const grouped: Record<string, Record<string, Record<string, string>>> = {};

        items.forEach(item => {

            const match = item.key.match(/^(.*?)(-(hover|focus|disabled))?$/);
            const baseKey = match ? match[1].replace(/-(lighter|darker|dark|light)/, '') : item.key;
            const state = match && match[3] ? match[3] : 'default';

            const variation = item.key.includes('lighter')
                ? 'lighter'
                : item.key.includes('darker')
                    ? 'darker'
                    : item.key.includes('dark')
                        ? 'dark'
                        : item.key.includes('light')
                            ? 'light'
                            : 'default';

            if (!grouped[baseKey]) {
                grouped[baseKey] = {};
            }

            if (!grouped[baseKey][state]) {
                grouped[baseKey][state] = { dark: "", light: "", lighter: "", darker: "", default: "" };
            }

            grouped[baseKey][state][variation] = item.value;
        });

        return grouped;
    }

    handleColorClick(key: string, value: string) {

        console.info({ key, value });

    }

    setTooltip() {
        const doc: Document = this.ownerDocument || document;
        const tooltipEl = doc.querySelector('collab-tooltip') as any;
        this.querySelectorAll('.token-item').forEach((item) => {
            if (tooltipEl && tooltipEl.tooltip) tooltipEl.tooltip(item);
        })

    }

    async getTokens() {
        const tokens = await this.getTokensColor();
        if (tokens) this.tokens = tokens;
    }

    updated(changedProperties: any) {
        if (changedProperties.has('tokens')) {
            this.setTooltip();
        }
        if (changedProperties.has('filter')) {
            this.getTokens();
        }
    }

    async firstUpdated() {
        this.getTokens();
    }

    render() {

        return html`
            <div>
                ${Object.keys(this.tokens).map((cat) => html`
                <div class="tokens-container">
                    ${cat}
                    <div class="tokens-content">
                    ${Object.keys(this.tokens[cat]).map((state) => html`
                        <div class="token">
                        ${Object.keys(this.tokens[cat][state]).map((variation) => {
            return this.tokens[cat][state][variation] ? html`
                            <div
                                @click=${() => { this.handleColorClick(`${cat}${variation !== 'default' ? '-' + variation : ''}${state !== 'default' ? '-' + state : ''}`, this.tokens[cat][state][variation]) }} 
                                class="token-item"
                                data-tooltip="${cat}${variation !== 'default' ? '-' + variation : ''}${state !== 'default' ? '-' + state : ''}"
                                style="background-color: ${this.tokens[cat][state][variation]}">
                            
                            </div>
                            ` : html``;
        })}
                        </div>
                    `)}
                    </div>
                </div>
                `)}
            </div>
            `;

    }


}