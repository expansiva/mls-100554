/// <mls fileReference="_100554_/l2/collabDsInputSelectColor.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
//import { convertColorToHex } from '/_102027_/l2/libCommom.js';
export function initCollabDsInputSelectColor() { }
;
let CollabDsInputSelectColor = class CollabDsInputSelectColor extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.arrayInputSelect = [];
        this.arraySelect = [];
        this._valueInput = '';
        this._valueSelect = '';
        this._valueColor = '';
        this.prop = '';
        this.useInput = 'true';
        this.useSelect = 'true';
        this.useColor = 'true';
    }
    get value() { return this.configGetValue(); }
    ;
    set value(str) { this.configSetValue(str); }
    ;
    get valueInput() { return this._valueInput; }
    ;
    set valueInput(str) { this._valueInput = str; }
    ;
    get valueSelect() { return this._valueSelect; }
    ;
    set valueSelect(str) { this._valueSelect = str; }
    ;
    get valueColor() { return this._valueColor; }
    ;
    set valueColor(str) { this._valueColor = str || '#000000'; } //convertColorToHex(str) || '#000000' };
    render() {
        return html `    
            ${this.useInput === 'true' ? this.renderInput() : ''}
            ${this.useSelect === 'true' ? this.renderSelect() : ''}
            ${this.useColor === 'true' ? this.renderColor() : ''}
        `;
    }
    renderInput() {
        return html `
            <div>
                <input type="text" .value=${this.onlyNumber(this._valueInput)} @input=${this.changeInput} @wheel=${this.handleWhell}>
                <select @change="${this.allChange}" .value="px">
                    ${repeat(this.arrayInputSelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
                </select>
            </div>
        `;
    }
    renderSelect() {
        return html `
            <select @change="${this.allChange}" .value="px" prop="${this.prop}">
                    ${repeat(this.arraySelect, ((key) => key), ((k, index) => {
            return html `<option value="${k}">${k}</option>`;
        }))}
            </select>
        `;
    }
    renderColor() {
        return html `
            <input type="color" .value="${this._valueColor}" @input="${this.allChange}">
        `;
    }
    updated() {
        const sel = this.querySelector('div select');
        if (sel)
            sel.value = this.onlyTxt(this._valueInput);
        const sel2 = this.querySelector('select[prop]');
        if (sel2)
            sel2.value = this.onlyTxt(this._valueSelect);
    }
    //---------IMPLEMENTS-------------
    configGetValue() {
        let ret = '';
        if (this.useInput === 'true' && this._valueInput)
            ret = this._valueInput;
        else if (this.useInput === 'true')
            ret = '0px';
        if (this.useSelect === 'true' && this._valueSelect)
            ret += ' ' + this._valueSelect;
        else if (this.useSelect === 'true')
            ret = ' none';
        if (this.useColor === 'true' && this._valueColor)
            ret += ' ' + this._valueColor;
        else if (this.useColor === 'true')
            ret = ' #ffffff';
        return ret.trim();
    }
    configSetValue(str) {
        if (!str)
            return;
        const array = str.split(' ');
        if (this.useInput === 'true' && array.length >= 1) {
            this._valueInput = array[0];
            array.splice(0, 1);
        }
        if (this.useSelect === 'true' && array.length >= 1) {
            this._valueSelect = array[0];
            array.splice(0, 1);
        }
        if (this.useColor === 'true' && array.length >= 1) {
            this._valueColor = array[0];
            array.splice(0, 1);
        }
    }
    onlyNumber(str) {
        const regexNum = /-?\d+(?:\.\d+)?/;
        const res = str.match(regexNum);
        return res ? res[0] : '';
    }
    onlyTxt(str) {
        const regexStr = /[a-zA-Z]+/;
        const res = str.match(regexStr);
        return res && res[0] ? res[0].replace('.', '') : 'px';
    }
    handleWhell(wheelEvent) {
        wheelEvent.preventDefault();
        const input = wheelEvent.target;
        let currentValue = input.value.replace(',', '.');
        if (!currentValue)
            currentValue = '0';
        let isDecimal = currentValue.includes('.');
        let parsedValue = parseFloat(currentValue);
        let isScrollingUp = wheelEvent.deltaY < 0;
        if (isNaN(parsedValue)) {
            return;
        }
        if (!isDecimal)
            parsedValue += (wheelEvent.deltaY < 0 ? 1 : -1);
        else {
            let decimalPart = currentValue.split('.')[1] || '';
            let decimalLength = decimalPart.length;
            if (decimalLength > 0) {
                let factor = Math.pow(10, decimalLength);
                if (isScrollingUp)
                    parsedValue = (Math.floor(parsedValue * factor) + 1) / factor; // Incrementa a última casa decimal
                else
                    parsedValue = (Math.floor(parsedValue * factor) - 1) / factor; // Decrementa a última casa decimal
            }
        }
        input.value = parsedValue.toString();
        this.allChange(wheelEvent);
    }
    changeInput(e) {
        const input = e.target;
        let value = input.value.replace(/[^0-9.,]/g, '');
        let dotCount = (value.match(/\./g) || []).length;
        if (dotCount > 1)
            value = value.replace(/\.(?=[^\.]*$)/, '');
        value = value.replace(',', '.');
        input.value = value;
        if (value.endsWith('.'))
            return;
        this.allChange(e);
    }
    allChange(e) {
        e.stopPropagation();
        let input = this.querySelector('input[type="text"]');
        let sel = this.querySelector('select');
        let sel2 = this.querySelector('select[prop]');
        let color = this.querySelector('input[type="color"]');
        const ret = [];
        if (this.useInput === 'true') {
            this._valueInput = input.value + sel.value;
            ret.push({ tp: 'input', value: input.value + sel.value });
        }
        if (this.useSelect === 'true') {
            this._valueSelect = sel2.value;
            ret.push({ tp: 'select', value: sel2.value });
        }
        if (this.useColor === 'true') {
            this._valueColor = color.value;
            ret.push({ tp: 'color', value: color.value });
        }
        this.fireEvents({
            key: this.prop,
            value: ret
        });
    }
    fireEvents(obj) {
        obj.target = this;
        const onChangePropEvento = new CustomEvent('onchange', {
            bubbles: true,
            detail: obj,
        });
        this.dispatchEvent(onChangePropEvento);
    }
};
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "_valueInput", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "_valueSelect", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "_valueColor", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "prop", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useInput", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useSelect", void 0);
__decorate([
    property()
], CollabDsInputSelectColor.prototype, "useColor", void 0);
CollabDsInputSelectColor = __decorate([
    customElement('collab-ds-input-select-color-100554')
], CollabDsInputSelectColor);
export { CollabDsInputSelectColor };
