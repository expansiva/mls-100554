/// <mls shortName="collabDOMSync" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

export function sync() {

    if (!window.preview.editor || !window.preview.iframe) return;
    const model = window.preview.editor.getModel();
    if (!model) return;
    const newHTMLOnlyICA = clearTree(window.preview.iframe)
    const formatedNewHTML = formatHtml(newHTMLOnlyICA);
    setValueInModeKeepingUndo2(model, formatedNewHTML);

}

export function updateHTML(html: string, format:boolean = true) {

    if (!window.preview.editor || !window.preview.iframe) return;
    const model = window.preview.editor.getModel();
    if (!model) return;
    const newHTMLOnlyICA = html
    const formatedNewHTML = format ? formatHtml(newHTMLOnlyICA) : newHTMLOnlyICA;
    setValueInModeKeepingUndo2(model, formatedNewHTML);

}

function setValueInModeKeepingUndo2(model: monaco.editor.ITextModel, newContent: string) {
    const editor = window.preview.editor;
    if (!editor)
        throw new Error('No find editor');

    editor.setModel(model);
    const lastLineNumber = model.getLineCount();
    const lastLineLength = model.getLineLength(lastLineNumber);
    const range = new monaco.Range(1, 1, lastLineNumber, lastLineLength + 1);
    editor.pushUndoStop();
    editor.executeEdits('userEdit', [{
        range: range,
        text: newContent
    }]);
    editor.pushUndoStop();
    editor.layout();
}

export function formatHtml(html: string) {
    const placeholders: string[] = [];

    const escapedBlockRegex = /(&lt;[^]+?&gt;)/g;
    const htmlWithPlaceholders = html.replace(escapedBlockRegex, (match) => {
        const key = `__ESCAPED_BLOCK_${placeholders.length}__`;
        placeholders.push(match);
        return key;
    });

    const container = document.createElement('div');
    container.innerHTML = htmlWithPlaceholders.trim();

    function formatNode(node: any, indentLevel = 0): string {
        const indent = '\t'.repeat(indentLevel);
        const childIndent = '\t'.repeat(indentLevel + 1);
        let formattedHtml = '';

        if (node.nodeType === Node.ELEMENT_NODE) {
            const tagName = node.nodeName.toLowerCase();
            formattedHtml += `${indent}<${tagName}`;

            for (const attr of node.attributes) {
                let attrValue = attr.value.replace(/'/g, '"');
                formattedHtml += `\n${childIndent}${attr.name}='${attrValue}'`;
            }

            formattedHtml += '>';

            let childHtml = '';
            for (const child of node.childNodes) {
                const childFormatted = formatNode(child, indentLevel + 1);
                if (childFormatted) {
                    childHtml += `\n${childFormatted}`;
                }
            }
            formattedHtml += childHtml.trim();
            formattedHtml += `\n${indent}</${tagName}>`;
        } else if (node.nodeType === Node.TEXT_NODE) {
            let text = node.nodeValue;
            if (text.trim()) {
                formattedHtml += indent + text.trim();
            }
        }

        return formattedHtml;
    }

    let result = formatNode(container.firstChild);

    result = result
        .split('\n')
        .filter(line => line.trim() !== '')
        .join('\n');

    for (let i = 0; i < placeholders.length; i++) {
        const key = `__ESCAPED_BLOCK_${i}__`;
        result = result.replace(key, placeholders[i].trim());
    }

    return result;
}

function getDiffs(originalLines: string[], modifiedLines: string[]) {
    const diffs: IDiffs[] = [];
    originalLines.forEach((line, index) => {
        if (line !== modifiedLines[index]) {
            diffs.push({
                lineNumber: index + 1,
                originalLine: line,
                modifiedLine: modifiedLines[index]
            });
        }
    });
    return diffs;
}

function applyDiffs(originalModel: monaco.editor.ITextModel, diffs: IDiffs[]) {

    const editor = window.preview.editor;
    if (!editor) throw new Error('No find editor');
    editor.setModel(originalModel);
    const edits: monaco.editor.IIdentifiedSingleEditOperation[] = [];

    diffs.forEach(diff => {
        if (!diff.lineNumber) return;
        const lines = originalModel.getLineCount();
        let lineContent = 0;

        if (diff.lineNumber <= lines) lineContent = originalModel.getLineLength(diff.lineNumber);
        else lineContent = diff.modifiedLine?.length || 0;

        let range: monaco.Range;
        range = new monaco.Range(diff.lineNumber, 1, diff.lineNumber, lineContent + 1)
        const edit: monaco.editor.IIdentifiedSingleEditOperation = {
            range,
            text: diff.modifiedLine || '',
            forceMoveMarkers: true,
        }
        edits.push(edit);
    });

    editor.executeEdits('my-source', edits);

}

function clearTree(iframe: HTMLIFrameElement): string {
    let ret = '';
    const div = document.createElement('div');
    const divRet = document.createElement('div');
    const body = iframe.contentDocument?.body
    if (!body) return ret;
    clearTree2(div, body as HTMLElement);
    clearTree3(divRet, div);
    return divRet.innerHTML;
}

function clearTree2(parent: HTMLElement, element: HTMLElement): HTMLElement {

    const tagname = element.tagName.toLowerCase();

    if (element && element.getAttribute('modeoverlay')) {
        const clone = element.cloneNode(false);
        (clone as HTMLElement).removeAttribute('style');
        (clone as HTMLElement).removeAttribute('level');
        parent.appendChild(clone);
        let children = [];
        if (element.shadowRoot) children = [...element.shadowRoot.children]
        else children = [...element.children]
        for (const child of children) {
            clearTree2(clone as HTMLElement, child as HTMLElement);
        }
    }

    if (tagname.startsWith('ica-')) {

        const clone = element.cloneNode(false);
        const idEl = (clone as HTMLElement).id;
        (clone as HTMLElement).removeAttribute('idel');
        (clone as HTMLElement).removeAttribute('style');
        (clone as HTMLElement).removeAttribute('level');
        (clone as HTMLElement).removeAttribute('rendertype');
        if (idEl && idEl.startsWith('ica_')) (clone as HTMLElement).setAttribute('id', idEl.substring(4, idEl.length));

        parent.appendChild(clone);

        let children = [];
        if (element.shadowRoot) children = [...element.shadowRoot.children]
        else children = [...element.children]

        for (const child of children) {
            clearTree2(clone as HTMLElement, child as HTMLElement);
        }

    } else {

        let children = [];
        if (element.shadowRoot) children = [...element.shadowRoot.children]
        else children = [...element.children]
        for (const child of children) {
            clearTree2(parent, child as HTMLElement);
        }
    }
    return parent;
}

function clearTree3(parent: HTMLElement, element: HTMLElement) {

    let children = [...element.children];

    for (const child of children) {
        const tagname = child.tagName.toLowerCase();
        if (tagname.indexOf('-') > 0) {
            const clone = child.cloneNode(false);
            parent.appendChild(clone);
            clearTree3(clone as HTMLElement, child as HTMLElement);
        } else {
            clearTree3(parent, child as HTMLElement);
        }

    }
}


interface IDiffs {
    lineNumber: number,
    originalLine: string,
    modifiedLine: string
}
