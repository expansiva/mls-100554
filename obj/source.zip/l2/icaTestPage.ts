/// <mls shortName="icaTestPage" project="100554" enhancement="_100554_enhancementLit" groupName="other" />
import { html, css, LitElement } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { getFormComponentsEvents, getEventDescription, getFormComponentsDescription } from './_100554_icaBaseDescription'
import { Window } from './_100554_icaState';

@customElement('ica-test-page-100554')
export class IcaTestPage100554 extends LitElement {

    static styles = css`:host {
        display: flex;
    }`;

    render() {
        console.info(getFormComponentsEvents('forms', 'input', 'number'));
        (window as any as Window).globalState = {
            wcdAddEventSelected: '',
            tables: {
                sex: [{ key: 'm', value: 'masculino' }, { key: 'f', value: 'feminino' }],
                events: [{ key: 'click', value: 'click', description: 'evento onclick' }, { key: 'blur', value: 'blur', description: 'evento onblur' }, { key: 'change', value: 'change', description: 'evento onchange' }],
            },
            users: [{
                name: 'Wagner',
                age: 63,
                city: 'SP',
                sex: 'm'
            },
            {
                name: 'Guilherme',
                age: 28,
                city: 'SP',
                sex: 'm'
            }]
        };

        return html``;

    }
}

interface IUser {
    name: string,
    age: number,
    city: string,
    sex: string,
}