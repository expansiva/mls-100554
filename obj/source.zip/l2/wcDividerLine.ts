/// <mls shortName="wcDividerLine" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, css, LitElement } from 'lit'; 
import { customElement, property } from 'lit/decorators.js';

@customElement('wc-divider-line-100554')
export class WcDivider100554 extends LitElement {

    @property() text: string | undefined;

    render() {
        return html`<hr></hr>`;
    }
}

