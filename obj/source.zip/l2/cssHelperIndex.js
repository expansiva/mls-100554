/// <mls fileReference="_100554_/l2/cssHelperIndex.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, } from 'lit';
import { when } from 'lit/directives/when.js';
import { repeat } from 'lit/directives/repeat.js';
import { customElement, property, queryAll } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { getState } from '/_102029_/l2/collabState.js';
import { loadPluginProject } from '/_102027_/l2/libCommom.js';
import '/_100554_/l2/pluginStyleIndexItem.js';
/// **collab_i18n_start**
const message_pt = {
    'msg': 'Nenhum helper disponivel',
    'selector': 'Seletor',
};
const message_en = {
    'msg': 'No helper available.',
    'selector': 'Selector',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
let CssHelperIndex = class CssHelperIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.minValueToOpen = {
            'full': 3,
            'expanded': 20,
        };
        this.helpers = [];
        this.avaliablePlugins = [];
        this.position = 'left';
        this.actualProp = '';
        this.actualValue = '';
        this.actualSelector = '';
        this.actualLineContent = '';
        this.isFirtsLoading = true;
        this.baseProject = 100554;
    }
    handleIcaStateChange(_key, _value) {
        if (_key !== `less.${this.position}` || !_value)
            return;
        const { key, value, selector, lineNumber, lineContent } = _value;
        this.actualSelector = selector;
        this.actualProp = key;
        this.actualValue = value;
        this.actualLineNumber = lineNumber;
        this.actualLineContent = lineContent;
        if (lineNumber && key) {
            this.actualProp = key;
            this.actualValue = value;
        }
        else {
            this.actualProp = '';
            this.actualValue = '';
        }
    }
    async updated(changedProperties) {
        if ((changedProperties.has('actualProp') ||
            changedProperties.has('actualValue') ||
            changedProperties.has('actualLineNumber'))) {
            if (!(this.actualSelector && (this.actualSelector.endsWith(':') || this.actualSelector.endsWith('::'))) &&
                !(this.actualLineContent && (this.actualLineContent.endsWith(':') || this.actualLineContent.endsWith('::')))) {
                this.avaliablePlugins = this.mergeHelpersArrays(this.avaliablePlugins, this.helpers);
                this.helpers = this.filterByProp(this.avaliablePlugins, this.actualProp, this.actualValue).sort((a, b) => a.priority - b.priority);
            }
        }
        if (changedProperties.has('actualLineContent') &&
            this.actualProp === '' &&
            this.actualValue === '' &&
            (this.actualLineContent && (this.actualLineContent.endsWith(':') || this.actualLineContent.endsWith('::')) ||
                this.actualSelector && (this.actualSelector.endsWith(':') || this.actualSelector.endsWith('::')))) {
            this.avaliablePlugins = this.mergeHelpersArrays(this.avaliablePlugins, this.helpers);
            this.helpers = this.avaliablePlugins.filter((pl) => pl.tags.includes('pseudo:*'));
            if (this.helpers[0])
                this.helpers[0].mode = 'full';
        }
        // if (changedProperties.has('actualSelector') &&
        //     this.actualProp === '' &&
        //     this.actualValue === '' &&
        //     this.actualSelector &&
        //     (this.actualSelector.endsWith(':') || this.actualSelector.endsWith('::'))
        // ) {
        //     this.avaliablePlugins = this.mergeHelpersArrays(this.avaliablePlugins, this.helpers);
        //     this.helpers = this.avaliablePlugins.filter((pl) => pl.tags.includes('pseudo:*'));
        //     if (this.helpers[0]) this.helpers[0].mode = 'full';
        // }
    }
    mergeHelpersArrays(a, b) {
        const mergedMap = new Map();
        for (const item of a) {
            mergedMap.set(item.name, { ...item });
        }
        for (const item of b) {
            mergedMap.set(item.name, { ...mergedMap.get(item.name), ...item });
        }
        return Array.from(mergedMap.values());
    }
    async firstUpdated(a) {
        super.firstUpdated(a);
        const avaliablePlugins = await this.getAvaliablesPlugins();
        this.avaliablePlugins = avaliablePlugins;
        const helpers = this.filterByProp(this.avaliablePlugins, this.actualProp, this.actualValue);
        this.helpers = helpers;
        await this.updateComplete;
    }
    async getAvaliablesPlugins() {
        const project = mls.actualProject;
        const allPlugins = await loadPluginProject(project || 0, 'l2StyleHelper');
        const helpers = [];
        for await (let plugin of allPlugins) {
            const instance = await import(`/${plugin.widget}`);
            let description = '';
            if (!instance || !instance.tags || !Array.isArray(instance.tags))
                continue;
            if (instance.getDescription && typeof instance.getDescription === 'function') {
                const descriptionRc = instance.getDescription();
                if (descriptionRc && typeof descriptionRc === 'string')
                    description = descriptionRc;
            }
            const obj = {
                name: plugin.category || 'none',
                widget: plugin.widget,
                tags: instance.tags,
                priority: plugin.priority || 1,
                description,
                mode: 'expanded',
                liked: false,
                likedAnimation: false,
                showInfo: false,
            };
            helpers.push(obj);
        }
        return helpers;
    }
    filterByProp(helpers, actualProp, actualValue) {
        const state = getState(`less.${this.position}`);
        if (!state || !state.selector || !state.lineNumber)
            return [];
        const rc = helpers.filter(helper => {
            return helper.tags.some(helperTag => {
                const [tagProperty, tagValue] = helperTag.split(':');
                const validateTagOrProp = (tagCompare, value, returnAllIfEmpty = false) => {
                    if (!value && returnAllIfEmpty)
                        return true;
                    if (!value)
                        return false;
                    if (tagCompare.startsWith('!')) {
                        const prefix = tagCompare.substring(1);
                        if (tagCompare.endsWith('*')) {
                            const trimmedPrefix = prefix.slice(0, -1);
                            return !value.startsWith(trimmedPrefix);
                        }
                        return value !== prefix;
                    }
                    if (tagCompare.endsWith('*')) {
                        const prefix = tagCompare.slice(0, -1);
                        return value.startsWith(prefix);
                    }
                    return tagCompare === value;
                };
                const propMatches = validateTagOrProp(tagProperty, actualProp || '', true);
                const valueMatches = tagValue ? validateTagOrProp(tagValue, actualValue || '') : true;
                return propMatches && valueMatches;
            });
        });
        if (this.isFirtsLoading) {
            this.isFirtsLoading = false;
            const mode = rc.length < this.minValueToOpen.full ? 'full' : (rc.length < this.minValueToOpen.expanded ? 'expanded' : 'collapsed');
            rc.forEach((help) => {
                const sameHelp = this.avaliablePlugins.find((item) => item.widget === help.widget);
                if (sameHelp)
                    sameHelp.mode = mode;
                help.mode = mode;
            });
        }
        if (rc.length <= this.minValueToOpen.full) {
            rc.forEach((help) => {
                help.mode = 'full';
            });
        }
        if (rc.length > this.minValueToOpen.full) {
            rc.forEach((help) => {
                help.mode = 'expanded';
            });
        }
        return rc;
    }
    render() {
        return html `
            <div> ${this.msg.selector}: <b>${this.actualSelector} </b> </div>
            ${when(this.helpers.length === 0, () => html `<div>${this.msg.msg}</div>`, () => html `
                <div class="helpers">
                    ${repeat(this.helpers, ((item) => item.widget), ((item, index) => this.renderHelper(item, index)))}
                </div>`)}`;
    }
    renderHelper(help, index) {
        return html `<plugin-style-index-item-100554 position="${this.position}" mode=${help.mode} .help=${help}></plugin-style-index-item-100554>`;
    }
};
__decorate([
    property()
], CssHelperIndex.prototype, "helpers", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "avaliablePlugins", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "position", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualProp", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualValue", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualSelector", void 0);
__decorate([
    property({ reflect: true })
], CssHelperIndex.prototype, "actualLineContent", void 0);
__decorate([
    property()
], CssHelperIndex.prototype, "actualLineNumber", void 0);
__decorate([
    propertyDataSource()
], CssHelperIndex.prototype, "state", void 0);
__decorate([
    queryAll('plugin-style-index-item-100554')
], CssHelperIndex.prototype, "allPluginsEls", void 0);
CssHelperIndex = __decorate([
    customElement('css-helper-index-100554')
], CssHelperIndex);
export { CssHelperIndex };
