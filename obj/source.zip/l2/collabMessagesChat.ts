/// <mls shortName="collabMessagesChat" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, LitElement, unsafeHTML } from 'lit';
import { customElement, property, state, query } from 'lit/decorators.js';
import { collab_chevron_left, collab_gear, collab_translate, collab_circle_exclamation, collab_plus } from './_100554_collabIcons';
import { collabImport } from './_100554_collabImport';
import { removeThreadFromSync, getThreadUpdateInBackground, checkIfNotificationUnread } from './_100554_collabMessagesSyncNotifications';
import { openElementInServiceDetails, clearServiceDetails } from './_100554_libCommom';
import { listUsers, deleteAllMessagesFromThread } from './_100554_msgDBController';
import { setFavicon } from './_100554_collabInit';

import {
    getTemporaryContext,
    formatTimestamp,
    getNextResultStep,
    notifyThreadChange
} from './_100554_aiAgentHelper';

import {
    addOrUpdateTask,
    addMessages,
    addMessage,
    updateThread,
    updateUsers,
    getMessage,
    getMessagesByThreadId
} from './_100554_msgDBController';

import {
    loadChatPreferences,
    getBotsContext,
    registerToken,
    loadNotificationPreferences,
    loadNotificationDeviceId
} from './_100554_collabMessageHelper';

import './_100554_collabMessagesTaskInfo';
import './_100554_collabMessagesTask';
import './_100554_collabMessagesTopics';
import './_100554_collabMessagesPrompt';
import './_100554_collabMessagesAvatar';
import './_100554_collabMessagesThreadDetails';
import './_100554_collabMessagesRichPreview';
import './_100554_collabMessagesUserModal';
import './_100554_collabMessagesAdd';

import { IChatPreferences, AGENTDEFAULT, PROJECTAGENTDEFAULT } from './_100554_collabMessageHelper';
import { StateLitElement } from './_100554_stateLitElement';
import { CollabMessagesPrompt100554 } from './_100554_collabMessagesPrompt';
import { IAgent } from './_100554_aiAgentBase';

/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando...',
    btnAddParticipant: 'Adicionar participante',
    threadDetails: 'Detalhes da sala',
    msgNotSend: 'Mensagem não enviada*',
    noThreads: 'Nenhuma sala disponível no momento.',
    placeholderSearch: 'Digite para filtrar',
    threadArchived: 'A thread foi arquivada por [user] em [date]',
    threadDeleting: 'A thread foi deletada em [date]',
    archived: 'Arquivado',
    deleting: 'Deletando',
    btnNext: 'Continuar',
    promptPlaceholder: 'Digite aqui... (@ para menções) (@@ para agentes)'
}

const message_en = {
    loading: 'Loading...',
    btnAddParticipant: 'Add Participant',
    threadDetails: 'Thread details',
    msgNotSend: 'Message not sent*',
    noThreads: 'No threads available at the moment.',
    placeholderSearch: 'Type to filter',
    threadArchived: 'Thread is archived by [user] in [date]',
    threadDeleting: 'Thread was deleted in [date]',
    archived: 'Archived',
    deleting: 'Deleting',
    btnNext: 'Next',
    promptPlaceholder: 'Type here... (@ for mentions) (@@ for agents)'
}

type MessageType = typeof message_en;
const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**


@customElement('collab-messages-chat-100554')
export class CollabMessagesChat100554 extends StateLitElement {

    private msg: MessageType = messages['en'];

    @query('collab-messages-prompt-100554') collabMessagesPrompt: CollabMessagesPrompt100554 | undefined;
    @query('#unread') private unreadEl!: HTMLDivElement | undefined;
    @query('.chat-container') private messageContainer!: HTMLDivElement | undefined;

    @state() userPreferenceChat?: IChatPreferences;
    @state() isLoadingThread: boolean = false;
    @state() filteredThreads: IFilteredThreadsByStatus = { active: [], archived: [], deleted: [], deleting: [] };
    // @state() allUsersInThread: mls.msg.User[] = [];
    @state() isThreadError: boolean = false;
    @state() threadErrorMsg: string = '';
    @state() lastTopicFilter: string = '';
    @state() welcomeMessage: string = '';
    @state() usersAvaliables: mls.msg.User[] = [];

    @property() group: 'CONNECT' | 'APPS' | 'DOCS' | 'CRM' = 'CONNECT';
    @property() userId: string | undefined;
    @property() threadToOpen: string | undefined;
    @property() userDeviceId: string | undefined;
    @property() activeScenerie: IScenery = 'list';
    @property() actualThread: IThreadInfo | undefined;
    @property() actualTask: mls.msg.TaskData | undefined;
    @property() actualMessage: IMessage | undefined;
    @property() actualMessages: IMessage[] = [];
    @property() actualMessagesParsed: IMessageGrouped = {};
    @property() isLoadingMessages: boolean = false;
    @property() searchTerm: string = '';
    @property({ attribute: false }) userThreads: IThread = {};
    @property({ attribute: false }) allThreads: mls.msg.Thread[] = []

    private isSystemChangeScroll: boolean = false;
    private savedScrollTop = 0;
    private hasMoreMessagesLocalDB = true;
    private hasMoreMessagesBefore: boolean = false;
    private messagesLimit = 10;
    private messagesOffset = 0;
    private isLoadingMoreMessages = false;
    private isChangeTopics = false;
    private wasMessagesAtBottom: boolean = true;


    private imageUrls = [
        "https://images.unsplash.com/photo-1577563908411-5077b6dc7624?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    ];

    async updated(changedProperties: Map<PropertyKey, unknown>) {
        super.updated(changedProperties);
        if (this.unreadEl && this.messageContainer) {
            await this.updateComplete;
            this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
            return;
        }

        if (changedProperties.has('activeScenerie') && (this.activeScenerie === 'list')) {
            this.usersAvaliables = await listUsers();
        }

        if (changedProperties.has('threadToOpen')) {
            if (this.threadToOpen) {
                if (this.activeScenerie !== 'list') {
                    this.activeScenerie = 'list';
                    await this.updateComplete;
                }
                const threadElement = this.querySelector(`[threadId="${this.threadToOpen}"]`) as IHTMLLiThreadItem;
                if (!threadElement) return;
                this.onThreadClick(threadElement.item);
            }
        }

        if (changedProperties.has('activeScenerie')
            && (changedProperties.get('activeScenerie') === 'task'
                || changedProperties.get('activeScenerie') === 'addParticipant'
                || changedProperties.get('activeScenerie') === 'threadDetails'
            )
            && this.activeScenerie === 'details') {
            this.restoreScrollPosition();
        }

        if (changedProperties.has('actualMessagesParsed') && this.actualMessagesParsed !== undefined) {

            if (this.messageContainer && (this.isSystemChangeScroll)) {
                await this.updateComplete;
                this.messageContainer.scrollTop = this.messageContainer.scrollHeight;
                this.isSystemChangeScroll = false;

            }
        }
    }

    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('task-change', this.onTaskChange);
        window.removeEventListener('task-details-close', this.onTaskDetailsClose);
        window.removeEventListener('thread-change', this.onThreadChange);
        window.removeEventListener('message-send', this.onMessageSend);
    }

    async firstUpdated(changedProperties: Map<PropertyKey, unknown>) {
        super.firstUpdated(changedProperties);
        window.addEventListener('task-change', this.onTaskChange);
        window.addEventListener('task-details-close', this.onTaskDetailsClose);
        window.addEventListener('thread-change', this.onThreadChange);
        window.addEventListener('message-send', this.onMessageSend);
    }

    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.activeScenerie === 'loading') {
            return html`<div class="loading">${this.msg.loading}</div>`;
        }
        return html`
            ${this.renderHeader()}
            ${this.renderContent()}`;
    }

    private renderHeader() {
        switch (this.activeScenerie) {
            case 'task':
                return html`
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} Task: ${this.actualTask?.PK || ''}</span>
                    </div>`;
            case 'details':
                return html`
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} Thread: ${this.getThreadName(this.actualThread)}</span>
                        ${this.actualThread?.thread.status !== 'deleted' ? html`
                            <div class="header-actions">
                                <span @click=${this.onThreadDetailsClick}>${collab_gear}</span>
                            </div>
                        `: ''}                        
                    </div>`;
            case 'list':
                return html`<div class="header">
                    ${this.renderThreadSearch()}
                    <div class="header-actions">
                            <span @click=${this.onThreadAddClick}>${collab_plus}</span>
                    </div>
                </div>`;
            case 'threadDetails':
                return html`
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} ${this.msg.threadDetails}</span>
                    </div>`;
            case 'threadAdd':
                return html`
                    <div class="header">
                        <span @click=${this.onTitleClick}>${collab_chevron_left} Threads</span>
                    </div>`;
            default:
                return null;
        }
    }

    private renderContent() {
        switch (this.activeScenerie) {
            case 'list':
                return this.renderListThreads();
            case 'details':
                return this.renderChatMessages();
            case 'task':
                return this.renderTaskDetails();
            case 'threadDetails':
                return this.renderThreadDetails();
            case 'threadAdd':
                return this.renderThreadAdd();
            default:
                return null;
        }
    }

    private renderChatMessages() {
        if (!this.actualThread) return html``;
        if (this.welcomeMessage && !['deleting', 'deleted', 'archived'].includes(this.actualThread?.thread.status)) {
            return this.renderWelcomeMessage();
        }

        if (this.actualThread.thread.status === 'deleting' || this.actualThread.thread.status === 'deleted') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.deletedAt || '');
            const deletedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            return html`
                <div>${this.msg.threadDeleting.replace('[date]', deletedAt.datafull)}</div>
            `
        }

        if (this.actualThread.thread.status === 'archived') {
            const formatedTimestamp = formatTimestamp(this.actualThread.thread.archivedAt || '');
            const archivedAt = this.parseLocalDate(formatedTimestamp?.dateFull || '');
            const archivedBy = this.actualThread.users.find((user) => user.userId === this.actualThread?.thread.archivedBy)
            return html`
                <div>${this.msg.threadArchived.replace('[user]', archivedBy?.name || '').replace('[date]', archivedAt.datafull)}</div>
            `
        }

        this.userPreferenceChat = loadChatPreferences();
        const sortedEntries = Object.entries(this.actualMessagesParsed)
            .map(([date, value]) => [date.trim(), value])
            .sort(([a], [b]) => new Date(a as string).getTime() - new Date(b as string).getTime());
        const sortedObj: IMessageGrouped = Object.fromEntries(sortedEntries);

        return html`
        ${this.renderTopics()}
        <div @scroll=${this.onChatScroll} class="chat-container">
            ${Object.keys(sortedObj).map((key) => {
            const threadMessages = sortedObj[key];
            const messageTime = this.parseLocalDate(key);
            return html`
                    <div class="message-time">${messageTime.date}</div>
                    ${threadMessages.map((message) => {
                const dateFormated = formatTimestamp(message.createAt);
                const userToFind = [
                    ...this.usersAvaliables,
                    ...(this.actualThread?.users || [])
                ].filter(
                    (user, index, self) =>
                        index === self.findIndex(u => u.userId === user.userId)
                );

                const userName = userToFind.find((user) => user.userId === message.senderId)?.name || message.senderId;
                const userAvatar = userToFind.find((user) => user.userId === message.senderId)?.avatar_url || '';
                const cls = message.senderId === this.userId ? 'user' : 'system';
                const isSame = message.isSame;
                const titleTranslated = this.getTitleMessageTranslated(message)
                return html`
                    <div class="message ${cls} ${isSame ? 'same' : ''}">
                        <div class="message-group">
                            <div class="message-row">
                                <div class="message-card ${cls} ${isSame ? 'same' : ''}">
                                    ${!isSame ? html`<div class="message-title">@${userName}</div>` : ``}
                                    ${this.renderMessageByLanguage(message)}
                                    ${message.isLoading ? html`<span class="loader"></span>` : ''}
                                    ${message.isFailed ? html`<div class="failed">
                                        <div>
                                            <span>${collab_circle_exclamation}</span>
                                            <small>${this.msg.msgNotSend}</small>
                                        </div>
                                        <small>${message.isFailedError}</small>
                                    </div>`: ''}
                                    ${message.taskId ? html`
                                        <div class="message-ai">
                                            <collab-messages-task-100554
                                                messageId=${message.createAt}
                                                .context= ${message.context}
                                                lastChanged= ${message.lastChanged}
                                                taskId=${message.taskId}
                                                title=${titleTranslated}
                                                status=${message.taskStatus}
                                                @taskclick=${() => this.onTaskClick(message?.taskId || '', message.createAt, message.threadId, message)}
                                            >
                                            </collab-messages-task-100554>
                                        </div> `: html``}
                                    ${this.renderMessageResultByLanguage(message)}
                                    ${this.renderMessageFooterResult(message)}
                                    <div class="message-footer">${dateFormated?.timeShort}</div>
                                </div>
                                ${cls === 'system' && !isSame ? html`<collab-messages-avatar-100554 avatar=${userAvatar}></collab-messages-avatar-100554>` : ''}
                            </div>
                        </div>
                    </div>`
            })}`
        })}
        ${this.isLoadingMessages ? html`<div class="unread-messages" id="unread">Loading messages...</div>` : html``}
        ${this.isThreadError ? html`<div class="error-messages">${this.threadErrorMsg}</div>` : html``}

</div>
        ${this.renderPrompt()}
`
    }

    private renderWelcomeMessage() {

        return html`
            <div class="welcome-message">
                <p>${this.welcomeMessage}</p>
                <button @click=${() => { this.welcomeMessage = ''; }}>${this.msg.btnNext}</button>       
            </div>`
    }

    private renderMessageFooterResult(message: mls.msg.MessagePerformanceCache) {

        if (!message.footers || message.footers.length === 0) return html``;
        return html`<div class="message-result">
            ${message.footers?.map((footer) => {
            const content = footer.lines.join('\n').trim();
            if (!content) return html``;
            return html`
                <div class="message-result-text">
                    <b>${footer.title?.trim()}</b>
                    <div>
                        ${this.renderCollabMessagesRichPreview(footer.lines.join('\n').trim())}                    
                    </div>
                </div>`
        })}
        </div>`

    }

    private renderCollabMessagesRichPreview(text: string) {

        return html`
        <collab-messages-rich-preview-100554 
            @mention-hover=${this.onMentionHover}
            .allUsers=${this.usersAvaliables} 
            .allThreads=${this.allThreads}
            text="${text}"
        ></collab-messages-rich-preview-100554>`
    }

    private renderTopics() {
        return html`
            <collab-messages-topics-100554
                .selectedTopic=${this.lastTopicFilter === '' ? 'all' : this.lastTopicFilter}
                .messages=${this.actualMessages}
                .threadTopics=${this.actualThread?.thread.defaultTopics || []}
                @topic-selected=${(e: CustomEvent) => this.onTopicClick(e)}
            ></collab-messages-topics-100554>
        `
    }

    private async onTopicClick(e: CustomEvent) {

        this.lastTopicFilter = e.detail.topic === 'all' ? '' : e.detail.topic;
        this.isChangeTopics = true;
        if (e.detail.topic === 'all') this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        else this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateComplete;

        if (this.messageContainer) {
            const newHeight = this.messageContainer.scrollHeight;
            this.messageContainer.scrollTop = newHeight;
        }

    }

    private async onMentionHover(ev: CustomEvent) {

        this.removeAllUserModal();
        if (!ev.detail || !ev.detail.value || !ev.detail.element) return;
        const actualUserModal = this.usersAvaliables.find((user) => user.name === ev.detail.value);

        const rects = (ev.detail.element as HTMLElement).getBoundingClientRect();
        const modal = document.createElement('collab-messages-user-modal-100554');
        (modal as any).user = actualUserModal;
        (modal as any).setAttribute('actualUserId', this.userId);
        this.appendChild(modal);
        await (modal as LitElement).updateComplete;
        const rectsModal = modal.getBoundingClientRect();
        modal.style.top = (rects.top - rectsModal.height - rects.height - 70) + 'px';
        modal.style.left = '20px';

    }

    private removeAllUserModal() {
        const all = this.querySelectorAll('collab-messages-user-modal-100554');
        all.forEach((item) => item.remove());
    }

    private renderMessageResultByLanguage(message: mls.msg.Message) {

        if (!message.taskResults || message.taskResults.length === 0 || message.taskStatus !== 'done') return html``;
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none') {
            return html`<div class="message-content">${message.taskResults[0]}</div>`
        }
        const response = message.taskResults[0];
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.taskResultsTranslated ? message.taskResultsTranslated[language] : '';
        const isSameLanguege = language === message.taskResultsTranslated?.language_detected;

        switch (mode) {
            case 'icon':
                return html`<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>`;
            case 'text':
                return html`
                <div class="message-content">${messageByLanguagePref || response}</div>
                ${!isSameLanguege ? html`<small class="message-content translate">${response}</small>` : ''}`;
            case 'iconText':
                return html`<div class="message-content">${messageByLanguagePref || response} ${!isSameLanguege ? collab_translate : ''}</div>
                ${!isSameLanguege ? html`<small class="message-content translate">${response}</small>` : ''}`;
            case 'trace':
                return html`<div class="message-content trace">
                <div><b>[LanguageDetected: ${message.language_detected}]</b> ${response}</div>
                ${Object.keys(message.taskResultsTranslated || {}).map((key) => {
                    if (key === 'language_detected') return ''
                    if (key === message.taskResultsTranslated?.language_detected) return ''
                    return html`<div><b>[${key}]</b> ${message.taskResultsTranslated ? message.taskResultsTranslated[key] : ''}</div>`
                })}
                </div>`
            default:
                return null;
        }
    }

    private getTitleMessageTranslated(message: mls.msg.Message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.taskTitleTranslated) {
            return message.taskTitle;
        }
        const { language } = this.userPreferenceChat;
        const titleByLanguagePref = message.taskTitleTranslated ? (message.taskTitleTranslated[language] ? message.taskTitleTranslated[language] : message.taskTitle) : message.taskTitle;
        return titleByLanguagePref;
    }

    private renderMessageByLanguage(message: mls.msg.Message) {
        const mode = this.userPreferenceChat?.translationMode || 'icon';
        if (!this.userPreferenceChat || mode === 'none' || !message.translations) {
            return html`
            <div class="message-content">
                ${this.renderCollabMessagesRichPreview(message.content)} 
            </div>`
        }
        const { language } = this.userPreferenceChat;
        const messageByLanguagePref = message.translations ? message.translations[language] : '';
        const isSameLanguege = language === message.language_detected;
        switch (mode) {
            case 'icon':
                return html`
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)} 
                     ${!isSameLanguege ? collab_translate : ''}
                </div>`;
            case 'text':
                return html`
                <div class="message-content">
                    ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                </div>
                ${!isSameLanguege ?
                        html`<small class="message-content translate">
                            ${this.renderCollabMessagesRichPreview(message.content)}   
                        </small>`
                        : ''}`;
            case 'iconText':
                return html`
                    <div class="message-content">
                        ${this.renderCollabMessagesRichPreview(messageByLanguagePref || message.content)}   
                        ${!isSameLanguege ? collab_translate : ''}
                    </div>
                ${!isSameLanguege ?
                        html`<small class="message-content translate">
                        ${this.renderCollabMessagesRichPreview(message.content)}    
                    </small>`
                        : ''
                    }`;
            case 'trace':
                return html`
                <div class="message-content trace">
                    <div>
                        <b>[LanguageDetected: ${message.language_detected}]</b>
                        ${this.renderCollabMessagesRichPreview(message.content)}   
                    </div>
                    ${Object.keys(message.translations).map((key) => {
                    if (key === 'language_detected') return ''
                    if (key === message.language_detected) return ''
                    return html`
                            <div>
                                <b>[${key}]</b>
                                ${this.renderCollabMessagesRichPreview(message.translations ? message.translations[key] : '')}                        
                            </div>`
                })}
                </div>`
            default:
                return null;
        }
    }

    private renderPrompt() {
        return html`
            <collab-messages-prompt-100554
                acceptAutoCompleteAgents="true"
                acceptAutoCompleteUser="true"
                threadId=${this.actualThread?.thread.threadId}
                .onSend=${this.handleSend.bind(this)}
                placeholder=${this.msg.promptPlaceholder}
                @textarea-resize=${this.handlePromptResize}
            ></collab-messages-prompt-100554>
        `;
    }

    private renderListThreads() {

        if (!this.userThreads[this.group] || (this.userThreads[this.group].length === 0 && !this.isLoadingThread)) {
            return html`<div style="padding:1rem;">${this.msg.noThreads}</div>`;
        }

        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);

        return html`
            ${this.renderThreadsByStatus()}
            ${this.isLoadingThread ? html`<div>${this.msg.loading}</div>` : ''}
        `;
    }

    private getThreadAvatar(item: IFilteredThreads) {
        let threadAvatar = this.imageUrls[Math.floor(Math.random() * this.imageUrls.length)];
        if (item.thread.name.startsWith('@') && item.thread.users.length === 2) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user && user.avatar_url) threadAvatar = user.avatar_url;
        } else if (item.thread.avatar_url) {
            threadAvatar = item.thread.avatar_url;
        }
        return threadAvatar;
    }

    private getThreadName(item: IThreadInfo | undefined) {

        if (!item) return '';
        if (item.thread.name.startsWith('@') && item.thread.users.length === 2) {
            const user = item.users.find((user) => user.userId !== this.userId);
            if (user) return '@' + user.name;
        }
        return item.thread.name || item.thread.threadId;
    }

    private renderThreadsByStatus() {

        return html`
        <ul class="thread-list">
            ${this.filteredThreads.active.map((item) => {

            let threadAvatar = this.getThreadAvatar(item);
            let threadName = this.getThreadName(item);
            let lastMessage: string = item.thread.lastMessage || '';
            const unreadCount = item.thread.unreadCount || 0;
            const now = new Date();
            const isToday =
                item._lastMessageDate.dateObject.getFullYear() === now.getFullYear() &&
                item._lastMessageDate.dateObject.getMonth() === now.getMonth() &&
                item._lastMessageDate.dateObject.getDate() === now.getDate();

            const displayDate = isToday
                ? item._lastMessageDate.time
                : item._lastMessageDate.date;

            if (item.users.length > 0) {
                const sortedUsers = [...item.users].sort((a, b) => b.name.length - a.name.length);

                lastMessage = lastMessage.replace(/\[@([^\]]+)\]\(([^)]+)\)/g, (_m, name, userId) => {
                    const user = sortedUsers.find(u => u.userId === userId);
                    if (!user) return `[@${name}]`;
                    return `@${user.name}`;
                });
            }

            return html`
                <li .item=${item} threadId=${item.thread.threadId} @click=${() => this.onThreadClick(item)} class="thread-item">
                    <div class="thread-item-avatar">
                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                    html`${unsafeHTML(threadAvatar)}` :
                    html`<img src="${threadAvatar}"></img>`
                }
                    </div>
                    <div class="thread-content">
                        <div class="thread-item-header">
                            <span class="thread-name">${threadName}</span>
                            <span class="last-update">${displayDate}</span>
                        </div>
                        <div class="thread-summary">
                            <span class="last-message">${lastMessage || ''}</span>
                            ${unreadCount > 0 ? html`<span class="unread-count">${unreadCount}</span>` : ''}
                        </div>
                    </div>
                </li>
                `;
        })}
            ${this.renderArchivedThreads()}
            ${this.renderDeletingThreads()}

        </ul>
        `
    }

    private renderArchivedThreads() {
        if (this.filteredThreads.archived.length === 0) return html``;
        return html`        
            ${this.filteredThreads.archived.map((item) => {

            let threadAvatar = this.getThreadAvatar(item);

            function isWithinLastWeek(date: Date): boolean {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }

            if (!item._lastMessageDateArchived) return html``

            return html`
                ${!isWithinLastWeek(item._lastMessageDateArchived.dateObject)
                    ? html``
                    : html`
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                            html`${unsafeHTML(threadAvatar)}` :
                            html`<img src="${threadAvatar}"></img>`
                        }
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.archived}) ${item.thread.name || item.thread.threadId}</span>
                                </div>
                            </div>
                        </li>`
                }`
        })}
        `
    }

    private renderDeletingThreads() {
        if (this.filteredThreads.deleting.length === 0) return html``;
        return html`        
            ${this.filteredThreads.deleting.map((item) => {

            let threadAvatar = this.getThreadAvatar(item);

            function isWithinLastWeek(date: Date): boolean {
                const now = new Date();
                const oneWeekAgo = new Date();
                oneWeekAgo.setDate(now.getDate() - 7);
                return date >= oneWeekAgo;
            }

            if (!item.lastMessageDateDeleting) return html``

            return html`
                ${!isWithinLastWeek(item.lastMessageDateDeleting.dateObject)
                    ? html``
                    : html`
                        <li @click=${() => this.onThreadClick(item)} class="thread-item">
                            <div class="thread-item-avatar">
                                    ${threadAvatar.startsWith('<') && threadAvatar.endsWith('>') ?
                            html`${unsafeHTML(threadAvatar)}` :
                            html`<img src="${threadAvatar}"></img>`
                        }
                            </div>
                            <div class="thread-content">
                                <div class="thread-item-header">
                                    <span class="thread-name">(${this.msg.deleting}) ${item.thread.name || item.thread.threadId}</span>
                                </div>
                            </div>
                        </li>`
                }`
        })}
        `
    }

    private renderThreadSearch() {
        return html`<div class="thread-search">
                <input type="search"
                    .value=${this.searchTerm}
                    placeholder=${this.msg.placeholderSearch} 
                    @input=${this.onSearchInput} 
                    type="text">
                </input>
        </div>`
    }

    private renderTaskDetails() {
        const messageId = `${this.actualThread?.thread.threadId}/${this.actualMessage?.createAt}`
        return html`<collab-messages-task-info-100554 messageId=${messageId} .task=${this.actualTask} .message=${this.actualMessage} taskId=${this.actualTask?.PK}></collab-messages-task-info-100554>`
    }

    private renderThreadDetails() {
        return html`<collab-messages-thread-details-100554 userId=${this.userId} .threadDetails=${{ ...this.actualThread }}></collab-messages-thread-details-100554>`
    }

    private renderThreadAdd() {
        return html`
            <collab-messages-add-100554 
                .onAddSuccess = ${() => { this.activeScenerie = 'list' }}
                .group=${this.group}
                userId=${this.userId} 
            ></collab-messages-add-100554>`
    }

    private onSearchInput(e: Event) {
        const target = e.target as HTMLInputElement;
        this.searchTerm = target.value.toLowerCase();
        const ordenedThreads = this.getOrdenedThreadsByStatus();
        this.filteredThreads = this.getFilteredThreads(ordenedThreads);
    }

    private async updateMessagesAfterScrollMore(newMessages: mls.msg.MessagePerformanceCache[], container: HTMLElement, previousHeight: number) {

        this.actualMessages = [...this.actualMessages, ...newMessages];
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateComplete;
        const newHeight = container.scrollHeight;
        container.scrollTop = newHeight - previousHeight;
    }

    private async getBeforeMessagesInServer(thread: mls.msg.ThreadPerformanceCache) {
        const firstItem = [...this.actualMessages].sort((a, b) => a.orderAt.localeCompare(b.orderAt))[0];
        const response = await this.getMessagesBefore(thread, firstItem.orderAt);
        const newMessages = response?.data;
        this.hasMoreMessagesBefore = response?.hasMore || false;
        return newMessages;
    }

    private async onChatScroll(e: Event) {

        this.removeAllUserModal();
        if (this.isChangeTopics) {
            this.isChangeTopics = false;
            return;
        }

        if (this.isSystemChangeScroll) {
            this.isSystemChangeScroll = false;
            return;
        }

        const container = e.target as HTMLElement;
        this.savedScrollTop = container.scrollTop;
        const threshold = 5;
        this.wasMessagesAtBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - threshold;
        const previousHeight = container.scrollHeight;

        if (
            container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            !this.hasMoreMessagesLocalDB &&
            this.hasMoreMessagesBefore
        ) {
            this.isLoadingMoreMessages = true;
            const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
            if (newMessages) this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, previousHeight);
            this.isLoadingMoreMessages = false;
            return;
        }

        if (
            container.scrollTop === 0 &&
            !this.isLoadingMoreMessages &&
            this.actualThread &&
            this.hasMoreMessagesLocalDB
        ) {

            this.isLoadingMoreMessages = true;
            const newOffset = this.messagesOffset + this.messagesLimit;
            const newMessages = await getMessagesByThreadId(
                this.actualThread.thread.threadId,
                this.messagesLimit,
                newOffset
            );

            if (newMessages.length > 0) {
                this.messagesOffset = newOffset;
                this.updateMessagesAfterScrollMore(newMessages, container, previousHeight);
            } else {
                const newMessages = await this.getBeforeMessagesInServer(this.actualThread.thread);
                if (newMessages) this.updateMessagesAfterScrollMore(newMessages.map(item => ({ ...item, footers: [], })), container, previousHeight);
                this.hasMoreMessagesLocalDB = false;
            }

            this.isLoadingMoreMessages = false;
        }
    }

    private getOrdenedThreadsByStatus(): IFilteredThreadsByStatus {
        const threads = this.userThreads[this.group]
            .map((item) => {
                const lastTimestamp = item.thread.lastMessageTime
                    ? item.thread.lastMessageTime
                    : item.thread.history[0].timestamp;

                const formatedTimestamp = formatTimestamp(lastTimestamp)?.dateFull;
                const lastMessageDate = this.parseLocalDate(formatedTimestamp || '');
                let lastMessageDateArchived;
                let lastMessageDateDeleting;

                if (item.thread.status === 'archived' && item.thread.archivedAt) {
                    const formatedTimestampArchived = formatTimestamp(item.thread.archivedAt)?.dateFull;
                    lastMessageDateArchived = this.parseLocalDate(formatedTimestampArchived || '');
                }

                if (item.thread.status === 'deleting' && item.thread.deletedAt) {
                    const formatedTimestampArchived = formatTimestamp(item.thread.deletedAt)?.dateFull;
                    lastMessageDateDeleting = this.parseLocalDate(formatedTimestampArchived || '');
                }

                return {
                    ...item,
                    _lastMessageDate: lastMessageDate,
                    _lastMessageDateArchived: lastMessageDateArchived,
                    lastMessageDateDeleting: lastMessageDateDeleting,

                };
            })
            .sort((a, b) =>
                b._lastMessageDate.dateObject.getTime() -
                a._lastMessageDate.dateObject.getTime()
            );

        const result = {
            archived: [] as IFilteredThreads[],
            deleted: [] as IFilteredThreads[],
            deleting: [] as IFilteredThreads[],
            active: [] as IFilteredThreads[],
        };

        for (const threadInfo of threads) {
            if (threadInfo.thread.status === 'archived') {
                result.archived.push(threadInfo);
            } else if (threadInfo.thread.status === 'deleted') {
                result.deleted.push(threadInfo);
            } else if (threadInfo.thread.status === 'deleting') {
                result.deleting.push(threadInfo);
            } else {
                result.active.push(threadInfo);
            }
        }

        return result;
    }
    private getFilteredThreads(ordened: IFilteredThreadsByStatus): IFilteredThreadsByStatus {
        if (!this.searchTerm) return ordened;

        const term = this.searchTerm.toLowerCase();

        Object.keys(ordened).forEach((key: string) => {
            const key2 = key as 'deleted' | 'archived' | 'active' | 'deleting';

            ordened[key2] = ordened[key2].filter(item => {
                const threadName = item.thread.name?.toLowerCase() ?? '';

                if (threadName.startsWith('@')) {
                    const users = item.thread.users
                        .map(u => this.usersAvaliables.find(au => au.userId === u.userId));
                    return users.some(user =>
                        (`@${user?.name.toLowerCase()}`).includes(term)
                    );
                }

                return threadName.includes(term);
            });
        });

        return ordened;
    }

    private async getMessagesAfter(thread: mls.msg.Thread, lastOrderAt: string = ''): Promise<mls.msg.ResponseGetMessagesAfter | undefined> {
        if (!this.userId) {
            return undefined;
        }
        const response = await mls.api.msgGetMessagesAfter({
            lastOrderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        return response;

    }

    private async getMessagesBefore(thread: mls.msg.Thread, orderAt: string = ''): Promise<mls.msg.ResponseGetMessagesAfter | undefined> {
        if (!this.userId) {
            return undefined;
        }
        const response = await mls.api.msgGetMessagesBefore({
            orderAt,
            threadId: thread.threadId,
            userId: this.userId
        });
        return response;

    }

    private parseMessages(
        rawData: mls.msg.MessagePerformanceCache[],
        topic: string
    ): IMessageGrouped {
        const groupedByDay: IMessageGrouped = {};

        [...rawData].forEach(msg => {

            if (
                topic &&
                msg.content &&
                !(
                    msg.content.startsWith(`${topic} `) ||
                    msg.content.endsWith(` ${topic}`) ||
                    msg.content.includes(` ${topic} `)
                )
            ) {
                return;
            }

            const formatted = formatTimestamp(msg.createAt);
            const dateKey =
                formatted?.date ||
                msg.createAt
                    .slice(0, 8)
                    .replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');

            if (!groupedByDay[dateKey]) {
                groupedByDay[dateKey] = [];
            }
            groupedByDay[dateKey].push(msg);
        });


        for (const day in groupedByDay) {
            groupedByDay[day].sort((a, b) =>
                a.orderAt.localeCompare(b.orderAt)
            );
        }

        return this.groupMessages(groupedByDay);
    }

    private groupMessages(groupedByDay: IMessageGrouped): IMessageGrouped {
        const result: IMessageGrouped = {};

        Object.keys(groupedByDay).forEach((key) => {
            let consecutiveCount = 0;
            let lastSenderId: string | null = null;

            result[key] = groupedByDay[key].map((msg, index, arr) => {
                let isSame = false;

                if (msg.senderId === lastSenderId) {
                    consecutiveCount++;
                    isSame = true;
                    if (consecutiveCount >= 3) {
                        consecutiveCount = 0;
                        isSame = false;
                    }

                } else {
                    consecutiveCount = 0;
                    isSame = false;
                    lastSenderId = msg.senderId;
                }

                return { ...msg, isSame };
            });
        });

        return result;
    }

    private parseLocalDate(dateString: string) {

        const normalized = dateString.includes(' ')
            ? dateString.replace(' ', 'T')
            : `${dateString}T00:00:00`;

        const date = new Date(normalized);

        return {
            dateObject: date,
            datafull: date.toLocaleString(),
            date: date.toLocaleDateString(),
            time: date.toTimeString().split(' ')[0]
        };
    }

    private mergeMessages(
        array1: mls.msg.MessagePerformanceCache[],
        array2: mls.msg.MessagePerformanceCache[]
    ): mls.msg.MessagePerformanceCache[] {
        const map = new Map<string, mls.msg.MessagePerformanceCache>();
        for (const item of array1) {
            map.set(`${item.threadId}/${item.createAt}`, item);
        }
        for (const item of array2) {
            map.set(`${item.threadId}/${item.createAt}`, { ...map.get(`${item.threadId}/${item.createAt}`), ...item });
        }
        return Array.from(map.values());
    }

    private async onThreadClick(threadInfo: IThreadInfo) {

        this.welcomeMessage = '';
        this.activeScenerie = 'loading';
        this.lastTopicFilter = '';
        this.messagesOffset = 0;
        this.hasMoreMessagesLocalDB = true;
        this.hasMoreMessagesBefore = false;
        this.actualThread = threadInfo;
        const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
        this.actualMessages = messagesInDb;
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.activeScenerie = 'details';
        this.isLoadingMessages = true;
        this.isThreadError = false;
        this.threadErrorMsg = '';
        this.checkWelcomeMessage(this.actualThread.thread, messagesInDb);

        try {
            if (!this.userId) return;
            const threadByServer = await this.getThreadInfo(this.actualThread.thread.threadId, this.userId, threadInfo.thread.lastMessageTime || new Date('2000-01-01').toISOString());

            await updateThread(threadByServer.thread.threadId, threadByServer.thread);

            threadInfo = await this.updateMessagesOnDb(threadByServer, threadByServer.messages);

            await updateUsers(threadByServer.users);
            // this.allUsersInThread = threadByServer.users;
            this.actualThread = { ...threadByServer };
            if (threadByServer.hasMore) await this.loadAllMessages(threadInfo);
            this.checkForRegisterNotification();

            if (threadByServer.threadsPending) {
                for await (let threadsPending of threadByServer.threadsPending) {
                    if (threadsPending !== threadInfo.thread.threadId) {
                        removeThreadFromSync(threadsPending);
                        await getThreadUpdateInBackground(threadsPending);
                    }
                }
            }

            if (['deleted'].includes(threadByServer.thread.status)) {
                await deleteAllMessagesFromThread(threadByServer.thread.threadId);
                notifyThreadChange(threadByServer.thread)
            }

            this.checkNotificationsUnreadMessages();


        } catch (err: any) {
            this.isThreadError = true;
            this.threadErrorMsg = err.message || 'Error on read thread';
            throw new Error('Error on loading messages: ' + err.message);
        } finally {
            this.isLoadingMessages = false;
        }
    }

    private checkWelcomeMessage(thread: mls.msg.ThreadPerformanceCache, messagesInDb: mls.msg.MessagePerformanceCache[]) {
        if (messagesInDb.length > 0) return;
        if (!thread.welcomeMessage) return;
        this.welcomeMessage = thread.welcomeMessage;
    }

    private async checkNotificationsUnreadMessages() {
        const hasPendingMessages = await checkIfNotificationUnread();
        if (!hasPendingMessages) {
            setFavicon(false);
            mls.services['100554_serviceCollabMessages_left']?.toogleBadge(false, '_100554_serviceCollabMessages');
        }
    }
    private alreadyCheckForRegisterToken: boolean = false;
    private async checkForRegisterNotification() {
        if (this.alreadyCheckForRegisterToken) return;
        this.alreadyCheckForRegisterToken = true;
        const notificationPreference = loadNotificationPreferences();
        if (notificationPreference === 'denied') return;
        await registerToken();
    }

    private async loadAllMessages(threadInfo: IThreadInfo): Promise<void> {
        const response = await this.getMessagesAfter(threadInfo.thread, threadInfo.thread.lastMessageTime || '');
        if (!response || !response.data || response.data.length === 0 || !this.actualThread || !this.userId) {
            return;
        }
        threadInfo = await this.updateMessagesOnDb(threadInfo, response.data);
        if (!response.hasMore) return;
        return this.loadAllMessages(threadInfo);
    }

    private async updateMessagesOnDb(threadInfo: IThreadInfo, messages: mls.msg.Message[] | undefined) {
        if (!messages) return threadInfo;
        const newMessages: mls.msg.MessagePerformanceCache[] = [];
        for await (let mm of messages) {
            const messageId = `${mm.threadId}/${mm.createAt}`
            const messageOld = await getMessage(messageId);
            const tempMessage: mls.msg.MessagePerformanceCache = { ...mm, footers: messageOld?.footers || [] };
            newMessages.push(tempMessage);
        }
        await addMessages(newMessages);
        this.actualMessages = this.mergeMessages(this.actualMessages, newMessages);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        await this.updateLastMessage(threadInfo);
        return threadInfo;
    }

    private async updateLastMessage(threadInfo: IThreadInfo) {
        const keys = Object.keys(this.actualMessagesParsed).sort();
        const lastKey = keys.length > 0 ? keys[keys.length - 1] : null;
        const lastArray = lastKey ? this.actualMessagesParsed[lastKey] : [];
        const lastMessage = lastArray.length > 0 ? lastArray[lastArray.length - 1] : undefined;
        if (lastMessage) {
            const thread = await updateThread(
                threadInfo.thread.threadId,
                threadInfo.thread,
                lastMessage.content,
                lastMessage.createAt,
                0
            );
            threadInfo.thread = thread;
            notifyThreadChange(thread);
        }
    }

    private async onTitleClick() {
        await this.updateComplete;
        if (this.activeScenerie === 'task') {
            this.activeScenerie = 'details';
            return;
        }
        if (this.activeScenerie === 'details' || this.activeScenerie === 'threadAdd') {
            this.actualThread = undefined;
            this.activeScenerie = 'list';
            return;
        }
        if (this.activeScenerie === 'threadDetails') {
            this.activeScenerie = 'details';
            return;
        }
    }

    private onThreadDetailsClick() {
        this.saveScrollPosition();
        this.activeScenerie = 'threadDetails';
    }

    private onThreadAddClick() {
        this.activeScenerie = 'threadAdd';
    }

    private async handleSend(value: string, opt: { isSpecialMention: boolean, agentName: string }) {
        this.isSystemChangeScroll = true;
        this.lastTopicFilter = '';
        try {
            if (!opt.isSpecialMention) {
                await this.addMessage(value);
            } else {
                await this.addMessageIA(value, opt.agentName);
            }
        } catch (err: any) {
            throw new Error(err.message);
        }
    }

    private handlePromptResize(e: CustomEvent) {
        if (this.wasMessagesAtBottom) {
            const chatEl = this.querySelector('.chat-container') as HTMLElement | null;
            if (chatEl) chatEl.scrollTop = chatEl.scrollHeight;
        }
    }

    private async addMessage(prompt: string) {
        if (!this.userId || !this.actualThread) return;

        const message: IMessage = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId);
        try {
            const context: mls.msg.ExecutionContext = {
                message,
                task: undefined
            }
            const contextToBot = await getBotsContext(this.actualThread.thread, prompt, context);
            const params: mls.msg.RequestAddMessage = {
                action: 'addMessage',
                content: prompt,
                threadId: this.actualThread.thread.threadId,
                userId: this.userId,
            };
            if (contextToBot) params.contextToBot = contextToBot;
            const response = await mls.api.msgAddMessage(params);
            message.isFailed = false;
            message.isFailedError = '';
            this.updateMessage2(false, true, message, response.message, response.botOutputs);
        } catch (err: any) {
            message.isFailed = true;
            message.isFailedError = err.message;
            message.isLoading = false;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            console.error('Error on send message:' + err.message);
        }
    }

    private async addMessageIA(prompt: string, agentName: string) {
        if (!this.userId || !this.actualThread) return;
        const context = getTemporaryContext(this.actualThread.thread.threadId, this.userId, prompt);
        let agentToCall = AGENTDEFAULT;
        if (agentName) agentToCall = agentName;
        const message: IMessage = await this.createTempMessage(prompt, this.userId, this.actualThread.thread.threadId);
        try {
            const moduleAgent = await collabImport({ project: PROJECTAGENTDEFAULT, shortName: agentToCall, folder: '' });
            if (!moduleAgent || !moduleAgent.createAgent || typeof moduleAgent.createAgent !== 'function') throw new Error('Invalid agent')
            const agent: IAgent = moduleAgent.createAgent()
            context.message = message;
            await agent.beforePrompt(context);
        } catch (err: any) {
            console.error('Error on send message:' + err.message);
            if (message.isLoading) {
                message.isLoading = false;
                message.isFailed = true;
                message.isFailedError = err.message;
                this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            }
        }
    }

    private async updateMessageAI(context: mls.msg.ExecutionContext, updateThreadDB: boolean, oldContextCreateAt?: string) {

        if (this.activeScenerie !== 'details') return;
        if (!context.message) return;

        const { content, createAt, orderAt, senderId, threadId, taskId, status, taskTitle, taskTitleTranslated, taskStatus,
            taskResults, taskResultsTranslated } = context.message;
        const createAt2 = oldContextCreateAt ? oldContextCreateAt : createAt;
        let messageAdded = this.actualMessages.find((item) =>
            item.content === content &&
            item.senderId === senderId &&
            item.createAt === createAt2 &&
            item.threadId === threadId
        )
        if (!messageAdded) {
            const newMessage: mls.msg.MessagePerformanceCache = {
                content,
                createAt,
                orderAt,
                senderId,
                threadId,
                footers: []
            }
            if (updateThreadDB && this.actualThread) {
                const thread = await updateThread(threadId, this.actualThread.thread, content, createAt, 0);
                if (this.actualThread) this.actualThread.thread = thread;
            }
            if (taskId) newMessage.taskId = taskId;
            this.actualMessages.unshift({ context, lastChanged: new Date().getTime(), ...newMessage });
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(newMessage);
            this.requestUpdate();
        } else {

            messageAdded.content = content;
            messageAdded.senderId = senderId;
            messageAdded.createAt = createAt;
            messageAdded.threadId = threadId;
            messageAdded.orderAt = orderAt;
            if (status) messageAdded.status = status;
            if (taskTitle) messageAdded.taskTitle = taskTitle;
            if (taskTitleTranslated) messageAdded.taskTitleTranslated = taskTitleTranslated;
            if (taskStatus) messageAdded.taskStatus = taskStatus;
            if (taskResults) messageAdded.taskResults = taskResults;
            if (taskResultsTranslated) messageAdded.taskResultsTranslated = taskResultsTranslated;
            messageAdded.context = context;
            messageAdded.isLoading = false;
            messageAdded.lastChanged = new Date().getTime();
            if (taskId) messageAdded.taskId = taskId;
            const cloned = structuredClone(messageAdded);
            delete cloned.context;
            delete cloned.isLoading;
            delete cloned.lastChanged;

            if (oldContextCreateAt) this.isSystemChangeScroll = true;
            this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
            await addMessage(cloned);
            this.requestUpdate();

        }
    }

    private async createTempMessage(content: string, senderId: string, threadId: string, taskId?: string) {
        const now = new Date();
        const formattedDate = now.getFullYear().toString()
            + String(now.getMonth() + 1).padStart(2, '0')
            + String(now.getDate()).padStart(2, '0')
            + String(now.getHours() + 3).padStart(2, '0')
            + String(now.getMinutes()).padStart(2, '0')
            + String(now.getSeconds()).padStart(2, '0')
            + "." + Math.floor(1000 + Math.random() * 9000);
        const newMessage: IMessage = {
            content,
            createAt: formattedDate,
            orderAt: formattedDate,
            senderId,
            threadId,
            isLoading: true,
            isFailed: false,
            isFailedError: '',
            footers: []
        }
        if (taskId) newMessage.taskId = taskId;
        this.actualMessages.unshift(newMessage);
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
        this.requestUpdate();
        return newMessage;
    }

    private async updateMessage2(updateCreateAtThreadDB: boolean, updateLastMessageThreadDB: boolean, oldMessage: IMessage, newMessage: mls.msg.Message, outputs: mls.msg.BotOutput[] | undefined) {

        if (this.actualThread && (updateCreateAtThreadDB || updateLastMessageThreadDB)) {

            const thread = await updateThread(
                newMessage.threadId,
                this.actualThread.thread,
                updateLastMessageThreadDB ? newMessage.content : undefined,
                updateCreateAtThreadDB ? newMessage.createAt : undefined,
                0);
            if (this.actualThread) this.actualThread.thread = thread;
            notifyThreadChange(this.actualThread.thread);
        }

        const footerData: IMessageFooter[] = [];

        outputs?.forEach((item) => {
            const footerItem: IMessageFooter = {
                title: item.botId,
                lines: [item.output]
            }
            footerData.push(footerItem)
        });

        const alreadyExist = this.actualMessages.find(item =>
            item.content === oldMessage.content &&
            item.senderId === oldMessage.senderId &&
            item.createAt === oldMessage.createAt &&
            item.threadId === oldMessage.threadId);
        if (alreadyExist) {
            this.actualMessages = this.actualMessages.map(item => {
                if (
                    item.content === oldMessage.content &&
                    item.senderId === oldMessage.senderId &&
                    item.createAt === oldMessage.createAt &&
                    item.threadId === oldMessage.threadId
                ) {
                    const { isLoading, isFailed, isFailedError, ...rest }: IMessage = { ...newMessage, isSame: oldMessage.isSame, footers: footerData };
                    return rest;
                }
                return item;
            });
        } else this.actualMessages.unshift({ ...newMessage, footers: footerData });
        this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);

        const m = newMessage as IMessage;
        delete m.isLoading;
        delete m.isFailed;
        delete m.isFailedError;
        delete m.isSame;
        if (outputs) m.footers = footerData;
        addMessage(m);
        this.requestUpdate();
    }

    private async onTaskClick(taskId: string, messageId: string, threadId: string, message: IMessage) {
        this.saveScrollPosition();
        // this.activeScenerie = 'loading';
        const task = await this.getTaskUpdate(taskId, messageId, threadId);
        addOrUpdateTask(task);
        this.actualTask = task;
        this.actualMessage = message;

        const messageId2 = `${this.actualThread?.thread.threadId}/${this.actualMessage?.createAt}`
        const el = document.createElement('collab-messages-task-info-100554');
        el.setAttribute('messageId', messageId2);
        if (this.actualTask && this.actualTask.PK) el.setAttribute('taskId', this.actualTask.PK);
        (el as any)['task'] = this.actualTask;
        (el as any)['message'] = this.actualMessage;
        openElementInServiceDetails(el);
        // this.activeScenerie = 'task';
    }

    private async getTaskUpdate(taskId: string, createdAt: string, threadId: string) {
        if (!taskId || !createdAt || !threadId) throw new Error('Invalid args');
        if (!this.userId) throw new Error('Invalid userId');
        const taskData = await mls.api.msgGetTaskUpdate(
            {
                taskId,
                messageId: `${threadId}/${createdAt}`,
                userId: this.userId
            }
        );
        if (taskData.statusCode !== 200) throw new Error("error on AI get taskUpdate , stoped");
        return taskData.task;
    }

    private async getThreadInfo(threadId: string, userId: string, lastOrderAt: string): Promise<mls.msg.ResponseGetThreadUpdate> {
        const deviceId = loadNotificationDeviceId();

        try {
            const response = await mls.api.msgGetThreadUpdate({
                threadId,
                userId,
                lastOrderAt,
                deviceId: deviceId || undefined
            });
            removeThreadFromSync(threadId);

            if (response.statusCode === 403) {
                throw new Error(response.msg);
            }

            return response;
        } catch (err: any) {
            throw new Error(err.message)
        }
    }

    private saveScrollPosition() {
        if (this.messageContainer) {
            this.savedScrollTop = this.messageContainer.scrollTop;
        }
    }

    private async restoreScrollPosition() {
        if (this.messageContainer) {
            await this.updateComplete;
            this.messageContainer.scrollTop = this.savedScrollTop;
        }
    }
    private onTaskChange = async (e: Event) => {
        const customEvent = e as CustomEvent;
        const message: mls.msg.Message = customEvent.detail.context.message;
        const task: mls.msg.TaskData = customEvent.detail.context.task;
        const thId = message?.threadId;
        if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId) return;
        await this.updateMessageAI(customEvent.detail.context, false, customEvent.detail.oldContextCreateAt);
        if (task) await addOrUpdateTask(customEvent.detail.context.task);
    };



    private onTaskDetailsClose = async (_e: Event) => {
        clearServiceDetails();
    };

    private onThreadChange = async (e: Event) => {

        const customEvent = e as CustomEvent;
        await this.updateMessageAI(customEvent.detail, false);
        const thread = customEvent.detail as mls.msg.Thread;
        const threadUpdated = this.userThreads[this.group].find((th) => th.thread.threadId === thread.threadId);

        if (['deleted'].includes(thread.status)) {
            await deleteAllMessagesFromThread(thread.threadId);
        }

        if (threadUpdated) threadUpdated.thread = { ...threadUpdated.thread, ...thread };
        else if (thread.group === this.group) {
            this.userThreads[this.group] = [...this.userThreads[this.group], { thread, hasMore: false, users: [] }];
        }

        if (threadUpdated?.thread.threadId === this.actualThread?.thread.threadId) {
            this.actualThread = threadUpdated;
            if (this.actualThread && this.actualThread.thread.unreadCount && this.actualThread.thread.unreadCount > 0) {
                const chatEl = this.querySelector('.chat-container') as HTMLElement | null;
                if (chatEl) {
                    const isScrolledToBottom = chatEl.scrollTop + chatEl.clientHeight >= chatEl.scrollHeight - 1;
                    if (isScrolledToBottom) this.isSystemChangeScroll = true;
                }
                const messagesInDb = await getMessagesByThreadId(this.actualThread.thread.threadId, this.messagesLimit, 0);
                this.actualMessages = messagesInDb;
                this.actualMessagesParsed = this.parseMessages(this.actualMessages, this.lastTopicFilter);
                await this.updateLastMessage(this.actualThread);
            }
        }

        if (this.activeScenerie === 'threadDetails' && (
            thread.status === 'deleted' ||
            thread.status === 'deleting' ||
            thread.status === 'archived'
        )) {
            this.activeScenerie = 'list';
        }

        this.requestUpdate();
    };

    private onMessageSend = async (e: Event) => {
        const customEvent = e as CustomEvent;
        const message: mls.msg.Message = customEvent.detail.context.message;
        const outputs: mls.msg.BotOutput[] = customEvent.detail.context.botOutput;
        const thId = message?.threadId;
        if (!this.actualThread || !thId || thId !== this.actualThread.thread.threadId) return;
        this.updateMessage2(false, true, { ...message, footers: [] }, message, outputs);
    };

}

interface IThreadInfo {
    thread: mls.msg.ThreadPerformanceCache,
    threadsPending?: string[],
    users: mls.msg.User[],
    hasMore?: boolean | undefined,
    messages?: mls.msg.Message[] | undefined
}

interface IMessage extends mls.msg.MessagePerformanceCache {
    context?: mls.msg.ExecutionContext,
    lastChanged?: number,
    isSame?: boolean,
    isLoading?: boolean,
    isFailed?: boolean,
    isFailedError?: string,
}

interface IMessageFooter {
    title?: string;
    lines: string[];
    icon?: string; // icon to show in footer, ex: "fa fa-check"
    color?: string; // color of the footer, ex: "#00ff00"
    backgroundColor?: string; // background color of the footer, ex: "#000000"
    timestamp?: string;
}

interface IFilteredThreadsByStatus {
    archived: IFilteredThreads[];
    deleted: IFilteredThreads[];
    deleting: IFilteredThreads[];
    active: IFilteredThreads[];
}

interface IHTMLLiThreadItem extends HTMLElement {
    item: IThreadInfo
}

interface IFilteredThreads {
    _lastMessageDate: {
        dateObject: Date;
        datafull: string;
        date: string;
        time: string;
    };
    _lastMessageDateArchived?: {
        dateObject: Date;
        datafull: string;
        date: string;
        time: string;
    };
    lastMessageDateDeleting?: {
        dateObject: Date;
        datafull: string;
        date: string;
        time: string;
    };
    hasMore?: boolean | undefined,
    thread: mls.msg.ThreadPerformanceCache;
    users: mls.msg.User[];
}
type IMessageGrouped = { [key: string]: IMessage[] }
type IThread = { [key: string]: IThreadInfo[] }
type IScenery = 'list' | 'details' | 'loading' | 'task' | 'threadDetails' | 'threadAdd'
