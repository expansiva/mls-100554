/// <mls fileReference="_100554_/l2/docMd.ts" enhancement="_102027_/l2/enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let DocMd = class DocMd extends CollabLitElement {
    constructor() {
        super(...arguments);
        this._html = '';
    }
    connectedCallback() {
        this.oriHtml = this.innerHTML;
        this.innerHTML = '';
        super.connectedCallback();
    }
    firstUpdated() {
        this.init();
    }
    render() {
        return html `
            <div class="preview">${unsafeHTML(this._html)}</div>

        `;
    }
    async _importMarked() {
        const url = 'https://cdn.jsdelivr.net/npm/marked@17.0.4/lib/marked.esm.js';
        const mod = await import(url);
        this._marked = mod.marked;
    }
    async _parse() {
        if (!this._marked)
            return;
        this.style.display = '';
        this._html = await this._marked(this.oriHtml);
    }
    async init() {
        await this._importMarked();
        this._parse();
    }
};
__decorate([
    state()
], DocMd.prototype, "_html", void 0);
DocMd = __decorate([
    customElement('doc-md-100554')
], DocMd);
export { DocMd };
