/// <mls shortName="collabDsInputRange" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, css, repeat } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from './_100554_collabLitElement';
import { IcaLitElement, propertyDataSource } from './_100554_icaLitElement';

export function initCollabDSInputRange() { };

@customElement('collab-ds-input-range-100554')
export class CollabDSInputRange extends IcaLitElement {

    public arraySelect: string[] = [];

    @property() useSelect: string = 'true';

    @property() value: string = '';

    @property() prop: string = '';

    min: number = 0;

    max: number = 100;

    render() {

        //${this.renderInput()}
        return html`
            ${this.renderSelect()}
            
        `
    }

    renderSelect() {
        return html`
            <div>
                <input type="number" .value="${this.onlyNumber(this.value)}" @input="${this.changeInput}"> </input>
                <select @change="${this.changeSelect}" style="${this.useSelect === 'false' ? 'display:none' : ''}">
                    ${repeat(this.arraySelect, ((key: any) => key) as any,
            ((k: any, index: any) => {

                return html`<option value="${k}">${k}</option>`;

            }) as any
        )}
                </select>
            </div>
        `;
    }

    updated() {
        const sel = this.querySelector('select') as HTMLSelectElement;
        if (!sel) return;
        sel.value = this.onlyTxt(this.value);
    }

    //---------IMPLEMENTS-------------

    private onlyNumber(str: string): string {
        const regexNum = /(\d+(?:\.\d+)?)/;
        const res = str.match(regexNum);
        return res && (res as any)[0] ? (res as any)[0] as string : '';
    }

    private onlyTxt(str: string): string {
        const regexStr = /[a-zA-Z]+/;
        const res = str.match(regexStr);
        return res && (res as any)[0] ? ((res as any)[0] as string).replace('.', '') : 'px';
    }

    private changeInput(e: InputEvent): void {
        this.allChange(e, 'input')
    }

    private changeSelect(e: InputEvent): void {
        this.allChange(e, 'sel')
    }

    private allChange(e: InputEvent, mode: string): void {

        e.stopPropagation();
        let input = this.querySelector('input[type="number"]') as HTMLInputElement;
        let sel = this.querySelector('select') as HTMLSelectElement;
        if (!input || !sel ) return;
        this.value = input.value + sel.value;

        this.fireEvents(
            {
                key: this.prop,
                value: input.value + sel.value
            }
        );

    }

    private fireEvents(obj: any): void {

        obj.target = this;
        const onChangePropEvento = new CustomEvent('onchange', {
            bubbles: true,
            detail: obj
        });

        this.dispatchEvent(onChangePropEvento);
    }


}
