/// <mls shortName="collabMessagesAvatar" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, css } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { IcaLitElement } from './_100554_icaLitElement';
import { collab_user } from './_100554_collabIcons';

@customElement('collab-messages-avatar-100554')
export class CollabMessagesAvatar100554 extends IcaLitElement {

    @property() avatar: string = '';
    @property({ type: String }) width = '30px';
    @property({ type: String }) height = '30px';

    updated(changedProperties: Map<string, any>) {
        super.updated(changedProperties);
        if (changedProperties.has('width') || changedProperties.has('height')) {
            this.style.setProperty('--avatar-width', this.width);
            this.style.setProperty('--avatar-height', this.height);
        }
    }

    render() {
        
        return html`
        <div class="avatar">
            ${this.avatar
                ? html`<img src="${this.avatar}" alt="Avatar" />`
                : html`<div class="avatar-placeholder">${collab_user}</div>`
            }
        </div>`;
    }
}
