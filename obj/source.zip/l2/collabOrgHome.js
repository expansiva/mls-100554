/// <mls fileReference="_100554_/l2/collabOrgHome.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    loading: 'Carregando organização…',
    again: 'Tentar novamente',
    error: 'Erro desconhecido',
    projects: 'Projetos',
    users: 'Usuários',
    teams: 'Times',
};
const message_en = {
    loading: 'Loading organization…',
    again: 'Try again',
    error: 'Unknown error',
    projects: 'Projects',
    users: 'Users',
    teams: 'Teams',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
const MOCK_ORG_DATA = {
    name: 'Collab Codes',
    description: 'Plataforma colaborativa de desenvolvimento low-code.',
    totalProjects: 42,
    totalUsers: 18,
    totalTeams: 5,
};
let CollabOrgHome = class CollabOrgHome extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.msg = messages['en'];
        this.project = 0;
        this._loading = false;
        this._error = '';
        this._data = null;
    }
    connectedCallback() {
        super.connectedCallback();
        this._fetchOrg();
    }
    async _fetchOrg() {
        this._loading = true;
        this._error = '';
        this._data = null;
        this.requestUpdate();
        try {
            const idxOrg = mls.l5.getProjectOrgIndex(this.project) || -1;
            const orgName = mls.l5.getOrgsName()[idxOrg];
            const lastOrg = mls.stor.orgs[orgName];
            if (!lastOrg) {
                this._error = 'Not found organization';
                return;
            }
            this._data = {
                name: orgName,
                description: lastOrg.sett.description,
                totalProjects: lastOrg.sett.projects.length,
                totalUsers: lastOrg.sett.users.length,
                totalTeams: lastOrg.sett.teams.length,
            };
        }
        catch (err) {
            this._error = err instanceof Error ? err.message : this.msg.error;
        }
        finally {
            this._loading = false;
            this.requestUpdate();
        }
    }
    _renderLoading() {
        return html `
            <div class="state-loading">
                <span class="spinner"></span>
                <span>${this.msg.loading}</span>
            </div>
        `;
    }
    _renderError() {
        return html `
            <div class="state-error">
                <span class="error-icon">⚠</span>
                <span>${this._error}</span>
                <button @click="${() => this._fetchOrg()}">${this.msg.again}</button>
            </div>
        `;
    }
    _renderData(data) {
        return html `
            <div class="org-card">
                <div class="org-header">
                    <h1 class="org-name">${data.name}</h1>
                    <p class="org-description">${data.description || 'no description'}</p>
                </div>
                <div class="org-counters">
                    <div class="counter">
                        <span class="counter-value">${data.totalProjects}</span>
                        <span class="counter-label">${this.msg.projects}</span>
                    </div>
                    <div class="counter">
                        <span class="counter-value">${data.totalUsers}</span>
                        <span class="counter-label">${this.msg.users}</span>
                    </div>
                    <div class="counter">
                        <span class="counter-value">${data.totalTeams}</span>
                        <span class="counter-label">${this.msg.teams}</span>
                    </div>
                </div>
            </div>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this._loading)
            return this._renderLoading();
        if (this._error)
            return this._renderError();
        if (this._data)
            return this._renderData(this._data);
        return html ``;
    }
};
__decorate([
    property({ type: Number })
], CollabOrgHome.prototype, "project", void 0);
CollabOrgHome = __decorate([
    customElement('collab-org-home-100554')
], CollabOrgHome);
export { CollabOrgHome };
