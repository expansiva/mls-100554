/// <mls shortName="serviceDetail" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />

import { html, css } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { ServiceBase, IService, IToolbarContent, IMenu } from './_100554_serviceBase';
import { getAllWebComponentsInSource } from './_100554_libCompile';
import { convertTagToFileName, convertFileNameToTag } from './_100554_utilsLit';

@customElement('service-detail-100554')
export class ServiceDetail100554 extends ServiceBase {

    @property({ type: String }) msize = '';
    @property({ type: String }) widget = '';

    @query('#contentPlugin') contentPlugin: HTMLDivElement | undefined;

    private plugin: { shortName: string, project: number } = {} as any;

    constructor() {
        super();
        this.setEvents();
    }


    //-------SERVICE------------
    public details: IService = {
        icon: '&#xf059',
        state: 'background',
        position: 'right',
        tooltip: 'Detail',
        visible: true,
        widget: '_100554_serviceDetail',
        level: [1, 2, 3, 4, 5, 6, 7]
    }

    public onClickLink = (op: string): boolean => {
        if (op === 'opAboutThis') return this.showAboutThis();
        if (this.menu.setMode) this.menu.setMode('initial');
        return false;
    }

    public menu: IMenu = {
        title: '',
        actions: {
            opAboutThis: 'About this content',
        },
        icons: {},
        actionDefault: '', // call after close icon clicked
        setMode: undefined, // child will set this
        onClickLink: this.onClickLink,
        getLastMode: undefined,
        updateTitle: undefined
    }

    private showAboutThis(): boolean {

        const div = document.createElement('div');
        div.style.padding = '1rem';

        const name = this.plugin.project ? `_${this.plugin.project}_${this.plugin.shortName}` : 'nothing selected';

        div.innerHTML = `
        
            <h3>About this content</h3>
            <ul>
                <li>Reference: ${name}</li>
                <li>Level: ${this.level}</li>
                <li>Position: ${this.position}</li>
                <li><button>Open</button></li>
            </ul>
		

        `;
        div.onclick = (e) => {

            let el = e.target as HTMLElement;

            if (el.tagName.toLocaleLowerCase() === 'button' || (el.parentElement && el.parentElement.tagName.toLocaleLowerCase() === 'button')) {

                const keyFile = mls.stor.getKeyToFiles(this.plugin.project, 2, this.plugin.shortName, '', '.ts');
                const storFile = mls.stor.files[keyFile];

                if (!storFile) return;

                this.selectLevel(2)
                this.fireEvents('open', storFile, {});
            }

        };
        if (this.menu.setMode) this.menu.setMode('page', div);
        return true;
    }

    onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null) {

        if (!visible && this.contentPlugin) {
            this.contentPlugin.innerHTML = '';
        }

        if (!this.contentPlugin) return;
        Array.from(this.contentPlugin.children).forEach((child) => {
            if (child.tagName.startsWith('PLUGIN-')) {
                child.setAttribute('msize', this.msize);
            }
        });

    }

    //----------COMPONENT------------------

    firstUpdated(_changedProperties: Map<PropertyKey, unknown>) {
        super.firstUpdated(_changedProperties);
        this.onWidgetChanged();
    }

    updated(changedProperties: Map<PropertyKey, unknown>) {

        super.firstUpdated(changedProperties);

        if (changedProperties.has('widget')) {
            this.onWidgetChanged();
        }

        if (changedProperties.has('msize')) {
            if (!this.visible || !this.contentPlugin) return;

            Array.from(this.contentPlugin.children).forEach((child) => {
                if (child.tagName.startsWith('PLUGIN-')) {
                    child.setAttribute('msize', this.msize);
                }
            });
        }
    }

    render() {
        return html`<div style="overflow:auto;height:100%;padding:1rem" id="contentPlugin"></div>`;
    }

    //----------IMPLEMENTS-------------------

    private setEvents(): void {
        mls.events.addEventListener([0, 1, 2, 3, 4, 5, 6, 7], ['PluginDetails'], (ev) => this.onPluginDetails(ev));
        mls.events.addListener(2, 'MonacoAction', (ev) => this.onMonacoEvents(ev));
        mls.events.addListener(2, 'FileAction', (ev) => this.onFileActionReceived.bind(this)(ev));
    }

    private onMonacoEvents(ev: mls.events.IEvent): void {

        if (!ev.desc) return;
        const args: mls.events.IMonacoAction = JSON.parse(ev.desc);
        if (!args) return;
        const { action, position } = args;

        if (position === this.position) return;
        if (action !== 'helpAssistant') return;
        if (!args.codeLenCommand?.refs) return;

        this.openMe();
        mls.actual[0].setFullName(args.codeLenCommand.refs);
        const { project, path } = mls.actual[0];
        if (!path || !project) return;
        const info: mls.events.IPluginDetail = {
            project,
            shortName: path,
        };
        this.showPluginContent(info);

    }

    private async onFileActionReceived(ev: mls.events.IEvent) {

        if (!ev.desc) return;
        const params: mls.events.IFileAction = JSON.parse(ev.desc);
        if (params.action !== 'fileReference') return;
        const info: mls.events.IPluginDetail = {
            project: 100554,
            shortName: 'pluginCodelensFileReferences',
            htmlText: `<plugin-codelens-file-references-100554 project=${params.project} shortname=${params.shortName} position=${params.position}></plugin-codelens-file-references-100554>`
        };
        this.openMe();
        this.showPluginContent(info);

    }

    private onPluginDetails(ev: mls.events.IEvent) {
        if (!ev.desc) throw new Error('Error on PluginDetails event, invalid desc');
        this.openMe();
        if (this.menu && this.menu.closeMenu) this.menu.closeMenu();
        const data: mls.events.IPluginDetail = JSON.parse(ev.desc);
        this.showPluginContent(data);
    }

    private onWidgetChanged() {
        if (this.widget) {
            const { project, shortName } = mls.l2.getPath(this.widget);
            const tag = convertFileNameToTag(this.widget);
            const info: mls.events.IPluginDetail = {
                project,
                shortName,
                htmlText: `<${tag}></${tag}>`
            };
            this.showPluginContent(info);
        }
    }

    private async showPluginContent(info: mls.events.IPluginDetail) {
        // show htmlText or plugin html
        if (!info.project || !info.shortName) {
            if (!info.htmlText) throw new Error(`Error on PluginDetails events, invalid data: ${info.project} ${info.shortName}`);
        }
        if (!this.contentPlugin) throw new Error('Error on serviceDetail, contentPlugin is null');

        this.plugin = info;
        const content: string = info.htmlText ? info.htmlText : await this.getHtmlFromPlugin(info);
        this.updateContentPluginWithScripts(content);
    }

    private async getHtmlFromPlugin(info: mls.events.IPluginDetail): Promise<string> {
        const keyFile = mls.stor.getKeyToFiles(info.project, 2, info.shortName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (!storFile) return 'Not found storFile:' + JSON.stringify(info);
        const content = await storFile.getContent();
        if (typeof content !== 'string') return `Error on content of _${info.project}_${info.shortName}`;
        return content;
    }

    private updateContentPluginWithScripts(content: string): void {
        if (!this.contentPlugin) throw new Error('Error on serviceDetail, contentPlugin is null');
        this.contentPlugin.innerHTML = '';
        const allWcs = getAllWebComponentsInSource(content);
        this.contentPlugin.innerHTML = content;
        allWcs.forEach((wc) => {
            const fileName = convertTagToFileName(wc);
            const script = document.createElement('script');
            script.type = 'module';
            script.id = fileName;
            script.src = (`/${fileName}`);
            this.contentPlugin?.appendChild(script)
        });
        Array.from(this.contentPlugin.children).forEach((child) => {
            if (child.tagName.startsWith('PLUGIN-')) {
                child.setAttribute('msize', this.msize);
            }
        });
    }

    private fireEvents(action: string, file: mls.stor.IFileInfo, info: any, timeout: number = 0): void {

        const params = {} as mls.events.IFileAction;

        (params.action as any) = action;
        params.level = file.level;
        params.project = file.project;
        params.shortName = file.shortName;
        params.extension = '.ts';
        params.folder = file.folder;
        params.position = 'left' as ('right' | 'left');

        if (info && info.shortName) {
            params.newshortName = info.shortName;
            params.newProject = info.project;
            params.newfolder = file.folder;
        }

        if (['open'].includes(action)) {

            mls.actual[2].setFullName(`_${file.project}_${file.shortName}`);
            (mls.actual[2] as any)['left' as any] = {
                project: file.project,
                shortName: file.shortName,
                extension: '.ts',
                folder: file.folder,
            } as any;

        }

        mls.events.fire([2], ['FileAction'], JSON.stringify(params), timeout);

    }

}
