/// <mls shortName="collabMessagesTask" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { html, css } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { StateLitElement } from './_100554_stateLitElement';
import { getTask } from './_100554_msgDBController';
import { getNextPendentStep, getTotalCost } from './_100554_aiAgentHelper';
import {
    collab_money,
    collab_pause,
    collab_bell,
    collab_chevron_right,
    collab_clock,
    collab_check,
    collab_bug
} from './_100554_collabIcons';

/// **collab_i18n_start** 
const message_pt = {
    loading: 'Carregando...',
}

const message_en = {
    loading: 'Loading...',
}
type MessageType = typeof message_en;
const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**

@customElement('collab-messages-task-100554')
export class WidgetAiTask100554 extends StateLitElement {

    private msg: MessageType = messages['en'];

    @property() taskid: string = '';
    @property() messageid: string = '';
    @property() lastChanged: string = '';
    @property() title: string = '';
    @property() status: string = '';

    @state() task: mls.msg.TaskData | undefined;
    @state() context: mls.msg.ExecutionContext | undefined;

    async updated(changedProperties: Map<PropertyKey, unknown>) {
        super.updated(changedProperties);

        if (changedProperties.has('lastChanged')) {
            if (this.context && this.context.task) {
                this.task = this.context.task;
            }
        }

        if (changedProperties.has('taskid') && changedProperties.get('taskid') !== '') {
            this.getTaskLocal(this.taskid);
        }
    }

    render() {

        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.task && !this.title && !this.status) {
            return html`<div @click=${this.onCardClick} class="card no-details"> 
            <div class="card-header">
                <span class="card-title">Task</span>
                ${collab_chevron_right}
            </div>
         </div>`
        }

        const price = this.task ? getTotalCost(this.task) || '0.00' : '';
        const title =  this.task?.title || this.title || '';

        return html`<div @click=${this.onCardClick} class="card"> 
            <div class="card-header">
                ${this.renderIconTask()}
                    <span class="card-title"> ${title}</span>
                    <span class="card-price"> ${price ? collab_money : ''}${price}</span>
            </div>
         </div>`;
    }

    renderIconTask() {
        const taskObj: any = {
            '': html``,
            'pending': collab_clock,
            'paused': collab_pause,
            'todo': collab_clock,
            'in progress': collab_clock,
            'done': collab_check,
            'failed': collab_bug,
            'waitingforuser': html`
                    <span class="icon-wrapper">
                        ${collab_bell}
                        <span class="notification-badge">1</span>
                    </span>`,
        }
        let status = this.status;
        if (this.task) {
            status = this.task.status;
            const nextStepPending = getNextPendentStep(this.task);
            if (nextStepPending?.type === 'clarification') status = 'waitingforuser'
        }

        if (!status) return html`<spanclass="task-icon in progress ">${collab_clock}</span>`;
        return html`<span class="task-icon ${status.split(' ').join('-')} ">${taskObj[status]}</span>`;

    }

    private async getTaskLocal(taskId: string) {
        const task = await getTask(taskId);
        if (task) this.task = task;
    }

    private onCardClick() {
        const event = new CustomEvent('taskclick', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(event);
    }

}
