/// <mls fileReference="_100554_/l2/collabMessagesEnvironment.ts" enhancement="_blank"/>
import { loadAgent, executeBeforePrompt } from '/_102027_/l2/aiAgentOrchestration.js';
import { getTemporaryContext } from '/_102027_/l2/aiAgentHelper.js';
import { openElementInServiceDetails, saveOpenedFile } from '/_102027_/l2/libCommom.js';
import { createModel } from '/_102027_/l2/libModel.js';
import { setAuraState, saveAuraProject, getAuraState } from '/_102020_/l2/auraState.js';
export const collabEnvironment = {
    getAgents,
    getIntegrationsOpenClaw,
    setIntegrationsOpenClaw: (integrations) => setIntegrationsOpenClaw(integrations),
    notifications: {
        getFCMTokenForBackend,
        getNotifySoundUrl,
        sendACK: (id) => sendACK(id),
        sendRequestMissed,
    },
    bots: {
        getArgsToBots,
        getBotContextVarsBeforeMessageSend,
        getBotContextVarsBeforeMessageSend2
    },
    agents: {
        generateSvgAvatar: (threadId, userId, promptToAvatar) => generateSvgAvatar(threadId, userId, promptToAvatar),
        executeAgent: (agent, context) => executeAgent(agent, context),
        loadAgent: (agentName) => loadAgent2(agentName)
    },
    tasks: {
        openTaskDetails: (messageId, taskId, task, message) => openTaskDetails(messageId, taskId, task, message)
    },
    apps: {
        getProgramMenu: () => getProgramMenu(),
        openProgram: (item) => openProgram(item)
    },
    config: {
        getMenuMode: () => 'custom',
        generateSvgAvatarEnabled: () => true
    }
};
// Reads and parses <project>/l5/config.json from the stor.
async function readWorkspaceConfig(project) {
    try {
        const key = mls.stor.getKeyToFiles(project, 5, 'config', '', '.json');
        const storFile = mls.stor.files[key];
        if (!storFile)
            return undefined;
        const content = await storFile.getContent();
        if (!content || typeof content !== 'string')
            return undefined;
        return JSON.parse(content);
    }
    catch (err) {
        console.info('[readWorkspaceConfig] failed', err);
        return undefined;
    }
}
// Builds the Apps menu tree from config.json:
// first level = module (per project), children = the module's navigation links.
// Every module is listed (even without navigation), so backend/empty modules still show up.
async function getProgramMenu() {
    const project = mls.actualProject;
    if (!project)
        return [];
    const config = await readWorkspaceConfig(project);
    if (!config || !config.projects)
        return [];
    const menus = [];
    for (const projectId of Object.keys(config.projects)) {
        const modules = config.projects[projectId]?.modules ?? [];
        for (const module of modules) {
            const navigation = module.navigation ?? [];
            const items = navigation.map((nav) => ({
                title: nav.label ?? nav.id,
                icon: nav.icon ?? '',
                url: nav.href ?? '',
                pageName: nav.id,
                target: undefined
            }));
            menus.push({
                name: module.moduleId,
                icon: '',
                project: Number(projectId),
                path: module.basePath ?? '',
                menu: items
            });
        }
    }
    return menus;
}
// Splits a config "source" path (e.g. "l2/cafeFlow/web/desktop/page11/kitchenQueue.ts")
// into the stor coordinates used to open the file.
function parseSource(source) {
    let s = source.replace(/^\.?\//, '');
    let level = 2;
    const m = s.match(/^l(\d)\//);
    if (m) {
        level = Number(m[1]);
        s = s.slice(m[0].length);
    }
    const dot = s.lastIndexOf('.');
    const extension = dot >= 0 ? s.slice(dot) : '.ts';
    s = dot >= 0 ? s.slice(0, dot) : s;
    const slash = s.lastIndexOf('/');
    const folder = slash >= 0 ? s.slice(0, slash) : '';
    const shortName = slash >= 0 ? s.slice(slash + 1) : s;
    return { level, folder, shortName, extension };
}
// Opens the selected page in the Aura preview. Resolves the real page file from
// config.json (frontend.pages[].source), then mirrors the proven aura open flow
// (serviceGenome._openPage): editor models + mls.actual[3/4] + aura state + 'open' event.
async function openProgram(item) {
    const project = item.project ?? mls.actualProject;
    if (!project)
        return;
    let target = { level: 2, folder: item.path ?? '', shortName: item.pageName, extension: '.ts' };
    // Resolve the page source from config so the preview opens the actual .ts file.
    const config = await readWorkspaceConfig(mls.actualProject);
    const modules = config?.projects?.[String(project)]?.modules ?? [];
    const module = modules.find(m => m.basePath === item.path || m.moduleId === item.module);
    const page = (module?.frontend?.pages ?? []).find(p => p.pageId === item.pageName || p.route === item.url);
    if (page?.source)
        target = parseSource(page.source);
    if (!target.shortName)
        return;
    // Swap the source's variation segment (e.g. page11) for the current layout/design system.
    const layout = getAuraState().actualLayout ?? 1;
    const ds = getAuraState().actualDesignSystem ?? 1;
    const folder = target.folder.replace(/page\d+(\/|$)/, `page${layout}${ds}$1`);
    const file = { project, level: target.level, folder, shortName: target.shortName, extension: target.extension };
    const fullName = folder ? `_${project}_${folder}/${target.shortName}` : `_${project}_${target.shortName}`;
    // Bind the editor levels used by the preview and load the monaco models.
    for (const lv of [3, 4]) {
        mls.actual[lv].setFullName(fullName);
        mls.actual[lv].right = file;
    }
    const files = await mls.stor.getFiles({ project, shortName: target.shortName, folder, loadContent: false });
    if (files?.ts)
        await createModel(files.ts);
    if (files?.less)
        await createModel(files.less);
    if (files?.html)
        await createModel(files.html);
    saveOpenedFile(project, 4, mls.actual[4].getFullName());
    saveOpenedFile(project, 3, mls.actual[3].getFullName());
    // Aura preview repaints from the actualPage state.
    const pageRef = { project, shortName: target.shortName, folder, level: target.level, extension: target.extension };
    setAuraState('actualPage', pageRef);
    saveAuraProject();
    // Fire the standard 'open' action the preview listens to.
    const params = {};
    params.action = 'open';
    params.level = mls.actualLevel;
    params.project = project;
    params.shortName = target.shortName;
    params.extension = target.extension;
    params.folder = folder;
    params.position = 'right';
    mls.events.fire([mls.actualLevel], ['FileAction'], JSON.stringify(params), 0);
}
async function getAgents() {
    const keys = Object.keys(mls.stor.files);
    const ret = [];
    for await (const k of keys) {
        if (k.indexOf('agent') < 0)
            continue;
        const file = mls.stor.files[k];
        const path = `/_${file.project}_${file.folder ? file.folder + '/' : ''}${file.shortName}`;
        if (file.extension !== '.ts' || !file.shortName.startsWith('agent'))
            continue;
        try {
            const mdl = await import(path);
            if (!mdl.createAgent)
                continue;
            const agent = mdl.createAgent();
            ret.push(agent);
        }
        catch (err) {
            console.info(err);
            continue;
        }
    }
    return ret;
}
async function getIntegrationsOpenClaw() {
    if (mls.l5.actualOrg === undefined)
        return [];
    const actualOrgDetails = getOrgDetails(mls.l5.actualOrg);
    if (!actualOrgDetails || !actualOrgDetails.value)
        return [];
    try {
        const data = JSON.parse(actualOrgDetails.value);
        return data.integrations || [];
    }
    catch (err) {
        throw new Error(err.message);
    }
}
async function setIntegrationsOpenClaw(integrations) {
    if (mls.l5.actualOrg === undefined)
        throw new Error(`Invalid org actual: ${mls.l5.actualOrg}`);
    const actualOrgDetails = getOrgDetails(mls.l5.actualOrg);
    if (!actualOrgDetails)
        throw new Error(`Invalid org details: ${mls.l5.actualOrg}`);
    try {
        let data = {};
        if (actualOrgDetails.value) {
            data = JSON.parse(actualOrgDetails.value);
        }
        data = { ...data, integrations };
        await mls.api.cbeAddOrUpdateOrgValue(actualOrgDetails.sett.name, JSON.stringify(data));
    }
    catch (err) {
        throw new Error(err.message);
    }
}
async function getNotifySoundUrl() {
    return './l3/_100529_/audio/collabNotification.mp3';
}
async function getFCMTokenForBackend() {
    const token = await mls.events.getFCMTokenForBackend();
    return token;
}
async function sendRequestMissed() {
    return await mls.stor.cache.sendRequestMissed();
}
async function sendACK(id) {
    return await mls.stor.cache.sendACK(id);
}
async function getArgsToBots() {
    const data = {};
    return data;
}
async function getBotContextVarsBeforeMessageSend(thread, prompt) {
    return mls.bots.getBotContextVarsBeforeMessageSend(thread, prompt);
}
async function getBotContextVarsBeforeMessageSend2(vars, myArgs) {
    return mls.bots.getBotContextVarsBeforeMessageSend2(vars, myArgs);
}
async function generateSvgAvatar(threadId, userId, promptToAvatar) {
    const agentName = '_100554_/l2/agents/agentGenerateAvatarSvg';
    const agent = await loadAgent(agentName);
    if (!agent)
        throw new Error('Invalid agent');
    const context = getTemporaryContext(threadId, userId, promptToAvatar);
    await executeBeforePrompt(agent, context);
    const svg = extractSvgFromContext(context);
    return svg;
}
async function loadAgent2(agentName) {
    const agent = await loadAgent(agentName);
    if (!agent)
        return null;
    return agent;
}
async function executeAgent(agentToCall, context) {
    const agent = await loadAgent(agentToCall);
    if (!agent)
        throw new Error('Invalid agent' + agentToCall);
    await executeBeforePrompt(agent, context);
}
async function openTaskDetails(messageId, taskId, task, message) {
    await import('/_102025_/l2/collabMessagesTaskInfo.js');
    const el = document.createElement('collab-messages-task-info-102025');
    el.setAttribute('messageId', messageId);
    if (task && task.PK)
        el.setAttribute('taskId', task.PK);
    el['task'] = task;
    el['message'] = message;
    openElementInServiceDetails(el);
    return { openLocal: false, element: undefined };
}
function extractSvgFromContext(context) {
    return context?.task?.iaCompressed?.nextSteps?.[0]?.interaction?.payload?.[0]?.result ?? null;
}
function getOrgDetails(orgIndex) {
    const actualOrgName = Object.keys(mls.stor.orgs)[orgIndex];
    const actualOrgDetails = mls.stor.orgs[actualOrgName];
    return actualOrgDetails;
}
