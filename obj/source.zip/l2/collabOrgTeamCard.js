/// <mls fileReference="_100554_/l2/collabOrgTeamCard.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
/// **collab_i18n_start**
const message_pt = {
    addUser: 'Adicionar usuário',
    addUserPlaceholder: 'Nome de usuário',
    btnAdd: 'Adicionar',
    btnCancel: 'Cancelar',
    confirmRemove: 'Remover',
    cancelRemove: 'Cancelar',
    confirmMessage: 'Remover este membro do time?',
    noMembers: 'Nenhum membro neste time.',
};
const message_en = {
    addUser: 'Add User',
    addUserPlaceholder: 'Username',
    btnAdd: 'Add',
    btnCancel: 'Cancel',
    confirmRemove: 'Remove',
    cancelRemove: 'Cancel',
    confirmMessage: 'Remove this member from the team?',
    noMembers: 'No members in this team.',
};
const messages = {
    'en': message_en,
    'pt': message_pt,
};
let CollabOrgTeamCard = class CollabOrgTeamCard extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.project = 0;
        this.members = [];
        this.users = [];
        this.loading = false;
        this.msg = messages['en'];
        this._addOpen = false;
        this._addUsername = '';
        this._confirmingRemove = null;
    }
    firstUpdated() {
        const idxOrg = mls.l5.getProjectOrgIndex(this.project) || -1;
        const orgName = mls.l5.getOrgsName()[idxOrg];
        const lastOrg = mls.stor.orgs[orgName];
        if (!lastOrg) {
            return;
        }
        if (this.team) {
            this.members = this.team.users;
        }
        const users = [];
        lastOrg.sett.users.forEach((u, idx) => {
            users.push({ idx, name: u, avatar: 'https://i.pravatar.cc/40?u=alice' });
        });
        this.users = users;
    }
    _toggleAdd() {
        this._addOpen = !this._addOpen;
        this._addUsername = '';
        this.requestUpdate();
    }
    _handleAddInput(e) {
        const target = e.target;
        this._addUsername = target.value;
    }
    _handleAdd(e) {
        e.preventDefault();
        if (!this._addUsername.trim())
            return;
        this._addOpen = false;
        this._addUsername = '';
        this.requestUpdate();
    }
    _requestRemove(username) {
        this._confirmingRemove = username;
        this.requestUpdate();
    }
    _cancelRemove() {
        this._confirmingRemove = null;
        this.requestUpdate();
    }
    _confirmRemove(username) {
        this._confirmingRemove = null;
        this.requestUpdate();
    }
    _renderMember(m) {
        const confirming = this._confirmingRemove === m.name;
        return html `
            <li class="member-item">
                <div class="member-info">
                    <img class="avatar" src="${m.avatar}" alt="${m.name}" />
                    <span class="member-name">${m.name}</span>
                </div>

                ${confirming ? html `
                    <div class="confirm-inline">
                        <span class="confirm-label">${this.msg.confirmMessage}</span>
                        <button
                            class="btn-danger"
                            ?disabled="${this.loading}"
                            @click="${() => this._confirmRemove(m.name)}"
                        >${this.msg.confirmRemove}</button>
                        <button
                            class="btn-secondary"
                            @click="${() => this._cancelRemove()}"
                        >${this.msg.cancelRemove}</button>
                    </div>
                ` : html `
                    <button
                        class="btn-remove"
                        ?disabled="${this.loading}"
                        @click="${() => this._requestRemove(m.name)}"
                        title="Remove"
                    >🗑</button>
                `}
            </li>
        `;
    }
    _renderAddForm() {
        return html `
            <form class="add-form" @submit="${(e) => this._handleAdd(e)}">
                <select
                    class="add-input"
                    placeholder="${this.msg.addUserPlaceholder}"
                    .value="${this._addUsername}"
                    ?disabled="${this.loading}"
                    @input="${(e) => this._handleAddInput(e)}"
                >   
                    <option value="-1"></option> 
                    ${this.users.map((u) => html `<option value="${u.idx}">${u.name}</option>`)}
                </select>
                <button type="submit" class="btn-primary" ?disabled="${this.loading}">
                    ${this.msg.btnAdd}
                </button>
                <button
                    type="button"
                    class="btn-secondary"
                    @click="${() => this._toggleAdd()}"
                >${this.msg.btnCancel}</button>
            </form>
        `;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
            <div class="team-card">

                <ul class="member-list">
                    ${this.members.length > 0
            ? this.members.map((m) => this._renderMember(m))
            : html `<li class="no-members">${this.msg.noMembers}</li>`}
                </ul>

                <div class="add-section">
                    ${this._addOpen
            ? this._renderAddForm()
            : html `
                            <button
                                class="btn-add-toggle"
                                ?disabled="${this.loading}"
                                @click="${() => this._toggleAdd()}"
                            >+ ${this.msg.addUser}</button>
                        `}
                </div>

            </div>
        `;
    }
};
__decorate([
    property({ type: Number })
], CollabOrgTeamCard.prototype, "project", void 0);
__decorate([
    property({ type: Array })
], CollabOrgTeamCard.prototype, "members", void 0);
__decorate([
    property({ type: Array })
], CollabOrgTeamCard.prototype, "users", void 0);
__decorate([
    property({ type: Boolean })
], CollabOrgTeamCard.prototype, "loading", void 0);
CollabOrgTeamCard = __decorate([
    customElement('collab-org-team-card-100554')
], CollabOrgTeamCard);
export { CollabOrgTeamCard };
