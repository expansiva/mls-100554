/// <mls shortName="serviceProject" project="100554" enhancement="_100554_enhancementLitService" groupName="other" />

import { html, css, repeat } from 'lit';
import { customElement, property, query, } from 'lit/decorators.js';
import { ServiceBase, IService, IToolbarContent, IMenu } from './_100554_serviceBase';
import { collab_user } from './_100554_collabIcons';
import { getAllWebComponentsInSource } from './_100554_libCompile';
import { convertTagToFileName, convertFileNameToTag } from './_100554_utilsLit';
import('./_100554_collabPanel');

/// **collab_i18n_start**
const message_pt = {
    installPlugin: 'Explore e adicione novos plug-ins',
}

const message_en = {
    installPlugin: 'Explore and add new plugins',
}

type MessageType = typeof message_en;

const messages: { [key: string]: MessageType } = {
    'en': message_en,
    'pt': message_pt
}
/// **collab_i18n_end**

@customElement('service-project-100554')
export class ServiceProject100554 extends ServiceBase {

    private msg: MessageType = messages['en'];

    static styles = css`[[mls_getDefaultDesignSystem]]`;

    @property() activeTab: IScenery = 'Explore';

    @property({ type: Array }) explories: mls.plugin.MenuAction[] = [];

    @query('#projectDiv') projectDiv: HTMLDivElement | undefined;

    @query('details') firstDetails: HTMLDetailsExplore | undefined;

    public details: IService = {
        icon: '&#xf542',
        state: 'foreground',
        position: 'left',
        tooltip: 'Project',
        visible: true,
        widget: '_100554_serviceProject',
        level: [5]
    }

    public onClickLink = (op: string): boolean => {
        if (this.menu.setMode) this.menu.setMode('initial');
        return false;
    }

    public onClickIcon = (op: string): void => {
        this.activeTab = op as IScenery;
    }

    public menu: IMenu = {
        title: '',
        actions: {
        },
        icons: {
            Explore: 'Explore;e521',
            ShowCase: 'ShowCase;f5da',
            Admin: 'Admin;f508',
            Plugins: 'Plugins;f1e6',
        },
        actionDefault: '', // call after close icon clicked
        iconDefault: 'Explore',
        iconMenuType: 'full',
        setMode: undefined,
        updateTitle: undefined,
        getLastMode: undefined,
        lastIcon: undefined,
        setIconActive: undefined,
        onClickLink: this.onClickLink,
        onClickIcon: this.onClickIcon,


    }

    private myData: { [key: string]: mls.plugin.MenuAction[] } = {};

    async firstUpdated() {
        this.setMyData();
        await this.getExploreData();
        if (this.activeTab === 'Explore') {
            await this.updateComplete;
            if (this.firstDetails) this.firstDetails.click();
        }
    }

    async updated(changedProperties: Map<string | number | symbol, unknown>) {
        super.updated(changedProperties);
        if (changedProperties.has('activeTab') && !!changedProperties.get('activeTab')) {

            if (this.menu.setIconActive) this.menu.setIconActive(this.activeTab);
            if (this.activeTab === 'Explore') {
                await this.updateComplete;
                if (this.firstDetails) this.firstDetails.click();
            }

        }
    }

    private lastLevel: number = 0;

    onServiceClick(visible: boolean, reinit: boolean, el: IToolbarContent | null) {
        if (this.visible && this.lastLevel !== this.level) {
            this.lastLevel = this.level;
            this.updateIconsByLevel(this.lastLevel);
        }
    }

    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html`
            ${this.renderContent()}
        `;
    }


    private updateIconsByLevel(level: number) {
        if (!this.menu || !this.menu.refresh) return;

        if (level === 5) {
            this.menu.icons = {
                Explore: 'Explore;e521',
                ShowCase: 'ShowCase;f5da',
                Admin: 'Admin;f508',
                Plugins: 'Plugins;f1e6',
            }
        } else {
            this.menu.icons = {
                Explore: 'Explore;e521',
                ShowCase: 'ShowCase;f5da',
            }
        }

        this.menu.refresh();

    }

    private renderContent() {
        switch (this.activeTab) {
            case 'Explore':
                return this.renderExplore();
            case 'ShowCase':
                return this.renderShowCase();
            case 'Admin':
                return this.renderAdmin();
            case 'Plugins':
                return this.renderPlugin();
            default:
                return html``;
        }
    }

    private fireEventClose(msg: string) {
        mls.events.fire(
            5,
            'PluginDetails' as any,
            JSON.stringify(
                {
                    htmlText: `<div>${msg}</div>`

                }
            ),
            0
        );
    }

    private renderExplore() {

        // this.fireEventClose('In development: Details explore');
        return html`<div>
                ${this.explories.map((explorie, index) => {
            return html`
                        <details ?open=${index === 0} .data=${explorie} @click=${this.handleDetailExplorieClick}>
                            <summary>${explorie.category}</summary>
                            <div></div>
                        </details>
                    `
        })
            }</div>`;
    }

    private async handleDetailExplorieClick(e: MouseEvent) {
        const target = e.target as HTMLElement;
        const details = target.closest('details') as HTMLDetailsExplore;
        if (!details) return;
        const div = details.querySelector('div');
        if (!div || div.childElementCount > 0) return;

        await import(`./${details.data.widget}`);
        const pluginTag = convertFileNameToTag(details.data.widget);
        const pluginEl = document.createElement(pluginTag);
        pluginEl.setAttribute('autoprepare', '');
        pluginEl.setAttribute('level', this.level.toString());
        pluginEl.setAttribute('position', this.position.toString());
        div.appendChild(pluginEl);
    }

    private async getExploreData() {
        const { project } = mls.actual[5]
        if (!project) throw new Error('No project selected');
        await mls.plugin.loadAll(project, true);
        this.explories = mls.plugin.getAllMenuActions(project, { scope: 'l5Explore' } as any);

    }

    private renderShowCase() {
        this.fireEventClose('In development: Details showcase');

        const { project } = mls.actual[5];
        if (!project) return '<div>No project selected</div<';
        const keyToFile = mls.stor.getKeyToFiles(project, 2, 'project', '', '.html');
        const file = mls.stor.files[keyToFile]
        if (!file) return html`<div>File 'project.html' dont's exist in selected project</div>`;
        this.loadHelpPage('project' || '', project || 0);
        return html`<div style="overflow:auto;height:100%;" id="projectDiv"></div>`
    }

    private renderAdmin() {

        this.fireEventClose('Select a plugin');

        const keys = Object.keys(this.myData);
        return html`
        <div>
            ${repeat(keys, (
            (key: string, idx: number) => key + idx) as any,
            ((item: string, index: any) => {

                return this.renderPanel(item, index);

            }) as any
        )}
        </div>
        `

    }

    private renderPanel(key: string, index: number) {
        return html`
            <collab-panel-100554 .myData=${this.myData[key]}>
            </collab-panel-100554>
        
        `
    }

    private renderPlugin() {
        this.fireEventClose('In development: Details plugins');

        const groupedPlugins = this.groupPluginsByCategory(this.pluginsList);
        const sortedCategories = Object.keys(groupedPlugins).sort();
        return html`

        <ul class="plugin-container">
            ${sortedCategories.map(category => html`
                <li class="headerCategory">
                    <details open ">
                        <summary>${category}</summary>
                            <div class="plugins-list">
                            ${groupedPlugins[category].map(plugin => html`
                                <div
                                    plugin-id="${plugin.prjID}"
                                    class="${plugin.status === 'active' ? 'plugin active' : 'plugin'}"                                
                                >
                                    <div class= "plugin-title">
                                        <h3>${plugin.name}</h3>
                                    </div>
                                    <div class="plugin-info">    
                                        <p>${plugin.description}</p>
                                        <div>
                                            <div class="owner">
                                                <i>${collab_user}</i>
                                                <span>CollabTeam</span>
                                            </div>
                                            <div class="${plugin.status === 'active' ? 'plugin-status active' : 'plugin-status inactive'}">
                                                <div></div>
                                                <span>${plugin.status === 'active' ? 'Enabled' : 'Disabled'}</span>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            `)}
                        </div>
                        
                    </details>
                </li>        
            `)}
        </ul>
        <div class="buttons-container">
            <button @click=${this.handleAddNewPlugin}>${this.msg.installPlugin}</button>
        </div>
    `;
    }

    private handleAddNewPlugin() {
        alert('In Develpoment');
    }




    private pluginsList: Plugin[] = [
        { prjID: 1, name: "SEO Optimizer", description: "Melhore o posicionamento do seu site nos mecanismos de busca, ajustando as práticas recomendadas de SEO de forma automatizada e eficaz.", category: "SEO", status: "active" },
        { prjID: 3, name: "Social Media Integration", description: "Integre facilmente plataformas de redes sociais ao seu site, permitindo que os usuários compartilhem conteúdo e conectem suas contas.", category: "Social Media", status: "active" },
        { prjID: 4, name: "E-commerce Solution", description: "Gerencie sua loja online com este plugin robusto, que permite controle completo sobre inventário, vendas e integração de pagamentos.", category: "E-commerce", status: "active" },
        { prjID: 6, name: "Gallery Manager", description: "Crie, organize e gerencie galerias de imagens no seu site, oferecendo uma experiência visual personalizada e otimizada para seus visitantes.", category: "Media", status: "active" },
        { prjID: 9, name: "Custom CSS Editor", description: "Personalize o design do seu site com um editor de CSS integrado, permitindo edições diretas no estilo das suas páginas sem a necessidade de ferramentas externas.", category: "Design", status: "active" },
        { prjID: 11, name: "Email Marketing Integration", description: "Integre serviços de marketing por e-mail diretamente ao seu site, facilitando o envio de newsletters e campanhas personalizadas para sua audiência.", category: "Marketing", status: "active" },
        { prjID: 15, name: "Image Optimizer", description: "Otimize automaticamente as imagens do seu site para melhorar a performance, garantindo tempos de carregamento mais rápidos sem perder qualidade.", category: "Media", status: "active" },
        { prjID: 17, name: "Knowledge Base", description: "Crie e organize uma base de conhecimento completa para seus usuários, permitindo fácil acesso a artigos de ajuda e documentação técnica.", category: "Content", status: "inactive" },
        { prjID: 20, name: "Newsletter Subscription", description: "Permita que os visitantes do seu site se inscrevam facilmente em newsletters, mantendo-os atualizados sobre novidades e promoções de maneira automatizada.", category: "Marketing", status: "active" },
        { prjID: 22, name: "Payment Gateway Integration", description: "Integre uma ampla variedade de gateways de pagamento ao seu site, garantindo uma experiência de checkout segura e fácil para seus clientes.", category: "E-commerce", status: "inactive" },
        { prjID: 24, name: "Related Posts", description: "Exiba posts relacionados ao final de cada artigo, aumentando o engajamento dos usuários ao manter o interesse em conteúdos similares.", category: "Content", status: "inactive" },
        { prjID: 26, name: "SEO Friendly URLs", description: "Gere URLs otimizadas para SEO automaticamente, melhorando o posicionamento do seu site nos mecanismos de busca e facilitando a indexação de conteúdo.", category: "SEO", status: "inactive" },
        { prjID: 27, name: "Social Sharing Buttons", description: "Adicione botões de compartilhamento social aos seus posts, facilitando para os visitantes a divulgação de conteúdo em suas redes sociais preferidas.", category: "Social Media", status: "active" },
        { prjID: 28, name: "Theme Customizer", description: "Personalize facilmente a aparência do seu site com este plugin, que oferece uma interface simples para ajustar cores, fontes e layout.", category: "Design", status: "inactive" },
        { prjID: 30, name: "Video Embedder", description: "Incorpore vídeos diretamente nas suas postagens sem complicações, permitindo que você adicione conteúdo multimídia de maneira rápida e eficaz.", category: "Media", status: "inactive" },
    ];
    private groupPluginsByCategory(plugins: Plugin[]): { [category: string]: Plugin[] } {
        return plugins.reduce((acc, plugin) => {
            if (!acc[plugin.category]) {
                acc[plugin.category] = [];
            }
            acc[plugin.category].push(plugin);
            return acc;
        }, {} as { [category: string]: Plugin[] });
    }

    private async loadHelpPage(shortName: string, project: number) {
        const keyFile = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
        const storFile = mls.stor.files[keyFile];
        if (storFile) {
            const content = await storFile.getContent();
            if (this.projectDiv && typeof content === 'string') {
                const allWcs = getAllWebComponentsInSource(content);

                allWcs.forEach((wc) => {
                    const fileName = convertTagToFileName(wc);
                    const script = document.createElement('script');
                    script.type = 'module';
                    script.id = fileName;
                    script.src = (`/${fileName}`);
                    this.projectDiv?.appendChild(script)
                });

                const div = document.createElement('div');
                div.innerHTML = content;
                div.children[0].setAttribute('level', '7');
                this.projectDiv.innerHTML = '';
                this.projectDiv.appendChild(div);
            }

        }
    }

    private async setMyData() {

        const prj = mls.actual[5].project;
        if (!prj) return;
        let array: any[] = [];
        await mls.plugin.loadAll(prj, false);
        array = mls.plugin.getAllMenuActions(prj, {} as any);

        const wc = ["_100554_pluginProjectConfig", "_100554_pluginProjectUsage", "_100554_pluginProjectInfo", "_100554_pluginProjectReadMe"]

        array.forEach((item: mls.plugin.MenuAction) => {

            if (!wc.includes(item.widget)) return;
            const cat = item.category as string;
            if (!this.myData[cat]) this.myData[cat] = [item]
            else this.myData[cat].push(item);

        });

        this.requestUpdate();

    }
}




type IScenery = 'Explore' | 'ShowCase' | 'Admin' | 'Plugins'

interface Plugin {
    prjID: number; // unique
    name: string;
    description: string;
    category: string;
    status: PluginStatus
}

interface HTMLDetailsExplore extends HTMLDetailsElement {
    data: mls.plugin.MenuAction
}

type PluginStatus = 'active' | 'inactive';
