/// <mls fileReference="_100554_/l2/collabPanel.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { repeat } from 'lit/directives/repeat.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, property, query } from 'lit/decorators.js';
import '/_100554_/l2/collabPanelItem.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
let CollabPanel = class CollabPanel extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.open = true;
        this.myData = [];
        this.minus = '<svg xmlns="http://www.w3.org/2000/svg" style="width:15px"  viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M432 256c0 17.7-14.3 32-32 32L48 288c-17.7 0-32-14.3-32-32s14.3-32 32-32l352 0c17.7 0 32 14.3 32 32z"/></svg>';
        this.plus = '<svg xmlns="http://www.w3.org/2000/svg" style="width:15px" viewBox="0 0 448 512"><!--!Font Awesome Free 6.6.0 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 144L48 224c-17.7 0-32 14.3-32 32s14.3 32 32 32l144 0 0 144c0 17.7 14.3 32 32 32s32-14.3 32-32l0-144 144 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l-144 0 0-144z"/></svg>';
    }
    //---------COMPONENT-------------
    createRenderRoot() {
        return this;
    }
    render() {
        if (!this.myData || this.myData.length === 0) {
            return html `<h3 style="margin-left:1rem">Not found plugins</h3>`;
        }
        const category = this.myData[0].category;
        if (!this.icon)
            this.icon = this.open ? unsafeHTML(this.minus) : unsafeHTML(this.plus);
        return html `
            <details open="${this.open}">
                <summary @click=${this.changeSummary}>
                    <paneltitle>${category}</paneltitle>
                    <panelicon>${this.icon}</panelicon>
                </summary>
                <collab-panel-content>
                    ${repeat(this.myData, ((key, idx) => key.widget + idx), ((item, index) => {
            return this.renderItem(item, index);
        }))}
                </collab-panel-content>
            </details>
        `;
    }
    renderItem(item, index) {
        return html `
            <collab-panel-item-100554 widget=${item.widget} mode=${item.mode}>
            </collab-panel-item-100554>
        `;
    }
    //---------IMPLEMENT-------------
    changeSummary() {
        this.icon = !this.detail?.open ? unsafeHTML(this.minus) : unsafeHTML(this.plus);
    }
};
__decorate([
    query('details')
], CollabPanel.prototype, "detail", void 0);
__decorate([
    property({ type: Boolean, reflect: true })
], CollabPanel.prototype, "open", void 0);
__decorate([
    property({ reflect: true })
], CollabPanel.prototype, "icon", void 0);
CollabPanel = __decorate([
    customElement('collab-panel-100554')
], CollabPanel);
export { CollabPanel };
