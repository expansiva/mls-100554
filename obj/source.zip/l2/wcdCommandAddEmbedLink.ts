/// <mls shortName="wcdCommandAddEmbedLink" project="100554" enhancement="_100554_enhancementLit" groupName="other" />

import { IcaLitElementBase } from './_100554_icaLitElementBase';
import { IWCDCommand, dispatchEventConciliate } from './_100554_wcdCommandBase';
import { PREFIX_ICA_ID } from './_100554_collabPageElement';

export async function execute(param: IWCDCommand) {
    
    if (!param?.selectedIca) throw new Error('invalid param.selectedIca');
    if (!param.overlay || typeof param.overlay.selectItem !== 'function') throw new Error('invalid param.overlay');

    const args = param.args as IArgs;
    if (!args.url || typeof args.url !== 'string') throw new Error('Invalid args: url is missing or invalid');

    const elEmbedSocialMedia = document.createElement('ica-apresentation-embeds-social-media-100554') as IcaLitElementBase;
    elEmbedSocialMedia.setAttribute('widget', 'wc-embeds-social-media-100554');
    elEmbedSocialMedia.setAttribute('url', args.url || '');

    const allEmbedLinks = param.overlay.querySelectorAll('[widget="ica-apresentation-embeds-social-media-100554"]');

    const id = 'apEmbedLink' + (allEmbedLinks.length + 1);;
    elEmbedSocialMedia.id = PREFIX_ICA_ID + id;
    elEmbedSocialMedia.setAttribute('idEl', id);
    param.selectedIca.insertAdjacentElement('afterend', elEmbedSocialMedia);

    await elEmbedSocialMedia.updateComplete;
    param.selectedIca.remove();

    const { x, y, height, width } = elEmbedSocialMedia.getBoundingClientRect();
    if (!param.overlay.myItens) param.overlay.myItens = [];
    param.overlay.myItens.push({ element: elEmbedSocialMedia, depth: 0, x, y, height, width, opacity: elEmbedSocialMedia.style.opacity });
    param.overlay.createOverlayItems();
    setTimeout(() => { param.overlay.selectItem(elEmbedSocialMedia) }, 500);
    dispatchEventConciliate();
}

interface IArgs {
    url: string
}