/// <mls fileReference="_100554_/l2/pluginStyleIndexItem.ts" enhancement="_100554_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102029_/l2/collabLitElement.js';
import { convertFileNameToTag, getPath } from '/_102027_/l2/utils.js';
import { collab_heart, collab_heart_o, collab_question, collab_angles_right, collab_chevron_right, collab_info_circle } from '/_100554_/l2/collabIcons.js';
let PluginStyleIndexItem = class PluginStyleIndexItem extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.position = 'left';
        this.mode = 'collapsed';
        this.pluginLoaded = false;
    }
    firstUpdated() {
        if (this.mode !== 'collapsed') {
            const container = this.querySelector('.plugin-item-container');
            this.openPlugin(container, this.help, false);
        }
    }
    updated(_changedProperties) {
        if (_changedProperties.has('mode') && this.mode) {
            this.pluginEl?.setAttribute('showFull', this.mode === 'full' ? 'true' : 'false');
        }
    }
    render() {
        return html `
            <div class="plugin-item" .data=${this.help} >
                
                <div class="plugin-item-header">
                    <span>${this.help?.name}</span>
                    <div class="plugin-item-icons">
                        <i
                            class="i-expanded ${this.mode === 'full' || this.mode === 'expanded' ? 'open' : ''}"
                            @click=${(e) => { this.handleExpandedClick(e); }}
                        >${collab_chevron_right}</i>

                        <i
                            class="i-full ${this.mode === 'full' ? 'open' : ''}"
                            @click=${(e) => { this.handleFullClick(e); }}
                        
                        >${collab_angles_right}</i>
                        <i
                            class="i-question ${this.help?.showInfo ? 'info' : ''}"
                            @click=${(e) => { this.handleInfoClick(e); }}
                        >${collab_question}</i>
                        <i
                            class="i-like ${this.help?.liked ? 'liked' : ''} ${this.help?.likedAnimation ? 'likedAnimation' : ''}"
                            @click=${(e) => { this.handleLikeClick(e); }}
                        >${this.help?.liked ? collab_heart : collab_heart_o}
                        </i>
                    </div>
                </div>
                
                ${this.help?.showInfo ? html `
                    <div class="plugin-item-info">
                        <i>${collab_info_circle}</i>
                        <span>${this.help.widget}</span>
                    </div>
                    <div class="plugin-item-desc">${this.help.description}</div>

                ` : ''}

                <div
                    class="plugin-item-container ${this.help?.mode === 'expanded' ? 'expanded' : ''}"
                    style="${this.help?.mode !== 'collapsed' ? 'display:block;' : 'display:none;'}"
                >
                </div>            

            </div>`;
    }
    async openPlugin(container, help, close) {
        if (!help)
            return;
        if (close) {
            container.style.display = 'none';
            return;
        }
        if (container.childElementCount === 0) {
            const info = getPath(help.widget);
            if (!info)
                throw new Error('[openPlugin] Not found path:' + help.widget);
            const { folder, project, shortName } = info;
            const tag = convertFileNameToTag({ project, shortName, folder });
            this.pluginEl = document.createElement(tag);
            this.pluginEl.setAttribute('state', `{{ less.${this.position} }}`);
            this.pluginEl.setAttribute('showFull', this.mode === 'full' ? 'true' : 'false');
            container.appendChild(this.pluginEl);
        }
        else {
            const item = this.pluginEl;
            if (item)
                item.setAttribute('showFull', this.mode === 'full' ? 'true' : 'false');
        }
        container.style.display = 'block';
    }
    async handleOpenPlugin(e, help, close = false) {
        e.stopPropagation();
        const target = e.target;
        if (!target)
            return;
        const parent = target.closest('.plugin-item');
        if (!parent)
            return;
        const container = parent.querySelector('.plugin-item-container');
        if (!container)
            return;
        this.openPlugin(container, help, close);
    }
    async handleExpandedClick(e) {
        e.stopPropagation();
        if (!this.help)
            return;
        if (this.mode === 'expanded' || this.mode === 'full') {
            this.mode = 'collapsed';
            this.handleOpenPlugin(e, this.help, true);
        }
        else {
            this.mode = 'expanded';
            await this.handleOpenPlugin(e, this.help);
        }
        this.help.mode = this.mode;
    }
    handleFullClick(e) {
        e.stopPropagation();
        if (!this.help)
            return;
        if (this.mode === 'full') {
            this.mode = 'collapsed';
            this.handleOpenPlugin(e, this.help, true);
        }
        else {
            this.mode = 'full';
            this.handleOpenPlugin(e, this.help);
        }
        this.help.mode = this.mode;
    }
    async handleLikeClick(e) {
        e.stopPropagation();
        if (!this.help)
            return;
        this.help.liked = !this.help.liked;
        this.help.likedAnimation = this.help.liked;
        this.requestUpdate();
        setTimeout(() => {
            if (!this.help)
                return;
            this.help.likedAnimation = false;
        }, 1000);
    }
    async handleInfoClick(e) {
        if (!this.help)
            return;
        e.stopPropagation();
        this.help.showInfo = !this.help.showInfo;
        this.requestUpdate();
    }
};
__decorate([
    property({ reflect: false })
], PluginStyleIndexItem.prototype, "help", void 0);
__decorate([
    property()
], PluginStyleIndexItem.prototype, "position", void 0);
__decorate([
    property({ reflect: true })
], PluginStyleIndexItem.prototype, "mode", void 0);
__decorate([
    property()
], PluginStyleIndexItem.prototype, "pluginLoaded", void 0);
PluginStyleIndexItem = __decorate([
    customElement('plugin-style-index-item-100554')
], PluginStyleIndexItem);
export { PluginStyleIndexItem };
