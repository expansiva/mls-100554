/// <mls fileReference="_100554_/l2/collabStartL4.test.ts" enhancement="_blank" />

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];