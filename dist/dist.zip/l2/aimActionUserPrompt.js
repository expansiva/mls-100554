var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || (target[__knownSymbol("metadata")] = array[3]), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _isLoading_dec, _modeInternal_dec, _textareaPrompt_dec, _textareaAdd_dec, _a, _AimActionUserPrompt_decorators, _init;
import { html, unsafeHTML } from "lit";
import { customElement, query, property } from "lit/decorators.js";
import { tasks, updateTaskOnServer, getUserConfigs } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
import { convertFileNameToTag } from "./_100554_utilsLit";
import { initCollabShowCodeSnippet100554 } from "./_100554_collabShowCodeSnippet";
const myName = "_100554_aimActionUserPrompt";
const message_pt = {
  btn_cancel: "Cancelar",
  btn_confirm: "Confirmar",
  template_title: "prompt para usu\xE1rio",
  textarea_placelholder: "Entre com o prompt aqui",
  tryagain_placeholder: "Digite aqui seu prompt.",
  btn_confirmar: "Enviar novo prompt",
  btn_ok: "Finalizar",
  tasks: "Tarefas"
};
const message_en = {
  btn_cancel: "Cancel",
  btn_confirm: "Confirm",
  template_title: "prompt for user",
  textarea_placelholder: "Enter your prompt here",
  tryagain_placeholder: "Type your prompt here.",
  btn_confirmar: "Send new prompt",
  btn_ok: "Close",
  tasks: "Tasks"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_AimActionUserPrompt_decorators = [customElement("aim-action-user-prompt-100554")];
class AimActionUserPrompt extends (_a = AimActionBase, _textareaAdd_dec = [query("textarea.add")], _textareaPrompt_dec = [query("textarea.prompt")], _modeInternal_dec = [property({ type: String, reflect: true })], _isLoading_dec = [property()], _a) {
  constructor() {
    super();
    this.msg = messages["en"];
    this.assistant = "gpt3_typescript";
    this.title = "User Prompt";
    this.isLoading = __runInitializers(_init, 20, this, false), __runInitializers(_init, 23, this);
    initCollabShowCodeSnippet100554();
  }
  getRules() {
    return [{
      level: 5,
      tags: ["*"]
    }];
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    if (this.mode === "add") return this.renderAdd();
    return this.renderTaskRoot();
  }
  renderTaskRoot() {
    var _a2;
    const renderChild = (child, index2) => {
      this.loadDynamicWidget(taskRoot, child, child.widget);
      if (child.mode !== "processed" && child.mode !== "error" && child.nextStep) this.prepareNextStep(child);
      const taskName = convertFileNameToTag(child.widget);
      const sHtml = `<${taskName} mode="${child.mode}" taskindex="${this.taskIndex}" childindex="${index2}" />`;
      return html`${unsafeHTML(sHtml)}`;
    };
    if (this.taskIndex < 0 || this.taskIndex >= tasks.length) return html`invalid task index`;
    const taskRoot = tasks[this.taskIndex];
    const index = Number((_a2 = taskRoot.key) == null ? void 0 : _a2.split("/").pop()) || 0;
    const cost = taskRoot.cost || 0;
    const promptUser = this.getPromptUser(taskRoot);
    const ref = this.getRef(taskRoot);
    const lastUpdateDate = this.getLastUpdateDate(taskRoot);
    const configs = getUserConfigs();
    return html`
            <details>
                <summary>
                    <div class="action-title">
                        ${this.renderToolbar()} 
                        ${configs.cost ? html`<span title="Cost" class="ac ac-cost"> ${this.iconMoney} ${cost.toFixed(4)}</span>` : ""}
                        ${configs.sequencial ? html`<span title="Sequential" class="ac ac-id">${index.toString().padStart(5, "0")}</span>` : ""}
                        ${configs.countChild ? html`    <span title="Count Child" class="ac ac-count">${this.iconHash} ${taskRoot.children.length}</span>` : ""}
                        ${configs.title ? html`    <span title="Title" class="ac ac-title">${this.title}</span>` : ""}
                        ${configs.prompt ? html`    <span title="Prompt" class="ac ac-prompt"> ${this.iconPrompt} ${promptUser || "..."}</span>` : ""}
                        ${configs.user ? html`<span title="User" class="ac ac-user"> ${this.iconUser} ${taskRoot.userName} </span>` : ""}
                        ${configs.reference ? html`<span title="Reference" class="ac ac-ref"> ${this.iconRef} ${ref} </span>     ` : ""}
                        ${configs.lastUpdateDate ? html`<span title="Last update date " class="ac ac-date"> ${this.iconDate}  ${lastUpdateDate} </span>` : ""}                                         
                    </div>
                </summary>
                <details>
                    <summary>${this.msg.tasks}</summary>
                    ${taskRoot.children.map((child, index2) => renderChild(child, index2))}
                </details>
                <div style="padding: 1rem 3rem;background: #fcfcfc;">
                    ${this.renderResult()} 
                </div>
            </details>
        `;
  }
  renderResult() {
    const taskRoot = tasks[this.taskIndex];
    const chat = this.prepareChat(taskRoot);
    return html`
            <div>
                ${chat.map((item) => {
      if (item.answer) {
        return html`
                    <div style="display: flex;flex-direction: column;align-items: flex-end;gap: .25rem;width: 100%;margin-top: 2rem;">
                        <div style="background:#f4f4f4;max-width: 70%; padding:1.25rem .625rem;border-radius: 1.5rem;">
                            ${item.answer}
                        </div>
                    </div>
                `;
      } else {
        return html`
                    <div style="margin-top: 1rem;">
                        ${unsafeHTML(this.formatText(item.response.trim()))}
                    </div>
                `;
      }
    })}
            </div>
            <hr>

            ${this.modeInternal === "waiting for user" ? html`
                <div style='margin: 10px;'>
                    <div>
                        <textarea class="prompt" rows="5" placeholder=${this.msg.tryagain_placeholder} style="width:100%"></textarea>
                    </div>
                    <br>
                    <div class="buttonGroup">
                        <button style=${this.isLoading ? "pointer-events:none" : "pointer-events:all"} @click="${this.handleOk}">${this.msg.btn_ok}</button>
                        <button style=${this.isLoading ? "pointer-events:none" : "pointer-events:all"} @click="${this.handleConfirm}">
                            ${this.msg.btn_confirmar}
                            ${this.isLoading ? this.iconClock : ""}
                        </button>
                    </div>
                </div> 
                    ` : ""}
    
        `;
  }
  prepareChat(taskRoot) {
    const rc = [];
    for (let i = 0; i < taskRoot.children.length; i++) {
      const item = taskRoot.children[i];
      const chatItemAnswer = {
        answer: "",
        response: ""
      };
      const chatItemResponse = {
        answer: "",
        response: ""
      };
      if (item.widget === "_100554_aimTaskExecLLM") {
        chatItemAnswer.answer = item.prompt || "";
        chatItemResponse.response = item.result || "";
        rc.push(chatItemAnswer);
        rc.push(chatItemResponse);
      }
    }
    return rc;
  }
  formatText(text) {
    const regex = /```(\w+)\n([\s\S]*?)\n```/g;
    const replaceCodeBlock = (match, language, code) => {
      return `<collab-show-code-snippet-100554 language="${language}">
${code}
</collab-show-code-snippet-100554>`;
    };
    let formattedText = text.replace(regex, replaceCodeBlock);
    return formattedText;
  }
  handleConfirm() {
    let prompt = "";
    if (!this.textareaPrompt) return;
    prompt = this.textareaPrompt.value;
    if (!prompt) return;
    this.dispatchEvent(new CustomEvent("task-new-prompt", {
      detail: prompt,
      bubbles: true,
      composed: true
    }));
    this.textareaPrompt.value = "";
  }
  handleOk() {
    this.dispatchEvent(new CustomEvent("task-new-prompt", {
      detail: "",
      bubbles: true,
      composed: true
    }));
  }
  handleCancel() {
    this.dispatchEvent(new CustomEvent("add-task", {
      detail: { cancel: "true" },
      bubbles: true,
      composed: true
    }));
  }
  handleAdd() {
    return __async(this, null, function* () {
      if (!this.textareaAdd) return;
      const txtAreaValue = this.textareaAdd.value;
      const args = {
        prompt: txtAreaValue
      };
      this.taskRoot = {
        mode: "initializing",
        title: "prompt livre para o usuario",
        widget: myName,
        children: [],
        args: JSON.stringify(args),
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(this.taskRoot);
      this.prepareTask1(this.taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: this.taskRoot,
        bubbles: true,
        composed: true
      }));
    });
  }
  openMe() {
    const det = this.querySelector("details");
    if (det) det.open = true;
  }
  prepareTask1(taskRoot) {
    this.mode = taskRoot.mode = "in progress";
    this.isLoading = true;
    if (!taskRoot.args) {
      this.mode = taskRoot.mode = "error";
      taskRoot.trace.push("invalid taskroot args");
      return;
    }
    const args = JSON.parse(taskRoot.args);
    this.addTaskAndWaitForCompletion(taskRoot, {
      mode: "initializing",
      title: "execute prompt",
      widget: "_100554_aimTaskExecLLM",
      agent: this.assistant,
      prompt: args.prompt,
      trace: [],
      nextStep: this.prepareTaskWaitUser.name
      // danger, loop
    });
    this.requestUpdate();
  }
  prepareTaskWaitUser(taskFinishResult) {
    this.isLoading = false;
    this.openMe();
    const child = taskFinishResult.taskChild;
    if (taskFinishResult.status === "error" || taskFinishResult.status === "rejected") return this.endTasks(taskFinishResult);
    child.mode = this.modeInternal = "waiting for user";
    const listener = (e) => {
      const prompt = e.detail;
      if (!prompt) {
        this.modeInternal = "processed";
        return this.endTasks(taskFinishResult);
      }
      const args = {
        prompt
      };
      taskFinishResult.taskRoot.args = JSON.stringify(args);
      child.mode = "processed";
      this.prepareTask1(taskFinishResult.taskRoot);
      this.removeEventListener("task-new-prompt", listener);
    };
    if (taskFinishResult.status === "ok") {
      this.addEventListener("task-new-prompt", listener);
    }
    this.requestUpdate();
  }
  endTasks(taskFinishResult) {
    const { taskChild, taskRoot, status, result } = taskFinishResult;
    if (status === "error") taskChild.mode = "error";
    else taskChild.mode = "processed";
    this.mode = taskFinishResult.taskRoot.mode = taskChild.mode;
    this.requestUpdate();
    updateTaskOnServer(taskFinishResult.taskIndex);
  }
  renderAdd() {
    return html`
        <p> ${this.msg.template_title}</p>

        <div>
            <label><b>Prompt:</b></label>
            <textarea class="add" rows="5" placeholder=${this.msg.textarea_placelholder} style="width:100%"></textarea>
        </div>

        <div class="buttonGroup">
            <button @click="${this.handleCancel}">${this.msg.btn_cancel}</button>
            <button @click="${this.handleAdd}">${this.msg.btn_confirm}</button>
        </div>
`;
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "textareaAdd", _textareaAdd_dec, AimActionUserPrompt);
__decorateElement(_init, 5, "textareaPrompt", _textareaPrompt_dec, AimActionUserPrompt);
__decorateElement(_init, 5, "modeInternal", _modeInternal_dec, AimActionUserPrompt);
__decorateElement(_init, 5, "isLoading", _isLoading_dec, AimActionUserPrompt);
AimActionUserPrompt = __decorateElement(_init, 0, "AimActionUserPrompt", _AimActionUserPrompt_decorators, AimActionUserPrompt);
__runInitializers(_init, 1, AimActionUserPrompt);
export {
  AimActionUserPrompt
};
