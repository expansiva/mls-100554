var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || (target[__knownSymbol("metadata")] = array[3]), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _textarea_dec, _a, _AimActionUserPrompt_decorators, _init;
import { html } from "lit";
import { customElement, query } from "lit/decorators.js";
import { tasks, updateTaskOnServer } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
const myName = "_100554_aimActionUserPrompt";
const message_pt = {
  btn_cancel: "Cancelar",
  btn_confirm: "Confirmar",
  template_title: "prompt para usu\xE1rio",
  textarea_placelholder: "Entre com o prompt aqui"
};
const message_en = {
  btn_cancel: "Cancel",
  btn_confirm: "Confirm",
  template_title: "prompt for user",
  textarea_placelholder: "Enter your prompt here"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_AimActionUserPrompt_decorators = [customElement("aim-action-user-prompt-100554")];
class AimActionUserPrompt extends (_a = AimActionBase, _textarea_dec = [query("textarea")], _a) {
  constructor() {
    super(...arguments);
    this.msg = messages["en"];
    this.assistant = "gpt3_typescript";
    this.title = "User Prompt";
  }
  getRules() {
    return {
      levels: [5],
      tags: ["*servicePlugins*"]
    };
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return super.render();
  }
  handleCancel() {
    this.dispatchEvent(new CustomEvent("add-task", {
      detail: { cancel: "true" },
      bubbles: true,
      composed: true
    }));
  }
  handleAdd() {
    return __async(this, null, function* () {
      if (!this.textarea) return;
      const txtAreaValue = this.textarea.value;
      const args = {
        prompt: txtAreaValue
      };
      this.taskRoot = {
        mode: "initializing",
        title: "prompt livre para o usuario",
        widget: myName,
        children: [],
        args: JSON.stringify(args),
        trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
      };
      tasks.unshift(this.taskRoot);
      this.prepareTask1(this.taskRoot);
      this.dispatchEvent(new CustomEvent("finished-add-task-root", {
        detail: this.taskRoot,
        bubbles: true,
        composed: true
      }));
    });
  }
  prepareTask1(taskRoot) {
    this.mode = taskRoot.mode = "in progress";
    if (!taskRoot.args) {
      this.mode = taskRoot.mode = "error";
      taskRoot.trace.push("invalid taskroot args");
      return;
    }
    const args = JSON.parse(taskRoot.args);
    this.addTaskAndWaitForCompletion(taskRoot, {
      mode: "initializing",
      title: "execute prompt",
      widget: "_100554_aimTaskExecLLM",
      agent: this.assistant,
      prompt: args.prompt,
      trace: [],
      nextStep: this.prepareTask2.name
      // danger, loop
    });
    this.requestUpdate();
  }
  prepareTask2(taskFinishResult) {
    const child = taskFinishResult.taskChild;
    const result = child.result || "";
    if (taskFinishResult.status === "error" || !result) {
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      return;
    }
    child.mode = "processed";
    this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
      mode: "initializing",
      title: "result",
      widget: "_100554_aimTaskResultUserPrompt",
      trace: [],
      result,
      nextStep: this.prepareTask3.name
      // danger, loop
    });
    this.requestUpdate();
  }
  prepareTask3(taskFinishResult) {
    const child = taskFinishResult.taskChild;
    if (taskFinishResult.status === "ok" || taskFinishResult.status === "error" || taskFinishResult.status === "rejected") {
      return this.endTasks(taskFinishResult);
    }
    if (taskFinishResult.status !== "userEvent") throw new Error("Event not prepared");
    if (taskFinishResult.taskRoot.children.length > 20) throw new Error("Maximum task exceted");
    if (!taskFinishResult.newPrompt) throw new Error("Prompt invalid");
    const source = taskFinishResult.result;
    if (!source) {
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      child.trace.push("invalid finish , must be notify finish with result field");
      this.requestUpdate();
      return;
    }
    child.mode = "processed";
    this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
      mode: "initializing",
      title: "exec prompt",
      widget: "_100554_aimTaskExecLLM",
      ref: child.ref,
      agent: this.assistant,
      prompt: taskFinishResult.newPrompt,
      trace: [],
      nextStep: this.prepareTask2.name
      // looping exec prompt
    });
  }
  endTasks(taskFinishResult) {
    const { taskChild, taskRoot, status, result } = taskFinishResult;
    if (status === "error") taskChild.mode = "error";
    else taskChild.mode = "processed";
    this.mode = taskFinishResult.taskRoot.mode = taskChild.mode;
    this.requestUpdate();
    updateTaskOnServer(taskFinishResult.taskIndex);
  }
  renderAdd() {
    return html`
        <p> ${this.msg.template_title}</p>

        <div>
            <label><b>Prompt:</b></label>
            <textarea rows="5" placeholder=${this.msg.textarea_placelholder} style="width:100%"></textarea>
        </div>

        <div class="buttonGroup">
            <button @click="${this.handleCancel}">${this.msg.btn_cancel}</button>
            <button @click="${this.handleAdd}">${this.msg.btn_confirm}</button>
        </div>
`;
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "textarea", _textarea_dec, AimActionUserPrompt);
AimActionUserPrompt = __decorateElement(_init, 0, "AimActionUserPrompt", _AimActionUserPrompt_decorators, AimActionUserPrompt);
__runInitializers(_init, 1, AimActionUserPrompt);
export {
  AimActionUserPrompt
};
