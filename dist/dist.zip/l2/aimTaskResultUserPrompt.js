var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || (target[__knownSymbol("metadata")] = array[3]), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _modeInternal_dec, _textarea_dec, _a, _AimTaskResulUserPrompt_decorators, _init;
import { html, unsafeHTML } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeSnippet100554 } from "./_100554_collabShowCodeSnippet";
const message_pt = {
  tryagain_placeholder: "Digite aqui seu prompt.",
  btn_confirmar: "Confirmar",
  btn_cancelar: "Cancelar",
  btn_yes: "Sim",
  btn_no: "N\xE3o"
};
const message_en = {
  tryagain_placeholder: "Type your prompt here.",
  btn_confirmar: "Confirm",
  btn_cancelar: "Cancel",
  btn_yes: "Yes",
  btn_no: "No"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_AimTaskResulUserPrompt_decorators = [customElement("aim-task-result-user-prompt-100554")];
class AimTaskResulUserPrompt extends (_a = AimTaskBase, _textarea_dec = [query("textarea")], _modeInternal_dec = [property({ type: String, reflect: true })], _a) {
  constructor() {
    super();
    this.msg = messages["en"];
    this.result = "";
    initCollabShowCodeSnippet100554();
  }
  onInitializing() {
    if (this.taskChild.mode !== "error" && this.taskChild.mode !== "processed") {
      this.taskRoot.mode = this.taskChild.mode = "waiting for user";
    }
    this.openMe();
  }
  renderBody(taskRoot, child) {
    this.modeInternal = this.taskRoot.mode;
    const body = child.result || "";
    this.result = body;
    const chat = this.prepareChat(taskRoot);
    return html`
            <div>
                ${chat.map((item) => {
      if (item.answer) {
        return html`
                    <div style="display: flex;flex-direction: column;align-items: flex-end;gap: .25rem;width: 100%;margin-top: 2rem;">
                        <div style="background:#f4f4f4;max-width: 70%; padding:1.25rem .625rem;border-radius: 1.5rem;">
                            ${item.answer}
                        </div>
                    </div>
                `;
      } else {
        return html`
                    <div style="margin-top: 1rem;">
                        ${unsafeHTML(this.formatText(item.response.trim()))}
                    </div>
                `;
      }
    })}
            </div>
            <hr>

            ${this.modeInternal === "waiting for user" ? html`
                <div style='margin: 10px;'>
                    <div>
                        <textarea rows="5" placeholder=${this.msg.tryagain_placeholder} style="width:100%"></textarea>
                    </div>
                    <br>
                    <div class="buttonGroup">
                        <button @click="${this.handleCancel}">${this.msg.btn_cancelar}</button>
                        <button @click="${this.handleConfirm}">${this.msg.btn_confirmar}</button>
                    </div>
                </div> 
                    ` : ""}
    
        `;
  }
  prepareChat(taskRoot) {
    const rc = [];
    for (let i = 0; i < taskRoot.children.length; i++) {
      const item = taskRoot.children[i];
      const chatItem = {
        answer: "",
        response: ""
      };
      if (item.widget === "_100554_aimTaskExecLLM") chatItem.answer = item.prompt || "";
      else if (item.widget === "_100554_aimTaskResultUserPrompt") chatItem.response = item.result || "";
      rc.push(chatItem);
    }
    return rc;
  }
  formatText(text) {
    const regex = /```(\w+)\n([\s\S]*?)\n```/g;
    const replaceCodeBlock = (match, language, code) => {
      return `<collab-show-code-snippet-100554 language="${language}">
${code}
</collab-show-code-snippet-100554>`;
    };
    let formattedText = text.replace(regex, replaceCodeBlock);
    return formattedText;
  }
  openMe() {
    const det = this.closest("details");
    const detInternal = this.querySelector("details");
    if (det) det.open = true;
    if (detInternal) detInternal.open = true;
  }
  closeMe() {
    const det = this.querySelector("details");
    if (det) det.open = false;
  }
  handleCancel() {
    this.notifyCompleteByStatus("ok", this.result);
  }
  handleConfirm() {
    let prompt = "";
    if (this.textarea) prompt = this.textarea.value;
    this.notifyCompleteByStatus("userEvent", this.result, prompt);
    this.closeMe();
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "textarea", _textarea_dec, AimTaskResulUserPrompt);
__decorateElement(_init, 5, "modeInternal", _modeInternal_dec, AimTaskResulUserPrompt);
AimTaskResulUserPrompt = __decorateElement(_init, 0, "AimTaskResulUserPrompt", _AimTaskResulUserPrompt_decorators, AimTaskResulUserPrompt);
__runInitializers(_init, 1, AimTaskResulUserPrompt);
export {
  AimTaskResulUserPrompt
};
