var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _optionItems_dec, _desc_container_dec, _select_toogle_dec, _select_container_dec, _selectedvalue_dec, _options_dec, _label_dec, _disabled_dec, _required_dec, _hint_dec, _a, _CollabSelectOneWithDescription100554_decorators, _init;
import { html, css } from "lit";
import { customElement, property, query, queryAll } from "lit/decorators.js";
import { propertyDataSource, propertyCompositeDataSource } from "./_100554_icaLitElement";
import { IcaLitElement } from "./_100554_icaLitElement";
import { collab_plus } from "./_100554_collabIcons";
const message_pt = {
  defaultMsg: "Passe o mouse sobre as op\xE7\xF5es para saber mais."
};
const message_en = {
  defaultMsg: "Hover over the options to learn more."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_CollabSelectOneWithDescription100554_decorators = [customElement("collab-select-one-with-description-100554")];
class CollabSelectOneWithDescription100554 extends (_a = IcaLitElement, _hint_dec = [propertyDataSource({ type: String })], _required_dec = [property({ type: Boolean })], _disabled_dec = [property({ type: Boolean })], _label_dec = [propertyCompositeDataSource({ type: String })], _options_dec = [propertyDataSource()], _selectedvalue_dec = [propertyDataSource()], _select_container_dec = [query(".select_container")], _select_toogle_dec = [query(".select_toogle")], _desc_container_dec = [query(".desc_container")], _optionItems_dec = [queryAll("ul > li")], _a) {
  constructor() {
    super(...arguments);
    this.msg = messages["en"];
    this.required = __runInitializers(_init, 12, this, false), __runInitializers(_init, 15, this);
    this.disabled = __runInitializers(_init, 16, this, false), __runInitializers(_init, 19, this);
    this.defaultMsg = "";
    this.currentIndex = -1;
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    this.defaultMsg = this.msg.defaultMsg;
    return html`
            <div class="select_toogle" tabindex="1" @blur=${this.onBlur} @click=${this.onIconClick}>${collab_plus}</div>
            <div tabindex="0" @blur=${this.onBlur} class="select_container">
                <ul>
                    ${this.renderOpt()}
                </ul>
                <div tabindex="0" @blur=${this.onBlur} class="desc_container">
                    ${this.defaultMsg}
                </div>
            </div>
   
    `;
  }
  firstUpdated() {
    this.onkeydown = (e) => {
      this.handleKeyDown(e);
    };
  }
  onIconClick(e) {
    e.stopPropagation();
    this.toogle();
  }
  onBlur(e) {
    var _a2, _b;
    if ((_a2 = this.select_container) == null ? void 0 : _a2.contains(e.relatedTarget)) {
      e.preventDefault();
      return;
    }
    (_b = this.select_container) == null ? void 0 : _b.classList.remove("open");
  }
  renderOpt() {
    if (this.options) {
      return html`
                ${this.options.map((opt, index) => {
        return html`
                <li 
                    tabindex="0"  
                    @blur=${this.onBlur} 
                    @mouseover=${this.handleHover}
                    @mouseout=${this.handleOut}
                    @focus=${(ev) => {
          this.handleFocus(ev, index);
        }}
                    @click=${() => {
          this.handleChange(opt.value);
        }}
                    .description=${opt.description}
                    .val=${opt.value}
                    >
                    ${opt.key}
                </li>`;
      })}
        `;
    }
  }
  handleHover(ev) {
    const target = ev.target;
    if (!this.desc_container || !this.optionItems) return;
    this.desc_container.innerHTML = target.description;
    this.optionItems.forEach((item) => item.classList.remove("hover"));
    target.classList.add("hover");
  }
  handleOut() {
    if (!this.desc_container) return;
    this.desc_container.innerHTML = this.defaultMsg;
  }
  handleFocus(ev, index) {
    const target = ev.target;
    this.currentIndex = index;
    if (!this.desc_container || !this.optionItems) return;
    this.desc_container.innerHTML = target.description;
    this.optionItems.forEach((item) => item.classList.remove("hover"));
    target.classList.add("hover");
  }
  handleChange(value) {
    this.selectedvalue = value;
    this.dispatchEvent(new CustomEvent("select-change", {
      detail: value,
      bubbles: true,
      composed: true
    }));
    this.toogle();
  }
  handleKeyDown(event) {
    event.preventDefault();
    switch (event.key) {
      case "ArrowDown":
        if (this.optionItems && this.currentIndex < this.optionItems.length - 1) {
          this.currentIndex++;
          this.optionItems[this.currentIndex].focus();
        }
        break;
      case "ArrowUp":
        if (this.optionItems && this.currentIndex > 0) {
          this.currentIndex--;
          this.optionItems[this.currentIndex].focus();
        }
        break;
      case "Enter":
      case " ":
        event.preventDefault();
        if (this.optionItems && this.currentIndex > -1) {
          const val = this.optionItems[this.currentIndex].val;
          this.handleChange(val);
        }
        break;
    }
  }
  toogle() {
    if (!this.select_container || !this.optionItems) return;
    this.select_container.classList.toggle("open");
    if (this.select_container.classList.contains("open")) {
      this.calculatePopupPosition();
      if (this.optionItems[this.currentIndex]) this.optionItems[this.currentIndex].focus();
    }
  }
  calculatePopupPosition() {
    if (!this.select_toogle || !this.select_container) return;
    const selectBoxRect = this.select_toogle.getBoundingClientRect();
    const popupHeight = this.select_container.offsetHeight;
    const popupWidth = this.select_container.offsetWidth;
    this.select_container.style.left = "";
    this.select_container.style.top = "";
    this.select_container.style.bottom = "";
    const spaceBelow = window.innerHeight - selectBoxRect.bottom;
    const spaceRight = window.innerWidth - selectBoxRect.right;
    if (spaceBelow >= popupHeight) this.select_container.style.top = `${30}px`;
    else this.select_container.style.top = `-${popupHeight + 5}px`;
    if (spaceRight >= popupWidth) this.select_container.style.left = `${5}px`;
    else this.select_container.style.right = `${5}px`;
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "hint", _hint_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "required", _required_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "disabled", _disabled_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "label", _label_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "options", _options_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "selectedvalue", _selectedvalue_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "select_container", _select_container_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "select_toogle", _select_toogle_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "desc_container", _desc_container_dec, CollabSelectOneWithDescription100554);
__decorateElement(_init, 5, "optionItems", _optionItems_dec, CollabSelectOneWithDescription100554);
CollabSelectOneWithDescription100554 = __decorateElement(_init, 0, "CollabSelectOneWithDescription100554", _CollabSelectOneWithDescription100554_decorators, CollabSelectOneWithDescription100554);
CollabSelectOneWithDescription100554.styles = css`[[mls_getDefaultDesignSystem]]`;
__runInitializers(_init, 1, CollabSelectOneWithDescription100554);
export {
  CollabSelectOneWithDescription100554
};
