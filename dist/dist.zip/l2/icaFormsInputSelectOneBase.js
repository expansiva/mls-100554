import { IcaLitElement } from "./_100554_icaLitElement";
class IcaFormsInputSelectOneBase extends IcaLitElement {
  // Whether the field is ready for input or disabled
}
export {
  IcaFormsInputSelectOneBase
};
