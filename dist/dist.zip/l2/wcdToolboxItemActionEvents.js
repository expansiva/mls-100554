import { initCollabSelectOneWithDescription } from "./_100554_collabSelectOneWithDescription";
const getTemplate = (mode = "", position = "") => {
  let ret = templateActionEvents.event;
  if (position !== "") ret.position = position;
  const a = initCollabSelectOneWithDescription;
  return ret;
};
const templateActionEvents = {
  event: {
    position: "p-r1",
    tp: "event",
    format: "",
    title: "",
    iconSvg: "",
    onclick: (e, wc) => {
      if (wc.level === "2") {
        if (!e.elICA || !e.elICA.id) return;
        mls.events.fire(2, "WidgetAction", `{"op":"OpenScenario", "widget":"_100554_scenarioInsertEventOrChange", "value":"${e.detail}", "id":"${e.elICA.id}"}`);
      }
    },
    menuItens: [],
    menuSubItens: [],
    widget: "collab-select-one-with-description-100554",
    cursor: "pointer",
    attrs: void 0,
    isDblClick: false
  }
};
export {
  getTemplate
};
