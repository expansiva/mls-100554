import { initCollabSelectOneWithDescription } from "./_100554_collabSelectOneWithDescription";
const getTemplate = (mode = "", position = "") => {
  let ret = templateActionEvents.event;
  if (position !== "") ret.position = position;
  const a = initCollabSelectOneWithDescription;
  return ret;
};
const templateActionEvents = {
  event: {
    position: "p-r1",
    tp: "event",
    format: "",
    title: "",
    iconSvg: "",
    onclick: (e, wc) => {
      var _a;
      debugger;
      if (wc.level === "2") {
        const overlayItem = wc.parentElement;
        if (!overlayItem) return;
        const elIca = (_a = overlayItem.info) == null ? void 0 : _a.element;
        if (!elIca || !elIca.id) return;
        mls.events.fire(2, "WidgetAction", `{"op":"OpenScenario", "widget":"_100554_scenarioInsertEventOrChange", "value":"${e.detail}", "id":"${elIca.id}"}`);
      }
    },
    menuItens: [],
    menuSubItens: [],
    widget: "collab-select-one-with-description-100554",
    cursor: "pointer",
    attrs: void 0,
    isDblClick: false
  }
};
export {
  getTemplate
};
