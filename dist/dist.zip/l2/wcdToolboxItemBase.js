import { LitElement } from "lit";
class WcdToolboxItemBase extends LitElement {
}
export {
  WcdToolboxItemBase
};
