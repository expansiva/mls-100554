var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _hint_dec, _a, _ServiceSaveAddBRanch_decorators, _init;
import { html, css, repeat, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
const initServiceSaveaddBranch = () => {
};
_ServiceSaveAddBRanch_decorators = [customElement("save-add-branch-100554")];
class ServiceSaveAddBRanch extends (_a = LitElement, _hint_dec = [property()], _a) {
  constructor() {
    super(...arguments);
    this.owner = "";
    this.repo = "";
    this.branch = "";
    this.branchMain = [];
    this.listForks = [];
    this.error = "";
    this.mode = "list";
  }
  // -------------  WEBCOMPONENT -------------
  connectedCallback() {
    super.connectedCallback();
    this.init();
  }
  render() {
    if (this.mode === "list") {
      return this.renderModeList();
    } else {
      return this.renderModeAdd();
    }
  }
  renderModeList() {
    return html`
            <div class="contentAllBranch">
                <div style="display:flex; gap:1rem; font-size:.95rem; padding-bottom: .5rem; position: relative">

                    <div>
                        <span style="font-weight:600">Owner:</span>
                        <span>${this.owner}</span> 
                    </div>
                    <div>
                        <span style="font-weight:600">Repo:</span>
                        <span>${this.repo}</span> 
                    </div>
                    <div>
                        <span style="font-weight:600">Branch:</span>
                        <span>${this.branch}</span> 
                    </div>
                </div>
                <div class="clsHeader">
                    
                    <div class="contentInput">
                        <input placeholder="Filter..."></input>
                        <button>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg>
                        </button>
                    </div>
                    <button class="btn" @click="${this.addClick}">
                        <svg style=" width: 15px;" xmlns="http://www.w3.org/2000/svg" fill="#fff" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z"/></svg>
                        New Branch
                    </button>
                </div>
                ${this.renderBranchs()}
                ${this.renderForks()}
            </div>
        `;
  }
  renderModeAdd() {
    return html`
        <div class="contentAllBranch">
            <div style="display:flex; gap:1rem; font-size:.95rem; padding-bottom: .5rem; position: relative">

                <div>
                    <span style="font-weight:600">Owner:</span>
                    <span>${this.owner}</span> 
                </div>
                <div>
                    <span style="font-weight:600">Repo:</span>
                    <span>${this.repo}</span> 
                </div>
                <div>
                    <span style="font-weight:600">Branch:</span>
                    <span>${this.branch}</span> 
                </div>
            </div>
            <div class="grp_form">
                <div>
                    <labe>New Branch:</label>
                    <input type="text"></input>
                </div>
                <div class="grp_btn">
                    <button class="btn" @click="${this.addBranch}">
                        <svg style=" width: 15px;" xmlns="http://www.w3.org/2000/svg" fill="#fff" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z"/></svg>
                        Add
                    </button>

                    <button class="btn" style="background:#ff6b00" @click="${this.cancel}">
                        <svg style="width:15px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="#fff"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M367.2 412.5L99.5 144.8C77.1 176.1 64 214.5 64 256c0 106 86 192 192 192c41.5 0 79.9-13.1 111.2-35.5zm45.3-45.3C434.9 335.9 448 297.5 448 256c0-106-86-192-192-192c-41.5 0-79.9 13.1-111.2 35.5L412.5 367.2zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256z"/></svg>
                        Cancel
                    </button>
                </div>
                <div class="load" style="display:none">
                    <svg class="spinner" style=" width: 60px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M304 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm0 416a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM48 304a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm464-48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM142.9 437A48 48 0 1 0 75 369.1 48 48 0 1 0 142.9 437zm0-294.2A48 48 0 1 0 75 75a48 48 0 1 0 67.9 67.9zM369.1 437A48 48 0 1 0 437 369.1 48 48 0 1 0 369.1 437z"/></svg>
                </div>
                <div style="color:red;">
                    ${this.error}
                </div>
            </div>
        </div>
        `;
  }
  renderBranchs() {
    return html`
        <h4>Branches</h4>
        <ul>
            ${repeat(
      this.branchMain,
      (key) => key,
      (item, index) => {
        return this.renderItem(item, index);
      }
    )}
        </ul>`;
  }
  renderForks() {
    if (this.listForks.length <= 0) return html``;
    return html`
        <h4>Forks</h4>
        <ul>
            ${repeat(
      this.listForks,
      (key) => key,
      (item, index) => {
        return this.renderItemFork(item, index);
      }
    )}
        </ul>`;
  }
  renderItem(obj, index) {
    return html`
            <li @click="${this.setItem}" .info=${obj}>
                <input type="radio" id="item-${index}" name="optBranch" value="${obj.name}">
                <label for="item-${index}">
                    ${obj.name}
                </label>
            
            </li>
        
        `;
  }
  renderItemFork(obj, index) {
    return html`
            <li @click="${this.setItemFork}" .info=${obj}>
                <input type="radio" id="item-${index}" name="optFork" value="${obj.nameWithOwner}">
                <label for="item-${index}">
                    ${obj.nameWithOwner}
                </label>
            
            </li>
        
        `;
  }
  // ------------- IMPLEMENTATION -------------
  init() {
    return __async(this, null, function* () {
      const prj = mls.actual[5].project;
      if (!prj) return;
      if (!this.driver)
        this.driver = mls.stor.others.getDefaultDriver(prj);
      const info = mls.l5.getProjectSettings(prj);
      let str = info.projectURL.split("/");
      str = str.filter((item) => item.trim() !== "");
      this.branch = str[0];
      this.owner = str[1];
      this.repo = str[2];
      this.getInfosRepo();
    });
  }
  cancel() {
    this.mode = "list";
    this.error = "";
    this.requestUpdate();
  }
  addClick() {
    this.mode = "add";
    this.requestUpdate();
  }
  addBranch(e) {
    return __async(this, null, function* () {
      const el = e.target;
      if (!el) return;
      const g = el.closest(".grp_form");
      if (!g) return;
      const ipt = g.querySelector("input");
      if (!ipt) return;
      if (ipt.value === "") {
        this.error = "Erro: invalid name";
        this.requestUpdate();
        return;
      }
      const load = g.querySelector(".load");
      if (!load) return;
      load.style.display = "";
      try {
        yield this.addNewBranch(ipt.value);
        this.mode = "list";
        ipt.value = "";
        load.style.display = "none";
        this.getInfosRepo();
      } catch (e2) {
        this.error = "Erro: " + e2.message;
        console.info(e2);
        load.style.display = "none";
        this.requestUpdate();
      }
    });
  }
  addNewBranch(name) {
    return __async(this, null, function* () {
      if (!this.driver) throw new Error("Not found driver");
      if (!name) throw new Error("Name invalid");
      const prj = mls.actual[5].project;
      if (!prj) throw new Error("Project invalid");
      yield this.driver.createNewBranch({ owner: this.owner, repo: this.repo, branch: this.branch, newBranch: name });
    });
  }
  getInfosRepo() {
    return __async(this, null, function* () {
      if (!this.driver) return;
      const ret = yield this.driver.listBranches(this.owner, this.repo);
      const fork = yield this.driver.listForks(this.owner, this.repo);
      this.listForks = fork;
      this.branchMain = ret;
      this.requestUpdate();
    });
  }
  setItem(e) {
    e.stopPropagation();
    e.preventDefault();
    const el = e.target;
    if (!el) return;
    const li = el.closest("li");
    if (!li) return;
    if (!this.callBack) return;
    this.callBack(li.info);
  }
  setItemFork(e) {
    e.stopPropagation();
    e.preventDefault();
    const el = e.target;
    if (!el) return;
    const li = el.closest("li");
    if (!li) return;
    if (!this.callBack) return;
    this.callBack(li.info);
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "hint", _hint_dec, ServiceSaveAddBRanch);
ServiceSaveAddBRanch = __decorateElement(_init, 0, "ServiceSaveAddBRanch", _ServiceSaveAddBRanch_decorators, ServiceSaveAddBRanch);
// -------------  CSS -------------
ServiceSaveAddBRanch.styles = css`
        :host {
            padding: 1rem; 
        }

        .contentAllBranch{
            padding: 1rem; 
            position:relative;
        }

        .clsHeader{
            display:flex;
            gap:.5rem;
        }

        .btn{
            background: #007bff; 
            color: #fff;
            border:none;
            border-radius:5px;
            display:flex;
            justify-content: center; 
            align-items: center;
            gap:.3rem;
            cursor:pointer;
        }

        .contentInput{
            display: flex; 
            justify-content: start; 
            align-items: center; 
            border: 1px solid #ced4da; 
            border-radius:5px; 
            width:calc(100% - 140px);
            height:25px;
    
        }

        .contentInput input{
            border:none; 
            width:calc(100% - 30px);
            outline: none;
        }

        .contentInput button{
            width:25.5px; 
            border:none; 
            border-radius:0px;
            height:25px;
        }

        ul{
            list-style: none;
            margin: 0px;
            padding: 0px;
            padding-left: .5rem;
        }

        ul li{
            display:flex;
            justify-content: start; 
            align-items: center; 
            gap:.3rem;
        }

        ul li label{
            display:flex;
            justify-content: start; 
            align-items: center; 
            gap:.3rem;
            cursor:pointer;
            font-size:.98rem;
        }

        .grp_form{
            padding:1rem;
            padding-top:3rem;
            display:flex;
            flex-direction:column;
            gap:.8rem;
            justify-content:center;
            align-items:center;
            border:1px solid #dfdfdf;
            border-radius:5px;
        }

        .grp_form input{
            border-radius:5px;
            border: 1px solid #dfdfdf;
            height: 23px;
            width: 250px;
            outline: none;
        }

        .grp_btn{
            display:flex;
            gap:1rem
        }

        .load{
            position:absolute;
            width:100%;
            height:100%;
            display:flex;
            justify-content:center;
            align-items:center;
            background:#dfdfdf;
            margin-top:10px;

        }

        .spinner {
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }
            100% {
                transform: rotate(360deg);
            }
        }
    `;
__runInitializers(_init, 1, ServiceSaveAddBRanch);
export {
  ServiceSaveAddBRanch,
  initServiceSaveaddBranch
};
