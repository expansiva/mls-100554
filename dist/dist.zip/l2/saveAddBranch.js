var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _hint_dec, _a, _ServiceSaveAddBRanch_decorators, _init;
import { html, css, repeat, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
const initServiceSaveaddBranch = () => {
};
_ServiceSaveAddBRanch_decorators = [customElement("save-add-branch-100554")];
class ServiceSaveAddBRanch extends (_a = LitElement, _hint_dec = [property()], _a) {
  constructor() {
    super(...arguments);
    this.owner = "";
    this.repo = "";
    this.branch = "";
    this.branchMain = [];
  }
  // -------------  WEBCOMPONENT -------------
  connectedCallback() {
    super.connectedCallback();
    this.init();
  }
  render() {
    return html`
            <div class="contentAllBranch">
                <div style="display:flex; gap:1rem; font-size:.95rem; padding-bottom: .5rem; position: relative">

                    <div>
                        <span style="font-weight:600">Owner:</span>
                        <span>${this.owner}</span> 
                    </div>
                    <div>
                        <span style="font-weight:600">Repo:</span>
                        <span>${this.repo}</span> 
                    </div>
                    <div>
                        <span style="font-weight:600">Branch:</span>
                        <span>${this.branch}</span> 
                    </div>
                </div>
                <div class="clsHeader">
                    
                    <div class="contentInput">
                        <input placeholder="Filter..."></input>
                        <button>
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352a144 144 0 1 0 0-288 144 144 0 1 0 0 288z"/></svg>
                        </button>
                    </div>
                    <button class="btn">
                        <svg style=" width: 15px;" xmlns="http://www.w3.org/2000/svg" fill="#fff" viewBox="0 0 448 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z"/></svg>
                        New Branch
                    </button>
                </div>
                ${this.renderBranchs()}
            </div>
        `;
  }
  renderBranchs() {
    return html`
        <h4>Branches</h4>
        <ul>
            ${repeat(
      this.branchMain,
      (key) => key,
      (item, index) => {
        return this.renderItem(item, index);
      }
    )}
        </ul>`;
  }
  renderItem(obj, index) {
    return html`
            <li @click="${this.setItem}" .info=${obj}>
                <input type="radio" id="item-${index}" name="optBranch" value="${obj.name}">
                <label for="item-${index}">
                    ${obj.name}
                </label>
            
            </li>
        
        `;
  }
  // ------------- IMPLEMENTATION -------------
  init() {
    return __async(this, null, function* () {
      const prj = mls.actual[5].project;
      if (!prj) return;
      if (!this.driver)
        this.driver = mls.stor.others.getDefaultDriver(prj);
      const info = yield mls.l5.getProjectConf(prj);
      let str = info.projectURL.split("/");
      str = str.filter((item) => item.trim() !== "");
      this.branch = str[0];
      this.owner = str[1];
      this.repo = str[2];
      this.getInfosRepo();
    });
  }
  getInfosRepo() {
    return __async(this, null, function* () {
      if (!this.driver) return;
      const ret = yield this.driver.getListBranch(this.owner, this.repo);
      this.branchMain = ret;
      this.requestUpdate();
    });
  }
  setItem(e) {
    e.stopPropagation();
    e.preventDefault();
    const el = e.target;
    if (!el) return;
    const li = el.closest("li");
    if (!li) return;
    if (!this.callBack) return;
    this.callBack(li.info);
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "hint", _hint_dec, ServiceSaveAddBRanch);
ServiceSaveAddBRanch = __decorateElement(_init, 0, "ServiceSaveAddBRanch", _ServiceSaveAddBRanch_decorators, ServiceSaveAddBRanch);
// -------------  CSS -------------
ServiceSaveAddBRanch.styles = css`
        :host {
            padding: 1rem; 
        }

        .contentAllBranch{
            padding: 1rem; 
        }

        .clsHeader{
            display:flex;
            gap:.5rem;
        }

        .btn{
            background: #007bff; 
            color: #fff;
            border:none;
            border-radius:5px;
            display:flex;
            justify-content: center; 
            align-items: center;
            gap:.3rem;
        }

        .contentInput{
            display: flex; 
            justify-content: start; 
            align-items: center; 
            border: 1px solid #ced4da; 
            border-radius:5px; 
            width:calc(100% - 140px);
            height:25px;
    
        }

        .contentInput input{
            border:none; 
            width:calc(100% - 30px);
            outline: none;
        }

        .contentInput button{
            width:25.5px; 
            border:none; 
            border-radius:0px;
            height:25px;
        }

        ul{
            list-style: none;
            margin: 0px;
            padding: 0px;
            padding-left: .5rem;
        }

        ul li{
            display:flex;
            justify-content: start; 
            align-items: center; 
            gap:.3rem;
        }

        ul li label{
            display:flex;
            justify-content: start; 
            align-items: center; 
            gap:.3rem;
            cursor:pointer;
            font-size:.98rem;
        }
    `;
__runInitializers(_init, 1, ServiceSaveAddBRanch);
export {
  ServiceSaveAddBRanch,
  initServiceSaveaddBranch
};
