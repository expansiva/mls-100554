function _100554_testScenario1_getScenaryDetails() {
  const html = document.createElement("wc-input-text-100554");
  return {
    description: "Cen\xE1rio 1",
    html
  };
}
export {
  _100554_testScenario1_getScenaryDetails
};
