var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _widget_dec, _level_dec, _titleEl_dec, _a, _WCDToolbox_decorators, _init;
import { html, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
function initWCDToolbox() {
  return true;
}
_WCDToolbox_decorators = [customElement("wcd-toolbox-100554")];
class WCDToolbox extends (_a = CollabLitElement, _titleEl_dec = [query("wcd-toolbox-title")], _level_dec = [property({ type: String, reflect: true })], _widget_dec = [property({ type: String, reflect: true })], _a) {
  constructor() {
    super(...arguments);
    // ica base to wcd
    this.actions = [];
  }
  get lastHelper() {
    if (!this.elICA) return "";
    return this.elICA["lasthelper"];
  }
  set lastHelper(helper) {
    if (!this.elICA) return;
    this.elICA["lasthelper"] = helper;
  }
  // ------------ COMPONENT-------------------
  connectedCallback() {
    super.connectedCallback();
    if (!this.elICA) return;
    const widgetName = this.elICA.getAttribute("widget");
    if (!widgetName) return;
    const widget = this.elICA.querySelector(widgetName);
    if (!widget) return;
    this.elMain = widget;
    this.setAttribute("widget", widget.tagName.toLowerCase());
  }
  disconnectedCallback() {
    super.disconnectedCallback();
    if (this.resizeObserver) this.resizeObserver.disconnect();
  }
  firstUpdated() {
    if (!this.elMain) return;
    this.updateSize(this.elMain, this, true);
    this.initObserverResize();
    this.calculateTitlePosition();
  }
  render() {
    return html`
         <wcd-toolbox-aux-background></wcd-toolbox-aux-background>
         <wcd-toolbox-title>${this.widget}</wcd-toolbox-title>
        `;
  }
  updateSize(elBase, elChange, changePosition) {
    if (!elBase) return;
    setTimeout(() => {
      const display = elChange.style.display;
      elChange.style.display = "none!important";
      const icaBase = elBase.parentElement;
      if (!icaBase) return;
      const ad3 = (n1, s1, s2) => n1 + parseInt(s1, 10) + parseInt(s2, 10);
      const { marginTop, marginBottom, marginLeft, marginRight, paddingTop, paddingBottom, paddingLeft, paddingRight } = window.getComputedStyle(elBase);
      let { width, height, y } = elBase.getBoundingClientRect();
      let topIca = icaBase.getBoundingClientRect().top;
      let left = 0;
      let top = 0;
      left -= parseInt(marginLeft, 10);
      top -= parseInt(marginTop, 10);
      width = Math.max(ad3(width, marginLeft, marginRight), ad3(0, paddingLeft, paddingRight));
      if (width > elBase.ownerDocument.body.clientWidth) width -= 3;
      height = Math.max(ad3(height, marginTop, marginBottom), ad3(0, paddingTop, paddingBottom));
      const grandFahter = elBase.parentElement && elBase.parentElement.parentElement ? elBase.parentElement.parentElement : void 0;
      if (grandFahter) {
        const display2 = window.getComputedStyle(grandFahter).display;
        if (["flex"].includes(display2) && elBase.parentElement) {
          const fTop = elBase.parentElement.getClientRects()[0].top;
          const bTop = elBase.getClientRects()[0].top;
          top = fTop - bTop;
          top = top < 0 ? top * -1 : top;
        }
      }
      if (changePosition) {
        elChange.style.left = `${left - 1 < 0 ? 0 : left - 1}px`;
        elChange.style.top = `${top - 1}px`;
      }
      elChange.style.width = `${width + 2}px`;
      elChange.style.height = `${height + 2}px`;
      elChange.style.display = display;
    }, 50);
  }
  initObserverResize() {
    if (!this.elICA) return;
    if (this.resizeObserver) this.resizeObserver.disconnect();
    this.resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        if (!this.elMain) return;
        this.updateSize(this.elMain, this, true);
      }
    });
    this.resizeObserver.observe(this.elICA);
  }
  calculateTitlePosition() {
    if (!this.widget || !this.parentElement) return;
    const widget = this.elMain;
    if (!widget || !this.titleEl) return;
    const selectBoxRect = widget.getBoundingClientRect();
    this.titleEl.style.display = "block";
    const popupWidth = this.titleEl.offsetWidth;
    this.titleEl.style.display = "";
    this.titleEl.style.left = "";
    this.titleEl.style.top = "";
    this.titleEl.style.bottom = "";
    const spaceRight = window.innerWidth - selectBoxRect.right;
    if (spaceRight >= popupWidth) this.titleEl.style.left = `${-1}px`;
    else this.titleEl.style.right = `${-1}px`;
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "titleEl", _titleEl_dec, WCDToolbox);
__decorateElement(_init, 5, "level", _level_dec, WCDToolbox);
__decorateElement(_init, 5, "widget", _widget_dec, WCDToolbox);
WCDToolbox = __decorateElement(_init, 0, "WCDToolbox", _WCDToolbox_decorators, WCDToolbox);
//--------------CSS--------------------
WCDToolbox.styles = css`
        :host{
            display:block;
            border:1px solid #d3cece;
            position:absolute;
            user-select:none;
            z-index:9999;
            background: #c8c8c8c2; 
        }

        :host(:hover){
            border:1px solid purple!important;
        }

        :host(:not(.action-open):hover){
            wcd-toolbox-title{
                display:block;
            }
        }

        .itensFcaToolbox:hover{
            background:purple;
        }

        .fcaButtonAction{
            cursor:pointer;
        }

        .fcaBackButton{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-2rem;
            right:0px
        }

        .p-l1{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-6px;
            left:-6px
        }

        .p-l2{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            left:-6px;
            transform: translateY(-50%);
        }

        .p-l3{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-6px;
            left:-6px;
        }

        .p-l4{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-2rem;
            left:0px;
        }

        .p-l5{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            left:-23px;
            transform: translateY(-50%);
        }

        .p-m1{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-6px;
            left: 50%;
            transform: translateX(-50%);
        }

        .p-m2{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .p-m3{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-6px;
            left: 50%;
            transform: translateX(-50%);
        }

        .p-m4{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-2rem;
            left: 50%;
            transform: translateX(-50%);
        }

        .p-r1{
            cursor:pointer;
            display:block;
            position:absolute;
            top:-6px;
            right:-6px
        }

        .p-r2{
            cursor:pointer;
            display:block;
            position:absolute;
            top:50%;
            right:-6px;
            transform: translateY(-50%);
        }

        .p-r3{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-6px;
            right:-6px;
        }

        .p-r4{
            cursor:pointer;
            display:block;
            position:absolute;
            bottom:-2rem;
            right:-6px;
        }

        .f-circle{
            width:10px;
            height:10px;
            background:#fff;
            border-radius:50%;
            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);
        }
        

        .f-square{
            width:23px;
            height:7px;
            background:#fff;
            border-radius:3px;
            box-shadow: 0 0 4px 1px rgba(57,76,96,.15), 0 0 0 1px rgba(43,59,74,.3);
        }

        .p-l1.f-square{
            top:-4px;
            left:-4px
        }

        .p-l2.f-square{
            top:50%;
            left:-4px;
            width:7px;
            height:23px;
        }

        .p-l3.f-square{
            bottom:-4px;
            left:-4px;
        }

        .p-m1.f-square{
            top:-4px;
            width:23px;
            height:7px;
        }

        .p-m2.f-square{
            width:23px;
            height:7px;
        }

        .p-m3.f-square{
            bottom:-4px;
            width:23px;
            height:7px;
        }

        .p-r1.f-square{
            top:-4px;
            right:-4px
        }

        .p-r2.f-square{
            right:-4px;
            width:7px;
            height:23px;
        }

        .p-r3.f-square{
            bottom:-4px;
            right:-4px;
        }

        wcd-toolbox-menu.p-m1{
            top:-30px
        }

        wcd-toolbox-menu.p-m3{
            bottom:-30px
        }

        wcd-toolbox-menu{
            display:block;
            height:17px;
            border:1px solid #d3cece;
            padding:.2rem;
            border-radius:5px;
            position:relative;
            background:#fff;
            
        }

        wcd-toolbox-menu-container{
            display:block;
            position:relative;
        }

        wcd-toolbox-itemmenu{
            display:flex;
            height:20px;
            gap:.3rem;
            
        }

        wcd-toolbox-itemmenu a{
            display: flex!important;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            font-size:13px;
            width:18px;
            height:18px;
        }

        wcd-toolbox-itemmenu a:hover{
            background:#e1e1e1;
        }

        wcd-toolbox-submenu{
            position:absolute;
            top:19px;
            left:80%;
            display:flex;
            flex-direction: column;
            gap:.3rem;
            min-width: 150px;
            min-height: 50px;
            padding:.5rem;
            border:1px solid #d3cece;
            background:#fff;
            border-bottom-left-radius: 10px;
            border-bottom-right-radius: 10px;
            border-top-right-radius: 10px;
            box-shadow: 0px 1px 4px 1px #e1e1e1;
        }

        wcd-toolbox-submenu a {
            font-size:13px;
            display:flex;
            gap:.3rem;
            align-items: center;
            padding:.1rem;
        }

        wcd-toolbox-submenu a:hover {
            background:#e1e1e1;
        }

        wcd-toolbox-title {
            display:none;
            position: absolute;
            background: #4c4c4c;
            color: #fff;
            font-size: 11px;
            text-transform: lowercase;
            padding: 0 .5rem;
            height: 14px;
            bottom: -14px;
            right: -1px;
            border-bottom-right-radius: 5px;
            border-bottom-left-radius: 5px;
            font-weight: normal;
            letter-spacing: -.5px;
            font-family: monospace;
            width: max-content;
        }


    `;
__runInitializers(_init, 1, WCDToolbox);
export {
  WCDToolbox,
  initWCDToolbox
};
