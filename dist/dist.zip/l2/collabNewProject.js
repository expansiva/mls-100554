var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _progress_dec, _step3_dec, _step2_dec, _step1_dec, _logsContainer_dec, _form_dec, _inputProjectName_dec, _logs_dec, _errorDriver_dec, _isValidProjectName_dec, _actualTeams_dec, _actualOrgs_dec, _orgsLoaded_dec, _loadingAdd1Msg_dec, _orgSelected_dec, _driverSelected_dec, _a, _CollabNewProject_decorators, _init;
import { html, css } from "lit";
import { customElement, property, query } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
import {
  collab_pull_request,
  collab_commit,
  collab_arrows_rotate
} from "./_100554_collabIcons";
const message_pt = {
  btnCreateProject: "Criar projeto",
  btnRefreshOrg: "Atualizar",
  push: "Permite que os desenvolvedores fa\xE7am push diretamente para a branch principal.",
  pullRequest: "Exige que todas as mudan\xE7as sejam feitas atrav\xE9s de Pull Requests, permitindo revis\xF5es de c\xF3digo e aprova\xE7\xE3o antes da integra\xE7\xE3o na branch principal.",
  projectNameLabel: "Nome do projeto",
  errorProjectName: "Por favor, entre com um nome de projeto valido",
  driverNameLabel: "Driver",
  organizationLabel: "Organiza\xE7\xE3o",
  visibilityLabel: "Visibilidade do projeto",
  visibilityPublicOption: "P\xFAblico - Qualquer pessoa pode ver este reposit\xF3rio.",
  visibilityPrivateOption: "Privado - Voc\xEA escolhe quem pode ver.",
  teamLabel: "Time",
  loadingAddText1: "Buscando informa\xE7\xF5es do usu\xE1rio",
  loadingAddText2: "Buscando organiza\xE7\xF5es do usu\xE1rio",
  step1Title: "Passo 1",
  step2Title: "Passo 2",
  step3Title: "Passo 3",
  step1Msg: "Escolha o driver para carregar suas organiza\xE7\xF5es existentes.",
  step2Msg: "Agora selecione a organiza\xE7\xE3o e o modo de atualiza\xE7\xE3o.",
  step3Msg: "Finalmente, selecione a equipe e a visibilidade do projeto.",
  log_init: "Processando",
  log_error: "Erro",
  log_ok: "Concluido",
  log_0: "Verificando reposit\xF3rio",
  log_1: "Criando reposit\xF3rio",
  log_2: "Criando arquivo de valida\xE7\xE3o",
  log_3: "Criando projeto no collab.codes",
  log_4: "Configurando visibilidade do projeto",
  log_5: "Renomeando projeto",
  log_6: "Criando arquivo de configura\xE7\xE3o",
  log_7: "Projeto criado com sucesso!",
  log_error_03: "Por favor espere, outro usu\xE1rio esta utilizando o reposit\xF3rio.",
  log_error_04: "Existe um reposit\xF3rio, mas n\xE3o foi poss\xEDvel validar o usu\xE1rio"
};
const message_en = {
  btnCreateProject: "Create project",
  btnRefreshOrg: "Refresh",
  push: "Allows developers to push directly to the main branch.",
  pullRequest: "Requires all changes to be made through Pull Requests, allowing code reviews and approval before integration into the main branch.",
  projectNameLabel: "Project name",
  errorProjectName: "Please, enter with a valid project name",
  driverNameLabel: "Driver",
  organizationLabel: "Organization",
  visibilityLabel: "Project visibility",
  visibilityPublicOption: "Public - Anyone can see this repository.",
  visibilityPrivateOption: "Private - You choose who can see.",
  teamLabel: "Team",
  loadingAddText1: "Loading user informations",
  loadingAddText2: "Loading user organizations",
  step1Title: "Step 1",
  step2Title: "Step 2",
  step3Title: "Step 3",
  step1Msg: "Choose the driver to load your existing organizations.",
  step2Msg: "Now select the organization and the update mode.",
  step3Msg: "Finally select the team and the visibility of the project.",
  log_init: "Processing",
  log_error: "Error",
  log_ok: "Completed",
  log_0: "Verify repository",
  log_1: "Creating repository",
  log_2: "Creating validation file",
  log_3: "Creating project on collab.codes",
  log_4: "Setting project visibility",
  log_5: "Renaming project",
  log_6: "Creating configuration file",
  log_7: "Project created successfully!",
  log_error_03: "Please wait, another user is creating; ",
  log_error_04: " There is a repository, but I was unable to validate the user"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_CollabNewProject_decorators = [customElement("collab-new-project-100554")];
class CollabNewProject extends (_a = CollabLitElement, _driverSelected_dec = [property()], _orgSelected_dec = [property()], _loadingAdd1Msg_dec = [property()], _orgsLoaded_dec = [property()], _actualOrgs_dec = [property()], _actualTeams_dec = [property()], _isValidProjectName_dec = [property()], _errorDriver_dec = [property()], _logs_dec = [property()], _inputProjectName_dec = [query("#input_project_name")], _form_dec = [query("form")], _logsContainer_dec = [query(".logs-container")], _step1_dec = [query(".step1")], _step2_dec = [query(".step2")], _step3_dec = [query(".step3")], _progress_dec = [query(".progress-line")], _a) {
  constructor() {
    super(...arguments);
    this.msg = messages["en"];
    this.NEWREPONAME = "mls-new";
    this.VALIDADEFILE = "validate.json";
    this.driverSelected = __runInitializers(_init, 8, this, false), __runInitializers(_init, 11, this);
    this.orgSelected = __runInitializers(_init, 12, this, false), __runInitializers(_init, 15, this);
    this.loadingAdd1Msg = __runInitializers(_init, 16, this, ""), __runInitializers(_init, 19, this);
    this.orgsLoaded = __runInitializers(_init, 20, this, false), __runInitializers(_init, 23, this);
    this.actualOrgs = __runInitializers(_init, 24, this, []), __runInitializers(_init, 27, this);
    this.actualTeams = __runInitializers(_init, 28, this, []), __runInitializers(_init, 31, this);
    this.isValidProjectName = __runInitializers(_init, 32, this, true), __runInitializers(_init, 35, this);
    this.errorDriver = __runInitializers(_init, 36, this, ""), __runInitializers(_init, 39, this);
    this.logs = __runInitializers(_init, 40, this, []), __runInitializers(_init, 43, this);
    this.newProjectName = "";
    this.newProjectNumber = 0;
    this.newProjectTeam = "admin";
    this.newProjectVisibility = "public";
    this.newProjectUpdateMode = "push";
    this.driverName = "";
    this.orgName = "";
    this.login = "";
    this.drivers = {
      "github": "GitHub",
      "gitlab": "GitLab"
    };
    this.urls = {
      "github": "https://github.com/",
      "gitlab": "https://gitlab.com/"
    };
    this.PROJECTFIXED = 100570;
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return html`
            <div class="add-container">
                <form>
                    <div class="step step1">
                        <h5>${this.msg.step1Title}</h5>
                        <small>${this.msg.step1Msg}</small>
                        <hr>
                    </div>
                    <div>
                        <label>${this.msg.projectNameLabel}</label>
                        <input id="input_project_name" type="text" @input=${(e) => {
      this.newProjectName = e.target.value;
    }}>
                        ${!this.isValidProjectName ? html`<small class="error"> ${this.msg.errorProjectName}</small>` : ""}
                    </div>

                    <div>
                        <label>${this.msg.driverNameLabel}</label>
                        <select @change=${this.onSelectDriverChange}>
                            <option value=""></option>
                            <option value="github">gitHub</option>
                            <option value="gitlab">gitLab</option>
                        </select>
                        ${!!this.errorDriver ? html`<small class="error"> ${this.errorDriver}</small>` : ""}

                    </div>
                    ${this.driverSelected ? html`

                            ${!this.orgsLoaded ? html`<div class="msg-loading">
                                ${this.loadingAdd1Msg}
                                <div>
                                    <span class="dot"></span>
                                    <span class="dot"></span>
                                    <span class="dot"></span>
                                </div>
                            </div>` : html`
                                <div class="step step2">
                                        <h5>${this.msg.step2Title}</h5>
                                        <small>${this.msg.step2Msg}</small>
                                    <hr>
                                </div>
                                <div class="cards-update-mode">
                                    <div class="card-update-mode" @click=${(ev) => this.onCardClick("push", ev)}>
                                        <input name="update_mode" type="radio" checked></input>
                                        <div>
                                            <div class="card-update-mode-title">
                                                <span>${collab_commit}</span>
                                                <span >Push</span>
                                            </div>
                                            <span>${this.msg.push}</span>
                                        </div>
                                    </div>
                                    <div class="card-update-mode" @click=${(ev) => this.onCardClick("pullRequest", ev)}>
                                        <input name="update_mode" type="radio"></input>
                                        <div>
                                            <div class="card-update-mode-title">
                                                <span>${collab_pull_request}</span>
                                                <span>Pull Request</span>
                                            </div>
                                            <span> ${this.msg.pullRequest}</span>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <label>${this.msg.organizationLabel}</label>
                                    <div class="orgs-select">
                                        <select @change=${this.onOrgChanged}>
                                            <option></option>
                                            ${this.actualOrgs.map((org) => html`<option value="${org.id}">${org.name}</option>`)}
                                        </select>
                                        <button @click=${this.onRefreshOrgsClick}>${this.msg.btnRefreshOrg} ${collab_arrows_rotate}</button>
                                    </div>
                                    
                                </div>

                
                                ${this.orgSelected ? html`
                                    <div class="step step3">
                                        <h5>${this.msg.step3Title}</h5>
                                        <small>${this.msg.step3Msg}</small>
                                        <hr>
                                    </div>
                                    <div>
                                        <label>${this.msg.teamLabel}</label>
                                        <select @change=${(e) => {
      this.newProjectTeam = e.target.value;
    }}>
                                            ${this.actualTeams.map((team) => html`<option value="${team}">${team}</option>`)}
                                        </select>
                                    </div>
                                    <div>
                                        <label>${this.msg.visibilityLabel}</label>
                                        <select @change=${(e) => {
      this.newProjectVisibility = e.target.value;
    }}>
                                            <option value="public">${this.msg.visibilityPublicOption}</option>
                                            <option value="private">${this.msg.visibilityPrivateOption}</option>
                                        </select>
                                    </div>

                                    <div class="actions-btn">
                                        <button @click=${this.onCreateProjectClick}>
                                            ${this.msg.btnCreateProject}
                                        </button>
                                    </div>
                                
                                ` : html``}
                                
                            `}
                    ` : html``}
            
                </form>

                ${this.logs.length > 0 ? html`
            
                    <div class="logs-container">
                        <div class="progress">
                            <div class="progress-line"></div>
                        </div>
                        ${this.logs.map((log) => html`<collab-log-line-100554 status=${log.status} text=${log.pre}:${log.log}></collab-log-line-100554>`)}
                    </div>` : ""}
            </div>
        `;
  }
  toogleForm(disabled) {
    if (this.form) {
      this.form.classList.toggle("form-disabled", disabled);
    }
  }
  onSelectDriverChange(e) {
    this.errorDriver = "";
    const value = e.target.value;
    this.driverSelected = !!value;
    this.orgsLoaded = false;
    this.driverName = value;
    if (value) {
      this.loadOrgsByDriver(value);
    } else {
      this.orgSelected = false;
    }
  }
  onOrgChanged(e) {
    const value = e.target.value;
    this.orgSelected = !!value;
    this.orgName = value;
    if (value) {
      this.loadTeamByOrg(value);
      setTimeout(() => {
        var _a2;
        return (_a2 = this.step3) == null ? void 0 : _a2.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 100);
    }
  }
  loadOrgsByDriver(driver) {
    return __async(this, null, function* () {
      try {
        this.instanceDriver = mls.stor.others.getDriver(100529, driver);
        if (!this.instanceDriver) throw new Error("Invalid driver instance");
        this.loadingAdd1Msg = this.msg.loadingAddText1;
        const userInfo = yield this.instanceDriver.getUserInfo();
        this.loadingAdd1Msg = this.msg.loadingAddText2;
        if (!userInfo.login) throw new Error("Invalid user login");
        this.login = userInfo.login;
        this.actualOrgs = yield this.getOrgsByUser(this.login);
        this.orgsLoaded = true;
        setTimeout(() => {
          var _a2;
          return (_a2 = this.step2) == null ? void 0 : _a2.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 100);
      } catch (err) {
        this.driverSelected = false;
        this.errorDriver = err.message;
        console.error(err.message);
      }
    });
  }
  getOrgsByUser(user) {
    return __async(this, null, function* () {
      if (!this.instanceDriver) throw new Error("Invalid driver instance");
      const orgs = yield this.instanceDriver.getOrganizations(user);
      orgs.unshift({ id: user, name: user, avatarUrl: "", visibility: "public" });
      return orgs;
    });
  }
  loadTeamByOrg(org) {
    this.actualTeams = ["admin"];
  }
  delay(time) {
    return __async(this, null, function* () {
      yield new Promise((resolve) => setTimeout(resolve, time));
    });
  }
  delay2() {
    return __async(this, null, function* () {
      return new Promise((resolve, reject) => {
        resolve("free");
      });
    });
  }
  delayOk() {
    return __async(this, null, function* () {
      return new Promise((resolve, reject) => {
        resolve("Simulate ok");
      });
    });
  }
  delayError() {
    return __async(this, null, function* () {
      return new Promise((resolve, reject) => {
        reject(new Error("Simulate error"));
      });
    });
  }
  addLog(log) {
    this.logs.push(log);
    this.requestUpdate();
  }
  changeStatusLastLog(status, msg) {
    const lastLog = this.logs[this.logs.length - 1];
    if (lastLog) {
      lastLog.status = status;
      lastLog.pre = status === "finish" ? this.msg.log_ok : this.msg.log_error;
      if (msg) lastLog.log = msg;
      this.requestUpdate();
    }
  }
  tryItem(fc, log) {
    return __async(this, null, function* () {
      try {
        this.addLog({ pre: this.msg.log_init, log, status: "inprogress" });
        setTimeout(() => {
          var _a2;
          return (_a2 = this.logsContainer) == null ? void 0 : _a2.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 100);
        const rc = yield fc();
        this.changeStatusLastLog("finish");
        return rc;
      } catch (err) {
        const msg = log + ":" + err.message;
        this.changeStatusLastLog("error", msg);
        this.setProgressError(true);
        throw new Error(err.message);
      }
    });
  }
  setProgress(nr) {
    if (!this.progress) return;
    this.progress.style.width = Math.ceil(nr) + "%";
  }
  setProgressError(enabled) {
    if (!this.progress) return;
    if (enabled) this.progress.classList.add("error");
    else this.progress.classList.remove("error");
  }
  setProgressFinished(finished) {
    if (!this.progress) return;
    if (finished) this.progress.classList.add("finished");
    else this.progress.classList.remove("finished");
  }
  checkIsValidProjectName(name) {
    if (!name || name.length <= 3) return false;
    const projectNameRegex = /^[a-zA-Z][a-zA-Z0-9_]*$/;
    return projectNameRegex.test(name);
  }
  onCreateProjectClick(e) {
    return __async(this, null, function* () {
      var _a2, _b;
      e.preventDefault();
      this.logs = [];
      this.toogleForm(true);
      if (!this.checkIsValidProjectName(this.newProjectName)) {
        this.toogleForm(false);
        this.isValidProjectName = false;
        (_a2 = this.inputProjectName) == null ? void 0 : _a2.focus();
        (_b = this.inputProjectName) == null ? void 0 : _b.scrollIntoView({ behavior: "smooth", block: "center" });
        return;
      }
      this.isValidProjectName = true;
      const userNameCollab = this.getLoginUser();
      if (!userNameCollab) return;
      this.simulate();
      return;
      try {
        let percent = 16.6;
        let newPercent = 0;
        this.setProgressError(false);
        this.setProgressFinished(false);
        this.setProgress(newPercent);
        const rc = yield this.tryItem(() => __async(this, null, function* () {
          var _a3;
          return yield (_a3 = this.instanceDriver) == null ? void 0 : _a3.verifyRepositoryNew(this.login, this.NEWREPONAME, userNameCollab);
        }), `${this.msg.log_0} ${this.NEWREPONAME}`);
        if (rc === "reuse") percent = 25;
        newPercent += percent;
        this.setProgress(newPercent);
        if (rc === "error" || rc === "wait") {
          const obj = {
            "wait": this.msg.log_error_03,
            "error": this.msg.log_error_04
          };
          this.addLog({ pre: this.msg.log_error, log: obj[rc], status: "error" });
          this.toogleForm(false);
          return;
        }
        if (rc === "free") {
          yield this.tryItem(() => __async(this, null, function* () {
            var _a3;
            return yield (_a3 = this.instanceDriver) == null ? void 0 : _a3.createRepository(this.login, this.NEWREPONAME, this.orgName, "new project in collab.codes", "PUBLIC");
          }), `${this.msg.log_1} ${this.NEWREPONAME} `);
          newPercent += percent;
          this.setProgress(newPercent);
          yield this.tryItem(() => __async(this, null, function* () {
            var _a3;
            return yield (_a3 = this.instanceDriver) == null ? void 0 : _a3.createFileInRepo(this.orgName, this.NEWREPONAME, this.VALIDADEFILE, `{ "users": [ "${userNameCollab}" ] }`);
          }), `${this.msg.log_2} ${this.VALIDADEFILE} `);
          newPercent += percent;
          this.setProgress(newPercent);
        }
        const newProjectId = yield this.tryItem(
          () => __async(this, null, function* () {
            return yield mls.api.cbeSaveNewPrj(
              {
                orgName: this.orgName,
                info: {
                  project: this.newProjectNumber,
                  projectDriver: this.drivers[this.driverName],
                  projectURL: `${this.urls[this.driverName]}main/${this.orgName}/mls-new/`
                },
                settings: {
                  id: 0,
                  name: this.newProjectName,
                  owner: userNameCollab,
                  userAuth: this.newProjectVisibility
                }
              }
            );
          }),
          `${this.msg.log_3}`
        );
        newPercent += percent;
        this.setProgress(newPercent);
        if (this.newProjectVisibility === "private") yield this.tryItem(() => __async(this, null, function* () {
          var _a3;
          return yield (_a3 = this.instanceDriver) == null ? void 0 : _a3.changeVisibility(this.orgName, this.NEWREPONAME, "PRIVATE");
        }), `${this.msg.log_4}`);
        newPercent += percent;
        this.setProgress(newPercent);
        const newProjectName = `mls-${newProjectId}`;
        yield this.tryItem(() => __async(this, null, function* () {
          var _a3;
          return yield (_a3 = this.instanceDriver) == null ? void 0 : _a3.renameRepository(this.orgName, this.NEWREPONAME, newProjectName);
        }), `${this.msg.log_5}`);
        newPercent += percent;
        this.setProgress(newPercent);
        const newUrlProject = `${this.urls[this.driverName]}main/${this.orgName}/${newProjectName}/`;
        yield this.tryItem(() => __async(this, null, function* () {
          yield this.createConfigFile(newProjectId, this.newProjectName, this.driverName, newUrlProject, this.newProjectUpdateMode);
        }), `${this.msg.log_6}`);
        newPercent += percent;
        this.setProgress(newPercent);
      } catch (err) {
        this.toogleForm(false);
      }
      this.addLog({ pre: this.msg.log_ok, log: this.msg.log_7, status: "finish" });
      this.setProgressFinished(true);
      this.dispatchEvent(new CustomEvent("collab-new-project", {
        detail: this.newProjectNumber,
        bubbles: true,
        composed: true
      }));
    });
  }
  simulate() {
    return __async(this, null, function* () {
      try {
        let percent = 16.6;
        let newPercent = 0;
        this.setProgressError(false);
        this.setProgressFinished(false);
        this.setProgress(newPercent);
        const rc = yield this.tryItem(() => __async(this, null, function* () {
          return yield this.delay2();
        }), this.msg.log_0);
        if (rc === "reuse") percent = 25;
        newPercent += percent;
        this.setProgress(newPercent);
        if (rc === "error" || rc === "wait") {
          const obj = {
            "wait": this.msg.log_error_03,
            "error": this.msg.log_error_04
          };
          this.addLog({ pre: this.msg.log_error, log: obj[rc], status: "error" });
          this.setProgressError(true);
          this.toogleForm(false);
          return;
        }
        if (rc === "free") {
          yield this.tryItem(() => __async(this, null, function* () {
            return yield this.delay(2e3);
          }), `${this.msg.log_1} ${this.NEWREPONAME} `);
          newPercent += percent;
          this.setProgress(newPercent);
          yield this.tryItem(() => __async(this, null, function* () {
            return yield this.delay(2e3);
          }), `${this.msg.log_2} ${this.VALIDADEFILE} `);
          newPercent += percent;
          this.setProgress(newPercent);
        }
        yield this.tryItem(() => __async(this, null, function* () {
          return yield this.delay(2e3);
        }), `${this.msg.log_4}`);
        newPercent += percent;
        this.setProgress(newPercent);
        yield this.tryItem(() => __async(this, null, function* () {
          return yield this.delay(200);
        }), `${this.msg.log_5}`);
        newPercent += percent;
        this.setProgress(newPercent);
        yield this.tryItem(() => __async(this, null, function* () {
          return yield this.delay(2e3);
        }), `${this.msg.log_6}`);
        newPercent += percent;
        this.setProgress(newPercent);
      } catch (err) {
        this.toogleForm(false);
        return;
      }
      this.addLog({ pre: this.msg.log_ok, log: this.msg.log_7, status: "finish" });
      this.setProgressFinished(true);
      this.dispatchEvent(new CustomEvent("collab-new-project", {
        detail: this.PROJECTFIXED,
        bubbles: true,
        composed: true
      }));
    });
  }
  createConfigFile(project, name, projectDriver, projectURL, projectSaveMode) {
    return __async(this, null, function* () {
      const newConfig = {
        name,
        projectDriver,
        projectURL,
        projectSaveMode,
        designSystems: [],
        languages: []
      };
      const content = JSON.stringify(newConfig);
      const params = {
        project,
        level: 5,
        shortName: "project",
        extension: ".json",
        versionRef: "0",
        folder: ""
      };
      const file = yield mls.stor.addOrUpdateFile(params);
      file.status = "new";
      const fileInfo = {
        content,
        contentType: "string"
      };
      yield mls.stor.localStor.setContent(file, fileInfo);
    });
  }
  onCardClick(opt, ev) {
    var _a2;
    const target = ev.target;
    const input = (_a2 = target.closest(".card-update-mode")) == null ? void 0 : _a2.querySelector("input");
    if (input) input.checked = true;
    this.newProjectUpdateMode = opt;
  }
  onRefreshOrgsClick(ev) {
    return __async(this, null, function* () {
      ev.preventDefault();
      this.actualOrgs = yield this.getOrgsByUser(this.login);
      this.requestUpdate();
    });
  }
  getLoginUser() {
    const userNameCollab = localStorage.getItem("loginUser");
    return userNameCollab;
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "driverSelected", _driverSelected_dec, CollabNewProject);
__decorateElement(_init, 5, "orgSelected", _orgSelected_dec, CollabNewProject);
__decorateElement(_init, 5, "loadingAdd1Msg", _loadingAdd1Msg_dec, CollabNewProject);
__decorateElement(_init, 5, "orgsLoaded", _orgsLoaded_dec, CollabNewProject);
__decorateElement(_init, 5, "actualOrgs", _actualOrgs_dec, CollabNewProject);
__decorateElement(_init, 5, "actualTeams", _actualTeams_dec, CollabNewProject);
__decorateElement(_init, 5, "isValidProjectName", _isValidProjectName_dec, CollabNewProject);
__decorateElement(_init, 5, "errorDriver", _errorDriver_dec, CollabNewProject);
__decorateElement(_init, 5, "logs", _logs_dec, CollabNewProject);
__decorateElement(_init, 5, "inputProjectName", _inputProjectName_dec, CollabNewProject);
__decorateElement(_init, 5, "form", _form_dec, CollabNewProject);
__decorateElement(_init, 5, "logsContainer", _logsContainer_dec, CollabNewProject);
__decorateElement(_init, 5, "step1", _step1_dec, CollabNewProject);
__decorateElement(_init, 5, "step2", _step2_dec, CollabNewProject);
__decorateElement(_init, 5, "step3", _step3_dec, CollabNewProject);
__decorateElement(_init, 5, "progress", _progress_dec, CollabNewProject);
CollabNewProject = __decorateElement(_init, 0, "CollabNewProject", _CollabNewProject_decorators, CollabNewProject);
CollabNewProject.styles = css`[[mls_getDefaultDesignSystem]]`;
__runInitializers(_init, 1, CollabNewProject);
export {
  CollabNewProject
};
