import { IcaLitElement } from "./_100554_icaLitElement";
class IcaFormsSubmitSubmitBase extends IcaLitElement {
  // The form element that the button is associated with (it is the owning form).
}
export {
  IcaFormsSubmitSubmitBase
};
