var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _ScenarioInsertEventOrChange_decorators, _init, _a;
import { html, css, LitElement } from "lit";
import { customElement } from "lit/decorators.js";
function _100554_scenarioInsertEventOrChange_getScenaryDetails() {
  const html2 = document.createElement("scenario-insert-event-or-change-100554");
  return {
    description: "Insert or Change Event",
    html: html2
  };
}
const initCollabSelectOneWithDescription = "";
const message_pt = {
  defaultMsg: "Em desenvolvimento inserir ou alterar Eventos",
  noIten: "Nenhum elemento selecionado!",
  helpYou: "Como podemos te ajudar?",
  card1: "Fa\xE7a voc\xEA mesmo",
  card1Desc: "Codifique manualmente e desenvolva o seu pr\xF3prio evento.",
  card2: "Rotinas pr\xE9-prontas",
  card2Desc: "Utilize rotinas pr\xE9-prontas para facilitar o desenvolvimento do seu evento."
};
const message_en = {
  defaultMsg: "In development insert or change Events",
  noIten: "No elements selected!",
  helpYou: "How can we help you?",
  card1: "Do it yourself",
  card1Desc: "Manually code and develop your own event.",
  card2: "Pre-ready routines",
  card2Desc: "Use pre-made routines to facilitate the development of your event."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_ScenarioInsertEventOrChange_decorators = [customElement("scenario-insert-event-or-change-100554")];
class ScenarioInsertEventOrChange extends (_a = LitElement) {
  constructor() {
    super(...arguments);
    this.msg = messages["en"];
  }
  //---------- COMPONENT---------
  connectedCallback() {
    super.connectedCallback();
    this.init();
  }
  render() {
    if (!this.myInfos) {
      return this.renderNoSelected();
    }
    return html`${this.renderScenarioHowDo()}`;
  }
  renderNoSelected() {
    return html`<h3 style="text-align:center">${this.msg.noIten}</h3>`;
  }
  renderScenarioHowDo() {
    return html`
            <div class="scenarioHowDo">
                <h3 style="text-align:center">${this.msg.helpYou}</h3>
                <div class="container">
                    <div class="card">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M246.9 23.7C242.3 6.6 224.8-3.5 207.7 1.1s-27.2 22.1-22.6 39.2L238 237.8c2.5 9.2-4.5 18.2-14 18.2c-6.4 0-12-4.2-13.9-10.3L166.6 102.7c-5.1-16.9-23-26.4-39.9-21.3s-26.4 23-21.3 39.9l62.8 206.4c2.4 7.9-7.2 13.8-13.2 8.1L99.6 283c-16-15.2-41.3-14.6-56.6 1.4s-14.6 41.3 1.4 56.6L156.8 448c43.1 41.1 100.4 64 160 64h10.9 8.2c.1 0 .1-.1 .1-.1s.1-.1 .1-.1c58.3-3.5 108.6-43.2 125.3-99.7l81.2-275c5-16.9-4.7-34.7-21.6-39.8s-34.7 4.7-39.8 21.6L443.5 247.1c-1.6 5.3-6.4 8.9-12 8.9c-7.9 0-13.8-7.3-12.2-15.1l36-170.3c3.7-17.3-7.4-34.3-24.7-37.9s-34.3 7.4-37.9 24.7L355.1 235.1c-2.6 12.2-13.3 20.9-25.8 20.9c-11.9 0-22.4-8-25.4-19.5l-57-212.8z"/></svg>
                        <h2>${this.msg.card1}</h2>
                        <p>${this.msg.card1Desc}</p>
                    </div>
                    <div class="card">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M320 0c17.7 0 32 14.3 32 32V96H472c39.8 0 72 32.2 72 72V440c0 39.8-32.2 72-72 72H168c-39.8 0-72-32.2-72-72V168c0-39.8 32.2-72 72-72H288V32c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16h32c8.8 0 16-7.2 16-16s-7.2-16-16-16H208zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16h32c8.8 0 16-7.2 16-16s-7.2-16-16-16H304zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16h32c8.8 0 16-7.2 16-16s-7.2-16-16-16H400zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224H64V416H48c-26.5 0-48-21.5-48-48V272c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48v96c0 26.5-21.5 48-48 48H576V224h16z"/></svg>
                        <h2>${this.msg.card2}</h2>
                        <p>${this.msg.card2Desc}</p>
                    </div>
                </div>
            </div>
        
        `;
  }
  //------------IMPLEMETNATION---------
  init() {
    this.setInfos();
  }
  setInfos() {
    if (!window.infoScenarioInsertOrCreateEvent) {
      this.requestUpdate();
      return;
    }
    this.myInfos = Object.assign({}, window.infoScenarioInsertOrCreateEvent);
    delete window.infoScenarioInsertOrCreateEvent;
    this.requestUpdate();
  }
}
_init = __decoratorStart(_a);
ScenarioInsertEventOrChange = __decorateElement(_init, 0, "ScenarioInsertEventOrChange", _ScenarioInsertEventOrChange_decorators, ScenarioInsertEventOrChange);
//---------------CSS----------------
ScenarioInsertEventOrChange.styles = css`

        .scenarioHowDo .container {
            display: flex;
            gap: 20px;
            justify-content:center;
            padding:3rem;
        }

        .scenarioHowDo .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            cursor:pointer;
            width: 300px;
        }

        .scenarioHowDo .card:hover {
            box-shadow: 0 5px 9px rgba(0, 0, 0, 0.5);
        }

        .scenarioHowDo .card svg {
            width: 50px;
            height: 50px;
            margin-bottom: 20px;
        }

        .scenarioHowDo .card h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .scenarioHowDo .card p {
            font-size: 16px;
            color: #666;
        }


    `;
__runInitializers(_init, 1, ScenarioInsertEventOrChange);
export {
  ScenarioInsertEventOrChange,
  _100554_scenarioInsertEventOrChange_getScenaryDetails,
  initCollabSelectOneWithDescription
};
