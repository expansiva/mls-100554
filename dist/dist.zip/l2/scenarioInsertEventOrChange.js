var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _ScenarioInsertEventOrChange_decorators, _init, _a;
import { html, css, LitElement, repeat, unsafeHTML } from "lit";
import { customElement } from "lit/decorators.js";
function _100554_scenarioInsertEventOrChange_getScenaryDetails() {
  const html2 = document.createElement("scenario-insert-event-or-change-100554");
  return {
    description: "Insert or Change Event",
    html: html2
  };
}
const initCollabSelectOneWithDescription = "";
const message_pt = {
  defaultMsg: "Em desenvolvimento inserir ou alterar Eventos",
  event: "Evento: ",
  noIten: "Nenhum elemento selecionado!",
  helpYou: "Como podemos te ajudar?",
  card1: "Fa\xE7a voc\xEA mesmo",
  card1Desc: "Codifique manualmente e desenvolva o seu pr\xF3prio evento.",
  card2: "Rotinas pr\xE9-prontas",
  card2Desc: "Utilize rotinas pr\xE9-prontas para facilitar o desenvolvimento do seu evento.",
  scnearioDevice: "Para qual dispositivo o evento ser\xE1 criado?",
  selectPreReady: "Selecione uma fun\xE7\xE3o pre programada."
};
const message_en = {
  defaultMsg: "In development insert or change Events",
  event: "Event: ",
  noIten: "No elements selected!",
  helpYou: "How can we help you?",
  card1: "Do it yourself",
  card1Desc: "Manually code and develop your own event.",
  card2: "Pre-ready routines",
  card2Desc: "Use pre-made routines to facilitate the development of your event.",
  scnearioDevice: "For which device will the event be created?",
  selectPreReady: "Select a pre-programmed function."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_ScenarioInsertEventOrChange_decorators = [customElement("scenario-insert-event-or-change-100554")];
class ScenarioInsertEventOrChange extends (_a = LitElement) {
  constructor() {
    super(...arguments);
    this.msg = messages["en"];
    //-----------PreRotinas----------
    this.iconsEvents = {
      click: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M32 480c0 17.7 14.3 32 32 32s32-14.3 32-32V272H32V480zM224 320c0 17.7 14.3 32 32 32s32-14.3 32-32V256c0-17.7-14.3-32-32-32s-32 14.3-32 32v64zm-64 64c17.7 0 32-14.3 32-32V304c0-17.7-14.3-32-32-32s-32 14.3-32 32v48c0 17.7 14.3 32 32 32zm160-96c0 17.7 14.3 32 32 32s32-14.3 32-32V224c0-17.7-14.3-32-32-32s-32 14.3-32 32v64zm-96-88l0 .6c9.4-5.4 20.3-8.6 32-8.6c13.2 0 25.4 4 35.6 10.8c8.7-24.9 32.5-42.8 60.4-42.8c11.7 0 22.6 3.1 32 8.6V160C384 71.6 312.4 0 224 0H162.3C119.8 0 79.1 16.9 49.1 46.9L37.5 58.5C13.5 82.5 0 115.1 0 149v27c0 35.3 28.7 64 64 64h88c22.1 0 40-17.9 40-40s-17.9-40-40-40H96c-8.8 0-16-7.2-16-16s7.2-16 16-16h56c39.8 0 72 32.2 72 72z"/></svg>`,
      change: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M418.4 157.9c35.3-8.3 61.6-40 61.6-77.9c0-44.2-35.8-80-80-80c-43.4 0-78.7 34.5-80 77.5L136.2 151.1C121.7 136.8 101.9 128 80 128c-44.2 0-80 35.8-80 80s35.8 80 80 80c12.2 0 23.8-2.7 34.1-7.6L259.7 407.8c-2.4 7.6-3.7 15.8-3.7 24.2c0 44.2 35.8 80 80 80s80-35.8 80-80c0-27.7-14-52.1-35.4-66.4l37.8-207.7zM156.3 232.2c2.2-6.9 3.5-14.2 3.7-21.7l183.8-73.5c3.6 3.5 7.4 6.7 11.6 9.5L317.6 354.1c-5.5 1.3-10.8 3.1-15.8 5.5L156.3 232.2z"/></svg>`,
      input: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M64 112c-8.8 0-16 7.2-16 16V384c0 8.8 7.2 16 16 16H512c8.8 0 16-7.2 16-16V128c0-8.8-7.2-16-16-16H64zM0 128C0 92.7 28.7 64 64 64H512c35.3 0 64 28.7 64 64V384c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V128zM176 320H400c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H176c-8.8 0-16-7.2-16-16V336c0-8.8 7.2-16 16-16zm-72-72c0-8.8 7.2-16 16-16h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H120c-8.8 0-16-7.2-16-16V248zm16-96h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H120c-8.8 0-16-7.2-16-16V168c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H200c-8.8 0-16-7.2-16-16V248zm16-96h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H200c-8.8 0-16-7.2-16-16V168c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H280c-8.8 0-16-7.2-16-16V248zm16-96h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H280c-8.8 0-16-7.2-16-16V168c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H360c-8.8 0-16-7.2-16-16V248zm16-96h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H360c-8.8 0-16-7.2-16-16V168c0-8.8 7.2-16 16-16zm64 96c0-8.8 7.2-16 16-16h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H440c-8.8 0-16-7.2-16-16V248zm16-96h16c8.8 0 16 7.2 16 16v16c0 8.8-7.2 16-16 16H440c-8.8 0-16-7.2-16-16V168c0-8.8 7.2-16 16-16z"/></svg>`
    };
    this.preRotinas = [
      {
        event: "click",
        title: "Open new page",
        desc: "Use when you want to navigate to another page",
        code: "(page:string){\n  window.location.href = page;\n\n}"
      },
      {
        event: "click",
        title: "Show alert",
        desc: "Use when you want to display an alert message",
        code: "(message:string){\n  alert(message);\n}"
      },
      {
        event: "click",
        title: "Change element text",
        desc: "Use when you want to change the text of an HTML element",
        code: "(elementId:string, newText:string){\n  document.getElementById(elementId).innerText = newText;\n}"
      },
      {
        event: "change",
        title: "Change background color",
        desc: "Use when you want to change the background color of an HTML element",
        code: "(elementId:string, color:string){\n  document.getElementById(elementId).style.backgroundColor = color;\n}"
      },
      {
        event: "change",
        title: "Update paragraph text",
        desc: "Use when you want to update the text of a paragraph with the value from an input",
        code: "(inputId:string, paragraphId:string){\n  const value = document.getElementById(inputId).value;\n  document.getElementById(paragraphId).innerText = value;\n}"
      },
      {
        event: "change",
        title: "Toggle button enabled state",
        desc: "Use when you want to enable or disable a button based on the value of a checkbox",
        code: "(checkboxId:string, buttonId:string){\n  const isChecked = document.getElementById(checkboxId).checked;\n  document.getElementById(buttonId).disabled = !isChecked;\n}"
      },
      {
        event: "input",
        title: "Display input value",
        desc: "Use when you want to display the value being typed in an input field in a span element",
        code: "(inputId:string, spanId:string){\n  const value = document.getElementById(inputId).value;\n  document.getElementById(spanId).innerText = value;\n}"
      },
      {
        event: "input",
        title: "Filter list items",
        desc: "Use when you want to filter the items in a list based on the input value",
        code: "(inputId:string, listId:string){\n  const filter = document.getElementById(inputId).value.toLowerCase();\n  const items = document.getElementById(listId).getElementsByTagName('li');\n  for (let i = 0; i < items.length; i++) {\n    let item = items[i].innerText.toLowerCase();\n    items[i].style.display = item.includes(filter) ? '' : 'none';\n  }\n}"
      },
      {
        event: "input",
        title: "Update element width",
        desc: "Use when you want to update the width of an element based on the value of a range input",
        code: "(inputId:string, elementId:string){\n  const width = document.getElementById(inputId).value;\n  document.getElementById(elementId).style.width = width + 'px';\n}"
      }
    ];
  }
  //---------- COMPONENT---------
  connectedCallback() {
    super.connectedCallback();
    this.init();
  }
  render() {
    if (!this.myInfos && !this.scenario) {
      return this.renderNoSelected();
    }
    if (this.scenario === "init") {
      return html`
                <div style="padding:1rem">
                    ${this.renderScenarioHowDo()}
                </div>
            `;
    }
    if (this.scenario === "yourSelf") {
      return html`
                <div style="padding:1rem">
                    ${this.renderYourSelfDevice()}
                </div>
            `;
    }
    if (this.scenario === "devicePR") {
      return html`
                <div style="padding:1rem">
                    ${this.renderPreReadyDevice()}
                </div>
            `;
    }
    if (this.scenario === "preready") {
      return html`
                <div style="padding:1rem">
                    ${this.renderPreReady()}
                </div>
            `;
    }
  }
  renderNoSelected() {
    return html`<h3 style="text-align:center">${this.msg.noIten}</h3>`;
  }
  renderScenarioHowDo() {
    return html`
            <h4 class="header">
                ${this.msg.event} ${this.myInfos ? this.myInfos.value : ""}
            </h4>
            <div class="scenarioHowDo">
                <h3 style="text-align:center">${this.msg.helpYou}</h3>
                <div class="container">
                    <div class="card" @click="${this.goToYS}">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M246.9 23.7C242.3 6.6 224.8-3.5 207.7 1.1s-27.2 22.1-22.6 39.2L238 237.8c2.5 9.2-4.5 18.2-14 18.2c-6.4 0-12-4.2-13.9-10.3L166.6 102.7c-5.1-16.9-23-26.4-39.9-21.3s-26.4 23-21.3 39.9l62.8 206.4c2.4 7.9-7.2 13.8-13.2 8.1L99.6 283c-16-15.2-41.3-14.6-56.6 1.4s-14.6 41.3 1.4 56.6L156.8 448c43.1 41.1 100.4 64 160 64h10.9 8.2c.1 0 .1-.1 .1-.1s.1-.1 .1-.1c58.3-3.5 108.6-43.2 125.3-99.7l81.2-275c5-16.9-4.7-34.7-21.6-39.8s-34.7 4.7-39.8 21.6L443.5 247.1c-1.6 5.3-6.4 8.9-12 8.9c-7.9 0-13.8-7.3-12.2-15.1l36-170.3c3.7-17.3-7.4-34.3-24.7-37.9s-34.3 7.4-37.9 24.7L355.1 235.1c-2.6 12.2-13.3 20.9-25.8 20.9c-11.9 0-22.4-8-25.4-19.5l-57-212.8z"/></svg>
                        <h2>${this.msg.card1}</h2>
                        <p>${this.msg.card1Desc}</p>
                    </div>
                    <div class="card" @click="${this.goToDevicePR}">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M320 0c17.7 0 32 14.3 32 32V96H472c39.8 0 72 32.2 72 72V440c0 39.8-32.2 72-72 72H168c-39.8 0-72-32.2-72-72V168c0-39.8 32.2-72 72-72H288V32c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16h32c8.8 0 16-7.2 16-16s-7.2-16-16-16H208zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16h32c8.8 0 16-7.2 16-16s-7.2-16-16-16H304zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16h32c8.8 0 16-7.2 16-16s-7.2-16-16-16H400zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224H64V416H48c-26.5 0-48-21.5-48-48V272c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48v96c0 26.5-21.5 48-48 48H576V224h16z"/></svg>
                        <h2>${this.msg.card2}</h2>
                        <p>${this.msg.card2Desc}</p>
                    </div>
                </div>
            </div>
        
        `;
  }
  renderYourSelfDevice() {
    return html`
            <div class="header">
                <span title="back" @click="${this.goToInit}" style="width:10px; position: absolute; left: 20px; top: 0px; cursor:pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" style="fill:white" viewBox="0 0 320 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg>
                </span>
                <h4 class="margin:0px">
                    ${this.msg.event} ${this.myInfos ? this.myInfos.value : ""}
                </h4>
            </div>
            
            <div class="scenarioHowDo">
                
                <h3 style="text-align:center">
                    ${this.msg.scnearioDevice}
                </h3>
                <div class="container">
                    <div class="card" @click="${this.selectedDesktop}">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M64 96c0-35.3 28.7-64 64-64H512c35.3 0 64 28.7 64 64V352H512V96H128V352H64V96zM0 403.2C0 392.6 8.6 384 19.2 384H620.8c10.6 0 19.2 8.6 19.2 19.2c0 42.4-34.4 76.8-76.8 76.8H76.8C34.4 480 0 445.6 0 403.2zM281 209l-31 31 31 31c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-48-48c-9.4-9.4-9.4-24.6 0-33.9l48-48c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9zM393 175l48 48c9.4 9.4 9.4 24.6 0 33.9l-48 48c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l31-31-31-31c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0z"/></svg>
                        <h2>Desktop</h2>
                    </div>
                    <div class="card"  @click="${this.selectedMobile}">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M16 64C16 28.7 44.7 0 80 0H304c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H80c-35.3 0-64-28.7-64-64V64zM224 448a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM304 64H80V384H304V64z"/></svg>
                        <h2>Mobile</h2>
                    </div>
                </div>
            </div>
        
        `;
  }
  renderPreReadyDevice() {
    return html`
            <div class="header">
                <span title="back" @click="${this.goToInit}" style="width:10px; position: absolute; left: 20px; top: 0px; cursor:pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" style="fill:white" viewBox="0 0 320 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg>
                </span>
                <h4 class="margin:0px">
                    ${this.msg.event} ${this.myInfos ? this.myInfos.value : ""}
                </h4>
            </div>
            
            <div class="scenarioHowDo">
                
                <h3 style="text-align:center">
                    ${this.msg.scnearioDevice}
                </h3>
                <div class="container">
                    <div class="card" @click="${this.selDesktopPR}">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M64 96c0-35.3 28.7-64 64-64H512c35.3 0 64 28.7 64 64V352H512V96H128V352H64V96zM0 403.2C0 392.6 8.6 384 19.2 384H620.8c10.6 0 19.2 8.6 19.2 19.2c0 42.4-34.4 76.8-76.8 76.8H76.8C34.4 480 0 445.6 0 403.2zM281 209l-31 31 31 31c9.4 9.4 9.4 24.6 0 33.9s-24.6 9.4-33.9 0l-48-48c-9.4-9.4-9.4-24.6 0-33.9l48-48c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9zM393 175l48 48c9.4 9.4 9.4 24.6 0 33.9l-48 48c-9.4 9.4-24.6 9.4-33.9 0s-9.4-24.6 0-33.9l31-31-31-31c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0z"/></svg>
                        <h2>Desktop</h2>
                    </div>
                    <div class="card"  @click="${this.selMobilePR}">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M16 64C16 28.7 44.7 0 80 0H304c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H80c-35.3 0-64-28.7-64-64V64zM224 448a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM304 64H80V384H304V64z"/></svg>
                        <h2>Mobile</h2>
                    </div>
                </div>
            </div>
        
        `;
  }
  renderPreReady() {
    return html`
            <div class="header">
                <span title="back" @click="${this.goToInit}" style="width:10px; position: absolute; left: 20px; top: 0px; cursor:pointer">
                    <svg xmlns="http://www.w3.org/2000/svg" style="fill:white" viewBox="0 0 320 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M9.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L77.3 256 246.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z"/></svg>
                </span>
                <h4 class="margin:0px">
                    ${this.msg.event} ${this.myInfos ? this.myInfos.value : ""}
                </h4>
            </div>
        
            <div class="scenarioHowDo">
                <h3 style="text-align:center">
                    ${this.msg.selectPreReady}
                </h3>
                <div class="container">
                    ${repeat(
      this.preRotinas,
      (key, idx) => key.event + idx,
      (item, index) => {
        return this.renderItem(item, index);
      }
    )}
                </div>
            </div>
        `;
  }
  renderItem(item, idx) {
    return html`
            <div class="card" .info=${item} @click="${this.selectedItemPR}">
                ${unsafeHTML(this.iconsEvents[item.event])}
                <h2>${item.title}</h2>
                <p>${item.desc}</p>
            </div>
        `;
  }
  //------------IMPLEMETNATION---------
  init() {
    this.setInfos();
  }
  setInfos() {
    if (!window.infoScenarioInsertOrCreateEvent) {
      this.requestUpdate();
      return;
    }
    this.myInfos = Object.assign({}, window.infoScenarioInsertOrCreateEvent);
    delete window.infoScenarioInsertOrCreateEvent;
    this.scenario = "init";
    this.requestUpdate();
  }
  selectedDesktop() {
    if (!this.myInfos) return;
    mls.events.fire(2, "WidgetAction", `{"op":"CreateOrSetEvent", "id":"${this.myInfos.id}", "event":"${this.myInfos.value}", "device":"desktop"}`);
  }
  selectedMobile() {
    if (!this.myInfos) return;
    mls.events.fire(2, "WidgetAction", `{"op":"CreateOrSetEvent", "id":"${this.myInfos.id}", "event":"${this.myInfos.value}", "device":"mobile"}`);
  }
  goToYS() {
    this.scenario = "yourSelf";
    this.requestUpdate();
  }
  goToInit() {
    this.scenario = "init";
    this.requestUpdate();
  }
  goToDevicePR() {
    this.scenario = "devicePR";
    this.requestUpdate();
  }
  selDesktopPR() {
    this.devicePR = "desktop";
    this.scenario = "preready";
    this.requestUpdate();
  }
  selMobilePR() {
    this.devicePR = "mobile";
    this.scenario = "preready";
    this.requestUpdate();
  }
  selectedItemPR(e) {
    e.stopPropagation();
    let el = e.target;
    if (el.className !== "card") {
      el = el.closest(".card");
    }
    if (!el) return;
    const info = el.info;
    if (!info) return;
    if (!this.myInfos) return;
    const j = {
      op: "CreateOrSetEventPR",
      id: this.myInfos.id,
      event: info.event,
      device: this.devicePR,
      func: info.code
    };
    mls.events.fire(2, "WidgetAction", JSON.stringify(j));
  }
}
_init = __decoratorStart(_a);
ScenarioInsertEventOrChange = __decorateElement(_init, 0, "ScenarioInsertEventOrChange", _ScenarioInsertEventOrChange_decorators, ScenarioInsertEventOrChange);
//---------------CSS----------------
ScenarioInsertEventOrChange.styles = css`
        .header{
            text-align: center;
            background: #37369b;
            color: white;
            height: 30px;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-top: 0px;
            margin-bottom: 0px;
            position:relative;
        }

        .scenarioHowDo{
            border:1px solid #37369b;
        }

        .scenarioHowDo .container {
            display: flex;
            gap: 20px;
            justify-content:center;
            padding:3rem;
            flex-wrap: wrap;
        }

        .scenarioHowDo .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            cursor:pointer;
            width: 300px;
        }

        .scenarioHowDo .card:hover {
            box-shadow: 0 5px 9px #37369b87;
        }

        .scenarioHowDo .card svg {
            width: 50px;
            height: 50px;
            margin-bottom: 20px;
        }

        .scenarioHowDo .card h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .scenarioHowDo .card p {
            font-size: 16px;
            color: #666;
        }


    `;
__runInitializers(_init, 1, ScenarioInsertEventOrChange);
export {
  ScenarioInsertEventOrChange,
  _100554_scenarioInsertEventOrChange_getScenaryDetails,
  initCollabSelectOneWithDescription
};
