var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _level_dec, _widget_dec, _info_dec, _a, _IcaPageOverlayItem_decorators, _init;
import { html, LitElement } from "lit";
import { customElement, property } from "lit/decorators.js";
import { getPosition } from "./_100554_icaPageOverlayBase";
function initIcaPageOverlayItem() {
  return true;
}
_IcaPageOverlayItem_decorators = [customElement("ica-page-overlay-item-100554")];
class IcaPageOverlayItem extends (_a = LitElement, _info_dec = [property()], _widget_dec = [property()], _level_dec = [property()], _a) {
  createRenderRoot() {
    return this;
  }
  firstUpdated(_changedProperties) {
    super.firstUpdated(_changedProperties);
    this.setEvents();
  }
  updated(changedProperties) {
    super.updated(changedProperties);
    if (changedProperties.has("level") && changedProperties.get("level") !== void 0) {
      this.checkToChangeWCD();
    }
  }
  render() {
    this.overlay = this.parentElement;
    if (!this.info || !this.boundingPage) return html``;
    const pos = getPosition(this.info, this.boundingPage);
    this.info.element.overlayRef = this;
    this.style.display = "block";
    this.style.position = "absolute";
    this.style.width = pos.width;
    this.style.height = pos.height;
    this.style.top = pos.top;
    this.style.left = pos.left;
    return html``;
  }
  setEvents() {
    this.onmouseover = (e) => {
      this.onIcaOverlayItemOver(e);
    };
    this.onmouseleave = (e) => {
      this.onIcaOverlayItemLeave(e);
    };
    this.onclick = (e) => {
      this.onIcaOverlayItemClick(e);
    };
  }
  onIcaOverlayItemLeave(e) {
    this.style.opacity = "";
    this.style.background = "";
  }
  onIcaOverlayItemOver(e) {
    const wcd = this.querySelector("wcd-toolbox-100554");
    if (wcd) return;
    this.style.background = "#d3e3fd";
    this.style.opacity = ".3";
  }
  onIcaOverlayItemClick(e) {
    return __async(this, null, function* () {
      e.stopPropagation();
      const origin = e.detail.origin;
      yield this.addWCDToolbox();
      if (origin !== "editor") this.selectOnHTML();
    });
  }
  addWCDToolbox() {
    return __async(this, null, function* () {
      if (!this.overlay || !this.info) return;
      this.style.opacity = "";
      this.style.background = "";
      const wcds = this.overlay.querySelectorAll("wcd-toolbox-100554");
      wcds.forEach((wc) => wc.remove());
      const wcd = document.createElement("wcd-toolbox-100554");
      wcd.elICA = this.info.element;
      yield this.setActions();
      let act = this.info.element.actions[this.level];
      console.info({
        actions: JSON.parse(JSON.stringify(act)),
        level: this.level
      });
      if (!act) act = [];
      wcd.actions = act;
      this.appendChild(wcd);
    });
  }
  selectOnHTML() {
    if (!this.info || !this.info.element) return;
    const level = this.info.element.getAttribute("level");
    if (level !== "2") return;
    const id = this.info.element.id;
    if (!id) return;
    const infoL2 = mls.actual[2].left;
    const name = mls.l2.editor.getKey({ project: infoL2.project, shortName: infoL2.shortName });
    const mfile = mls.l2.editor.mfiles[name];
    if (!mfile || !mfile.modelHTML) return;
    const model = mfile.modelHTML;
    const line = model.findMatches(`id="${id}"`, false, false, false, null, true);
    if (!line || !line[0]) return;
    const { startLineNumber } = line[0].range;
    mls.events.fire(2, "WidgetAction", `{"op":"SelectLine", "line":${startLineNumber}, "origin":"preview"}`);
  }
  setActions() {
    return __async(this, null, function* () {
      if (!this.info || !this.info.element) return;
      const el = this.info.element;
      if (el.isLoadMyAction[this.level]) return;
      yield el.setActions(this.level);
      el.isLoadMyAction[this.level] = true;
    });
  }
  checkToChangeWCD() {
    return __async(this, null, function* () {
      const wcd = this.querySelector("wcd-toolbox-100554");
      ;
      if (!wcd) return;
      if (!this.info || !this.info.element) return;
      yield this.addWCDToolbox();
    });
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "info", _info_dec, IcaPageOverlayItem);
__decorateElement(_init, 5, "widget", _widget_dec, IcaPageOverlayItem);
__decorateElement(_init, 5, "level", _level_dec, IcaPageOverlayItem);
IcaPageOverlayItem = __decorateElement(_init, 0, "IcaPageOverlayItem", _IcaPageOverlayItem_decorators, IcaPageOverlayItem);
__runInitializers(_init, 1, IcaPageOverlayItem);
export {
  IcaPageOverlayItem,
  initIcaPageOverlayItem
};
