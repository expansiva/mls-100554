var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || (target[__knownSymbol("metadata")] = array[3]), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _codeDiff_dec, _a, _AimTaskResultLanguageTypescript_decorators, _init;
import { html } from "lit";
import { customElement, query } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
import { initCollabShowCodeDiff100554 } from "./_100554_collabShowCodeDiff";
_AimTaskResultLanguageTypescript_decorators = [customElement("aim-task-result-language-html-100554")];
class AimTaskResultLanguageTypescript extends (_a = AimTaskBase, _codeDiff_dec = [query("collab-show-code-diff-100554")], _a) {
  constructor() {
    super();
    this.result = "";
    this.original = "";
    this.alreadyInit = false;
    initCollabShowCodeDiff100554();
  }
  onInitializing() {
    this.changeFile(this.taskRoot);
  }
  changeFile(taskRoot) {
    if (!taskRoot.args) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": taskroot args is missing");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    const args = JSON.parse(taskRoot.args);
    const mfile = mls.l2.editor.mfiles[args.fileName];
    if (!mfile && !mfile.modelHTML) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no mfile find to this file");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    const result = this.taskChild._tempResult;
    if (!result) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no result find is taskchild");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    const html2 = this.extractHtml(result);
    const model = mfile.modelHTML;
    this.original = model.getValue();
    const startLineNumber = 1;
    const startColumn = 1;
    const endLineNumber = model.getLineCount();
    const endColumn = model.getLineMaxColumn(endLineNumber);
    const newText = html2;
    const editOperation = {
      range: new monaco.Range(startLineNumber, startColumn, endLineNumber, endColumn),
      text: newText,
      forceMoveMarkers: true
    };
    model.pushEditOperations([], [editOperation], () => null);
    this.notifyCompleteByStatus("ok", "");
  }
  extractHtml(src) {
    const regex = /```html([\s\S]+?)```/g;
    const matches = src.match(regex);
    const contents = [];
    let ret = src;
    if (matches) {
      for (const m of matches) {
        const conteudo = m.replace(/```html|```/g, "").trim();
        contents.push(conteudo);
      }
      ret = contents[0];
    }
    return ret;
  }
  handleClick(taskRoot) {
    var _a2;
    this.setValues(taskRoot);
    if (this.alreadyInit) return;
    (_a2 = this.codeDiff) == null ? void 0 : _a2.init();
    this.alreadyInit = true;
  }
  setValues(taskRoot) {
    return __async(this, null, function* () {
      if (!taskRoot.args) return;
      const args = JSON.parse(taskRoot.args);
      if (!this.codeDiff) return;
      this.codeDiff.actualTextResult = this.result.trim();
      this.codeDiff.actualTextDiffModified = this.result.trim();
      this.codeDiff.actualTextDiffOriginal = args.html;
    });
  }
  renderBody(taskRoot, child) {
    const body = child._tempResult || "";
    const h = this.extractHtml(body);
    this.result = h;
    return html`
        <details @click=${() => this.handleClick(taskRoot)}>
            <summary>Result</summary>
            <div>
                <div style='margin: 10px;'>
                    <collab-show-code-diff-100554
                        language="html"
                        withdiff  
                    ></collab-show-code-diff-100554>
                </div> 
            </div>
        </details>
        `;
  }
  onIconClick(action) {
    console.error("dont implemented");
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "codeDiff", _codeDiff_dec, AimTaskResultLanguageTypescript);
AimTaskResultLanguageTypescript = __decorateElement(_init, 0, "AimTaskResultLanguageTypescript", _AimTaskResultLanguageTypescript_decorators, AimTaskResultLanguageTypescript);
__runInitializers(_init, 1, AimTaskResultLanguageTypescript);
export {
  AimTaskResultLanguageTypescript
};
