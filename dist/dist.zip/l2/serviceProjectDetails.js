var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || (target[__knownSymbol("metadata")] = array[3]), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _actualKeyGitHub_dec, _actualProjectDetails_dec, _a, _ServiceProjectDetails100554_decorators, _init;
import { html, css, unsafeHTML } from "lit";
import { customElement, property } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
const message_pt = {
  noProjectSelected: "Nenhum projeto selecionado!",
  resume: "Resumo",
  name: "Nome",
  projectDriver: "Driver do Projeto",
  projectURL: "URL do Projeto",
  designSystems: "Sistemas de Design",
  files: "Arquivos",
  keyGithub: "Chave do GitHub"
};
const message_en = {
  noProjectSelected: "No project selected!",
  resume: "Resume",
  name: "Name",
  projectDriver: "ProjectDriver",
  projectURL: "ProjectURL",
  designSystems: "DesignSystems",
  files: "Files",
  keyGithub: "Key Github"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_ServiceProjectDetails100554_decorators = [customElement("service-project-details-100554")];
class ServiceProjectDetails100554 extends (_a = ServiceBase, _actualProjectDetails_dec = [property()], _actualKeyGitHub_dec = [property()], _a) {
  constructor() {
    super();
    this.msg = messages["en"];
    this.showKey = false;
    this.details = {
      icon: "&#xf15b",
      state: "foreground",
      position: "right",
      tooltip: "Project Details",
      visible: true,
      widget: "_100554_serviceProjectDetails",
      level: [5]
    };
    this.onClickLink = (op) => {
      if (this.menu.setMode) this.menu.setMode("initial");
      return false;
    };
    this.menu = {
      title: "Project",
      actions: {},
      icons: {},
      actionDefault: "",
      // call after close icon clicked
      setMode: void 0,
      // child will set this
      onClickLink: this.onClickLink,
      getLastMode: void 0,
      updateTitle: void 0
    };
    this.iconEye = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M288 32c-80.8 0-145.5 36.8-192.6 80.6C48.6 156 17.3 208 2.5 243.7c-3.3 7.9-3.3 16.7 0 24.6C17.3 304 48.6 356 95.4 399.4C142.5 443.2 207.2 480 288 480s145.5-36.8 192.6-80.6c46.8-43.5 78.1-95.4 93-131.1c3.3-7.9 3.3-16.7 0-24.6c-14.9-35.7-46.2-87.7-93-131.1C433.5 68.8 368.8 32 288 32zM144 256a144 144 0 1 1 288 0 144 144 0 1 1 -288 0zm144-64c0 35.3-28.7 64-64 64c-7.1 0-13.9-1.2-20.3-3.3c-5.5-1.8-11.9 1.6-11.7 7.4c.3 6.9 1.3 13.8 3.2 20.7c13.7 51.2 66.4 81.6 117.6 67.9s81.6-66.4 67.9-117.6c-11.1-41.5-47.8-69.4-88.6-71.1c-5.8-.2-9.2 6.1-7.4 11.7c2.1 6.4 3.3 13.2 3.3 20.3z"/></svg>
    `;
    this.iconEyeClose = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--!Font Awesome Free 6.5.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2024 Fonticons, Inc.--><path d="M38.8 5.1C28.4-3.1 13.3-1.2 5.1 9.2S-1.2 34.7 9.2 42.9l592 464c10.4 8.2 25.5 6.3 33.7-4.1s6.3-25.5-4.1-33.7L525.6 386.7c39.6-40.6 66.4-86.1 79.9-118.4c3.3-7.9 3.3-16.7 0-24.6c-14.9-35.7-46.2-87.7-93-131.1C465.5 68.8 400.8 32 320 32c-68.2 0-125 26.3-169.3 60.8L38.8 5.1zM223.1 149.5C248.6 126.2 282.7 112 320 112c79.5 0 144 64.5 144 144c0 24.9-6.3 48.3-17.4 68.7L408 294.5c8.4-19.3 10.6-41.4 4.8-63.3c-11.1-41.5-47.8-69.4-88.6-71.1c-5.8-.2-9.2 6.1-7.4 11.7c2.1 6.4 3.3 13.2 3.3 20.3c0 10.2-2.4 19.8-6.6 28.3l-90.3-70.8zM373 389.9c-16.4 6.5-34.3 10.1-53 10.1c-79.5 0-144-64.5-144-144c0-6.9 .5-13.6 1.4-20.2L83.1 161.5C60.3 191.2 44 220.8 34.5 243.7c-3.3 7.9-3.3 16.7 0 24.6c14.9 35.7 46.2 87.7 93 131.1C174.5 443.2 239.2 480 320 480c47.8 0 89.9-12.9 126.2-32.5L373 389.9z"/></svg>
    `;
    mls.events.addListener(5, "ProjectSelected", (ev) => this.onProjectSelected(ev));
  }
  onServiceClick(visible, reinit, el) {
  }
  getDetailsProject(project) {
    return __async(this, null, function* () {
      const details = yield mls.l5.getProjectConf(project);
      if (!this.actualProjectDetails) this.actualProjectDetails = {};
      this.actualProjectDetails.designSystems = details.designSystems ? details.designSystems.length : 0;
      this.actualProjectDetails.name = details.name;
      this.actualProjectDetails.projectDriver = details.projectDriver;
      this.actualProjectDetails.projectURL = details.projectURL;
      this.actualProjectDetails.files = Object.keys(mls.stor.files).filter((item) => item.startsWith(project.toString())).length;
      this.actualKeyGitHub = localStorage == null ? void 0 : localStorage.getItem("keyGitHub");
      this.requestUpdate();
    });
  }
  onProjectSelected(ev) {
    if (!ev.desc) return;
    const data = JSON.parse(ev.desc);
    this.getDetailsProject(data.value);
  }
  getLastProject() {
    const lastPrjId = localStorage.getItem("l5-last-project");
    if (lastPrjId) this.getDetailsProject(+lastPrjId);
  }
  handleChangeKey() {
    if (this.actualKeyGitHub) {
      localStorage == null ? void 0 : localStorage.setItem("keyGitHub", this.actualKeyGitHub);
    }
  }
  handleInputChangeKey(value) {
    this.actualKeyGitHub = value;
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    this.getLastProject();
    return html`
            ${!this.actualProjectDetails ? html`<h4> ${this.msg.noProjectSelected}</h4>` : html`
                <section class="section-details">
                    <details open>
                        <summary>${this.msg.resume}</summary>
                        <ul>
                            <li>${this.msg.name}: ${this.actualProjectDetails.name}</li>
                            <li>${this.msg.projectDriver}: ${this.actualProjectDetails.projectDriver}</li>
                            <li>${this.msg.projectURL}: ${this.actualProjectDetails.projectURL}</li>
                            <li>${this.msg.designSystems}: ${this.actualProjectDetails.designSystems}</li>
                            <li>${this.msg.files}: ${this.actualProjectDetails.files}</li>
                        </ul>
                    </details>
                </section>
                <section
                    style=${this.actualProjectDetails.projectDriver === "github" ? "display: block" : "display:none"} 
                    class="section-config-github">
                    <div>
                        <label>${this.msg.keyGithub}</label>
                        <div class="cls_key">
                            <input .value=${this.showString(this.actualKeyGitHub, this.showKey)} @input="${this.handleInputChangeKey}"></input rows=4>
                            <button @click="${this.clickShowEye}">${this.showKey ? unsafeHTML(this.iconEye) : unsafeHTML(this.iconEyeClose)}</button>
                        </div>
                        <button @click=${this.handleChangeKey}>Alterar</button>
                    </div>
                </section>
                <section class="cls_tree_branch">
                    ${this.renderCreateTreeFork()}
                </section>
                `}`;
  }
  renderCreateTreeFork() {
    return html`
            <details>
                <summary>Branchs:</summary>
                <ul>
                    <li>
                        owner
                        <ul>
                            <li>
                                <a href="">expansiva</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul>
                    <li>
                        user
                        <ul>
                            <li>
                                santiagoExpansiva
                                <ul>
                                    <li>
                                        <a href="">mls-20001</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </details>
        `;
  }
  clickShowEye(e) {
    e.stopPropagation();
    if (this.showKey) this.showKey = false;
    else this.showKey = true;
    this.requestUpdate();
  }
  showString(input, show) {
    if (!input) return "";
    if (show) return input;
    else return this.maskString(input);
  }
  maskString(input) {
    return "*".repeat(input.length);
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "actualProjectDetails", _actualProjectDetails_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "actualKeyGitHub", _actualKeyGitHub_dec, ServiceProjectDetails100554);
ServiceProjectDetails100554 = __decorateElement(_init, 0, "ServiceProjectDetails100554", _ServiceProjectDetails100554_decorators, ServiceProjectDetails100554);
ServiceProjectDetails100554.styles = css`[[mls_getDefaultDesignSystem]]`;
__runInitializers(_init, 1, ServiceProjectDetails100554);
export {
  ServiceProjectDetails100554
};
