var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _buttonSeePrj_dec, _historieEl_dec, _titleList_dec, _list_dec, _currentScenario_dec, _lastPrjId_dec, _state_dec, _actualKeyGitHub_dec, _files_dec, _projectCreated_dec, _designSystems_dec, _projectURL_dec, _projectDriver_dec, _name_dec, _a, _ServiceProjectDetails100554_decorators, _init;
import { html, css } from "lit";
import { customElement, property, queryAll, query } from "lit/decorators.js";
import { ServiceBase } from "./_100554_serviceBase";
import {
  collab_chevron_right,
  collab_eye,
  collab_eye_slash
} from "./_100554_collabIcons";
const message_pt = {
  noProjectSelected: "Nenhum projeto selecionado!",
  resume: "Resumo",
  name: "Nome",
  projectDriver: "Driver do Projeto",
  projectURL: "URL do Projeto",
  designSystems: "Design systems",
  files: "Arquivos",
  keyGithub: "Chave do GitHub",
  project: "Projeto",
  noProject: "Nenhum projeto selecionado, por favor selecione.",
  selectProject: "Selecione o projeto",
  btnChange: "Alterar",
  btnAddNewProject: "Adicionar novo projeto",
  btnCreateProject: "Criar projeto",
  btnRefreshOrg: "Atualizar",
  btnOpenProject: "Abrir projeto",
  addProject: "Novo projeto",
  placeholderFilter: "Filtro",
  push: "Permite que os desenvolvedores fa\xE7am push diretamente para a branch principal.",
  pullRequest: "Exige que todas as mudan\xE7as sejam feitas atrav\xE9s de Pull Requests, permitindo revis\xF5es de c\xF3digo e aprova\xE7\xE3o antes da integra\xE7\xE3o na branch principal.",
  projectNameLabel: "Nome do projeto",
  driverNameLabel: "Driver",
  organizationLabel: "Organiza\xE7\xE3o",
  visibilityLabel: "Visibilidade do projeto",
  visibilityPublicOption: "P\xFAblico - Qualquer pessoa pode ver este reposit\xF3rio.",
  visibilityPrivateOption: "Privado - Voc\xEA escolhe quem pode ver.",
  teamLabel: "Time",
  loadingAddText1: "Buscando informa\xE7\xF5es do usu\xE1rio",
  loadingAddText2: "Buscando organiza\xE7\xF5es do usu\xE1rio",
  step1Title: "Passo 1",
  step2Title: "Passo 2",
  step3Title: "Passo 3",
  step1Msg: "Escolha o driver para carregar suas organiza\xE7\xF5es existentes.",
  step2Msg: "Agora selecione a organiza\xE7\xE3o e o modo de atualiza\xE7\xE3o.",
  step3Msg: "Finalmente, selecione a equipe e a visibilidade do projeto."
};
const message_en = {
  noProjectSelected: "No project selected!",
  resume: "Resume",
  name: "Name",
  projectDriver: "ProjectDriver",
  projectURL: "ProjectURL",
  designSystems: "Design systems",
  files: "Files",
  keyGithub: "Key Github",
  project: "Project",
  noProject: "No project selected, please select",
  selectProject: "Select project",
  btnChange: "Change",
  btnAddNewProject: "Add new Project",
  btnCreateProject: "Create project",
  btnRefreshOrg: "Refresh",
  btnOpenProject: "Open project",
  addProject: "New project",
  placeholderFilter: "Filter",
  push: "Allows developers to push directly to the main branch.",
  pullRequest: "Requires all changes to be made through Pull Requests, allowing code reviews and approval before integration into the main branch.",
  projectNameLabel: "Project name",
  driverNameLabel: "Driver",
  organizationLabel: "Organization",
  visibilityLabel: "Project visibility",
  visibilityPublicOption: "Public - Anyone can see this repository.",
  visibilityPrivateOption: "Private - You choose who can see.",
  teamLabel: "Team",
  loadingAddText1: "Loading user informations",
  loadingAddText2: "Loading user organizations",
  step1Title: "Step 1",
  step2Title: "Step 2",
  step3Title: "Step 3",
  step1Msg: "Choose the driver to load your existing organizations.",
  step2Msg: "Now select the organization and the update mode.",
  step3Msg: "Finally select the team and the visibility of the project."
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_ServiceProjectDetails100554_decorators = [customElement("service-project-details-100554")];
class ServiceProjectDetails100554 extends (_a = ServiceBase, _name_dec = [property()], _projectDriver_dec = [property()], _projectURL_dec = [property()], _designSystems_dec = [property()], _projectCreated_dec = [property()], _files_dec = [property()], _actualKeyGitHub_dec = [property()], _state_dec = [property()], _lastPrjId_dec = [property()], _currentScenario_dec = [property({ type: String })], _list_dec = [queryAll(".serviceListProjects .serviceListList li")], _titleList_dec = [queryAll(".serviceListProjects .serviceListTitle")], _historieEl_dec = [query(".l5-project-list-history")], _buttonSeePrj_dec = [query("#button-see-project")], _a) {
  constructor() {
    super();
    this.msg = messages["en"];
    this.showKey = false;
    this.details = {
      icon: "&#xf15b",
      state: "foreground",
      position: "left",
      tooltip: "Project Details",
      visible: true,
      widget: "_100554_serviceProjectDetails",
      level: [5]
    };
    this.onClickLink = (op) => {
      if (this.menu.setMode) this.menu.setMode("initial");
      return false;
    };
    this.onClickTitle = () => {
      this.changeScenario("select");
    };
    this.menu = {
      title: {
        icon: "&#xf053",
        text: ""
      },
      actions: {},
      icons: {},
      actionDefault: "",
      // call after close icon clicked
      setMode: void 0,
      // child will set this
      onClickLink: this.onClickLink,
      getLastMode: void 0,
      updateTitle: void 0,
      onClickTitle: this.onClickTitle
    };
    this.projectCreated = __runInitializers(_init, 24, this, false), __runInitializers(_init, 27, this);
    this.state = __runInitializers(_init, 36, this, { history: [], orgs: [], projectSelected: void 0 }), __runInitializers(_init, 39, this);
    this.currentScenario = __runInitializers(_init, 44, this, "details"), __runInitializers(_init, 47, this);
    this.projectCreatedNumber = 100554;
    this.filterTimeout = 0;
    mls.events.addListener(5, "ProjectSelected", (ev) => this.onProjectSelected(ev));
  }
  onServiceClick(visible, reinit, el) {
  }
  changeScenario(scenario) {
    this.currentScenario = scenario;
  }
  getDetailsProject(project) {
    return __async(this, null, function* () {
      let details;
      try {
        details = yield mls.l5.getProjectConf(project);
      } catch (err) {
        details = mls.l5.getProjectSettings(project);
      }
      this.designSystems = details.designSystems ? details.designSystems.length : 0;
      this.name = details.name;
      this.projectDriver = details.projectDriver;
      this.projectURL = details.projectURL;
      this.files = Object.keys(mls.stor.files).filter((item) => item.startsWith(project.toString())).length;
      this.actualKeyGitHub = localStorage == null ? void 0 : localStorage.getItem("keyGitHub");
    });
  }
  onProjectSelected(ev) {
    if (!ev.desc) return;
    const data = JSON.parse(ev.desc);
    this.getDetailsProject(data.value);
  }
  getLastProject() {
    this.lastPrjId = localStorage.getItem("l5-last-project");
    return this.lastPrjId;
  }
  handleChangeKey() {
    if (this.actualKeyGitHub) {
      localStorage == null ? void 0 : localStorage.setItem("keyGitHub", this.actualKeyGitHub);
    }
  }
  handleInputChangeKey(value) {
    this.actualKeyGitHub = value;
  }
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    this.getLastProject();
    return html`
            <section>
                ${this.renderScenario()}
            </section>
        `;
  }
  renderScenario() {
    switch (this.currentScenario) {
      case "details":
        return html`
                    ${this.renderDetails()}
                `;
      case "select":
        return html`
                    ${this.renderSelectProject()}
                `;
      case "add":
        return html`
                    ${this.renderAdd()}
                `;
    }
  }
  renderDetails() {
    this.projectCreated = false;
    if (this.lastPrjId) this.getDetailsProject(+this.lastPrjId);
    else {
      this.changeScenario("select");
      return;
    }
    this.menu.title.text = this.msg.project + " : " + this.lastPrjId;
    this.menu.title.icon = "&#xf053";
    if (this.menu.updateTitle) this.menu.updateTitle();
    return html`
            ${!this.lastPrjId ? html`<h4> ${this.msg.noProjectSelected}</h4>` : html`
                <section class="section-details">
                    <details open>
                        <summary>${this.msg.resume}</summary>
                        <ul>
                            <li>${this.msg.name}: ${this.name}</li>
                            <li>${this.msg.projectDriver}: ${this.projectDriver}</li>
                            <li>${this.msg.projectURL}: ${this.projectURL}</li>
                            <li>${this.msg.designSystems}: ${this.designSystems}</li>
                            <li>${this.msg.files}: ${this.files}</li>
                        </ul>
                    </details>
                </section>
                <section
                    style=${this.projectDriver === "github" ? "display: block" : "display:none"} 
                    class="section-config-github">
                    <div>
                        <label>${this.msg.keyGithub}</label>
                        <div class="cls_key">
                            <input .value=${this.showString(this.actualKeyGitHub, this.showKey)} @input="${this.handleInputChangeKey}"></input rows=4>
                            <button @click="${this.clickShowEye}">${this.showKey ? collab_eye : collab_eye_slash}</button>
                        </div>
                        <button @click=${this.handleChangeKey}>${this.msg.btnChange}</button>
                    </div>
                </section>
                <section class="cls_tree_branch">
                    ${this.renderCreateTreeFork()}
                </section>
                `}`;
  }
  renderCreateTreeFork() {
    return html`
            <details>
                <summary>Branchs:</summary>
                <ul>
                    <li>
                        owner
                        <ul>
                            <li>
                                <a href="">expansiva</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <ul>
                    <li>
                        user
                        <ul>
                            <li>
                                santiagoExpansiva
                                <ul>
                                    <li>
                                        <a href="">mls-20001</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>
            </details>
        `;
  }
  renderSelectProject() {
    this.menu.title.text = this.msg.selectProject;
    this.menu.title.icon = "";
    if (this.menu.updateTitle) this.menu.updateTitle();
    this.getOrgsAndProjects();
    this.state.history = this.loadHistory();
    return html`
            <div class="scroll-custom l5-project-list">
                <div class="filter-container" style="display:flex">
                    <input style="width:calc(100% - 160px)" type="text" placeholder="Filter" @input=${this._filterProjects}>
                    <button style="margin-left:5px; width:150px;" @click=${this.onAddNewProjectClick}>${this.msg.btnAddNewProject}</button>
                </div>
                <div class="l5-project-list-history" style="${this.state.history.length === 0 ? "display:none" : "display: block"}">
                    <div class="serviceListTitle">History</div>
                    <ul class="serviceListList">
                        ${this.state.history.map((his) => html`
                            <li class=${this.lastPrjId && +this.lastPrjId === his.project ? "selected" : ""} @click=${() => {
      this.onHistoryClick(his);
    }}>
                                <div>
                                    <span>${his.name + " (" + his.project.toString() + ")"}</span>
                                </div>
                                <span>${collab_chevron_right}</span>
                            </li>
                        `)}
                    </ul>
                </div>
                <div class="serviceListProjects">
                    ${this.state.orgs.map((org) => {
      return html`
                            <div class="serviceListTitle">${org.key}</div>
                            <ul class="serviceListList">
                                ${org.projects.map((prj) => html`
                                <li class=${this.lastPrjId && +this.lastPrjId === prj.id ? "selected" : ""} @click=${() => this.onProjectClick(prj)}>
                                    <div>
                                        <span>${prj.name + " (" + prj.id.toString() + ")"}</span>
                                    </div>
                                <span>${collab_chevron_right}</span>
                                </li>
                            `)}
                            </ul>
                            `;
    })}
                
                </div>
            </div>
        `;
  }
  renderAdd() {
    this.menu.title.text = this.msg.addProject;
    this.menu.title.icon = "";
    if (this.menu.updateTitle) this.menu.updateTitle();
    return html`
        <collab-new-project-100554 @collab-new-project=${this.onProjectCreated}></collab-new-project-100554>
        <div style="display:flex; justify-content:center;">
            ${this.projectCreated ? html`<button id="button-see-project" @click=${this.onSeeProjectClick}>${this.msg.btnOpenProject}</button>` : ""}
        </div>
        `;
  }
  onProjectCreated(ev) {
    return __async(this, null, function* () {
      this.projectCreated = true;
      this.projectCreatedNumber = ev.detail;
      setTimeout(() => {
        if (this.buttonSeePrj) this.buttonSeePrj.scrollIntoView();
      }, 150);
    });
  }
  onSeeProjectClick() {
    return __async(this, null, function* () {
      this.setProjectActual(this.projectCreatedNumber);
      this._fireEventProjectSelected(this.projectCreatedNumber);
      this.changeScenario("details");
      yield this.loadProjectActual(this.projectCreatedNumber);
      this.projectCreated = false;
    });
  }
  // LIST
  onAddNewProjectClick() {
    this.changeScenario("add");
  }
  onProjectClick(item) {
    return __async(this, null, function* () {
      this.setProjectActual(item.id);
      this.setOrgActual(item.id);
      this.addOnHistory(item);
      this._fireEventProjectSelected(item.id);
      this.changeScenario("details");
      yield this.loadProjectActual(item.id);
    });
  }
  onHistoryClick(item) {
    return __async(this, null, function* () {
      this.setProjectActual(item.project);
      this.setOrgActual(item.project);
      this._fireEventProjectSelected(item.project);
      this.changeScenario("details");
      yield this.loadProjectActual(item.project);
    });
  }
  loadProjectActual(project) {
    return __async(this, null, function* () {
      yield mls.stor.server.loadProjectInfoIfNeeded(project);
    });
  }
  setOrgActual(project) {
    const orgIndex = mls.l5.getProjectOrgIndex(project);
    mls.l5.setActualOrg(orgIndex);
  }
  setProjectActual(project) {
    mls.actual[5].project = project;
    this.state.projectSelected = project;
    localStorage.setItem("l5-last-project", project.toString());
  }
  addOnHistory(item) {
    const indexInHistory = this.state.history.findIndex((his) => his.name === item.name && his.project === item.id);
    if (indexInHistory > -1) this.state.history.splice(indexInHistory, 1);
    const historyItem = {
      project: item.id,
      name: item.name
    };
    this.state.history.unshift(historyItem);
    if (this.state.history.length > 9) this.state.history.pop();
    localStorage.setItem("l5-projects-history", JSON.stringify(this.state.history));
  }
  _filterProjects(ev) {
    const filterText = ev.target.value;
    clearTimeout(this.filterTimeout);
    this.filterTimeout = setTimeout(() => {
      var _a2, _b, _c;
      if (filterText) {
        (_a2 = this.titleList) == null ? void 0 : _a2.forEach((item) => {
          item.style.display = "none";
        });
        if (this.historieEl) this.historieEl.style.display = "none";
      } else {
        (_b = this.titleList) == null ? void 0 : _b.forEach((item) => {
          item.style.display = "";
        });
        if (this.historieEl) this.historieEl.style.display = "block";
      }
      (_c = this.list) == null ? void 0 : _c.forEach((li) => {
        var _a3;
        li.style.display = "";
        const text = (_a3 = li.querySelector("span")) == null ? void 0 : _a3.innerText;
        if (text && text.toLowerCase().indexOf(filterText.toLowerCase()) < 0) li.style.display = "none";
      });
    }, 100);
  }
  _fireEventProjectSelected(project) {
    const params = {
      emitter: "left",
      value: project
    };
    mls.events.fire(5, ["ProjectSelected"], JSON.stringify(params));
  }
  clearState() {
    this.state.history = [];
    this.state.orgs = [];
  }
  loadHistory() {
    const lcHistory = localStorage.getItem("l5-projects-history");
    let rc = [];
    if (!lcHistory) return rc;
    try {
      rc = JSON.parse(lcHistory);
    } catch (err) {
      throw new Error("Error on load l5 project history");
    }
    return rc;
  }
  getOrgsAndProjects() {
    this.clearState();
    Object.keys(mls.stor.orgs).forEach((org, index) => {
      const { name, description, created_at, projects } = mls.stor.orgs[org].sett;
      const prj = [];
      projects.forEach((p) => {
        try {
          const json = JSON.parse(p.value);
          if (!json.l5_actionPrjSettings || !json.l5_actionPrjSettings.projectDriver || json.l5_actionPrjSettings.projectDriver === "mls") return;
          prj.push(p);
        } catch (e) {
        }
      });
      if (prj.length <= 0) return;
      const obj = {
        name,
        created_at,
        description,
        key: org,
        projects: prj
      };
      this.state.orgs.push(obj);
    });
  }
  clickShowEye(e) {
    e.stopPropagation();
    if (this.showKey) this.showKey = false;
    else this.showKey = true;
    this.requestUpdate();
  }
  showString(input, show) {
    if (!input) return "";
    if (show) return input;
    else return this.maskString(input);
  }
  maskString(input) {
    return "*".repeat(input.length);
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "name", _name_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "projectDriver", _projectDriver_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "projectURL", _projectURL_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "designSystems", _designSystems_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "projectCreated", _projectCreated_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "files", _files_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "actualKeyGitHub", _actualKeyGitHub_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "state", _state_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "lastPrjId", _lastPrjId_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "currentScenario", _currentScenario_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "list", _list_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "titleList", _titleList_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "historieEl", _historieEl_dec, ServiceProjectDetails100554);
__decorateElement(_init, 5, "buttonSeePrj", _buttonSeePrj_dec, ServiceProjectDetails100554);
ServiceProjectDetails100554 = __decorateElement(_init, 0, "ServiceProjectDetails100554", _ServiceProjectDetails100554_decorators, ServiceProjectDetails100554);
ServiceProjectDetails100554.styles = css`[[mls_getDefaultDesignSystem]]`;
__runInitializers(_init, 1, ServiceProjectDetails100554);
export {
  ServiceProjectDetails100554
};
