import { html } from "lit";
import { CollabLitElement } from "./_100554_collabLitElement";
class CollabPageElement extends CollabLitElement {
  connectedCallback() {
    super.connectedCallback();
    this.setupEventListeners();
  }
  setupEventListeners() {
    const device = this.getVariationDevice();
    const elements = this.querySelectorAll("[data-event]");
    const that = this;
    elements.forEach((element) => {
      var _a;
      const events = ((_a = element.getAttribute("data-event")) == null ? void 0 : _a.split(" ")) || [];
      const elementId = element.getAttribute("id");
      events.forEach((event) => {
        const handlerGeneric = `handle${event.charAt(0).toUpperCase() + event.slice(1)}`;
        const handlerSpecificID = `${handlerGeneric}${elementId}`;
        const handlerSpecificDevice = `${handlerSpecificID}${device}`;
        if (that[handlerSpecificDevice]) {
          element.addEventListener(event, that[handlerSpecificDevice].bind(this));
        } else if (that[handlerSpecificID]) {
          element.addEventListener(event, that[handlerSpecificID].bind(this));
        } else if (that[handlerGeneric]) {
          element.addEventListener(event, that[handlerGeneric].bind(this));
        }
      });
    });
  }
  getVariationDevice() {
    const device = (document.documentElement.getAttribute("variation") || "desktop").toLowerCase();
    return device;
  }
  createRenderRoot() {
    return this;
  }
  render() {
    return html`<slot></slot>`;
  }
}
export {
  CollabPageElement
};
