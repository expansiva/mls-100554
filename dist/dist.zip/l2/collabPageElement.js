var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _level_dec, _a, _init;
import { html } from "lit";
import { property } from "lit/decorators.js";
import { CollabLitElement } from "./_100554_collabLitElement";
class CollabPageElement extends (_a = CollabLitElement, _level_dec = [property({ type: String, reflect: true })], _a) {
  constructor() {
    super(...arguments);
    this.isPage = true;
    this.level = __runInitializers(_init, 8, this, mls.actualLevel.toString() || "7"), __runInitializers(_init, 11, this);
    this.actualSelected = null;
  }
  connectedCallback() {
    super.connectedCallback();
    this.setupEventListeners();
  }
  setupEventListeners() {
    let device = this.getVariationDevice();
    if (device.length > 0) device = device.charAt(0).toUpperCase() + device.slice(1);
    const elements = this.querySelectorAll("[data-event]");
    const that = this;
    elements.forEach((element) => {
      var _a2;
      const events = ((_a2 = element.getAttribute("data-event")) == null ? void 0 : _a2.split(" ")) || [];
      const elementId = element.getAttribute("id");
      events.forEach((event) => {
        const handlerGeneric = `handle${event.charAt(0).toUpperCase() + event.slice(1)}`;
        const handlerSpecificID = `${handlerGeneric}${elementId}`;
        const handlerSpecificDevice = `${handlerSpecificID}${device}`;
        if (that[handlerSpecificDevice]) {
          element.addEventListener(event, that[handlerSpecificDevice].bind(this));
        } else if (that[handlerSpecificID]) {
          element.addEventListener(event, that[handlerSpecificID].bind(this));
        } else if (that[handlerGeneric]) {
          element.addEventListener(event, that[handlerGeneric].bind(this));
        }
      });
    });
  }
  getVariationDevice() {
    const device = (document.documentElement.getAttribute("data-device") || "desktop").toLowerCase();
    return device;
  }
  createRenderRoot() {
    return this;
  }
  firstUpdated(changedProperties) {
    super.firstUpdated(changedProperties);
    setTimeout(() => {
      this.checkToAddOverlay();
    }, 500);
    this.initPage();
  }
  updated(changedProperties) {
    super.updated(changedProperties);
    if (changedProperties.has("level") && changedProperties.get("level") !== void 0) {
      this.checkToAddOverlay();
    }
  }
  checkToAddOverlay() {
    if (this.overlay) this.overlay.remove();
    this.createOverlay();
  }
  createOverlay() {
    this.overlay = document.createElement("wcd-overlay");
    this.overlay.style.position = "absolute";
    this.overlay.style.width = "100%";
    this.overlay.style.height = "100%";
    this.overlay.style.zIndex = "9999";
    this.overlay.style.top = "0";
    this.overlay.onclick = (e) => {
    };
    if (this.resizeObserver) this.resizeObserver.disconnect();
    this.resizeObserver = new ResizeObserver((entries) => {
      console.info(entries);
      for (let entry of entries) {
        this.updateSizeOverlayItems();
      }
    });
    this.resizeObserver.observe(this.overlay);
    const boundingPage = this.getBoundingClientRect();
    const icas = this.findAllElementsIca(this);
    icas.forEach((item) => {
      this.createOverlayItem(item, this.overlay, boundingPage);
    });
    this.appendChild(this.overlay);
  }
  updateSizeOverlayItems() {
    if (!this.overlay) return;
    const items = Array.from(this.overlay.children);
    const boundingPage = this.getBoundingClientRect();
    items.forEach((item) => {
      const { x, y, height, width } = item.info.element.getBoundingClientRect();
      item.info.x = x;
      item.info.y = y;
      item.info.height = height;
      item.info.width = width;
      const pos = this.getPosition(item.info, boundingPage);
      item.style.width = pos.width;
      item.style.height = pos.height;
      item.style.top = pos.top;
      item.style.left = pos.left;
    });
  }
  createOverlayItem(icaInfo, content, boundingPage) {
    const pos = this.getPosition(icaInfo, boundingPage);
    const icaOverlayItem = document.createElement("wcd-overlay-item");
    icaOverlayItem.setAttribute("widget", icaInfo.element.tagName.toLowerCase());
    icaOverlayItem.info = icaInfo;
    icaOverlayItem.style.position = "absolute";
    icaOverlayItem.style.width = pos.width;
    icaOverlayItem.style.height = pos.height;
    icaOverlayItem.style.zIndex = "9999";
    icaOverlayItem.style.top = pos.top;
    icaOverlayItem.style.left = pos.left;
    icaOverlayItem.onmouseover = () => {
      const items = Array.from(content.children);
      items.forEach((item) => {
        item.style.opacity = "";
        item.style.background = "";
      });
      icaOverlayItem.style.background = "#d3e3fd";
      icaOverlayItem.style.opacity = ".3";
    };
    icaOverlayItem.onclick = (e) => {
      e.stopPropagation();
      if (!this.overlay) return;
      const wcds = this.overlay.querySelectorAll("wcd-toolbox-100554");
      wcds.forEach((wc) => wc.remove());
      const wcd = document.createElement("wcd-toolbox-100554");
      wcd.elICA = icaOverlayItem.info.element;
      icaOverlayItem.appendChild(wcd);
    };
    content.appendChild(icaOverlayItem);
  }
  getPosition(icaInfo, boundingPage) {
    const elBase = icaInfo.element;
    let { width, height } = icaInfo;
    const ad3 = (n1, s1, s2) => n1 + parseInt(s1, 10) + parseInt(s2, 10);
    const { marginTop, marginBottom, marginLeft, marginRight, paddingTop, paddingBottom, paddingLeft, paddingRight } = window.getComputedStyle(elBase);
    let left = icaInfo.x;
    let top = icaInfo.y;
    left -= parseInt(marginLeft, 10);
    top -= parseInt(marginTop, 10);
    width = Math.max(ad3(width, marginLeft, marginRight), ad3(0, paddingLeft, paddingRight));
    if (width > elBase.ownerDocument.body.clientWidth) width -= 3;
    height = Math.max(ad3(height, marginTop, marginBottom), ad3(0, paddingTop, paddingBottom));
    return {
      left: `${left - boundingPage.left}px`,
      top: `${top - boundingPage.top}px`,
      width: `${width}px`,
      height: `${height}px`
    };
  }
  onClickOverlay(e) {
    const elements = this.ownerDocument.elementsFromPoint(e.clientX, e.clientY);
    const mostDepth = elements[1];
    if (!mostDepth) return;
    const allIcas = this.findAllElementsIca(mostDepth);
    const finalEl = this.findMostDeepElementFromPoint(allIcas, e.clientX, e.clientY);
    this.actualSelected = finalEl;
    console.info(this.actualSelected);
  }
  findMostDeepElementFromPoint(arr, clientX, clientY) {
    function isBetween(nr, min, max) {
      return nr >= min && nr <= max;
    }
    function findMaxDepthElement(elements) {
      if (elements.length === 0) return null;
      return elements.reduce((max, current) => {
        return current.depth > max.depth ? current : max;
      });
    }
    const res = [];
    arr.forEach((ica) => {
      const { x, y, height, width } = ica.element.getBoundingClientRect();
      const isBtwX = isBetween(clientX, x, x + width);
      const isBtwY = isBetween(clientY, y, y + height);
      if (isBtwY && isBtwX) {
        res.push(ica);
      }
    });
    const mostDepth = findMaxDepthElement(res);
    if (!mostDepth) return null;
    else return mostDepth.element;
  }
  findAllElementsIca(el) {
    let elements = [];
    let elToSearch = el;
    function traverseShadowRoot(element, depth) {
      if (element.tagName.toLowerCase().startsWith("ica")) {
        const { x, y, height, width } = element.getBoundingClientRect();
        elements.push({ element, depth, x, y, height, width, opacity: element.style.opacity });
        return;
      }
      if (element.shadowRoot) {
        element.shadowRoot.querySelectorAll("*").forEach((item) => {
          traverseShadowRoot(item, depth + 1);
        });
      } else {
        const children = Array.from(element.children);
        if (children.length > 0) {
          children.forEach((child) => traverseShadowRoot(child, depth + 1));
        }
      }
    }
    if (el.shadowRoot) elToSearch = el.shadowRoot;
    elToSearch.querySelectorAll("*").forEach((item) => {
      traverseShadowRoot(item, 0);
    });
    return elements;
  }
  findClosestIcaParent(element) {
    let elToSearch = element;
    function traverseParents(currentElement) {
      if (!currentElement) return null;
      if (currentElement.tagName.toLowerCase().startsWith("ica")) {
        return currentElement;
      } else {
        if (currentElement.parentElement) {
          return traverseParents(currentElement.parentElement);
        } else {
          const parentNode = currentElement.parentNode;
          if (parentNode && parentNode.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
            const hostElement = parentNode.host;
            if (hostElement instanceof Element) {
              return traverseParents(hostElement);
            }
          }
        }
      }
      return null;
    }
    if (element.shadowRoot) elToSearch = element.shadowRoot;
    return traverseParents(element.parentElement);
  }
  render() {
    this.style.position = "relative";
    return html``;
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "level", _level_dec, CollabPageElement);
__decoratorMetadata(_init, CollabPageElement);
function getEventName(eventName, elementId, device) {
  const handlerGeneric = `handle${eventName.charAt(0).toUpperCase() + eventName.slice(1)} `;
  if (!elementId) return handlerGeneric;
  const handlerSpecificID = `${handlerGeneric}${elementId} `;
  if (!device) return handlerSpecificID;
  if (device.length > 0) device = device.charAt(0).toUpperCase() + device.slice(1);
  const handlerSpecificDevice = `${handlerSpecificID}${device} `;
  return handlerSpecificDevice;
}
export {
  CollabPageElement,
  getEventName
};
