var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || (target[__knownSymbol("metadata")] = array[3]), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _onlyLanguageDontConfigured_dec, _languages_dec, _widgets_dec, _height_dec, _level_dec, _currentScenario_dec, _a, _AimActionAddLanguage_decorators, _init;
import { html } from "lit";
import { customElement, property } from "lit/decorators.js";
import { tasks, updateTaskOnServer, getInfoMyService } from "./_100554_aimHelper";
import { AimActionBase } from "./_100554_aimActionBase";
import { initAimSelectWidget100554 } from "./_100554_aimSelectWidget";
import { initAimSelectLanguage100554 } from "./_100554_aimSelectLanguage";
const myName = "_100554_aimActionAddLanguage";
const message_pt = {
  "action_title": "verificar e adicionar uma nova linguagem",
  "btn_cancel": "Cancelar",
  "btn_confirm": "Confirmar",
  "filesSelected": "arquivos selecionado",
  "languagesSelected": "linguagens selecionadas",
  "anchorSelectWidget": "selecionar arquivos...",
  "anchorSelectLanguage": "selecionar linguagens...",
  "file": "Arquivo:",
  "language": "Linguagem:",
  "label_checkbox": "Somente criar action se n\xE3o existir a linguagem selecionada.",
  "message_error_1": "Por favor, selecione um widget para continuar",
  "message_error_2": "Por favor, selecione uma linguagem para continuar",
  "info": "Configura\xE7\xF5es"
};
const message_en = {
  "action_title": "check and add new language",
  "btn_cancel": "Cancel",
  "btn_confirm": "Confirm",
  "filesSelected": "files selected.",
  "languagesSelected": "languages selected.",
  "anchorSelectWidget": "select files...",
  "anchorSelectLanguage": "select languages...",
  "file": "File:",
  "language": "Language:",
  "label_checkbox": "Only create the action if the selected language does not exist.",
  "message_error_1": "Please select a widget first!",
  "message_error_2": "Please select a language first!",
  "info": "Config"
};
const messages = {
  "en": message_en,
  "pt": message_pt
};
_AimActionAddLanguage_decorators = [customElement("aim-action-add-language-100554")];
class AimActionAddLanguage extends (_a = AimActionBase, _currentScenario_dec = [property({ type: String })], _level_dec = [property({ type: Number })], _height_dec = [property({ type: Number })], _widgets_dec = [property({ type: Array })], _languages_dec = [property({ type: Array })], _onlyLanguageDontConfigured_dec = [property({ type: Boolean })], _a) {
  constructor() {
    super();
    this.currentScenario = __runInitializers(_init, 8, this, "main"), __runInitializers(_init, 11, this);
    this.level = __runInitializers(_init, 12, this, 0), __runInitializers(_init, 15, this);
    this.height = __runInitializers(_init, 16, this, 0), __runInitializers(_init, 19, this);
    this.widgets = __runInitializers(_init, 20, this, []), __runInitializers(_init, 23, this);
    this.languages = __runInitializers(_init, 24, this, []), __runInitializers(_init, 27, this);
    this.onlyLanguageDontConfigured = __runInitializers(_init, 28, this, false), __runInitializers(_init, 31, this);
    this.msg = messages["en"];
    this.assistant = "gpt3_typescript";
    this.title = "Add Language";
    this.language = "english";
    initAimSelectWidget100554();
    initAimSelectLanguage100554();
  }
  getRules() {
    return {
      levels: [2, 5],
      tags: ["*serviceSource*", "*servicePlugins*"]
    };
  }
  render() {
    var _a2;
    this.info = getInfoMyService(this);
    this.level = ((_a2 = this.info) == null ? void 0 : _a2.level) || 0;
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];
    return super.render();
  }
  handleCancel() {
    this.dispatchEvent(new CustomEvent("add-task", {
      detail: { cancel: "true" },
      bubbles: true,
      composed: true
    }));
  }
  changeScenario(ev, s) {
    ev.preventDefault();
    this.currentScenario = s;
  }
  handleSelectLanguageConfirm(e) {
    const languages = e.detail;
    this.languages = [...languages];
    this.handleCancel2();
  }
  handleSelectWidgetConfirm(e) {
    const widgets = e.detail;
    this.widgets = [...widgets];
    this.handleCancel2();
  }
  handleCancel2() {
    this.currentScenario = "main";
  }
  handleCheckConfig(e) {
    const inp = e.target;
    this.onlyLanguageDontConfigured = inp.checked;
  }
  handleAdd() {
    return __async(this, null, function* () {
      if (this.level === 2) {
        if (!this.info || this.info.actServiceOp && this.info.actServiceOp.tagName !== "SERVICE-SOURCE-100554") {
          throw new Error("Invalid service opposite side");
        }
        const position = this.info.position === "left" ? "right" : "left";
        if (!mls.actual[2][position]) throw new Error("Invalid File in mls.actual[2]");
        const { shortName } = mls.actual[2][position];
        this.widgets = [shortName];
      }
      if (this.widgets.length === 0) {
        window.collabMessages.add(this.msg.message_error_1, "error", { autoClose: true, timeToClose: 3e3 });
        return;
      }
      if (this.languages.length === 0) {
        window.collabMessages.add(this.msg.message_error_2, "error");
        return;
      }
      const { project } = mls.actual[5];
      if (!project) throw new Error("Invalid project");
      for (const widget of this.widgets) {
        this.addTask(project, widget);
      }
    });
  }
  addTask(project, fileName) {
    const args = {
      project,
      fileName,
      languages: this.languages,
      onlyLanguageDontConfigured: this.onlyLanguageDontConfigured
    };
    const taskRoot = {
      mode: "initializing",
      title: this.msg.action_title,
      widget: myName,
      children: [],
      args: JSON.stringify(args),
      trace: [(/* @__PURE__ */ new Date()).toISOString() + ": trask created at "]
    };
    tasks.unshift(taskRoot);
    this.prepareTask1(taskRoot, fileName, project);
    this.dispatchEvent(new CustomEvent("finished-add-task-root", {
      detail: taskRoot,
      bubbles: true,
      composed: true
    }));
  }
  renderAdd() {
    if (!this.info) throw new Error("Invalid Service Info");
    if (![2, 5].includes(this.level)) throw new Error("Invalid level");
    this.style.height = this.height + "px";
    this.style.display = "block";
    return html`
                ${this.currentScenario === "main" ? html`
                    <p> ${this.msg.action_title}</p>
                    <hr>
                    <div style="display:flex;">
                        <input id="check-config" type="checkbox" ?checked=${this.onlyLanguageDontConfigured} @change=${this.handleCheckConfig}></input>
                        <label for="check-config">${this.msg.label_checkbox}</label>
                    </div>
                    <div>
                        <fieldset>
                            <legend>${this.msg.info}</legend>
                            <div style=${this.level === 2 ? "display:none;" : "display:block;"}>
                                <span>${this.msg.file} ${this.widgets.length === 1 ? this.widgets[0] : this.widgets.length + " " + this.msg.filesSelected}</span>
                                <a href="#" @click=${(e) => this.changeScenario(e, "selectWidget")}> ${this.msg.anchorSelectWidget} </a>
                            </div>
                            <div>
                                <span>${this.msg.language} ${this.languages.length === 1 ? this.languages[0].name + "(" + this.languages[0].code + ")" : this.languages.length + " " + this.msg.languagesSelected}</span>
                                <a href="#" @click=${(e) => this.changeScenario(e, "selectLanguage")} > ${this.msg.anchorSelectLanguage} </a>
                            </div>
                        </fieldset>
                    </div>
                ` : ""}

                ${this.currentScenario === "selectLanguage" ? html`
                    <div>
                        <aim-select-language-100554
                            height=${this.height}
                            .defaultValue=${this.languages}
                            @select-language-confirm=${this.handleSelectLanguageConfirm} 
                            @select-language-cancel=${this.handleCancel2}>
                        </aim-select-language-100554>
                    </div>
                ` : ""}
    

                ${this.currentScenario === "selectWidget" ? html`
                    <aim-select-widget-100554
                        height=${this.height}
                        .defaultValue=${this.widgets}
                        @select-widget-confirm=${this.handleSelectWidgetConfirm} 
                        @select-widget-cancel=${this.handleCancel2}>
                    </aim-select-widget-100554>
                ` : ""}

                ${this.currentScenario === "main" ? html`    
                    <div class="buttonGroup" style="margin-top:1rem;">
                        <button @click="${this.handleCancel}">${this.msg.btn_cancel}</button>
                        <button @click="${this.handleAdd}">${this.msg.btn_confirm}</button>
                    </div>
                ` : ""}
    `;
  }
  getPromptTs(source, languages) {
    const langs = languages.map((lang) => `${lang.name}(${lang.code})`);
    const prompt = `adicionar as linguagens: ${langs.join(";")}  no c\xF3digo abaixo. Manter as linguagens existentes. N\xE3o retornar explica\xE7\xF5es. Retornar um \xFAnico bloco \`\`\`typescript

${source}
 `;
    return prompt;
  }
  getPromptHTML(source, attributesHTMLWithLanguages, languages) {
    const langs = languages.map((lang) => `${lang.name}(${lang.code})`);
    const prompt = `Complete os atributos: ${attributesHTMLWithLanguages.join(";")} que est\xE3o vazios, com os valores traduzidos de acordo com as seguintes linguagens: ${langs.join(";")}.
        
Por favor, n\xE3o adicione novos atributos nem modifique atributos que j\xE1 possuem valores. Apenas preencha os atributos que est\xE3o explicitamente vazios.

N\xE3o retornar explica\xE7\xF5es.
Retorne somente o c\xF3digo html em um bloco   \`\`\`html 

Aqui esta o codigo HTML: 

${source}
 `;
    return prompt;
  }
  prepareTask1(taskRoot, fileName, project) {
    this.mode = taskRoot.mode = "in progress";
    const ref = `_${project}_${fileName}`;
    this.addTaskAndWaitForCompletion(taskRoot, {
      mode: "initializing",
      title: "get info",
      widget: "_100554_aimTaskGetSourceLanguages",
      ref,
      trace: [],
      nextStep: this.prepareTaskPromptTs.name
      // danger, loop
    });
  }
  prepareTaskPromptTs(taskFinishResult) {
    var _a2;
    const child = taskFinishResult.taskChild;
    const result = taskFinishResult.result || "";
    if (taskFinishResult.status === "error") {
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      return;
    }
    if (!result) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no result find in task child");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    child.mode = "processed";
    const args = JSON.parse(result);
    console.info(args);
    taskFinishResult.taskRoot.args = JSON.stringify(args);
    if (!args.checkHtml && !args.checkTs) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no html/ts avaliable to add language");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    if (!args.checkTs) {
      this.prepareTaskPromptHTML(taskFinishResult);
      return;
    }
    this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
      mode: "initializing",
      title: "exec prompt",
      widget: "_100554_aimTaskExecLLM",
      ref: child.ref + ".ts",
      agent: this.assistant,
      prompt: this.getPromptTs((_a2 = args.detailsi18n) == null ? void 0 : _a2.source, args.languages),
      trace: [],
      nextStep: this.prepareTaskResultTs.name
      // danger, loop
    });
  }
  prepareTaskResultTs(taskFinishResult) {
    const child = taskFinishResult.taskChild;
    const result = child.result || "";
    if (taskFinishResult.status === "error") {
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      return;
    }
    if (!taskFinishResult.taskRoot.args) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": taskroot args is missing");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    if (!child.result) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no result in task");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    const infoFile = JSON.parse(taskFinishResult.taskRoot.args);
    child.mode = "processed";
    const nextStep = infoFile.checkHtml ? this.prepareTaskPromptHTML.name : this.endTasks.name;
    this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
      mode: "initializing",
      title: "add language in typescript source",
      widget: "_100554_aimTaskResultLanguageTypescript",
      ref: infoFile.fileName + ".ts",
      trace: [],
      _tempResult: result,
      nextStep
    });
  }
  prepareTaskPromptHTML(taskFinishResult) {
    const child = taskFinishResult.taskChild;
    const result = taskFinishResult.result || "";
    if (taskFinishResult.status === "error") {
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      return;
    }
    if (!result) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no result find in task child");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    child.mode = "processed";
    const args = JSON.parse(result);
    taskFinishResult.taskRoot.args = JSON.stringify(args);
    if (!args.checkHtml) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no html avaliable to add language");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
      mode: "initializing",
      title: "exec prompt",
      widget: "_100554_aimTaskExecLLM",
      ref: child.ref + ".ts",
      agent: this.assistant,
      prompt: this.getPromptHTML(args.html, args.attributesHTMLWithLanguages, args.languages),
      trace: [],
      nextStep: this.prepareTaskResultHTML.name
      // danger, loop
    });
  }
  prepareTaskResultHTML(taskFinishResult) {
    const child = taskFinishResult.taskChild;
    const result = child.result || "";
    if (taskFinishResult.status === "error") {
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      return;
    }
    if (!taskFinishResult.taskRoot.args) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": taskroot args is missing");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    if (!child.result) {
      child.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no result in task");
      this.mode = taskFinishResult.taskRoot.mode = child.mode = "error";
      this.requestUpdate();
      return;
    }
    const infoFile = JSON.parse(taskFinishResult.taskRoot.args);
    child.mode = "processed";
    this.addTaskAndWaitForCompletion(taskFinishResult.taskRoot, {
      mode: "initializing",
      title: "add language in html source",
      widget: "_100554_aimTaskResultLanguageHtml",
      ref: infoFile.fileName,
      trace: [],
      _tempResult: result,
      nextStep: this.endTasks.name
    });
  }
  endTasks(taskFinishResult) {
    const child = taskFinishResult.taskChild;
    if (taskFinishResult.status === "error") child.mode = "error";
    else child.mode = "processed";
    this.mode = taskFinishResult.taskRoot.mode = child.mode;
    this.requestUpdate();
    updateTaskOnServer(taskFinishResult.taskIndex);
  }
}
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "currentScenario", _currentScenario_dec, AimActionAddLanguage);
__decorateElement(_init, 5, "level", _level_dec, AimActionAddLanguage);
__decorateElement(_init, 5, "height", _height_dec, AimActionAddLanguage);
__decorateElement(_init, 5, "widgets", _widgets_dec, AimActionAddLanguage);
__decorateElement(_init, 5, "languages", _languages_dec, AimActionAddLanguage);
__decorateElement(_init, 5, "onlyLanguageDontConfigured", _onlyLanguageDontConfigured_dec, AimActionAddLanguage);
AimActionAddLanguage = __decorateElement(_init, 0, "AimActionAddLanguage", _AimActionAddLanguage_decorators, AimActionAddLanguage);
__runInitializers(_init, 1, AimActionAddLanguage);
export {
  AimActionAddLanguage
};
