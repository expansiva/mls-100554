import { IcaLitElement } from "./_100554_icaLitElement";
class IcaFormsInputStringBase extends IcaLitElement {
}
export {
  IcaFormsInputStringBase
};
