var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _AimTaskResultLanguageTypescript_decorators, _init, _a;
import { customElement } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
_AimTaskResultLanguageTypescript_decorators = [customElement("aim-task-result-language-typescript-100554")];
class AimTaskResultLanguageTypescript extends (_a = AimTaskBase) {
  onInitializing() {
    this.changeFile(this.taskRoot);
  }
  changeFile(taskRoot) {
    if (!taskRoot.args) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": taskroot args is missing");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    const args = JSON.parse(taskRoot.args);
    const mfile = mls.l2.editor.mfiles[args.fileName];
    if (!mfile) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no mfile find to this file");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    const result = this.taskChild._tempResult;
    if (!result) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no result find is taskchild");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    if (!args.detailsi18n) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": no detailsi18n find is args");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    const ts = this.extractScript(result);
    console.info(args.detailsi18n);
    const model = mfile.model;
    const startLineNumber = args.detailsi18n.startLine + 1;
    const startColumn = 1;
    const endLineNumber = args.detailsi18n.endLine - 1;
    ;
    const endColumn = model.getLineMaxColumn(endLineNumber);
    const newText = ts;
    const editOperation = {
      range: new monaco.Range(startLineNumber, startColumn, endLineNumber, endColumn),
      text: newText,
      forceMoveMarkers: true
    };
    model.pushEditOperations([], [editOperation], () => null);
    this.notifyCompleteByStatus("ok", "");
  }
  extractScript(src) {
    const regex = /```typescript([\s\S]+?)```/g;
    const matches = src.match(regex);
    const contents = [];
    let ret = src;
    if (matches) {
      for (const m of matches) {
        const conteudo = m.replace(/```typescript|```/g, "").trim();
        contents.push(conteudo);
      }
      ret = contents[0];
    }
    return ret;
  }
  onIconClick(action) {
    console.error("dont implemented");
  }
}
_init = __decoratorStart(_a);
AimTaskResultLanguageTypescript = __decorateElement(_init, 0, "AimTaskResultLanguageTypescript", _AimTaskResultLanguageTypescript_decorators, AimTaskResultLanguageTypescript);
__runInitializers(_init, 1, AimTaskResultLanguageTypescript);
export {
  AimTaskResultLanguageTypescript
};
