var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getProtoOf = Object.getPrototypeOf;
var __reflectGet = Reflect.get;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __superGet = (cls, obj, key) => __reflectGet(__getProtoOf(cls), key, obj);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _styleel_dec, _level_dec, _renderType_dec, _isICAGroup_dec, _id_dec, _widget_dec, _changeState_dec, _a, _init;
import { collabState } from "./_100554_collabLitElement";
import { IcaLitElement } from "./_100554_icaLitElement";
import * as icaGlobal from "./_100554_icaGlobal";
import * as states from "./_100554_icaCollabStore";
import { convertFileNameToTag, convertTagToFileName } from "./_100554_utilsLit";
import { html, unsafeHTML } from "lit";
import { property } from "lit/decorators.js";
import * as myDefinition from "./_100554_icaBaseDescription";
const _IcaLitElementBase = class _IcaLitElementBase extends (_a = IcaLitElement, _changeState_dec = [property({ type: String }), collabState(states.CHANGESTATE)], _widget_dec = [property({ type: String, reflect: true })], _id_dec = [property({ type: String, reflect: true })], _isICAGroup_dec = [property({ type: Boolean, reflect: true })], _renderType_dec = [property({ type: String })], _level_dec = [property({ type: String })], _styleel_dec = [property({ type: String })], _a) {
  constructor() {
    super();
    this.changeState = __runInitializers(_init, 8, this, ""), __runInitializers(_init, 11, this);
    this.id = __runInitializers(_init, 16, this, ""), __runInitializers(_init, 19, this);
    this.styleel = __runInitializers(_init, 32, this, ""), __runInitializers(_init, 35, this);
    this.internalInnerHTML = "";
    this.isLoadMyAction = {};
    this.lastWidget = "";
    this.styleElMain = void 0;
  }
  createRenderRoot() {
    return this;
  }
  connectedCallback() {
    super.connectedCallback();
    this.setInitialConfigs();
  }
  firstUpdated(changedProperties) {
    return __async(this, null, function* () {
      __superGet(_IcaLitElementBase.prototype, this, "firstUpdated").call(this, changedProperties);
      const tempeEl = document.createElement("span");
      tempeEl.style.cssText = this.styleel ? this.styleel : "";
      this.styleElMain = tempeEl.style;
      yield this.performPreSlotAllocationOperations();
    });
  }
  updated(changedProperties) {
    super.updated(changedProperties);
    const hasLevel = changedProperties.has("level");
    const hasStyleEl = changedProperties.has("styleel");
    if (this.lastWidget !== this.widget) {
      this.lastWidget = this.widget;
      customElements.whenDefined(this.lastWidget).then(() => {
        this.updateStyleDisplay();
      });
    }
    if (hasLevel) {
      const valLevel = changedProperties.get("level");
      if (this.level === valLevel) return;
      this.updateLevelIcas();
    }
    if (hasStyleEl) {
      const valStyleEl = changedProperties.get("styleel");
      if (this.styleel === valStyleEl) return;
      this.updateStyleEl();
    }
  }
  changeStateStyle(style) {
    if (!this.styleElMain || !style) return;
    const el = this.querySelector(`${this.widget}:first-child`);
    if (el) {
      this.styleElMain.cssText = el.style.cssText;
      Object.assign(this.styleElMain, style);
      el.style.cssText = this.styleElMain.cssText;
      this.styleel = el.style.cssText;
    }
  }
  updateId(id) {
    if (!this.widget) return;
    const widgetEl = this.querySelector(this.widget);
    if (!widgetEl) return;
    widgetEl.id = id;
  }
  updateStyleEl() {
    if (!this.widget) return;
    const widgetEl = this.querySelector(this.widget);
    if (!widgetEl) return;
    widgetEl.style.cssText = this.styleel || "";
  }
  updateLevelIcas() {
    if (!this.level) return;
    const traverseShadowRoot = (element) => {
      if (element.tagName.toLowerCase().startsWith("ica")) {
        element.setAttribute("level", this.level);
        return;
      }
      if (element.shadowRoot) {
        element.shadowRoot.querySelectorAll("*").forEach((item) => {
          if (item.tagName.toLowerCase().startsWith("ica")) {
            item.setAttribute("level", this.level);
          }
        });
      } else {
        const children = Array.from(element.children);
        if (children.length > 0) {
          children.forEach((child) => {
            if (child.tagName.toLowerCase().startsWith("ica")) {
              child.setAttribute("level", this.level);
            }
          });
        }
      }
    };
    if (!this.widget) return;
    const widgetEl = this.querySelector(this.widget);
    if (!widgetEl) return;
    traverseShadowRoot(widgetEl);
  }
  updateStyleDisplay() {
    const el = this.querySelector(this.widget);
    if (el) {
      const d = window.getComputedStyle(el);
      this.style.display = d.display;
    }
  }
  shouldUpdate(changedProperties) {
    if (changedProperties.get("changeState") !== void 0 && this.changeState) {
      this.doChangeState(this.changeState);
      return false;
    }
    return true;
  }
  doChangeState(js) {
    const info = JSON.parse(js);
    switch (info.tp) {
      case "menu":
        break;
      case "style":
        this.changeStateStyle(info.style);
        break;
      case "html":
        this.changeStateHtml(info.html);
        break;
      default:
        "";
        break;
    }
  }
  importAction(imports, actions, level, mode = "", position = "") {
    return __async(this, null, function* () {
      try {
        if (!imports.startsWith("./")) imports = "./" + imports;
        const { getTemplate } = yield import(imports);
        const temp = getTemplate(mode, position);
        actions[level].push(temp);
      } catch (e) {
        console.info(e);
      }
    });
  }
  getICAComponents(scope) {
    let ret = [];
    const reentrance = (el) => {
      const tag = el.tagName.toLowerCase();
      if (tag.startsWith(`${icaGlobal.PREFIX}-`)) {
        ret.push(el);
      }
      const isGroup = el.getAttribute(`${icaGlobal.ATTRGROUP}`);
      if (!isGroup || isGroup === "false") {
        Array.from(el.children).forEach((i) => {
          reentrance(i);
        });
      }
    };
    Array.from(scope.children).forEach((i) => {
      reentrance(i);
    });
    return ret;
  }
  getMyScope() {
    let ret = this.closest(`${icaGlobal.ICAPAGE}`);
    if (!ret) ret = this.closest("body");
    return ret;
  }
  getIcaParent(target) {
    const parent = target.parentElement;
    if (!parent) return;
    const tag = parent.tagName.toLowerCase();
    if (!tag.startsWith(`${icaGlobal.PREFIX}-`)) return this.getIcaParent(parent);
    else if (tag.startsWith(`${icaGlobal.PREFIX}-`)) return parent;
  }
  performPreSlotAllocationOperations() {
    return __async(this, null, function* () {
      if (!this.widget) return;
      const tag = convertFileNameToTag(this.widget);
      if (tag.startsWith(icaGlobal.PREFIX) || tag.startsWith(icaGlobal.PREFIXWCD)) return;
      Promise.all([tag].map((wc) => customElements.whenDefined(wc))).then(() => __async(this, null, function* () {
        let childrens = Array.from(this.children).filter((child) => child.tagName !== tag.toUpperCase());
        const widgetElement = this.querySelector(tag);
        if (!widgetElement || !childrens || childrens.length === 0) return;
        childrens.forEach((child) => {
          if (child.tagName.toLowerCase().startsWith(icaGlobal.PREFIXWCD)) return;
          child.remove();
          widgetElement.appendChild(child);
        });
        const slots = widgetElement.shadowRoot ? Array.from(widgetElement.shadowRoot.querySelectorAll(`slot`)) : Array.from(widgetElement.querySelectorAll(`slot`));
        if (!slots || slots.length === 0) return;
        const slotWithoutName = slots.find((slot) => !slot.getAttribute("name"));
        childrens.forEach((element) => {
          var _a2, _b;
          const elementSlotName = element.getAttribute("slot");
          if (elementSlotName) {
            const slotByName = slots.find((slot) => slot.getAttribute("name") === elementSlotName);
            if (slotByName) (_a2 = slotByName.parentNode) == null ? void 0 : _a2.insertBefore(element, slotByName);
          } else if (slotWithoutName) {
            (_b = slotWithoutName.parentNode) == null ? void 0 : _b.insertBefore(element, slotWithoutName);
          }
        });
        slots.forEach((sl) => sl.remove());
      }));
    });
  }
  setInitialConfigs() {
    return __async(this, null, function* () {
      if (this.widget) {
        const fileName = convertTagToFileName(this.widget);
        yield import("./" + fileName);
      }
    });
  }
  render() {
    this.style.display = "block";
    if (!this.style.width) this.style.width = "inherit";
    if (!this.style.height) this.style.height = "inherit";
    const attrs = this.getAttributes();
    let code = `
            <${this.widget} ${attrs}>
            </${this.widget}>
        `;
    return html`${unsafeHTML(code)}`;
  }
  getAttributes() {
    const excludesProps = ["rendertype", "level", "widget", "style", "styleel", "id"];
    const objVariations = {
      0: "en",
      1: "pt",
      2: "es",
      3: "ru"
    };
    const variation = objVariations[this.globalVariation || 0];
    const attributes = [];
    const attributeNames = this.getAttributeNames();
    for (let attrName of attributeNames) {
      if (excludesProps.includes(attrName)) continue;
      let attrValue = this.getAttribute(attrName);
      if (attrName === "idel") attrName = "id";
      if (attrValue !== null) {
        attributes.push({
          name: attrName,
          value: attrValue
        });
      }
    }
    const attrsByVariation = this.filterAttributes(attributes, variation);
    let attributesStr = "";
    attrsByVariation.forEach((item) => attributesStr += `${item.name}="${item.value}"`);
    console.info({ el: this, variation, attributes, attrsByVariation });
    return attributesStr;
  }
  filterAttributes(attributes, variation) {
    const variationSuffix = `-${variation}`;
    const variationAttributes = attributes.filter((attr) => attr.name.endsWith(variationSuffix));
    const nonVariationAttributes = attributes.filter((attr) => {
      if (attr.name.includes("-")) return false;
      const split = attr.name.split("-");
      if (split.length > 1) split.pop();
      const attrBase = split.join("-");
      return !attributes.some((a) => a.name.startsWith(attrBase) && a !== attr && variationAttributes.includes(a));
    });
    const aux = [...nonVariationAttributes, ...variationAttributes];
    aux.forEach((attr) => {
      const split = attr.name.split("-");
      if (split.length > 0) {
        const language = split.pop();
        if (language === variation) attr.name = split.join("-");
      }
    });
    return aux;
  }
  getMyInfos() {
    let cleanedInput = this.tagName.toLocaleLowerCase().replace(/^ica-|-\d+$/g, "");
    let root, subgroup, finalgroup;
    let parts = cleanedInput.split("-");
    if (parts.length < 3) throw new Error("Invalid ica tag name");
    root = parts.shift();
    subgroup = parts.shift();
    finalgroup = parts.join(" ");
    return {
      root: root || "",
      subGroup: subgroup || "",
      finalGroup: finalgroup || ""
    };
  }
  getMyEvents() {
    if (!this.myInfos) this.myInfos = this.getMyInfos();
    return myDefinition.getFormComponentsEvents(this.myInfos.root, this.myInfos.subGroup, this.myInfos.finalGroup);
  }
  getDefinitionFromEvent(event) {
    if (!this.myInfos) this.myInfos = this.getMyInfos();
    return myDefinition.getEventDescription(this.myInfos.root, this.myInfos.subGroup, this.myInfos.finalGroup, event);
  }
};
_init = __decoratorStart(_a);
__decorateElement(_init, 5, "changeState", _changeState_dec, _IcaLitElementBase);
__decorateElement(_init, 5, "widget", _widget_dec, _IcaLitElementBase);
__decorateElement(_init, 5, "id", _id_dec, _IcaLitElementBase);
__decorateElement(_init, 5, "isICAGroup", _isICAGroup_dec, _IcaLitElementBase);
__decorateElement(_init, 5, "renderType", _renderType_dec, _IcaLitElementBase);
__decorateElement(_init, 5, "level", _level_dec, _IcaLitElementBase);
__decorateElement(_init, 5, "styleel", _styleel_dec, _IcaLitElementBase);
__decoratorMetadata(_init, _IcaLitElementBase);
let IcaLitElementBase = _IcaLitElementBase;
export {
  IcaLitElementBase
};
