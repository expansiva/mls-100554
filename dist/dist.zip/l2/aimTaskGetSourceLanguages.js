var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __knownSymbol = (name, symbol) => (symbol = Symbol[name]) ? symbol : Symbol.for("Symbol." + name);
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __decoratorStart = (base) => {
  var _a2;
  return [, , , __create((_a2 = base == null ? void 0 : base[__knownSymbol("metadata")]) != null ? _a2 : null)];
};
var __decoratorStrings = ["class", "method", "getter", "setter", "accessor", "field", "value", "get", "set"];
var __expectFn = (fn) => fn !== void 0 && typeof fn !== "function" ? __typeError("Function expected") : fn;
var __decoratorContext = (kind, name, done, metadata, fns) => ({ kind: __decoratorStrings[kind], name, metadata, addInitializer: (fn) => done._ ? __typeError("Already initialized") : fns.push(__expectFn(fn || null)) });
var __decoratorMetadata = (array, target) => __defNormalProp(target, __knownSymbol("metadata"), array[3]);
var __runInitializers = (array, flags, self, value) => {
  for (var i = 0, fns = array[flags >> 1], n = fns && fns.length; i < n; i++) flags & 1 ? fns[i].call(self) : value = fns[i].call(self, value);
  return value;
};
var __decorateElement = (array, flags, name, decorators, target, extra) => {
  var fn, it, done, ctx, access, k = flags & 7, s = !!(flags & 8), p = !!(flags & 16);
  var j = k > 3 ? array.length + 1 : k ? s ? 1 : 2 : 0, key = __decoratorStrings[k + 5];
  var initializers = k > 3 && (array[j - 1] = []), extraInitializers = array[j] || (array[j] = []);
  var desc = k && (!p && !s && (target = target.prototype), k < 5 && (k > 3 || !p) && __getOwnPropDesc(k < 4 ? target : { get [name]() {
    return __privateGet(this, extra);
  }, set [name](x) {
    return __privateSet(this, extra, x);
  } }, name));
  k ? p && k < 4 && __name(extra, (k > 2 ? "set " : k > 1 ? "get " : "") + name) : __name(target, name);
  for (var i = decorators.length - 1; i >= 0; i--) {
    ctx = __decoratorContext(k, name, done = {}, array[3], extraInitializers);
    if (k) {
      ctx.static = s, ctx.private = p, access = ctx.access = { has: p ? (x) => __privateIn(target, x) : (x) => name in x };
      if (k ^ 3) access.get = p ? (x) => (k ^ 1 ? __privateGet : __privateMethod)(x, target, k ^ 4 ? extra : desc.get) : (x) => x[name];
      if (k > 2) access.set = p ? (x, y) => __privateSet(x, target, y, k ^ 4 ? extra : desc.set) : (x, y) => x[name] = y;
    }
    it = (0, decorators[i])(k ? k < 4 ? p ? extra : desc[key] : k > 4 ? void 0 : { get: desc.get, set: desc.set } : target, ctx), done._ = 1;
    if (k ^ 4 || it === void 0) __expectFn(it) && (k > 4 ? initializers.unshift(it) : k ? p ? extra = it : desc[key] = it : target = it);
    else if (typeof it !== "object" || it === null) __typeError("Object expected");
    else __expectFn(fn = it.get) && (desc.get = fn), __expectFn(fn = it.set) && (desc.set = fn), __expectFn(fn = it.init) && initializers.unshift(fn);
  }
  return k || __decoratorMetadata(array, target), desc && __defProp(target, name, desc), p ? k ^ 4 ? extra : desc : target;
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateIn = (member, obj) => Object(obj) !== obj ? __typeError('Cannot use the "in" operator on this value') : member.has(obj);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
var _AimTaskGetSourceLanguages_decorators, _init, _a;
import { customElement } from "lit/decorators.js";
import { AimTaskBase } from "./_100554_aimTaskBase";
import { getDataInternationalization } from "./_100554_aimTaskGetSourceLanguageTypescript";
import { checkAttributteHasVariation } from "./_100554_icaBaseDescription";
_AimTaskGetSourceLanguages_decorators = [customElement("aim-task-get-source-languages-100554")];
class AimTaskGetSourceLanguages extends (_a = AimTaskBase) {
  onInitializing() {
    this.getSource();
  }
  getSource() {
    if (!this.taskRoot.args) {
      this.taskChild.trace.push((/* @__PURE__ */ new Date()).toISOString() + ": taskroot args is missing");
      this.notifyCompleteByStatus("error", "");
      return;
    }
    const args = JSON.parse(this.taskRoot.args);
    this.prepareInfoFile(args).then((ret) => {
      const result = ret;
      this.notifyCompleteByStatus("ok", JSON.stringify(result));
    }).catch((e) => {
      this.notifyCompleteByStatus("error", e);
    });
  }
  prepareInfoFile(args) {
    return __async(this, null, function* () {
      var _a2;
      const fileName = `_${args.project}_${args.fileName}`;
      const infoFile = {
        fileName,
        checkHtml: true,
        checkTs: true,
        languages: args.languages,
        html: "",
        detailsi18n: void 0,
        attributesHTML: [],
        attributesHTMLWithLanguages: [],
        htmlTags: [],
        onlyLanguageDontConfigured: args.onlyLanguageDontConfigured
      };
      const mfile = mls.l2.editor.mfiles[fileName];
      if (!mfile) infoFile.checkTs = false;
      const valueTs = mfile.model.getValue() || "";
      if (!valueTs) infoFile.checkTs = false;
      const details = getDataInternationalization(valueTs);
      if (!details.internationalization || !details.internationalization.source || details.internationalization.languages.length === 0) infoFile.checkTs = false;
      if (args.onlyLanguageDontConfigured && this.allElementsPresent(args.languages.map((lang) => lang.code), ((_a2 = details.internationalization) == null ? void 0 : _a2.languages) || [])) infoFile.checkTs = false;
      infoFile.detailsi18n = details.internationalization;
      const keyToFileHTML = mls.stor.getKeyToFiles(args.project, 2, args.fileName, "", ".html");
      const fileHTML = mls.stor.files[keyToFileHTML];
      if (!fileHTML) infoFile.checkHtml = false;
      else {
        const valueHTML = yield fileHTML.getContent();
        if (typeof valueHTML !== "string") {
          infoFile.checkHtml = false;
          return infoFile;
        }
        const rc = this.prepareHTMLInfo(valueHTML);
        if (rc.components.length === 0) infoFile.checkHtml = false;
        infoFile.htmlTags = rc.components;
        infoFile.attributesHTML = rc.attrs;
        const preparedHtml = this.parseHtmlString(valueHTML, infoFile.htmlTags, infoFile.attributesHTML, infoFile.languages);
        infoFile.html = preparedHtml.text;
        infoFile.attributesHTMLWithLanguages = preparedHtml.attributesHTMLWithLanguages;
      }
      return infoFile;
    });
  }
  prepareHTMLInfo(valueHTML) {
    const rc = {
      attrs: [],
      components: []
    };
    const data = this.analyzeHTML(valueHTML);
    data.attrs.forEach((attr) => {
      const hasVariation = checkAttributteHasVariation(attr);
      if (hasVariation) rc.attrs.push(attr);
    });
    rc.components = data.components;
    return rc;
  }
  allElementsPresent(arrayA, arrayB) {
    for (const element of arrayA) {
      if (!arrayB.includes(element)) {
        return false;
      }
    }
    return true;
  }
  analyzeHTML(htmlString) {
    const tempElement = document.createElement("div");
    tempElement.innerHTML = htmlString;
    const data = {
      components: [],
      attrs: []
    };
    function traverseElement(element) {
      if (element.tagName.includes("-")) {
        const tagName = element.tagName.toLowerCase();
        if (!data.components.includes(tagName)) {
          data.components.push(tagName);
        }
        const attributes = element.getAttributeNames();
        attributes.forEach((attribute) => {
          if (!data.attrs.includes(attribute)) {
            data.attrs.push(attribute);
          }
        });
      }
      if (element.children.length > 0) {
        for (let i = 0; i < element.children.length; i++) {
          traverseElement(element.children[i]);
        }
      }
    }
    traverseElement(tempElement);
    return data;
  }
  parseHtmlString(htmlString, tagsToProcess, propsToProcess, languages) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, "text/html");
    const elements = doc.body.children;
    const attributesHTMLWithLanguages = /* @__PURE__ */ new Set();
    function containsAnyAttributes(element, attrs) {
      for (const attr of attrs) {
        if (element.hasAttribute(attr)) return true;
      }
      return false;
    }
    function addAttributesForEachLanguage(element, attrs, languages2) {
      for (const attr of attrs) {
        if (element.hasAttribute(attr)) {
          for (const lang of languages2) {
            const attrWithLanguage = `${attr}-${lang.code}`;
            const elementAlreadyHasAttr = element.hasAttribute(attrWithLanguage);
            if (!elementAlreadyHasAttr) {
              element.setAttribute(attrWithLanguage, "");
              attributesHTMLWithLanguages.add(attrWithLanguage);
            }
          }
        }
      }
    }
    function traverse(element) {
      const tagName = element.tagName.toLowerCase();
      const elementContainsAnyAttributes = containsAnyAttributes(element, propsToProcess);
      const needProcessTag = tagsToProcess.includes(tagName);
      if (needProcessTag && elementContainsAnyAttributes) {
        addAttributesForEachLanguage(element, propsToProcess, languages);
      }
      if (element.children.length > 0) {
        for (let i = 0; i < element.children.length; i++) {
          const child = element.children[i];
          traverse(child);
        }
      }
    }
    function decodeHTMLEntities(str) {
      return str.replace(/&quot;/g, '"').replace(/&apos;/g, "'");
    }
    for (let i = 0; i < elements.length; i++) {
      traverse(elements[i]);
    }
    return { text: doc.body.innerHTML, attributesHTMLWithLanguages: Array.from(attributesHTMLWithLanguages) };
  }
}
_init = __decoratorStart(_a);
AimTaskGetSourceLanguages = __decorateElement(_init, 0, "AimTaskGetSourceLanguages", _AimTaskGetSourceLanguages_decorators, AimTaskGetSourceLanguages);
__runInitializers(_init, 1, AimTaskGetSourceLanguages);
export {
  AimTaskGetSourceLanguages
};
